"""Deciding what to test: the reach of a change, and the coverage a scope needs.

Two agents that answer the questions a QE lead asks before anything is run.

**Impact Analyzer** -- "we are changing this; what does it touch?" It traces a
change through the business journeys it sits in, the requirements behind it, the
tests that exercise it, the automation that will break on it, and the defects the
area has a history of. The most useful thing it reports is what nothing covers: a
changed step with no test is a release risk that a green regression run will
never reveal, because no test in that run looks at it.

**Coverage Planning** -- "what should we write, in what order, with the days we
have?" It gives every requirement a risk tier, holds it to the coverage that tier
requires, and turns the shortfall into a backlog ordered by risk removed per
engineer-day. When the backlog does not fit the capacity, it says what was
deferred and what risk that leaves, rather than quietly planning less.

Both compute their answer from recorded project state in `gather_context`, so the
prompt and the deterministic draft reason over the same facts. Every threshold and
effort figure they use is returned with the result, because a plan whose
assumptions are hidden cannot be argued with -- only accepted or ignored.
"""

from __future__ import annotations

import json
import string
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select

from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.healing.impact import CRITICALITY_WEIGHT, affected_steps
from app.models.defect import Defect
from app.models.testing import (
    BusinessFlow,
    Requirement,
    TestCase,
    TestDependency,
    TestScenario,
    TestScript,
)

PRIORITY_WEIGHT = {"critical": 1.0, "high": 0.75, "medium": 0.5, "low": 0.25}
SEVERITY_WEIGHT = {"blocker": 1.0, "critical": 1.0, "major": 0.6, "minor": 0.25, "trivial": 0.1}
OPEN_DEFECT_STATUSES = {"new", "open", "triaged", "in_progress", "reopened"}

# A test this flaky or this recently red is coverage nobody can rely on.
FLAKY_THRESHOLD = 0.2
FAILING_RESULTS = {"failed", "error", "broken"}

_WORD_EDGES = string.punctuation.replace("-", "") + string.whitespace


def _clean_list(value: Any) -> list[str]:  # noqa: ANN401
    """A caller's list, stripped and de-duplicated, keeping its order."""
    if value is None:
        return []
    if isinstance(value, str):
        value = value.split(",")
    seen: dict[str, None] = {}
    for item in value:
        text = str(item).strip()
        if text and text.lower() not in {key.lower() for key in seen}:
            seen[text] = None
    return list(seen)


def _aware(moment: datetime | None) -> datetime | None:
    if moment is not None and moment.tzinfo is None:
        return moment.replace(tzinfo=UTC)
    return moment


def _failure_rate(case: TestCase) -> float:
    return round(case.failure_count / case.execution_count, 4) if case.execution_count else 0.0


def _is_unstable(case: TestCase) -> bool:
    return (case.flakiness_score or 0.0) >= FLAKY_THRESHOLD or case.last_result in FAILING_RESULTS


def _requirements_by_key(session: Any, project_id: str) -> dict[str, Requirement]:  # noqa: ANN401
    rows = session.execute(
        select(Requirement).where(
            Requirement.project_id == project_id, Requirement.is_deleted.is_(False)
        )
    ).scalars()
    return {row.external_key.upper(): row for row in rows}


def _live_cases(session: Any, project_id: str) -> list[TestCase]:  # noqa: ANN401
    return list(
        session.execute(
            select(TestCase).where(
                TestCase.project_id == project_id, TestCase.is_deleted.is_(False)
            )
        )
        .scalars()
        .all()
    )


def _defects(session: Any, project_id: str) -> list[Defect]:  # noqa: ANN401
    return list(
        session.execute(
            select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
        )
        .scalars()
        .all()
    )


# ===========================================================================
# Impact Analyzer
# ===========================================================================

# How much each signal moves the risk score. Returned with every result so the
# rating can be traced back to what produced it.
IMPACT_FACTOR_WEIGHTS = {
    "journey_criticality": 0.30,
    "requirement_priority": 0.20,
    "blind_spots": 0.20,
    "open_defects": 0.15,
    "unstable_tests": 0.15,
}

# Assumed when a manual test has no recorded duration.
MANUAL_TEST_MINUTES = 10


def _risk_rating(score: float) -> str:
    if score >= 0.75:
        return "critical"
    if score >= 0.5:
        return "high"
    if score >= 0.3:
        return "medium"
    return "low"


# Each fenced block is cut at app.ai.prompts.safety.DEFAULT_MAX_CHARS. A list
# cut there arrives as broken JSON with its most important rows possibly gone,
# so lists are fitted to a budget below that limit instead: whole rows only,
# worst first, and the block says how many of how many it shows.
BLOCK_BUDGET_CHARS = 3500


def _rendered_size(value: Any, depth: int) -> int:  # noqa: ANN401
    """Characters `value` takes once the fence pretty-prints it at `depth`.

    Measured the way `app.ai.prompts.library` renders a block -- JSON with an
    indent of two -- because compact JSON undercounts it by half or more.
    """
    text = json.dumps(value, indent=2, default=str, ensure_ascii=False)
    return len(text) + len(text.splitlines()) * 2 * depth + 2


def _fit(rows: list[Any], *, budget: int = BLOCK_BUDGET_CHARS, depth: int = 2) -> dict[str, Any]:
    """As many whole rows as fit the budget, with the total they were taken from.

    `depth` is how deeply the list sits inside its block, since every level
    adds indentation to every line.
    """
    shown: list[Any] = []
    used = 80  # the wrapper's own keys
    for row in rows:
        size = _rendered_size(row, depth)
        if used + size > budget:
            break
        shown.append(row)
        used += size
    return {"showing": len(shown), "of": len(rows), "rows": shown}


def _impact_blocks(analysis: dict[str, Any]) -> dict[str, Any]:
    """The impact trace as the model sees it, one fenced block per concern."""
    retest = analysis.get("retest") or {}
    tests = retest.get("tests") or []
    automation = analysis.get("automation") or {}
    defects = analysis.get("defects") or {}
    return {
        # The judgement-bearing summary. Small by construction, never cut.
        "trace": {
            "risk": {
                "score": (analysis.get("risk") or {}).get("score"),
                "rating": (analysis.get("risk") or {}).get("rating"),
                "factors": {
                    f["factor"]: f["value"] for f in (analysis.get("risk") or {}).get("factors", [])
                },
            },
            "journeys": _fit(analysis.get("journeys") or [], budget=1000, depth=3),
            "blind_spots": _fit(
                [
                    {k: spot[k] for k in ("journey", "step", "changed", "why_at_risk")}
                    for spot in analysis.get("blind_spots") or []
                ],
                budget=1000,
                depth=3,
            ),
            "unmapped": _fit(analysis.get("unmapped") or [], budget=300, depth=3),
            "unresolved_requirements": _fit(
                analysis.get("unresolved_requirements") or [], budget=200, depth=3
            ),
            "retest_totals": {key: value for key, value in retest.items() if key != "tests"},
        },
        "requirements": _fit(
            [
                {"key": r["key"], "title": (r["title"] or "")[:60], "priority": r["priority"], "how": r["how"]}
                for r in analysis.get("requirements") or []
            ]
        ),
        "tests": _fit(
            [
                {
                    "key": row["key"],
                    "title": (row["title"] or "")[:60],
                    "priority": row["priority"],
                    "automated": row["automated"],
                    "unstable": row["unstable"],
                    "why": row["reasons"][0] if row["reasons"] else None,
                }
                for row in tests
            ]
        ),
        "automation": {
            "likely_to_break": _fit(automation.get("likely_to_break") or [], budget=3000, depth=3),
            "rerun_count": len(automation.get("rerun") or []),
        },
        "defects": {
            "open": _fit(
                [
                    {"key": d["key"], "severity": d["severity"], "module": d["module"], "title": (d["title"] or "")[:60]}
                    for d in defects.get("open") or []
                ],
                budget=3000,
                depth=3,
            ),
            "recently_resolved_count": len(defects.get("recently_resolved") or []),
        },
    }


class ImpactAnalyzerAgent(BaseAgent):
    key = "impact-analyzer"
    computed_outputs = True
    name = "Impact Analyzer Agent"
    category = "Planning"
    description = (
        "Traces a change through business journeys, requirements, tests, automation and "
        "defect history to show its blast radius, its risk, and the blind spots no test covers."
    )
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "Radar"
    supported_tools = ["knowledge"]
    goal = "Know everything a change touches, and where nothing is watching, before it ships."
    system_instructions = (
        "You are a change impact analyst. Trace a change to every journey, requirement, test "
        "and script it reaches, rate the risk from evidence, and lead with the blind spots: "
        "anything the change touches that no test would notice breaking."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "change_description": {
                "type": "string",
                "description": (
                    "What changed, in words. Requirement keys, journey components and "
                    "module names in it are recognised."
                ),
            },
            "changed_components": {
                "type": "array",
                "items": {"type": "string"},
                "description": "UI components or test ids that changed, e.g. checkout-submit-btn",
            },
            "changed_endpoints": {
                "type": "array",
                "items": {"type": "string"},
                "description": "API endpoints that changed, e.g. /api/payments",
            },
            "changed_modules": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Modules that changed",
            },
            "changed_requirements": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Keys of requirements whose behaviour changed, e.g. PAY-201",
            },
            "lookback_days": {
                "type": "integer",
                "default": 14,
                "description": "When no change is named, analyse requirements edited in this many days",
            },
        },
    }

    # ------------------------------------------------------------------
    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        session, project_id = ctx.session, ctx.project_id
        requirements = _requirements_by_key(session, project_id)

        components = _clean_list(inputs.get("changed_components"))
        endpoints = _clean_list(inputs.get("changed_endpoints"))
        modules = _clean_list(inputs.get("changed_modules"))
        requirement_keys = [key.upper() for key in _clean_list(inputs.get("changed_requirements"))]
        description = str(inputs.get("change_description") or "").strip()
        source = "stated"

        # A description names things too. Only exact requirement keys, the
        # components modelled in a journey, and module names are taken from it
        # -- anything looser would be guessing at scope.
        if description:
            words = {word.strip(_WORD_EDGES).upper() for word in description.split()}
            mentioned = sorted(key for key in requirements if key in words)

            # "the login form" names the `login-form` component. Hyphens and
            # underscores read as spaces, and matching is on whole words.
            def spaced(text: str) -> str:
                cleaned = " ".join(word.strip(_WORD_EDGES) for word in text.lower().split())
                return " " + cleaned.replace("-", " ").replace("_", " ") + " "

            text = spaced(description)
            known_components = {
                str(item)
                for flow in session.execute(
                    select(BusinessFlow).where(
                        BusinessFlow.project_id == project_id, BusinessFlow.is_deleted.is_(False)
                    )
                ).scalars()
                for step in flow.steps
                for item in (step.ui_components or [])
            }
            mentioned_components = sorted(c for c in known_components if spaced(c) in text)
            # A word already spent naming a component does not also name its
            # module: "the login form" is one control, not the whole Login module.
            for component in mentioned_components:
                text = text.replace(spaced(component), " ")
            known_modules = {row.module for row in requirements.values() if row.module}
            mentioned_modules = sorted(m for m in known_modules if spaced(m) in text)

            if not (components or endpoints or modules or requirement_keys) and (
                mentioned or mentioned_components or mentioned_modules
            ):
                source = "description"
            requirement_keys = _clean_list(requirement_keys + mentioned)
            components = _clean_list(components + mentioned_components)
            modules = _clean_list(modules + mentioned_modules)

        # Nothing named at all: look at what was recently edited, and say so.
        # `or 14` would read an explicit 0 as "use the default".
        raw_lookback = inputs.get("lookback_days")
        lookback = max(0, int(raw_lookback)) if raw_lookback is not None else 14
        if not (components or endpoints or modules or requirement_keys):
            cutoff = datetime.now(UTC) - timedelta(days=lookback)
            recent = [
                row for row in requirements.values() if (_aware(row.updated_at) or cutoff) >= cutoff
            ]
            if recent:
                source = "recent_requirement_edits"
                requirement_keys = sorted(row.external_key.upper() for row in recent)

        if not (components or endpoints or modules or requirement_keys):
            return {
                "analysis": None,
                "change": {"description": description, "source": "none"},
                "evidence": [],
                "tool_calls": [],
            }

        changed_requirements = [requirements[key] for key in requirement_keys if key in requirements]
        unresolved = [key for key in requirement_keys if key not in requirements]
        cases = {case.id: case for case in _live_cases(session, project_id)}
        changed_by_id = {row.id: row for row in changed_requirements}
        changed_requirement_ids = set(changed_by_id)

        # A changed requirement changes the journey steps its own tests cover --
        # not its whole module. Widening to the module is the blunt instrument
        # the journey graph exists to replace: it pulls in every step and test
        # filed there, whether or not they touch this behaviour.
        requirement_steps: dict[str, str] = {}
        requirement_test_ids = [
            case.id for case in cases.values() if case.requirement_id in changed_requirement_ids
        ]
        if requirement_test_ids:
            for dependency in session.execute(
                select(TestDependency).where(
                    TestDependency.project_id == project_id,
                    TestDependency.test_case_id.in_(requirement_test_ids),
                    TestDependency.relationship_type == "covers",
                )
            ).scalars():
                owner = changed_by_id[cases[dependency.test_case_id].requirement_id]
                requirement_steps.setdefault(
                    dependency.business_flow_step_id,
                    f"covered by changed requirement {owner.external_key}",
                )

        journey_modules = modules
        changed_steps, at_risk_steps = affected_steps(
            session,
            project_id=project_id,
            changed_components=components,
            changed_modules=journey_modules,
            changed_endpoints=endpoints,
            changed_steps=requirement_steps,
        )

        # Which named components and endpoints no modelled journey contains.
        # Their impact is unknown, which is different from "none".
        step_components = {
            str(item).lower()
            for flow, step, _ in at_risk_steps.values()
            for item in (step.ui_components or [])
        }
        step_endpoints = {
            str(item).lower()
            for flow, step, _ in at_risk_steps.values()
            for item in (step.api_endpoints or [])
        }
        unmapped = [c for c in components if c.lower() not in step_components] + [
            e for e in endpoints if e.lower() not in step_endpoints
        ]

        dependencies = (
            list(
                session.execute(
                    select(TestDependency).where(
                        TestDependency.project_id == project_id,
                        TestDependency.business_flow_step_id.in_(list(at_risk_steps)),
                    )
                )
                .scalars()
                .all()
            )
            if at_risk_steps
            else []
        )
        tests_by_step: dict[str, set[str]] = {}
        for dependency in dependencies:
            tests_by_step.setdefault(dependency.business_flow_step_id, set()).add(
                dependency.test_case_id
            )

        # Every test the change reaches, with every reason it was chosen.
        reasons: dict[str, list[str]] = {}
        for step_id, test_ids in tests_by_step.items():
            flow, step, why = at_risk_steps[step_id]
            for test_id in test_ids:
                if test_id in cases:
                    reasons.setdefault(test_id, []).append(
                        f"exercises '{step.name}' in {flow.name} ({why})"
                    )
        for case in cases.values():
            if case.requirement_id in changed_by_id:
                reasons.setdefault(case.id, []).append(
                    f"tests changed requirement {changed_by_id[case.requirement_id].external_key}"
                )

        module_set = {m.lower() for m in journey_modules}
        module_only = sum(
            1
            for case in cases.values()
            if case.id not in reasons and (case.module or "").lower() in module_set
        )

        retest = []
        for test_id, why in reasons.items():
            case = cases[test_id]
            retest.append(
                {
                    "test_case_id": case.id,
                    "key": case.key,
                    "title": case.title,
                    "module": case.module,
                    "priority": case.priority,
                    "automated": bool(case.is_automated),
                    "last_result": case.last_result,
                    "failure_rate": _failure_rate(case),
                    "flakiness": round(case.flakiness_score or 0.0, 4),
                    "unstable": _is_unstable(case),
                    "avg_duration_ms": case.avg_duration_ms or 0,
                    "reasons": why,
                }
            )
        retest.sort(
            key=lambda row: (
                -PRIORITY_WEIGHT.get(row["priority"], 0.5),
                -row["failure_rate"],
                row["key"] or "",
            )
        )

        # Requirements reached through the tests, not only the ones named.
        reached_ids = {cases[test_id].requirement_id for test_id in reasons} - {None}
        by_id = {row.id: row for row in requirements.values()}
        requirement_rows = [
            {
                "key": row.external_key,
                "title": row.title,
                "module": row.module,
                "priority": row.priority,
                "risk_score": round(row.risk_score or 0.0, 3),
                "how": "changed" if row.id in changed_requirement_ids else "exercised by an affected test",
            }
            for row in sorted(
                (by_id[i] for i in (changed_requirement_ids | reached_ids) if i in by_id),
                key=lambda r: (r.id not in changed_requirement_ids, -PRIORITY_WEIGHT.get(r.priority, 0.5)),
            )
        ]

        # Blind spots: steps the change reaches that no test depends on.
        blind_spots = []
        for step_id, (flow, step, why) in at_risk_steps.items():
            if tests_by_step.get(step_id):
                continue
            blind_spots.append(
                {
                    "journey": flow.name,
                    "criticality": flow.criticality,
                    "step": step.name,
                    "step_key": step.key,
                    "module": step.module,
                    "changed": step_id in changed_steps,
                    "why_at_risk": why,
                    "assertions_unverified": list(step.assertions or []),
                }
            )
        blind_spots.sort(key=lambda row: (not row["changed"], -CRITICALITY_WEIGHT.get(row["criticality"], 0.5)))

        # Scripts whose locators name a changed component will fail on the new
        # UI, not merely need re-running.
        component_needles = [c.lower() for c in components]
        # Grouped by file: one script file can serve several test cases, and it is
        # the file somebody has to open and fix.
        breaking_files: dict[str, dict[str, Any]] = {}
        rerun_files: dict[str, dict[str, Any]] = {}
        scripts = session.execute(
            select(TestScript).where(
                TestScript.project_id == project_id, TestScript.is_deleted.is_(False)
            )
        ).scalars()
        for script in scripts:
            haystack = json.dumps(script.locators or [], sort_keys=True).lower()
            hits = [needle for needle in component_needles if needle in haystack]
            if not hits and script.test_case_id not in reasons:
                continue
            bucket = breaking_files if hits else rerun_files
            entry = bucket.setdefault(
                script.file_path or script.name,
                {"script": script.name, "file_path": script.file_path, "test_cases": [], "references": []},
            )
            case = cases.get(script.test_case_id)
            if case is not None and case.key not in entry["test_cases"]:
                entry["test_cases"].append(case.key)
            entry["references"] = sorted(set(entry["references"]) | set(hits))
        likely_to_break = list(breaking_files.values())
        rerun_scripts = [
            {key: value for key, value in entry.items() if key != "references"}
            for path, entry in rerun_files.items()
            if path not in breaking_files
        ]

        # Defect history in the affected area.
        affected_modules = module_set | {(row["module"] or "").lower() for row in retest}
        affected_requirement_ids = changed_requirement_ids | reached_ids
        now = datetime.now(UTC)
        open_defects, recent_resolved = [], []
        for defect in _defects(session, project_id):
            linked = (
                (defect.module or "").lower() in affected_modules
                or defect.test_case_id in reasons
                or defect.requirement_id in affected_requirement_ids
            )
            if not linked:
                continue
            row = {
                "key": defect.external_key,
                "title": defect.title,
                "module": defect.module,
                "severity": defect.severity,
                "status": defect.status,
            }
            if defect.status in OPEN_DEFECT_STATUSES:
                open_defects.append(row)
            elif (_aware(defect.resolved_at) or now - timedelta(days=365)) >= now - timedelta(days=90):
                recent_resolved.append(row)
        open_defects.sort(key=lambda row: -SEVERITY_WEIGHT.get(row["severity"], 0.3))

        journeys: dict[str, dict[str, Any]] = {}
        for step_id, (flow, step, why) in at_risk_steps.items():
            entry = journeys.setdefault(
                flow.id,
                {
                    "journey": flow.name,
                    "criticality": flow.criticality,
                    "owner": flow.owner,
                    "changed_steps": [],
                    "downstream_steps": [],
                },
            )
            (entry["changed_steps"] if step_id in changed_steps else entry["downstream_steps"]).append(step.name)

        risk = self._risk(
            journeys=list(journeys.values()),
            requirements=requirement_rows,
            blind_spots=blind_spots,
            unmapped=unmapped,
            open_defects=open_defects,
            retest=retest,
        )

        automated = [row for row in retest if row["automated"]]
        manual = [row for row in retest if not row["automated"]]
        minutes = sum(row["avg_duration_ms"] for row in automated) / 60000 + len(manual) * MANUAL_TEST_MINUTES

        # Retrieval selects documents; what comes back is fenced like any other
        # untrusted context.
        query = " ".join(
            [description] + [row["title"] for row in requirement_rows[:4]]
        ).strip()[:400]
        knowledge_block, evidence = ("", [])
        if query:
            knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
                query, project_id=project_id, limit=4
            )

        analysis = {
            "change": {
                "description": description or None,
                "source": source,
                "components": components,
                "endpoints": endpoints,
                "modules": journey_modules,
                "requirements": [row.external_key for row in changed_requirements],
            },
            "risk": risk,
            "journeys": list(journeys.values()),
            "blind_spots": blind_spots,
            "unmapped": unmapped,
            "unresolved_requirements": unresolved,
            "requirements": requirement_rows,
            "retest": {
                "tests": retest,
                "automated_count": len(automated),
                "manual_count": len(manual),
                "estimated_minutes": round(minutes, 1),
                # Tests that only share a folder with the change. Not selected:
                # living in the same module is not a dependency.
                "module_only_not_selected": module_only,
            },
            "automation": {"likely_to_break": likely_to_break, "rerun": rerun_scripts},
            "defects": {"open": open_defects, "recently_resolved": recent_resolved},
            "assumptions": {
                "factor_weights": IMPACT_FACTOR_WEIGHTS,
                "manual_test_minutes": MANUAL_TEST_MINUTES,
                "unstable_means": f"flakiness >= {FLAKY_THRESHOLD} or last result failed",
                "lookback_days": lookback,
            },
        }
        return {
            "analysis": analysis,
            "knowledge": knowledge_block,
            "evidence": evidence,
            "tool_calls": [],
        }

    @staticmethod
    def _risk(
        *,
        journeys: list[dict[str, Any]],
        requirements: list[dict[str, Any]],
        blind_spots: list[dict[str, Any]],
        unmapped: list[str],
        open_defects: list[dict[str, Any]],
        retest: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """A score made of named parts, so the rating can be argued with."""
        journey = max(
            (CRITICALITY_WEIGHT.get(row["criticality"], 0.5) for row in journeys if row["changed_steps"]),
            default=0.0,
        )
        priority = max((PRIORITY_WEIGHT.get(row["priority"], 0.5) for row in requirements), default=0.0)
        if any(row["changed"] for row in blind_spots):
            blind = 1.0
        elif blind_spots or unmapped:
            blind = 0.5
        else:
            blind = 0.0
        defects = min(1.0, sum(SEVERITY_WEIGHT.get(row["severity"], 0.3) for row in open_defects) / 3)
        unstable = (sum(1 for row in retest if row["unstable"]) / len(retest)) if retest else 0.0

        values = {
            "journey_criticality": (journey, "most critical journey with a changed step"),
            "requirement_priority": (priority, "highest priority requirement affected"),
            "blind_spots": (blind, "1.0 if a changed step is untested, 0.5 if only downstream or unmapped"),
            "open_defects": (defects, "open defects in the area, weighted by severity"),
            "unstable_tests": (unstable, "share of affected tests that are flaky or failing"),
        }
        factors = []
        score = 0.0
        for name, (value, meaning) in values.items():
            contribution = value * IMPACT_FACTOR_WEIGHTS[name]
            score += contribution
            factors.append(
                {
                    "factor": name,
                    "value": round(value, 3),
                    "weight": IMPACT_FACTOR_WEIGHTS[name],
                    "contribution": round(contribution, 3),
                    "meaning": meaning,
                }
            )
        score = round(min(1.0, score), 3)
        return {"score": score, "rating": _risk_rating(score), "factors": factors}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        analysis = context.get("analysis") or {}
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.impact-analyzer.assess",
                change=analysis.get("change") or context.get("change") or {},
                **_impact_blocks(analysis),
                knowledge=context.get("knowledge") or "",
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        analysis = context.get("analysis")
        if analysis is None:
            return {
                "status": "partial",
                "confidence": 0.2,
                "summary": (
                    "No change was named and no requirement was edited recently, so there is "
                    "nothing to trace."
                ),
                "recommendations": [
                    {
                        "priority": "high",
                        "action": (
                            "Name what changed: components, endpoints, modules or requirement "
                            "keys, or describe the change mentioning them."
                        ),
                    }
                ],
                "next_action": "describe_change",
                "outputs": {"change": context.get("change")},
            }

        risk = analysis["risk"]
        retest = analysis["retest"]
        blind = analysis["blind_spots"]
        breaking = analysis["automation"]["likely_to_break"]
        open_defects = analysis["defects"]["open"]
        journeys = analysis["journeys"]
        change = analysis["change"]

        findings: list[dict[str, Any]] = []
        for spot in blind:
            findings.append(
                {
                    "type": "blind_spot",
                    "severity": "critical" if spot["changed"] else "high",
                    "journey": spot["journey"],
                    "step": spot["step"],
                    "detail": (
                        f"'{spot['step']}' in {spot['journey']} "
                        + ("changed" if spot["changed"] else f"is at risk ({spot['why_at_risk']})")
                        + " and no test covers it."
                    ),
                }
            )
        for item in analysis["unmapped"]:
            findings.append(
                {
                    "type": "unmapped_change",
                    "severity": "high",
                    "item": item,
                    "detail": (
                        f"'{item}' is not part of any modelled journey, so its impact is unknown -- "
                        "which is not the same as none."
                    ),
                }
            )
        for key in analysis["unresolved_requirements"]:
            findings.append(
                {
                    "type": "unresolved_requirement",
                    "severity": "medium",
                    "item": key,
                    "detail": f"{key} is not a requirement in this project; it was not traced.",
                }
            )
        for journey in journeys:
            findings.append(
                {
                    "type": "journey_impact",
                    "severity": journey["criticality"],
                    "journey": journey["journey"],
                    "owner": journey["owner"],
                    "detail": (
                        f"{journey['journey']}: {len(journey['changed_steps'])} step(s) changed, "
                        f"{len(journey['downstream_steps'])} downstream at risk."
                    ),
                }
            )
        for script in breaking:
            findings.append(
                {
                    "type": "automation_at_risk",
                    "severity": "high",
                    "script": script["script"],
                    "file_path": script["file_path"],
                    "test_cases": script["test_cases"],
                    "detail": (
                        f"{script['file_path'] or script['script']} locates "
                        f"{', '.join(script['references'])}, which changed; expect it to fail "
                        f"until updated or healed ({len(script['test_cases'])} test case(s): "
                        f"{', '.join(script['test_cases'])})."
                    ),
                }
            )
        for defect in open_defects[:5]:
            findings.append(
                {
                    "type": "defect_history",
                    "severity": defect["severity"],
                    "defect": defect["key"],
                    "detail": f"Open {defect['severity']} defect {defect['key']} in {defect['module']}: {defect['title']}",
                }
            )

        recommendations: list[dict[str, Any]] = []
        for spot in blind[:5]:
            recommendations.append(
                {
                    "priority": "critical" if spot["changed"] else "high",
                    "action": (
                        f"Write a test for '{spot['step']}' in {spot['journey']} before release; "
                        "nothing would notice it breaking."
                    ),
                }
            )
        if breaking:
            recommendations.append(
                {
                    "priority": "high",
                    "action": (
                        f"Update or heal {len(breaking)} script file(s) whose locators reference a "
                        "changed component, before trusting the regression run."
                    ),
                }
            )
        if retest["tests"]:
            recommendations.append(
                {
                    "priority": "high" if risk["rating"] in ("critical", "high") else "medium",
                    "action": (
                        f"Re-run {len(retest['tests'])} test(s): {retest['automated_count']} automated, "
                        f"{retest['manual_count']} manual, about {retest['estimated_minutes']:.0f} minutes."
                    ),
                }
            )
        for item in analysis["unmapped"][:3]:
            recommendations.append(
                {
                    "priority": "medium",
                    "action": f"Model '{item}' in a business flow so its impact can be traced.",
                }
            )
        for defect in [d for d in open_defects if d["severity"] in ("critical", "blocker")][:3]:
            recommendations.append(
                {
                    "priority": "high",
                    "action": f"Check open {defect['severity']} defect {defect['key']} is not made worse by this change.",
                }
            )
        owners = sorted({j["owner"] for j in journeys if j["owner"] and j["changed_steps"]})
        if owners:
            recommendations.append(
                {"priority": "medium", "action": f"Tell the journey owner(s): {', '.join(owners)}."}
            )

        source_note = {
            "stated": "",
            "description": " Scope was read from the description.",
            "recent_requirement_edits": (
                f" No change was named, so the {len(change['requirements'])} requirement(s) edited in "
                f"the last {analysis['assumptions']['lookback_days']} days were analysed."
            ),
        }[change["source"]]

        journey_names = ", ".join(j["journey"] for j in journeys) or "no modelled journey"
        summary = (
            f"{risk['rating'].capitalize()} risk ({risk['score']}). The change reaches {journey_names}, "
            f"{len(analysis['requirements'])} requirement(s) and {len(retest['tests'])} test(s)"
            + (
                f"; {len(blind)} blind spot(s) no test covers"
                if blind
                else ("; every modelled step it reaches is tested" if journeys else "")
            )
            + (f"; {len(breaking)} script file(s) likely to break" if breaking else "")
            + "."
            + (
                f" Impact of {', '.join(repr(item) for item in analysis['unmapped'])} is unknown: "
                "no modelled journey contains it."
                if analysis["unmapped"]
                else ""
            )
            + source_note
        )

        confidence = 0.9
        if change["source"] != "stated":
            confidence -= 0.25
        if analysis["unmapped"] or analysis["unresolved_requirements"]:
            confidence -= 0.15
        if not journeys:
            confidence -= 0.1

        return {
            "status": "success" if change["source"] == "stated" and not analysis["unresolved_requirements"] else "partial",
            "confidence": round(max(0.2, confidence), 2),
            "summary": summary,
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": (
                "Walked the change through the business journey graph (changed steps and everything "
                "downstream), then to the tests depending on those steps, the requirements those tests "
                "cover, the scripts whose locators name changed components, and the defect history of "
                "the area. Risk is a weighted sum of five named factors."
            ),
            "next_action": "generate_scenarios" if blind else ("run_regression" if retest["tests"] else "report"),
            "outputs": analysis,
        }


# ===========================================================================
# Coverage Planning
# ===========================================================================

# What each risk tier must have before it counts as covered.
TIER_POLICY: dict[str, dict[str, Any]] = {
    "critical": {"scenario_types": ["positive", "negative", "edge"], "min_cases": 4, "min_automated": 2, "execution_days": 30},
    "high": {"scenario_types": ["positive", "negative"], "min_cases": 3, "min_automated": 1, "execution_days": 30},
    "medium": {"scenario_types": ["positive", "negative"], "min_cases": 2, "min_automated": 0, "execution_days": None},
    "low": {"scenario_types": ["positive"], "min_cases": 1, "min_automated": 0, "execution_days": None},
}
TIER_WEIGHT = {"critical": 1.0, "high": 0.7, "medium": 0.4, "low": 0.15}

# Engineer-days per unit of work. Estimates, stated so they can be corrected.
EFFORT_DAYS = {
    "write_case": 0.3,
    "automate_case": 0.5,
    # Running what already exists: roughly 10 minutes by hand, 2-3 automated.
    "execute_manual_case": 0.02,
    "execute_automated_case": 0.005,
    "stabilise_case": 0.5,
    "cover_journey_step": 0.75,
}

# How much of a requirement's risk each kind of gap represents.
GAP_WEIGHT = {
    "missing_positive": 1.0,
    "missing_negative": 0.9,
    "missing_edge": 0.6,
    "too_few_cases": 0.5,
    "not_automated": 0.6,
    "not_executed": 0.7,
    "unstable": 0.5,
    "journey_step_untested": 0.9,
}


# How each gap reads to a person; the codes stay in `gaps` for machines.
GAP_PHRASE = {
    "missing_positive": "no positive-path test",
    "missing_negative": "no negative-path test",
    "missing_edge": "no edge-case test",
    "too_few_cases": "too few tests",
    "not_automated": "too little automation",
    "not_executed": "not run recently enough",
    "unstable": "flaky or failing tests",
    "journey_step_untested": "a journey step with no test",
}


def schedule(items: list[dict[str, Any]], capacity: float) -> float:
    """Order work by risk removed per day and fit it to the capacity.

    Sorts `items` in place, marks each `planned` or not, numbers them by `rank`,
    and returns the days left over. Greedy by efficiency, with one deliberate
    departure from a plain greedy fill: an item too large for what is left is
    skipped rather than ending the plan, so a big critical item that does not fit
    does not also push out the small ones ranked after it.
    """
    # The tier breaks ties so that, at equal efficiency, the more important
    # requirement goes first.
    items.sort(
        key=lambda item: (-item["priority_score"], -TIER_WEIGHT[item["tier"]], item.get("requirement") or "")
    )
    remaining = capacity
    for rank, item in enumerate(items, start=1):
        item["rank"] = rank
        item["planned"] = item["effort_days"] <= remaining + 1e-9
        if item["planned"]:
            remaining -= item["effort_days"]
    return remaining


def _tier(requirement: Requirement, open_defect_weight: float) -> tuple[str, float, dict[str, float]]:
    basis = {
        "priority": PRIORITY_WEIGHT.get(requirement.priority, 0.5),
        "risk_score": float(requirement.risk_score or 0.0),
        "change_frequency": min(requirement.change_frequency or 0, 10) / 10,
        "open_defects": min(1.0, open_defect_weight / 2),
    }
    score = (
        0.45 * basis["priority"]
        + 0.25 * basis["risk_score"]
        + 0.15 * basis["change_frequency"]
        + 0.15 * basis["open_defects"]
    )
    if score >= 0.7:
        tier = "critical"
    elif score >= 0.5:
        tier = "high"
    elif score >= 0.3:
        tier = "medium"
    else:
        tier = "low"
    return tier, round(score, 3), {k: round(v, 3) for k, v in basis.items()}


class CoveragePlanningAgent(BaseAgent):
    key = "coverage-planning"
    computed_outputs = True
    name = "Coverage Planning Agent"
    category = "Planning"
    description = (
        "Holds every requirement to the coverage its risk tier requires and turns the shortfall "
        "into a prioritised, effort-estimated plan that fits the capacity available."
    )
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "Target"
    supported_tools = ["knowledge"]
    goal = "Spend the testing days available where they remove the most risk, and say what is left."
    system_instructions = (
        "You are a coverage planner. Judge coverage against what each requirement's risk demands, "
        "not against a flat count; order work by risk removed per day; and be explicit about "
        "what does not fit and the risk that leaves."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "scope": {"type": "string", "description": "Release, sprint or label for this plan"},
            "modules": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Modules in scope; all when omitted",
            },
            "requirement_keys": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Specific requirements in scope, e.g. PAY-201",
            },
            "capacity_days": {
                "type": "number",
                "default": 10,
                "description": "Engineer-days available for the plan",
            },
            "include_journeys": {
                "type": "boolean",
                "default": True,
                "description": "Also plan tests for business journey steps nothing covers",
            },
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        session, project_id = ctx.session, ctx.project_id
        all_requirements = _requirements_by_key(session, project_id)

        keys = [key.upper() for key in _clean_list(inputs.get("requirement_keys"))]
        modules = {m.lower() for m in _clean_list(inputs.get("modules"))}
        unresolved = [key for key in keys if key not in all_requirements]

        in_scope = [
            row
            for key, row in sorted(all_requirements.items())
            if (not keys or key in keys) and (not modules or (row.module or "").lower() in modules)
        ]

        try:
            capacity = max(0.0, float(inputs.get("capacity_days", 10)))
        except (TypeError, ValueError):
            capacity = 10.0

        cases = _live_cases(session, project_id)
        scenarios = {
            row.id: row
            for row in session.execute(
                select(TestScenario).where(
                    TestScenario.project_id == project_id, TestScenario.is_deleted.is_(False)
                )
            ).scalars()
        }
        # A duplicate case repeats coverage someone already has; counting it
        # would make a requirement look better tested than it is.
        cases_by_requirement: dict[str, list[TestCase]] = {}
        duplicates = 0
        for case in cases:
            if case.duplicate_of_id:
                duplicates += 1
                continue
            requirement_id = case.requirement_id or (
                scenarios[case.scenario_id].requirement_id if case.scenario_id in scenarios else None
            )
            if requirement_id:
                cases_by_requirement.setdefault(requirement_id, []).append(case)

        defect_weight: dict[str, float] = {}
        for defect in _defects(session, project_id):
            if defect.status in OPEN_DEFECT_STATUSES and defect.requirement_id:
                defect_weight[defect.requirement_id] = defect_weight.get(
                    defect.requirement_id, 0.0
                ) + SEVERITY_WEIGHT.get(defect.severity, 0.3)

        now = datetime.now(UTC)
        rows: list[dict[str, Any]] = []
        items: list[dict[str, Any]] = []

        for requirement in in_scope:
            tier, tier_score, basis = _tier(requirement, defect_weight.get(requirement.id, 0.0))
            policy = TIER_POLICY[tier]
            linked = cases_by_requirement.get(requirement.id, [])
            types = sorted(
                {
                    scenarios[case.scenario_id].scenario_type
                    for case in linked
                    if case.scenario_id in scenarios
                }
            )
            automated = sum(1 for case in linked if case.is_automated)
            unstable = [case for case in linked if _is_unstable(case)]
            last_run = max((_aware(case.last_executed_at) for case in linked if case.last_executed_at), default=None)
            window = policy["execution_days"]
            executed_ok = window is None or (last_run is not None and last_run >= now - timedelta(days=window))

            gaps: list[dict[str, Any]] = []

            def add(kind: str, work: str, units: int, detail: str, effort: float | None = None) -> None:
                effort = round(EFFORT_DAYS[work] * units if effort is None else effort, 2)
                value = TIER_WEIGHT[tier] * GAP_WEIGHT[kind]
                gaps.append(
                    {
                        "requirement": requirement.external_key,
                        "module": requirement.module,
                        "tier": tier,
                        "gap": kind,
                        "work": work,
                        "units": units,
                        "effort_days": effort,
                        "risk_removed": round(value, 3),
                        "priority_score": round(value / effort, 3) if effort else value,
                        "detail": detail,
                    }
                )

            missing_types = [t for t in policy["scenario_types"] if t not in types]
            for scenario_type in missing_types:
                add(
                    f"missing_{scenario_type}",
                    "write_case",
                    1,
                    f"No {scenario_type}-path test; a {tier} requirement needs one.",
                )
            shortfall = policy["min_cases"] - len(linked) - len(missing_types)
            if shortfall > 0:
                add(
                    "too_few_cases",
                    "write_case",
                    shortfall,
                    f"{len(linked)} test(s); a {tier} requirement needs at least {policy['min_cases']}.",
                )
            automation_gap = policy["min_automated"] - automated
            if automation_gap > 0:
                add(
                    "not_automated",
                    "automate_case",
                    automation_gap,
                    f"{automated} automated; a {tier} requirement needs at least {policy['min_automated']}.",
                )
            if linked and not executed_ok:
                manual = len(linked) - automated
                add(
                    "not_executed",
                    "execute",
                    len(linked),
                    (
                        "Never executed."
                        if last_run is None
                        else f"Last executed {last_run.date().isoformat()}; a {tier} requirement needs a run within {window} days."
                    ),
                    effort=max(
                        0.05,
                        manual * EFFORT_DAYS["execute_manual_case"]
                        + automated * EFFORT_DAYS["execute_automated_case"],
                    ),
                )
            if unstable:
                add(
                    "unstable",
                    "stabilise_case",
                    len(unstable),
                    f"{len(unstable)} test(s) flaky or failing, so their coverage cannot be relied on.",
                )

            items.extend(gaps)
            rows.append(
                {
                    "requirement": requirement.external_key,
                    "title": requirement.title,
                    "module": requirement.module,
                    "priority": requirement.priority,
                    "tier": tier,
                    "tier_score": tier_score,
                    "tier_basis": basis,
                    "required": {k: v for k, v in policy.items()},
                    "current": {
                        "test_cases": len(linked),
                        "scenario_types": types,
                        "automated": automated,
                        "unstable": len(unstable),
                        "last_executed": last_run.isoformat() if last_run else None,
                    },
                    "gaps": [gap["gap"] for gap in gaps],
                    "meets_target": not gaps,
                }
            )

        # Journey steps nothing covers, weighted by the journey's criticality.
        journey_rows: list[dict[str, Any]] = []
        if inputs.get("include_journeys", True):
            covered_steps = {
                row[0]
                for row in session.execute(
                    select(TestDependency.business_flow_step_id).where(
                        TestDependency.project_id == project_id
                    )
                ).all()
            }
            flows = session.execute(
                select(BusinessFlow).where(
                    BusinessFlow.project_id == project_id, BusinessFlow.is_deleted.is_(False)
                )
            ).scalars()
            for flow in flows:
                for step in flow.steps:
                    if modules and (step.module or "").lower() not in modules:
                        continue
                    if step.id in covered_steps:
                        continue
                    tier = flow.criticality if flow.criticality in TIER_WEIGHT else "medium"
                    value = TIER_WEIGHT[tier] * GAP_WEIGHT["journey_step_untested"]
                    effort = EFFORT_DAYS["cover_journey_step"]
                    journey_rows.append({"journey": flow.name, "step": step.name, "tier": tier})
                    items.append(
                        {
                            "requirement": None,
                            "journey": flow.name,
                            "step": step.name,
                            "module": step.module,
                            "tier": tier,
                            "gap": "journey_step_untested",
                            "work": "cover_journey_step",
                            "units": 1,
                            "effort_days": effort,
                            "risk_removed": round(value, 3),
                            "priority_score": round(value / effort, 3),
                            "detail": f"'{step.name}' in {flow.name} has no test at all.",
                        }
                    )

        remaining = schedule(items, capacity)

        planned = [item for item in items if item["planned"]]
        deferred = [item for item in items if not item["planned"]]
        unplanned_requirements = {item["requirement"] for item in deferred if item["requirement"]}

        def weighted(met: set[str]) -> float:
            total = sum(TIER_WEIGHT[row["tier"]] for row in rows)
            got = sum(TIER_WEIGHT[row["tier"]] for row in rows if row["requirement"] in met)
            return round(got / total, 4) if total else 0.0

        met_now = {row["requirement"] for row in rows if row["meets_target"]}
        met_after = {row["requirement"] for row in rows if row["requirement"] not in unplanned_requirements}

        analysis = {
            "scope": {
                "label": str(inputs.get("scope") or "").strip() or None,
                "modules": sorted(modules),
                "requirement_keys": keys,
                "requirements_in_scope": len(rows),
            },
            "capacity": {
                "days_available": capacity,
                "days_planned": round(capacity - remaining, 2),
                "days_needed_for_everything": round(sum(item["effort_days"] for item in items), 2),
            },
            "coverage": {
                "meeting_target_now": len(met_now),
                "meeting_target_after_plan": len(met_after),
                "risk_weighted_now": weighted(met_now),
                "risk_weighted_after_plan": weighted(met_after),
                "by_tier": {
                    tier: {
                        "requirements": sum(1 for row in rows if row["tier"] == tier),
                        "meeting_target_now": sum(1 for row in rows if row["tier"] == tier and row["requirement"] in met_now),
                        "meeting_target_after_plan": sum(
                            1 for row in rows if row["tier"] == tier and row["requirement"] in met_after
                        ),
                    }
                    for tier in TIER_POLICY
                },
            },
            "requirements": rows,
            "untested_journey_steps": journey_rows,
            "plan": planned,
            "deferred": deferred,
            "unresolved_requirements": unresolved,
            "duplicates_excluded": duplicates,
            "assumptions": {
                "tier_policy": TIER_POLICY,
                "effort_days": EFFORT_DAYS,
                "gap_weights": GAP_WEIGHT,
                "tier_weights": TIER_WEIGHT,
                "tier_formula": "0.45*priority + 0.25*risk_score + 0.15*change_frequency + 0.15*open_defects",
                "unstable_means": f"flakiness >= {FLAKY_THRESHOLD} or last result failed",
            },
        }
        return {"analysis": analysis, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        analysis = context.get("analysis") or {}
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.coverage-planning.plan",
                requirements=_fit(
                    [
                        {key: row[key] for key in ("requirement", "priority", "tier", "gaps")}
                        for row in analysis.get("requirements", [])
                    ]
                ),
                gaps=_fit(
                    [
                        {
                            key: item.get(key)
                            for key in ("rank", "requirement", "step", "tier", "gap", "effort_days", "planned")
                        }
                        for item in analysis.get("plan", []) + analysis.get("deferred", [])
                    ]
                ),
                capacity={
                    **analysis.get("capacity", {}),
                    "scope": analysis.get("scope"),
                    "coverage": {
                        key: value
                        for key, value in (analysis.get("coverage") or {}).items()
                        if key != "by_tier"
                    },
                },
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        analysis = context["analysis"]
        rows = analysis["requirements"]
        if not rows:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No requirements match this scope, so there is nothing to plan.",
                "recommendations": [
                    {
                        "priority": "high",
                        "action": "Widen the scope, or ingest the requirements for these modules first.",
                    }
                ],
                "next_action": "ingest_requirements",
                "outputs": analysis,
            }

        coverage = analysis["coverage"]
        capacity = analysis["capacity"]
        plan = analysis["plan"]
        deferred = analysis["deferred"]
        deferred_critical = sorted(
            {item["requirement"] or item.get("step") for item in deferred if item["tier"] == "critical"}
        )

        findings = [
            {
                "type": "requirement_coverage",
                "severity": row["tier"],
                "requirement": row["requirement"],
                "module": row["module"],
                "tier": row["tier"],
                "meets_target": row["meets_target"],
                "gaps": row["gaps"],
                "detail": (
                    f"{row['requirement']} ({row['tier']}): "
                    + (
                    "meets its target."
                    if row["meets_target"]
                    else "; ".join(GAP_PHRASE.get(gap, gap) for gap in row["gaps"]) + "."
                )
                ),
            }
            for row in sorted(rows, key=lambda r: (r["meets_target"], -TIER_WEIGHT[r["tier"]], r["requirement"]))
        ]
        for step in analysis["untested_journey_steps"]:
            findings.append(
                {
                    "type": "journey_step_untested",
                    "severity": step["tier"],
                    "detail": f"'{step['step']}' in {step['journey']} has no test.",
                }
            )

        recommendations = [
            {
                "priority": item["tier"] if item["tier"] in ("critical", "high") else "medium",
                "action": (
                    f"#{item['rank']} {item['requirement'] or item.get('journey')}: {item['detail']} "
                    f"({item['work'].replace('_', ' ')} x{item['units']}, {item['effort_days']}d)"
                ),
            }
            for item in plan[:6]
        ]
        if deferred_critical:
            shortfall = round(capacity["days_needed_for_everything"] - capacity["days_available"], 1)
            recommendations.append(
                {
                    "priority": "critical",
                    "action": (
                        f"Capacity leaves critical work undone on {', '.join(deferred_critical[:5])}. "
                        f"Add about {shortfall} engineer-day(s), or record that this risk is accepted."
                    ),
                }
            )
        for key in analysis["unresolved_requirements"]:
            recommendations.append(
                {"priority": "medium", "action": f"{key} is not a requirement in this project; it was left out."}
            )

        label = analysis["scope"]["label"]
        summary = (
            (f"{label}: " if label else "")
            + f"{len(rows)} requirement(s) in scope; {coverage['meeting_target_now']} meet their risk-tier "
            f"target today. The plan schedules {len(plan)} of {len(plan) + len(deferred)} work item(s) in "
            f"{capacity['days_planned']} of {capacity['days_available']} engineer-day(s), raising that to "
            f"{coverage['meeting_target_after_plan']} (risk-weighted coverage "
            f"{coverage['risk_weighted_now']:.0%} to {coverage['risk_weighted_after_plan']:.0%})."
            + (
                f" {len(deferred)} item(s) deferred, including critical work on {len(deferred_critical)} item(s)."
                if deferred_critical
                else (f" {len(deferred)} lower-risk item(s) deferred." if deferred else " Nothing is deferred.")
            )
        )

        design_work = any(item["work"] in ("write_case", "cover_journey_step") for item in plan)
        return {
            "status": "partial" if analysis["unresolved_requirements"] else "success",
            "confidence": 0.85,
            "summary": summary,
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": (
                "Tiered each requirement by priority, risk, change frequency and open defects; held it to "
                "that tier's required scenario types, case count, automation and execution recency; "
                "ignored duplicate cases; and packed the gaps into the capacity by risk removed per day."
            ),
            "next_action": "generate_scenarios" if design_work else ("automate" if plan else "report"),
            "outputs": {
                **analysis,
                "effort_days_note": "Effort figures are estimates; correct EFFORT_DAYS for your team.",
            },
        }
