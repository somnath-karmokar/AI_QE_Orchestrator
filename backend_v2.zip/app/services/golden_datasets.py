"""Golden datasets: inputs with expectations a consumer can check for themselves.

Modelled on the golden datasets already in use in this organisation
(requirement_docs/golden_dataset_strands.json): test cases with expected
content and expected tool use, edge cases, and quality targets. Two kinds of
case, held to different standards:

**Edge cases (contract)** are derived from the published input schema, so every
agent and flow has them and they are true anywhere: a misspelled field is
refused with a suggestion, a wrong type is refused naming the field, a missing
required field is refused. A calling platform can run these against its own
project to prove its integration handles refusals.

**Reference cases (behaviour)** are curated, and run against the reference
project -- the seeded demo project `ABCR` -- because a behavioural expectation
needs known data behind it ("PAY-201 has test scenarios"). Only expectations
that are checkable are written: a disposition, an output key, a word in the
summary, a minimum count. Nothing that depends on the wording of a model.

Every case in this module is executed by the test suite on every build
(tests/test_golden_datasets.py). A golden dataset that stops being true fails
the build rather than quietly misleading whoever relies on it.

An agent or flow with no curated reference case says so, rather than being
given invented ones.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.project import Project

GOLDEN_DATASET_VERSION = "1.0"
REFERENCE_PROJECT = "ABCR"
API = settings.api_prefix

EXPECTATION_SEMANTICS = {
    "disposition_in": "The run's disposition (GET /integration/runs/{id}) is one of these.",
    "approvals_at_least": "At least this many approvals are pending in guardrails.awaiting_approval.",
    "status_in": "outputs[<agent_key>].status is one of these.",
    "outputs_have": "Each key is present in outputs[<agent_key>].outputs.",
    "summary_mentions": "Each word appears in outputs[<agent_key>].summary, ignoring case.",
    "next_action_in": "outputs[<agent_key>].next_action is one of these.",
    "min_findings": "outputs[<agent_key>].findings has at least this many entries.",
    "agents_produced": "Each agent key is present in the flow run's outputs.",
    "http_status": "The start request itself is answered with this status.",
    "invalid_field": "error.details.invalid_inputs names this field.",
    "did_you_mean": "The refusal suggests this field.",
}

# ---------------------------------------------------------------------------
# Curated reference cases, against the reference project
# ---------------------------------------------------------------------------

_OK = {"disposition_in": ["succeeded"], "status_in": ["success"]}
_PAUSES = {"disposition_in": ["waiting_for_approval"], "approvals_at_least": 1}

AGENT_CASES: dict[str, list[dict[str, Any]]] = {
    "user-story-completeness": [
        {"id": "READY_001", "category": "readiness", "priority": "high",
         "description": "Score a known story for test readiness.",
         "inputs": {"requirement_key": "PAY-201"},
         "expect": {**_OK, "outputs_have": ["completeness_score", "passed", "gap_count"], "summary_mentions": ["PAY-201"]}},
    ],
    "test-planning": [
        {"id": "PLAN_001", "category": "planning", "priority": "high",
         "description": "Plan testing for one module.",
         "inputs": {"scope": "Release 2.4", "modules": ["Payments"]},
         "expect": {**_OK, "outputs_have": ["module_plans", "total_effort_days", "entry_criteria", "exit_criteria"],
                    "summary_mentions": ["Payments"]}},
    ],
    "test-design": [
        {"id": "DESIGN_001", "category": "design", "priority": "high",
         "description": "Expand a story's scenarios into test cases.",
         "inputs": {"requirement_key": "PAY-201"},
         "expect": {**_OK, "outputs_have": ["test_cases", "test_case_count"], "min_findings": 1}},
    ],
    "test-knowledge": [
        {"id": "KNOW_001", "category": "knowledge", "priority": "medium",
         "description": "Retrieve grounded context for a business rule.",
         "inputs": {"query": "daily payment limit"},
         "expect": {**_OK, "outputs_have": ["context", "related_requirements", "related_tests"], "min_findings": 1}},
    ],
    "test-scenario-generator": [
        {"id": "SCEN_001", "category": "design", "priority": "high",
         "description": "Generate scenarios for a known story.",
         "inputs": {"requirement_key": "PAY-201", "max_scenarios": 4},
         "expect": {**_OK, "outputs_have": ["scenarios", "scenario_count"], "summary_mentions": ["PAY-201"]}},
    ],
    "traceability-coverage": [
        {"id": "TRACE_001", "category": "coverage", "priority": "high",
         "description": "Report requirement-to-execution coverage for one module.",
         "inputs": {"module": "Payments"},
         "expect": {**_OK, "outputs_have": ["requirement_coverage", "automation_coverage", "matrix", "uncovered_count"]}},
    ],
    "impact-analyzer": [
        {"id": "IMPACT_001", "category": "change_impact", "priority": "high",
         "description": "Trace a change to a UI component through its journey.",
         "inputs": {"changed_components": ["login-form"]},
         "expect": {**_OK, "outputs_have": ["risk", "journeys", "retest", "automation", "blind_spots"],
                    "next_action_in": ["run_regression", "generate_scenarios"]}},
        {"id": "IMPACT_002", "category": "change_impact", "priority": "medium",
         "description": "A component no journey models is reported as unknown impact, not none.",
         "inputs": {"changed_components": ["component-that-does-not-exist"]},
         "expect": {**_OK, "outputs_have": ["unmapped"], "summary_mentions": ["unknown"]}},
    ],
    "coverage-planning": [
        {"id": "COVER_001", "category": "coverage", "priority": "high",
         "description": "Plan coverage for one module within two engineer-days.",
         "inputs": {"modules": ["Payments"], "capacity_days": 2},
         "expect": {**_OK, "outputs_have": ["plan", "deferred", "coverage", "capacity", "assumptions"]}},
    ],
    "test-data-generator": [
        {"id": "DATA_001", "category": "test_data", "priority": "high",
         "description": "Generate a small synthetic data set.",
         "inputs": {"module": "Payments", "record_count": 6},
         "expect": {**_OK, "outputs_have": ["records", "record_count", "masked_fields"], "summary_mentions": ["Payments"]}},
    ],
    "test-data-management": [
        {"id": "DATAMGMT_001", "category": "test_data", "priority": "medium",
         "description": "Audit the data sets of one module.",
         "inputs": {"module": "Payments"},
         "expect": {**_OK, "outputs_have": ["audited", "needs_attention"]}},
    ],
    "db-script-generator": [
        {"id": "SQL_001", "category": "test_data", "priority": "medium",
         "description": "Generate parameterised SQL for a table.",
         "inputs": {"table": "payments"},
         "expect": {**_OK, "outputs_have": ["scripts", "table"]}},
    ],
    "auto-script-generator": [
        {"id": "SCRIPT_001", "category": "automation", "priority": "high",
         "description": "Generate Playwright tests for a module.",
         "inputs": {"module": "Payments", "limit": 2},
         "expect": {**_OK, "outputs_have": ["scripts", "script_count"]}},
    ],
    "self-healing-automation": [
        {"id": "HEAL_001", "category": "governance", "priority": "high",
         "description": "A high-risk repair agent pauses for a person before it acts.",
         "inputs": {},
         "expect": _PAUSES},
    ],
    "automated-test-execution": [
        {"id": "EXEC_001", "category": "execution", "priority": "high",
         "description": "Run a smoke suite and report the outcome.",
         "inputs": {"suite_type": "smoke", "module": "Login"},
         # A run with failures reports needs_review rather than success: the
         # point of the case is that it ran and reported, not that it was green.
         "expect": {"disposition_in": ["succeeded"], "status_in": ["success", "needs_review"],
                    "outputs_have": ["total_tests", "pass_rate", "execution_id"]}},
    ],
    "automation-failure-analysis": [
        {"id": "FAIL_001", "category": "triage", "priority": "high",
         "description": "Group the latest failures by cause.",
         "inputs": {},
         "expect": {**_OK, "outputs_have": ["analysed", "distinct_causes", "triage"]}},
    ],
    "regression-suite-optimization": [
        {"id": "REGR_001", "category": "regression", "priority": "high",
         "description": "Select a regression suite for a changed module.",
         "inputs": {"changed_modules": ["Payments"]},
         "expect": {**_OK, "outputs_have": ["selected", "selected_count", "reduction_percent"], "summary_mentions": ["Payments"]}},
    ],
    "performance-test-generator": [
        {"id": "PERF_001", "category": "performance", "priority": "medium",
         "description": "Generate a load profile against a latency target.",
         "inputs": {"module": "Payments"},
         "expect": {**_OK, "outputs_have": ["script", "stages", "thresholds"]}},
    ],
    "accessibility-test": [
        {"id": "A11Y_001", "category": "accessibility", "priority": "medium",
         "description": "Prepare WCAG checks for a module.",
         "inputs": {"module": "Accounts"},
         "expect": {**_OK, "outputs_have": ["checks", "standard", "script"], "summary_mentions": ["WCAG"]}},
    ],
    "defect-prediction": [
        {"id": "PRED_001", "category": "risk", "priority": "high",
         "description": "Predict defect risk by module.",
         "inputs": {"horizon_days": 14},
         "expect": {**_OK, "outputs_have": ["predictions", "high_risk_count"]}},
    ],
    "automated-rca": [
        {"id": "RCA_001", "category": "rca", "priority": "high",
         "description": "Find the probable root cause of the latest failures.",
         "inputs": {},
         "expect": {**_OK, "outputs_have": ["probable_root_cause", "category", "affected_tests"]}},
    ],
    "automated-defect-rca": [
        {"id": "DEFRCA_001", "category": "rca", "priority": "high",
         "description": "Analyse a defect named by its key rather than an internal id.",
         "inputs": {"defect_id": "DEF-0003"},
         "expect": {"disposition_in": ["succeeded"], "status_in": ["success", "partial", "needs_review"]}},
    ],
    "duplicate-test-detection": [
        {"id": "DUP_001", "category": "hygiene", "priority": "medium",
         "description": "Find likely duplicate tests; flagged for review, never retired automatically.",
         "inputs": {"module": "Payments"},
         "expect": {"disposition_in": ["succeeded"], "status_in": ["needs_review", "success"],
                    "outputs_have": ["pairs", "duplicate_count"]}},
    ],
    "observability": [
        {"id": "OBS_001", "category": "observability", "priority": "medium",
         "description": "Summarise execution health over a window.",
         "inputs": {"window_days": 30},
         "expect": {**_OK, "outputs_have": ["current_pass_rate", "flaky_rate", "recurring_signatures"]}},
    ],
    "uat-assistant": [
        {"id": "UAT_001", "category": "uat", "priority": "medium",
         "description": "Prepare business-readable UAT scripts.",
         "inputs": {"module": "Payments", "limit": 3},
         "expect": {**_OK, "outputs_have": ["scripts", "script_count"]}},
    ],
    "jira-defect-assistant": [
        {"id": "JIRA_001", "category": "governance", "priority": "high",
         "description": "Drafting a defect in an external tracker waits for a person to approve it.",
         "inputs": {"title": "Payment confirmation shows the wrong total", "module": "Payments"},
         "expect": _PAUSES},
    ],
}

FLOW_CASES: dict[str, list[dict[str, Any]]] = {
    "accessibility-compliance": [
        {"id": "FLOW_A11Y_001", "category": "accessibility", "priority": "medium",
         "description": "Accessibility checks with coverage context.",
         "inputs": {},
         "expect": {"disposition_in": ["succeeded"], "agents_produced": ["accessibility-test", "traceability-coverage"]}},
    ],
    "failure-to-rca-defect": [
        {"id": "FLOW_RCA_001", "category": "governance", "priority": "high",
         "description": "Triage runs, then a person must approve before a defect is drafted.",
         "inputs": {},
         "expect": _PAUSES},
    ],
    "regression-intelligence": [
        {"id": "FLOW_REGR_001", "category": "regression", "priority": "high",
         "description": "Risk, selection and coverage for a changed module.",
         "inputs": {"changed_modules": ["Payments"]},
         "expect": {"disposition_in": ["succeeded"],
                    "agents_produced": ["defect-prediction", "regression-suite-optimization", "traceability-coverage"]}},
    ],
    "release-readiness": [
        {"id": "FLOW_READY_001", "category": "release", "priority": "high",
         "description": "Coverage, health, hygiene and risk for a release decision.",
         "inputs": {},
         "expect": {"disposition_in": ["succeeded"],
                    "agents_produced": ["traceability-coverage", "observability", "duplicate-test-detection", "defect-prediction"]}},
    ],
    "requirement-to-automated-test": [
        {"id": "FLOW_R2T_001", "category": "end_to_end", "priority": "high",
         "description": "From a ready story to generated automation.",
         "inputs": {"requirement_key": "PAY-201"},
         "expect": {"disposition_in": ["succeeded"],
                    "agents_produced": ["user-story-completeness", "test-scenario-generator", "test-design",
                                        "test-data-generator", "auto-script-generator"]}},
    ],
    "uat-preparation": [
        {"id": "FLOW_UAT_001", "category": "governance", "priority": "medium",
         "description": "UAT material is prepared, then waits for sign-off.",
         "inputs": {},
         "expect": _PAUSES},
    ],
}


# ---------------------------------------------------------------------------
# Edge cases, derived from the published schema
# ---------------------------------------------------------------------------

_WRONG_VALUE = {"string": 12345, "integer": "not-a-number", "number": "not-a-number",
                "boolean": "not-a-boolean", "array": "not-an-array", "object": "not-an-object"}


def _misspelling(name: str) -> str:
    """A near miss the validator should recognise: drop one inner letter."""
    return name[:2] + name[3:] if len(name) > 4 else name + "x"


def contract_cases(schema: dict[str, Any]) -> list[dict[str, Any]]:
    """Refusals every caller can rely on, generated from the input schema."""
    properties = (schema or {}).get("properties") or {}
    cases: list[dict[str, Any]] = []
    if properties:
        field = sorted(properties)[0]
        typo = _misspelling(field)
        cases.append(
            {
                "id": "EDGE_UNKNOWN_FIELD",
                "description": f"A misspelled field ('{typo}') is refused and '{field}' is suggested.",
                "inputs": {typo: "value"},
                "expect": {"http_status": 422, "invalid_field": typo, "did_you_mean": field},
            }
        )
        typed = next((name for name in sorted(properties) if properties[name].get("type") in _WRONG_VALUE), None)
        if typed:
            kind = properties[typed]["type"]
            cases.append(
                {
                    "id": "EDGE_WRONG_TYPE",
                    "description": f"'{typed}' must be a {kind}; another type is refused naming the field.",
                    "inputs": {typed: _WRONG_VALUE[kind]},
                    "expect": {"http_status": 422, "invalid_field": typed},
                }
            )
    else:
        cases.append(
            {
                "id": "EDGE_UNKNOWN_FIELD",
                "description": "This takes no inputs, so any field is refused rather than ignored.",
                "inputs": {"unexpected_field": "value"},
                "expect": {"http_status": 422, "invalid_field": "unexpected_field"},
            }
        )
    for field in (schema or {}).get("required") or []:
        cases.append(
            {
                "id": f"EDGE_MISSING_{field.upper()}",
                "description": f"'{field}' is required; a request without it is refused.",
                "inputs": {},
                "expect": {"http_status": 422, "invalid_field": field},
            }
        )
    return cases


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------


def evaluate(case: dict[str, Any], envelope: dict[str, Any], *, agent_key: str | None = None) -> dict[str, Any]:
    """Check one reference case against the run envelope a consumer receives.

    `agent_key` names whose result to read for agent-level expectations. The
    same function is used by the test suite, so the semantics a consumer reads
    in `EXPECTATION_SEMANTICS` are the ones actually enforced.
    """
    expect = case.get("expect", {})
    failures: list[str] = []
    outputs = envelope.get("outputs") or {}
    result = outputs.get(agent_key) or {} if agent_key else {}

    if "disposition_in" in expect and envelope.get("disposition") not in expect["disposition_in"]:
        failures.append(f"disposition was {envelope.get('disposition')!r}, expected one of {expect['disposition_in']}")
    if "approvals_at_least" in expect:
        pending = len((envelope.get("guardrails") or {}).get("awaiting_approval") or [])
        if pending < expect["approvals_at_least"]:
            failures.append(f"{pending} approval(s) pending, expected at least {expect['approvals_at_least']}")
    if "status_in" in expect and result.get("status") not in expect["status_in"]:
        failures.append(f"status was {result.get('status')!r}, expected one of {expect['status_in']}")
    missing = [k for k in expect.get("outputs_have", []) if k not in (result.get("outputs") or {})]
    if missing:
        failures.append(f"outputs missing {missing}")
    summary = (result.get("summary") or "").lower()
    absent = [w for w in expect.get("summary_mentions", []) if w.lower() not in summary]
    if absent:
        failures.append(f"summary does not mention {absent}")
    if "next_action_in" in expect and result.get("next_action") not in expect["next_action_in"]:
        failures.append(f"next_action was {result.get('next_action')!r}, expected one of {expect['next_action_in']}")
    if len(result.get("findings") or []) < expect.get("min_findings", 0):
        failures.append(f"{len(result.get('findings') or [])} finding(s), expected at least {expect['min_findings']}")
    unproduced = [k for k in expect.get("agents_produced", []) if k not in outputs]
    if unproduced:
        failures.append(f"flow produced no output for {unproduced}")
    return {"id": case["id"], "passed": not failures, "failures": failures}


# ---------------------------------------------------------------------------
# The datasets
# ---------------------------------------------------------------------------


def _writes(agent_key: str) -> bool:
    from app.agents.base import BaseAgent  # noqa: PLC0415
    from app.agents.registry import AGENT_CLASS_BY_KEY  # noqa: PLC0415

    agent_class = AGENT_CLASS_BY_KEY.get(agent_key)
    return bool(agent_class and agent_class.persist is not BaseAgent.persist)


def _quality_metrics(performance: dict[str, Any], *, success_target: float, timeout_seconds: int) -> dict[str, Any]:
    return {
        "targets": {
            "success_rate": success_target,
            "max_duration_ms": timeout_seconds * 1000,
            "edge_cases_pass": 1.0,
            "reference_cases_pass": 1.0,
        },
        "observed": performance,
        "verified_by": "tests/test_golden_datasets.py runs every case on every build",
    }


def agent_golden_dataset(session: Session, agent: Agent, project: Project) -> dict[str, Any]:
    from app.services.model_cards import observed_performance  # noqa: PLC0415

    key = agent.handler_key or agent.key
    cases = AGENT_CASES.get(key, [])
    return {
        "metadata": {
            "version": GOLDEN_DATASET_VERSION,
            "generated_at": datetime.now(UTC).isoformat(),
            "subject": {"type": "agent", "key": key, "name": agent.name, "version": agent.version},
            "purpose": "Validate an integration against this agent, and evidence that it behaves as documented.",
            "reference_project": REFERENCE_PROJECT,
            "preconditions": "The reference project's demo data, with its knowledge indexed.",
            "invoke": f"POST {API}/integration/agents/{key}/runs",
            "side_effects": (
                "Writes results into the project (for example generated tests or data sets). Run reference "
                "cases against a non-production project."
                if _writes(key)
                else "Read-only: running a case changes nothing in the project."
            ),
            "how_to_use": (
                "Edge cases work in any project: send the inputs and expect the refusal. Reference cases "
                "assume the reference project's demo data; in another project, adapt the inputs to your data."
            ),
        },
        "test_cases": cases,
        "curated": bool(cases),
        "note": None if cases else "No reference case is curated for this agent yet; only schema-derived edge cases are provided.",
        "edge_cases": contract_cases(agent.input_schema or {}),
        "expectation_semantics": EXPECTATION_SEMANTICS,
        "quality_metrics": _quality_metrics(
            observed_performance(session, project.id, agent_key=agent.key),
            success_target=0.9,
            timeout_seconds=agent.timeout_seconds or 120,
        ),
    }


def flow_golden_dataset(session: Session, flow: AgentFlow, project: Project) -> dict[str, Any]:
    from app.services.integration import _flow_descriptor  # noqa: PLC0415
    from app.services.model_cards import observed_performance  # noqa: PLC0415

    cases = FLOW_CASES.get(flow.key, [])
    slo = (flow.governance or {}).get("slo_success_rate") or 0.9
    return {
        "metadata": {
            "version": GOLDEN_DATASET_VERSION,
            "generated_at": datetime.now(UTC).isoformat(),
            "subject": {"type": "flow", "id": flow.id, "key": flow.key, "name": flow.name, "version": flow.version},
            "purpose": "Validate an integration against this flow, and evidence that it behaves as documented.",
            "reference_project": REFERENCE_PROJECT,
            "preconditions": "The reference project's demo data and flows, with its knowledge indexed.",
            "invoke": f"POST {API}/integration/flows/{flow.id}/runs",
            "side_effects": "A flow may write results into the project. Run reference cases against a non-production project.",
            "how_to_use": (
                "Edge cases work in any project. Reference cases assume the reference project's demo data and "
                "flows; a flow created from the same template in another project can reuse them with its own data."
            ),
        },
        "test_cases": cases,
        "curated": bool(cases),
        "note": None if cases else "No reference case is curated for this flow; only schema-derived edge cases are provided.",
        "edge_cases": contract_cases(_flow_descriptor(flow)["input_schema"]),
        "expectation_semantics": EXPECTATION_SEMANTICS,
        "quality_metrics": _quality_metrics(
            observed_performance(session, project.id, flow_id=flow.id),
            success_target=slo,
            timeout_seconds=max((node.timeout_seconds or 120) for node in flow.nodes) if flow.nodes else 120,
        ),
    }


def dataset_summary(session: Session, *, agent: Agent | None = None, flow: AgentFlow | None = None) -> dict[str, Any]:
    """What the golden dataset holds, for the model card to point at."""
    if agent is not None:
        key = agent.handler_key or agent.key
        return {
            "endpoint": f"GET {API}/integration/agents/{key}/golden-dataset",
            "reference_cases": len(AGENT_CASES.get(key, [])),
            "edge_cases": len(contract_cases(agent.input_schema or {})),
        }
    from app.services.integration import _flow_descriptor  # noqa: PLC0415

    return {
        "endpoint": f"GET {API}/integration/flows/{flow.id}/golden-dataset",
        "reference_cases": len(FLOW_CASES.get(flow.key, [])),
        "edge_cases": len(contract_cases(_flow_descriptor(flow)["input_schema"])),
    }
