"""Run logs, the audit feed, metrics, model cards and the SOP -- for consumers.

What a consuming platform can learn about its own runs, and what it can learn
about an agent before trusting it. The negatives matter as much as the
positives here: the log must not carry another key's runs, a secret, a person's
identity, a prompt or a tool argument; a model card must not report a seeded
statistic as performance, or claim a control nothing enforces.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy import select

from app.core.worker import job_queue
from app.models.agent import Agent
from app.models.governance import ApprovalRequest, GovernancePolicy
from app.models.run import AgentRun
from app.services.integration_clients import issue_client

API = "/api/v1/integration"
SECRET = "sk-live-do-not-log-me"
EMAIL = "someone.private@customer.example"


def _key(db, project_id: str, name: str, scopes: list[str], **grants) -> str:  # noqa: ANN001, ANN003
    _record, token = issue_client(
        db,
        project_id=project_id,
        name=name,
        actor="alex.morgan@example.com",
        scopes=scopes,
        rate_limit_per_minute=10_000,
        **({"grants_all_agents": True, "grants_all_flows": True} | grants),
    )
    db.commit()
    return token


@pytest.fixture
def observer(db, project_id: str) -> str:
    return _key(db, project_id, "observer", ["catalog:read", "agents:run", "flows:run", "runs:read", "runs:logs"])


def _start(client, token: str, agent_key: str = "test-planning", inputs: dict | None = None) -> str:  # noqa: ANN001
    started = client.post(
        f"{API}/agents/{agent_key}/runs",
        headers={"X-API-Key": token},
        json={"inputs": inputs if inputs is not None else {"modules": ["Payments"]}},
    )
    assert started.status_code in (200, 202), started.text
    job_queue.wait_for_idle(timeout=60)
    return started.json()["run_id"]


def _log(client, token: str, run_id: str):  # noqa: ANN001, ANN202
    return client.get(f"{API}/runs/{run_id}/log", headers={"X-API-Key": token})


# ===========================================================================
# The run log
# ===========================================================================


def test_the_log_is_a_versioned_contract(client, observer: str) -> None:  # noqa: ANN001
    body = _log(client, observer, _start(client, observer)).json()

    assert body["schema_version"] == "1.0"
    for section in ("run", "activities", "timeline", "approvals", "audit", "usage", "redaction", "links"):
        assert section in body, section
    activity = next(a for a in body["activities"] if a["agent"])
    assert activity["agent"]["key"] == "test-planning"
    assert activity["model"]["provider"] and activity["model"]["model"]
    assert set(activity["usage"]) == {"prompt_tokens", "completion_tokens", "total_tokens", "cost_usd"}
    assert body["usage"]["by_model"], "the model actually called is recorded"


def test_the_log_includes_the_call_that_started_the_run(client, observer: str) -> None:  # noqa: ANN001
    """The integration start event now records the run it started, so it is
    part of that run's audit trail rather than orphaned beside it."""
    body = _log(client, observer, _start(client, observer)).json()
    actions = [entry["action"] for entry in body["audit"]]
    assert "integration.agent_invoked" in actions


def test_the_log_needs_the_runs_logs_scope(client, db, project_id: str) -> None:  # noqa: ANN001
    """runs:read is for polling a result; the log is more, and asked for separately."""
    token = _key(db, project_id, "reader-only", ["agents:run", "runs:read"])
    run_id = _start(client, token)
    response = _log(client, token, run_id)
    assert response.status_code == 403
    assert response.json()["error"]["details"]["required_scope"] == "runs:logs"


def test_a_key_cannot_read_another_keys_log(client, db, project_id: str, observer: str) -> None:  # noqa: ANN001
    other = _key(db, project_id, "someone-else", ["agents:run", "runs:read", "runs:logs"])
    theirs = _start(client, other)
    assert _log(client, observer, theirs).status_code == 404


def test_a_key_cannot_read_the_log_of_a_run_a_person_started(client, db, observer: str, project_id: str) -> None:  # noqa: ANN001
    run = db.execute(
        select(AgentRun).where(AgentRun.project_id == project_id, AgentRun.integration_client_id.is_(None),
                               ~AgentRun.triggered_by.like("integration:%"))
    ).scalars().first()
    assert run is not None
    assert _log(client, observer, run.id).status_code == 404


def test_secrets_and_personal_data_are_masked(client, observer: str) -> None:  # noqa: ANN001
    run_id = _start(client, observer, "test-knowledge", {"query": f"refund for {EMAIL}"})
    text = _log(client, observer, run_id).text
    assert EMAIL not in text
    assert "[REDACTED_EMAIL]" in text


def test_secret_named_values_never_appear(client, db, observer: str) -> None:  # noqa: ANN001
    """Inputs are logged for governance, but not a value under a secret's name."""
    run_id = _start(client, observer)
    run = db.get(AgentRun, run_id)
    run.inputs = {**(run.inputs or {}), "api_key": SECRET}
    db.commit()
    body = _log(client, observer, run_id)
    assert SECRET not in body.text
    assert body.json()["run"]["inputs"]["api_key"] == "********"


def test_prompts_and_tool_arguments_are_left_out(client, observer: str, db) -> None:  # noqa: ANN001
    run_id = _start(client, observer, "user-story-completeness", {"requirement_key": "PAY-201"})
    body = _log(client, observer, run_id).json()
    tools = [tool for activity in body["activities"] for tool in activity["tools"]]
    assert tools, "this agent calls a tool, so the omission is being exercised"
    assert all("arguments" not in tool for tool in tools)
    agent = db.execute(select(Agent).where(Agent.key == "user-story-completeness")).scalars().first()
    assert agent.system_instructions[:60] not in str(body)


def test_who_approved_is_not_disclosed_but_that_it_was_is(client, db, observer: str) -> None:  # noqa: ANN001
    run_id = _start(client, observer)
    run = db.get(AgentRun, run_id)
    db.add(
        ApprovalRequest(
            project_id=run.project_id, run_id=run.id, subject_type="agent_run", title="Approve",
            reason="Policy", risk_level="high", status="approved", required_role="qe_lead",
            requested_by="system", decided_by="priya.raman@example.com",
            decided_at=datetime.now(UTC), decision_notes=f"Checked with {EMAIL}",
        )
    )
    db.commit()
    body = _log(client, observer, run_id)
    approval = body.json()["approvals"][0]
    assert approval["status"] == "approved" and approval["required_role"] == "qe_lead"
    assert approval["decided_at"]
    assert "priya.raman" not in body.text
    assert EMAIL not in body.text


# ===========================================================================
# The audit feed
# ===========================================================================


def test_the_feed_pages_without_repeating_or_skipping(client, db, project_id: str) -> None:  # noqa: ANN001
    token = _key(db, project_id, "siem", ["agents:run", "runs:read", "runs:logs"])
    for _ in range(3):
        _start(client, token)

    everything = client.get(f"{API}/audit-events", headers={"X-API-Key": token}, params={"limit": 500}).json()
    total = [item["event_id"] for item in everything["items"]]
    assert total, "the runs produced audit entries"

    seen, cursor = [], None
    while True:
        params = {"limit": 2, **({"cursor": cursor} if cursor else {})}
        page = client.get(f"{API}/audit-events", headers={"X-API-Key": token}, params=params).json()
        seen += [item["event_id"] for item in page["items"]]
        cursor = page["next_cursor"]
        if not page["has_more"]:
            break

    assert seen == total
    assert len(seen) == len(set(seen))
    # A poller that caught up keeps its place.
    caught_up = client.get(f"{API}/audit-events", headers={"X-API-Key": token}, params={"cursor": cursor}).json()
    assert caught_up["items"] == [] and caught_up["next_cursor"] == cursor


def test_the_feed_carries_only_this_keys_runs(client, db, project_id: str) -> None:  # noqa: ANN001
    mine = _key(db, project_id, "feed-mine", ["agents:run", "runs:read", "runs:logs"])
    other = _key(db, project_id, "feed-other", ["agents:run", "runs:read", "runs:logs"])
    my_run, their_run = _start(client, mine), _start(client, other)

    items = client.get(f"{API}/audit-events", headers={"X-API-Key": mine}, params={"limit": 500}).json()["items"]
    runs = {item["run_id"] for item in items}
    assert my_run in runs
    assert their_run not in runs


def test_a_cursor_we_did_not_issue_is_refused(client, observer: str) -> None:  # noqa: ANN001
    response = client.get(f"{API}/audit-events", headers={"X-API-Key": observer}, params={"cursor": "not-a-cursor"})
    assert response.status_code == 422


# ===========================================================================
# Metrics and filters
# ===========================================================================


def test_metrics_agree_with_the_runs_they_summarise(client, db, project_id: str) -> None:  # noqa: ANN001
    token = _key(db, project_id, "metrics", ["agents:run", "runs:read", "runs:logs"])
    _start(client, token)
    _start(client, token, "coverage-planning", {"modules": ["Payments"]})

    metrics = client.get(f"{API}/metrics", headers={"X-API-Key": token}).json()
    assert metrics["runs"]["total"] == 2
    assert metrics["runs"]["by_disposition"] == {"succeeded": 2}
    assert metrics["runs"]["success_rate"] == 1.0
    assert {row["id"] for row in metrics["by_resource"]} == {"test-planning", "coverage-planning"}
    assert sum(row["calls"] for row in metrics["by_model"]) >= 2


def test_the_run_list_filters_only_narrow(client, db, project_id: str) -> None:  # noqa: ANN001
    token = _key(db, project_id, "filters", ["agents:run", "runs:read"])
    planning = _start(client, token)
    coverage = _start(client, token, "coverage-planning", {"modules": ["Payments"]})
    headers = {"X-API-Key": token}

    by_agent = client.get(f"{API}/runs", headers=headers, params={"agent_key": "coverage-planning"}).json()
    assert [item["run_id"] for item in by_agent["items"]] == [coverage]

    succeeded = client.get(f"{API}/runs", headers=headers, params={"disposition": "succeeded"}).json()
    assert {item["run_id"] for item in succeeded["items"]} == {planning, coverage}

    future = (datetime.now(UTC) + timedelta(days=1)).isoformat()
    assert client.get(f"{API}/runs", headers=headers, params={"since": future}).json()["total"] == 0
    assert client.get(f"{API}/runs", headers=headers, params={"disposition": "finished"}).status_code == 422


# ===========================================================================
# Model cards
# ===========================================================================


def test_every_catalogued_agent_has_a_card_and_nothing_else_does(client, db, project_id: str) -> None:  # noqa: ANN001
    """The catalog and the card endpoint answer from one rule, so they agree."""
    token = _key(db, project_id, "cards", ["catalog:read"], grants_all_agents=False, grants_all_flows=False,
                 allowed_agent_keys=["impact-analyzer", "test-planning"])
    headers = {"X-API-Key": token}
    listed = {entry["key"] for entry in client.get(f"{API}/catalog", headers=headers).json()["agents"]}
    assert listed == {"impact-analyzer", "test-planning"}
    for agent_key in listed:
        assert client.get(f"{API}/agents/{agent_key}/model-card", headers=headers).status_code == 200
    assert client.get(f"{API}/agents/coverage-planning/model-card", headers=headers).status_code == 404


def test_a_card_describes_the_agent_as_deployed(client, db, observer: str, project_id: str) -> None:  # noqa: ANN001
    from app.agents.registry import AGENT_CLASS_BY_KEY  # noqa: PLC0415
    from app.ai.router.model_router import ModelRouter, RoutingRequest  # noqa: PLC0415
    from app.models.project import Project  # noqa: PLC0415

    card = client.get(f"{API}/agents/impact-analyzer/model-card", headers={"X-API-Key": observer}).json()
    agent = db.execute(select(Agent).where(Agent.key == "impact-analyzer", Agent.project_id.is_(None))).scalar_one()

    assert card["model_card_version"] == "1.0"
    assert card["version"] == agent.version
    assert card["input_schema"] == agent.input_schema
    project = db.get(Project, project_id)
    decision = ModelRouter(db).resolve(
        RoutingRequest(capability=agent.capability, complexity=AGENT_CLASS_BY_KEY[agent.key].complexity,
                       agent_config=agent.llm_config or {}, project_config=project.llm_config or {}),
        project_id=project_id,
    )
    assert card["model"]["provider"] == decision.selection.provider
    assert card["model"]["model"] == decision.selection.model
    assert {c["id"] for c in card["compliance"]["controls"]} >= {"computed_outputs_authoritative", "untrusted_content_fenced"}


def test_a_card_names_prompts_but_never_prints_them(client, db, observer: str) -> None:  # noqa: ANN001
    from app.ai.prompts import get  # noqa: PLC0415

    card = client.get(f"{API}/agents/impact-analyzer/model-card", headers={"X-API-Key": observer})
    ids = {p["id"] for p in card.json()["prompts"]}
    assert "agent.impact-analyzer.assess" in ids
    assert get("agent.impact-analyzer.assess").text[:50] not in card.text


def test_performance_is_observed_never_the_seeded_marketplace_figure(client, db, observer: str) -> None:  # noqa: ANN001
    """The agent row carries marketplace statistics seeded to make the demo look
    lived-in. A card that reported one would be presenting fiction as evidence."""
    agent = db.execute(select(Agent).where(Agent.key == "uat-assistant", Agent.project_id.is_(None))).scalar_one()
    agent.success_rate = 0.1234
    agent.avg_duration_ms = 4321
    db.commit()

    card = client.get(f"{API}/agents/uat-assistant/model-card", headers={"X-API-Key": observer}).json()
    performance = card["performance_characteristics"]
    assert performance["success_rate"] != 0.1234
    assert 4321 not in (performance["duration_ms"]["p50"], performance["duration_ms"]["p95"])
    assert performance["source"].startswith("recorded runs")


def test_too_few_runs_is_said_plainly(client, observer: str) -> None:  # noqa: ANN001
    card = client.get(f"{API}/agents/impact-analyzer/model-card", headers={"X-API-Key": observer}).json()
    performance = card["performance_characteristics"]
    if performance["sample_size"] < 5:
        assert performance["insufficient_data"] is True
        assert performance["success_rate"] is None
        assert performance["note"]


def test_a_control_is_listed_only_while_it_is_enforced(client, db, observer: str) -> None:  # noqa: ANN001
    policy = db.execute(select(GovernancePolicy).where(GovernancePolicy.policy_type == "pii_masking")).scalars().first()
    ids = lambda: {c["id"] for c in client.get(f"{API}/agents/test-planning/model-card", headers={"X-API-Key": observer}).json()["compliance"]["controls"]}  # noqa: E731
    assert "pii_masked_before_model" in ids()

    policy.is_enabled = False
    db.commit()
    try:
        assert "pii_masked_before_model" not in ids()
    finally:
        policy.is_enabled = True
        db.commit()


def test_a_missing_control_is_stated_not_implied(client, observer: str) -> None:  # noqa: ANN001
    card = client.get(f"{API}/agents/test-planning/model-card", headers={"X-API-Key": observer}).json()
    assert card["resilience"]["circuit_breaker"]["provided"] is False
    assert card["resilience"]["retry"]["backoff"] == "linear"


def test_a_flow_card_shows_its_graph_and_its_approval_gates(client, db, observer: str, project_id: str) -> None:  # noqa: ANN001
    from app.models.flow import AgentFlow  # noqa: PLC0415

    flow = db.execute(select(AgentFlow).where(AgentFlow.project_id == project_id, AgentFlow.key == "uat-preparation")).scalar_one()
    card = client.get(f"{API}/flows/{flow.id}/model-card", headers={"X-API-Key": observer}).json()

    assert card["type"] == "flow"
    assert len(card["nodes"]) == len(flow.nodes)
    assert len(card["edges"]) == len(flow.edges)
    assert card["governance"]["approval_gates"], "this flow waits for sign-off"
    assert all(agent["model_card"].endswith("/model-card") for agent in card["agents"])


# ===========================================================================
# PII masking before a model sees anything
# ===========================================================================


def test_personal_data_is_masked_before_the_provider_sees_it(db, project_id: str, monkeypatch) -> None:  # noqa: ANN001
    """The policy says so, and was shown as evaluated on every run page while
    nothing enforced it. This is what a provider now receives."""
    from app.ai.cost.tracker import UsageContext  # noqa: PLC0415
    from app.ai.providers.base import ChatMessage  # noqa: PLC0415
    from app.ai.providers.mock import MockLLMProvider  # noqa: PLC0415
    from app.ai.router.model_router import ModelRouter, RoutingRequest  # noqa: PLC0415

    seen: list[str] = []
    original = MockLLMProvider.chat

    def capture(self, messages, selection, **kwargs):  # noqa: ANN001, ANN202
        seen.extend(message.content for message in messages)
        return original(self, messages, selection, **kwargs)

    monkeypatch.setattr(MockLLMProvider, "chat", capture)
    message = ChatMessage(role="user", content=f"Refund the customer {EMAIL}, card 4111 1111 1111 1111.")
    router = ModelRouter(db)
    router.complete([message], RoutingRequest(capability="generation"), UsageContext(project_id=project_id))

    assert EMAIL not in " ".join(seen)
    assert "4111 1111 1111 1111" not in " ".join(seen)
    assert "[REDACTED_EMAIL]" in " ".join(seen)

    policy = db.execute(select(GovernancePolicy).where(GovernancePolicy.policy_type == "pii_masking")).scalars().first()
    policy.is_enabled = False
    db.flush()
    seen.clear()
    router.complete([message], RoutingRequest(capability="generation"), UsageContext(project_id=project_id))
    assert EMAIL in " ".join(seen), "with the policy off, nothing is masked"
    db.rollback()


# ===========================================================================
# The SOP
# ===========================================================================


def test_any_valid_key_can_read_the_sop(client, db, project_id: str) -> None:  # noqa: ANN001
    token = _key(db, project_id, "sop-reader", ["runs:read"], grants_all_agents=False, grants_all_flows=False)
    sop = client.get(f"{API}/sop", headers={"X-API-Key": token}).json()
    assert {"purpose", "workflow", "operations", "incidents", "escalation"} <= set(sop)
    assert client.get(f"{API}/sop").status_code == 401


def test_the_sop_document_matches_the_served_sop() -> None:
    """The Markdown copy is generated; editing it by hand would make it disagree."""
    from app.services.sop import consumer_sop, render_markdown  # noqa: PLC0415

    document = Path(__file__).resolve().parents[2] / "docs" / "integration" / "SOP.md"
    assert document.read_text(encoding="utf-8") == render_markdown(consumer_sop()), (
        "docs/integration/SOP.md is stale; regenerate it with scripts/export_agent_documentation.py"
    )
