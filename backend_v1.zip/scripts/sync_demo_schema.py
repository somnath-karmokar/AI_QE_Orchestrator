"""Bring a live SQLite database up to what the models declare.

The demo database is built with `create_all`, which creates missing *tables* but
never alters existing ones. So every time a column is added to a model, a
database created before that change keeps working until something reads the new
column, and then fails with `no such column`.

This closes that gap: it creates missing tables, adds missing columns, and
reports exactly what it changed. Safe to run repeatedly, and safe to run against
a database with data in it -- it only ever adds.

    python scripts/sync_demo_schema.py                 # the default demo database
    python scripts/sync_demo_schema.py --check         # report drift, change nothing
    python scripts/sync_demo_schema.py path/to.db

Production databases use Alembic; this is for the demo and for local work.
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import inspect  # noqa: E402
from sqlalchemy.schema import CreateTable  # noqa: E402

import app.models  # noqa: E402, F401 - registers every table on the metadata
from app.core.database import engine  # noqa: E402
from app.models.base import Base  # noqa: E402

BACKEND_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = BACKEND_ROOT / "data" / "aiqe.db"

# SQLite will not add a NOT NULL column without a default, so supply one that
# matches the column's own type rather than refusing to help.
_FALLBACK_DEFAULT = {
    "INTEGER": "0",
    "BIGINT": "0",
    "SMALLINT": "0",
    "FLOAT": "0",
    "NUMERIC": "0",
    "BOOLEAN": "0",
    "JSON": "'{}'",
    "TEXT": "''",
    "VARCHAR": "''",
    "DATETIME": "CURRENT_TIMESTAMP",
}


def _server_default(column) -> str:  # noqa: ANN001
    if column.server_default is not None:
        return str(column.server_default.arg)
    default = getattr(column.default, "arg", None)
    if default is not None and not callable(default):
        if isinstance(default, bool):
            return "1" if default else "0"
        if isinstance(default, (int, float)):
            return str(default)
        if isinstance(default, str):
            return f"'{default}'"
    # A JSON column defaulting to list/dict shows up as a callable.
    type_name = column.type.__class__.__name__.upper()
    compiled = str(column.type).split("(")[0].upper()
    for key in (type_name, compiled):
        if key in _FALLBACK_DEFAULT:
            return _FALLBACK_DEFAULT[key]
    if "JSON" in type_name or "JSON" in compiled:
        return "'{}'"
    return "''"


def sync(db_path: Path, *, check_only: bool = False) -> int:
    if not db_path.exists():
        print(f"No database at {db_path}; nothing to do.")
        return 0

    created_tables: list[str] = []
    added_columns: list[str] = []

    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())

    connection = sqlite3.connect(db_path)
    try:
        for name, table in Base.metadata.tables.items():
            if name not in existing_tables:
                created_tables.append(name)
                if not check_only:
                    connection.execute(str(CreateTable(table).compile(engine)))
                continue

            present = {row[1] for row in connection.execute(f"PRAGMA table_info({name})")}
            for column in table.columns:
                if column.name in present:
                    continue
                type_sql = column.type.compile(engine.dialect)
                clause = f"{column.name} {type_sql}"
                if not column.nullable:
                    clause += f" NOT NULL DEFAULT {_server_default(column)}"
                added_columns.append(f"{name}.{column.name}")
                if not check_only:
                    connection.execute(f"ALTER TABLE {name} ADD COLUMN {clause}")
        if not check_only:
            connection.commit()
    finally:
        connection.close()

    verb = "would create" if check_only else "created"
    if created_tables:
        print(f"Tables {verb}  : {', '.join(sorted(created_tables))}")
    verb = "would add" if check_only else "added"
    if added_columns:
        print(f"Columns {verb} : {', '.join(sorted(added_columns))}")
    if not created_tables and not added_columns:
        print(f"{db_path.name} already matches the models.")
        return 0

    if check_only:
        print("\nRun without --check to apply.")
        return 1
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("database", nargs="?", default=str(DEFAULT_DB))
    parser.add_argument("--check", action="store_true", help="report drift without changing anything")
    args = parser.parse_args()
    return sync(Path(args.database), check_only=args.check)


if __name__ == "__main__":
    raise SystemExit(main())
