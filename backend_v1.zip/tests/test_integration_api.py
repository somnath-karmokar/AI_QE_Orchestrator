"""The surface other platforms integrate against.

Most of these are security tests. An integration key is a credential handed to
a system outside this one, so what it *cannot* do matters more than what it can:
it must not be able to enumerate a project, read another key's runs, or invoke
anything it was not explicitly granted.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.core.errors import ValidationError
from app.models.flow import AgentFlow
from app.models.governance import AuditLog
from app.models.integration import DEFAULT_SCOPES, SCOPES, IntegrationClient
from app.models.run import AgentRun
from app.services.integration import disposition, run_envelope
from app.services.integration_clients import issue_client, revoke_client, rotate_token

BASE = "/api/v1/integration"


@pytest.fixture
def flow(db, project_id: str) -> AgentFlow:
    row = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id, AgentFlow.is_deleted.is_(False)
        )
    ).scalars().first()
    assert row is not None, "the demo project should contain flows"
    return row


@pytest.fixture
def client_token(db, project_id: str, flow: AgentFlow) -> tuple[IntegrationClient, str]:
    record, token = issue_client(
        db,
        project_id=project_id,
        name="jenkins-nightly",
        actor="alex.morgan@example.com",
        platform="jenkins",
        allowed_flow_ids=[flow.id],
    )
    db.commit()
    return record, token


def headers(token: str) -> dict[str, str]:
    return {"X-API-Key": token}


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------


def test_a_call_without_a_key_is_refused(client) -> None:
    assert client.get(f"{BASE}/manifest").status_code == 401


def test_an_unknown_key_is_refused(client) -> None:
    assert client.get(f"{BASE}/manifest", headers=headers("qei_not-a-real-token")).status_code == 401


def test_a_revoked_key_stops_working(client, db, client_token) -> None:
    record, token = client_token
    assert client.get(f"{BASE}/manifest", headers=headers(token)).status_code == 200

    revoke_client(db, record, "alex.morgan@example.com")
    db.commit()
    assert client.get(f"{BASE}/manifest", headers=headers(token)).status_code == 401


def test_rotating_a_key_invalidates_the_previous_one(client, db, client_token) -> None:
    record, old_token = client_token
    new_token = rotate_token(db, record, "alex.morgan@example.com")
    db.commit()

    assert client.get(f"{BASE}/manifest", headers=headers(old_token)).status_code == 401
    assert client.get(f"{BASE}/manifest", headers=headers(new_token)).status_code == 200


def test_every_authentication_failure_reads_the_same(client, db, client_token) -> None:
    """A caller must not be able to tell an unknown key from a revoked one."""
    record, token = client_token
    revoke_client(db, record, "alex.morgan@example.com")
    db.commit()

    revoked = client.get(f"{BASE}/manifest", headers=headers(token))
    unknown = client.get(f"{BASE}/manifest", headers=headers("qei_completely-made-up"))
    missing = client.get(f"{BASE}/manifest")

    messages = {response.json()["error"]["message"] for response in (revoked, unknown, missing)}
    assert len(messages) == 1, f"authentication failures differ: {messages}"


def test_the_token_is_returned_once_and_never_stored(db, project_id: str) -> None:
    record, token = issue_client(
        db, project_id=project_id, name="one-time", actor="alex.morgan@example.com"
    )
    assert token.startswith("qei_")
    # Only the hash and a hint are kept.
    assert token not in record.token_hash
    assert record.token_hint == token[-4:]
    assert len(record.token_hint) == 4


# ---------------------------------------------------------------------------
# Scopes
# ---------------------------------------------------------------------------


def test_a_key_gets_a_usable_default_set_of_scopes(db, project_id: str) -> None:
    record, _ = issue_client(
        db, project_id=project_id, name="defaults", actor="alex.morgan@example.com"
    )
    assert set(record.scopes) == set(DEFAULT_SCOPES)
    # A pipeline has to be able to read back what it started.
    assert record.has_scope("runs:read")


def test_an_unknown_scope_is_rejected_at_issue_time(db, project_id: str) -> None:
    with pytest.raises(ValidationError):
        issue_client(
            db,
            project_id=project_id,
            name="bad-scope",
            actor="alex.morgan@example.com",
            scopes=["flows:run", "everything:*"],
        )


def test_a_key_with_no_scopes_is_rejected(db, project_id: str) -> None:
    with pytest.raises(ValidationError):
        issue_client(
            db, project_id=project_id, name="empty", actor="alex.morgan@example.com", scopes=[]
        )


def test_a_missing_scope_is_refused_and_says_which(client, db, project_id: str, flow) -> None:
    record, token = issue_client(
        db,
        project_id=project_id,
        name="starter-only",
        actor="alex.morgan@example.com",
        scopes=["flows:run"],
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    response = client.get(f"{BASE}/catalog", headers=headers(token))
    assert response.status_code == 403
    details = response.json()["error"]["details"]
    assert details["required_scope"] == "catalog:read"
    assert "flows:run" in details["granted_scopes"]


def test_there_is_no_wildcard_grant(db, project_id: str) -> None:
    """An empty allow-list means none, never all."""
    record, _ = issue_client(
        db,
        project_id=project_id,
        name="nothing-granted",
        actor="alex.morgan@example.com",
        scopes=["flows:run", "agents:run"],
    )
    assert record.may_run_flow("any-flow-at-all") is False
    assert record.may_run_agent("self-healing-automation") is False


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def test_the_manifest_tells_an_integrator_what_they_need(client, client_token) -> None:
    _record, token = client_token
    body = client.get(f"{BASE}/manifest", headers=headers(token)).json()

    assert body["authentication"]["header"] == "X-API-Key"
    assert body["platform"]["api_version"] == "v1"
    assert set(body["authentication"]["scopes_available"]) == set(SCOPES)
    assert "waiting_for_approval" in body["conventions"]["run_dispositions"]
    assert body["endpoints"]["run_status"]
    assert body["limits"]["rate_limit_per_minute"] >= 1


def test_the_manifest_states_the_guardrail_contract(client, client_token) -> None:
    """The promises an integrator is allowed to design around."""
    _record, token = client_token
    guardrails = client.get(f"{BASE}/manifest", headers=headers(token)).json()["guardrails"]

    ids = {item["id"] for item in guardrails["guarantees"]}
    assert "business_assertions_never_changed" in ids
    assert "no_unvalidated_repair" in ids
    assert "human_approval_for_high_risk" in ids
    # Each promise names where it is enforced, so it can be checked, not trusted.
    for guarantee in guardrails["guarantees"]:
        assert guarantee["enforced_by"].startswith("app/")
    assert guardrails["caller_obligations"]


def test_the_catalog_publishes_input_schemas(client, client_token, flow) -> None:
    _record, token = client_token
    body = client.get(f"{BASE}/catalog", headers=headers(token)).json()

    assert body["counts"]["flows"] == 1
    entry = body["flows"][0]
    assert entry["id"] == flow.id
    assert entry["invoke"]["path"].endswith(f"/flows/{flow.id}/runs")
    assert entry["input_schema"]["type"] == "object"
    assert "requires_approval" in entry["guardrails"]


def test_the_catalog_shows_only_what_was_granted(client, db, project_id: str, flow) -> None:
    """Not a filter on display -- a key cannot see the rest of the project."""
    record, token = issue_client(
        db,
        project_id=project_id,
        name="scoped",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    total_flows = len(
        db.execute(
            select(AgentFlow).where(
                AgentFlow.project_id == project_id, AgentFlow.is_deleted.is_(False)
            )
        ).scalars().all()
    )
    assert total_flows > 1, "the demo project should have several flows"

    body = client.get(f"{BASE}/catalog", headers=headers(token)).json()
    assert body["counts"]["flows"] == 1


# ---------------------------------------------------------------------------
# Invocation and isolation
# ---------------------------------------------------------------------------


def test_a_pipeline_can_start_a_flow_and_read_it_back(client, client_token, flow) -> None:
    """The gap this closed: the trigger used to hand back a status URL that the
    token holder was not allowed to call."""
    _record, token = client_token

    started = client.post(f"{BASE}/flows/{flow.id}/runs", headers=headers(token), json={"inputs": {}})
    assert started.status_code == 202, started.text
    body = started.json()
    assert body["disposition"] in {"pending", "waiting_for_approval", "succeeded", "failed"}

    # The same key can follow its own run.
    follow_up = client.get(f"{BASE}/runs/{body['run_id']}", headers=headers(token))
    assert follow_up.status_code == 200, follow_up.text
    assert follow_up.json()["run_id"] == body["run_id"]


def test_a_flow_that_was_not_granted_is_indistinguishable_from_one_that_does_not_exist(
    client, db, project_id: str, flow
) -> None:
    other = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.id != flow.id,
            AgentFlow.is_deleted.is_(False),
        )
    ).scalars().first()
    assert other is not None

    _record, token = issue_client(
        db,
        project_id=project_id,
        name="one-flow-only",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    ungranted = client.post(f"{BASE}/flows/{other.id}/runs", headers=headers(token), json={})
    imaginary = client.post(
        f"{BASE}/flows/00000000-0000-0000-0000-000000000000/runs", headers=headers(token), json={}
    )
    assert ungranted.status_code == imaginary.status_code == 404
    # Byte-identical, including not echoing the id back.
    assert ungranted.json()["error"]["message"] == imaginary.json()["error"]["message"]
    assert other.id not in ungranted.text


def test_a_key_cannot_read_another_keys_run(client, db, project_id: str, flow) -> None:
    first, first_token = issue_client(
        db,
        project_id=project_id,
        name="pipeline-a",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    second, second_token = issue_client(
        db,
        project_id=project_id,
        name="pipeline-b",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    started = client.post(f"{BASE}/flows/{flow.id}/runs", headers=headers(first_token), json={})
    run_id = started.json()["run_id"]

    assert client.get(f"{BASE}/runs/{run_id}", headers=headers(first_token)).status_code == 200
    assert client.get(f"{BASE}/runs/{run_id}", headers=headers(second_token)).status_code == 404


def test_a_key_cannot_read_a_run_a_person_started(client, db, client_token, project_id: str) -> None:
    _record, token = client_token
    human_run = db.execute(
        select(AgentRun).where(
            AgentRun.project_id == project_id, AgentRun.triggered_by.notlike("integration:%")
        )
    ).scalars().first()
    assert human_run is not None, "the demo project should contain runs started by people"

    assert client.get(f"{BASE}/runs/{human_run.id}", headers=headers(token)).status_code == 404


def test_repeating_a_start_with_the_same_idempotency_key_returns_the_first_run(
    client, client_token, flow
) -> None:
    """A network retry must not start the work twice."""
    _record, token = client_token
    request = {"inputs": {}}
    key = {"X-Idempotency-Key": "build-8412"}

    first = client.post(f"{BASE}/flows/{flow.id}/runs", headers={**headers(token), **key}, json=request)
    second = client.post(f"{BASE}/flows/{flow.id}/runs", headers={**headers(token), **key}, json=request)

    assert first.status_code == 202
    assert second.status_code == 200
    assert second.headers.get("X-Idempotent-Replay") == "true"
    assert first.json()["run_id"] == second.json()["run_id"]


def test_different_idempotency_keys_start_different_runs(client, client_token, flow) -> None:
    _record, token = client_token
    first = client.post(
        f"{BASE}/flows/{flow.id}/runs",
        headers={**headers(token), "X-Idempotency-Key": "build-1"},
        json={},
    )
    second = client.post(
        f"{BASE}/flows/{flow.id}/runs",
        headers={**headers(token), "X-Idempotency-Key": "build-2"},
        json={},
    )
    assert first.json()["run_id"] != second.json()["run_id"]


def test_starting_a_flow_is_audited_against_the_calling_system(
    client, db, client_token, flow
) -> None:
    _record, token = client_token
    client.post(f"{BASE}/flows/{flow.id}/runs", headers=headers(token), json={})

    entry = db.execute(
        select(AuditLog)
        .where(AuditLog.action == "integration.flow_started")
        .order_by(AuditLog.created_at.desc())
    ).scalars().first()
    assert entry is not None
    assert entry.actor == "integration:jenkins-nightly"
    assert entry.input_summary["client_platform"] == "jenkins"


# ---------------------------------------------------------------------------
# The run envelope
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("status", "expected"),
    [
        ("queued", "pending"),
        ("running", "pending"),
        ("paused", "waiting_for_approval"),
        ("succeeded", "succeeded"),
        ("failed", "failed"),
        ("cancelled", "cancelled"),
        ("something-new", "pending"),
    ],
)
def test_internal_statuses_map_onto_a_small_stable_set(status: str, expected: str) -> None:
    """A caller branches on `disposition`, so it must not need to know this
    platform's internal vocabulary."""
    assert disposition(status) == expected


def test_a_paused_run_is_reported_as_waiting_not_failed(db, client_token, flow) -> None:
    """The distinction an integration must not get wrong."""
    from app.governance.policy_engine import PolicyEngine  # noqa: PLC0415

    record, _token = client_token
    run = db.execute(
        select(AgentRun).where(AgentRun.project_id == record.project_id)
    ).scalars().first()
    assert run is not None
    # A run still in flight; a finished run is not un-finished by a late approval.
    run.status = "running"
    db.flush()

    PolicyEngine(db).request_approval(
        project_id=record.project_id,
        title="Approve the deployment gate",
        reason="High-risk change to a production-like environment.",
        run_id=run.id,
        risk_level="high",
    )
    db.flush()

    envelope = run_envelope(db, run)
    assert envelope["disposition"] == "waiting_for_approval"
    assert envelope["is_terminal"] is False
    assert envelope["guardrails"]["awaiting_approval"][0]["title"] == "Approve the deployment gate"
    assert "has not failed" in envelope["guardrails"]["note"]


def test_a_finished_run_is_not_reopened_by_a_late_approval(db, client_token) -> None:
    """A pending approval left over from earlier must not make a succeeded run
    look like it is still waiting."""
    from app.governance.policy_engine import PolicyEngine  # noqa: PLC0415

    record, _token = client_token
    run = db.execute(
        select(AgentRun).where(AgentRun.project_id == record.project_id)
    ).scalars().first()
    run.status = "succeeded"
    db.flush()

    PolicyEngine(db).request_approval(
        project_id=record.project_id,
        title="Stale gate",
        reason="Left pending after the run finished.",
        run_id=run.id,
    )
    db.flush()

    envelope = run_envelope(db, run)
    assert envelope["disposition"] == "succeeded"
    assert envelope["is_terminal"] is True


def test_the_envelope_reports_cost(db, client_token) -> None:
    record, _token = client_token
    run = db.execute(
        select(AgentRun).where(AgentRun.project_id == record.project_id)
    ).scalars().first()
    envelope = run_envelope(db, run)
    assert "total_cost_usd" in envelope["guardrails"]["cost"]
    assert "total_tokens" in envelope["guardrails"]["cost"]


def test_the_envelope_does_not_leak_the_internal_step_graph(db, client_token) -> None:
    """Steps are an implementation detail and are deliberately not part of the
    contract, so they can change without breaking an integration."""
    record, _token = client_token
    run = db.execute(
        select(AgentRun).where(AgentRun.project_id == record.project_id)
    ).scalars().first()
    envelope = run_envelope(db, run)
    assert "steps" not in envelope
    assert envelope["progress"]["total_steps"] == run.step_count


# ---------------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------------


def test_the_advertised_per_key_limit_is_enforced(client, db, project_id: str, flow) -> None:
    """Advertising a limit that does nothing is worse than advertising none: an
    integrator paces against a number, and the first real constraint they meet
    is a different one they never saw."""
    from app.api import integration_auth

    record, token = issue_client(
        db,
        project_id=project_id,
        name="limited",
        actor="alex.morgan@example.com",
        rate_limit_per_minute=3,
        allowed_flow_ids=[flow.id],
    )
    db.commit()
    integration_auth._key_buckets.pop(record.id, None)  # noqa: SLF001

    codes = [client.get(f"{BASE}/manifest", headers=headers(token)).status_code for _ in range(5)]

    assert codes[:3] == [200, 200, 200]
    assert codes[3] == 429
    body = client.get(f"{BASE}/manifest", headers=headers(token)).json()
    assert body["error"]["details"]["limit_per_minute"] == 3
    assert body["error"]["details"]["retry_after_seconds"] >= 1


def test_each_key_has_its_own_budget(client, db, project_id: str, flow) -> None:
    """The global limiter buckets by IP, which would make two integrations
    behind one NAT share a budget."""
    from app.api import integration_auth

    busy, busy_token = issue_client(
        db, project_id=project_id, name="busy", actor="alex.morgan@example.com",
        rate_limit_per_minute=2, allowed_flow_ids=[flow.id],
    )
    quiet, quiet_token = issue_client(
        db, project_id=project_id, name="quiet", actor="alex.morgan@example.com",
        rate_limit_per_minute=2, allowed_flow_ids=[flow.id],
    )
    db.commit()
    for record in (busy, quiet):
        integration_auth._key_buckets.pop(record.id, None)  # noqa: SLF001

    for _ in range(3):
        client.get(f"{BASE}/manifest", headers=headers(busy_token))

    assert client.get(f"{BASE}/manifest", headers=headers(busy_token)).status_code == 429
    assert client.get(f"{BASE}/manifest", headers=headers(quiet_token)).status_code == 200


def test_the_manifest_advertises_the_mcp_endpoint(client, client_token) -> None:
    """An agent platform should not have to be told out of band that this speaks
    MCP."""
    _record, token = client_token
    manifest = client.get(f"{BASE}/manifest", headers=headers(token)).json()
    assert manifest["endpoints"]["mcp"] == "POST /mcp"
    assert manifest["conventions"]["protocols"]["mcp"] == "2024-11-05"
