"""Tests for the conversational copilot: intent, entity resolution and routing."""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.copilot.intent import extract_entities, navigation_target
from app.copilot.planner import CopilotPlanner
from app.copilot.service import CopilotService
from app.models.project import Project


@pytest.fixture
def project(db):  # noqa: ANN001, ANN201
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


@pytest.fixture
def planner(db):  # noqa: ANN001, ANN201
    return CopilotPlanner(db)


# ---------------------------------------------------------------------------
# Entity extraction
# ---------------------------------------------------------------------------


class TestEntityExtraction:
    def test_resolves_a_real_story_key(self, db, project) -> None:  # noqa: ANN001
        entities = extract_entities(db, "Is PAY-201 ready for testing?", project)
        assert entities.requirement_key == "PAY-201"
        assert entities.requirement_id is not None
        # The module comes from the requirement, not from the sentence.
        assert entities.module == "Payments"

    def test_reports_a_story_key_that_does_not_exist(self, db, project) -> None:  # noqa: ANN001
        entities = extract_entities(db, "Check ZZZ-999 please", project)
        assert entities.requirement_key is None
        assert "ZZZ-999" in entities.unresolved

    def test_matches_a_declared_module(self, db, project) -> None:  # noqa: ANN001
        entities = extract_entities(db, "generate test data for Beneficiaries", project)
        assert entities.module == "Beneficiaries"

    def test_understands_module_shorthand(self, db, project) -> None:  # noqa: ANN001
        entities = extract_entities(db, "what about the payment screens", project)
        assert entities.module == "Payments"

    def test_carries_context_from_earlier_turns(self, db, project) -> None:  # noqa: ANN001
        """'automate it' must know what 'it' refers to."""
        carried = {"requirement_key": "PAY-201", "requirement_id": "abc", "module": "Payments"}
        entities = extract_entities(db, "now automate it", project, carried)
        assert entities.requirement_key == "PAY-201"
        assert entities.module == "Payments"

    def test_extracts_execution_options(self, db, project) -> None:  # noqa: ANN001
        entities = extract_entities(db, "run the smoke suite on firefox", project)
        assert entities.suite_type == "smoke"
        assert entities.browser == "firefox"

    def test_maps_browser_aliases(self, db, project) -> None:  # noqa: ANN001
        assert extract_entities(db, "run it on chrome", project).browser == "chromium"

    @pytest.mark.parametrize(
        ("message", "route"),
        [
            ("show me the defects", "/quality/defects"),
            ("open the flow builder", "/flows"),
            ("take me to governance", "/governance"),
            ("where is the knowledge base", "/knowledge"),
        ],
    )
    def test_navigation_targets(self, message: str, route: str) -> None:
        target = navigation_target(message)
        assert target is not None
        assert target[0] == route

    def test_unknown_navigation_returns_nothing(self) -> None:
        assert navigation_target("make me a sandwich") is None


# ---------------------------------------------------------------------------
# Planning
# ---------------------------------------------------------------------------


class TestPlanner:
    @pytest.mark.parametrize(
        ("message", "expected_agent"),
        [
            ("Is PAY-201 ready for testing?", "user-story-completeness"),
            ("Generate test scenarios for PAY-201", "test-scenario-generator"),
            ("Where is the risk in this release?", "defect-prediction"),
            ("We changed Payments, what needs retesting?", "regression-suite-optimization"),
            ("Create test data for Beneficiaries", "test-data-generator"),
            ("Prepare UAT scripts for Payments", "uat-assistant"),
            ("Check accessibility for Accounts", "accessibility-test"),
        ],
    )
    def test_routes_to_the_right_specialist(self, db, project, planner, message, expected_agent) -> None:  # noqa: ANN001
        entities = extract_entities(db, message, project)
        plan = planner.plan(message, project=project, entities=entities)
        assert plan.kind in {"run_agent", "run_flow"}
        assert plan.selected, f"no agent selected for '{message}'"
        assert plan.selected[0].agent_key == expected_agent

    def test_knowledge_questions_are_answered_not_executed(self, db, project, planner) -> None:  # noqa: ANN001
        message = "What is the daily payment limit?"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.kind == "answer"

    def test_navigation_does_not_run_an_agent(self, db, project, planner) -> None:  # noqa: ANN001
        message = "Show me the defects"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.kind == "navigate"
        assert plan.navigation["route"] == "/quality/defects"

    def test_nonsense_asks_rather_than_guessing(self, db, project, planner) -> None:  # noqa: ANN001
        message = "banana helicopter"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.kind == "clarify"
        assert plan.clarify_options, "a clarification should offer alternatives"

    def test_generation_without_a_subject_asks_for_one(self, db, project, planner) -> None:  # noqa: ANN001
        """'generate test cases' with no story or module is unanswerable."""
        message = "Generate test cases"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.kind == "clarify"

    def test_multi_step_request_uses_a_flow(self, db, project, planner) -> None:  # noqa: ANN001
        message = "Automate PAY-201 end to end"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.kind == "run_flow"
        assert plan.flow_key == "requirement-to-automated-test"

    def test_plan_explains_itself(self, db, project, planner) -> None:  # noqa: ANN001
        """The UI shows why an agent was chosen, so the plan must say."""
        message = "Is PAY-201 ready for testing?"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.reasoning
        assert len(plan.considered) > 1, "alternatives should be recorded, not just the winner"
        # Every candidate carries the two signals that produced its score.
        for candidate in plan.considered:
            assert 0.0 <= candidate.score <= 1.0
            assert candidate.rationale

    def test_selected_agent_outranks_the_alternatives(self, db, project, planner) -> None:  # noqa: ANN001
        message = "Create test data for Beneficiaries"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        best = plan.selected[0]
        others = [c for c in plan.considered if c.agent_key != best.agent_key]
        assert all(best.score >= other.score for other in others)

    def test_agent_inputs_are_populated_from_entities(self, db, project, planner) -> None:  # noqa: ANN001
        message = "Generate test scenarios for PAY-201"
        plan = planner.plan(message, project=project, entities=extract_entities(db, message, project))
        assert plan.agent_inputs.get("requirement_key") == "PAY-201"


# ---------------------------------------------------------------------------
# Conversation
# ---------------------------------------------------------------------------


class TestConversation:
    def test_a_turn_runs_an_agent_and_records_everything(self, db, project) -> None:  # noqa: ANN001
        service = CopilotService(db)
        conversation = service.get_or_create_conversation(
            conversation_id=None, project_id=project.id, user_id=None
        )
        reply = service.handle_message(
            conversation=conversation,
            message="Is PAY-201 ready for testing?",
            project=project,
            actor="tester@example.com",
        )

        assert reply.role == "assistant"
        assert reply.plan_kind == "run_agent"
        assert reply.run_id, "the agent should actually have run"
        assert reply.selected_agents
        assert reply.reasoning_summary
        # Cost is attributed, exactly as it is for a Flow Builder run.
        assert reply.total_tokens > 0

    def test_follow_up_resolves_a_pronoun(self, db, project) -> None:  # noqa: ANN001
        service = CopilotService(db)
        conversation = service.get_or_create_conversation(
            conversation_id=None, project_id=project.id, user_id=None
        )
        service.handle_message(
            conversation=conversation, message="Is PAY-201 ready for testing?",
            project=project, actor="t",
        )
        reply = service.handle_message(
            conversation=conversation, message="Now generate test scenarios for it",
            project=project, actor="t",
        )
        assert reply.extracted_entities.get("requirement_key") == "PAY-201"
        assert reply.selected_agents[0]["agent_key"] == "test-scenario-generator"

    def test_conversation_is_titled_from_the_first_message(self, db, project) -> None:  # noqa: ANN001
        service = CopilotService(db)
        conversation = service.get_or_create_conversation(
            conversation_id=None, project_id=project.id, user_id=None
        )
        service.handle_message(
            conversation=conversation, message="Where is the risk in this release?",
            project=project, actor="t",
        )
        assert conversation.title.startswith("Where is the risk")

    def test_voice_turns_are_marked(self, db, project) -> None:  # noqa: ANN001
        service = CopilotService(db)
        conversation = service.get_or_create_conversation(
            conversation_id=None, project_id=project.id, user_id=None
        )
        reply = service.handle_message(
            conversation=conversation, message="How is quality looking?",
            project=project, actor="t", is_voice=True,
        )
        assert reply.is_voice is True

    def test_auto_execute_off_describes_instead_of_running(self, db, project) -> None:  # noqa: ANN001
        service = CopilotService(db)
        conversation = service.get_or_create_conversation(
            conversation_id=None, project_id=project.id, user_id=None
        )
        reply = service.handle_message(
            conversation=conversation, message="Create test data for Payments",
            project=project, actor="t", auto_execute=False,
        )
        assert reply.run_id is None
        assert "would run" in reply.content.lower()


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------


class TestCopilotApi:
    def test_message_endpoint(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        response = client.post(
            "/api/v1/copilot/message",
            headers=auth_headers,
            json={"project_id": project_id, "message": "Where is the risk in this release?"},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["conversation_id"]
        assert body["message"]["plan_kind"] in {"run_agent", "run_flow", "answer"}

    def test_requires_authentication(self, client, project_id) -> None:  # noqa: ANN001
        response = client.post(
            "/api/v1/copilot/message",
            json={"project_id": project_id, "message": "hello"},
        )
        assert response.status_code == 401

    def test_capabilities_endpoint(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        response = client.get(
            f"/api/v1/copilot/capabilities?project_id={project_id}", headers=auth_headers
        )
        assert response.status_code == 200
        body = response.json()
        assert body["intents"] and body["starters"]

    def test_conversation_history_round_trip(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        first = client.post(
            "/api/v1/copilot/message",
            headers=auth_headers,
            json={"project_id": project_id, "message": "How is quality looking?"},
        ).json()
        conversation_id = first["conversation_id"]

        detail = client.get(
            f"/api/v1/copilot/conversations/{conversation_id}", headers=auth_headers
        )
        assert detail.status_code == 200
        # One user turn plus one assistant turn.
        assert len(detail.json()["messages"]) >= 2
