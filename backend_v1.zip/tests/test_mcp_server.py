"""The platform exposed as an MCP server.

An MCP tool call and a REST call are the same operation routed differently, so
the interesting tests are the ones that would catch the two drifting apart: the
same scopes, the same isolation, the same guarantees.

The rest is protocol conformance, and one distinction that matters more than it
looks — MCP separates a *protocol* failure from a *tool* failure, and collapsing
them would make "policy declined this" look like "the server is broken".
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.models.flow import AgentFlow
from app.models.governance import AuditLog
from app.services.integration_clients import issue_client
from app.services.mcp_tools import PROTOCOL_VERSION, tool_name, tools_as_openai_functions

MCP = "/api/v1/mcp"


@pytest.fixture
def flow(db, project_id: str) -> AgentFlow:
    row = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id, AgentFlow.is_deleted.is_(False)
        )
    ).scalars().first()
    assert row is not None
    return row


@pytest.fixture
def key(db, project_id: str, flow: AgentFlow) -> str:
    _client, token = issue_client(
        db,
        project_id=project_id,
        name="mcp-agent",
        actor="alex.morgan@example.com",
        platform="another-agent-platform",
        allowed_flow_ids=[flow.id],
    )
    db.commit()
    return token


def rpc(client, token: str, method: str, params: dict | None = None, request_id: int = 1):  # noqa: ANN001, ANN201
    body = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        body["params"] = params
    return client.post(MCP, headers={"X-API-Key": token}, json=body)


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


def test_an_unauthenticated_call_is_refused(client) -> None:
    response = client.post(MCP, json={"jsonrpc": "2.0", "id": 1, "method": "initialize"})
    assert response.status_code == 401


def test_initialize_declares_the_protocol_and_the_server(client, key: str) -> None:
    result = rpc(client, key, "initialize").json()["result"]

    assert result["protocolVersion"] == PROTOCOL_VERSION
    assert result["capabilities"]["tools"] is not None
    assert result["serverInfo"]["name"]


def test_initialize_tells_an_agent_what_it_must_not_get_wrong(client, key: str) -> None:
    """The instruction block exists so an agent learns this before it retries a
    run that is waiting on a person."""
    instructions = rpc(client, key, "initialize").json()["result"]["instructions"]

    assert "waiting_for_approval" in instructions
    assert "not a failure" in instructions
    assert "Do not retry" in instructions
    # And the healing guarantee, since these tools can trigger repairs.
    assert "never changes what a test asserts" in instructions


def test_a_non_jsonrpc_body_is_rejected(client, key: str) -> None:
    response = client.post(MCP, headers={"X-API-Key": key}, json={"hello": "world"})
    assert response.json()["error"]["code"] == -32600


def test_an_unknown_method_is_reported_as_such(client, key: str) -> None:
    assert rpc(client, key, "resources/list").json()["error"]["code"] == -32601


def test_ping_is_answered(client, key: str) -> None:
    assert rpc(client, key, "ping").json()["result"] == {}


def test_the_request_id_is_echoed(client, key: str) -> None:
    assert rpc(client, key, "ping", request_id=4242).json()["id"] == 4242


# ---------------------------------------------------------------------------
# Discovery is the authorisation boundary
# ---------------------------------------------------------------------------


def test_granted_flows_are_listed_as_tools(client, key: str, flow: AgentFlow) -> None:
    tools = rpc(client, key, "tools/list").json()["result"]["tools"]
    names = {tool["name"] for tool in tools}

    assert tool_name("run_flow", flow.key) in names
    assert "get_run" in names


def test_a_tool_carries_a_schema_an_agent_can_fill_in(client, key: str, flow: AgentFlow) -> None:
    tools = rpc(client, key, "tools/list").json()["result"]["tools"]
    entry = next(tool for tool in tools if tool["name"] == tool_name("run_flow", flow.key))

    assert entry["inputSchema"]["type"] == "object"
    # The description has to carry the asynchronous contract; an agent will not
    # read the docs site.
    assert "poll get_run" in entry["description"]
    assert "waiting_for_approval" in entry["description"]


def test_an_ungranted_flow_is_not_listed(client, db, project_id: str, flow: AgentFlow) -> None:
    """The listing is the authorisation boundary, not a convenience filter."""
    other = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.id != flow.id,
            AgentFlow.is_deleted.is_(False),
        )
    ).scalars().first()
    assert other is not None

    _record, token = issue_client(
        db,
        project_id=project_id,
        name="one-flow-only",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    names = {tool["name"] for tool in rpc(client, token, "tools/list").json()["result"]["tools"]}
    assert tool_name("run_flow", other.key) not in names


def test_a_key_without_the_scope_sees_no_run_tools(client, db, project_id: str, flow) -> None:
    _record, token = issue_client(
        db,
        project_id=project_id,
        name="reader-only",
        actor="alex.morgan@example.com",
        scopes=["catalog:read", "runs:read"],
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    names = {tool["name"] for tool in rpc(client, token, "tools/list").json()["result"]["tools"]}
    assert names == {"get_run"}


def test_tool_names_are_stable_identifiers() -> None:
    """An agent may store a tool name, so it comes from the key rather than a
    display name somebody may rename."""
    assert tool_name("run_flow", "Payment Regression!") == "run_flow_payment_regression"


# ---------------------------------------------------------------------------
# Invocation
# ---------------------------------------------------------------------------


def test_calling_a_flow_tool_starts_a_run(client, key: str, flow: AgentFlow) -> None:
    response = rpc(
        client, key, "tools/call",
        {"name": tool_name("run_flow", flow.key), "arguments": {}},
    )
    result = response.json()["result"]

    assert result["isError"] is False
    envelope = result["structuredContent"]
    assert envelope["run_id"]
    assert envelope["disposition"] in {
        "pending", "waiting_for_approval", "succeeded", "failed",
    }


def test_a_tool_result_carries_both_prose_and_structure(client, key: str, flow) -> None:
    """The text is what a model reads to decide what to do next; the structured
    content is what code branches on."""
    result = rpc(
        client, key, "tools/call",
        {"name": tool_name("run_flow", flow.key), "arguments": {}},
    ).json()["result"]

    assert result["content"][0]["type"] == "text"
    assert result["content"][0]["text"]
    assert "disposition" in result["structuredContent"]


def test_a_run_can_be_read_back_through_the_same_transport(client, key: str, flow) -> None:
    started = rpc(
        client, key, "tools/call",
        {"name": tool_name("run_flow", flow.key), "arguments": {}},
    ).json()["result"]["structuredContent"]

    read = rpc(
        client, key, "tools/call",
        {"name": "get_run", "arguments": {"run_id": started["run_id"]}},
    ).json()["result"]

    assert read["isError"] is False
    assert read["structuredContent"]["run_id"] == started["run_id"]


def test_an_unknown_tool_is_a_tool_error_not_a_protocol_error(client, key: str) -> None:
    """The distinction MCP draws, and the reason it matters: an agent must not
    treat "you may not call this" as "the server is broken" and retry."""
    response = rpc(client, key, "tools/call", {"name": "run_flow_not_a_thing", "arguments": {}})
    body = response.json()

    assert "error" not in body, "a refused tool is a successful call with isError"
    assert body["result"]["isError"] is True


def test_an_ungranted_tool_reads_the_same_as_a_missing_one(
    client, db, project_id: str, flow
) -> None:
    other = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.id != flow.id,
            AgentFlow.is_deleted.is_(False),
        )
    ).scalars().first()

    _record, token = issue_client(
        db, project_id=project_id, name="narrow", actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    ungranted = rpc(
        client, token, "tools/call",
        {"name": tool_name("run_flow", other.key), "arguments": {}},
    ).json()["result"]
    imaginary = rpc(
        client, token, "tools/call", {"name": "run_flow_imaginary", "arguments": {}}
    ).json()["result"]

    assert ungranted["content"][0]["text"] == imaginary["content"][0]["text"]


def test_a_key_cannot_read_another_keys_run_over_mcp(client, db, project_id: str, flow) -> None:
    """The same isolation the REST route enforces, for the same reason."""
    _first, first_token = issue_client(
        db, project_id=project_id, name="agent-a", actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    _second, second_token = issue_client(
        db, project_id=project_id, name="agent-b", actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()

    started = rpc(
        client, first_token, "tools/call",
        {"name": tool_name("run_flow", flow.key), "arguments": {}},
    ).json()["result"]["structuredContent"]

    read = rpc(
        client, second_token, "tools/call",
        {"name": "get_run", "arguments": {"run_id": started["run_id"]}},
    ).json()["result"]
    assert read["isError"] is True


def test_get_run_requires_a_run_id(client, key: str) -> None:
    result = rpc(client, key, "tools/call", {"name": "get_run", "arguments": {}}).json()["result"]
    assert result["isError"] is True


def test_a_call_with_no_tool_name_is_a_protocol_error(client, key: str) -> None:
    assert rpc(client, key, "tools/call", {"arguments": {}}).json()["error"]["code"] == -32602


def test_an_mcp_call_is_audited_as_mcp(client, db, key: str, flow) -> None:
    rpc(client, key, "tools/call", {"name": tool_name("run_flow", flow.key), "arguments": {}})

    entry = db.execute(
        select(AuditLog)
        .where(AuditLog.action == "integration.mcp_flow_started")
        .order_by(AuditLog.created_at.desc())
    ).scalars().first()

    assert entry is not None
    assert entry.actor == "integration:mcp-agent"
    assert entry.input_summary["transport"] == "mcp"


def test_argument_values_are_not_written_to_the_audit_log(client, db, key: str, flow) -> None:
    """Argument values may carry customer data; the keys are enough to say what
    was called with what shape."""
    # A variable the flow actually declares -- an undeclared one is now refused
    # before a run starts, which is a different test.
    assert flow.variables, "this flow should declare variables"
    secret = "confidential-value-9f2a"
    # A declared variable, carrying the marker in the type the flow expects --
    # an undeclared or wrongly typed argument is refused before a run starts,
    # which is a different test.
    name, default = next(
        (key_, value)
        for key_, value in sorted(flow.variables.items())
        if isinstance(value, (str, list))
    )
    value = [secret] if isinstance(default, list) else secret

    rpc(
        client, key, "tools/call",
        {"name": tool_name("run_flow", flow.key), "arguments": {name: value}},
    )
    entry = db.execute(
        select(AuditLog)
        .where(AuditLog.action == "integration.mcp_flow_started")
        .order_by(AuditLog.created_at.desc())
    ).scalars().first()

    assert entry.input_summary["arguments"] == [name]
    assert secret not in str(entry.input_summary)


# ---------------------------------------------------------------------------
# The same tools, other shapes
# ---------------------------------------------------------------------------


def test_tools_are_also_offered_as_openai_functions(db, project_id: str, flow) -> None:
    """Not every caller speaks MCP; the underlying call is the same one."""
    record, _token = issue_client(
        db, project_id=project_id, name="functions", actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.flush()

    functions = tools_as_openai_functions(db, record)
    assert functions
    entry = functions[0]
    assert entry["type"] == "function"
    assert entry["function"]["name"]
    assert entry["function"]["parameters"]["type"] == "object"


# ---------------------------------------------------------------------------
# Finding the platform without a key
# ---------------------------------------------------------------------------


def test_the_discovery_document_needs_no_credential(client) -> None:
    """A caller with no key still has to be able to learn where to start."""
    response = client.get("/.well-known/qe-platform.json")
    assert response.status_code == 200

    body = response.json()
    assert body["protocols"]["mcp"]["endpoint"] == "/api/v1/mcp"
    assert body["protocols"]["rest"]["manifest"].endswith("/integration/manifest")
    assert body["authentication"]["header"] == "X-API-Key"


def test_the_discovery_document_reveals_nothing_about_any_project(client, db, project_id: str, flow) -> None:
    """Publishing capabilities here would turn a convenience into a way of
    surveying an installation."""
    from app.models.project import Project

    body = client.get("/.well-known/qe-platform.json").text
    project = db.get(Project, project_id)

    assert project.name not in body
    assert project.key not in body
    assert flow.name not in body
    assert project_id not in body
    # And no counts that would hint at size.
    for leak in ("flows_available", "agents_available", "project"):
        assert leak not in body
