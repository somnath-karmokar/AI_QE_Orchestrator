"""Run creation, dispatch, cancellation and resume."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import session_scope
from app.core.errors import ConflictError, NotFoundError, ValidationError
from app.core.logging import get_logger
from app.core.worker import CancellationToken, job_queue
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest
from app.models.project import Environment, Project
from app.models.run import AgentRun
from app.orchestration.engine import FlowEngine, next_run_number
from app.orchestration.graph import FlowGraph

logger = get_logger(__name__)

ACTIVE_STATUSES = {"queued", "running", "awaiting_approval"}


def _execute_run_job(run_id: str, job_id: str) -> None:
    """Worker entry point. Owns its own session so it is independent of the request."""
    token = CancellationToken(job_id=job_id)
    with session_scope() as session:
        engine = FlowEngine(session, cancellation=token)
        engine.execute_run(run_id)


class RunService:
    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Creation
    # ------------------------------------------------------------------
    def start_flow_run(
        self,
        *,
        flow_id: str,
        project_id: str,
        inputs: dict[str, Any] | None = None,
        environment_id: str | None = None,
        triggered_by: str | None = None,
        trigger: str = "manual",
        title: str | None = None,
    ) -> AgentRun:
        flow = self.session.get(AgentFlow, flow_id)
        if flow is None or flow.is_deleted:
            raise NotFoundError(f"Flow '{flow_id}' was not found.", details={"flow_id": flow_id})
        if flow.project_id != project_id:
            raise ValidationError("The flow does not belong to the selected project.")

        validation = FlowGraph.from_flow(flow).validate()
        if not validation["valid"]:
            raise ValidationError(
                "The flow is not valid and cannot be run.",
                details={"validation": validation},
            )

        environment_id = environment_id or flow.default_environment_id
        if environment_id and self.session.get(Environment, environment_id) is None:
            raise NotFoundError(f"Environment '{environment_id}' was not found.")

        run = AgentRun(
            project_id=project_id,
            flow_id=flow.id,
            flow_version=flow.version,
            environment_id=environment_id,
            run_number=next_run_number(self.session, project_id),
            title=title or flow.name,
            kind="flow",
            status="queued",
            trigger=trigger,
            correlation_id=str(uuid.uuid4()),
            inputs=inputs or {},
            variables={},
            step_count=validation.get("agent_node_count", 0),
            triggered_by=triggered_by,
        )
        self.session.add(run)
        self.session.flush()
        return run

    def start_agent_run(
        self,
        *,
        agent_id: str,
        project_id: str,
        inputs: dict[str, Any] | None = None,
        environment_id: str | None = None,
        triggered_by: str | None = None,
        kind: str = "agent",
    ) -> AgentRun:
        agent = self.session.get(Agent, agent_id)
        if agent is None or agent.is_deleted:
            raise NotFoundError(f"Agent '{agent_id}' was not found.", details={"agent_id": agent_id})

        run = AgentRun(
            project_id=project_id,
            agent_id=agent.id,
            environment_id=environment_id,
            run_number=next_run_number(self.session, project_id),
            title=f"{agent.name}",
            kind=kind,
            status="queued",
            trigger="manual",
            correlation_id=str(uuid.uuid4()),
            inputs=inputs or {},
            step_count=1,
            triggered_by=triggered_by,
        )
        self.session.add(run)
        self.session.flush()
        return run

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------
    def dispatch(self, run: AgentRun) -> AgentRun:
        """Hand the run to the background worker and record the job id.

        The job id is allocated up front and committed together with the run, so
        a cancellation arriving immediately after dispatch always finds it.
        """
        job_id = str(uuid.uuid4())
        run.job_id = job_id
        self.session.flush()
        # The worker opens its own session, so the run must be visible first.
        self.session.commit()

        job_queue.submit(
            f"run:{run.id}",
            _execute_run_job,
            run.id,
            job_id,
            job_id=job_id,
            correlation_id=run.correlation_id,
            job_metadata={"run_id": run.id, "project_id": run.project_id},
        )
        logger.info("run_dispatched", run_id=run.id, job_id=job_id)
        return run

    def run_synchronously(self, run: AgentRun) -> AgentRun:
        """Execute inline. Used by tests and by the agent 'Test' action."""
        engine = FlowEngine(self.session)
        return engine.execute_run(run.id)

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------
    def cancel(self, run_id: str, actor: str | None = None) -> AgentRun:
        run = self.session.get(AgentRun, run_id)
        if run is None:
            raise NotFoundError(f"Run '{run_id}' was not found.")
        if run.status not in ACTIVE_STATUSES:
            raise ConflictError(f"Run is '{run.status}' and cannot be cancelled.")

        if run.job_id:
            job_queue.cancel(run.job_id)
        run.status = "cancelled"
        run.finished_at = datetime.now(UTC)
        run.summary = f"Cancelled by {actor or 'user'}."
        self.session.flush()
        logger.info("run_cancelled", run_id=run_id, actor=actor)
        return run

    def resume(self, run_id: str, actor: str | None = None) -> AgentRun:
        """Resume a paused run once its approvals have been decided."""
        run = self.session.get(AgentRun, run_id)
        if run is None:
            raise NotFoundError(f"Run '{run_id}' was not found.")
        if run.status != "awaiting_approval":
            raise ConflictError(f"Run is '{run.status}' and is not waiting for approval.")

        pending = self.session.execute(
            select(ApprovalRequest).where(
                ApprovalRequest.run_id == run.id, ApprovalRequest.status == "pending"
            )
        ).scalars().first()
        if pending is not None:
            raise ConflictError(
                "The run still has a pending approval request.",
                details={"approval_request_id": pending.id},
            )

        run.status = "queued"
        run.resume_token = None
        self.session.flush()
        return self.dispatch(run)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def get(self, run_id: str) -> AgentRun:
        run = self.session.get(AgentRun, run_id)
        if run is None:
            raise NotFoundError(f"Run '{run_id}' was not found.", details={"run_id": run_id})
        return run

    def list_runs(
        self,
        *,
        project_id: str | None = None,
        flow_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[AgentRun], int]:
        statement = select(AgentRun)
        if project_id:
            statement = statement.where(AgentRun.project_id == project_id)
        if flow_id:
            statement = statement.where(AgentRun.flow_id == flow_id)
        if status:
            statement = statement.where(AgentRun.status == status)

        total = len(list(self.session.execute(statement).scalars().all()))
        rows = list(
            self.session.execute(
                statement.order_by(AgentRun.created_at.desc()).limit(limit).offset(offset)
            )
            .scalars()
            .all()
        )
        return rows, total


def project_or_404(session: Session, project_id: str) -> Project:
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.", details={"project_id": project_id})
    return project
