"""An OpenAPI document for the integration surface alone.

The platform's own `/api/openapi.json` describes 118 paths, of which 10 are the
contract another platform integrates against. Handing an integrator the whole
thing tells them nothing about which routes are stable, and generating a client
from it produces a hundred methods they must not call.

This is the narrow document: the integration routes, with the response shapes
spelled out. Those routes return plain dictionaries, so FastAPI infers no
response schema for them and a generated client would be typeless -- the shapes
here are written out deliberately for that reason.

**With an API key it also describes your own flows and agents**, one operation
each, carrying the real input schema. That is the version worth generating a
client from: `POST /integration/flows/{id}/runs` with a typed body per flow,
rather than one generic call taking `dict`.

Without a key it describes the contract and nothing about any project.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.integration import SCOPES, IntegrationClient
from app.services.integration import DISPOSITIONS, TERMINAL

API = settings.api_prefix


# ---------------------------------------------------------------------------
# Reusable shapes
# ---------------------------------------------------------------------------


def _schemas() -> dict[str, Any]:
    return {
        "Error": {
            "type": "object",
            "description": "Every failure has this shape.",
            "properties": {
                "error": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string", "example": "validation_error"},
                        "message": {"type": "string"},
                        "details": {"type": "object", "additionalProperties": True},
                        "correlation_id": {
                            "type": "string",
                            "description": "Log this; it ties your request to the platform's own logs and audit entries.",
                        },
                    },
                    "required": ["code", "message"],
                }
            },
        },
        "InvalidInputs": {
            "type": "object",
            "description": (
                "Returned when inputs do not match what the flow or agent declares. "
                "An input that is not declared is rejected rather than ignored: ignoring it "
                "would mean running on the declared default and returning a confident answer "
                "about something you did not ask for."
            ),
            "properties": {
                "invalid_inputs": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "field": {"type": "string"},
                            "message": {"type": "string"},
                            "did_you_mean": {
                                "type": "string",
                                "description": "Present when the field looks like a typo of a declared one.",
                            },
                        },
                    },
                },
                "accepts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "The inputs this flow does declare.",
                },
            },
        },
        "RunRequest": {
            "type": "object",
            "properties": {
                "inputs": {
                    "type": "object",
                    "additionalProperties": True,
                    "description": (
                        "Validated against the published input schema. Read it from "
                        "`/integration/catalog`, or use the per-flow operations in the "
                        "key-authenticated version of this document."
                    ),
                },
                "title": {
                    "type": "string",
                    "maxLength": 200,
                    "description": "What the run is called in the platform's UI. Use your build reference.",
                },
                "environment_id": {"type": "string", "nullable": True},
            },
        },
        "InputsApplied": {
            "type": "object",
            "description": (
                "What the run will actually use, and where each value came from, so "
                "'run it with my data' is verifiable rather than assumed."
            ),
            "additionalProperties": {
                "type": "object",
                "properties": {
                    "value": {},
                    "source": {"type": "string", "enum": ["caller", "flow_default"]},
                },
            },
        },
        "Guardrails": {
            "type": "object",
            "properties": {
                "awaiting_approval": {
                    "type": "array",
                    "description": "Populated when a named person must decide before the run continues.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "approval_id": {"type": "string"},
                            "title": {"type": "string"},
                            "reason": {"type": "string"},
                            "risk_level": {"type": "string"},
                            "required_role": {"type": "string"},
                            "requested_at": {"type": "string", "format": "date-time"},
                            "expires_at": {"type": "string", "format": "date-time"},
                        },
                    },
                },
                "cost": {
                    "type": "object",
                    "properties": {
                        "total_cost_usd": {"type": "number"},
                        "total_tokens": {"type": "integer"},
                    },
                },
                "note": {
                    "type": "string",
                    "nullable": True,
                    "description": "Plain-language explanation when a run is waiting rather than finished.",
                },
            },
        },
        "Run": {
            "type": "object",
            "description": "A run, as a calling system should see it.",
            "properties": {
                "run_id": {"type": "string"},
                "run_number": {"type": "integer"},
                "title": {"type": "string"},
                "kind": {"type": "string", "enum": ["flow", "agent"]},
                "status": {
                    "type": "string",
                    "description": "Internal vocabulary; may gain values. Branch on `disposition` instead.",
                },
                "disposition": {
                    "type": "string",
                    "enum": sorted(set(DISPOSITIONS.values())),
                    "description": (
                        "The field to branch on. `waiting_for_approval` is a normal outcome, "
                        "not a failure, and retrying will not clear it."
                    ),
                },
                "is_terminal": {
                    "type": "boolean",
                    "description": f"True for: {', '.join(sorted(TERMINAL))}. Stop polling.",
                },
                "flow_id": {"type": "string", "nullable": True},
                "correlation_id": {"type": "string"},
                "started_at": {"type": "string", "format": "date-time", "nullable": True},
                "finished_at": {"type": "string", "format": "date-time", "nullable": True},
                "duration_ms": {"type": "integer"},
                "summary": {"type": "string", "nullable": True},
                "error": {"type": "string", "nullable": True},
                "progress": {
                    "type": "object",
                    "properties": {
                        "completed_steps": {"type": "integer"},
                        "total_steps": {"type": "integer"},
                    },
                },
                "guardrails": {"$ref": "#/components/schemas/Guardrails"},
                "outputs": {
                    "type": "object",
                    "additionalProperties": True,
                    "description": "Keyed by the agent that produced each result.",
                },
                "inputs_applied": {"$ref": "#/components/schemas/InputsApplied"},
                "links": {
                    "type": "object",
                    "properties": {
                        "self": {"type": "string"},
                        "cancel": {"type": "string"},
                    },
                },
            },
            "required": ["run_id", "disposition", "is_terminal"],
        },
        "Catalog": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "flows": {"type": "array", "items": {"$ref": "#/components/schemas/CatalogEntry"}},
                "agents": {"type": "array", "items": {"$ref": "#/components/schemas/CatalogEntry"}},
                "counts": {"type": "object", "additionalProperties": {"type": "integer"}},
            },
        },
        "CatalogEntry": {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "name": {"type": "string"},
                "description": {"type": "string", "nullable": True},
                "invoke": {
                    "type": "object",
                    "properties": {
                        "method": {"type": "string"},
                        "path": {"type": "string"},
                        "scope": {"type": "string"},
                    },
                },
                "input_schema": {
                    "type": "object",
                    "additionalProperties": True,
                    "description": "JSON Schema. Validate against it, or build a form from it.",
                },
                "guardrails": {
                    "type": "object",
                    "properties": {
                        "requires_approval": {"type": "boolean"},
                        "risk_level": {"type": "string"},
                        "cost_budget_usd": {"type": "number", "nullable": True},
                    },
                },
            },
        },
        "Manifest": {
            "type": "object",
            "description": "What this platform is, how to authenticate, and what it promises.",
            "properties": {
                "platform": {"type": "object", "additionalProperties": True},
                "client": {"type": "object", "additionalProperties": True},
                "authentication": {"type": "object", "additionalProperties": True},
                "limits": {"type": "object", "additionalProperties": True},
                "guardrails": {
                    "type": "object",
                    "description": "Guarantees, caller obligations and the active policies.",
                    "additionalProperties": True,
                },
                "endpoints": {"type": "object", "additionalProperties": {"type": "string"}},
                "conventions": {"type": "object", "additionalProperties": True},
            },
        },
    }


def _error_responses(*codes: int) -> dict[str, Any]:
    known = {
        400: "Malformed request.",
        401: "The key is missing, unknown, revoked or expired. Every cause reads the same, by design.",
        403: "The key lacks the scope named in `details.required_scope`. Retrying will not help.",
        404: "Not granted, or does not exist — deliberately indistinguishable.",
        409: "Conflicts with the current state of the run.",
        422: "The request or the requested change is not permitted.",
        429: "The per-key rate limit was exceeded; `details.retry_after_seconds` says when to retry.",
    }
    responses: dict[str, Any] = {}
    for code in codes:
        schema = (
            {"$ref": "#/components/schemas/InvalidInputs"}
            if code == 422
            else {"$ref": "#/components/schemas/Error"}
        )
        responses[str(code)] = {
            "description": known.get(code, "Error."),
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/Error"}
                    if code != 422
                    else {
                        "allOf": [
                            {"$ref": "#/components/schemas/Error"},
                            {"type": "object", "properties": {"details": schema}},
                        ]
                    }
                }
            },
        }
    return responses


# ---------------------------------------------------------------------------
# The document
# ---------------------------------------------------------------------------


def build_integration_openapi(
    session: Session | None = None, client: IntegrationClient | None = None
) -> dict[str, Any]:
    """The integration contract, optionally extended with this key's own flows."""
    paths: dict[str, Any] = {
        f"{API}/integration/manifest": {
            "get": {
                "tags": ["Discovery"],
                "summary": "What this platform is, and what it promises",
                "description": (
                    "The first call to make. Names the authentication scheme, the limits, "
                    "every endpoint and the guardrail contract, so the rest of the "
                    "integration can be built without reading source."
                ),
                "operationId": "getManifest",
                "responses": {
                    "200": {
                        "description": "The manifest.",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/Manifest"}
                            }
                        },
                    },
                    **_error_responses(401, 429),
                },
            }
        },
        f"{API}/integration/catalog": {
            "get": {
                "tags": ["Discovery"],
                "summary": "The flows and agents this key may invoke",
                "description": (
                    "Only what this key was granted. Each entry carries the JSON Schema of "
                    "its inputs, so you can validate a payload, build a form or generate a "
                    "client from it."
                ),
                "operationId": "getCatalog",
                "responses": {
                    "200": {
                        "description": "Everything this key may invoke.",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/Catalog"}
                            }
                        },
                    },
                    **_error_responses(401, 403, 429),
                },
            }
        },
        f"{API}/integration/flows/{{flow_id}}/runs": {
            "post": {
                "tags": ["Flows"],
                "summary": "Start a flow",
                "description": (
                    "Returns **202** — the work has been accepted, not finished. Poll "
                    "`links.self` until `is_terminal` is true.\n\n"
                    "Send `X-Idempotency-Key` on every call: a repeat returns **200** with "
                    "`X-Idempotent-Replay: true` and the original run, rather than starting "
                    "a second one."
                ),
                "operationId": "startFlowRun",
                "parameters": [
                    {
                        "name": "flow_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                    },
                    _idempotency_param(),
                ],
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/RunRequest"}
                        }
                    }
                },
                "responses": {
                    "202": _run_response("Accepted; the run has started."),
                    "200": _run_response("Idempotent replay of an earlier request."),
                    **_error_responses(401, 403, 404, 422, 429),
                },
            }
        },
        f"{API}/integration/agents/{{agent_key}}/runs": {
            "post": {
                "tags": ["Agents"],
                "summary": "Invoke a single agent",
                "description": (
                    "The same governance applies as inside a flow: an agent that requires "
                    "approval pauses here too."
                ),
                "operationId": "startAgentRun",
                "parameters": [
                    {
                        "name": "agent_key",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                    }
                ],
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/RunRequest"}
                        }
                    }
                },
                "responses": {
                    "202": _run_response("Accepted; the agent has started."),
                    **_error_responses(401, 403, 404, 422, 429),
                },
            }
        },
        f"{API}/integration/runs/{{run_id}}": {
            "get": {
                "tags": ["Runs"],
                "summary": "Status, guardrail outcome and result of a run",
                "description": (
                    "The endpoint you poll. A key can only read runs **it started**; "
                    "another key's runs and runs a person started return 404."
                ),
                "operationId": "getRun",
                "parameters": [
                    {"name": "run_id", "in": "path", "required": True, "schema": {"type": "string"}}
                ],
                "responses": {
                    "200": _run_response("The run."),
                    **_error_responses(401, 403, 404, 429),
                },
            }
        },
        f"{API}/integration/runs/{{run_id}}/cancel": {
            "post": {
                "tags": ["Runs"],
                "summary": "Cancel a run this key started",
                "operationId": "cancelRun",
                "parameters": [
                    {"name": "run_id", "in": "path", "required": True, "schema": {"type": "string"}}
                ],
                "responses": {
                    "200": _run_response("The cancelled run."),
                    **_error_responses(401, 403, 404, 422, 429),
                },
            }
        },
        f"{API}/mcp": {
            "post": {
                "tags": ["MCP"],
                "summary": "MCP endpoint (JSON-RPC 2.0)",
                "description": (
                    "The same agents and flows, for a caller that is an agent rather than a "
                    "pipeline. Methods: `initialize`, `tools/list`, `tools/call`, `ping`. "
                    "See docs/integration/mcp.md."
                ),
                "operationId": "mcp",
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "properties": {
                                    "jsonrpc": {"type": "string", "enum": ["2.0"]},
                                    "id": {},
                                    "method": {
                                        "type": "string",
                                        "enum": ["initialize", "tools/list", "tools/call", "ping"],
                                    },
                                    "params": {"type": "object", "additionalProperties": True},
                                },
                                "required": ["jsonrpc", "method"],
                            }
                        }
                    }
                },
                "responses": {
                    "200": {
                        "description": (
                            "A JSON-RPC response. A *refused tool* is a successful call whose "
                            "result carries `isError: true`; only a protocol failure returns "
                            "an `error` object."
                        ),
                        "content": {"application/json": {"schema": {"type": "object"}}},
                    },
                    **_error_responses(401, 429),
                },
            }
        },
    }

    if session is not None and client is not None:
        paths.update(_per_capability_paths(session, client))

    return {
        "openapi": "3.1.0",
        "info": {
            "title": f"{settings.app_name} — Integration API",
            "version": settings.app_version,
            "description": _description(client),
            "x-documentation": "docs/integration/README.md",
        },
        "servers": [{"url": "/", "description": "This platform"}],
        "security": [{"ApiKeyAuth": []}],
        # Only tags that have operations. Advertising "Your flows" on the
        # unauthenticated document would render an empty group and imply the
        # key was not working.
        "tags": [
            tag
            for tag in (
                {"name": "Discovery", "description": "What this platform is and what you may call."},
                {"name": "Flows", "description": "Start a flow and watch it."},
                {"name": "Agents", "description": "Invoke a single agent."},
                {"name": "Runs", "description": "Read and cancel runs this key started."},
                {"name": "MCP", "description": "The same capabilities, for agent platforms."},
                {"name": "Your flows", "description": "Your own flows, with their real input schemas."},
                {"name": "Your agents", "description": "Your own agents, with their real input schemas."},
            )
            if tag["name"] in _tags_in_use(paths)
        ],
        "paths": paths,
        "components": {
            "securitySchemes": {
                "ApiKeyAuth": {
                    "type": "apiKey",
                    "in": "header",
                    "name": "X-API-Key",
                    "description": (
                        "An integration key issued by a platform operator. Scopes: "
                        + ", ".join(sorted(SCOPES))
                    ),
                }
            },
            "schemas": _schemas(),
        },
    }


def _tags_in_use(paths: dict[str, Any]) -> set[str]:
    return {
        tag
        for methods in paths.values()
        for operation in methods.values()
        for tag in operation.get("tags", [])
    }


def _idempotency_param() -> dict[str, Any]:
    return {
        "name": "X-Idempotency-Key",
        "in": "header",
        "required": False,
        "schema": {"type": "string"},
        "description": (
            "Send one on every start request. A repeat returns the original run rather "
            "than starting a second. Use a build number, commit SHA or ticket."
        ),
    }


def _run_response(description: str) -> dict[str, Any]:
    return {
        "description": description,
        "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Run"}}},
    }


def _description(client: IntegrationClient | None) -> str:
    base = (
        "The surface other platforms integrate against — deliberately narrow and stable, "
        "separate from the routes the web app uses.\n\n"
        "**Branch on `disposition`, not on `status`.** `waiting_for_approval` is a normal "
        "outcome meaning a named person must decide; it is not a failure and retrying will "
        "not clear it.\n\n"
        "**Inputs are validated.** An input a flow does not declare is rejected rather than "
        "ignored, because ignoring it would mean running on the default and returning a "
        "confident answer about something you did not ask for.\n\n"
        "Self-healing never changes what a test asserts about your application, and never "
        "records a repair as successful without a re-run that proved it. The full contract "
        "is in `docs/integration/guardrails.md`."
    )
    if client is None:
        return (
            base
            + "\n\n---\n\n*Send a valid `X-API-Key` when fetching this document and it will also "
            "describe your own flows and agents, one operation each, with their real input "
            "schemas — which is the version worth generating a client from.*"
        )
    return base + f"\n\n---\n\n*Personalised for **{client.name}**.*"


# ---------------------------------------------------------------------------
# One operation per granted flow and agent
# ---------------------------------------------------------------------------


def _per_capability_paths(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """Each granted flow and agent as its own operation, with its real schema.

    This is what makes a generated client useful: a typed body per flow, rather
    than one generic call taking an untyped dictionary.
    """
    from app.services.integration import build_catalog  # noqa: PLC0415

    catalog = build_catalog(session, client)
    paths: dict[str, Any] = {}

    for entry in catalog.get("flows", []):
        paths[f"{API}/integration/flows/{entry['id']}/runs"] = {
            "post": _capability_operation(
                tag="Your flows",
                summary=entry["name"],
                description=entry.get("description") or entry["name"],
                operation_id=f"runFlow_{_identifier(entry['name'])}",
                input_schema=entry["input_schema"],
                guardrails=entry.get("guardrails") or {},
            )
        }

    for entry in catalog.get("agents", []):
        paths[f"{API}/integration/agents/{entry['key']}/runs"] = {
            "post": _capability_operation(
                tag="Your agents",
                summary=entry["name"],
                description=entry.get("description") or entry["name"],
                operation_id=f"runAgent_{_identifier(entry['key'])}",
                input_schema=entry.get("input_schema") or {"type": "object"},
                guardrails=entry.get("guardrails") or {},
            )
        }

    return paths


def _capability_operation(
    *,
    tag: str,
    summary: str,
    description: str,
    operation_id: str,
    input_schema: dict[str, Any],
    guardrails: dict[str, Any],
) -> dict[str, Any]:
    notes = description
    if guardrails.get("requires_approval"):
        notes += (
            "\n\n**This one pauses for approval.** Expect `waiting_for_approval`, and treat "
            "it as a hold rather than a failure."
        )
    return {
        "tags": [tag],
        "summary": summary,
        "description": notes,
        "operationId": operation_id,
        "parameters": [_idempotency_param()],
        "requestBody": {
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "properties": {
                            "inputs": input_schema,
                            "title": {"type": "string", "maxLength": 200},
                            "environment_id": {"type": "string", "nullable": True},
                        },
                    }
                }
            }
        },
        "responses": {
            "202": _run_response("Accepted; the run has started."),
            "200": _run_response("Idempotent replay of an earlier request."),
            **_error_responses(401, 403, 404, 422, 429),
        },
    }


def _identifier(text: str) -> str:
    cleaned = "".join(part.capitalize() for part in "".join(
        character if character.isalnum() else " " for character in text
    ).split())
    return cleaned[:48] or "Capability"
