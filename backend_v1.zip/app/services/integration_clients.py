"""Issuing and revoking the keys other platforms authenticate with.

The token is generated here, hashed, and returned to the caller exactly once.
Nothing stores or can recover the plain value afterwards, so a lost key is
rotated rather than looked up.
"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta

from sqlalchemy.orm import Session

from app.core.errors import ValidationError
from app.core.security import hash_api_token
from app.governance.policy_engine import AuditService
from app.models.integration import DEFAULT_SCOPES, SCOPES, IntegrationClient

TOKEN_PREFIX = "qei_"  # "QE integration", so a leaked key is recognisable in logs


def issue_client(
    session: Session,
    *,
    project_id: str,
    name: str,
    actor: str,
    description: str | None = None,
    platform: str | None = None,
    scopes: list[str] | None = None,
    allowed_flow_ids: list[str] | None = None,
    allowed_agent_keys: list[str] | None = None,
    rate_limit_per_minute: int = 60,
    callback_url: str | None = None,
    expires_in_days: int | None = None,
) -> tuple[IntegrationClient, str]:
    """Create a client and its token. The token is returned once, here."""
    # `None` means "no preference, use the defaults". An explicit empty list is
    # a different request, and a mistake -- it must not quietly become four
    # scopes the caller never asked for.
    granted = list(DEFAULT_SCOPES) if scopes is None else list(scopes)
    unknown = [scope for scope in granted if scope not in SCOPES]
    if unknown:
        raise ValidationError(
            "Unknown scope requested.",
            details={"unknown_scopes": unknown, "available_scopes": sorted(SCOPES)},
        )
    if not granted:
        raise ValidationError("A client with no scopes could not do anything; grant at least one.")

    token = TOKEN_PREFIX + secrets.token_urlsafe(24)
    client = IntegrationClient(
        project_id=project_id,
        name=name,
        description=description,
        platform=platform,
        token_hash=hash_api_token(token),
        token_hint=token[-4:],
        scopes=granted,
        allowed_flow_ids=list(allowed_flow_ids or []),
        allowed_agent_keys=list(allowed_agent_keys or []),
        rate_limit_per_minute=rate_limit_per_minute,
        callback_url=callback_url,
        expires_at=(
            datetime.now(UTC) + timedelta(days=expires_in_days) if expires_in_days else None
        ),
    )
    session.add(client)
    session.flush()

    AuditService(session).record(
        action="integration.client.create",
        entity_type="integration_client",
        entity_id=client.id,
        entity_label=name,
        actor=actor,
        actor_type="user",
        project_id=project_id,
        severity="warning",
        reason=f"API key issued to '{platform or name}'. The token was shown once and is not recoverable.",
        output_summary={
            "scopes": granted,
            "flows": len(client.allowed_flow_ids),
            "agents": len(client.allowed_agent_keys),
        },
    )
    return client, token


def rotate_token(session: Session, client: IntegrationClient, actor: str) -> str:
    """Replace the token. The previous one stops working immediately."""
    token = TOKEN_PREFIX + secrets.token_urlsafe(24)
    client.token_hash = hash_api_token(token)
    client.token_hint = token[-4:]
    session.flush()

    AuditService(session).record(
        action="integration.client.rotate",
        entity_type="integration_client",
        entity_id=client.id,
        entity_label=client.name,
        actor=actor,
        actor_type="user",
        project_id=client.project_id,
        severity="warning",
        reason="API key rotated; the previous token no longer works.",
    )
    return token


def revoke_client(session: Session, client: IntegrationClient, actor: str) -> None:
    client.is_active = False
    session.flush()
    AuditService(session).record(
        action="integration.client.revoke",
        entity_type="integration_client",
        entity_id=client.id,
        entity_label=client.name,
        actor=actor,
        actor_type="user",
        project_id=client.project_id,
        severity="warning",
        reason="API key revoked; every call with this token is now refused.",
    )
