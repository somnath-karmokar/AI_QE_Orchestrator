"""What another platform needs to know to use this one safely.

Three things, and the third is the one that matters:

  * a **manifest** -- what this platform is, how to authenticate, what the
    limits are, and where the contract is written down;
  * a **catalog** -- the flows and agents this particular key may invoke, each
    with the JSON Schema of what it takes and returns;
  * a **guardrail block** -- attached to every run response, saying what the
    governance layer decided, what it refused, what is waiting on a human, and
    what it cost.

The guardrail block exists because an integration that only reports success or
failure is not safe to build on. A caller has to be able to tell "this finished"
from "this is waiting for a person to approve it" from "policy refused this",
and to act differently in each case, without parsing prose.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest, GovernancePolicy
from app.models.integration import SCOPES, IntegrationClient
from app.models.run import AgentRun

# A run's status, in terms a calling system can branch on without knowing this
# platform's vocabulary.
DISPOSITIONS: dict[str, str] = {
    "queued": "pending",
    "running": "pending",
    "paused": "waiting_for_approval",
    "awaiting_approval": "waiting_for_approval",
    "succeeded": "succeeded",
    "completed": "succeeded",
    "failed": "failed",
    "cancelled": "cancelled",
    "aborted": "cancelled",
    "blocked": "refused",
}

TERMINAL = {"succeeded", "failed", "cancelled", "refused"}


def disposition(status: str | None) -> str:
    """Map an internal status onto the small set a caller should branch on."""
    return DISPOSITIONS.get((status or "").lower(), "pending")


# ---------------------------------------------------------------------------
# Manifest
# ---------------------------------------------------------------------------


def build_manifest(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """Everything a calling platform needs before its first real request."""
    policies = list(
        session.execute(
            select(GovernancePolicy).where(GovernancePolicy.is_enabled.is_(True))
        )
        .scalars()
        .all()
    )
    project_policies = [
        policy for policy in policies if policy.project_id in (None, client.project_id)
    ]

    return {
        "platform": {
            "name": settings.app_name,
            "version": settings.app_version,
            "api_version": "v1",
            "base_path": f"{settings.api_prefix}/integration",
        },
        "client": {
            "name": client.name,
            "project_id": client.project_id,
            "platform": client.platform,
            "token_hint": client.token_hint,
            "expires_at": client.expires_at.isoformat() if client.expires_at else None,
        },
        "authentication": {
            "scheme": "api_key",
            "header": "X-API-Key",
            "scopes_granted": client.scopes or [],
            "scopes_available": SCOPES,
        },
        "limits": {
            "rate_limit_per_minute": client.rate_limit_per_minute,
            "flows_available": len(client.allowed_flow_ids or []),
            "agents_available": len(client.allowed_agent_keys or []),
        },
        "guardrails": guardrail_contract(project_policies),
        "endpoints": {
            "manifest": "GET /integration/manifest",
            "catalog": "GET /integration/catalog",
            "start_flow": "POST /integration/flows/{flow_id}/runs",
            "invoke_agent": "POST /integration/agents/{agent_key}/runs",
            "run_status": "GET /integration/runs/{run_id}",
            "cancel_run": "POST /integration/runs/{run_id}/cancel",
            # The same agents and flows, for a caller that is an agent rather
            # than a pipeline. Advertised here so nobody has to be told.
            "mcp": "POST /mcp",
        },
        "conventions": {
            "run_dispositions": sorted(set(DISPOSITIONS.values())),
            "terminal_dispositions": sorted(TERMINAL),
            "correlation_header": "X-Correlation-ID",
            "idempotency_header": "X-Idempotency-Key",
            "protocols": {
                "rest": "v1",
                # Model Context Protocol, for agent platforms. Same scopes,
                # same governance, same run envelope.
                "mcp": "2024-11-05",
            },
            # Stated rather than implied: a caller that assumed callbacks worked
            # would wait for a message that never arrives.
            "result_delivery": {
                "poll": "GET /integration/runs/{run_id}",
                "callbacks": "not_available",
                "detail": (
                    "Outbound callbacks are not delivered yet. A key may carry a callback_url "
                    "for forward compatibility, but nothing is sent to it -- poll instead."
                ),
            },
            "error_shape": {
                "error": {"code": "string", "message": "string", "details": {}, "correlation_id": "string"}
            },
        },
        "documentation": "docs/integration/README.md",
    }


def guardrail_contract(policies: list[GovernancePolicy]) -> dict[str, Any]:
    """The promises this platform makes to anything calling it.

    These are not descriptions of intent -- each one is enforced in code and has
    a test. They are stated here so an integrator can design around them rather
    than discover them.
    """
    return {
        "guarantees": [
            {
                "id": "human_approval_for_high_risk",
                "statement": (
                    "An action whose risk level requires approval pauses and waits for a named "
                    "person. The run reports 'waiting_for_approval'; it does not proceed and it "
                    "does not fail."
                ),
                "enforced_by": "app/governance/policy_engine.py",
            },
            {
                "id": "business_assertions_never_changed",
                "statement": (
                    "Self-healing repairs how a test finds and drives the application. It never "
                    "changes an assertion, a business rule or test logic, at any confidence, for "
                    "any caller."
                ),
                "enforced_by": "app/healing/policy.py",
            },
            {
                "id": "no_unvalidated_repair",
                "statement": (
                    "A repair is only applied after a re-run proves it. A failed re-run leaves the "
                    "test exactly as it was."
                ),
                "enforced_by": "app/healing/validation.py",
            },
            {
                "id": "everything_is_audited",
                "statement": (
                    "Every invocation, decision and refusal is written to an append-only audit log "
                    "with the caller, the inputs, the policy result and the outcome."
                ),
                "enforced_by": "app/governance/policy_engine.py",
            },
            {
                "id": "budgets_are_enforced",
                "statement": (
                    "Project, flow and agent budgets are checked before spending. Exceeding one "
                    "stops the run rather than continuing at cost."
                ),
                "enforced_by": "app/ai/cost/tracker.py",
            },
            {
                "id": "scopes_are_explicit",
                "statement": (
                    "A key may only invoke what it was explicitly granted. There is no wildcard "
                    "grant, and an ungranted flow is indistinguishable from one that does not exist."
                ),
                "enforced_by": "app/api/integration_auth.py",
            },
        ],
        "caller_obligations": [
            "Treat 'waiting_for_approval' as a normal outcome, not an error; a human decides next.",
            "Do not retry a run that is pending -- poll it. Callbacks are not delivered yet.",
            "Send X-Idempotency-Key on start requests so a network retry does not start a second run.",
            "Do not send secrets in inputs; reference them by name and hold them in your own vault.",
        ],
        "active_policies": [
            {
                "key": policy.key,
                "name": policy.name,
                "type": policy.policy_type,
                "effect": policy.effect,
                "severity": policy.severity,
            }
            for policy in policies
        ],
    }


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


def build_catalog(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """The flows and agents this key may invoke, with their contracts."""
    from app.agents.registry import builtin_catalog  # noqa: PLC0415

    flows = []
    if client.has_scope("catalog:read") and client.allowed_flow_ids:
        rows = list(
            session.execute(
                select(AgentFlow).where(
                    AgentFlow.id.in_(client.allowed_flow_ids),
                    AgentFlow.project_id == client.project_id,
                    AgentFlow.is_deleted.is_(False),
                )
            )
            .scalars()
            .all()
        )
        flows = [_flow_descriptor(flow) for flow in rows]

    agents = []
    if client.has_scope("catalog:read") and client.allowed_agent_keys:
        allowed = set(client.allowed_agent_keys)
        agents = [
            _agent_descriptor(entry)
            for entry in builtin_catalog()
            if entry.get("key") in allowed
        ]

    return {
        "project_id": client.project_id,
        "flows": flows,
        "agents": agents,
        "counts": {"flows": len(flows), "agents": len(agents)},
    }


def _flow_descriptor(flow: AgentFlow) -> dict[str, Any]:
    """A flow as something another system can call, not as a diagram."""
    variables = flow.variables or {}
    return {
        "id": flow.id,
        "name": flow.name,
        "description": flow.description,
        "category": flow.category,
        "version": flow.version,
        "status": flow.status,
        "owner": flow.owner,
        "invoke": {
            "method": "POST",
            "path": f"/integration/flows/{flow.id}/runs",
            "scope": "flows:run",
        },
        # A flow's variables are its inputs; publishing them as a schema means a
        # caller can validate before sending rather than after failing.
        "input_schema": {
            "type": "object",
            "properties": {
                name: {
                    "type": _json_type(value),
                    "default": value,
                    "description": f"Flow variable '{name}'.",
                }
                for name, value in variables.items()
            },
            # False, and enforced: an input the flow does not declare is
            # refused rather than ignored, because ignoring it would run on the
            # default and return a confident answer about the wrong thing.
            "additionalProperties": False,
        },
        "guardrails": {
            "requires_approval": _flow_has_approval(flow),
            "risk_level": (flow.governance or {}).get("risk_level", "medium"),
            "cost_budget_usd": (flow.governance or {}).get("cost_budget_usd"),
        },
    }


def _agent_descriptor(entry: dict[str, Any]) -> dict[str, Any]:
    return {
        "key": entry.get("key"),
        "name": entry.get("name"),
        "description": entry.get("description"),
        "category": entry.get("category"),
        "invoke": {
            "method": "POST",
            "path": f"/integration/agents/{entry.get('key')}/runs",
            "scope": "agents:run",
        },
        "input_schema": entry.get("input_schema") or {"type": "object", "properties": {}},
        "output_schema": entry.get("output_schema") or {},
        "guardrails": {
            "requires_approval": bool(entry.get("requires_approval")),
            "risk_level": entry.get("risk_level", "medium"),
            "cost_tier": entry.get("cost_tier"),
        },
    }


def _flow_has_approval(flow: AgentFlow) -> bool:
    return any((node.node_type or "") == "approval" for node in (flow.nodes or []))


def _json_type(value: Any) -> str:  # noqa: ANN401
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "string"


# ---------------------------------------------------------------------------
# Run representation
# ---------------------------------------------------------------------------


def run_envelope(session: Session, run: AgentRun, *, include_outputs: bool = True) -> dict[str, Any]:
    """A run as a calling system should see it.

    Deliberately flat and stable: disposition, guardrails, outputs. The internal
    step graph is not part of this contract and may change without notice.
    """
    pending = list(
        session.execute(
            select(ApprovalRequest).where(
                ApprovalRequest.run_id == run.id, ApprovalRequest.status == "pending"
            )
        )
        .scalars()
        .all()
    )

    state = disposition(run.status)
    if pending and state == "pending":
        state = "waiting_for_approval"

    envelope: dict[str, Any] = {
        "run_id": run.id,
        "run_number": run.run_number,
        "title": run.title,
        "kind": run.kind,
        "status": run.status,
        "disposition": state,
        "is_terminal": state in TERMINAL,
        "flow_id": run.flow_id,
        "correlation_id": run.correlation_id,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "duration_ms": run.duration_ms,
        "summary": run.summary,
        "error": run.error,
        "progress": {
            "completed_steps": run.completed_step_count,
            "total_steps": run.step_count,
        },
        "guardrails": {
            "awaiting_approval": [
                {
                    "approval_id": approval.id,
                    "title": approval.title,
                    "reason": approval.reason,
                    "risk_level": approval.risk_level,
                    "required_role": approval.required_role,
                    "requested_at": approval.created_at.isoformat() if approval.created_at else None,
                    "expires_at": approval.expires_at.isoformat() if approval.expires_at else None,
                }
                for approval in pending
            ],
            "cost": {
                "total_cost_usd": round(run.total_cost_usd, 6),
                "total_tokens": run.total_tokens,
            },
            # Said plainly, because a caller must not mistake a pause for a finish.
            "note": (
                "This run is waiting for a named person to approve it. It has not failed, and it "
                "will continue once a decision is recorded."
                if state == "waiting_for_approval"
                else None
            ),
        },
        "links": {
            "self": f"{settings.api_prefix}/integration/runs/{run.id}",
            "cancel": f"{settings.api_prefix}/integration/runs/{run.id}/cancel",
        },
    }
    if include_outputs:
        envelope["outputs"] = run.outputs or {}
    return envelope
