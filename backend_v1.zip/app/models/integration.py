"""Credentials for other platforms calling in.

A flow's own `X-Flow-Token` starts exactly one flow and can do nothing else,
which is right for a pipeline step but too narrow for a platform that wants to
discover what is available, invoke an agent, and read the result back.

An `IntegrationClient` is that broader credential: one token, an explicit list of
scopes, and an explicit list of what it may invoke. Nothing is implied -- a
client that was never granted an agent cannot run it, and a client with no
`runs:read` scope cannot read results even for runs it started.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import (
    UTCDateTime,
    Base,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)

# What a token may do. Granted explicitly; there is no "all".
SCOPES: dict[str, str] = {
    "catalog:read": "Discover the agents and flows this client may invoke, with their schemas.",
    "flows:run": "Start a flow run.",
    "agents:run": "Invoke a single agent.",
    "runs:read": "Read the status, result and guardrail outcome of a run.",
    "runs:cancel": "Cancel a run this client started.",
    "approvals:read": "See approvals that are blocking this client's runs.",
}

# A sensible default for a CI pipeline: start work, watch it, read the result.
DEFAULT_SCOPES = ("catalog:read", "flows:run", "runs:read", "approvals:read")


class IntegrationClient(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    """An external system authorised to call this platform."""

    __tablename__ = "integration_clients"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    # The system on the other end, for the audit trail: "jenkins", "azure-devops".
    platform: Mapped[str | None] = mapped_column(String(80), nullable=True)

    # Only the keyed hash is stored; the token itself is shown once, at creation.
    token_hash: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    token_hint: Mapped[str] = mapped_column(String(12), nullable=False)

    scopes: Mapped[list] = mapped_column(JSONType, default=list)
    # Empty means "none of them", never "all of them".
    allowed_flow_ids: Mapped[list] = mapped_column(JSONType, default=list)
    allowed_agent_keys: Mapped[list] = mapped_column(JSONType, default=list)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    # A ceiling the caller can see in the manifest, so it can pace itself.
    rate_limit_per_minute: Mapped[int] = mapped_column(Integer, default=60, nullable=False)

    # Reserved. Nothing delivers callbacks yet, so a caller must poll. The field
    # is here so keys issued now do not need reissuing later; the manifest
    # reports it as unavailable rather than letting an integrator assume it works.
    callback_url: Mapped[str | None] = mapped_column(String(600), nullable=True)

    last_used_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    call_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    def has_scope(self, scope: str) -> bool:
        return scope in (self.scopes or [])

    def may_run_flow(self, flow_id: str) -> bool:
        return self.has_scope("flows:run") and flow_id in (self.allowed_flow_ids or [])

    def may_run_agent(self, agent_key: str) -> bool:
        return self.has_scope("agents:run") and agent_key in (self.allowed_agent_keys or [])
