"""Agent registry.

Built-in agents register their implementation class here. Custom agents created
through the UI have no class of their own -- they run on `ConfigurableAgent`,
which is driven entirely by its database row. That is what lets a user add an
agent without a code change (spec sections 4 and 7).
"""

from __future__ import annotations

from typing import Any

from app.agents.base import AgentContext, BaseAgent
from app.agents.implementations.automation import (
    AccessibilityTestAgent,
    AutomatedTestExecutionAgent,
    AutomationFailureAnalysisAgent,
    AutoScriptGeneratorAgent,
    PerformanceTestScriptGeneratorAgent,
    RegressionSuiteOptimizationAgent,
    SelfHealingAgent,
)
from app.agents.implementations.business import JiraDefectAssistantAgent, UATAssistantAgent
from app.agents.implementations.quality import (
    AutomatedDefectRCAAgent,
    AutomatedRCAAgent,
    DefectPredictionAgent,
    DuplicateTestCaseDetectionAgent,
    ObservabilityAgent,
)
from app.agents.implementations.requirements import (
    TestDesignAgent,
    TestKnowledgeAgent,
    TestPlanningAgent,
    TestScenarioGeneratorAgent,
    TraceabilityCoverageAgent,
    UserStoryCompletenessAgent,
)
from app.agents.implementations.testdata import (
    DBScriptGeneratorAgent,
    TestDataGeneratorAgent,
    TestDataManagementAgent,
)
from app.ai.providers.base import ChatMessage
from app.core.errors import NotFoundError
from app.core.logging import get_logger
from app.models.agent import Agent

logger = get_logger(__name__)

# Catalogue order matches the specification's agent list (spec section 4).
BUILTIN_AGENT_CLASSES: list[type[BaseAgent]] = [
    # Requirement / planning
    UserStoryCompletenessAgent,
    TestPlanningAgent,
    TestDesignAgent,
    TestKnowledgeAgent,
    TestScenarioGeneratorAgent,
    TraceabilityCoverageAgent,
    # Test data
    TestDataGeneratorAgent,
    TestDataManagementAgent,
    DBScriptGeneratorAgent,
    # Automation
    AutoScriptGeneratorAgent,
    SelfHealingAgent,
    AutomatedTestExecutionAgent,
    AutomationFailureAnalysisAgent,
    RegressionSuiteOptimizationAgent,
    PerformanceTestScriptGeneratorAgent,
    AccessibilityTestAgent,
    # Defect / quality intelligence
    DefectPredictionAgent,
    AutomatedRCAAgent,
    AutomatedDefectRCAAgent,
    DuplicateTestCaseDetectionAgent,
    ObservabilityAgent,
    # UAT / business
    UATAssistantAgent,
    JiraDefectAssistantAgent,
]

AGENT_CLASS_BY_KEY: dict[str, type[BaseAgent]] = {
    agent_class.key: agent_class for agent_class in BUILTIN_AGENT_CLASSES
}


class ConfigurableAgent(BaseAgent):
    """Runs a user-defined agent purely from its database row.

    A custom agent has instructions, schemas, tools and a model policy but no
    bespoke Python. It retrieves context from the Knowledge Fabric, calls the
    tools it declares, and returns the standard output contract -- so it is a
    first-class citizen in flows, governance, costing and the run timeline.
    """

    key = "configurable-agent"
    name = "Configurable Agent"
    category = "Governance"
    description = "User-defined agent driven by stored instructions and schema."
    icon = "Sparkles"

    def __init__(self, definition: Agent) -> None:
        super().__init__(definition)
        self.key = definition.key
        self.name = definition.name
        self.category = definition.category
        self.description = definition.description or ""
        self.capability = definition.capability or "generation"
        self.risk_level = definition.risk_level
        self.cost_tier = definition.cost_tier
        self.icon = definition.icon
        self.requires_approval = definition.requires_approval
        self.input_schema = definition.input_schema or {"type": "object", "properties": {}}
        self.output_schema = definition.output_schema or BaseAgent.output_schema
        self.system_instructions = definition.system_instructions or BaseAgent.system_instructions
        self.goal = definition.goal or ""

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        query = " ".join(str(value) for value in inputs.values() if isinstance(value, str))[:400]

        knowledge_block, evidence = ("", [])
        if query:
            knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
                query, project_id=ctx.project_id, limit=5, module=inputs.get("module")
            )

        # Call the read-only tools this agent declares, so its context is real.
        for reference in self.allowed_tool_refs():
            if "." not in reference:
                continue
            server_key, tool_name = reference.split(".", 1)
            definition = None
            try:
                definition = ctx.mcp.adapter(server_key).tool(tool_name)
            except Exception:  # noqa: BLE001 - unavailable server is not fatal
                continue
            if definition is None or definition.mutating:
                continue
            arguments = {
                parameter.name: inputs[parameter.name]
                for parameter in definition.parameters
                if parameter.name in inputs
            }
            missing_required = [
                parameter.name
                for parameter in definition.parameters
                if parameter.required and parameter.name not in arguments
            ]
            if missing_required:
                continue
            self.call_tool(ctx, server_key, tool_name, arguments, tool_calls=tool_calls)

        return {"knowledge": knowledge_block, "evidence": evidence, "tool_calls": tool_calls}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        goal = self.config_value("goal", self.goal)
        return [
            self.system_message(ctx),
            ChatMessage(
                role="user",
                content=(
                    (f"Goal: {goal}\n\n" if goal else "")
                    + self.context_block("inputs", str(inputs))
                    + "\n\n"
                    + self.context_block("retrieved_context", context.get("knowledge") or "none")
                    + "\n\n"
                    + self.context_block("tool_results", str(context.get("tool_calls") or "none"))
                ),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        evidence = context.get("evidence", [])
        tool_calls = context.get("tool_calls", [])
        successful_calls = [call for call in tool_calls if call.get("success")]

        findings: list[dict[str, Any]] = [
            {"source": item.get("title"), "source_type": item.get("source_type"), "relevance": item.get("score")}
            for item in evidence[:6]
        ]
        findings.extend(
            {"tool": f"{call['server']}.{call['tool']}", "status": "succeeded", "duration_ms": call.get("duration_ms")}
            for call in successful_calls
        )

        # Without a model, a custom agent reports what it grounded itself in
        # rather than inventing an answer.
        return {
            "status": "success" if (evidence or successful_calls) else "needs_review",
            "confidence": round(min(0.9, 0.45 + 0.06 * len(evidence) + 0.05 * len(successful_calls)), 3),
            "summary": (
                f"{self.name} gathered {len(evidence)} knowledge item(s) and completed "
                f"{len(successful_calls)} tool call(s) for the supplied inputs."
            ),
            "findings": findings,
            "recommendations": (
                []
                if (evidence or successful_calls)
                else [{"action": "Add knowledge sources or tools so this agent has grounded context to reason over."}]
            ),
            "reasoning_summary": (
                f"Custom agent '{self.name}' executed its configured retrieval and read-only tools. "
                "Connect a production LLM provider for generated analysis."
            ),
            "next_action": self.config_value("next_action") or "report",
            "outputs": {
                "inputs": inputs,
                "evidence_count": len(evidence),
                "tool_call_count": len(tool_calls),
                "context": context.get("knowledge", "")[:2000],
            },
        }


def build_agent(definition: Agent) -> BaseAgent:
    """Instantiate the runtime agent for a stored definition."""
    handler_key = definition.handler_key or definition.key
    agent_class = AGENT_CLASS_BY_KEY.get(handler_key)
    if agent_class is not None:
        return agent_class(definition)
    if definition.is_builtin:
        logger.warning("builtin_agent_class_missing", agent=definition.key, handler=handler_key)
    return ConfigurableAgent(definition)


def builtin_catalog() -> list[dict[str, Any]]:
    """Metadata for seeding `agents` from the built-in classes."""
    catalog: list[dict[str, Any]] = []
    for agent_class in BUILTIN_AGENT_CLASSES:
        catalog.append(
            {
                "key": agent_class.key,
                "name": agent_class.name,
                "category": agent_class.category,
                "description": agent_class.description,
                "summary": agent_class.description[:240],
                "icon": agent_class.icon,
                "capability": agent_class.capability,
                "risk_level": agent_class.risk_level,
                "cost_tier": agent_class.cost_tier,
                "requires_approval": agent_class.requires_approval,
                "supported_tools": list(agent_class.supported_tools),
                "input_schema": agent_class.input_schema,
                "output_schema": agent_class.output_schema,
                "system_instructions": agent_class.system_instructions,
                "goal": agent_class.goal,
                "handler_key": agent_class.key,
            }
        )
    return catalog


def resolve_agent(session, agent_id: str) -> BaseAgent:  # noqa: ANN001
    """Load an agent definition by id and build its runtime instance."""
    definition = session.get(Agent, agent_id)
    if definition is None or definition.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.", details={"agent_id": agent_id})
    return build_agent(definition)
