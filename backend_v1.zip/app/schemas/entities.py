"""Request and response schemas for the platform's domain entities."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.schemas.common import ORMModel

# ---------------------------------------------------------------------------
# Auth / identity
# ---------------------------------------------------------------------------


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1)


class UserOut(ORMModel):
    id: str
    email: str
    full_name: str
    job_title: str | None = None
    avatar_initials: str | None = None
    is_active: bool = True
    role_key: str
    permissions: list[str] = Field(default_factory=list)


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in_minutes: int
    user: UserOut


class DemoUserOut(BaseModel):
    """Shown on the sign-in screen so the demo is self-service."""

    email: str
    full_name: str
    role: str
    role_label: str
    job_title: str


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------


class EnvironmentOut(ORMModel):
    id: str
    key: str
    name: str
    description: str | None = None
    base_url: str | None = None
    api_base_url: str | None = None
    is_production_like: bool
    allows_write_actions: bool
    health_status: str


class IntegrationOut(ORMModel):
    id: str
    kind: str
    name: str
    description: str | None = None
    connector_mode: str
    status: str
    base_url: str | None = None
    last_sync_at: datetime | None = None
    config: dict[str, Any] = Field(default_factory=dict)


class ProjectSummary(ORMModel):
    id: str
    key: str
    name: str
    description: str | None = None
    status: str
    business_domain: str | None = None
    modules: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)


class ProjectOut(ProjectSummary):
    application_url: str | None = None
    jira_project_key: str | None = None
    confluence_space: str | None = None
    git_repository: str | None = None
    onboarding_step: int = 10
    qe_policies: dict[str, Any] = Field(default_factory=dict)
    execution_config: dict[str, Any] = Field(default_factory=dict)
    llm_config: dict[str, Any] = Field(default_factory=dict)
    cost_budget_usd: float = 0.0
    environments: list[EnvironmentOut] = Field(default_factory=list)
    integrations: list[IntegrationOut] = Field(default_factory=list)
    created_at: datetime | None = None


class ProjectCreate(BaseModel):
    key: str = Field(min_length=2, max_length=40)
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    business_domain: str | None = None
    application_url: str | None = None
    jira_project_key: str | None = None
    confluence_space: str | None = None
    git_repository: str | None = None
    modules: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    cost_budget_usd: float = 50.0


class ProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    status: str | None = None
    business_domain: str | None = None
    application_url: str | None = None
    jira_project_key: str | None = None
    confluence_space: str | None = None
    git_repository: str | None = None
    modules: list[str] | None = None
    tags: list[str] | None = None
    qe_policies: dict[str, Any] | None = None
    execution_config: dict[str, Any] | None = None
    llm_config: dict[str, Any] | None = None
    cost_budget_usd: float | None = None
    onboarding_step: int | None = None


class EnvironmentCreate(BaseModel):
    key: str
    name: str
    description: str | None = None
    base_url: str | None = None
    api_base_url: str | None = None
    database_alias: str | None = None
    is_production_like: bool = False
    allows_write_actions: bool = True


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------


class AgentSummary(ORMModel):
    id: str
    key: str
    name: str
    summary: str | None = None
    description: str | None = None
    category: str
    icon: str
    version: str
    lifecycle_state: str
    risk_level: str
    cost_tier: str
    requires_approval: bool
    is_builtin: bool
    is_published: bool
    supported_tools: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    usage_count: int = 0
    success_rate: float = 0.0
    avg_duration_ms: int = 0
    avg_cost_usd: float = 0.0
    rating: float = 0.0
    project_id: str | None = None


class AgentDetail(AgentSummary):
    goal: str | None = None
    system_instructions: str | None = None
    capability: str
    input_schema: dict[str, Any] = Field(default_factory=dict)
    output_schema: dict[str, Any] = Field(default_factory=dict)
    llm_config: dict[str, Any] = Field(default_factory=dict)
    temperature: float = 0.1
    max_tokens: int = 2500
    token_budget: int = 40000
    cost_budget_usd: float = 2.0
    retry_policy: dict[str, Any] = Field(default_factory=dict)
    timeout_seconds: int = 120
    guardrails: list[str] = Field(default_factory=list)
    mcp_servers: list[str] = Field(default_factory=list)
    handler_key: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class AgentCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    category: str = "Governance"
    icon: str = "Sparkles"
    goal: str | None = None
    system_instructions: str | None = None
    capability: str = "generation"
    risk_level: str = "low"
    cost_tier: str = "low"
    requires_approval: bool = False
    input_schema: dict[str, Any] = Field(default_factory=dict)
    output_schema: dict[str, Any] = Field(default_factory=dict)
    supported_tools: list[str] = Field(default_factory=list)
    mcp_servers: list[str] = Field(default_factory=list)
    llm_config: dict[str, Any] = Field(default_factory=dict)
    temperature: float = 0.1
    max_tokens: int = 2500
    token_budget: int = 40000
    cost_budget_usd: float = 2.0
    retry_policy: dict[str, Any] = Field(default_factory=dict)
    timeout_seconds: int = 120
    guardrails: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    project_id: str | None = None


class AgentUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    category: str | None = None
    icon: str | None = None
    goal: str | None = None
    system_instructions: str | None = None
    capability: str | None = None
    risk_level: str | None = None
    cost_tier: str | None = None
    requires_approval: bool | None = None
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    supported_tools: list[str] | None = None
    mcp_servers: list[str] | None = None
    llm_config: dict[str, Any] | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    token_budget: int | None = None
    cost_budget_usd: float | None = None
    retry_policy: dict[str, Any] | None = None
    timeout_seconds: int | None = None
    guardrails: list[str] | None = None
    tags: list[str] | None = None
    lifecycle_state: str | None = None


class AgentTestRequest(BaseModel):
    project_id: str
    inputs: dict[str, Any] = Field(default_factory=dict)
    environment_id: str | None = None


class AgentPublishRequest(BaseModel):
    version: str | None = None
    change_summary: str | None = None


class AgentVersionOut(ORMModel):
    id: str
    version: str
    lifecycle_state: str
    change_summary: str | None = None
    published_at: datetime | None = None
    published_by: str | None = None
    created_at: datetime | None = None


# ---------------------------------------------------------------------------
# Agent cart
# ---------------------------------------------------------------------------


class CartItemIn(BaseModel):
    agent_id: str
    project_id: str
    sequence: int | None = None
    notes: str | None = None
    config_overrides: dict[str, Any] = Field(default_factory=dict)


class CartItemOut(ORMModel):
    id: str
    agent_id: str
    project_id: str
    sequence: int
    notes: str | None = None
    config_overrides: dict[str, Any] = Field(default_factory=dict)
    agent: AgentSummary | None = None


class CartToFlowRequest(BaseModel):
    project_id: str
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    clear_cart: bool = True


# ---------------------------------------------------------------------------
# Flows
# ---------------------------------------------------------------------------


class FlowNodeIn(BaseModel):
    node_key: str
    node_type: str
    label: str
    agent_id: str | None = None
    agent_version: str | None = None
    position_x: float = 0.0
    position_y: float = 0.0
    sequence: int = 0
    config: dict[str, Any] = Field(default_factory=dict)
    input_mapping: dict[str, Any] = Field(default_factory=dict)
    output_mapping: dict[str, Any] = Field(default_factory=dict)
    condition_expression: str | None = None
    llm_config: dict[str, Any] = Field(default_factory=dict)
    retry_policy: dict[str, Any] = Field(default_factory=dict)
    timeout_seconds: int | None = None
    on_failure: str = "fail_flow"
    requires_approval: bool = False
    approval_role: str | None = None
    cost_limit_usd: float | None = None


class FlowNodeOut(FlowNodeIn, ORMModel):
    id: str


class FlowEdgeIn(BaseModel):
    source_node_key: str
    target_node_key: str
    branch_label: str | None = None
    condition_expression: str | None = None


class FlowEdgeOut(FlowEdgeIn, ORMModel):
    id: str


class FlowSummary(ORMModel):
    id: str
    key: str
    name: str
    description: str | None = None
    category: str
    status: str
    version: str
    is_template: bool
    project_id: str
    tags: list[str] = Field(default_factory=list)
    run_count: int = 0
    last_run_at: datetime | None = None
    cost_budget_usd: float = 0.0
    validation_result: dict[str, Any] = Field(default_factory=dict)
    owner: str | None = None
    trigger_type: str = "manual"
    schedule: dict[str, Any] = Field(default_factory=dict)
    schedule_description: str = "Not scheduled"
    next_run_at: datetime | None = None
    api_trigger_enabled: bool = False
    webhook_token_hint: str | None = None
    governance: dict[str, Any] = Field(default_factory=dict)
    updated_at: datetime | None = None


class FlowDetail(FlowSummary):
    variables: dict[str, Any] = Field(default_factory=dict)
    default_environment_id: str | None = None
    llm_config: dict[str, Any] = Field(default_factory=dict)
    token_budget: int = 0
    nodes: list[FlowNodeOut] = Field(default_factory=list)
    edges: list[FlowEdgeOut] = Field(default_factory=list)
    created_at: datetime | None = None
    created_by: str | None = None


class FlowCreate(BaseModel):
    project_id: str
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    category: str = "Test Engineering"
    variables: dict[str, Any] = Field(default_factory=dict)
    default_environment_id: str | None = None
    cost_budget_usd: float = 5.0
    token_budget: int = 120000
    tags: list[str] = Field(default_factory=list)
    nodes: list[FlowNodeIn] = Field(default_factory=list)
    edges: list[FlowEdgeIn] = Field(default_factory=list)
    owner: str | None = None
    schedule: dict[str, Any] | None = None
    governance: dict[str, Any] | None = None
    # How the flow was started, for the audit trail: blank | composer | template | cart
    source: str = "blank"


class FlowGovernanceSettings(BaseModel):
    run_roles: list[str] = Field(default_factory=list)
    budget_alert_percent: int = Field(default=80, ge=10, le=100)
    notify_on_failure: bool = True
    slo_success_rate: float = Field(default=0.9, ge=0.5, le=1.0)


class FlowSettingsUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=200)
    description: str | None = None
    owner: str | None = None
    tags: list[str] | None = None
    variables: dict[str, Any] | None = None
    default_environment_id: str | None = None
    cost_budget_usd: float | None = Field(default=None, gt=0, le=1000)
    token_budget: int | None = Field(default=None, gt=0)
    schedule: dict[str, Any] | None = None
    governance: FlowGovernanceSettings | None = None


class FlowComposeRequest(BaseModel):
    project_id: str
    description: str = Field(min_length=8, max_length=2000)
    name: str | None = None


class FlowFromTemplateRequest(BaseModel):
    project_id: str
    template_key: str
    name: str | None = Field(default=None, max_length=200)
    description: str | None = None
    variables: dict[str, Any] = Field(default_factory=dict)
    cost_budget_usd: float | None = Field(default=None, gt=0, le=1000)
    owner: str | None = None
    schedule: dict[str, Any] | None = None
    governance: FlowGovernanceSettings | None = None


class FlowApiTokenOut(BaseModel):
    token: str
    hint: str
    endpoint: str
    example: str


class FlowHookRequest(BaseModel):
    inputs: dict[str, Any] = Field(default_factory=dict)
    title: str | None = Field(default=None, max_length=200)


class IntegrationRunRequest(BaseModel):
    """What another platform sends to start work here.

    Kept minimal on purpose: inputs are validated against the invoked flow's or
    agent's own published schema, which the caller can read from the catalog.
    """

    inputs: dict[str, Any] = Field(default_factory=dict)
    title: str | None = Field(default=None, max_length=200)
    environment_id: str | None = None


class IntegrationClientCreate(BaseModel):
    project_id: str
    name: str = Field(min_length=1, max_length=160)
    description: str | None = Field(default=None, max_length=500)
    platform: str | None = Field(default=None, max_length=80)
    # Omit for a sensible default set; an explicit empty list is rejected rather
    # than quietly granting the defaults.
    scopes: list[str] | None = None
    allowed_flow_ids: list[str] = Field(default_factory=list)
    allowed_agent_keys: list[str] = Field(default_factory=list)
    rate_limit_per_minute: int = Field(default=60, ge=1, le=10_000)
    callback_url: str | None = Field(default=None, max_length=600)
    expires_in_days: int | None = Field(default=None, ge=1, le=3650)


class IntegrationClientOut(ORMModel):
    id: str
    project_id: str
    name: str
    description: str | None = None
    platform: str | None = None
    token_hint: str
    scopes: list[str] = Field(default_factory=list)
    allowed_flow_ids: list[str] = Field(default_factory=list)
    allowed_agent_keys: list[str] = Field(default_factory=list)
    is_active: bool = True
    rate_limit_per_minute: int = 60
    callback_url: str | None = None
    expires_at: datetime | None = None
    last_used_at: datetime | None = None
    call_count: int = 0
    created_at: datetime | None = None


class IntegrationClientCreated(IntegrationClientOut):
    """Carries the token itself. Returned once, at creation, and never again."""

    token: str


class FlowUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    category: str | None = None
    status: str | None = None
    variables: dict[str, Any] | None = None
    default_environment_id: str | None = None
    cost_budget_usd: float | None = None
    token_budget: int | None = None
    tags: list[str] | None = None
    nodes: list[FlowNodeIn] | None = None
    edges: list[FlowEdgeIn] | None = None


class FlowRunRequest(BaseModel):
    inputs: dict[str, Any] = Field(default_factory=dict)
    environment_id: str | None = None
    synchronous: bool = False


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------


class RunStepOut(ORMModel):
    id: str
    node_key: str
    node_type: str
    label: str
    sequence: int
    status: str
    agent_id: str | None = None
    agent_key: str | None = None
    attempt: int = 1
    started_at: datetime | None = None
    finished_at: datetime | None = None
    duration_ms: int = 0
    inputs: dict[str, Any] = Field(default_factory=dict)
    output: dict[str, Any] = Field(default_factory=dict)
    reasoning_summary: str | None = None
    evidence: list[Any] = Field(default_factory=list)
    tool_calls: list[Any] = Field(default_factory=list)
    artifacts: list[Any] = Field(default_factory=list)
    confidence: float | None = None
    policy_decision: dict[str, Any] = Field(default_factory=dict)
    provider: str | None = None
    model: str | None = None
    deployment: str | None = None
    total_tokens: int = 0
    cost_usd: float = 0.0
    error: str | None = None


class RunSummary(ORMModel):
    id: str
    project_id: str
    flow_id: str | None = None
    agent_id: str | None = None
    run_number: int
    title: str
    kind: str
    status: str
    trigger: str
    started_at: datetime | None = None
    finished_at: datetime | None = None
    duration_ms: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    step_count: int = 0
    completed_step_count: int = 0
    summary: str | None = None
    triggered_by: str | None = None
    created_at: datetime | None = None


class RunDetail(RunSummary):
    correlation_id: str
    flow_version: str | None = None
    environment_id: str | None = None
    inputs: dict[str, Any] = Field(default_factory=dict)
    outputs: dict[str, Any] = Field(default_factory=dict)
    variables: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    steps: list[RunStepOut] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Test engineering
# ---------------------------------------------------------------------------


class RequirementOut(ORMModel):
    id: str
    external_key: str
    title: str
    description: str | None = None
    module: str
    status: str
    priority: str
    epic: str | None = None
    sprint: str | None = None
    story_points: int | None = None
    acceptance_criteria: list[Any] = Field(default_factory=list)
    labels: list[Any] = Field(default_factory=list)
    risk_score: float = 0.0
    change_frequency: int = 0
    completeness_score: float | None = None
    completeness_findings: list[Any] = Field(default_factory=list)
    last_analyzed_at: datetime | None = None


class ScenarioOut(ORMModel):
    id: str
    key: str
    title: str
    description: str | None = None
    scenario_type: str
    module: str
    priority: str
    risk_level: str
    requirement_id: str | None = None
    generated_by_agent: str | None = None
    confidence: float | None = None


class TestCaseOut(ORMModel):
    id: str
    key: str
    title: str
    objective: str | None = None
    module: str
    test_type: str
    priority: str
    preconditions: list[Any] = Field(default_factory=list)
    steps: list[Any] = Field(default_factory=list)
    expected_result: str | None = None
    is_automated: bool = False
    automation_status: str
    scenario_id: str | None = None
    requirement_id: str | None = None
    duplicate_of_id: str | None = None
    duplicate_similarity: float | None = None
    last_result: str | None = None
    last_executed_at: datetime | None = None
    execution_count: int = 0
    failure_count: int = 0
    flakiness_score: float = 0.0
    avg_duration_ms: int = 0


class TestScriptOut(ORMModel):
    id: str
    name: str
    framework: str
    language: str
    file_path: str
    code: str
    page_objects: list[Any] = Field(default_factory=list)
    locators: list[Any] = Field(default_factory=list)
    version: int = 1
    status: str
    test_case_id: str | None = None
    generated_by_agent: str | None = None
    healing_count: int = 0
    quality_notes: list[Any] = Field(default_factory=list)


class TestDataSetOut(ORMModel):
    id: str
    name: str
    description: str | None = None
    module: str
    data_type: str
    record_count: int
    contains_pii: bool
    masking_applied: bool
    schema_definition: dict[str, Any] = Field(default_factory=dict)
    records: list[Any] = Field(default_factory=list)
    sql_scripts: list[Any] = Field(default_factory=list)
    generated_by_agent: str | None = None
    updated_at: datetime | None = None


# ---------------------------------------------------------------------------
# Executions
# ---------------------------------------------------------------------------


class ExecutionTestOut(ORMModel):
    id: str
    name: str
    module: str
    result: str
    duration_ms: int = 0
    retry_count: int = 0
    failure_message: str | None = None
    failure_category: str | None = None
    failure_signature: str | None = None
    stack_trace: str | None = None
    console_logs: list[Any] = Field(default_factory=list)
    network_logs: list[Any] = Field(default_factory=list)
    healed: bool = False
    test_case_id: str | None = None
    test_script_id: str | None = None


class ExecutionSummary(ORMModel):
    id: str
    name: str
    execution_number: int
    suite_type: str
    status: str
    browser: str
    mode: str
    project_id: str
    environment_id: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    duration_ms: int = 0
    total_tests: int = 0
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    flaky: int = 0
    healed: int = 0
    pass_rate: float = 0.0
    failure_categories: dict[str, Any] = Field(default_factory=dict)
    defects_created: int = 0
    triggered_by: str | None = None
    created_at: datetime | None = None


class ExecutionDetail(ExecutionSummary):
    parallelism: int = 1
    headless: bool = True
    trigger: str = "manual"
    config: dict[str, Any] = Field(default_factory=dict)
    ai_findings: list[Any] = Field(default_factory=list)
    tests: list[ExecutionTestOut] = Field(default_factory=list)


class ExecutionCreate(BaseModel):
    project_id: str
    name: str | None = None
    suite_type: str = "regression"
    environment_id: str | None = None
    browser: str = "chromium"
    headless: bool = True
    parallelism: int = 2
    module: str | None = None
    test_case_ids: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Defects / RCA
# ---------------------------------------------------------------------------


class DefectOut(ORMModel):
    id: str
    external_key: str | None = None
    title: str
    description: str | None = None
    module: str
    status: str
    severity: str
    priority: str
    source: str
    is_ai_suggested: bool = False
    ai_confidence: float | None = None
    cluster_key: str | None = None
    duplicate_of_id: str | None = None
    failure_signature: str | None = None
    steps_to_reproduce: list[Any] = Field(default_factory=list)
    evidence: list[Any] = Field(default_factory=list)
    labels: list[Any] = Field(default_factory=list)
    assigned_to: str | None = None
    reported_by: str | None = None
    execution_id: str | None = None
    test_case_id: str | None = None
    requirement_id: str | None = None
    resolved_at: datetime | None = None
    resolution_notes: str | None = None
    jira_sync_state: str = "not_synced"
    created_at: datetime | None = None


class RCAOut(ORMModel):
    id: str
    title: str
    probable_root_cause: str
    category: str
    confidence: float
    status: str
    evidence: list[Any] = Field(default_factory=list)
    contributing_factors: list[Any] = Field(default_factory=list)
    affected_tests: list[Any] = Field(default_factory=list)
    historical_similarity: list[Any] = Field(default_factory=list)
    related_code_changes: list[Any] = Field(default_factory=list)
    recommended_action: str | None = None
    defect_id: str | None = None
    execution_id: str | None = None
    agent_key: str | None = None
    reviewed_by: str | None = None
    created_at: datetime | None = None


class RCADecision(BaseModel):
    decision: str = Field(pattern="^(accept|reject)$")
    notes: str | None = None


class DefectAnalyzeRequest(BaseModel):
    project_id: str
    defect_id: str | None = None
    execution_id: str | None = None
    execution_test_id: str | None = None
    synchronous: bool = True


class HealingRecordOut(ORMModel):
    id: str
    status: str
    failure_class: str
    change_type: str = "locator"
    original_locator: str
    proposed_locator: str
    locator_strategy: str
    candidates: list[Any] = Field(default_factory=list)
    reason: str
    confidence: float
    confidence_breakdown: list[Any] = Field(default_factory=list)
    evidence: list[Any] = Field(default_factory=list)
    policy_decision: dict[str, Any] = Field(default_factory=dict)
    patch: dict[str, Any] = Field(default_factory=dict)
    result_before: str | None = None
    result_after: str | None = None
    validation_status: str = "not_started"
    validation_mode: str | None = None
    validation_evidence: list[Any] = Field(default_factory=list)
    validation_execution_id: str | None = None
    validated_at: datetime | None = None
    attempt_count: int = 0
    rolled_back_at: datetime | None = None
    approval_request_id: str | None = None
    approver: str | None = None
    approved_at: datetime | None = None
    script_version_before: int | None = None
    script_version_after: int | None = None
    test_script_id: str | None = None
    created_at: datetime | None = None

    @field_validator("confidence_breakdown", "evidence", "validation_evidence", "candidates", mode="before")
    @classmethod
    def _empty_list(cls, value: object) -> object:
        # A JSON column added by a migration is NULL on rows that predate it.
        return [] if value is None else value

    @field_validator("policy_decision", "patch", mode="before")
    @classmethod
    def _empty_dict(cls, value: object) -> object:
        return {} if value is None else value


class DefectPredictionOut(ORMModel):
    id: str
    target_ref: str
    module: str
    probability: float
    predicted_severity: str
    risk_band: str
    drivers: list[Any] = Field(default_factory=list)
    recommended_actions: list[Any] = Field(default_factory=list)
    horizon_days: int
    created_at: datetime | None = None


class RegressionAnalysisOut(ORMModel):
    id: str
    name: str
    changed_modules: list[Any] = Field(default_factory=list)
    changed_requirements: list[Any] = Field(default_factory=list)
    selected_tests: list[Any] = Field(default_factory=list)
    skipped_tests: list[Any] = Field(default_factory=list)
    risk_score: float
    baseline_duration_ms: int
    optimized_duration_ms: int
    reduction_percent: float
    rationale: str | None = None
    created_at: datetime | None = None


# ---------------------------------------------------------------------------
# Knowledge
# ---------------------------------------------------------------------------


class KnowledgeSourceOut(ORMModel):
    id: str
    key: str
    name: str
    description: str | None = None
    source_type: str
    connector_mode: str
    sync_status: str
    sync_schedule: str
    is_enabled: bool
    last_synced_at: datetime | None = None
    document_count: int = 0
    chunk_count: int = 0
    collection_name: str


class KnowledgeDocumentOut(ORMModel):
    id: str
    external_id: str
    title: str
    source_type: str
    artifact_type: str
    module: str
    version: int
    url: str | None = None
    author: str | None = None
    index_status: str
    indexed_at: datetime | None = None
    chunk_count: int = 0
    tags: list[Any] = Field(default_factory=list)


class KnowledgeSearchRequest(BaseModel):
    query: str = Field(min_length=1)
    collection: str = "qe_knowledge"
    limit: int = Field(default=8, ge=1, le=50)
    module: str | None = None


class KnowledgeSearchHit(BaseModel):
    id: str
    content: str
    score: float
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Governance
# ---------------------------------------------------------------------------


class PolicyOut(ORMModel):
    id: str
    key: str
    name: str
    description: str | None = None
    policy_type: str
    effect: str
    scope: str
    conditions: dict[str, Any] = Field(default_factory=dict)
    parameters: dict[str, Any] = Field(default_factory=dict)
    severity: str
    is_enabled: bool
    priority: int
    enforcement_count: int = 0
    last_enforced_at: datetime | None = None
    project_id: str | None = None


class PolicyUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    effect: str | None = None
    conditions: dict[str, Any] | None = None
    parameters: dict[str, Any] | None = None
    severity: str | None = None
    is_enabled: bool | None = None
    priority: int | None = None


class ApprovalOut(ORMModel):
    id: str
    title: str
    reason: str
    risk_level: str
    status: str
    required_role: str
    subject_type: str
    subject_ref: str | None = None
    requested_by: str | None = None
    decided_by: str | None = None
    decided_at: datetime | None = None
    decision_notes: str | None = None
    expires_at: datetime | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    proposed_action: dict[str, Any] = Field(default_factory=dict)
    run_id: str | None = None
    project_id: str
    created_at: datetime | None = None


class ApprovalDecision(BaseModel):
    decision: str = Field(pattern="^(approve|reject)$")
    notes: str | None = None
    resume_run: bool = True


class AuditLogOut(ORMModel):
    id: str
    actor: str
    actor_type: str
    action: str
    entity_type: str
    entity_id: str | None = None
    entity_label: str | None = None
    reason: str | None = None
    outcome: str
    severity: str
    tool_used: str | None = None
    model_used: str | None = None
    confidence: float | None = None
    policy_result: dict[str, Any] = Field(default_factory=dict)
    correlation_id: str | None = None
    run_id: str | None = None
    created_at: datetime | None = None


class ChangeImpactRequest(BaseModel):
    """What changed, in whatever terms the caller has.

    All three are optional: a pipeline may know the changed files' components,
    a release note may only know the modules.
    """

    changed_components: list[str] = Field(default_factory=list)
    changed_modules: list[str] = Field(default_factory=list)
    changed_endpoints: list[str] = Field(default_factory=list)
