"""Evidence retention.

Traces, screenshots and DOM snapshots are large and stop being useful once the
failure they explain is closed. This removes evidence older than the configured
window, deleting the files as well as the rows -- a database that points at
files nobody kept is worse than no record at all.

`ARTIFACT_RETENTION_DAYS=0` keeps everything, for deployments whose retention is
governed elsewhere.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.models.testing import ExecutionArtifact, FailureEvidence

logger = get_logger(__name__)


def sweep_expired_evidence(session: Session, *, now: datetime | None = None) -> dict[str, int]:
    """Delete evidence past its retention window. Returns what it removed."""
    if settings.artifact_retention_days <= 0:
        return {"artifacts": 0, "evidence": 0, "files": 0, "bytes": 0}

    cutoff = (now or datetime.now(UTC)) - timedelta(days=settings.artifact_retention_days)
    removed_files = 0
    removed_bytes = 0

    artifacts = list(
        session.execute(select(ExecutionArtifact).where(ExecutionArtifact.created_at < cutoff))
        .scalars()
        .all()
    )
    for artifact in artifacts:
        removed_files, removed_bytes = _unlink(artifact.storage_path, removed_files, removed_bytes)
        session.delete(artifact)

    evidence = list(
        session.execute(select(FailureEvidence).where(FailureEvidence.created_at < cutoff))
        .scalars()
        .all()
    )
    for row in evidence:
        for path in (row.screenshot_path, row.trace_path):
            removed_files, removed_bytes = _unlink(path, removed_files, removed_bytes)
        session.delete(row)

    session.flush()
    summary = {
        "artifacts": len(artifacts),
        "evidence": len(evidence),
        "files": removed_files,
        "bytes": removed_bytes,
    }
    if artifacts or evidence:
        logger.info("evidence_retention_sweep", cutoff=cutoff.isoformat(), **summary)
    return summary


def _unlink(path: str | None, count: int, total_bytes: int) -> tuple[int, int]:
    if not path:
        return count, total_bytes
    candidate = Path(path)
    try:
        if candidate.is_file():
            size = candidate.stat().st_size
            candidate.unlink()
            return count + 1, total_bytes + size
    except OSError as error:  # noqa: PERF203 - one bad path must not stop the sweep
        logger.warning("evidence_file_not_removed", path=path, error=str(error))
    return count, total_bytes
