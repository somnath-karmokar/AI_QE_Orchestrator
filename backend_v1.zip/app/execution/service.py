"""Test execution service (spec section 12).

Two backends behind one contract:

  * `simulated` -- deterministic outcomes derived from each test's own history
    (flakiness, failure rate, module risk). Used when no application under test
    is reachable, which is the demo default. Results are persisted exactly like
    real ones, so every downstream agent, report and RCA path is exercised.
  * `playwright` -- runs the generated pytest/Playwright suite in a subprocess
    and parses the report. Enabled with `PLAYWRIGHT_ENABLED=true`.

Progress streams to the UI over the event bus as each test finishes.
"""

from __future__ import annotations

import json
import random
import re
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.providers.mock import stable_seed
from app.core.config import settings
from app.core.database import session_scope
from app.core.errors import NotFoundError, ValidationError
from app.core.events import event_bus, execution_topic
from app.core.logging import get_logger
from app.core.worker import CancellationToken, job_queue
from app.execution.failures import classify
from app.models.project import Environment
from app.models.testing import (
    Execution,
    ExecutionArtifact,
    ExecutionTest,
    FailureEvidence,
    TestCase,
    TestScript,
)

logger = get_logger(__name__)

# Failure messages keyed by category, used to give simulated failures a realistic
# signature that the analysis and RCA agents can genuinely classify.
_FAILURE_TEMPLATES: list[tuple[str, str, str]] = [
    (
        "locator_drift",
        "LOCATOR_NOT_FOUND",
        'Locator resolved to 0 elements: page.get_by_role("button", name="{element}") - '
        "waiting for locator to be visible",
    ),
    (
        "timing",
        "TIMEOUT_EXCEEDED",
        "Timeout 30000ms exceeded while waiting for element state 'visible' on {element}",
    ),
    (
        "assertion_mismatch",
        "ASSERTION_FAILED",
        'AssertionError: expected the confirmation panel to have text "Order confirmed" '
        'but it showed "Payment pending"',
    ),
    (
        "application_defect",
        "SERVER_ERROR",
        "HTTP 500 Internal Server Error returned by POST {url}/api/{module}",
    ),
    (
        "environment",
        "CONNECTION_REFUSED",
        "net::ERR_CONNECTION_REFUSED at {url} - the service did not accept the connection",
    ),
    (
        "test_data",
        "DATA_PRECONDITION_FAILED",
        "Precondition failed: no such record for account reference used by this test",
    ),
    (
        "authentication",
        "SESSION_EXPIRED",
        "401 Unauthorized - the session token expired before the assertion ran",
    ),
    (
        "navigation",
        "NAVIGATION_FAILED",
        "Expected url to be {url}/confirmation but was {url}/basket",
    ),
]

# What a healing patch changes about a simulated re-run. Repairing the cause of a
# failure removes that cause -- it does not make the test immune. A healed test
# can still fail for an unrelated reason, so a residual share of the original
# risk is kept and the healed category is excluded from the draw. Validation is
# therefore a real gate: heals do fail here, and when they do nothing is applied.
_RESIDUAL_RISK_AFTER_HEAL = 0.25

# Which simulated failure category a change type repairs.
_HEALED_CATEGORY = {
    "locator": "locator_drift",
    "timing": "timing",
    "test_data": "test_data",
    "navigation": "navigation",
}


def _execute_suite_job(execution_id: str, job_id: str) -> None:
    """Worker entry point for a suite run."""
    token = CancellationToken(job_id=job_id)
    with session_scope() as session:
        ExecutionService(session).run(execution_id, cancellation=token)


class ExecutionService:
    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Creation and dispatch
    # ------------------------------------------------------------------
    def create(
        self,
        *,
        project_id: str,
        name: str | None = None,
        suite_type: str = "regression",
        environment_id: str | None = None,
        browser: str = "chromium",
        headless: bool = True,
        parallelism: int = 2,
        test_case_ids: list[str] | None = None,
        module: str | None = None,
        run_id: str | None = None,
        triggered_by: str | None = None,
        trigger: str = "manual",
    ) -> Execution:
        cases = self._select_cases(project_id, test_case_ids=test_case_ids, module=module, suite_type=suite_type)
        if not cases:
            raise ValidationError(
                "No automated test cases match the selected criteria.",
                details={"module": module, "suite_type": suite_type},
            )

        sequence = (
            self.session.execute(
                select(func.coalesce(func.max(Execution.execution_number), 0)).where(
                    Execution.project_id == project_id
                )
            ).scalar_one()
            or 0
        )

        mode = "playwright" if settings.playwright_enabled else "simulated"
        execution = Execution(
            project_id=project_id,
            environment_id=environment_id,
            run_id=run_id,
            name=name or f"{suite_type.title()} suite #{sequence + 1}",
            execution_number=sequence + 1,
            suite_type=suite_type,
            status="queued",
            browser=browser,
            headless=headless,
            parallelism=max(1, min(parallelism, settings.max_parallel_workers)),
            trigger=trigger,
            mode=mode,
            total_tests=len(cases),
            triggered_by=triggered_by,
            config={"module": module, "test_case_ids": [case.id for case in cases]},
        )
        self.session.add(execution)
        self.session.flush()

        for case in cases:
            script = (
                self.session.execute(
                    select(TestScript).where(
                        TestScript.test_case_id == case.id, TestScript.is_deleted.is_(False)
                    )
                )
                .scalars()
                .first()
            )
            self.session.add(
                ExecutionTest(
                    execution_id=execution.id,
                    test_case_id=case.id,
                    test_script_id=script.id if script else None,
                    name=case.title,
                    module=case.module,
                    result="skipped",
                )
            )
        self.session.flush()
        return execution

    def _select_cases(
        self,
        project_id: str,
        *,
        test_case_ids: list[str] | None,
        module: str | None,
        suite_type: str,
    ) -> list[TestCase]:
        statement = select(TestCase).where(
            TestCase.project_id == project_id, TestCase.is_deleted.is_(False)
        )
        if test_case_ids:
            statement = statement.where(TestCase.id.in_(test_case_ids))
        else:
            statement = statement.where(TestCase.is_automated.is_(True))
            if module:
                statement = statement.where(TestCase.module == module)
            if suite_type == "smoke":
                statement = statement.where(TestCase.priority.in_(["critical", "high"]))
        return list(self.session.execute(statement).scalars().all())

    def dispatch(self, execution: Execution) -> Execution:
        import uuid  # noqa: PLC0415 - local to keep the module import surface small

        job_id = str(uuid.uuid4())
        execution.config = {**(execution.config or {}), "job_id": job_id}
        self.session.flush()
        self.session.commit()

        job_queue.submit(
            f"execution:{execution.id}",
            _execute_suite_job,
            execution.id,
            job_id,
            job_id=job_id,
            job_metadata={"execution_id": execution.id, "project_id": execution.project_id},
        )
        logger.info("execution_dispatched", execution_id=execution.id, job_id=job_id)
        return execution

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    def run(self, execution_id: str, *, cancellation: CancellationToken | None = None) -> Execution:
        execution = self.session.get(Execution, execution_id)
        if execution is None:
            raise NotFoundError(f"Execution '{execution_id}' was not found.")

        cancellation = cancellation or CancellationToken()
        execution.status = "running"
        execution.started_at = datetime.now(UTC)
        self.session.flush()
        # Results are committed per test (see _run_simulated) so the live view can
        # read them and a long suite never holds SQLite's write lock throughout.
        self.session.commit()

        topic = execution_topic(execution.id)
        event_bus.publish(
            topic,
            "execution_started",
            {
                "execution_id": execution.id,
                "name": execution.name,
                "total_tests": execution.total_tests,
                "mode": execution.mode,
            },
        )

        started = time.perf_counter()
        tests = list(execution.tests)

        if execution.mode == "playwright":
            results = self._run_browser(execution, tests, cancellation)
        else:
            results = self._run_simulated(execution, tests, cancellation)

        self._finalise(execution, results, started, cancelled=cancellation.is_cancelled)
        return execution

    def _run_simulated(
        self, execution: Execution, tests: list[ExecutionTest], cancellation: CancellationToken
    ) -> list[ExecutionTest]:
        """Deterministic outcomes driven by each test's own recorded history."""
        environment = (
            self.session.get(Environment, execution.environment_id) if execution.environment_id else None
        )
        base_url = (environment.base_url if environment else None) or "https://app.example.test"
        rng = random.Random(stable_seed(execution.project_id, execution.execution_number))

        # A healing validation run carries the proposed change as configuration.
        # It is applied for this run only and never written back to the script.
        patch = (execution.config or {}).get("healing_patch") or {}
        healed_category = _HEALED_CATEGORY.get(str(patch.get("change_type", "")))
        templates = _FAILURE_TEMPLATES
        if healed_category:
            templates = [row for row in _FAILURE_TEMPLATES if row[0] != healed_category]

        for index, test in enumerate(tests, start=1):
            if cancellation.is_cancelled:
                break

            case = self.session.get(TestCase, test.test_case_id) if test.test_case_id else None
            failure_probability = self._failure_probability(case)
            if healed_category:
                failure_probability = round(failure_probability * _RESIDUAL_RISK_AFTER_HEAL, 4)
            roll = rng.random()

            test.started_at = datetime.now(UTC)
            duration = rng.randint(1800, 9500)

            if roll < failure_probability and templates:
                category_key, signature, template = templates[rng.randrange(len(templates))]
                element = (case.module if case else "Submit") + " action"
                test.result = "failed"
                test.failure_signature = signature
                test.failure_message = template.format(
                    element=element,
                    url=base_url,
                    module=(case.module if case else "action").lower(),
                )
                # Classify the message we just wrote rather than trusting the
                # template's label, so the stored category and the one triage
                # computes can never disagree.
                test.failure_category = classify(test.failure_message).category
                test.stack_trace = (
                    f"  File \"{(test.name or 'test').replace(' ', '_').lower()}.py\", line 42\n"
                    f"    {test.failure_message}"
                )
                test.console_logs = [
                    {"level": "error", "message": test.failure_message[:180]},
                    {"level": "warn", "message": "Retrying element resolution once before failing."},
                ]
                test.network_logs = [
                    {"url": f"{base_url}/api/session", "status": 200, "duration_ms": rng.randint(60, 240)},
                    {
                        "url": f"{base_url}/api/{(case.module if case else 'action').lower()}",
                        "status": 500 if category_key == "application_defect" else 200,
                        "duration_ms": rng.randint(180, 2400),
                    },
                ]
                duration = rng.randint(4000, 32000)
                self._add_artifacts(execution, test, base_url)
            elif roll < failure_probability + (case.flakiness_score if case else 0.0) * 0.5:
                # Flaky: failed once, passed on retry.
                test.result = "flaky"
                test.retry_count = 1
                test.failure_category = "timing"
                test.failure_signature = "TIMEOUT_EXCEEDED"
                test.failure_message = (
                    "Timed out waiting for the panel to settle; passed on retry."
                )
                self._add_artifacts(execution, test, base_url)
            else:
                test.result = "passed"
                test.failure_message = None
                if healed_category:
                    # It passed with the temporary patch in place, so this run is
                    # the evidence the healing record needs.
                    test.healed = True

            test.duration_ms = duration
            # Running totals drive the live progress bar; _finalise recounts at the end.
            if test.result == "failed":
                execution.failed += 1
            elif test.result == "flaky":
                execution.flaky += 1
            else:
                execution.passed += 1
            self.session.flush()

            if case is not None:
                case.execution_count += 1
                case.last_result = test.result
                case.last_executed_at = datetime.now(UTC)
                if test.result in {"failed", "flaky"}:
                    case.failure_count += 1
                previous = case.avg_duration_ms or duration
                case.avg_duration_ms = int((previous + duration) / 2)
                case.flakiness_score = round(
                    min(1.0, case.failure_count / max(1, case.execution_count)), 4
                )
            self.session.commit()

            event_bus.publish(
                execution_topic(execution.id),
                "test_completed",
                {
                    "execution_id": execution.id,
                    "test_id": test.id,
                    "name": test.name,
                    "module": test.module,
                    "result": test.result,
                    "duration_ms": test.duration_ms,
                    "completed": index,
                    "total": len(tests),
                    "failure_category": test.failure_category,
                },
            )
            # Pace the stream so the live UI reads as a real run rather than a dump.
            time.sleep(0.12)

        return tests

    @staticmethod
    def _failure_probability(case: TestCase | None) -> float:
        """Blend historical failure rate with priority-driven baseline risk."""
        if case is None:
            return 0.12
        historical = (case.failure_count / case.execution_count) if case.execution_count else 0.0
        baseline = {"critical": 0.10, "high": 0.13, "medium": 0.16, "low": 0.09}.get(case.priority, 0.12)
        return round(min(0.55, historical * 0.6 + baseline * 0.6), 4)

    def _add_artifacts(self, execution: Execution, test: ExecutionTest, base_url: str) -> None:
        artifacts_dir = Path(settings.execution_artifacts_dir) / execution.id
        for artifact_type, extension, content_type in (
            ("screenshot", "png", "image/png"),
            ("trace", "zip", "application/zip"),
            ("log", "txt", "text/plain"),
        ):
            name = f"{(test.name or 'test')[:40].replace(' ', '_').lower()}-{artifact_type}.{extension}"
            self.session.add(
                ExecutionArtifact(
                    execution_id=execution.id,
                    execution_test_id=test.id,
                    artifact_type=artifact_type,
                    name=name,
                    storage_path=str(artifacts_dir / name),
                    content_type=content_type,
                    size_bytes=0,
                    artifact_metadata={
                        "captured_at": datetime.now(UTC).isoformat(),
                        "url": base_url,
                        # Nothing was written to disk in simulated mode; say so
                        # rather than implying a file exists.
                        "materialized": False,
                    },
                )
            )
        test.dom_snapshot_ref = str(artifacts_dir / f"{test.id}-dom.html")

    def _run_browser(
        self, execution: Execution, tests: list[ExecutionTest], cancellation: CancellationToken
    ) -> list[ExecutionTest]:
        """Check each test's locators against the live application.

        Locator resolution is what self-healing repairs, so that is what this
        verifies: for every locator a script declares, is the element still
        findable? When one is not, the page is captured -- DOM, accessibility
        tree, screenshot, console and network -- while the browser still has it,
        and that evidence is what a later heal reasons over.

        Driving Playwright directly rather than through pytest is deliberate: a
        finished pytest process cannot hand back the page that failed.
        """
        from app.execution.browser import BrowserRunner  # noqa: PLC0415

        environment = (
            self.session.get(Environment, execution.environment_id) if execution.environment_id else None
        )
        base_url = (environment.base_url if environment else None) or settings.demo_app_base_url
        artifacts_dir = Path(settings.execution_artifacts_dir) / execution.id
        runner = BrowserRunner(artifacts_dir)
        patch = (execution.config or {}).get("healing_patch") or {}

        for index, test in enumerate(tests, start=1):
            if cancellation.is_cancelled:
                break

            script = self.session.get(TestScript, test.test_script_id) if test.test_script_id else None
            locators = list(script.locators or []) if script else []
            # Only a locator change rewrites locators. A timing change keeps the
            # locator exactly as it is and alters how long the test waits for it.
            if (
                patch.get("change_type") != "timing"
                and patch.get("from")
                and patch.get("to")
                and patch.get("test_script_id") == (script.id if script else None)
            ):
                # The proposed change, applied for this run only.
                locators = [
                    {**item, "locator": patch["to"], "strategy": patch.get("strategy", item.get("strategy"))}
                    if item.get("locator") == patch["from"]
                    else item
                    for item in locators
                ]

            test.started_at = datetime.now(UTC)
            started_test = time.perf_counter()

            if not locators:
                test.result = "skipped"
                test.failure_message = "This test has no locators to verify."
                self.session.flush()
                self.session.commit()
                continue

            slug = re.sub(r"[^a-z0-9]+", "-", (test.name or "test").lower())[:48].strip("-") or "test"
            capture = runner.check_locators(
                url=base_url,
                locators=locators,
                label=test.name or "test",
                # A timing repair changes how long the test waits, not what it
                # looks for, so it is applied here rather than to the locators.
                wait_ms=patch.get("wait_ms") if patch.get("change_type") == "timing" else None,
            )

            test.duration_ms = int((time.perf_counter() - started_test) * 1000)
            failures = capture.failures
            if failures:
                # Prefer a timing failure when one is present: "the element was
                # late" is a more specific and more actionable answer than "the
                # element was missing", and it leads to a different repair.
                first = next((check for check in failures if check.is_timing), failures[0])
                test.result = "failed"
                if first.strategy == "navigation":
                    test.failure_signature = "NAVIGATION_FAILED"
                    test.failure_message = f"Could not open {capture.url}: {first.error}"
                elif first.is_timing:
                    test.failure_signature = "TIMEOUT_EXCEEDED"
                    test.failure_message = (
                        f"Timeout {settings.playwright_timeout_ms}ms exceeded while waiting for "
                        f"'{first.name}' ({first.expression}); it appeared after "
                        f"{first.appeared_after_ms}ms."
                    )
                else:
                    test.failure_signature = "LOCATOR_NOT_FOUND"
                    test.failure_message = (
                        f"Locator resolved to 0 elements: {first.expression} "
                        f"(looking for '{first.name}' on {capture.url})"
                    )
                test.failure_category = classify(test.failure_message).category
                test.dom_snapshot_ref = str(artifacts_dir / f"{slug}-dom.html")
                execution.failed += 1
            else:
                test.result = "passed"
                test.failure_message = None
                if patch:
                    test.healed = True
                execution.passed += 1

            test.console_logs = capture.console_logs[:20]
            test.network_logs = capture.network_logs[:20]
            self._persist_evidence(execution, test, capture, slug)
            self._remember_fingerprints(script, capture)
            self.session.flush()
            self.session.commit()

            event_bus.publish(
                execution_topic(execution.id),
                "test_completed",
                {
                    "execution_id": execution.id,
                    "test_id": test.id,
                    "name": test.name,
                    "module": test.module,
                    "result": test.result,
                    "duration_ms": test.duration_ms,
                    "completed": index,
                    "total": len(tests),
                    "failure_category": test.failure_category,
                },
            )

        return tests

    def _persist_evidence(
        self, execution: Execution, test: ExecutionTest, capture: Any, slug: str
    ) -> None:
        """Record what the browser actually saw, and the files it wrote."""
        from app.execution.browser import evidence_files  # noqa: PLC0415

        artifacts_dir = Path(settings.execution_artifacts_dir) / execution.id
        for row in evidence_files(capture, artifacts_dir, slug):
            self.session.add(
                ExecutionArtifact(
                    execution_id=execution.id,
                    execution_test_id=test.id,
                    artifact_type=row["artifact_type"],
                    name=row["name"],
                    storage_path=row["storage_path"],
                    content_type=row["content_type"],
                    size_bytes=row["size_bytes"],
                    artifact_metadata=row["metadata"],
                )
            )

        if not capture.failures:
            return

        first = next(
            (check for check in capture.failures if check.is_timing), capture.failures[0]
        )
        self.session.add(
            FailureEvidence(
                project_id=execution.project_id,
                execution_id=execution.id,
                execution_test_id=test.id,
                page_url=capture.url,
                page_title=capture.title,
                failed_locator=first.expression,
                failed_locator_name=first.name,
                failed_locator_strategy=first.strategy,
                observed_wait_ms=first.appeared_after_ms,
                dom_html=capture.dom_html or None,
                accessibility_tree=capture.accessibility_tree or {},
                console_logs=capture.console_logs[:50],
                network_logs=capture.network_logs[:50],
                screenshot_path=capture.screenshot_path,
                trace_path=capture.trace_path,
                capture_mode="playwright",
                captured_at=datetime.now(UTC),
            )
        )

    @staticmethod
    def _remember_fingerprints(script: TestScript | None, capture: Any) -> None:
        """Keep what each resolving element looked like, for the next heal."""
        if script is None:
            return
        found = {
            check.expression: check.fingerprint
            for check in capture.checks
            if check.resolved and check.fingerprint
        }
        if not found:
            return
        script.locators = [
            {**item, "fingerprint": found[item.get("locator")]}
            if item.get("locator") in found
            else item
            for item in (script.locators or [])
        ]

    def _run_pytest_suite(
        self, execution: Execution, tests: list[ExecutionTest], cancellation: CancellationToken
    ) -> list[ExecutionTest]:
        """Run the generated suite with pytest and map the JSON report back."""
        artifacts_dir = Path(settings.execution_artifacts_dir) / execution.id
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        suite_dir = artifacts_dir / "suite"
        suite_dir.mkdir(exist_ok=True)

        # Materialise the generated scripts so pytest has something to collect.
        # A healing patch is applied to the materialised copy only: the TestScript
        # row keeps its current locators until a re-run has proved the change.
        patch = (execution.config or {}).get("healing_patch") or {}
        for test in tests:
            if not test.test_script_id:
                continue
            script = self.session.get(TestScript, test.test_script_id)
            if script is None:
                continue
            code = script.code
            if patch.get("from") and patch.get("to") and patch.get("test_script_id") == script.id:
                code = code.replace(patch["from"], patch["to"])
            target = suite_dir / Path(script.file_path).name
            target.write_text(code, encoding="utf-8")

        report_path = artifacts_dir / "report.json"
        command = [
            "pytest",
            str(suite_dir),
            "--browser",
            execution.browser,
            f"--json-report-file={report_path}",
            "-q",
        ]
        if execution.headless:
            command.append("--headed" if not execution.headless else "--browser-channel=chrome")

        try:
            completed = subprocess.run(  # noqa: S603 - fixed argv, no shell
                command,
                cwd=str(suite_dir),
                capture_output=True,
                text=True,
                timeout=1800,
                check=False,
            )
            logger.info("playwright_suite_finished", return_code=completed.returncode)
        except FileNotFoundError:
            logger.error("pytest_not_available", detail="Falling back to simulated execution.")
            return self._run_simulated(execution, tests, cancellation)
        except subprocess.TimeoutExpired:
            logger.error("playwright_suite_timeout", execution_id=execution.id)
            for test in tests:
                test.result = "failed"
                test.failure_message = "Suite exceeded the 30 minute execution timeout."
                test.failure_category = "timing"
            self.session.flush()
            return tests

        outcomes: dict[str, dict[str, Any]] = {}
        if report_path.exists():
            try:
                report = json.loads(report_path.read_text(encoding="utf-8"))
                for entry in report.get("tests", []):
                    outcomes[entry.get("nodeid", "")] = entry
            except json.JSONDecodeError:
                logger.warning("playwright_report_unparseable", path=str(report_path))

        for index, test in enumerate(tests, start=1):
            match = next(
                (entry for node_id, entry in outcomes.items() if (test.name or "").lower() in node_id.lower()),
                None,
            )
            if match is None:
                test.result = "skipped"
            else:
                status = match.get("outcome", "failed")
                test.result = {"passed": "passed", "failed": "failed", "skipped": "skipped"}.get(status, "failed")
                test.duration_ms = int(float(match.get("duration", 0)) * 1000)
                if test.result == "failed":
                    message = str(match.get("call", {}).get("longrepr", ""))[:2000]
                    test.failure_message = message
                    test.stack_trace = message
                    test.failure_category = "unknown"

            event_bus.publish(
                execution_topic(execution.id),
                "test_completed",
                {
                    "execution_id": execution.id,
                    "test_id": test.id,
                    "name": test.name,
                    "result": test.result,
                    "completed": index,
                    "total": len(tests),
                },
            )
            self.session.flush()

        return tests

    def _finalise(
        self, execution: Execution, tests: list[ExecutionTest], started: float, *, cancelled: bool
    ) -> None:
        passed = sum(1 for test in tests if test.result == "passed")
        failed = sum(1 for test in tests if test.result == "failed")
        skipped = sum(1 for test in tests if test.result == "skipped")
        flaky = sum(1 for test in tests if test.result == "flaky")
        healed = sum(1 for test in tests if test.healed)

        categories: dict[str, int] = {}
        for test in tests:
            if test.failure_category:
                categories[test.failure_category] = categories.get(test.failure_category, 0) + 1

        execution.passed = passed
        execution.failed = failed
        execution.skipped = skipped
        execution.flaky = flaky
        execution.healed = healed
        execution.pass_rate = round((passed + flaky) / len(tests), 4) if tests else 0.0
        execution.failure_categories = categories
        execution.duration_ms = int((time.perf_counter() - started) * 1000)
        execution.finished_at = datetime.now(UTC)

        if cancelled:
            execution.status = "aborted"
        elif failed:
            execution.status = "failed"
        elif skipped == len(tests):
            execution.status = "partial"
        else:
            execution.status = "passed"

        self.session.commit()

        event_bus.publish(
            execution_topic(execution.id),
            "execution_completed",
            {
                "execution_id": execution.id,
                "status": execution.status,
                "passed": passed,
                "failed": failed,
                "skipped": skipped,
                "flaky": flaky,
                "pass_rate": execution.pass_rate,
                "duration_ms": execution.duration_ms,
            },
        )
        logger.info(
            "execution_finished",
            execution_id=execution.id,
            status=execution.status,
            passed=passed,
            failed=failed,
        )

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------
    def cancel(self, execution_id: str) -> Execution:
        execution = self.session.get(Execution, execution_id)
        if execution is None:
            raise NotFoundError(f"Execution '{execution_id}' was not found.")
        job_id = (execution.config or {}).get("job_id")
        if job_id:
            job_queue.cancel(job_id)
        execution.status = "aborted"
        execution.finished_at = datetime.now(UTC)
        self.session.flush()
        return execution

    def retry_failed(self, execution_id: str, triggered_by: str | None = None) -> Execution:
        """Create a follow-up execution containing only the failed tests."""
        source = self.session.get(Execution, execution_id)
        if source is None:
            raise NotFoundError(f"Execution '{execution_id}' was not found.")

        failed_case_ids = [
            test.test_case_id for test in source.tests if test.result in {"failed", "flaky"} and test.test_case_id
        ]
        if not failed_case_ids:
            raise ValidationError("This execution has no failed tests to retry.")

        retry = self.create(
            project_id=source.project_id,
            name=f"{source.name} (retry of failures)",
            suite_type=source.suite_type,
            environment_id=source.environment_id,
            browser=source.browser,
            headless=source.headless,
            parallelism=source.parallelism,
            test_case_ids=failed_case_ids,
            triggered_by=triggered_by,
            trigger="retry",
        )
        return retry
