"""Shared FastAPI dependencies: session, authentication, authorization, paging."""

from __future__ import annotations

from collections.abc import Callable
from typing import Annotated

from fastapi import Depends, Header, Query, Request
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.errors import AuthenticationError, NotFoundError
from app.core.security import Principal, principal_from_token
from app.models.project import Project
from app.schemas.common import PaginationParams

DbSession = Annotated[Session, Depends(get_db)]


def get_principal(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
) -> Principal:
    """Resolve the caller from the bearer token."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise AuthenticationError("An authentication token is required.")
    principal = principal_from_token(authorization.split(" ", 1)[1].strip())
    request.state.principal = principal
    return principal


CurrentUser = Annotated[Principal, Depends(get_principal)]


def require_permission(permission: str) -> Callable[[Principal], Principal]:
    """Dependency factory enforcing a single permission."""

    def _dependency(principal: CurrentUser) -> Principal:
        principal.require(permission)
        return principal

    return _dependency


def get_pagination(
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> PaginationParams:
    return PaginationParams(limit=limit, offset=offset)


Pagination = Annotated[PaginationParams, Depends(get_pagination)]


def get_project(project_id: str, session: DbSession) -> Project:
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.", details={"project_id": project_id})
    return project


CurrentProject = Annotated[Project, Depends(get_project)]
