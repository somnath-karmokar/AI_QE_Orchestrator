"""Governance: policies, approvals, audit trail and AI cost analytics."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select

from app.ai.cost.tracker import CostTracker
from app.api.deps import DbSession, Pagination, require_permission
from app.core.errors import ConflictError, NotFoundError
from app.core.security import Principal
from app.models.governance import ApprovalRequest, AuditLog, GovernancePolicy
from app.models.run import AgentRun
from app.schemas.common import Page
from app.schemas.entities import (
    ApprovalDecision,
    ApprovalOut,
    AuditLogOut,
    PolicyOut,
    PolicyUpdate,
)
from app.services.run_service import RunService

router = APIRouter(prefix="/governance", tags=["Governance"])


# ---------------------------------------------------------------------------
# Policies
# ---------------------------------------------------------------------------


@router.get("/policies", response_model=list[PolicyOut], summary="List governance policies")
def list_policies(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("governance:read"))],
    project_id: Annotated[str | None, Query()] = None,
    policy_type: Annotated[str | None, Query()] = None,
) -> list[PolicyOut]:
    statement = select(GovernancePolicy)
    if project_id:
        statement = statement.where(
            (GovernancePolicy.project_id == project_id) | (GovernancePolicy.project_id.is_(None))
        )
    if policy_type:
        statement = statement.where(GovernancePolicy.policy_type == policy_type)
    rows = list(
        session.execute(statement.order_by(GovernancePolicy.priority, GovernancePolicy.name))
        .scalars()
        .all()
    )
    return [PolicyOut.model_validate(row) for row in rows]


@router.patch("/policies/{policy_id}", response_model=PolicyOut, summary="Update a policy")
def update_policy(
    policy_id: str,
    payload: PolicyUpdate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("governance:read"))],
) -> PolicyOut:
    principal.require("project:write")
    policy = session.get(GovernancePolicy, policy_id)
    if policy is None:
        raise NotFoundError(f"Policy '{policy_id}' was not found.")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(policy, field, value)
    policy.updated_by = principal.email
    session.flush()
    return PolicyOut.model_validate(policy)


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------


@router.get("/approvals", response_model=Page[ApprovalOut], summary="List approval requests")
def list_approvals(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("governance:read"))],
    project_id: Annotated[str | None, Query()] = None,
    status: Annotated[str | None, Query()] = None,
) -> Page[ApprovalOut]:
    statement = select(ApprovalRequest)
    if project_id:
        statement = statement.where(ApprovalRequest.project_id == project_id)
    if status:
        statement = statement.where(ApprovalRequest.status == status)

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(ApprovalRequest.created_at.desc())
            .limit(pagination.limit)
            .offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[ApprovalOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/approvals/{approval_id}", response_model=ApprovalOut, summary="Get an approval request")
def get_approval(
    approval_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("governance:read"))],
) -> ApprovalOut:
    row = session.get(ApprovalRequest, approval_id)
    if row is None:
        raise NotFoundError(f"Approval request '{approval_id}' was not found.")
    return ApprovalOut.model_validate(row)


@router.post("/approvals/{approval_id}/decide", response_model=ApprovalOut, summary="Approve or reject")
def decide_approval(
    approval_id: str,
    payload: ApprovalDecision,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("approval:decide"))],
) -> ApprovalOut:
    approval = session.get(ApprovalRequest, approval_id)
    if approval is None:
        raise NotFoundError(f"Approval request '{approval_id}' was not found.")
    if approval.status != "pending":
        raise ConflictError(f"This request was already {approval.status}.")

    approval.status = "approved" if payload.decision == "approve" else "rejected"
    approval.decided_by = principal.email
    approval.decided_at = datetime.now(UTC)
    approval.decision_notes = payload.notes
    session.flush()

    session.add(
        AuditLog(
            project_id=approval.project_id,
            actor=principal.email,
            actor_type="user",
            action="approval.decide",
            entity_type="approval_request",
            entity_id=approval.id,
            entity_label=approval.title,
            reason=payload.notes or f"Request {approval.status}.",
            outcome="success",
            severity="info",
            policy_result={"decision": approval.status},
            run_id=approval.run_id,
        )
    )
    session.flush()

    # Approving a gate that paused a run should let the run continue.
    if payload.resume_run and approval.run_id and approval.status == "approved":
        run = session.get(AgentRun, approval.run_id)
        if run is not None and run.status == "awaiting_approval":
            still_pending = session.execute(
                select(ApprovalRequest).where(
                    ApprovalRequest.run_id == run.id, ApprovalRequest.status == "pending"
                )
            ).scalars().first()
            if still_pending is None:
                RunService(session).resume(run.id, actor=principal.email)

    return ApprovalOut.model_validate(approval)


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

audit_router = APIRouter(prefix="/audit", tags=["Governance"])


@audit_router.get("", response_model=Page[AuditLogOut], summary="Query the audit trail")
def list_audit(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("governance:read"))],
    project_id: Annotated[str | None, Query()] = None,
    action: Annotated[str | None, Query()] = None,
    actor: Annotated[str | None, Query()] = None,
    entity_type: Annotated[str | None, Query()] = None,
    outcome: Annotated[str | None, Query()] = None,
) -> Page[AuditLogOut]:
    statement = select(AuditLog)
    if project_id:
        statement = statement.where(AuditLog.project_id == project_id)
    if action:
        statement = statement.where(AuditLog.action == action)
    if actor:
        statement = statement.where(AuditLog.actor == actor)
    if entity_type:
        statement = statement.where(AuditLog.entity_type == entity_type)
    if outcome:
        statement = statement.where(AuditLog.outcome == outcome)

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(AuditLog.created_at.desc())
            .limit(pagination.limit)
            .offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[AuditLogOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


# ---------------------------------------------------------------------------
# AI cost analytics
# ---------------------------------------------------------------------------

llm_router = APIRouter(prefix="/llm", tags=["AI Governance"])


@llm_router.get("/usage", summary="AI usage and cost analytics")
def llm_usage(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    project_id: Annotated[str | None, Query()] = None,
    days: Annotated[int, Query(ge=1, le=365)] = 30,
) -> dict:
    return CostTracker(session).breakdown(project_id, days=days)
