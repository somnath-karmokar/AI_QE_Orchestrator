"""The surface another platform integrates against.

Separate from the routes the web app uses, and deliberately narrower. This is a
contract: the shapes here are stable, the internal step graph is not exposed,
and every response that concerns a run carries the same guardrail block.

Authentication is an API key (`X-API-Key`) belonging to an `IntegrationClient`
with explicit scopes. See `docs/integration/README.md`.
"""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Header, Query, Response
from sqlalchemy import func, select

from app.api.deps import DbSession, Pagination, require_permission
from app.api.integration_auth import (
    NOT_AVAILABLE,
    CurrentClient,
    require_scope,
    resolve_client,
    resolve_flow_or_deny,
)
from app.core.errors import NotFoundError, ValidationError
from app.core.logging import get_logger
from app.core.security import Principal
from app.governance.policy_engine import AuditService
from app.models.integration import IntegrationClient
from app.models.run import AgentRun
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import (
    IntegrationClientCreate,
    IntegrationClientCreated,
    IntegrationClientOut,
    IntegrationRunRequest,
)
from app.services.integration_clients import issue_client, revoke_client, rotate_token
from app.services.flow_triggers import trigger_flow
from app.services.input_validation import describe_effective, validate_inputs
from app.services.integration_openapi import build_integration_openapi
from app.services.integration import build_catalog, build_manifest, run_envelope
from app.services.run_service import RunService

logger = get_logger(__name__)

router = APIRouter(prefix="/integration", tags=["Integration"])

# Managing the keys themselves is an operator's job, not an integrator's, so it
# sits behind the normal user session rather than behind an API key.
admin_router = APIRouter(prefix="/integration-clients", tags=["Integration"])


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


@router.get("/manifest", summary="What this platform is, and what it promises")
def manifest(session: DbSession, client: CurrentClient) -> dict:
    """The first call an integrator makes.

    Names the platform, the authentication scheme, the limits, the guardrail
    contract and every endpoint, so the rest of the integration can be built
    without reading source.
    """
    return build_manifest(session, client)


@router.get(
    "/openapi.json",
    summary="OpenAPI document for the integration surface",
    description=(
        "The integration contract alone, not the platform's 118 internal routes. "
        "Send a valid `X-API-Key` and it also describes **your own** flows and agents, "
        "one operation each with its real input schema — the version worth generating "
        "a client from. Without a key it describes the contract and nothing about any "
        "project."
    ),
)
def integration_openapi(
    session: DbSession,
    x_api_key: Annotated[str | None, Header(alias="X-API-Key")] = None,
) -> dict:
    """Deliberately optional authentication.

    Unauthenticated it is the public contract, which a Swagger UI can load
    without a credential. With a key it gains that key's own capabilities — and
    a wrong key simply gets the public contract rather than an error, because
    this document reveals nothing worth protecting on its own.
    """
    client = _client_for_spec(session, x_api_key)
    return build_integration_openapi(session if client else None, client)


def _client_for_spec(session, token: str | None) -> IntegrationClient | None:  # noqa: ANN001
    """Resolve a key if one was sent, without the usual refusal on failure.

    Validity is decided by `resolve_client`, the same rule the authenticating
    dependency uses, so a revoked or expired key falls back to the public
    contract rather than keeping a window onto the project's flows.

    The per-key rate limit deliberately does not apply here. It meters the work
    a key may ask the platform to *do*, and this is a discovery document a code
    generator fetches once; charging it against the caller's run budget would
    make the advertised limit mean something different from what the manifest
    says. The global per-IP limiter still covers abuse of this route.
    """
    return resolve_client(session, token)


@router.get("/catalog", summary="The flows and agents this key may invoke")
def catalog(
    session: DbSession,
    client: Annotated[IntegrationClient, Depends(require_scope("catalog:read"))],
) -> dict:
    """Each entry carries the JSON Schema of its inputs, so a calling platform
    can build a form, validate a payload or generate a client from it."""
    return build_catalog(session, client)


# ---------------------------------------------------------------------------
# Invocation
# ---------------------------------------------------------------------------


@router.post("/flows/{flow_id}/runs", status_code=202, summary="Start a flow")
def start_flow_run(
    flow_id: str,
    session: DbSession,
    response: Response,
    client: Annotated[IntegrationClient, Depends(require_scope("flows:run"))],
    payload: IntegrationRunRequest | None = None,
    idempotency_key: Annotated[str | None, Header(alias="X-Idempotency-Key")] = None,
) -> dict:
    """Start a run and return immediately with somewhere to watch it.

    202, not 200: the work has been accepted, not finished. Poll `links.self`
    or supply a callback URL on the key.
    """
    flow = resolve_flow_or_deny(session, client, flow_id)
    payload = payload or IntegrationRunRequest()

    # Refuse data the flow cannot use. Accepting it would mean running on the
    # declared defaults instead and returning a confident answer about the
    # wrong thing, which the caller has no way to detect.
    checked = validate_inputs(
        _flow_input_schema(flow), payload.inputs, defaults=flow.variables or {}
    )
    if not checked.ok:
        raise ValidationError(
            "These inputs do not match what this flow accepts.",
            details={**checked.to_details(), "accepts": sorted(flow.variables or {})},
        )

    # A network retry must not start a second run. Same key, same run back.
    if idempotency_key:
        existing = _find_by_idempotency_key(session, client, idempotency_key)
        if existing is not None:
            response.status_code = 200
            response.headers["X-Idempotent-Replay"] = "true"
            return run_envelope(session, existing)

    run = trigger_flow(
        session,
        flow,
        trigger="api",
        triggered_by=f"integration:{client.name}",
        inputs=payload.inputs,
        title=payload.title,
        environment_id=payload.environment_id,
    )
    if idempotency_key:
        run.idempotency_key = idempotency_key
        session.flush()

    _audit(
        session,
        client,
        action="integration.flow_started",
        entity_type="agent_run",
        entity_id=run.id,
        entity_label=flow.name,
        summary={"flow_id": flow.id, "inputs": list((payload.inputs or {}).keys())},
    )
    logger.info("integration_flow_started", client=client.name, flow=flow.name, run_id=run.id)
    envelope = run_envelope(session, run)
    # So "run it with my data" is verifiable rather than assumed.
    envelope["inputs_applied"] = describe_effective(checked.effective, payload.inputs)
    return envelope


@router.post("/agents/{agent_key}/runs", status_code=202, summary="Invoke a single agent")
def start_agent_run(
    agent_key: str,
    session: DbSession,
    client: Annotated[IntegrationClient, Depends(require_scope("agents:run"))],
    payload: IntegrationRunRequest | None = None,
) -> dict:
    """Run one agent rather than a whole flow.

    The same governance applies: an agent that requires approval pauses here
    exactly as it would inside a flow.
    """
    if not client.may_run_agent(agent_key):
        raise NotFoundError(NOT_AVAILABLE)

    from app.models.agent import Agent  # noqa: PLC0415

    agent = (
        session.execute(
            select(Agent).where(
                Agent.project_id == client.project_id,
                Agent.handler_key == agent_key,
                Agent.is_deleted.is_(False),
            )
        )
        .scalars()
        .first()
    )
    if agent is None:
        raise NotFoundError(NOT_AVAILABLE)

    payload = payload or IntegrationRunRequest()
    checked = validate_inputs(agent.input_schema, payload.inputs)
    if not checked.ok:
        raise ValidationError(
            "These inputs do not match what this agent accepts.",
            details=checked.to_details(),
        )

    run = RunService(session).start_agent_run(
        agent_id=agent.id,
        project_id=client.project_id,
        inputs=payload.inputs or {},
        environment_id=payload.environment_id,
        triggered_by=f"integration:{client.name}",
        kind="agent",
    )
    _audit(
        session,
        client,
        action="integration.agent_invoked",
        entity_type="agent_run",
        entity_id=run.id,
        entity_label=agent.name,
        summary={"agent_key": agent_key, "inputs": list((payload.inputs or {}).keys())},
    )
    envelope = run_envelope(session, run)
    envelope["inputs_applied"] = describe_effective(checked.effective, payload.inputs)
    return envelope


# ---------------------------------------------------------------------------
# Watching
# ---------------------------------------------------------------------------


@router.get("/runs/{run_id}", summary="Status, guardrail outcome and result of a run")
def get_run(
    run_id: str,
    session: DbSession,
    client: Annotated[IntegrationClient, Depends(require_scope("runs:read"))],
) -> dict:
    """The endpoint a caller polls.

    `disposition` is the field to branch on: `pending`, `waiting_for_approval`,
    `succeeded`, `failed`, `cancelled` or `refused`. Anything else in the body
    is for humans reading logs.
    """
    run = _resolve_run_or_deny(session, client, run_id)
    return run_envelope(session, run)


@router.post("/runs/{run_id}/cancel", summary="Cancel a run this key started")
def cancel_run(
    run_id: str,
    session: DbSession,
    client: Annotated[IntegrationClient, Depends(require_scope("runs:cancel"))],
) -> dict:
    run = _resolve_run_or_deny(session, client, run_id)
    if run.status in {"succeeded", "failed", "cancelled", "aborted"}:
        raise ValidationError(f"This run has already finished with status '{run.status}'.")

    run = RunService(session).cancel(run.id, actor=f"integration:{client.name}")
    _audit(
        session,
        client,
        action="integration.run_cancelled",
        entity_type="agent_run",
        entity_id=run.id,
        entity_label=run.title,
        summary={},
    )
    return run_envelope(session, run)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _flow_input_schema(flow) -> dict:  # noqa: ANN001
    """The same schema the catalog publishes, so validation matches the contract."""
    from app.services.integration import _flow_descriptor  # noqa: PLC0415

    return _flow_descriptor(flow)["input_schema"]


def _resolve_run_or_deny(session, client: IntegrationClient, run_id: str) -> AgentRun:  # noqa: ANN001
    """A run this client started, or a 404 that reveals nothing.

    A key can read its own runs and no others -- not other keys' runs, and not
    runs a person started in the web app.
    """
    run = session.get(AgentRun, run_id)
    expected = f"integration:{client.name}"
    if run is None or run.project_id != client.project_id or run.triggered_by != expected:
        raise NotFoundError(NOT_AVAILABLE)
    return run


def _find_by_idempotency_key(
    session, client: IntegrationClient, key: str  # noqa: ANN001
) -> AgentRun | None:
    """The run this key already started under that idempotency key, if any.

    Scoped to the calling client, so two systems can use the same build number
    without colliding.
    """
    return (
        session.execute(
            select(AgentRun)
            .where(
                AgentRun.project_id == client.project_id,
                AgentRun.triggered_by == f"integration:{client.name}",
                AgentRun.idempotency_key == key,
            )
            .order_by(AgentRun.created_at.desc())
            .limit(1)
        )
        .scalars()
        .first()
    )


# ---------------------------------------------------------------------------
# Key management (operator-facing)
# ---------------------------------------------------------------------------


@admin_router.get("", response_model=Page[IntegrationClientOut], summary="List API keys")
def list_clients(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("governance:read"))],
    project_id: Annotated[str, Query()],
) -> Page[IntegrationClientOut]:
    statement = (
        select(IntegrationClient)
        .where(
            IntegrationClient.project_id == project_id,
            IntegrationClient.is_deleted.is_(False),
        )
        .order_by(IntegrationClient.created_at.desc())
    )
    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(statement.limit(pagination.limit).offset(pagination.offset)).scalars().all()
    )
    return Page(
        items=[IntegrationClientOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@admin_router.post(
    "", response_model=IntegrationClientCreated, status_code=201, summary="Issue an API key"
)
def create_client(
    payload: IntegrationClientCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("governance:write"))],
) -> IntegrationClientCreated:
    """The token is in this response and nowhere else. Copy it now."""
    client, token = issue_client(
        session,
        project_id=payload.project_id,
        name=payload.name,
        actor=principal.email,
        description=payload.description,
        platform=payload.platform,
        scopes=payload.scopes,
        allowed_flow_ids=payload.allowed_flow_ids,
        allowed_agent_keys=payload.allowed_agent_keys,
        rate_limit_per_minute=payload.rate_limit_per_minute,
        callback_url=payload.callback_url,
        expires_in_days=payload.expires_in_days,
    )
    return IntegrationClientCreated(
        **IntegrationClientOut.model_validate(client).model_dump(), token=token
    )


@admin_router.post(
    "/{client_id}/rotate", response_model=IntegrationClientCreated, summary="Rotate an API key"
)
def rotate_client_token(
    client_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("governance:write"))],
) -> IntegrationClientCreated:
    client = _client_or_404(session, client_id)
    token = rotate_token(session, client, principal.email)
    return IntegrationClientCreated(
        **IntegrationClientOut.model_validate(client).model_dump(), token=token
    )


@admin_router.delete("/{client_id}", response_model=MessageResponse, summary="Revoke an API key")
def revoke_client_token(
    client_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("governance:write"))],
) -> MessageResponse:
    client = _client_or_404(session, client_id)
    revoke_client(session, client, principal.email)
    return MessageResponse(message=f"API key '{client.name}' was revoked.")


def _client_or_404(session, client_id: str) -> IntegrationClient:  # noqa: ANN001
    client = session.get(IntegrationClient, client_id)
    if client is None or client.is_deleted:
        raise NotFoundError(f"Integration client '{client_id}' was not found.")
    return client


def _audit(
    session,  # noqa: ANN001
    client: IntegrationClient,
    *,
    action: str,
    entity_type: str,
    entity_id: str,
    entity_label: str,
    summary: dict,
) -> None:
    AuditService(session).record(
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        entity_label=entity_label,
        actor=f"integration:{client.name}",
        actor_type="system",
        project_id=client.project_id,
        input_summary={**summary, "client_platform": client.platform, "token": client.token_hint},
    )
