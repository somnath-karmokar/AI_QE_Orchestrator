"""Platform endpoints: AI providers, vector store, MCP inventory, dashboard, demo control."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select

from app.ai.prompts import get as get_prompt
from app.ai.prompts import templates as prompt_templates
from app.ai.providers.registry import full_catalog, provider_health
from app.api.deps import DbSession, require_permission
from app.core.config import settings
from app.core.errors import NotFoundError
from app.core.security import Principal, redact_secrets
from app.core.worker import job_queue
from app.mcp.registry import MCPRegistry
from app.models.llm import LLMRoutingPolicy
from app.models.project import Project
from app.schemas.common import MessageResponse
from app.services.analytics_service import AnalyticsService
from app.vectorstore.factory import get_vector_store

router = APIRouter(tags=["Platform"])


# ---------------------------------------------------------------------------
# Prompt library
# ---------------------------------------------------------------------------


@router.get("/prompts", summary="Every prompt this platform sends a model")
def list_prompts(
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> dict:
    """The library, for review and for audit.

    A QE lead asked to sign off on what an agent tells a model has, until now,
    had to read the source of whichever agent ran. Each entry carries the exact
    text, its version, and why the last version changed.
    """
    entries = [template.to_dict() for template in prompt_templates()]
    return {
        "prompts": entries,
        "total": len(entries),
        "note": (
            "Context is never interpolated into these instructions. It is fenced "
            "with a per-run nonce and labelled as data; see /prompts/{prompt_id}."
        ),
    }


@router.get("/prompts/{prompt_id}", summary="One prompt, with its change history")
def read_prompt(
    prompt_id: str,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> dict:
    from app.ai.prompts import PromptError  # noqa: PLC0415

    try:
        template = get_prompt(prompt_id)
    except PromptError as error:
        raise NotFoundError(str(error)) from None
    return template.to_dict()


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


@router.get("/dashboard", summary="Executive dashboard metrics")
def dashboard(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    project_id: Annotated[str, Query()],
    window_days: Annotated[int, Query(ge=7, le=180)] = 30,
) -> dict:
    if session.get(Project, project_id) is None:
        raise NotFoundError(f"Project '{project_id}' was not found.")
    return AnalyticsService(session).dashboard(project_id, window_days=window_days)


# ---------------------------------------------------------------------------
# AI providers and models
# ---------------------------------------------------------------------------

ai_router = APIRouter(prefix="/ai", tags=["AI Configuration"])


@ai_router.get("/providers", summary="AI provider connectivity status")
def providers(
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
) -> dict:
    """Connectivity and configuration status. Secret values are never returned."""
    return {
        "default_provider": settings.default_llm_provider,
        "demo_mode": settings.demo_mode,
        "providers": [redact_secrets(entry) for entry in provider_health()],
    }


@ai_router.post("/providers/test", summary="Test provider connectivity")
def test_provider(
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    provider: Annotated[str, Query()],
) -> dict:
    from app.ai.providers.registry import _PROVIDER_CLASSES  # noqa: PLC0415

    provider_class = _PROVIDER_CLASSES.get(provider)
    if provider_class is None:
        raise NotFoundError(f"Provider '{provider}' is not registered.")
    return redact_secrets(provider_class().health_check())


@ai_router.get("/models", summary="Model catalogue")
def models(
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    provider: Annotated[str | None, Query()] = None,
) -> list[dict]:
    entries = full_catalog() if provider is None else [
        item for item in full_catalog() if item["provider"] == provider
    ]
    return [
        {
            "provider": entry["provider"],
            "model_key": entry["model_key"],
            "display_name": entry["display_name"],
            "tier": entry["tier"],
            "capabilities": entry["capabilities"],
            "context_window": entry["context_window"],
            "max_output_tokens": entry["max_output_tokens"],
            "input_cost_per_1k": entry["input_cost_per_1k"],
            "output_cost_per_1k": entry["output_cost_per_1k"],
            # Azure addresses a deployment; OpenAI addresses the model directly.
            "deployment": entry.get("deployment"),
        }
        for entry in entries
    ]


@ai_router.get("/routing", summary="Capability routing policies")
def routing(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    project_id: Annotated[str | None, Query()] = None,
) -> list[dict]:
    statement = select(LLMRoutingPolicy).where(LLMRoutingPolicy.is_active.is_(True))
    if project_id:
        statement = statement.where(
            (LLMRoutingPolicy.project_id == project_id) | (LLMRoutingPolicy.project_id.is_(None))
        )
    rows = list(session.execute(statement.order_by(LLMRoutingPolicy.priority)).scalars().all())
    return [
        {
            "id": row.id,
            "name": row.name,
            "capability": row.capability,
            "complexity": row.complexity,
            "provider_key": row.provider_key,
            "model_key": row.model_key,
            "fallback_provider_key": row.fallback_provider_key,
            "fallback_model_key": row.fallback_model_key,
            "max_tokens": row.max_tokens,
            "temperature": row.temperature,
            "notes": row.notes,
            "project_id": row.project_id,
        }
        for row in rows
    ]


# ---------------------------------------------------------------------------
# Vector store
# ---------------------------------------------------------------------------

vector_router = APIRouter(prefix="/vector", tags=["Vector Store"])


@vector_router.get("/health", summary="Vector store health")
def vector_health(
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
) -> dict:
    return get_vector_store().health()


@vector_router.get("/collections", summary="Chroma collections and vector counts")
def vector_collections(
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
) -> list[dict]:
    return get_vector_store().list_collections()


@vector_router.post("/reindex", response_model=MessageResponse, status_code=202, summary="Rebuild the index")
def vector_reindex(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("knowledge:write"))],
    project_id: Annotated[str, Query()],
) -> MessageResponse:
    from app.seed.runner import index_project_knowledge  # noqa: PLC0415

    project = session.get(Project, project_id)
    if project is None:
        raise NotFoundError(f"Project '{project_id}' was not found.")

    job = job_queue.submit(
        f"reindex:{project_id}", index_project_knowledge, project.key, job_metadata={"project_id": project_id}
    )
    return MessageResponse(message="Re-indexing started.", details={"job_id": job.job_id})


# ---------------------------------------------------------------------------
# MCP
# ---------------------------------------------------------------------------

mcp_router = APIRouter(prefix="/mcp", tags=["MCP"])


@mcp_router.get("/servers", summary="MCP server inventory with discoverable tools")
def mcp_servers(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
    project_id: Annotated[str, Query()],
) -> list[dict]:
    if session.get(Project, project_id) is None:
        raise NotFoundError(f"Project '{project_id}' was not found.")
    return MCPRegistry(session, project_id).describe()


@mcp_router.post("/invoke", summary="Invoke an MCP tool")
def invoke_tool(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
    project_id: Annotated[str, Query()],
    server: Annotated[str, Query()],
    tool: Annotated[str, Query()],
    arguments: dict | None = None,
) -> dict:
    """Direct tool invocation for the MCP explorer.

    Governance still applies: the registry enforces allowlists, environment
    restrictions and approval requirements exactly as it does for agents.
    """
    registry = MCPRegistry(session, project_id)
    result = registry.invoke(server, tool, arguments or {})
    return result.to_dict()


# ---------------------------------------------------------------------------
# System / demo
# ---------------------------------------------------------------------------

system_router = APIRouter(prefix="/system", tags=["System"])


@system_router.get("/info", summary="Platform configuration summary")
def system_info() -> dict:
    """Unauthenticated: drives the demo-mode badge and the login screen."""
    store = get_vector_store()
    health = store.health()
    return {
        "app_name": settings.app_name,
        "version": settings.app_version,
        "environment": settings.app_env,
        "demo_mode": settings.demo_mode,
        "default_llm_provider": settings.default_llm_provider,
        "playwright_enabled": settings.playwright_enabled,
        "vector_store": {
            "provider": health.get("provider"),
            "status": health.get("status"),
            "mode": health.get("mode"),
            "total_vectors": health.get("total_vectors", 0),
        },
        "database": "postgresql" if not settings.is_sqlite else "sqlite",
    }


@system_router.get("/jobs", summary="Background job status")
def system_jobs(
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    limit: Annotated[int, Query(ge=1, le=200)] = 25,
) -> dict:
    return {
        "jobs": [job.to_dict() for job in job_queue.list_jobs(limit)],
        "dead_letters": job_queue.dead_letters(10),
    }


@system_router.post("/demo/reset", response_model=MessageResponse, status_code=202, summary="Reset demo data")
def reset_demo(
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
) -> MessageResponse:
    """Rebuild the demo dataset from scratch. Only available in demo mode."""
    if not settings.demo_mode:
        raise NotFoundError("Demo reset is only available while DEMO_MODE is enabled.")

    from app.seed.runner import seed_all  # noqa: PLC0415

    job = job_queue.submit("demo-reset", seed_all, reset=True)
    return MessageResponse(
        message="Demo reset started. This rebuilds all projects, history and vector indexes.",
        details={"job_id": job.job_id},
    )
