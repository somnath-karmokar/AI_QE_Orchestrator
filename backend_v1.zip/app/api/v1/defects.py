"""Defect intelligence, RCA and prediction endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, or_, select

from app.api.deps import DbSession, Pagination, require_permission
from app.core.errors import NotFoundError, ValidationError
from app.core.security import Principal
from app.models.agent import Agent
from app.models.defect import Defect, DefectPrediction, RootCauseAnalysis
from app.schemas.common import Page
from app.schemas.entities import (
    DefectAnalyzeRequest,
    DefectOut,
    DefectPredictionOut,
    RCADecision,
    RCAOut,
    RunDetail,
)
from app.services.analytics_service import AnalyticsService
from app.services.run_service import RunService

router = APIRouter(tags=["Defect Intelligence"])


@router.get("/defects", response_model=Page[DefectOut], summary="List defects")
def list_defects(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
    project_id: Annotated[str, Query()],
    status: Annotated[str | None, Query()] = None,
    severity: Annotated[str | None, Query()] = None,
    module: Annotated[str | None, Query()] = None,
    cluster_key: Annotated[str | None, Query()] = None,
    search: Annotated[str | None, Query()] = None,
) -> Page[DefectOut]:
    statement = select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
    if status:
        statement = statement.where(Defect.status == status)
    if severity:
        statement = statement.where(Defect.severity == severity)
    if module:
        statement = statement.where(Defect.module == module)
    if cluster_key:
        statement = statement.where(Defect.cluster_key == cluster_key)
    if search:
        pattern = f"%{search}%"
        statement = statement.where(
            or_(Defect.title.ilike(pattern), Defect.external_key.ilike(pattern))
        )

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(Defect.created_at.desc()).limit(pagination.limit).offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[DefectOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/defects/insights", summary="Defect intelligence summary")
def defect_insights(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
    project_id: Annotated[str, Query()],
) -> dict:
    return AnalyticsService(session).defect_insights(project_id)


@router.get("/defects/{defect_id}", response_model=DefectOut, summary="Get a defect")
def get_defect(
    defect_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
) -> DefectOut:
    row = session.get(Defect, defect_id)
    if row is None or row.is_deleted:
        raise NotFoundError(f"Defect '{defect_id}' was not found.")
    return DefectOut.model_validate(row)


@router.get("/defects/{defect_id}/analyses", summary="AI analyses for a defect")
def defect_analyses(
    defect_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
) -> list[dict]:
    defect = session.get(Defect, defect_id)
    if defect is None:
        raise NotFoundError(f"Defect '{defect_id}' was not found.")
    return [
        {
            "id": item.id,
            "agent_key": item.agent_key,
            "analysis_type": item.analysis_type,
            "summary": item.summary,
            "recommended_severity": item.recommended_severity,
            "recommended_priority": item.recommended_priority,
            "confidence": item.confidence,
            "findings": item.findings,
            "recommendations": item.recommendations,
            "accepted": item.accepted,
            "reviewed_by": item.reviewed_by,
            "created_at": item.created_at.isoformat(),
        }
        for item in defect.analyses
    ]


@router.post("/defects/analyze", response_model=RunDetail, summary="Run RCA on a defect or failure")
def analyze(
    payload: DefectAnalyzeRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:write"))],
) -> RunDetail:
    """Dispatch the appropriate RCA agent for the supplied subject."""
    if not any([payload.defect_id, payload.execution_id, payload.execution_test_id]):
        raise ValidationError(
            "Supply a defect_id, execution_id or execution_test_id to analyse."
        )

    agent_key = "automated-defect-rca" if payload.defect_id else "automated-rca"
    agent = session.execute(
        select(Agent).where(Agent.key == agent_key, Agent.project_id.is_(None))
    ).scalar_one_or_none()
    if agent is None:
        raise NotFoundError(f"The '{agent_key}' agent is not registered on this platform.")

    inputs = {
        key: value
        for key, value in {
            "defect_id": payload.defect_id,
            "execution_id": payload.execution_id,
            "execution_test_id": payload.execution_test_id,
        }.items()
        if value
    }

    service = RunService(session)
    run = service.start_agent_run(
        agent_id=agent.id,
        project_id=payload.project_id,
        inputs=inputs,
        triggered_by=principal.email,
    )
    if payload.synchronous:
        run = service.run_synchronously(run)
        session.refresh(run)
    else:
        service.dispatch(run)
        session.refresh(run)
    return RunDetail.model_validate(run)


# ---------------------------------------------------------------------------
# RCA
# ---------------------------------------------------------------------------


@router.get("/rca", response_model=Page[RCAOut], summary="List root cause analyses")
def list_rca(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
    project_id: Annotated[str, Query()],
    status: Annotated[str | None, Query()] = None,
    category: Annotated[str | None, Query()] = None,
) -> Page[RCAOut]:
    statement = select(RootCauseAnalysis).where(RootCauseAnalysis.project_id == project_id)
    if status:
        statement = statement.where(RootCauseAnalysis.status == status)
    if category:
        statement = statement.where(RootCauseAnalysis.category == category)

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(RootCauseAnalysis.created_at.desc())
            .limit(pagination.limit)
            .offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[RCAOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/rca/{rca_id}", response_model=RCAOut, summary="Get a root cause analysis")
def get_rca(
    rca_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
) -> RCAOut:
    row = session.get(RootCauseAnalysis, rca_id)
    if row is None:
        raise NotFoundError(f"Root cause analysis '{rca_id}' was not found.")
    return RCAOut.model_validate(row)


@router.post("/rca/{rca_id}/decide", response_model=RCAOut, summary="Accept or reject an RCA")
def decide_rca(
    rca_id: str,
    payload: RCADecision,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:write"))],
) -> RCAOut:
    row = session.get(RootCauseAnalysis, rca_id)
    if row is None:
        raise NotFoundError(f"Root cause analysis '{rca_id}' was not found.")

    row.status = "accepted" if payload.decision == "accept" else "rejected"
    row.reviewed_by = principal.email
    row.reviewed_at = datetime.now(UTC)
    if payload.notes:
        row.recommended_action = f"{row.recommended_action or ''}\n\nReviewer note: {payload.notes}".strip()
    session.flush()
    return RCAOut.model_validate(row)


# ---------------------------------------------------------------------------
# Predictions
# ---------------------------------------------------------------------------


@router.get("/predictions", response_model=list[DefectPredictionOut], summary="Defect risk predictions")
def list_predictions(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("defect:read"))],
    project_id: Annotated[str, Query()],
    risk_band: Annotated[str | None, Query()] = None,
) -> list[DefectPredictionOut]:
    statement = select(DefectPrediction).where(DefectPrediction.project_id == project_id)
    if risk_band:
        statement = statement.where(DefectPrediction.risk_band == risk_band)
    rows = list(
        session.execute(statement.order_by(DefectPrediction.probability.desc())).scalars().all()
    )
    return [DefectPredictionOut.model_validate(row) for row in rows]
