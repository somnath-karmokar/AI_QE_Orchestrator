"""Run inspection, control and live event streaming."""

from __future__ import annotations

import asyncio
import json
from typing import Annotated

from fastapi import APIRouter, Depends, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from sqlalchemy import select

from app.api.deps import DbSession, Pagination, require_permission
from app.core.errors import AuthenticationError, NotFoundError
from app.core.events import event_bus, execution_topic, run_topic
from app.core.logging import get_logger
from app.core.security import Principal, principal_from_token
from app.models.run import AgentMessage, AgentRun
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import RunDetail, RunSummary
from app.services.run_collaboration import run_collaboration
from app.services.run_service import RunService

logger = get_logger(__name__)
router = APIRouter(prefix="/runs", tags=["Runs"])

# How long a stream waits before emitting a keep-alive, in seconds.
_HEARTBEAT_SECONDS = 20.0


@router.get("", response_model=Page[RunSummary], summary="List runs")
def list_runs(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
    project_id: Annotated[str | None, Query()] = None,
    status: Annotated[str | None, Query()] = None,
) -> Page[RunSummary]:
    rows, total = RunService(session).list_runs(
        project_id=project_id, status=status, limit=pagination.limit, offset=pagination.offset
    )
    return Page(
        items=[RunSummary.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/{run_id}", response_model=RunDetail, summary="Get run detail with every step")
def get_run(
    run_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
) -> RunDetail:
    return RunDetail.model_validate(RunService(session).get(run_id))


@router.get("/{run_id}/collaboration", summary="How the agents in a run worked together")
def get_run_collaboration(
    run_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
) -> dict:
    """Graph state, the agent-to-agent conversation and the shared context of one run."""
    return run_collaboration(session, RunService(session).get(run_id))


@router.get("/{run_id}/messages", summary="Run event log")
def run_messages(
    run_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
) -> list[dict]:
    rows = list(
        session.execute(
            select(AgentMessage).where(AgentMessage.run_id == run_id).order_by(AgentMessage.sequence)
        )
        .scalars()
        .all()
    )
    return [
        {
            "id": row.id,
            "event_type": row.event_type,
            "role": row.role,
            "content": row.content,
            "payload": row.payload,
            "created_at": row.created_at.isoformat(),
        }
        for row in rows
    ]


@router.post("/{run_id}/cancel", response_model=RunDetail, summary="Cancel a run")
def cancel_run(
    run_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("run:cancel"))],
) -> RunDetail:
    return RunDetail.model_validate(RunService(session).cancel(run_id, actor=principal.email))


@router.post("/{run_id}/resume", response_model=RunDetail, summary="Resume a paused run")
def resume_run(
    run_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:run"))],
) -> RunDetail:
    run = RunService(session).resume(run_id, actor=principal.email)
    session.refresh(run)
    return RunDetail.model_validate(run)


@router.delete("/{run_id}", response_model=MessageResponse, summary="Delete a run record")
def delete_run(
    run_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("run:cancel"))],
) -> MessageResponse:
    run = session.get(AgentRun, run_id)
    if run is None:
        raise NotFoundError(f"Run '{run_id}' was not found.")
    session.delete(run)
    session.flush()
    return MessageResponse(message="Run deleted.")


# ---------------------------------------------------------------------------
# Live streaming
# ---------------------------------------------------------------------------


@router.get("/{run_id}/stream", summary="Server-sent event stream of run progress")
async def stream_run(
    run_id: str,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
) -> StreamingResponse:
    """SSE stream. Replays buffered events first so a late subscriber catches up."""
    topic = run_topic(run_id)
    queue = event_bus.subscribe(topic)

    async def generator():  # noqa: ANN202
        try:
            yield ": connected\n\n"
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=_HEARTBEAT_SECONDS)
                except TimeoutError:
                    # Keep-alive so proxies do not drop an idle connection.
                    yield ": keep-alive\n\n"
                    continue

                yield f"event: {event['type']}\ndata: {json.dumps(event, default=str)}\n\n"
                if event["type"] in {"run_completed", "run_failed", "run_paused"}:
                    break
        finally:
            event_bus.unsubscribe(topic, queue)

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


@router.websocket("/{run_id}/ws")
async def run_websocket(websocket: WebSocket, run_id: str) -> None:
    """WebSocket stream of run progress.

    The browser WebSocket API cannot set an Authorization header, so the token
    arrives as a query parameter and is validated before the socket is accepted.
    """
    token = websocket.query_params.get("token")
    try:
        if not token:
            raise AuthenticationError("A token query parameter is required.")
        principal = principal_from_token(token)
        principal.require("run:read")
    except Exception:  # noqa: BLE001
        await websocket.close(code=4401, reason="Unauthorized")
        return

    await websocket.accept()
    topic = run_topic(run_id)
    queue = event_bus.subscribe(topic)

    try:
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=_HEARTBEAT_SECONDS)
            except TimeoutError:
                await websocket.send_json({"type": "heartbeat", "topic": topic})
                continue

            await websocket.send_json(event)
            if event["type"] in {"run_completed", "run_failed", "run_paused"}:
                break
    except WebSocketDisconnect:
        logger.debug("run_ws_disconnected", run_id=run_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning("run_ws_error", run_id=run_id, error=str(exc)[:200])
    finally:
        event_bus.unsubscribe(topic, queue)
        try:
            await websocket.close()
        except RuntimeError:
            pass


@router.websocket("/executions/{execution_id}/ws")
async def execution_websocket(websocket: WebSocket, execution_id: str) -> None:
    """Live test-by-test progress for the Execution Center."""
    token = websocket.query_params.get("token")
    try:
        if not token:
            raise AuthenticationError("A token query parameter is required.")
        principal_from_token(token).require("execution:read")
    except Exception:  # noqa: BLE001
        await websocket.close(code=4401, reason="Unauthorized")
        return

    await websocket.accept()
    topic = execution_topic(execution_id)
    queue = event_bus.subscribe(topic)

    try:
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=_HEARTBEAT_SECONDS)
            except TimeoutError:
                await websocket.send_json({"type": "heartbeat", "topic": topic})
                continue

            await websocket.send_json(event)
            if event["type"] == "execution_completed":
                break
    except WebSocketDisconnect:
        logger.debug("execution_ws_disconnected", execution_id=execution_id)
    finally:
        event_bus.unsubscribe(topic, queue)
        try:
            await websocket.close()
        except RuntimeError:
            pass
