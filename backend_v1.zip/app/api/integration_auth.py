"""Authenticating another platform, and telling it only what it may know.

Every failure here returns the same 401 with the same wording. A caller must not
be able to tell an unknown token from a revoked one, or a flow it may not run
from a flow that does not exist -- otherwise the endpoint becomes a way to
enumerate what a project contains.
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from datetime import UTC, datetime
from typing import Annotated

from fastapi import Depends, Header
from sqlalchemy import select

from app.api.deps import DbSession
from app.core.errors import (
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    RateLimitedError,
)
from app.core.logging import get_logger
from app.core.security import hash_api_token
from app.models.integration import IntegrationClient

logger = get_logger(__name__)

# One message for every authentication failure, whatever the real reason.
_DENIED = "A valid X-API-Key header is required."

# One message for every "you cannot have this", whatever the real reason. It
# deliberately does not echo the id: two callers asking for an ungranted flow
# and a non-existent one must get byte-identical answers.
NOT_AVAILABLE = "No such resource is available to this API key."


def resolve_client(session, token: str | None) -> IntegrationClient | None:  # noqa: ANN001
    """Is this token a key that may be used right now?

    The one place that decides. It used to be two: the authenticating
    dependency below, and the OpenAPI document's optional-auth path, which
    checked deletion and revocation but not expiry. An expired key was
    therefore refused at every endpoint that runs anything and still served a
    document naming the project's flows, their ids and their input schemas --
    which is most of what expiry is meant to take away.

    Returns None rather than raising, so a caller can choose between refusing
    and falling back.
    """
    if not token:
        return None

    client = (
        session.execute(
            select(IntegrationClient).where(
                IntegrationClient.token_hash == hash_api_token(token),
                IntegrationClient.is_deleted.is_(False),
            )
        )
        .scalars()
        .first()
    )
    if client is None or not client.is_active:
        return None
    if client.expires_at and client.expires_at < datetime.now(UTC):
        return None
    return client


def authenticate_client(
    session: DbSession,
    x_api_key: Annotated[str | None, Header(alias="X-API-Key")] = None,
) -> IntegrationClient:
    """Resolve the token to a client, or refuse without explaining why."""
    if not x_api_key:
        raise AuthenticationError(_DENIED)

    client = resolve_client(session, x_api_key)
    if client is None:
        raise AuthenticationError(_DENIED)

    _enforce_rate_limit(client)

    client.last_used_at = datetime.now(UTC)
    client.call_count += 1
    session.flush()
    return client


# Per-key fixed-window counters. The global middleware limiter buckets by client
# IP, which is the wrong unit here: two integrations behind one NAT would share
# a budget, and a key's own advertised limit would mean nothing. A shared store
# replaces this dict in a multi-node deployment; the behaviour stays identical.
_key_buckets: dict[str, deque[float]] = defaultdict(deque)


def _enforce_rate_limit(client: IntegrationClient) -> None:
    """Hold the key to the limit the manifest advertises.

    Advertising a limit that is not enforced is worse than advertising none: an
    integrator paces against a number that does nothing, and the first real
    constraint they meet is a different one they never saw.
    """
    limit = client.rate_limit_per_minute
    if limit <= 0:
        return

    now = time.time()
    bucket = _key_buckets[client.id]
    while bucket and now - bucket[0] > 60:
        bucket.popleft()

    if len(bucket) >= limit:
        retry_after = max(1, int(60 - (now - bucket[0])))
        logger.info("integration_rate_limited", client=client.name, limit=limit)
        raise RateLimitedError(
            f"This API key is limited to {limit} requests per minute.",
            details={"limit_per_minute": limit, "retry_after_seconds": retry_after},
        )
    bucket.append(now)


CurrentClient = Annotated[IntegrationClient, Depends(authenticate_client)]


def require_scope(scope: str):  # noqa: ANN201 - FastAPI dependency factory
    """Refuse a call the token was never granted, and name the missing scope.

    Naming the scope is safe and useful: the caller already holds the token, so
    this tells them how to fix their own configuration rather than revealing
    anything about the project.
    """

    def _dependency(client: CurrentClient) -> IntegrationClient:
        if not client.has_scope(scope):
            raise AuthorizationError(
                f"This API key does not have the '{scope}' scope.",
                details={"required_scope": scope, "granted_scopes": client.scopes or []},
            )
        return client

    return _dependency


def resolve_flow_or_deny(session, client: IntegrationClient, flow_id: str):  # noqa: ANN001, ANN201
    """The flow this client may run, or a 404 that says nothing.

    A flow the client may not run and a flow that does not exist give the same
    answer, so the endpoint cannot be used to discover what exists.
    """
    from app.models.flow import AgentFlow  # noqa: PLC0415

    flow = session.get(AgentFlow, flow_id)
    if (
        flow is None
        or flow.is_deleted
        or flow.project_id != client.project_id
        or not client.may_run_flow(flow_id)
    ):
        # The real reason is logged for operators, never returned to the caller.
        logger.info("integration_flow_denied", client=client.name, flow_id=flow_id)
        raise NotFoundError(NOT_AVAILABLE)
    return flow
