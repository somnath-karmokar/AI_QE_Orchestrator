"""Intent taxonomy and entity extraction for the conversational copilot.

Entities are resolved against real project data, not guessed: a story key is
only accepted if that requirement exists, a module only if the project declares
it. That is what lets the planner hand an agent inputs it can actually use.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.defect import Defect
from app.models.project import Project
from app.models.testing import Execution, Requirement

# ---------------------------------------------------------------------------
# Intent taxonomy
# ---------------------------------------------------------------------------
# Each intent maps to what the platform should *do*, and carries example
# phrasings that are embedded alongside agent descriptions so that matching is
# semantic rather than keyword-driven.

INTENTS: dict[str, dict[str, Any]] = {
    "assess_requirement": {
        "label": "Assess requirement readiness",
        "examples": [
            "is this story ready for testing",
            "check the completeness of PAY-201",
            "does this requirement have enough detail to write tests",
            "review the acceptance criteria quality",
        ],
    },
    "generate_tests": {
        "label": "Generate scenarios and test cases",
        "examples": [
            "generate test scenarios for this story",
            "generate test cases",
            "create test cases for the payments module",
            "design test cases from the acceptance criteria",
            "what should we test for this requirement",
            "design tests covering negative paths",
            "write the test steps for this story",
        ],
    },
    "generate_automation": {
        "label": "Generate automation code",
        "examples": [
            "write playwright scripts for login",
            "generate automation code",
            "create the page objects for payments",
            "automate PAY-201",
            "automate this story end to end",
            "take this requirement all the way to automation",
            "build the automation for this requirement",
        ],
    },
    "generate_test_data": {
        "label": "Generate or review test data",
        "examples": [
            "create test data for beneficiaries",
            "generate synthetic records for payments",
            "is our test data stale",
            "make masked data for the profile module",
        ],
    },
    "run_execution": {
        "label": "Run a test suite",
        "examples": [
            "run the regression suite now",
            "execute the smoke tests",
            "kick off a test run for payments",
            "start testing on chromium",
            "trigger the suite",
            "launch a test execution",
        ],
    },
    "diagnose_failure": {
        "label": "Diagnose a failure or defect",
        "examples": [
            "why did this test fail",
            "what is the root cause of the payment failures",
            "analyse the last failed execution",
            "investigate DEF-0003",
        ],
    },
    "predict_risk": {
        "label": "Assess quality risk",
        "examples": [
            "where is the risk in this release",
            "which modules are most likely to break",
            "predict defects for the next sprint",
            "what should we worry about",
        ],
    },
    "optimize_regression": {
        "label": "Optimise the regression suite",
        "examples": [
            "which tests should we run for this change",
            "optimise the regression suite",
            "we changed payments, what needs retesting",
            "reduce our suite runtime",
        ],
    },
    "coverage_report": {
        "label": "Report coverage and traceability",
        "examples": [
            "what is our test coverage",
            "which requirements are untested",
            "show me the traceability",
            "are there gaps in coverage",
        ],
    },
    "quality_status": {
        "label": "Summarise quality status",
        "examples": [
            "how is quality looking",
            "give me a status summary",
            "what is our pass rate",
            "are we ready to release",
        ],
    },
    "prepare_uat": {
        "label": "Prepare UAT material",
        "examples": [
            "prepare UAT scripts",
            "create business acceptance tests",
            "what do business users need to validate",
        ],
    },
    "accessibility_check": {
        "label": "Check accessibility compliance",
        "examples": [
            "check accessibility",
            "are we WCAG compliant",
            "run an a11y audit on accounts",
        ],
    },
    "knowledge_question": {
        "label": "Answer from project knowledge",
        "examples": [
            "what is the daily payment limit",
            "how does the cooling-off period work",
            "what does our SOP say about regression",
            "explain the session timeout rules",
            "what are our exit criteria",
            "what are our entry criteria for testing",
            "what does the standard require",
            "what is our policy on test data",
            "how are severity levels defined",
            "what are the performance targets",
            "explain the business rule",
        ],
    },
    "flow_explain": {
        "label": "Explain a flow",
        "examples": [
            "what does the requirement to automated test flow do",
            "which agents are in the RCA flow",
            "explain the regression intelligence flow",
            "how does that flow work",
            "who owns the release readiness flow",
            "when does the regression flow run next",
            "what inputs does this flow need",
        ],
    },
    "flow_health": {
        "label": "Report on a flow's health",
        "examples": [
            "how is the failure to RCA flow doing",
            "is the regression flow healthy",
            "what is the success rate of that flow",
            "how much does the UAT flow cost per run",
            "how often does the accessibility flow run",
            "how long does that flow take",
            "how is it doing",
        ],
    },
    "flow_run_review": {
        "label": "Review a flow run",
        "examples": [
            "why did the last run fail",
            "what happened in run 196",
            "which step failed in the last run of the RCA flow",
            "how did the agents collaborate in that run",
            "did the last run of the regression flow succeed",
            "why is that run waiting",
        ],
    },
    "flow_governance": {
        "label": "Report a flow's governance",
        "examples": [
            "is that flow under control",
            "what is the governance posture of the RCA flow",
            "who can run the release readiness flow",
            "does this flow have approval gates",
            "what is the budget for that flow",
        ],
    },
    "flow_inventory": {
        "label": "List and compare flows",
        "examples": [
            "which flows do we have",
            "which flows are scheduled",
            "which flows need attention",
            "which flow costs the most",
            "list the flows in this project",
            "which flows can CI trigger",
        ],
    },
    "navigate": {
        "label": "Navigate the platform",
        "examples": [
            "show me the defects",
            "open the flow builder",
            "take me to governance",
            "where do I see executions",
        ],
    },
}

# Where a navigation intent should send the user.
NAVIGATION_TARGETS: list[tuple[tuple[str, ...], str, str]] = [
    (("defect", "bug"), "/quality/defects", "Defect Intelligence"),
    (("root cause", "rca"), "/quality/rca", "Root Cause Analysis"),
    (("regression",), "/quality/regression", "Regression Intelligence"),
    (("traceab", "coverage matrix"), "/quality/traceability", "Traceability Matrix"),
    (("execution", "test run"), "/executions", "Execution Center"),
    (("marketplace", "agent catalog", "agent catalogue"), "/marketplace", "Agent Marketplace"),
    (("flow", "workflow"), "/flows", "Flow Builder"),
    (("knowledge", "documentation"), "/knowledge", "Knowledge Fabric"),
    (("governance", "policy", "approval", "audit"), "/governance", "Governance"),
    (("cost", "spend", "budget"), "/governance?tab=cost", "AI Cost Governance"),
    (("integration", "mcp", "connector"), "/integrations", "Integrations"),
    (("setting", "provider", "model"), "/settings", "Settings"),
    (("test case", "test design", "scenario"), "/testing/design", "Test Design"),
    (("test data",), "/testing/data", "Test Data"),
    (("automation", "script"), "/testing/automation", "Automation"),
    (("planning", "requirement"), "/testing/planning", "Test Planning"),
    (("dashboard", "overview", "home"), "/", "Quality Overview"),
]

# Flow questions are close cousins ("what does it do" vs "how is it doing"), and an
# embedding alone mixes them up. These patterns decide when the wording is explicit;
# anything they do not cover still falls through to semantic classification.
FLOW_INTENT_PATTERNS: list[tuple[str, str]] = [
    (r"\bwhich flows?\b|\blist (the )?flows?\b|\bhow many flows?\b|\bwhat flows?\b|\ball (our|the) flows?\b", "flow_inventory"),
    (r"\bwhy (did|does|is)\b.*\b(run|fail|stop|pause|wait)|\bwhat happened\b|\bwhich step (failed|broke)\b"
     r"|\brun\s*#?\s*\d+\b|\bdid the (last|latest) run\b|\bhow did the agents\b", "flow_run_review"),
    (r"\bunder control\b|\bgovernance\b|\bposture\b|\bwho can run\b|\bapproval gates?\b|\baudit(ed)?\b"
     r"|\bcompliance\b|\bbudget (for|of)\b", "flow_governance"),
    (r"\bhow (is|are|was)\b|\bhealth(y|)\b|\bsuccess rate\b|\bhow often\b|\bhow long\b|\bhow much\b"
     r"|\bcost per run\b|\bperform(ing|ance)\b|\bdoing\b|\bstatus of\b|\breliab", "flow_health"),
    (r"\bwhat does\b|\bwhat is the\b.*\bflow\b|\bexplain\b|\bhow does\b.*\bwork\b|\bwhich agents?\b"
     r"|\bwho owns\b|\bwhen does\b.*\brun\b|\bwhat inputs?\b|\bsteps? (in|of)\b|\bdescribe\b", "flow_explain"),
]

_FLOW_WORDS = re.compile(r"\bflows?\b|\bworkflows?\b|\brun\s*#?\s*\d+\b|\b(last|latest) run\b", re.IGNORECASE)


def flow_intent_hint(message: str, *, has_flow_context: bool = False) -> str | None:
    """A flow intent when the wording makes it explicit, otherwise None.

    `has_flow_context` is true once a flow has been resolved (named here or carried
    from an earlier turn), which is what lets "how is it doing?" be a flow question.
    """
    if not (has_flow_context or _FLOW_WORDS.search(message)):
        return None
    lowered = message.lower()
    for pattern, intent in FLOW_INTENT_PATTERNS:
        if re.search(pattern, lowered):
            return intent
    return None


_STORY_KEY = re.compile(r"\b([A-Z]{2,6}-\d{1,5})\b")
_DEFECT_KEY = re.compile(r"\b(DEF-\d{3,5})\b", re.IGNORECASE)
_BROWSERS = ("chromium", "firefox", "webkit", "chrome", "safari")
_SUITES = ("regression", "smoke", "functional")


@dataclass
class ExtractedEntities:
    """Everything the planner could resolve from the message, all verified."""

    requirement_key: str | None = None
    requirement_id: str | None = None
    defect_key: str | None = None
    defect_id: str | None = None
    execution_id: str | None = None
    module: str | None = None
    modules: list[str] = field(default_factory=list)
    browser: str | None = None
    suite_type: str | None = None
    unresolved: list[str] = field(default_factory=list)
    # ----- the flow or run a question is about -----
    flow_id: str | None = None
    flow_key: str | None = None
    flow_name: str | None = None
    run_id: str | None = None
    run_number: int | None = None
    # Flows that matched the wording about equally; the copilot asks which was meant.
    flow_candidates: list[str] = field(default_factory=list)
    # A flow the user named that this project does not have.
    unknown_flow: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            key: value
            for key, value in {
                "requirement_key": self.requirement_key,
                "requirement_id": self.requirement_id,
                "defect_key": self.defect_key,
                "defect_id": self.defect_id,
                "execution_id": self.execution_id,
                "module": self.module,
                "modules": self.modules or None,
                "browser": self.browser,
                "suite_type": self.suite_type,
                "flow_id": self.flow_id,
                "flow_key": self.flow_key,
                "flow_name": self.flow_name,
                "run_id": self.run_id,
                "run_number": self.run_number,
                "flow_candidates": self.flow_candidates or None,
                "unknown_flow": self.unknown_flow,
                "unresolved": self.unresolved or None,
            }.items()
            if value
        }


def extract_entities(
    session: Session, message: str, project: Project, carried: dict[str, Any] | None = None
) -> ExtractedEntities:
    """Pull identifiers out of a message and verify each against the project.

    `carried` holds entities from earlier turns, so "now automate it" still
    knows which story "it" refers to.
    """
    entities = ExtractedEntities()
    lowered = message.lower()

    # ----- requirement key (verified) -----
    for candidate in _STORY_KEY.findall(message.upper()):
        if candidate.upper().startswith("DEF-"):
            continue
        requirement = session.execute(
            select(Requirement).where(
                Requirement.project_id == project.id,
                Requirement.external_key == candidate,
                Requirement.is_deleted.is_(False),
            )
        ).scalar_one_or_none()
        if requirement is not None:
            entities.requirement_key = requirement.external_key
            entities.requirement_id = requirement.id
            entities.module = entities.module or requirement.module
            break
        # Mentioned but not present — worth telling the user rather than ignoring.
        entities.unresolved.append(candidate)

    # ----- defect key (verified) -----
    for candidate in _DEFECT_KEY.findall(message):
        defect = session.execute(
            select(Defect).where(
                Defect.project_id == project.id,
                Defect.external_key == candidate.upper(),
                Defect.is_deleted.is_(False),
            )
        ).scalar_one_or_none()
        if defect is not None:
            entities.defect_key = defect.external_key
            entities.defect_id = defect.id
            entities.module = entities.module or defect.module
            break
        entities.unresolved.append(candidate.upper())

    # ----- module (matched against the project's declared modules) -----
    for module in project.modules or []:
        if module.lower() in lowered:
            entities.module = module
            if module not in entities.modules:
                entities.modules.append(module)
    # Common shorthands users actually type.
    aliases = {"payment": "Payments", "login": "Login", "auth": "Login",
               "account": "Accounts", "beneficiary": "Beneficiaries",
               "profile": "Customer Profile", "transaction": "Transaction History"}
    if not entities.module:
        for alias, module in aliases.items():
            if alias in lowered and module in (project.modules or []):
                entities.module = module
                entities.modules.append(module)
                break

    # ----- execution reference -----
    if any(phrase in lowered for phrase in ("last execution", "latest run", "last run", "recent execution")):
        execution = (
            session.execute(
                select(Execution)
                .where(Execution.project_id == project.id)
                .order_by(Execution.created_at.desc())
            )
            .scalars()
            .first()
        )
        if execution is not None:
            entities.execution_id = execution.id
    if "failed" in lowered and not entities.execution_id:
        execution = (
            session.execute(
                select(Execution)
                .where(Execution.project_id == project.id, Execution.failed > 0)
                .order_by(Execution.created_at.desc())
            )
            .scalars()
            .first()
        )
        if execution is not None:
            entities.execution_id = execution.id

    # ----- execution options -----
    for browser in _BROWSERS:
        if browser in lowered:
            entities.browser = {"chrome": "chromium", "safari": "webkit"}.get(browser, browser)
            break
    for suite in _SUITES:
        if suite in lowered:
            entities.suite_type = suite
            break

    # ----- the flow (and run) the question is about -----
    from app.copilot.flow_resolver import resolve as resolve_flow  # noqa: PLC0415 - avoids an import cycle

    reference = resolve_flow(session, message, project, carried)
    if reference.flow is not None:
        entities.flow_id = reference.flow.id
        entities.flow_key = reference.flow.key
        entities.flow_name = reference.flow.name
    if reference.run is not None:
        entities.run_id = reference.run.id
        entities.run_number = reference.run.run_number
    entities.flow_candidates = [flow.name for flow in reference.candidates]
    entities.unknown_flow = reference.named_but_unknown

    # ----- carry forward from earlier turns -----
    if carried:
        for attribute in ("requirement_key", "requirement_id", "defect_key", "defect_id", "execution_id", "module"):
            if getattr(entities, attribute) is None and carried.get(attribute):
                setattr(entities, attribute, carried[attribute])

    return entities


def navigation_target(message: str) -> tuple[str, str] | None:
    """Resolve a navigation request to a route and a human label."""
    lowered = message.lower()
    for keywords, route, label in NAVIGATION_TARGETS:
        if any(keyword in lowered for keyword in keywords):
            return route, label
    return None


def intent_corpus() -> list[tuple[str, str]]:
    """Flattened (intent, example) pairs used to build the intent index."""
    return [
        (intent, example)
        for intent, spec in INTENTS.items()
        for example in spec["examples"]
    ]
