"""The registered prompts.

Kept apart from `library` so the registry stays a mechanism and this stays a
list somebody can read end to end. Importing `app.ai.prompts` registers
everything here.

Ids are `agent.<agent-key>.<task>` for an agent's own instruction and
`shared.<name>` for text used by more than one. Bump `version` and add a
changelog line whenever wording changes in a way that could change answers;
`tests/test_prompt_library.py` holds every template to that.

**Values in an instruction.** Placeholders here are filled by `task_message`,
which accepts only numbers and booleans. Anything a caller can put free text
into -- a module name, a search query, a table -- is named in the instruction
and supplied as a fenced block, because the instruction itself sits outside the
fence and reads as operator text.
"""

from __future__ import annotations

from app.ai.prompts.library import PromptTemplate, register

# ---------------------------------------------------------------------------
# Shared
# ---------------------------------------------------------------------------

register(
    PromptTemplate(
        id="shared.agent_system",
        version=2,
        purpose=(
            "The system prompt under every agent: who it is, what it may assume, "
            "and the contract its answer must satisfy."
        ),
        inputs=(
            "instructions",
            "project_name",
            "business_domain",
            "environment_name",
            "untrusted_preamble",
            "output_schema",
        ),
        changelog=(
            "v1 - initial: role, project, output contract, and a one-line rule that "
            "retrieved content is untrusted.",
            "v2 - replaced that rule with the fence preamble. The old wording told the "
            "model context was untrusted but gave it no way to tell where context "
            "started and ended, so content that closed the delimiter read as operator "
            "instruction.",
        ),
        text=(
            "{instructions}\n\n"
            "Project: {project_name} ({business_domain}).\n"
            "Environment: {environment_name}.\n\n"
            "Rules:\n"
            "- Respond with a single JSON object matching the required schema.\n"
            "- Ground every claim in the supplied context; do not invent identifiers.\n"
            "- Provide a concise rationale and evidence, never internal deliberation.\n\n"
            "{untrusted_preamble}\n\n"
            "Required output schema:\n{output_schema}"
        ),
    )
)


# ---------------------------------------------------------------------------
# Requirements
# ---------------------------------------------------------------------------

register(
    PromptTemplate(
        id="agent.user-story-completeness.assess",
        version=1,
        purpose="Score a user story's testability and name what is missing.",
        text=(
            "Assess the testability of the user story in <story>. Score it 0-100, list every "
            "gap that would block test design, and recommend concrete additions."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.test-knowledge.summarise",
        version=2,
        purpose="Summarise what retrieved material establishes about a question.",
        changelog=(
            "v1 - initial; the question was interpolated into the instruction.",
            "v2 - the question moved into a fenced block. It is caller-supplied, and "
            "since the integration API the caller may be another platform.",
        ),
        text=(
            "Summarise what the material in <retrieved_context> establishes about the "
            "question in <query>. If it does not answer the question, say so."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.test-scenario-generator.generate",
        version=2,
        purpose="Turn a requirement into scenarios across positive, negative and edge cases.",
        inputs=("max_scenarios",),
        changelog=(
            "v1 - initial.",
            "v2 - the requirement moved into a fenced block; only the count is "
            "interpolated, and a count cannot carry an instruction.",
        ),
        text=(
            "Generate up to {max_scenarios} test scenarios for the requirement in "
            "<requirement>, covering positive, negative and edge cases. Give each a title, "
            "type, priority and risk level."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.test-design.expand",
        version=1,
        purpose="Expand scenarios into executable test cases.",
        text=(
            "Expand each scenario in <scenarios> into a test case with preconditions, "
            "numbered steps and a single expected result."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.test-planning.plan",
        version=2,
        purpose="Produce a risk-based test plan for a release scope.",
        changelog=(
            "v1 - initial; the scope string was interpolated into the instruction.",
            "v2 - scope moved into a fenced block.",
        ),
        text=(
            "Produce a risk-based test plan for the scope named in <scope>. Rank by risk, "
            "and say what you are choosing not to test and why."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.traceability-coverage.analyse",
        version=1,
        purpose="Report coverage from requirements through to execution.",
        text=(
            "Analyse traceability from requirements through scenarios, test cases, automation "
            "and execution. Report coverage percentages and name the uncovered requirements."
        ),
    )
)


# ---------------------------------------------------------------------------
# Automation
# ---------------------------------------------------------------------------

register(
    PromptTemplate(
        id="agent.auto-script-generator.generate",
        version=1,
        purpose="Write Playwright automation for a set of test cases.",
        text=(
            "Generate Python Playwright automation for the test cases in <test_cases>, using "
            "the page object pattern and resilient locators."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.test-execution.summarise",
        version=1,
        purpose="Summarise an execution and recommend what to do next.",
        text="Summarise the execution in <execution> and recommend the next action.",
    )
)

register(
    PromptTemplate(
        id="agent.automation-failure-analysis.triage",
        version=1,
        purpose="Confirm the triage of failures and apportion product vs automation fault.",
        inputs=("failure_count", "cause_count"),
        text=(
            "{failure_count} failure(s) reduced to {cause_count} distinct cause(s). For each "
            "cause in <failure_causes>, confirm or correct the classification, decide whether "
            "the product or the automation is at fault, and state the remedy."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.self-healing.propose-locator",
        version=2,
        purpose="Propose a replacement locator for an element whose selector has drifted.",
        changelog=(
            "v1 - initial.",
            "v2 - requires the evidence, and requires the model to decline when the "
            "candidates do not identify the same element. A confidence figure with "
            "nothing behind it was being persisted as though it predicted something.",
        ),
        text=(
            "Propose a replacement locator for each drifted element in <failures>, choosing "
            "from <locator_candidates>. Include a confidence score and the evidence "
            "supporting the choice. If the candidates do not identify the same element the "
            "original locator addressed, say so instead of proposing one."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.regression-suite-optimization.select",
        version=1,
        purpose="Choose the regression suite justified by a set of changes.",
        text=(
            "Select the optimal regression suite for the modules in <changed_modules>, and "
            "justify each inclusion and exclusion."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.performance-test-generator.generate",
        version=2,
        purpose="Write a performance test against a throughput and latency target.",
        inputs=("target_rps", "p95_ms"),
        changelog=(
            "v1 - initial; the module name was interpolated into the instruction.",
            "v2 - module moved into a fenced block. The targets stay interpolated: "
            "they are numbers, and a number cannot carry an instruction.",
        ),
        text=(
            "Generate a performance test for the module named in <module>, targeting "
            "{target_rps} RPS with a p95 under {p95_ms}ms."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.accessibility-test.audit",
        version=2,
        purpose="Audit a module against an accessibility standard and generate the checks.",
        changelog=(
            "v1 - initial; module and standard were interpolated into the instruction.",
            "v2 - both moved into fenced blocks.",
        ),
        text=(
            "Audit the module named in <module> against the standard named in <standard>, "
            "and generate the corresponding automated checks."
        ),
    )
)


# ---------------------------------------------------------------------------
# Quality
# ---------------------------------------------------------------------------

register(
    PromptTemplate(
        id="agent.defect-prediction.predict",
        version=1,
        purpose="Predict per-module defect likelihood over a horizon.",
        inputs=("horizon_days",),
        text=(
            "Predict defect likelihood per module over the next {horizon_days} days, using "
            "the history supplied. Justify each prediction with the evidence that drove it."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.automated-rca.analyse",
        version=1,
        purpose="Explain why a set of executions failed.",
        text=(
            "Determine the probable root cause of the failures in <failures>. Cite the "
            "evidence and give a calibrated confidence."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.duplicate-test-detection.review",
        version=1,
        purpose="Confirm which candidate test-case pairs are genuine duplicates.",
        text=(
            "Review the candidate duplicate pairs in <candidate_pairs>. Confirm genuine "
            "duplicates and recommend which case to retain."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.observability.trends",
        version=1,
        purpose="Read quality trends from a window of executions.",
        inputs=("window_days",),
        text=(
            "Analyse quality trends over the last {window_days} days from the executions "
            "supplied. Distinguish a trend from a single bad run."
        ),
    )
)


# ---------------------------------------------------------------------------
# Business
# ---------------------------------------------------------------------------

register(
    PromptTemplate(
        id="agent.uat-assistant.rewrite",
        version=1,
        purpose="Rewrite test cases as UAT scripts a business user can execute.",
        text=(
            "Rewrite the test cases in <test_cases> as UAT scripts a business user can "
            "execute, with plain-language steps and clear sign-off criteria."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.jira-defect-assistant.draft",
        version=1,
        purpose="Draft a defect from an analysis, checking for duplicates first.",
        text=(
            "Draft a defect from the analysis supplied. Check <similar_existing_defects> "
            "first and flag a duplicate if one exists."
        ),
    )
)


# ---------------------------------------------------------------------------
# Test data
# ---------------------------------------------------------------------------

register(
    PromptTemplate(
        id="agent.test-data-generator.generate",
        version=2,
        purpose="Generate synthetic records supporting a set of test cases.",
        inputs=("record_count",),
        changelog=(
            "v1 - initial; the module name was interpolated into the instruction.",
            "v2 - module moved into a fenced block.",
        ),
        text=(
            "Generate {record_count} synthetic records for the module named in <module>, "
            "supporting the test cases in <test_cases>. Include valid, invalid and boundary "
            "variants, and mask anything resembling personal data."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.test-data-management.audit",
        version=1,
        purpose="Audit test data sets for staleness, masking and coverage.",
        text=(
            "Audit the test data sets in <data_sets> for staleness, masking compliance and "
            "coverage gaps."
        ),
    )
)

register(
    PromptTemplate(
        id="agent.db-script-generator.generate",
        version=2,
        purpose="Generate parameterised setup, validation and cleanup SQL.",
        changelog=(
            "v1 - initial; the table name and field list were interpolated into the "
            "instruction.",
            "v2 - both moved into fenced blocks. A table name reaches this agent from "
            "caller input, and this prompt writes SQL.",
        ),
        text=(
            "Generate setup, validation and cleanup SQL for the table named in <table> with "
            "the fields in <fields>. Parameterise every value -- never concatenate a value "
            "into a statement."
        ),
    )
)
