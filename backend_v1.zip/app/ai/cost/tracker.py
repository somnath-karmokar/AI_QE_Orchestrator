"""Token/cost accounting and budget enforcement (spec section 17).

Every AI invocation writes an `llm_usage` row carrying provider, model,
deployment, tokens, latency and estimated cost. Budgets are checked *before*
the call at three scopes, so an over-budget run stops instead of silently
spending:

  * project -- everything the project has spent;
  * flow    -- one run of the flow;
  * agent   -- one invocation of the agent (a run step, retries included),
               capped further by the flow node's own cost limit.

Flow and agent budgets are per execution on purpose: measured cumulatively they
would eventually fail every run of a well-used flow.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.providers.base import LLMResponse, ModelSelection
from app.core.config import settings
from app.core.errors import BudgetExceededError
from app.core.logging import get_logger
from app.models.llm import LLMUsage

logger = get_logger(__name__)


@dataclass(slots=True)
class UsageContext:
    """Identifies which run/agent/flow an invocation should be billed to."""

    project_id: str | None = None
    run_id: str | None = None
    step_id: str | None = None
    agent_id: str | None = None
    agent_key: str | None = None
    flow_id: str | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class BudgetStatus:
    scope: str
    limit_usd: float
    spent_usd: float

    @property
    def remaining_usd(self) -> float:
        return max(0.0, self.limit_usd - self.spent_usd)

    @property
    def utilization(self) -> float:
        if self.limit_usd <= 0:
            return 0.0
        return min(1.0, self.spent_usd / self.limit_usd)

    @property
    def exhausted(self) -> bool:
        return self.limit_usd > 0 and self.spent_usd >= self.limit_usd

    def to_dict(self) -> dict[str, Any]:
        return {
            "scope": self.scope,
            "limit_usd": round(self.limit_usd, 4),
            "spent_usd": round(self.spent_usd, 6),
            "remaining_usd": round(self.remaining_usd, 6),
            "utilization": round(self.utilization, 4),
            "exhausted": self.exhausted,
        }


def estimate_cost(selection: ModelSelection, prompt_tokens: int, completion_tokens: int) -> float:
    return round(
        (prompt_tokens / 1000.0) * selection.input_cost_per_1k
        + (completion_tokens / 1000.0) * selection.output_cost_per_1k,
        6,
    )


class CostTracker:
    """Reads and writes cost state for a single database session."""

    def __init__(self, session: Session) -> None:
        self.session = session

    # ----- recording ---------------------------------------------------------
    def record(
        self,
        response: LLMResponse,
        context: UsageContext,
        *,
        operation: str = "chat",
        success: bool = True,
        fallback_used: bool = False,
        error: str | None = None,
    ) -> LLMUsage:
        usage = LLMUsage(
            project_id=context.project_id,
            run_id=context.run_id,
            step_id=context.step_id,
            agent_id=context.agent_id,
            agent_key=context.agent_key,
            flow_id=context.flow_id,
            provider=response.selection.provider,
            model=response.selection.model,
            deployment=response.selection.deployment,
            capability=response.selection.capability,
            operation=operation,
            prompt_tokens=response.usage.prompt_tokens,
            completion_tokens=response.usage.completion_tokens,
            total_tokens=response.usage.total_tokens,
            estimated_cost_usd=response.cost_usd,
            latency_ms=response.latency_ms,
            cache_hit=response.cache_hit,
            success=success,
            fallback_used=fallback_used,
            error=error,
            correlation_id=context.correlation_id,
        )
        self.session.add(usage)
        self.session.flush()
        return usage

    # ----- querying ----------------------------------------------------------
    def spent(
        self,
        *,
        project_id: str | None = None,
        run_id: str | None = None,
        step_id: str | None = None,
        flow_id: str | None = None,
        agent_id: str | None = None,
        since: datetime | None = None,
    ) -> float:
        query = select(func.coalesce(func.sum(LLMUsage.estimated_cost_usd), 0.0))
        if project_id:
            query = query.where(LLMUsage.project_id == project_id)
        if run_id:
            query = query.where(LLMUsage.run_id == run_id)
        if step_id:
            query = query.where(LLMUsage.step_id == step_id)
        if flow_id:
            query = query.where(LLMUsage.flow_id == flow_id)
        if agent_id:
            query = query.where(LLMUsage.agent_id == agent_id)
        if since:
            query = query.where(LLMUsage.created_at >= since)
        return float(self.session.execute(query).scalar_one() or 0.0)

    def tokens_used(self, *, run_id: str | None = None, agent_id: str | None = None) -> int:
        query = select(func.coalesce(func.sum(LLMUsage.total_tokens), 0))
        if run_id:
            query = query.where(LLMUsage.run_id == run_id)
        if agent_id:
            query = query.where(LLMUsage.agent_id == agent_id)
        return int(self.session.execute(query).scalar_one() or 0)

    # ----- enforcement -------------------------------------------------------
    def check_budgets(
        self,
        context: UsageContext,
        *,
        project_budget_usd: float | None = None,
        flow_budget_usd: float | None = None,
        agent_budget_usd: float | None = None,
        projected_cost_usd: float = 0.0,
    ) -> list[BudgetStatus]:
        """Raise `BudgetExceededError` if the projected call breaches any scope."""
        statuses: list[BudgetStatus] = []

        if context.project_id:
            limit = project_budget_usd if project_budget_usd is not None else settings.default_project_cost_budget_usd
            statuses.append(BudgetStatus("project", limit, self.spent(project_id=context.project_id)))
        if context.flow_id and context.run_id:
            limit = flow_budget_usd if flow_budget_usd is not None else settings.default_flow_cost_budget_usd
            statuses.append(BudgetStatus("flow", limit, self.spent(run_id=context.run_id)))
        if agent_budget_usd is not None and context.step_id:
            statuses.append(BudgetStatus("agent", agent_budget_usd, self.spent(step_id=context.step_id)))

        for status in statuses:
            if status.limit_usd <= 0:
                continue
            if status.spent_usd + projected_cost_usd > status.limit_usd:
                logger.warning(
                    "budget_exceeded",
                    scope=status.scope,
                    limit=status.limit_usd,
                    spent=status.spent_usd,
                    projected=projected_cost_usd,
                )
                raise BudgetExceededError(
                    f"{status.scope.capitalize()} AI budget of €{status.limit_usd:.2f} would be exceeded "
                    f"(spent €{status.spent_usd:.4f}, this call ~€{projected_cost_usd:.4f}).",
                    details={"budget": status.to_dict()},
                )
        return statuses

    # ----- analytics ---------------------------------------------------------
    def breakdown(self, project_id: str | None = None, days: int = 30) -> dict[str, Any]:
        """Cost grouped by agent, model and flow for the analytics screens."""
        since = datetime.now(UTC) - timedelta(days=days)

        def _grouped(column) -> list[dict[str, Any]]:  # noqa: ANN001
            query = select(
                column,
                func.sum(LLMUsage.estimated_cost_usd),
                func.sum(LLMUsage.total_tokens),
                func.count(LLMUsage.id),
            ).where(LLMUsage.created_at >= since)
            if project_id:
                query = query.where(LLMUsage.project_id == project_id)
            query = query.group_by(column).order_by(func.sum(LLMUsage.estimated_cost_usd).desc())
            return [
                {
                    "key": row[0] or "unattributed",
                    "cost_usd": round(float(row[1] or 0.0), 6),
                    "tokens": int(row[2] or 0),
                    "calls": int(row[3] or 0),
                }
                for row in self.session.execute(query).all()
            ]

        total_query = select(
            func.coalesce(func.sum(LLMUsage.estimated_cost_usd), 0.0),
            func.coalesce(func.sum(LLMUsage.total_tokens), 0),
            func.count(LLMUsage.id),
            func.coalesce(func.avg(LLMUsage.latency_ms), 0.0),
        ).where(LLMUsage.created_at >= since)
        if project_id:
            total_query = total_query.where(LLMUsage.project_id == project_id)
        total_cost, total_tokens, call_count, avg_latency = self.session.execute(total_query).one()

        return {
            "window_days": days,
            "total_cost_usd": round(float(total_cost or 0.0), 6),
            "total_tokens": int(total_tokens or 0),
            "total_calls": int(call_count or 0),
            "avg_latency_ms": int(avg_latency or 0),
            "by_agent": _grouped(LLMUsage.agent_key),
            "by_model": _grouped(LLMUsage.model),
            "by_provider": _grouped(LLMUsage.provider),
            "by_capability": _grouped(LLMUsage.capability),
        }
