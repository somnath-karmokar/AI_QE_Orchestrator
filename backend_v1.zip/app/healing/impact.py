"""What else a change touches.

Two questions this answers, and they are the same question asked twice.

**After a repair:** the re-run proves the test that broke now passes. It does not
prove the journey still works. A locator repaired on Add-to-Cart is only really
validated by the basket still totalling correctly at checkout, and a module tree
cannot tell you those are related.

**Before a regression run:** given what changed, which tests would notice? Module
names are a crude proxy — they answer "where does this test live", not "what does
this test depend on".

Both are the same graph walked in opposite directions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.models.testing import (
    BusinessFlow,
    BusinessFlowStep,
    TestCase,
    TestDependency,
)

logger = get_logger(__name__)

# How much a broken journey costs, used to order what gets attention first.
CRITICALITY_WEIGHT = {"critical": 1.0, "high": 0.75, "medium": 0.5, "low": 0.25}


@dataclass(slots=True)
class Impact:
    """What a change reaches, beyond the thing that changed."""

    step: dict[str, Any] | None = None
    business_flow: dict[str, Any] | None = None
    downstream_steps: list[dict[str, Any]] = field(default_factory=list)
    validation_tests: list[dict[str, Any]] = field(default_factory=list)
    business_assertions: list[str] = field(default_factory=list)
    risk_score: float = 0.0

    @property
    def found(self) -> bool:
        return self.step is not None

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step,
            "business_flow": self.business_flow,
            "downstream_steps": self.downstream_steps,
            "validation_tests": self.validation_tests,
            "business_assertions": self.business_assertions,
            "risk_score": self.risk_score,
        }


def _step_dict(step: BusinessFlowStep) -> dict[str, Any]:
    return {
        "id": step.id,
        "key": step.key,
        "name": step.name,
        "position": step.position,
        "module": step.module,
        "assertions": list(step.assertions or []),
    }


def locate_step(
    session: Session,
    *,
    project_id: str,
    test_case_id: str | None = None,
    component: str | None = None,
) -> BusinessFlowStep | None:
    """The journey step a test, or a UI component, belongs to."""
    if test_case_id:
        dependency = (
            session.execute(
                select(TestDependency).where(
                    TestDependency.project_id == project_id,
                    TestDependency.test_case_id == test_case_id,
                    TestDependency.relationship_type == "covers",
                )
            )
            .scalars()
            .first()
        )
        if dependency is not None:
            return session.get(BusinessFlowStep, dependency.business_flow_step_id)

    if component:
        needle = component.lower()
        for flow in _flows(session, project_id):
            for step in flow.steps:
                if any(needle in str(item).lower() for item in (step.ui_components or [])):
                    return step
    return None


def _flows(session: Session, project_id: str) -> list[BusinessFlow]:
    return list(
        session.execute(
            select(BusinessFlow).where(
                BusinessFlow.project_id == project_id,
                BusinessFlow.is_deleted.is_(False),
            )
        )
        .scalars()
        .all()
    )


def assess(
    session: Session,
    *,
    project_id: str,
    test_case_id: str | None = None,
    component: str | None = None,
) -> Impact:
    """What a repair here would need to be checked against.

    An empty result is a real answer: without a business flow covering this
    test, the platform does not know what else it touches and should not
    pretend to.
    """
    step = locate_step(
        session, project_id=project_id, test_case_id=test_case_id, component=component
    )
    if step is None:
        return Impact()

    flow = session.get(BusinessFlow, step.business_flow_id)
    if flow is None:
        return Impact()

    downstream = [item for item in flow.steps if item.position > step.position]

    # Tests that cover this step or anything after it: what a repair here could
    # break, and therefore what proves it did not.
    step_ids = [step.id, *[item.id for item in downstream]]
    dependencies = list(
        session.execute(
            select(TestDependency).where(
                TestDependency.project_id == project_id,
                TestDependency.business_flow_step_id.in_(step_ids),
            )
        )
        .scalars()
        .all()
    )

    validation_tests: list[dict[str, Any]] = []
    seen: set[str] = set()
    for dependency in dependencies:
        if dependency.test_case_id in seen or dependency.test_case_id == test_case_id:
            continue
        seen.add(dependency.test_case_id)
        case = session.get(TestCase, dependency.test_case_id)
        if case is None or case.is_deleted:
            continue
        validation_tests.append(
            {
                "test_case_id": case.id,
                "title": case.title,
                "module": case.module,
                "priority": case.priority,
                "relationship": dependency.relationship_type,
            }
        )

    # The assertions the journey still has to satisfy downstream. These are
    # business outcomes, and healing may never touch them.
    assertions: list[str] = []
    for item in [step, *downstream]:
        assertions.extend(str(entry) for entry in (item.assertions or []))

    weight = CRITICALITY_WEIGHT.get(flow.criticality, 0.5)
    reach = len(downstream) / max(len(flow.steps), 1)
    risk = round(min(1.0, weight * (0.5 + 0.5 * reach)), 4)

    return Impact(
        step=_step_dict(step),
        business_flow={
            "id": flow.id,
            "key": flow.key,
            "name": flow.name,
            "criticality": flow.criticality,
            "owner": flow.owner,
            "step_count": len(flow.steps),
        },
        downstream_steps=[_step_dict(item) for item in downstream],
        validation_tests=validation_tests,
        business_assertions=assertions,
        risk_score=risk,
    )


def select_for_change(
    session: Session,
    *,
    project_id: str,
    changed_components: list[str] | None = None,
    changed_modules: list[str] | None = None,
    changed_endpoints: list[str] | None = None,
) -> dict[str, Any]:
    """Which tests a change should re-run, and why each was chosen.

    Selection by module is a blunt instrument: it picks up every test filed in a
    folder and misses every test in another folder that depends on the same
    control. Walking the journey graph answers the question that was actually
    asked.
    """
    components = {item.lower() for item in (changed_components or [])}
    modules = {item.lower() for item in (changed_modules or [])}
    endpoints = {item.lower() for item in (changed_endpoints or [])}

    touched_steps: dict[str, tuple[BusinessFlow, BusinessFlowStep, str]] = {}
    for flow in _flows(session, project_id):
        for step in flow.steps:
            reason = None
            if components and any(
                str(item).lower() in components for item in (step.ui_components or [])
            ):
                reason = "a changed UI component"
            elif endpoints and any(
                str(item).lower() in endpoints for item in (step.api_endpoints or [])
            ):
                reason = "a changed API endpoint"
            elif modules and (step.module or "").lower() in modules:
                reason = "a changed module"
            if reason:
                touched_steps[step.id] = (flow, step, reason)

    if not touched_steps:
        return {
            "selected": [],
            "journeys": [],
            "reason": "No business flow covers what changed.",
            "selected_by": "business_flow",
        }

    # A change to a step puts everything after it in the journey at risk too.
    at_risk: dict[str, tuple[BusinessFlow, BusinessFlowStep, str]] = dict(touched_steps)
    for flow, step, _reason in list(touched_steps.values()):
        for later in flow.steps:
            if later.position > step.position and later.id not in at_risk:
                at_risk[later.id] = (flow, later, f"downstream of '{step.name}'")

    dependencies = list(
        session.execute(
            select(TestDependency).where(
                TestDependency.project_id == project_id,
                TestDependency.business_flow_step_id.in_(list(at_risk)),
            )
        )
        .scalars()
        .all()
    )

    selected: list[dict[str, Any]] = []
    seen: set[str] = set()
    for dependency in dependencies:
        if dependency.test_case_id in seen:
            continue
        seen.add(dependency.test_case_id)
        case = session.get(TestCase, dependency.test_case_id)
        if case is None or case.is_deleted:
            continue
        flow, step, reason = at_risk[dependency.business_flow_step_id]
        selected.append(
            {
                "test_case_id": case.id,
                "title": case.title,
                "module": case.module,
                "priority": case.priority,
                "business_flow": flow.name,
                "step": step.name,
                # Every selection says why, so a skipped test is a decision
                # someone can argue with rather than a silent omission.
                "selected_because": reason,
            }
        )

    journeys = sorted({flow.name for flow, _step, _reason in at_risk.values()})
    logger.info(
        "impact_selection",
        steps_touched=len(touched_steps),
        steps_at_risk=len(at_risk),
        tests_selected=len(selected),
    )
    return {
        "selected": selected,
        "journeys": journeys,
        "steps_changed": len(touched_steps),
        "steps_at_risk": len(at_risk),
        "reason": (
            f"{len(selected)} test(s) cover {len(at_risk)} step(s) across "
            f"{len(journeys)} journey(s) affected by this change."
        ),
        "selected_by": "business_flow",
    }
