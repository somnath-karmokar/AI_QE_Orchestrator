# Using this platform from another agent platform (MCP)

**Audience:** engineers connecting an agent platform — Claude, an internal orchestrator, or anything that
speaks Model Context Protocol — to this one.

The [REST surface](api-reference.md) is the right shape for a pipeline: start something, poll it, read the
result. It is the wrong shape for an *agent*, which needs to discover what it can call and invoke it without
a human having read documentation first. That is what MCP is for, and this platform speaks it.

**The guarantees do not change.** A tool call goes through the same scopes, the same approval gates and the
same audit trail as the REST route. Everything in [guardrails.md](guardrails.md) applies here unchanged.

---

## 1. Connect

One endpoint, JSON-RPC 2.0, authenticated with the same API key:

```
POST https://<host>/api/v1/mcp
X-API-Key: qei_…
```

```json
{"jsonrpc": "2.0", "id": 1, "method": "initialize"}
```

```json
{
  "protocolVersion": "2024-11-05",
  "capabilities": { "tools": { "listChanged": false } },
  "serverInfo": { "name": "AI QE Orchestrator", "version": "1.0.0" },
  "instructions": "…"
}
```

**Read `instructions` and give it to your model.** It carries the two things an agent most often gets wrong
here: that work is asynchronous, and that `waiting_for_approval` is a normal outcome rather than a failure to
retry.

Get a key exactly as a pipeline would — see [README §1](README.md#1-get-a-key). Grant `flows:run`,
`agents:run` and `runs:read` for a useful tool set.

---

## 2. Discover

```json
{"jsonrpc": "2.0", "id": 2, "method": "tools/list"}
```

```json
{ "tools": [
  { "name": "run_flow_regression_intelligence",
    "title": "Payment Regression Intelligence",
    "description": "Predicts risk and selects an optimised regression suite…\n\nStarts a flow and returns immediately…",
    "inputSchema": { "type": "object", "properties": { "changed_modules": { "type": "array" } } } },
  { "name": "get_run", "title": "Get run status and result", "inputSchema": { "…": "…" } }
] }
```

**The listing is the authorisation boundary, not a filter.** A flow your key was not granted is not listed
and cannot be called; calling it returns the same answer as a tool that does not exist. The tool list is
therefore safe to hand to a model without leaking what else the project contains.

Tool names are derived from the flow or agent key, not its display name, so they stay stable if somebody
renames a flow.

---

## 3. Call

```json
{"jsonrpc": "2.0", "id": 3, "method": "tools/call",
 "params": {"name": "run_flow_regression_intelligence",
            "arguments": {"changed_modules": ["Payments"]}}}
```

```json
{ "content": [{ "type": "text",
                "text": "Run fcd598a1 is pending. Poll get_run with this id until is_terminal is true." }],
  "structuredContent": { "run_id": "fcd598a1…", "disposition": "pending", "is_terminal": false, "…": "…" },
  "isError": false }
```

Both halves are returned on purpose: the **text** is what a model reads to decide what to do next, the
**structuredContent** is what your code branches on. It is the same envelope the REST route returns, so an
agent and a pipeline see identical facts about the same run.

Then poll:

```json
{"jsonrpc": "2.0", "id": 4, "method": "tools/call",
 "params": {"name": "get_run", "arguments": {"run_id": "fcd598a1…"}}}
```

Arguments are **checked against the tool's `inputSchema`**, and an argument the tool does not declare is
refused rather than ignored — with a `did_you_mean` when it looks like a typo. A silently dropped argument
would mean the flow ran on its default and reported success about something the agent never asked for.

An accepted call echoes `inputs_applied` in `structuredContent`, showing each value and whether it came from
the caller or a flow default.

---

## 4. The one thing to get right

When a run needs a person, the text your model reads says so plainly:

> *Run fcd598a1 is waiting for qe_lead to approve: Apply 4 locator repairs to the payments suite.
> This is not a failure and it has not stopped. Do not retry; a person decides next.*

An agent told only "failed" will retry, and will keep retrying, because nothing it does can clear an
approval. Branch on `structuredContent.disposition`:

| `disposition` | What your agent should do |
|---|---|
| `pending` | Poll again after a pause |
| `waiting_for_approval` | **Stop and report.** A person decides. Retrying cannot help |
| `succeeded` | Read `structuredContent.outputs` |
| `failed` | Read `error`; retrying may be reasonable |
| `refused` | Policy declined it. Do not retry |
| `cancelled` | Someone stopped it |

---

## 5. Errors

MCP separates a **protocol** failure from a **tool** failure, and this server keeps them apart:

- A malformed request, an unknown method or a missing tool name returns a JSON-RPC `error` object. Something
  is wrong with the call itself.
- A tool that refuses returns a **successful** result with `"isError": true` and the reason in `content`.
  The server is working; the answer is no.

Collapsing the two would make "policy declined this" indistinguishable from "the server is broken", and an
agent would retry the wrong one.

| JSON-RPC code | Meaning |
|---|---|
| `-32700` | The body was not valid JSON |
| `-32600` | Not a JSON-RPC 2.0 request |
| `-32601` | Method not supported |
| `-32602` | Invalid parameters, such as a call with no tool name |
| `-32603` | The server failed to invoke the tool |

HTTP `401` means the key is missing, unknown, revoked or expired. HTTP `429` means the key exceeded the
per-key rate limit reported in the manifest — `retry_after_seconds` is in `error.details`.

---

## 6. If you do not speak MCP

The same tools are available in OpenAI function-calling shape, so a platform built on OpenAI or Bedrock
tool-use can register them directly:

```python
from app.services.mcp_tools import tools_as_openai_functions

tools = tools_as_openai_functions(session, client)
# [{"type": "function", "function": {"name": …, "description": …, "parameters": {…}}}]
```

The underlying call is the same one, with the same scopes and the same guarantees.

---

## 7. Before you connect an agent

- [ ] `instructions` from `initialize` is in your system prompt
- [ ] `waiting_for_approval` is handled as a stop, not a retry
- [ ] Polling has a timeout, and the timeout does not cancel the run
- [ ] The key has the fewest scopes that work, and an expiry
- [ ] No secrets in tool arguments — argument **keys** are audited, values are not stored in the audit log,
      but they are stored with the run
- [ ] You have read [guardrails.md §3](guardrails.md#3-what-is-not-guaranteed), *What is not guaranteed*
