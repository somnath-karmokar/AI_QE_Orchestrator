# Integrating with the AI QE Orchestrator

**Audience:** engineers connecting another system — a CI server, a release pipeline, an internal portal, or
another agent platform — to this one.

Two ways in, over one credential and one set of guarantees:

- **REST**, under `/api/v1/integration` — right for a pipeline: start something, poll it, read the result.
- **MCP**, at `/api/v1/mcp` — right for an *agent*, which discovers callable tools rather than reading docs.
  See [mcp.md](mcp.md).

Both are deliberately narrow, stable surfaces, separate from the routes the web app uses. What the web app
calls may change; these will not, without a version change.

- **[QUICKSTART.md](QUICKSTART.md)** — the short version: seven steps from "I have a key" to
  "I'm branching on the result." Start here if you just want to make a call.
- **[guardrails.md](guardrails.md)** — what the platform promises, what it refuses, and what you must handle.
  Read this before writing code.
- **[api-reference.md](api-reference.md)** — every endpoint, with request and response shapes.
- **[recipes.md](recipes.md)** — working examples: a CI gate, a portal, an agent-to-agent call.
- **[mcp.md](mcp.md)** — connecting an *agent* platform rather than a pipeline, over Model Context Protocol.
- **[governance.md](governance.md)** — model cards, golden datasets, run logs, the audit feed and metrics:
  what you can know about an agent before trusting it, and about your runs afterwards.
- **[SOP.md](SOP.md)** — the operating procedure for a consuming platform (also `GET /integration/sop`).

---

## 1. Get a key

An operator issues it from **API Access** in the web app, or through the API below. A key belongs
to one project and names exactly what it may do. Two live keys in a project cannot share a name:
a run records its caller as `integration:{name}`, and that is what decides who may read it back.

```bash
curl -X POST https://<host>/api/v1/integration-clients \
  -H "Authorization: Bearer $OPERATOR_JWT" \
  -H "Content-Type: application/json" \
  -d '{
        "project_id": "…",
        "name": "jenkins-nightly",
        "platform": "jenkins",
        "scopes": ["catalog:read", "flows:run", "runs:read", "approvals:read"],
        "allowed_flow_ids": ["…"],
        "expires_in_days": 365
      }'
```

**The token is in that response and nowhere else.** Only a keyed hash is stored, so a lost key is rotated,
never recovered.

### Scopes

| Scope | Allows |
|---|---|
| `catalog:read` | Discover the flows and agents this key may invoke, with their schemas |
| `flows:run` | Start a flow run |
| `agents:run` | Invoke a single agent |
| `runs:read` | Read status, guardrail outcome and result |
| `runs:cancel` | Cancel a run this key started |
| `approvals:read` | See approvals blocking this key's runs |
| `runs:logs` | Read the governance log, audit feed and metrics of runs this key started |

Grant the least that works. `catalog:read`, `flows:run`, `runs:read`, `approvals:read` is the usual set for a
pipeline and is what you get if you omit `scopes` entirely. An explicit empty list is rejected rather than
quietly granting the defaults.

### What a key may reach

Scopes say *whether*; grants say *which*. Name them one at a time with `allowed_flow_ids` and
`allowed_agent_keys`, or hand over the project:

| Field | Effect |
|---|---|
| `grants_all_flows` | Every **published** flow in this project, including ones published later |
| `grants_all_agents` | Every published agent reachable in this project, built-ins included |

Both default to `false`, so a key never widens by accident, and neither ever crosses into another
project. A project-wide grant deliberately excludes drafts — publishing is the act that says a flow is
ready for someone else to run — while a flow named explicitly is honoured whatever its status.

---

## 2. Discover what you can call

```bash
curl -H "X-API-Key: $QE_API_KEY" https://<host>/api/v1/integration/manifest
```

The manifest names the platform and version, the authentication scheme, your granted scopes, the rate limit,
every endpoint, the **guardrail contract**, and the conventions below. Fetch it once at startup and assert on
what you depend on.

```bash
curl -H "X-API-Key: $QE_API_KEY" https://<host>/api/v1/integration/catalog
```

The catalog lists the flows and agents **this key** may invoke. Each entry carries a JSON Schema for its
inputs, so you can validate a payload, build a form or generate a client instead of guessing.

---

## 3. Start work

```bash
curl -X POST https://<host>/api/v1/integration/flows/$FLOW_ID/runs \
  -H "X-API-Key: $QE_API_KEY" \
  -H "X-Idempotency-Key: build-8412" \
  -H "Content-Type: application/json" \
  -d '{"inputs": {"requirement_key": "PAY-201", "module": "Payments"}}'
```

`202 Accepted` — the work has been accepted, not finished. Poll for the result; outbound
callbacks are not delivered yet.

**Always send `X-Idempotency-Key`.** If your side times out and retries, the same key returns the same run
with `200` and `X-Idempotent-Replay: true` rather than starting a second one. Use something your build
already has: a build number, a commit SHA, a change ticket.

---

## 4. Watch it

```bash
curl -H "X-API-Key: $QE_API_KEY" https://<host>/api/v1/integration/runs/$RUN_ID
```

**Branch on `disposition`, not on `status`.** `status` is the platform's internal vocabulary and may gain new
values; `disposition` is the small set below and will not.

| `disposition` | Meaning | Terminal |
|---|---|---|
| `pending` | Queued or running | no |
| `waiting_for_approval` | Stopped, waiting for a named person | no |
| `succeeded` | Finished; read `outputs` | yes |
| `failed` | Finished; read `error` | yes |
| `cancelled` | Stopped by a person or by your key | yes |
| `refused` | Policy did not permit it | yes |

`waiting_for_approval` is a normal outcome. A pipeline that treats it as a failure will fail builds that were
about to pass. See [guardrails.md](guardrails.md#21-a-high-risk-action-waits-for-a-person).

A key can only read runs **it started**. Another key's runs and runs a person started in the web app return
`404`, the same as a run that does not exist.

---

## 5. Conventions

| | |
|---|---|
| **Auth** | `X-API-Key: qei_…` |
| **Idempotency** | `X-Idempotency-Key` on every start request |
| **Tracing** | `X-Correlation-ID` is echoed and appears in the platform's logs and audit entries |
| **Errors** | `{"error": {"code", "message", "details", "correlation_id"}}` |
| **Retries** | Retry `5xx` with backoff and the original idempotency key. Never retry `401`, `403` or `422` |
| **Rate limit** | Per key, reported in the manifest under `limits.rate_limit_per_minute` and enforced. `429` carries `retry_after_seconds` |
| **Protocols** | REST (`/integration`) and MCP (`/mcp`), reported under `conventions.protocols` |
| **Results** | Poll `GET /runs/{id}`. Callbacks are **not delivered yet**; `callback_url` on a key is reserved for later |

---

## 6. A minimal, correct client

```python
import time, requests

BASE = "https://<host>/api/v1/integration"
HEAD = {"X-API-Key": QE_API_KEY}


def run_flow(flow_id: str, inputs: dict, idempotency_key: str, timeout_s: int = 1800) -> dict:
    started = requests.post(
        f"{BASE}/flows/{flow_id}/runs",
        headers={**HEAD, "X-Idempotency-Key": idempotency_key},
        json={"inputs": inputs},
        timeout=30,
    )
    started.raise_for_status()
    run = started.json()

    deadline = time.time() + timeout_s
    while not run["is_terminal"] and time.time() < deadline:
        # Waiting on a person is not a failure, and polling harder will not help.
        time.sleep(15)
        run = requests.get(f"{BASE}/runs/{run['run_id']}", headers=HEAD, timeout=30).json()

    return run


result = run_flow(FLOW_ID, {"requirement_key": "PAY-201"}, idempotency_key=BUILD_ID)

if result["disposition"] == "succeeded":
    publish(result["outputs"])
elif result["disposition"] == "waiting_for_approval":
    # Hold the gate; a QE lead decides. Do not fail the build.
    blocking = result["guardrails"]["awaiting_approval"]
    notify(f"Waiting on {blocking[0]['required_role']}: {blocking[0]['title']}")
else:
    fail(result.get("error") or result["disposition"])
```

---

## 7. Before you go live

- [ ] Read [guardrails.md](guardrails.md), including §3 *What is not guaranteed*
- [ ] Your key has the fewest scopes that work, and an expiry
- [ ] `waiting_for_approval` is handled as a hold, not a failure
- [ ] Every start request sends an idempotency key
- [ ] No secrets in `inputs`
- [ ] `correlation_id` is logged on every response
- [ ] You know whether this deployment runs real browsers or simulated execution
- [ ] Key rotation is scheduled and someone owns it
- [ ] The model card of every agent and flow you call has been reviewed, and its version recorded
- [ ] Each golden dataset's edge cases pass against your integration
- [ ] If governance needs an audit trail: the key has `runs:logs` and the audit feed is polled into your SIEM
