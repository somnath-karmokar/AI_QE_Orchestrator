# SOP - Consuming AI QE Orchestrator agents and flows

Version 1.0. Generated from `app/services/sop.py`; served live at `GET /api/v1/integration/sop`. Do not edit by hand.

## Purpose

Call the platform's agents and flows from another system, know what each run did, and keep the evidence governance asks for.

**Audience:** Engineers integrating a pipeline, portal or agent platform, and the people who operate it.

## Workflow

1. **Authenticate** - Send X-API-Key on every request. GET /api/v1/integration/me proves the key works without starting anything.
2. **Discover** - GET /api/v1/integration/catalog lists what this key may call, with input schemas.
3. **Review** - Read the model card (owner, model, controls, observed performance) and golden dataset of each agent or flow before relying on it.
4. **Start** - POST to the invoke path with an X-Idempotency-Key. The response is a run with a run_id; the work continues in the background.
5. **Poll** - GET /api/v1/integration/runs/{run_id} until is_terminal is true. Branch on disposition, never on status.
6. **Approvals** - waiting_for_approval is a normal pause: a named role must decide. Keep polling; do not retry.
7. **Result** - outputs is keyed by agent key; each value is that agent's result in the standard contract.
8. **Evidence** - GET /api/v1/integration/runs/{run_id}/log for the governance log of that run (scope runs:logs).

Dispositions: `cancelled`, `failed`, `pending`, `refused`, `succeeded`, `waiting_for_approval`.

## Operations

| When | Action |
| --- | --- |
| Before go-live | Run each golden dataset's edge cases against your project to prove your integration handles refusals. |
| Daily | Call GET /api/v1/integration/me; alert if the key is expired or revoked, or if expires_at is near. |
| Continuously | Poll GET /api/v1/integration/audit-events from the last next_cursor into your SIEM. The cursor never repeats or skips an entry. |
| Weekly | Review GET /api/v1/integration/metrics: success rate, p95 duration, cost, model fallbacks and approval waits. |
| On a model card change | Compare version, model and prompt versions with the last review; re-run the golden dataset. |
| Every key rotation | Ask the operator to rotate; the old token stops working immediately, so deploy the new one first. |

## Incidents

| Signal | Meaning | Action |
| --- | --- | --- |
| 401 | The key is missing, wrong, expired or revoked. | Check GET /integration/me with the key; ask the operator for a new one. |
| 403 | The key lacks the scope for this call; the error names it. | Ask the operator to grant that scope. |
| 404 | Not granted, or does not exist -- deliberately the same answer. | Check the catalog; ask for a grant. |
| 200 with X-Idempotent-Replay: true | That idempotency key already started a run for this resource; you were given that run back, even if your inputs differ. | Use a new idempotency key for genuinely new work. |
| 422 | An input was refused; invalid_inputs says which and suggests a fix. | Correct the input. Never drop the field silently. |
| 429 | The key's rate limit was reached. | Back off; the limit is in GET /integration/me. |
| disposition failed | The run finished unsuccessfully. | Read the run log's activities for the failing step and error; start a new run once fixed. |
| disposition refused | A policy blocked the run. | Read the run log's policy decisions; raise it with the flow owner, not by retrying. |

## Escalation

The platform operator who issued your API key. Quote the run_id and the X-Correlation-ID from the response.

## Caller obligations

- Treat 'waiting_for_approval' as a normal outcome, not an error; a human decides next.
- Do not retry a run that is pending -- poll it. Callbacks are not delivered yet.
- Send X-Idempotency-Key on start requests so a network retry does not start a second run.
- Do not send secrets in inputs; reference them by name and hold them in your own vault.

## Scopes

| Scope | Grants |
| --- | --- |
| `agents:run` | Invoke a single agent. |
| `approvals:read` | See approvals that are blocking this client's runs. |
| `catalog:read` | Discover the agents and flows this client may invoke, with their schemas. |
| `flows:run` | Start a flow run. |
| `runs:cancel` | Cancel a run this client started. |
| `runs:logs` | Read the governance log, audit feed and usage metrics of runs this client started. |
| `runs:read` | Read the status, result and guardrail outcome of a run. |
