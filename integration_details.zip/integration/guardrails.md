# Guardrail contract

**Audience:** engineers integrating another platform with the AI QE Orchestrator, and the people who have to
sign off on letting it act.

This document states what the platform will and will not do when something else drives it. Every promise
below is enforced in code, has a test, and is returned by
`GET /api/v1/integration/manifest` so an integration can assert on it at runtime rather than trusting a PDF.

---

## 1. The one-paragraph version

The platform runs AI agents that read your requirements, write and run tests, diagnose failures and repair
brittle automation. It will not change what a test claims about your application, it will not record a repair
it has not proved, and it will not perform a high-risk action without a named person approving it. When it
cannot proceed safely it stops and says so, in a field you can branch on — it does not guess and it does not
fail silently.

---

## 2. What is guaranteed

### 2.1 A high-risk action waits for a person

An action whose risk level requires approval **pauses**. The run reports `disposition: "waiting_for_approval"`
and lists what is blocking it, who may decide, and when the request expires.

```json
{
  "disposition": "waiting_for_approval",
  "is_terminal": false,
  "guardrails": {
    "awaiting_approval": [
      {
        "approval_id": "…",
        "title": "Apply 4 locator repairs to the payments suite",
        "reason": "Self-healing proposes changes to 4 test scripts.",
        "risk_level": "high",
        "required_role": "qe_lead",
        "expires_at": "2026-09-20T09:00:00Z"
      }
    ]
  }
}
```

**This is not an error.** A pipeline that treats it as one will fail builds that were about to succeed. Hold,
poll, or let the run expire — the decision belongs to a person in the platform, not to your caller.

*Enforced by `app/governance/policy_engine.py`.*

### 2.2 Business assertions are never changed

Self-healing repairs **how a test finds and drives** the application — locators, waits, navigation, test data.
It never changes **what a test claims about** the application.

| May be repaired | Never repaired |
|---|---|
| `locator`, `timing`, `navigation` | `assertion` |
| `test_data`, `api_contract` (with approval) | `business_rule`, `test_logic` |

A test that fails because the application is wrong **stays failed**. There is no confidence score that
unlocks this and no role that overrides it; the approval endpoint itself refuses, with `422` and the reason.

*Enforced by `app/healing/policy.py`, configurable only to become stricter via `HEALING_CHANGE_POLICY`.*

### 2.3 No repair is recorded without proof

A proposed repair is applied as a **temporary patch**, the affected test is **re-run**, and the change is
written to the test only if that re-run passed. A failed re-run leaves the test exactly as it was — there is
nothing to roll back, because nothing was changed.

`result_after` and `validated_at` on a healing record are written by the validation service and by nothing
else. They mean *a re-run produced this*, never *we expect this*.

*Enforced by `app/healing/validation.py`.*

### 2.4 Everything is audited

Every invocation, decision and refusal is written to an append-only log with the calling system, the inputs,
the policy result, the model and cost, and the outcome. Your key appears as `integration:<name>`, so platform
actions are attributable to the system that asked for them.

*Enforced by `app/governance/policy_engine.py`.*

### 2.5 Budgets stop work rather than overspending

Project, flow and agent budgets are checked before spending. Exceeding one **stops the run**; it does not
continue and invoice you for it. Cost is reported on every run response under `guardrails.cost`.

*Enforced by `app/ai/cost/tracker.py`.*

### 2.6 A key can only do what it was granted

There is **no wildcard grant**. A key names its scopes and the exact flows and agents it may invoke. An
empty allow-list means *none*, never *all*. A flow you were not granted and a flow that does not exist return
the same `404` with the same message, so the API cannot be used to discover what a project contains.

*Enforced by `app/api/integration_auth.py`.*

---

## 3. What is *not* guaranteed

Stated plainly, because an integration built on a wrong assumption is worse than one built on a known limit.

- **Timing.** A run is asynchronous. There is no guaranteed completion time; some runs wait on a human
  indefinitely until their approval expires.
- **Determinism.** These are language-model agents. The same inputs can produce different wording, different
  confidence scores and sometimes a different decision. Assert on `disposition` and structured outputs, never
  on prose.
- **Correctness of generated tests.** Generated tests are a starting point for a person to review. The
  platform does not claim they are complete or correct.
- **The step graph.** How a flow decomposes into steps is an implementation detail, deliberately excluded
  from the integration responses. It will change.
- **Simulated execution.** Unless `PLAYWRIGHT_ENABLED=true` and a target application is reachable, test
  execution is simulated. Simulated results are labelled as such on every record. Do not present them to a
  customer as evidence that their application works.

---

## 4. Your obligations as a caller

1. **Treat `waiting_for_approval` as normal.** It is not a failure, and retrying will not clear it.
2. **Do not retry pending runs.** Poll `links.self`. Outbound callbacks are not delivered yet, so
   `callback_url` on a key does nothing today — the manifest reports this under
   `conventions.result_delivery`.
3. **Send `X-Idempotency-Key` on every start request.** A network timeout on your side must not start the
   work twice. The same key returns the same run with `200` and `X-Idempotent-Replay: true`.
4. **Never put secrets in `inputs`.** Inputs are stored with the run and included in audit summaries.
   Reference credentials by name and keep the values in your own vault.
5. **Handle `403` by fixing your key, not by retrying.** A missing scope will never resolve itself.
6. **Rotate keys on a schedule**, and on any suspicion of exposure. Rotation invalidates the previous token
   immediately.

---

## 5. Data handling

| | |
|---|---|
| **What leaves the platform** | Nothing is pushed out. Data leaves only in response to a call you make, and only for runs your key started |
| **What is stored with a run** | The inputs you sent, the outputs produced, cost and token counts, and the audit trail |
| **Model providers** | Azure OpenAI, OpenAI, or a deterministic mock, chosen by deployment configuration. Ask your platform operator which is active — it determines where prompt content is processed |
| **Retention** | Execution evidence is deleted after `ARTIFACT_RETENTION_DAYS` (default 30), files included |
| **Secrets** | The platform stores credential *references*, never raw secret values |

---

## 6. Failure modes and what to do

| Status | Meaning | What to do |
|---|---|---|
| `401` | Key missing, unknown, revoked or expired | Fix the key. Do not retry; every failure reads the same by design |
| `403` | The key lacks the scope named in `details.required_scope` | Grant the scope. Retrying will not help |
| `404` | Not granted, or does not exist — indistinguishable on purpose | Check what your key was granted via `/catalog` |
| `409` | Conflicts with the current state | Re-read the run before acting |
| `422` | The request or the requested change is not permitted | Read `error.details`; for healing this often means the change type is forbidden |
| `402` | A budget would be exceeded | Raise the budget or reduce scope. The run did not start |
| `5xx` | Platform fault | Retry with backoff **and** your original idempotency key |

Every error has the same shape:

```json
{ "error": { "code": "forbidden", "message": "…", "details": {}, "correlation_id": "…" } }
```

Log the `correlation_id`. It ties your request to the platform's own logs and audit entries.

---

## 7. Verifying this document

Do not take it on trust:

```bash
curl -H "X-API-Key: $QE_API_KEY" \
     https://<host>/api/v1/integration/manifest | jq '.guardrails'
```

Each guarantee returns its `id`, its `statement` and the module that enforces it. The active governance
policies for your project are listed alongside, so you can see what is switched on rather than what is
switchable.
