# Integration recipes

Working patterns for the three ways other systems usually drive this platform. Each one handles
`waiting_for_approval` properly, because that is where most integrations go wrong.

---

## 1. A CI quality gate

**Goal:** the pipeline starts a regression flow, waits, and fails the build only on a real failure.

```bash
#!/usr/bin/env bash
set -euo pipefail

BASE="https://qe.internal/api/v1/integration"
AUTH="X-API-Key: ${QE_API_KEY}"

run=$(curl -sf -X POST "$BASE/flows/${QE_FLOW_ID}/runs" \
  -H "$AUTH" -H "Content-Type: application/json" \
  -H "X-Idempotency-Key: ${BUILD_ID}" \
  -d "{\"inputs\":{\"changed_modules\":${CHANGED_MODULES}},\"title\":\"Build ${BUILD_ID}\"}")

run_id=$(jq -r .run_id <<<"$run")
echo "QE run ${run_id} started"

deadline=$(( $(date +%s) + 1800 ))
while :; do
  run=$(curl -sf "$BASE/runs/${run_id}" -H "$AUTH")
  disposition=$(jq -r .disposition <<<"$run")
  [[ $(jq -r .is_terminal <<<"$run") == "true" ]] && break
  if (( $(date +%s) > deadline )); then
    echo "Timed out waiting for ${run_id}; it is still ${disposition}."
    exit 1
  fi
  sleep 15
done

case "$disposition" in
  succeeded) echo "Quality gate passed."; exit 0 ;;
  waiting_for_approval)
    # Not a failure. A QE lead has to decide, and the build should not fail
    # because a human has not clicked yet.
    jq -r '.guardrails.awaiting_approval[] | "Waiting on \(.required_role): \(.title)"' <<<"$run"
    exit 0 ;;
  refused)
    echo "Policy refused this run:"; jq -r .error <<<"$run"; exit 1 ;;
  *)
    echo "Quality gate failed (${disposition}):"; jq -r .error <<<"$run"; exit 1 ;;
esac
```

**Two decisions worth copying.** The idempotency key is the build id, so a retried pipeline step re-attaches
to the run it already started instead of launching a second one. And `waiting_for_approval` exits `0` — if
you fail the build there, you are failing it because a person was at lunch.

If your organisation would rather block: exit with a distinct code and let the pipeline mark the stage
*unstable* rather than *failed*, so the difference stays visible.

---

## 2. An internal portal

**Goal:** a team portal lists what can be run, renders a form from the schema, and shows progress.

```python
import requests

BASE, HEAD = "https://qe.internal/api/v1/integration", {"X-API-Key": QE_API_KEY}


def available():
    """Drive the UI from the catalog, so a new flow appears without a deploy."""
    catalog = requests.get(f"{BASE}/catalog", headers=HEAD, timeout=30).json()
    return [
        {
            "id": flow["id"],
            "name": flow["name"],
            "description": flow["description"],
            # Render the form straight from the published schema.
            "fields": flow["input_schema"]["properties"],
            "will_need_approval": flow["guardrails"]["requires_approval"],
        }
        for flow in catalog["flows"]
    ]


def start(flow_id: str, inputs: dict, requested_by: str) -> str:
    response = requests.post(
        f"{BASE}/flows/{flow_id}/runs",
        headers={**HEAD, "X-Idempotency-Key": f"portal-{requested_by}-{hash(frozenset(inputs))}"},
        json={"inputs": inputs, "title": f"Requested by {requested_by}"},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()["run_id"]


def progress(run_id: str) -> dict:
    """What to show a person who is watching."""
    run = requests.get(f"{BASE}/runs/{run_id}", headers=HEAD, timeout=30).json()
    step = run["progress"]
    percent = round(100 * step["completed_steps"] / max(step["total_steps"], 1))

    if run["disposition"] == "waiting_for_approval":
        blocking = run["guardrails"]["awaiting_approval"][0]
        return {
            "state": "waiting",
            "percent": percent,
            "message": f"Waiting for a {blocking['required_role']} to approve: {blocking['title']}",
        }
    return {
        "state": run["disposition"],
        "percent": percent,
        "message": run["summary"] or run["error"] or "Running…",
        "cost": run["guardrails"]["cost"]["total_cost_usd"],
    }
```

Building the form from `input_schema` means a flow whose variables change does not need a portal release.

---

## 3. Another agent platform calling in

**Goal:** an orchestrator elsewhere treats this platform as one tool among several, and has to reason about
the result rather than display it.

```python
def qe_tool(flow_id: str, inputs: dict, correlation_id: str) -> dict:
    """A tool another agent can call. Returns a result it can act on."""
    started = requests.post(
        f"{BASE}/flows/{flow_id}/runs",
        headers={**HEAD, "X-Idempotency-Key": correlation_id,
                 "X-Correlation-ID": correlation_id},
        json={"inputs": inputs},
        timeout=30,
    ).json()

    run = poll_until_terminal(started["run_id"], timeout_s=1800)

    if run["disposition"] == "succeeded":
        return {"ok": True, "outputs": run["outputs"], "cost_usd": run["guardrails"]["cost"]["total_cost_usd"]}

    if run["disposition"] == "waiting_for_approval":
        blocking = run["guardrails"]["awaiting_approval"]
        # Tell the calling agent the truth: this is unfinished, not failed, and
        # no amount of retrying will change it. A person is the next step.
        return {
            "ok": False,
            "retryable": False,
            "needs_human": True,
            "reason": blocking[0]["reason"] if blocking else "Awaiting approval.",
            "run_id": run["run_id"],
        }

    return {"ok": False, "retryable": run["disposition"] != "refused",
            "reason": run.get("error") or run["disposition"], "run_id": run["run_id"]}
```

The distinction that matters: `needs_human` is separate from `retryable`. An agent told only "failed" will
retry a run that is waiting on a person, and will keep retrying. Passing the `correlation_id` through as both
the idempotency key and the correlation header means those retries are harmless and every attempt is
traceable across both platforms.

---

## 4. Things that go wrong

| Symptom | Cause | Fix |
|---|---|---|
| Builds fail intermittently on "approval" | `waiting_for_approval` treated as failure | Handle it as a hold — see recipe 1 |
| Two runs per build | No idempotency key, and the pipeline retried | Send `X-Idempotency-Key` |
| `404` on a flow that exists | The key was not granted it | Check `/catalog`; empty allow-list means none |
| `403` that keeps repeating | Missing scope | Read `details.required_scope`; retrying will never help |
| `404` polling a run you started | Polling with a different key | A key can only read its own runs |
| Costs higher than expected | Flow run per commit rather than per merge | Trigger on merge, or narrow `inputs` |

---

## 5. Before you ship

- [ ] `waiting_for_approval` handled as a hold, not a failure
- [ ] `X-Idempotency-Key` on every start request
- [ ] Polling has a timeout, and the timeout does not cancel the run
- [ ] `correlation_id` logged on every response
- [ ] No secrets in `inputs`
- [ ] The key has the fewest scopes that work, and an expiry
- [ ] You have read [guardrails.md §3](guardrails.md#3-what-is-not-guaranteed), *What is not guaranteed*
