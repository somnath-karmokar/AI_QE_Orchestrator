# Integration API reference

Base path `/api/v1/integration`. Authentication is `X-API-Key: qei_…` on every request.

The examples below are real responses from a running instance, trimmed for length.

## Swagger and the machine-readable spec

| | |
|---|---|
| **Browse and try it** | **`/api/integration-docs`** — Swagger UI for this surface alone |
| **Generate a client** | **`/api/v1/integration/openapi.json`** — OpenAPI 3.1 |

Send your `X-API-Key` when fetching the spec (or click **Authorize** in the UI and reload) and it also
describes **your own flows and agents** — one operation each, carrying its real input schema. That is the
version worth generating a client from: a typed call per flow, rather than one generic call taking an
untyped dictionary.

```bash
curl -H "X-API-Key: $QE_API_KEY"      https://<host>/api/v1/integration/openapi.json > qe-api.json

npx @openapitools/openapi-generator-cli generate     -i qe-api.json -g typescript-fetch -o ./qe-client
```

Without a key it describes the contract and nothing about any project.

> The platform's own `/api/docs` and `/api/openapi.json` document all 118 routes, including everything the
> web app uses. Generate from those and you get a hundred methods you must not call. Use the scoped document
> above.

---

---

## GET /manifest

**Scope:** none beyond a valid key. The first call an integrator makes.

```json
{
  "platform": { "name": "AI QE Orchestrator", "version": "1.0.0",
                "api_version": "v1", "base_path": "/api/v1/integration" },
  "client":   { "name": "jenkins-nightly", "project_id": "f757a0a7-…",
                "platform": "jenkins", "token_hint": "4x57",
                "expires_at": "2027-09-18T14:47:40Z" },
  "authentication": {
    "scheme": "api_key",
    "header": "X-API-Key",
    "scopes_granted": ["catalog:read", "flows:run", "runs:read", "approvals:read"],
    "scopes_available": { "catalog:read": "…", "flows:run": "…" }
  },
  "limits": { "rate_limit_per_minute": 60, "flows_available": 1, "agents_available": 0 },
  "guardrails": {
    "guarantees": [
      { "id": "human_approval_for_high_risk", "statement": "…",
        "enforced_by": "app/governance/policy_engine.py" },
      { "id": "business_assertions_never_changed", "statement": "…",
        "enforced_by": "app/healing/policy.py" }
    ],
    "caller_obligations": ["Treat 'waiting_for_approval' as a normal outcome…"],
    "active_policies": [
      { "key": "high-risk-requires-approval", "type": "approval",
        "effect": "require_approval", "severity": "high" }
    ]
  },
  "endpoints":   { "run_status": "GET /integration/runs/{run_id}" },
  "conventions": {
    "run_dispositions": ["cancelled","failed","pending","refused","succeeded","waiting_for_approval"],
    "terminal_dispositions": ["cancelled","failed","refused","succeeded"],
    "correlation_header": "X-Correlation-ID",
    "idempotency_header": "X-Idempotency-Key"
  }
}
```

`guardrails.active_policies` is what is **switched on** for your project, not what is switchable. Read it if
you need to know why a run might pause or be refused.

---

## GET /catalog

**Scope:** `catalog:read`. Only what this key was granted; an ungranted flow is not listed and cannot be
discovered here.

```json
{
  "project_id": "f757a0a7-…",
  "flows": [
    {
      "id": "037ea353-…",
      "name": "Payment Regression Intelligence",
      "description": "Predicts risk, selects an optimised regression suite…",
      "category": "Quality Intelligence",
      "version": "1.0.0",
      "status": "published",
      "owner": "priya.raman@example.com",
      "invoke": { "method": "POST", "path": "/integration/flows/037ea353-…/runs",
                  "scope": "flows:run" },
      "input_schema": {
        "type": "object",
        "properties": {
          "changed_modules": { "type": "array", "default": ["Payments", "Beneficiaries"],
                               "description": "Flow variable 'changed_modules'." }
        },
        "additionalProperties": false
      },
      "guardrails": { "requires_approval": false, "risk_level": "medium",
                      "cost_budget_usd": null }
    }
  ],
  "agents": [],
  "counts": { "flows": 1, "agents": 0 }
}
```

`input_schema` is ordinary JSON Schema. Validate against it, build a form from it, or generate a client —
whichever suits. `guardrails.requires_approval` tells you in advance whether a run of this flow will stop for
a human.

---

## POST /flows/{flow_id}/runs

**Scope:** `flows:run`. Returns **202 Accepted** — the work has been accepted, not finished.

```http
POST /api/v1/integration/flows/037ea353-…/runs
X-API-Key: qei_…
X-Idempotency-Key: build-8412
Content-Type: application/json

{ "inputs": { "changed_modules": ["Payments"] },
  "title": "Nightly build 8412",
  "environment_id": null }
```

| Field | Required | Notes |
|---|---|---|
| `inputs` | no | **Validated against the flow's published `input_schema`.** An input the flow does not declare is rejected, not ignored — see below |
| `title` | no | What the run is called in the platform's UI; use your build reference |
| `environment_id` | no | Defaults to the flow's own environment |

### Inputs are checked, and unknown keys are refused

An input the flow does not declare returns **422** rather than being dropped:

```json
{ "error": {
    "code": "validation_error",
    "message": "These inputs do not match what this flow accepts.",
    "details": {
      "invalid_inputs": [
        { "field": "changed_moduls",
          "message": "'changed_moduls' is not an input this accepts. Sending it would have no effect, and the run would silently use the declared default instead.",
          "did_you_mean": "changed_modules" }
      ],
      "accepts": ["changed_modules"] } } }
```

This is deliberate, and it is the reason `input_schema` publishes
`"additionalProperties": false`. If a mistyped key were accepted and ignored, the flow would run on its
**declared default** and return a green result about something you never asked for — with nothing in the
response to tell you. An error is a better outcome than a wrong answer.

Every problem is reported at once, so you are not fixing one field per round trip. Type mismatches, `enum`
values and array item types are checked the same way.

### The response says what it will actually run with

An accepted start echoes the effective inputs and where each value came from, so *"run it with my data"* is
verifiable rather than assumed:

```json
"inputs_applied": {
  "changed_modules":        { "value": ["Payments"],  "source": "caller" },
  "completeness_threshold": { "value": 80,            "source": "flow_default" }
}
```

Assert on this in your integration if it matters which values were used.

There is no callback: poll `links.self` until `is_terminal` is true.

Send `X-Idempotency-Key` on every call. Repeating it returns **200** with `X-Idempotent-Replay: true` and the
original run, rather than starting a second one. The key is scoped to your client, so two systems can use the
same build number without colliding.

A flow you were not granted returns **404** with the same message as a flow that does not exist.

---

## POST /agents/{agent_key}/runs

**Scope:** `agents:run`, and the agent must be in the key's allow-list.

Identical request shape. Runs a single agent instead of a flow; the same governance applies, so an agent that
requires approval pauses here exactly as it would inside a flow.

---

## GET /runs/{run_id}

**Scope:** `runs:read`. Only runs **this key started** — another key's runs, and runs a person started in the
web app, return 404.

```json
{
  "run_id": "…", "run_number": 208, "title": "Nightly build 8412",
  "kind": "flow", "status": "succeeded",

  "disposition": "succeeded",
  "is_terminal": true,

  "flow_id": "037ea353-…",
  "correlation_id": "…",
  "started_at": "2026-09-18T14:52:01Z",
  "finished_at": "2026-09-18T14:52:49Z",
  "duration_ms": 48120,
  "summary": "Selected 34 of 118 tests…",
  "error": null,
  "progress": { "completed_steps": 3, "total_steps": 3 },

  "guardrails": {
    "awaiting_approval": [],
    "cost": { "total_cost_usd": 0.169415, "total_tokens": 13647 },
    "note": null
  },

  "outputs": {
    "defect-prediction": { "…": "…" },
    "regression-suite-optimization": { "…": "…" },
    "traceability-coverage": { "…": "…" }
  },

  "links": { "self": "/api/v1/integration/runs/…",
             "cancel": "/api/v1/integration/runs/…/cancel" }
}
```

**Branch on `disposition`.** `status` is internal vocabulary and may gain values; `disposition` is the fixed
set below.

| `disposition` | Meaning | `is_terminal` |
|---|---|---|
| `pending` | Queued or running | `false` |
| `waiting_for_approval` | Stopped, waiting for a named person | `false` |
| `succeeded` | Finished — read `outputs` | `true` |
| `failed` | Finished — read `error` | `true` |
| `cancelled` | Stopped by a person or by your key | `true` |
| `refused` | Policy did not permit it | `true` |

`outputs` is keyed by the agent that produced each result, so a flow that runs three agents returns three
entries. The internal step graph is deliberately **not** part of this response; use `progress` for a progress
bar.

When a run is waiting, the block is populated and says so in plain words:

```json
"guardrails": {
  "awaiting_approval": [
    { "approval_id": "…", "title": "Apply 4 locator repairs to the payments suite",
      "reason": "Self-healing proposes changes to 4 test scripts.",
      "risk_level": "high", "required_role": "qe_lead",
      "requested_at": "…", "expires_at": "2026-09-20T09:00:00Z" }
  ],
  "cost": { "total_cost_usd": 0.041, "total_tokens": 3204 },
  "note": "This run is waiting for a named person to approve it. It has not failed, and it will continue once a decision is recorded."
}
```

---

## POST /runs/{run_id}/cancel

**Scope:** `runs:cancel`. Cancels a run this key started. A run that has already finished returns **422**.

---

## Key management (operator, not integrator)

These use a normal user session (`Authorization: Bearer <jwt>`) and the `governance:write` permission.

| Method | Path | Notes |
|---|---|---|
| `GET` | `/api/v1/integration-clients?project_id=…` | List keys; never returns tokens |
| `POST` | `/api/v1/integration-clients` | Issue a key — **the token is in this response only** |
| `POST` | `/api/v1/integration-clients/{id}/rotate` | New token; the previous one stops working at once |
| `DELETE` | `/api/v1/integration-clients/{id}` | Revoke |

```json
{
  "project_id": "…",
  "name": "jenkins-nightly",
  "platform": "jenkins",
  "scopes": ["catalog:read", "flows:run", "runs:read", "approvals:read"],
  "allowed_flow_ids": ["037ea353-…"],
  "allowed_agent_keys": [],
  "rate_limit_per_minute": 60,
  "callback_url": null,
  "expires_in_days": 365
}
```

Omit `scopes` for the default set. An explicit `[]` is rejected rather than quietly granting the defaults.
`allowed_flow_ids` and `allowed_agent_keys` are the complete list of what the key may invoke — empty means
none, never all.

---

## Errors

```json
{ "error": { "code": "forbidden",
             "message": "This API key does not have the 'catalog:read' scope.",
             "details": { "required_scope": "catalog:read",
                          "granted_scopes": ["flows:run"] },
             "correlation_id": "…" } }
```

| Status | `code` | Retry? |
|---|---|---|
| 401 | `unauthenticated` | No — fix the key |
| 403 | `forbidden` | No — grant the scope named in `details` |
| 404 | `not_found` | No — check `/catalog` for what you were granted |
| 409 | `conflict` | Re-read the run first |
| 422 | `validation_error` | No — read `details` |
| 402 | `budget_exceeded` | No — the run did not start |
| 5xx | `internal_error` | Yes, with backoff and the original idempotency key |

Every authentication failure returns the same message whatever the real cause, so the endpoint cannot be used
to distinguish an unknown key from a revoked one. The same applies to 404: an ungranted resource and a
non-existent one are byte-identical.

Log `correlation_id`; it ties your request to the platform's logs and audit entries.
