# Using a Flow or Agent from another platform — steps

**Audience:** an engineer on another system (CI server, release pipeline, portal, another agent
platform) who needs to call this platform's flows and agents over HTTP.

The short version. Detail lives in [api-reference.md](api-reference.md), what the platform promises
and refuses in [guardrails.md](guardrails.md), worked examples in [recipes.md](recipes.md). Every
request and response below was captured from a running server.

Base URL: `https://<host>/api/v1` — shown as `$API` below.

---

## 1. Get an API key

An operator issues it; you cannot self-serve. They call this once, with **their own** login token:

```bash
# The whole project: every published flow and every agent, including ones
# published after this key was issued.
curl -X POST $API/integration-clients \
  -H "Authorization: Bearer $OPERATOR_JWT" -H "Content-Type: application/json" \
  -d '{
        "project_id": "…",
        "name": "your-platform",
        "scopes": ["catalog:read", "flows:run", "agents:run", "runs:read", "runs:cancel"],
        "grants_all_flows": true,
        "grants_all_agents": true
      }'

# Or a named few, when the key should reach only those:
#   "allowed_flow_ids": ["<flow id>"], "allowed_agent_keys": ["user-story-completeness"]
```

The `201` response carries the key in **`token`**, once — it cannot be read back, only revoked. Keep it
as a secret and send it as `X-API-Key` on every call below.

- **Scopes** say *whether* (`catalog:read` `flows:run` `agents:run` `runs:read` `runs:cancel`
  `approvals:read`). There is no "all scopes", and `flows:run` does **not** imply `agents:run`.
- **Grants** say *which*: either a named list, or `grants_all_flows` / `grants_all_agents` for the
  whole project. Both are off unless asked for, so a key never widens by accident, and neither
  ever reaches another project.
- A **project-wide grant covers published flows only** — a draft is work in progress. A flow named
  explicitly is honoured whatever its status.
- Default limit: **60 calls a minute** per key (`rate_limit_per_minute`).

Operators can see the endpoint for any agent or flow, and which keys already reach it, from that
agent's or flow's page in the web app — the **API endpoint** panel.

## 1b. Check your key works

```bash
curl $API/integration/me -H "X-API-Key: $TOKEN"
```

Reaching it at all proves the key authenticated. The body says what it may reach, when it expires,
what is left of its rate limit and what it has already run — without starting any work, which is the
point: every other endpoint has a side effect.

Prefer a screen? Open **`/portal`** in a browser and sign in with the same key. It shows the same
thing, plus every flow and agent provisioned to you and the runs you have started. It needs no
account on this platform — the key *is* the account.

## 2. See what you may call

```bash
curl $API/integration/catalog -H "X-API-Key: $TOKEN"
```

Each flow and agent comes with its real input schema and how to call it:

```json
{ "id": "63c43006-…", "name": "PAY-201 readiness to test data",
  "invoke": { "method": "POST", "path": "/integration/flows/63c43006-…/runs", "scope": "flows:run" },
  "input_schema": { "type": "object", "additionalProperties": false,
                    "properties": { "requirement_key": {"type": "string"}, "module": {"type": "string"} } },
  "guardrails": { "requires_approval": true, "risk_level": "medium" } }
```

`invoke.path` is relative to `$API`. Note `guardrails.requires_approval` — that flow will pause for a
person (see §5). Prefer a generated client? `GET $API/integration/openapi.json` with your key returns
an OpenAPI 3.1 document with one typed operation per grant; browse it at `/api/integration-docs`.

## 3. Start a run

```bash
# a flow
curl -X POST $API/integration/flows/<flow_id>/runs \
  -H "X-API-Key: $TOKEN" -H "X-Idempotency-Key: $(uuidgen)" -H "Content-Type: application/json" \
  -d '{"inputs": {"requirement_key": "PAY-201", "module": "Payments"}}'

# a single agent — use the `key` from the catalog
curl -X POST $API/integration/agents/user-story-completeness/runs \
  -H "X-API-Key: $TOKEN" -H "X-Idempotency-Key: $(uuidgen)" -H "Content-Type: application/json" \
  -d '{"inputs": {"requirement_key": "PAY-201"}}'
```

```json
{ "run_id": "32d8cfbc-…", "status": "queued", "disposition": "pending", "is_terminal": false,
  "inputs_applied": { "module": {"value": "Payments", "source": "caller"},
                      "requirement_key": {"value": "PAY-201", "source": "caller"} },
  "links": { "self": "/api/v1/integration/runs/32d8cfbc-…", "cancel": "/api/v1/integration/runs/32d8cfbc-…/cancel" } }
```

- **`202`, not 200** — accepted, not finished.
- **`inputs` are checked against the schema and rejected if wrong** (§6) — never silently replaced by
  the flow's defaults. `inputs_applied` shows, per field, whether *your* value (`caller`) or the
  flow's default (`flow_default`) was used.
- **Send `X-Idempotency-Key` on every start** (any string you generate; a build number works). A
  retry with the same key returns the original run (`200` + `X-Idempotent-Replay: true`) instead of
  starting another, so a timeout on your side can't run the work twice. A key is remembered per API
  key and per flow/agent: reusing one build number for a flow *and* an agent starts both.

## 4. Poll for the result

```bash
curl $API/integration/runs/<run_id> -H "X-API-Key: $TOKEN"     # the links.self URL
```

Poll until `is_terminal` is `true`. **There are no callbacks**: a `callback_url` on a key is stored
but never called. A run paused at an approval gate looks like this:

```json
{ "status": "awaiting_approval", "disposition": "waiting_for_approval", "is_terminal": false,
  "progress": { "completed_steps": 2, "total_steps": 3 },
  "guardrails": {
    "awaiting_approval": [ { "title": "Approve test data creation", "risk_level": "medium",
                             "required_role": "qe_lead", "expires_at": "2026-09-23T06:53:20+00:00" } ],
    "note": "This run is waiting for a named person to approve it. It has not failed, and it will continue once a decision is recorded." } }
```

## 5. Branch on `disposition`, never on `status`

`status` is internal vocabulary and may gain values. `disposition` is the stable set:

| `disposition` | Meaning | Do |
|---|---|---|
| `pending` | Queued or running | Keep polling |
| `waiting_for_approval` | Paused for a named person — **not a failure** | Keep polling; surface `guardrails.awaiting_approval` to a human if useful |
| `succeeded` | Done | Read `outputs` |
| `failed` | Done, unsuccessfully | Read `error` |
| `cancelled` | Cancelled | Stop |
| `refused` | Blocked by policy before it ran | Read `error`; a configuration problem, not transient |

Check `is_terminal` rather than listing the terminal values yourself.

## 6. Errors

Every error has one shape. **Quote `correlation_id` when you report a problem** — it finds the request in the logs.

```json
{ "error": { "code": "…", "message": "…", "details": {}, "correlation_id": "…" } }
```

| HTTP | `code` | Meaning |
|---|---|---|
| 401 | `unauthenticated` | Missing, unknown, revoked or expired key — deliberately the same message for all four |
| 403 | `forbidden` | Key lacks a scope; `details.required_scope` and `granted_scopes` say which |
| 404 | `not_found` | Not granted **or** doesn't exist — identical response, on purpose |
| 422 | `validation_error` | Inputs don't match the schema (below) |
| 429 | `rate_limited` | Wait `details.retry_after_seconds` (there is **no** `Retry-After` header). Every authenticated call counts, including ones that fail |

A rejected input names the field and guesses the fix. Don't resend unchanged:

```json
{ "error": { "code": "validation_error", "message": "These inputs do not match what this flow accepts.",
    "details": { "invalid_inputs": [ { "field": "module_name", "message": "'module_name' is not an input this accepts. …",
                                       "did_you_mean": "module" } ],
                 "accepts": ["module", "requirement_key"] } } }
```

(`accepts` is listed for flows; an agent's 422 has `invalid_inputs` only.)

## 6b. List your runs

```bash
curl "$API/integration/runs?limit=20" -H "X-API-Key: $TOKEN"
```

Newest first, scoped exactly as reading one run is: your key's own runs, never another key's and
never one a person started in the web app. Needs `runs:read`.

## 7. Cancel a run

```bash
curl -X POST $API/integration/runs/<run_id>/cancel -H "X-API-Key: $TOKEN"
```

Needs `runs:cancel`; only for runs your key started. A run that has already finished returns `422`.

---

**Calling from an agent platform instead of a pipeline?** Skip the REST calls and speak MCP — same
flows and agents, same key and scopes, JSON-RPC 2.0 at `$API/mcp`. See [mcp.md](mcp.md).
