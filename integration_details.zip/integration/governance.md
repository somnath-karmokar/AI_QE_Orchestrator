# Governance and observability for consuming platforms

**Audience:** teams integrating with this platform, and the governance reviewers who approve that
integration. Everything here is available over the integration API with your own key.

| You want to… | Call | Scope |
| --- | --- | --- |
| Know what an agent or flow is before trusting it | `GET /integration/agents/{key}/model-card` · `GET /integration/flows/{id}/model-card` | `catalog:read` |
| Check your integration, and evidence behaviour | `GET /integration/agents/{key}/golden-dataset` · `GET /integration/flows/{id}/golden-dataset` | `catalog:read` |
| Know how to operate the integration | `GET /integration/sop` ([SOP.md](SOP.md)) | any valid key |
| See what one run did | `GET /integration/runs/{run_id}/log` | `runs:logs` |
| Feed every audit entry into your SIEM | `GET /integration/audit-events?cursor=…` | `runs:logs` |
| Watch outcomes, latency, cost and model use | `GET /integration/metrics?days=30` | `runs:logs` |
| Find runs | `GET /integration/runs?agent_key=…&flow_id=…&disposition=…&since=…&until=…` | `runs:read` |

`runs:logs` is separate from `runs:read` on purpose: a pipeline polling for a result needs the result, not
the models, costs and audit trail behind it. Ask the operator who issued your key to grant it.

Over MCP, `get_run_log` returns the same log as the REST route, and is listed only for a key holding
`runs:logs`.

---

## 1. Where this comes from

The organisation's agent documentation package (`requirement_docs/`) has three artefacts. Here is what
each is for, and what this platform provides in its place.

| Artefact | What it is | Here |
| --- | --- | --- |
| **Model card** (`model-card.json`) | Identity and ownership, model and provider, tools with schemas, input/output contract, compliance controls, resilience, performance, endpoints, monitoring | **Generated for every agent and flow**, on request, from the live definition. Field names follow the organisation's card so a reviewer finds the same things in the same places. |
| **Golden dataset** (`golden_dataset_strands.json`) | Test cases with expected content and expected tool use, tool fixtures, edge cases, quality targets | **Provided for every agent and every reference flow**: schema-derived edge cases (true in any project) plus curated reference cases. The platform's own build executes every case. |
| **SOP** (`Strands_Agent_SOP.docx`) | A runbook for one deployed agent: configure credentials, start the service, check `/health`, watch logs | **One SOP for consumers**, not one per agent. Those agents are separately deployed services; ours all run behind one API, so 25 copies of one procedure would only drift. Per-agent specifics (approval roles, typical duration) are in each model card's `operations` block. |

What was deliberately *not* created: per-agent SOPs (see above), and tool response fixtures. The Strands
dataset needs fixtures because its tools return canned data. Ours read the reference project, so its seeded
data is the fixture.

---

## 2. Model cards

Generated on every request from what is actually deployed. A hand-written card is correct the day it is
written and drifts after that. Three rules keep it honest:

- **Performance is observed, never asserted.** `performance_characteristics` is computed from recorded runs in
  your project over the last 30 days. With fewer than 5 finished runs it says `insufficient_data: true` and
  reports no rates. The marketplace figures shown in the web app are seeded demo statistics and are
  never used here.
- **A control is listed only if code enforces it**, with the file that enforces it (`enforced_by`). The PII
  masking control appears only while the masking policy is enabled. Where a reviewer would expect a
  control that does not exist, the card says so: `resilience.circuit_breaker.provided` is `false`, and retries
  are described as they are (linear backoff, capped at 5 seconds).
- **Prompts are identified, not published.** `prompts` lists each template's id and version, so a change to
  what an agent is told is visible to governance. The text is not sent to callers.

The `model` block is the model the router would choose *now*. A flow node or the project can pin a different
one, so the model actually used is recorded per run in the run log.

A flow's card adds its graph: every node (agent, version, approval gate, retry, timeout, cost limit, pinned
model), every edge and condition, its approval gates and SLO, and whether observed performance meets that SLO.

## 3. Golden datasets

Each dataset has two kinds of case:

- **`edge_cases`** are derived from the published input schema: a misspelled field is refused with a
  suggestion, a wrong type is refused naming the field, and a missing required field is refused. They hold in
  any project. Run them before go-live to prove your integration handles refusals.
- **`test_cases`** are curated reference cases, written against the reference project `ABCR` (the seeded demo
  data, with its knowledge indexed). Only checkable expectations are used: a disposition, a pending approval,
  an output key, a word in the summary, a minimum count. Nothing depends on a model's wording.
  `expectation_semantics` in every dataset defines each one.

Every case of every dataset is executed through this API by `tests/test_golden_datasets.py` on every build. A
dataset that stops being true fails the build instead of misleading you.

`metadata.side_effects` says whether running a case writes to the project, for example generated tests or
data sets. Run reference cases against a non-production project.

## 4. The run log

`GET /integration/runs/{run_id}/log` is a versioned contract (`schema_version`), separate from the run envelope
so that the envelope stays small and stable.

```jsonc
{
  "schema_version": "1.0",
  "run": { "run_id": "…", "disposition": "succeeded", "agent_key": "impact-analyzer",
           "correlation_id": "…", "idempotency_key": "…", "inputs": { … }, "duration_ms": 1712 },
  "activities": [{
      "sequence": 1, "kind": "agent", "agent": { "key": "impact-analyzer", "version": "1.0.0" },
      "status": "succeeded", "attempt": 1, "duration_ms": 1650, "confidence": 0.9,
      "model": { "provider": "bedrock", "model": "…", "deployment": null },
      "usage": { "prompt_tokens": 3412, "completion_tokens": 820, "total_tokens": 4232, "cost_usd": 0.0133 },
      "tools": [{ "server": "jira", "tool": "get_story", "success": true, "duration_ms": 16, "error": null }],
      "policy": { "effect": "allow", "requires_approval": false, "policies": ["pii-masking-required"] } }],
  "timeline":  [{ "sequence": 1, "at": "…", "type": "flow_started", "message": "…" }],
  "approvals": [{ "title": "…", "required_role": "qe_lead", "status": "approved", "decided_at": "…" }],
  "audit":     [{ "at": "…", "action": "integration.agent_invoked", "actor": "integration:your-key", "outcome": "success" }],
  "usage":     { "total_tokens": 4232, "total_cost_usd": 0.0133,
                 "by_model": [{ "provider": "bedrock", "model": "…", "calls": 1, "fallback_calls": 0 }] },
  "redaction": { "masked": { … }, "omitted": [ … ] }
}
```

**What is masked or left out.** Every response carries a `redaction` block that says the following:

- **Masked:** values under keys that name a secret (`api_key`, `password`, `token`, …) and personal data in
  free text (email addresses, card numbers, IBANs, SSNs).
- **Omitted:**
  - prompts and model responses;
  - tool call arguments;
  - step inputs and outputs (the run's result is in the envelope);
  - the identity of platform users who approved or acted. The log keeps the role, the decision and the
    time.

## 5. The audit feed

Oldest first, resumable. It never repeats an entry and never skips one written in the same instant:

```python
cursor = load_cursor()                       # None the first time
while True:
    page = get("/api/v1/integration/audit-events", params={"cursor": cursor, "limit": 500})
    ship_to_siem(page["items"])
    cursor = page["next_cursor"]             # returned even when the page is empty
    save_cursor(cursor)
    if not page["has_more"]:
        break
```

It covers every audit entry of every run your key started, including the entry recording the call that
started it. Runs other keys started, and runs people started in the web app, are not in it.

## 6. Metrics

`GET /integration/metrics?days=30` gives:

- runs by disposition, and the success rate of finished runs;
- duration p50, p95 and max;
- tokens and cost;
- a per-agent and per-flow breakdown;
- per-model calls, failures and fallbacks;
- approvals requested, pending and the median wait;
- the most frequent failure reasons.

## 7. Files, for reviews done on files

```bash
cd backend
python scripts/export_agent_documentation.py --project ABCR --out ../docs/agent-documentation
```

This writes `agents/<key>/model-card.json` and `golden-dataset.json` for every agent, and the same for every
published flow, generated by the code the API uses. It also regenerates [SOP.md](SOP.md), which the test suite
checks against the SOP the API serves.

## 8. Limits worth knowing

- A key sees only runs it started. Organisation-wide reporting is an operator task in the web app.
- Reference cases assume the reference project's data. In your own project, adapt the inputs, or rely on the
  edge cases.
- There are no push notifications yet: poll the run, and poll the audit feed.
