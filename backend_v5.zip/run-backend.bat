@echo off
rem Sets up (first run only) and starts the AI QE Orchestrator backend on its own.
rem Works from a copy of just this backend/ folder on another computer -- no
rem need for the rest of the repository.
rem
rem   run-backend.bat                  start on the default port, 8100
rem   run-backend.bat -Port 8200       start on another port
rem   run-backend.bat -Reset           rebuild demo data from scratch first
rem   run-backend.bat -SkipSeed        don't touch demo data at all
rem
rem Runs in the foreground: close this window, or press Ctrl+C, to stop it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run-backend.ps1" %*
if errorlevel 1 (
    echo.
    pause
)
