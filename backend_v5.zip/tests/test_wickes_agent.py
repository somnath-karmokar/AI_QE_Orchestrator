"""The Wickes Change Impact & Risk Analyzer, run as a genuine platform agent.

Everything the standalone demo script proves about the underlying modules
(`test_wickes_risk_model.py`, `test_wickes_test_pack.py`) is not automatically
true of the agent wired on top of them -- `gather_context`/`draft` do their own
assembly, and that is what these tests hold. Run through `BaseAgent.execute`,
the same path the Agent Details "Test this agent" panel and the integration
API both use, so a pass here is a pass for both.
"""

from __future__ import annotations

from sqlalchemy import select

import pytest

from app.agents.base import AgentContext
from app.agents.implementations.wickes import WickesChangeImpactAgent
from app.agents.registry import AGENT_CLASS_BY_KEY
from app.models.project import Project


@pytest.fixture
def ctx(db) -> AgentContext:  # noqa: ANN001
    project = db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()
    return AgentContext(session=db, project=project, actor="test")


def _run(ctx: AgentContext, change_request_id: str):  # noqa: ANN202
    return WickesChangeImpactAgent().execute(ctx, {"change_request_id": change_request_id})


def test_the_agent_is_registered_and_reachable_by_key() -> None:
    assert AGENT_CLASS_BY_KEY["wickes-change-impact-analyzer"] is WickesChangeImpactAgent


def test_the_input_schema_offers_every_change_request_as_a_dropdown_option() -> None:
    properties = WickesChangeImpactAgent.input_schema["properties"]["change_request_id"]
    assert properties["enum"], "the enum must be populated from the change board, not empty"
    assert "CR-1001" in properties["enum"]
    assert len(properties["enum"]) == len(properties["enumNames"])
    assert any("Apple Pay" in label for label in properties["enumNames"])


def test_cr_1001_reproduces_the_worked_example_through_the_full_agent_pipeline(ctx: AgentContext) -> None:  # noqa: ANN001
    """Not the service layer directly (that is what test_wickes_risk_model.py
    holds) -- BaseAgent.execute, exactly as the platform runs it."""
    result = _run(ctx, "CR-1001")

    assert result.status == "success"
    assert result.outputs["base_score"] == 124
    assert result.outputs["band"] == "Critical / P1"
    assert set(result.outputs["veto_triggered"]) == {"business_criticality", "security_data_privacy"}
    assert result.outputs["modifier"] == 2
    assert "124" in result.summary
    assert "Critical / P1" in result.summary


def test_the_reasoning_summary_narrates_every_pipeline_step(ctx: AgentContext) -> None:  # noqa: ANN001
    """This is the 'step by step log' the client demo asks for, rendered where
    the platform already renders it for every other agent -- the Run Detail
    page's 'How this was determined' panel -- rather than a bespoke feature."""
    result = _run(ctx, "CR-1001")
    for marker in ("[1] INPUT", "[1b] AI-ASSIST", "[2] SCORE", "[3] BAND", "[4] SELECT", "[5] OUTPUT", "[6] LEARN"):
        assert marker in result.reasoning_summary, marker


def test_the_veto_narrative_does_not_claim_an_escalation_that_did_not_happen(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-1001")
    assert "already at the top band" in result.reasoning_summary
    band_finding = next(f for f in result.findings if f["type"] == "band")
    assert "already at the top band" in band_finding["detail"]


def test_findings_carry_all_fifteen_dimensions_the_band_and_the_modifier(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-1001")
    dimension_findings = [f for f in result.findings if f["type"] == "dimension_score"]
    assert len(dimension_findings) == 15
    assert any(f["type"] == "band" for f in result.findings)
    assert any(f["type"] == "modifier" for f in result.findings)


def test_selected_tests_appear_as_findings_and_in_outputs(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-1001")
    test_findings = [f for f in result.findings if f["type"] == "selected_test"]
    assert len(test_findings) == len(result.outputs["selected_tests"]) > 0
    assert result.outputs["test_counts_by_priority"].get("P1", 0) > 0


def test_a_p1_heavy_critical_change_recommends_reviewing_the_release_gate(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-1001")
    assert result.next_action == "review_release_gate"
    assert any("scored the maximum" in r["action"].lower() for r in result.recommendations)
    assert any("P1 test(s) must pass" in r["action"] for r in result.recommendations)


def test_a_low_band_change_recommends_proceeding(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-1004")  # search relevance tuning -- Low band
    assert result.outputs["band"] == "Low"
    assert result.next_action == "proceed"


def test_the_escalation_recommendation_does_not_claim_a_move_that_did_not_happen(ctx: AgentContext) -> None:  # noqa: ANN001
    """CR-1001 was already at the top band before the escalation rule fired. The
    recommendation text must agree with 'How this was determined' -- not say
    'escalated' for a band that never moved."""
    result = _run(ctx, "CR-1001")
    escalation_rec = next(r for r in result.recommendations if "scored the maximum" in r["action"].lower())
    assert "escalated" not in escalation_rec["action"].lower()
    assert result.outputs["band"] in escalation_rec["action"]


def test_a_genuine_escalation_recommendation_does_say_escalated(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-1003")  # Medium base score, escalated to High
    escalation_rec = next(r for r in result.recommendations if "scored the maximum" in r["action"].lower())
    assert "escalated from" in escalation_rec["action"].lower()
    assert result.outputs["band_before_veto"] in escalation_rec["action"]
    assert result.outputs["band"] in escalation_rec["action"]


def test_a_second_independent_escalation_also_reports_correctly(ctx: AgentContext) -> None:  # noqa: ANN001
    """CR-1003 would be Medium on its base score alone; peak-trading exposure
    escalates it up to High. This is the genuinely-moved case, unlike CR-1001."""
    result = _run(ctx, "CR-1003")
    assert result.outputs["band_before_veto"] != result.outputs["band"]
    assert "escalated from" in result.reasoning_summary


def test_an_unknown_change_request_fails_cleanly_rather_than_crashing(ctx: AgentContext) -> None:  # noqa: ANN001
    result = _run(ctx, "CR-9999-DOES-NOT-EXIST")
    assert result.status == "failed"
    assert result.next_action == "abort"
    assert "was not found" in result.summary
    assert "CR-9999-DOES-NOT-EXIST" in result.summary
    # The available options are surfaced, so a caller can self-correct.
    assert result.outputs["available"]


def test_a_missing_change_request_id_is_refused_before_any_work_happens(ctx: AgentContext) -> None:  # noqa: ANN001
    from app.core.errors import ValidationError

    with pytest.raises(ValidationError):
        WickesChangeImpactAgent().execute(ctx, {})


def test_the_agent_never_builds_a_prompt_by_hand() -> None:
    """The platform-wide rule (test_prompt_library.py) applies here too --
    checked directly since that test only scans app/agents/implementations."""
    import pathlib

    source = (pathlib.Path("app/agents/implementations") / "wickes.py").read_text(encoding="utf-8")
    assert "ChatMessage(" not in source


def test_computed_outputs_cannot_be_overridden_by_a_real_models_reply(ctx: AgentContext, monkeypatch) -> None:  # noqa: ANN001
    """Under a real provider the payload is the model's own answer. The score
    and band are arithmetic; a model's wording must not be able to replace
    them, the same guarantee the other planning agents hold (see
    test_planning_agents.py's equivalent test)."""
    from app.ai.providers.mock import MockLLMProvider

    original = MockLLMProvider.chat
    invented = {
        "status": "success", "confidence": 0.99, "summary": "invented",
        "outputs": {"base_score": 1, "band": "Low", "invented": True},
    }

    def real_model(self, messages, selection, **kwargs):  # noqa: ANN001, ANN202
        kwargs["deterministic_draft"] = invented
        return original(self, messages, selection, **kwargs)

    monkeypatch.setattr(MockLLMProvider, "chat", real_model)
    result = _run(ctx, "CR-1001")

    assert result.summary == "invented"  # the model's wording stands
    assert result.outputs["base_score"] == 124  # the computed number does not
    assert "invented" not in result.outputs
