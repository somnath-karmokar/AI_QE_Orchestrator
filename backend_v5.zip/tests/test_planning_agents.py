"""The Coverage Planning agent.

Most of these build a small, private corner of the project -- one module, one
journey, a handful of requirements and tests -- rather than asserting against
the seeded demo data. The claims being tested are specific ("a changed
requirement reaches the steps its tests cover, not its whole module"), and a
fixture shaped to make that claim falsifiable is worth more than a count that
happens to hold for today's seed.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from app.core.time import UTC

import pytest
from sqlalchemy import select

from app.agents.base import AgentContext
from app.agents.implementations.planning import (
    TIER_POLICY,
    schedule,
    CoveragePlanningAgent,
)
from app.models.project import Project
# Aliased: pytest tries to collect any imported class whose name starts "Test".
from app.models.testing import (
    BusinessFlow,
    BusinessFlowStep,
    Requirement,
)
from app.models.testing import TestCase as CaseRow
from app.models.testing import TestDependency as DependencyRow
from app.models.testing import TestScenario as ScenarioRow


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


@pytest.fixture
def ctx(db, project) -> AgentContext:  # noqa: ANN001
    return AgentContext(session=db, project=project, actor="test")


def _tag() -> str:
    return uuid.uuid4().hex[:6].upper()


@pytest.fixture
def corner(db, project):  # noqa: ANN001, ANN201
    """A module of our own: one journey, two requirements, a few tests.

    Journey `Checkout <tag>`, in order:
      1. browse   -- module M, component `browse-<tag>`, covered by T-BROWSE
      2. pay      -- module M, component `pay-<tag>`,    covered by T-PAY
      3. confirm  -- module M, component `confirm-<tag>`, covered by nothing

    REQ-PAY owns T-PAY; REQ-BROWSE owns T-BROWSE. Step 1 comes *before* step 2,
    so a change to REQ-PAY must not reach it unless something widens the change
    to the whole module.
    """
    tag = _tag()
    module = f"Module {tag}"
    flow = BusinessFlow(
        project_id=project.id,
        key=f"checkout-{tag.lower()}",
        name=f"Checkout {tag}",
        criticality="critical",
        owner="owner@example.com",
        modules=[module],
    )
    db.add(flow)
    db.flush()

    steps = {}
    for position, name in enumerate(("browse", "pay", "confirm"), start=1):
        step = BusinessFlowStep(
            business_flow_id=flow.id,
            position=position,
            key=f"{name}-{tag.lower()}",
            name=f"{name.capitalize()} {tag}",
            module=module,
            ui_components=[f"{name}-{tag.lower()}"],
            api_endpoints=[f"/api/{tag.lower()}/{name}"],
            assertions=[f"{name} works"],
        )
        db.add(step)
        steps[name] = step
    db.flush()

    requirements = {}
    for name, priority in (("PAY", "critical"), ("BROWSE", "low")):
        requirement = Requirement(
            project_id=project.id,
            external_key=f"{name}-{tag}",
            title=f"{name.title()} requirement {tag}",
            module=module,
            priority=priority,
            risk_score=0.9 if priority == "critical" else 0.1,
            change_frequency=8 if priority == "critical" else 0,
        )
        db.add(requirement)
        requirements[name] = requirement
    db.flush()

    tests = {}
    for name, step_name, requirement_name in (("PAY", "pay", "PAY"), ("BROWSE", "browse", "BROWSE")):
        scenario = ScenarioRow(
            project_id=project.id,
            requirement_id=requirements[requirement_name].id,
            key=f"SC-{name}-{tag}",
            title=f"Scenario {name}",
            scenario_type="positive",
            module=module,
        )
        db.add(scenario)
        db.flush()
        case = CaseRow(
            project_id=project.id,
            scenario_id=scenario.id,
            requirement_id=requirements[requirement_name].id,
            key=f"T-{name}-{tag}",
            title=f"Test {name}",
            module=module,
            priority="high",
            is_automated=False,
        )
        db.add(case)
        db.flush()
        db.add(
            DependencyRow(
                project_id=project.id,
                test_case_id=case.id,
                business_flow_step_id=steps[step_name].id,
                relationship_type="covers",
            )
        )
        tests[name] = case
    db.commit()
    db.refresh(flow)

    return {"tag": tag, "module": module, "flow": flow, "steps": steps, "requirements": requirements, "tests": tests}


def _plan(ctx, inputs):  # noqa: ANN001, ANN202
    return CoveragePlanningAgent().execute(ctx, inputs)


def test_no_prompt_block_is_cut_off(ctx) -> None:  # noqa: ANN001
    """A fenced block over the length limit is truncated mid-JSON, and the rows
    lost are whichever came last. Lists are fitted instead, and say so."""
    agent = CoveragePlanningAgent()
    inputs = {"capacity_days": 100}
    context = agent.gather_context(ctx, agent.validate_input(inputs))
    agent.begin_prompt()
    prompt = "".join(message.content for message in agent.build_messages(ctx, inputs, context))

    assert "[truncated]" not in prompt
    assert '"showing"' in prompt and '"of"' in prompt


# ===========================================================================
# Coverage Planning
# ===========================================================================


def test_each_requirement_is_held_to_its_tier(ctx, corner) -> None:  # noqa: ANN001
    result = _plan(ctx, {"modules": [corner["module"]], "capacity_days": 50})
    rows = {row["requirement"]: row for row in result.outputs["requirements"]}
    tag = corner["tag"]

    pay, browse = rows[f"PAY-{tag}"], rows[f"BROWSE-{tag}"]
    assert pay["tier"] in ("critical", "high")
    assert browse["tier"] == "low"

    # A low-tier requirement with one positive test meets its target...
    assert browse["meets_target"] is True
    # ...the same coverage on a high-risk requirement does not.
    assert pay["meets_target"] is False
    assert "missing_negative" in pay["gaps"]
    assert pay["required"] == TIER_POLICY[pay["tier"]]

    # People read the finding; the code is for machines.
    finding = next(f for f in result.findings if f.get("requirement") == f"PAY-{tag}")
    assert "no negative-path test" in finding["detail"]
    assert "missing_negative" not in finding["detail"]


def test_a_duplicate_test_is_not_counted_as_coverage(ctx, db, corner) -> None:  # noqa: ANN001
    tag = corner["tag"]
    original = corner["tests"]["BROWSE"]
    db.add(
        CaseRow(
            project_id=original.project_id,
            scenario_id=original.scenario_id,
            requirement_id=original.requirement_id,
            key=f"T-BROWSE-DUP-{tag}",
            title="Same test again",
            module=corner["module"],
            duplicate_of_id=original.id,
        )
    )
    db.commit()

    result = _plan(ctx, {"requirement_keys": [f"BROWSE-{tag}"]})
    row = result.outputs["requirements"][0]
    assert row["current"]["test_cases"] == 1
    assert result.outputs["duplicates_excluded"] >= 1


def test_work_is_ordered_by_risk_removed_per_day(ctx, corner) -> None:  # noqa: ANN001
    result = _plan(ctx, {"modules": [corner["module"]], "capacity_days": 50})
    items = result.outputs["plan"] + result.outputs["deferred"]
    scores = [item["priority_score"] for item in sorted(items, key=lambda i: i["rank"])]
    assert scores == sorted(scores, reverse=True)


def test_what_does_not_fit_is_deferred_and_said_out_loud(ctx, corner) -> None:  # noqa: ANN001
    result = _plan(ctx, {"modules": [corner["module"]], "capacity_days": 0})

    assert result.outputs["plan"] == []
    assert result.outputs["deferred"]
    assert result.outputs["coverage"]["meeting_target_after_plan"] == result.outputs["coverage"]["meeting_target_now"]
    assert "deferred" in result.summary
    # Deferring critical work is a decision somebody has to own.
    if any(item["tier"] == "critical" for item in result.outputs["deferred"]):
        assert any(
            rec["priority"] == "critical" and "engineer-day" in rec["action"]
            for rec in result.recommendations
        )


def test_a_large_item_that_does_not_fit_does_not_block_smaller_ones() -> None:
    """A big critical item that does not fit must not push out the small ones
    ranked after it -- that would be planning less than the days allow."""
    items = [
        {"requirement": "BIG", "tier": "critical", "effort_days": 2.0, "priority_score": 5.0},
        {"requirement": "SMALL", "tier": "low", "effort_days": 0.5, "priority_score": 1.0},
    ]
    remaining = schedule(items, capacity=1.0)

    by_key = {item["requirement"]: item for item in items}
    assert by_key["BIG"]["rank"] == 1 and by_key["BIG"]["planned"] is False
    assert by_key["SMALL"]["rank"] == 2 and by_key["SMALL"]["planned"] is True
    assert remaining == 0.5


def test_scheduling_never_exceeds_capacity() -> None:
    items = [
        {"requirement": f"R{i}", "tier": "high", "effort_days": effort, "priority_score": score}
        for i, (effort, score) in enumerate([(0.3, 3.0), (0.5, 2.5), (0.75, 1.2), (1.0, 0.6), (0.05, 14.0)])
    ]
    schedule(items, capacity=1.0)
    assert sum(item["effort_days"] for item in items if item["planned"]) <= 1.0 + 1e-9


def test_enough_capacity_closes_every_gap(ctx, corner) -> None:  # noqa: ANN001
    result = _plan(ctx, {"modules": [corner["module"]], "capacity_days": 100})
    coverage = result.outputs["coverage"]

    assert result.outputs["deferred"] == []
    assert coverage["meeting_target_after_plan"] == result.outputs["scope"]["requirements_in_scope"]
    assert coverage["risk_weighted_after_plan"] == 1.0
    assert coverage["risk_weighted_after_plan"] >= coverage["risk_weighted_now"]


def test_an_untested_journey_step_becomes_work_unless_excluded(ctx, corner) -> None:  # noqa: ANN001
    tag = corner["tag"]
    with_journeys = _plan(ctx, {"modules": [corner["module"]], "capacity_days": 50}).outputs
    steps = [i for i in with_journeys["plan"] + with_journeys["deferred"] if i["gap"] == "journey_step_untested"]
    assert [i["step"] for i in steps] == [f"Confirm {tag}"]
    assert steps[0]["tier"] == "critical"  # the journey's criticality

    without = _plan(ctx, {"modules": [corner["module"]], "capacity_days": 50, "include_journeys": False}).outputs
    assert not [i for i in without["plan"] + without["deferred"] if i["gap"] == "journey_step_untested"]


def test_a_test_that_never_ran_is_an_execution_gap_for_a_high_tier(ctx, corner) -> None:  # noqa: ANN001
    tag = corner["tag"]
    row = next(
        r
        for r in _plan(ctx, {"requirement_keys": [f"PAY-{tag}"], "capacity_days": 50}).outputs["requirements"]
    )
    assert row["current"]["last_executed"] is None
    assert "not_executed" in row["gaps"]


def test_a_recent_run_satisfies_the_execution_requirement(ctx, db, corner) -> None:  # noqa: ANN001
    tag = corner["tag"]
    case = corner["tests"]["PAY"]
    case.last_executed_at = datetime.now(UTC) - timedelta(days=2)
    case.execution_count = 1
    case.last_result = "passed"
    db.commit()

    row = _plan(ctx, {"requirement_keys": [f"PAY-{tag}"]}).outputs["requirements"][0]
    assert "not_executed" not in row["gaps"]


def test_an_unknown_requirement_key_is_reported(ctx, corner) -> None:  # noqa: ANN001
    result = _plan(ctx, {"requirement_keys": [f"PAY-{corner['tag']}", "GHOST-1"]})
    assert result.outputs["unresolved_requirements"] == ["GHOST-1"]
    assert result.status == "partial"


def test_a_scope_that_matches_nothing_says_so(ctx) -> None:  # noqa: ANN001
    result = _plan(ctx, {"modules": ["No Such Module"]})
    assert result.status == "partial"
    assert result.next_action == "ingest_requirements"


def test_the_assumptions_travel_with_the_plan(ctx, corner) -> None:  # noqa: ANN001
    """A plan whose effort figures are hidden can only be accepted or ignored."""
    assumptions = _plan(ctx, {"modules": [corner["module"]]}).outputs["assumptions"]
    assert set(assumptions) >= {"tier_policy", "effort_days", "gap_weights", "tier_formula"}


def test_a_real_models_answer_cannot_replace_the_computed_outputs(ctx, corner, monkeypatch) -> None:  # noqa: ANN001
    """A real provider answers instead of the deterministic draft. Its wording is
    welcome; a schedule it re-derived is not."""
    from app.ai.providers.mock import MockLLMProvider  # noqa: PLC0415

    original = MockLLMProvider.chat
    invented = {
        "status": "success",
        "confidence": 0.99,
        "summary": "The model's own summary.",
        "outputs": {"plan": [], "invented": True},
    }

    def real_model(self, messages, selection, **kwargs):  # noqa: ANN001, ANN202
        kwargs["deterministic_draft"] = invented  # what a real model would write
        return original(self, messages, selection, **kwargs)

    monkeypatch.setattr(MockLLMProvider, "chat", real_model)
    result = CoveragePlanningAgent().execute(ctx, {"modules": [corner["module"]], "capacity_days": 5})

    assert result.summary == "The model's own summary."  # the model's judgement stands
    assert "invented" not in result.outputs  # its numbers do not
    assert "assumptions" in result.outputs


# ===========================================================================
# Registered, seeded and runnable through the API
# ===========================================================================


def test_the_agent_is_in_the_catalogue_and_runs(client, auth_headers, project_id) -> None:  # noqa: ANN001
    key = "coverage-planning"
    listing = client.get("/api/v1/agents", headers=auth_headers, params={"limit": 200})
    assert listing.status_code == 200, listing.text
    agent = next((row for row in listing.json()["items"] if row["key"] == key), None)
    assert agent is not None, f"{key} was not seeded into the catalogue"
    assert agent["is_builtin"] is True

    response = client.post(
        f"/api/v1/agents/{agent['id']}/test",
        headers=auth_headers,
        json={"project_id": project_id, "inputs": {"capacity_days": 5}},
    )
    assert response.status_code == 200, response.text
    run = response.json()
    assert run["status"] == "succeeded", run
