"""Healing analytics.

A self-healing platform reporting its own success rate has an obvious incentive
to flatter itself. These tests exist to stop it: the numerator counts only
repairs a re-run proved, the effort figure states its own assumption, and the
confidence block is willing to report that confidence predicted nothing.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from app.core.time import UTC

import pytest

from app.healing.policy import ChangeType
from app.models.testing import HealingRecord
from app.services.healing_insights import (
    MINUTES_PER_MANUAL_REPAIR,
    dashboard,
    window_start,
)


def record(
    project_id: str,
    *,
    status: str,
    validation_status: str = "not_started",
    confidence: float = 0.9,
    change_type: str = ChangeType.LOCATOR,
    strategy: str = "test_id",
    age_days: int = 0,
) -> HealingRecord:
    row = HealingRecord(
        project_id=project_id,
        status=status,
        validation_status=validation_status,
        failure_class="locator_drift",
        change_type=change_type,
        original_locator="#old",
        proposed_locator="#new",
        locator_strategy=strategy,
        reason="because",
        confidence=confidence,
    )
    row.created_at = datetime.now(UTC) - timedelta(days=age_days)
    return row


@pytest.fixture
def analytics_project(db, project_id: str) -> str:
    """A fresh project id keeps these counts away from the seeded history."""
    from app.models.project import Project  # noqa: PLC0415

    project = Project(key="HEAL", name="Healing analytics fixture", description="test")
    db.add(project)
    db.flush()
    return project.id


# ---------------------------------------------------------------------------


def test_only_a_proven_repair_counts_as_a_success(db, analytics_project: str) -> None:
    """The distinction the whole dashboard rests on."""
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed"),
            record(analytics_project, status="applied", validation_status="passed"),
            # Applied before validation existed: real, but unproven.
            record(analytics_project, status="applied", validation_status="inconclusive"),
            record(analytics_project, status="rolled_back", validation_status="failed"),
        ]
    )
    db.flush()

    totals = dashboard(db, analytics_project)["totals"]
    assert totals["applied"] == 3
    assert totals["proven"] == 2
    assert totals["unproven_applied"] == 1
    # 2 proven out of 4 decided, not 3 applied out of 4.
    assert totals["success_rate"] == pytest.approx(0.5)


def test_an_undecided_proposal_is_not_counted_as_a_failure(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed"),
            record(analytics_project, status="proposed"),
            record(analytics_project, status="proposed"),
        ]
    )
    db.flush()

    totals = dashboard(db, analytics_project)["totals"]
    assert totals["decided"] == 1
    assert totals["awaiting_decision"] == 2
    # A proposal nobody looked at says nothing about how well healing works.
    assert totals["success_rate"] == pytest.approx(1.0)


def test_the_success_rate_states_its_own_basis(db, analytics_project: str) -> None:
    basis = dashboard(db, analytics_project)["totals"]["success_rate_basis"]
    assert "re-run passed" in basis


def test_a_run_with_no_healing_reports_zero_rather_than_dividing_by_zero(
    db, analytics_project: str
) -> None:
    result = dashboard(db, analytics_project)
    assert result["totals"]["success_rate"] == 0.0
    assert result["effort"]["hours_saved"] == 0.0
    assert result["confidence"]["separation"] is None


# ---------------------------------------------------------------------------


def test_results_are_broken_down_by_what_was_changed(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed"),
            record(analytics_project, status="rolled_back", validation_status="failed"),
            record(
                analytics_project,
                status="applied",
                validation_status="passed",
                change_type=ChangeType.TIMING,
                strategy="explicit_wait",
            ),
        ]
    )
    db.flush()

    rows = {row["change_type"]: row for row in dashboard(db, analytics_project)["by_change_type"]}
    assert rows["locator"]["success_rate"] == pytest.approx(0.5)
    assert rows["timing"]["success_rate"] == pytest.approx(1.0)


def test_which_rung_of_the_ladder_did_the_work_is_visible(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed", strategy="test_id"),
            record(analytics_project, status="applied", validation_status="passed", strategy="test_id"),
            record(analytics_project, status="applied", validation_status="passed", strategy="role"),
        ]
    )
    db.flush()

    rows = dashboard(db, analytics_project)["by_strategy"]
    assert rows[0]["strategy"] == "test_id"
    assert rows[0]["proposed"] == 2


# ---------------------------------------------------------------------------


def test_the_dashboard_will_report_that_confidence_predicted_nothing(
    db, analytics_project: str
) -> None:
    """The check a confidence score should have to survive. If repairs that held
    and repairs that did not scored the same, the number is decoration, and the
    dashboard says so rather than hiding it."""
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed", confidence=0.80),
            record(analytics_project, status="rolled_back", validation_status="failed", confidence=0.80),
        ]
    )
    db.flush()

    confidence = dashboard(db, analytics_project)["confidence"]
    assert confidence["separation"] == pytest.approx(0.0)
    assert "not earning its place" in confidence["note"]


def test_useful_confidence_shows_positive_separation(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed", confidence=0.95),
            record(analytics_project, status="rolled_back", validation_status="failed", confidence=0.60),
        ]
    )
    db.flush()
    assert dashboard(db, analytics_project)["confidence"]["separation"] > 0


# ---------------------------------------------------------------------------


def test_effort_saved_counts_only_repairs_that_held(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed"),
            record(analytics_project, status="applied", validation_status="inconclusive"),
            record(analytics_project, status="rolled_back", validation_status="failed"),
        ]
    )
    db.flush()

    effort = dashboard(db, analytics_project)["effort"]
    assert effort["repairs_that_held"] == 1
    assert effort["minutes_saved"] == MINUTES_PER_MANUAL_REPAIR
    # The assumption is part of the number, not a footnote somewhere else.
    assert str(MINUTES_PER_MANUAL_REPAIR) in effort["basis"]
    assert "did not hold are excluded" in effort["basis"]


def test_simulated_and_real_validation_are_not_blurred(db, analytics_project: str) -> None:
    """A success rate on simulated evidence means something different from the
    same rate on captured pages."""
    simulated = record(analytics_project, status="applied", validation_status="passed")
    simulated.validation_mode = "simulated"
    real = record(analytics_project, status="applied", validation_status="passed")
    real.validation_mode = "playwright"
    db.add_all([simulated, real])
    db.flush()

    validation = dashboard(db, analytics_project)["validation"]
    assert validation["by_mode"] == {"simulated": 1, "playwright": 1}
    assert validation["simulated_share"] == pytest.approx(0.5)


# ---------------------------------------------------------------------------


def test_the_window_is_midnight_aligned() -> None:
    """So a chart and a KPI over the same period agree, as they must."""
    now = datetime(2026, 9, 20, 14, 37, tzinfo=UTC)
    window = window_start(now, 7)
    assert window.start.hour == 0 and window.start.minute == 0
    assert (now.date() - window.start.date()).days == 6


def test_records_outside_the_window_are_excluded(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="applied", validation_status="passed", age_days=1),
            record(analytics_project, status="applied", validation_status="passed", age_days=90),
        ]
    )
    db.flush()
    assert dashboard(db, analytics_project, days=30)["totals"]["proposed"] == 1


def test_the_trend_has_one_point_per_day(db, analytics_project: str) -> None:
    assert len(dashboard(db, analytics_project, days=14)["trend"]) == 14


def test_the_queue_reports_what_is_waiting_now(db, analytics_project: str) -> None:
    db.add_all(
        [
            record(analytics_project, status="proposed", age_days=3),
            record(analytics_project, status="proposed", change_type=ChangeType.TEST_DATA),
        ]
    )
    db.flush()

    queue = dashboard(db, analytics_project)["queue"]
    assert queue["awaiting_decision"] == 2
    assert queue["oldest_hours"] >= 71
    assert queue["by_change_type"]["test_data"] == 1


# ---------------------------------------------------------------------------


def test_analytics_are_served(client, auth_headers, project_id: str) -> None:
    response = client.get(
        "/api/v1/healing/analytics",
        headers=auth_headers,
        params={"project_id": project_id, "window_days": 30},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["totals"]["success_rate_basis"]
    assert body["effort"]["basis"]
    assert len(body["trend"]) == 30
