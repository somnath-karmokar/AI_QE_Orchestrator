"""The tool-calling loop every agent now runs through (`BaseAgent.execute()`).

A zero-tool agent must be byte-for-byte grounded in its own deterministic draft, the
same as before this loop existed. A tool-bearing agent must let the (simulated) model
call a tool, see the fenced result, and still land on the grounded final answer.
Governance and the recursion cap are exercised directly rather than through a real
agent's business logic, which is already covered elsewhere.
"""

from __future__ import annotations

from typing import Any

import pytest
from sqlalchemy import select

from app.agents.base import AgentContext, BaseAgent
from app.agents.implementations.quality import AutomatedRCAAgent
from app.ai.providers.base import ChatMessage, LLMResponse, ModelSelection, TokenUsage
from app.ai.providers.mock import MockLLMProvider
from app.core.config import settings
from app.models.project import Project


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


@pytest.fixture
def ctx(db, project) -> AgentContext:  # noqa: ANN001
    return AgentContext(session=db, project=project, actor="test")


_DRAFT = {
    "status": "success",
    "confidence": 0.77,
    "summary": "State-derived answer, untouched by any model.",
    "outputs": {"answer": 42},
}


class _ZeroToolAgent(BaseAgent):
    key = "test-zero-tool"
    name = "Test Zero Tool Agent"
    supported_tools: list[str] = []

    def build_messages(self, ctx, inputs, context):  # noqa: ANN001, D102
        return [self.system_message(ctx), ChatMessage(role="user", content="Answer directly, no tools here.")]

    def draft(self, ctx, inputs, context):  # noqa: ANN001, D102
        return dict(_DRAFT)


class _ToolAgent(BaseAgent):
    key = "test-tool-agent"
    name = "Test Tool Agent"
    supported_tools = ["git"]

    def build_messages(self, ctx, inputs, context):  # noqa: ANN001, D102
        return [self.system_message(ctx), ChatMessage(role="user", content="Investigate before answering.")]

    def draft(self, ctx, inputs, context):  # noqa: ANN001, D102
        return dict(_DRAFT)


def test_zero_tool_agent_is_grounded_unchanged(ctx: AgentContext) -> None:
    """No tools bound -> exactly one model call -> the deterministic draft, verbatim."""
    agent = _ZeroToolAgent()
    result = agent.execute(ctx, {})

    assert result.status == "success"
    assert result.summary == _DRAFT["summary"]
    assert result.outputs == _DRAFT["outputs"]
    assert result.tool_calls == []


def test_tool_bearing_agent_calls_a_tool_before_answering(ctx: AgentContext) -> None:
    """The mock provider requests one tool call, the loop feeds the result back,
    and the second turn is grounded in the same deterministic draft."""
    agent = _ToolAgent()
    result = agent.execute(ctx, {})

    assert result.status == "success"
    assert result.summary == _DRAFT["summary"]
    assert result.outputs == _DRAFT["outputs"]
    # The mock provider picks one of git's 4 tools at random and synthesizes
    # schema-shaped (not necessarily resolvable) arguments for it -- e.g. a made-up
    # file path 404s against `get_file` -- so only the call itself, not its
    # success, is guaranteed. A failed call is still a governed, recorded one.
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["server"] == "git"


def test_governed_call_tool_still_rejects_a_tool_outside_the_allowlist(ctx: AgentContext) -> None:
    """Routing a call through a StructuredTool doesn't bypass `call_tool()`'s own
    allowlist check -- an agent scoped to `git` still can't reach `database`."""
    agent = _ToolAgent()
    log: list[dict[str, Any]] = []

    result = agent.call_tool(ctx, "database", "execute_read_query", {"query": "SELECT 1"}, tool_calls=log)

    assert result is None
    assert log[0]["success"] is False
    assert "not permitted" in log[0]["error"]


def test_recursion_cap_falls_back_to_deterministic_draft(
    ctx: AgentContext, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A model that never stops requesting tools still yields a usable result."""

    def _always_call_a_tool(
        self,
        messages: list[ChatMessage],
        selection: ModelSelection,
        *,
        response_schema=None,
        tools=None,
        timeout=None,
        deterministic_draft=None,
    ) -> LLMResponse:
        return LLMResponse(
            content="",
            selection=selection,
            usage=TokenUsage(prompt_tokens=10, completion_tokens=5),
            latency_ms=1,
            finish_reason="tool_calls",
            tool_calls=[{"id": "call_x", "name": (tools or [{}])[0].get("function", {}).get("name", ""), "arguments": {}}],
        )

    monkeypatch.setattr(MockLLMProvider, "chat", _always_call_a_tool)

    agent = _ToolAgent()
    result = agent.execute(ctx, {})

    # Never settles on its own -- the recursion cap in BaseAgent.execute() must
    # still produce the deterministic-draft fallback rather than raise.
    assert result.status in {"success", "needs_review"}
    assert result.summary
    assert len(result.tool_calls) > 1


def test_native_orchestration_engine_uses_the_old_single_call_path(
    ctx: AgentContext, monkeypatch: pytest.MonkeyPatch
) -> None:
    """ORCHESTRATION_ENGINE=native must not need langgraph/langchain-core at all --
    a tool-bearing agent still runs, just without a tool-calling loop."""
    monkeypatch.setattr(settings, "orchestration_engine", "native")

    agent = _ToolAgent()
    result = agent.execute(ctx, {})

    assert result.status == "success"
    assert result.summary == _DRAFT["summary"]
    assert result.outputs == _DRAFT["outputs"]
    # No loop in native mode: gather_context() made no calls, and nothing else did.
    assert result.tool_calls == []


def test_automated_rca_agent_runs_end_to_end_against_seeded_data(ctx: AgentContext) -> None:
    """A real, unmodified agent (not a test double) against real seeded demo data --
    confirms the universal loop rewire didn't break an actual business agent."""
    agent = AutomatedRCAAgent()
    result = agent.execute(ctx, {})

    assert result.status in {"success", "partial", "needs_review"}
    assert result.summary
    # Every tool call this run made -- hard-coded in gather_context() and/or
    # model-chosen through the loop -- went through the same governed call_tool().
    for call in result.tool_calls:
        assert call["server"] in {"git", "database"}
