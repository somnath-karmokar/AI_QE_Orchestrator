"""Flow Studio: composing and templating flows, and operating each flow on its own.

Covers the schedule rules, the plain-English composer, per-flow dashboards,
observability, governance and reports, the API trigger and the scheduler.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from app.core.time import UTC

import pytest
from sqlalchemy import select

from app.core.errors import ValidationError
from app.models.flow import AgentFlow
from app.models.governance import AuditLog
from app.models.project import Project
from app.models.run import AgentRun
from app.orchestration.composer import FlowComposer
from app.orchestration.graph import FlowGraph
from app.orchestration.schedule import describe_schedule, next_run_after, normalise_schedule
from app.services.flow_templates import create_from_template
from app.services.flow_triggers import apply_schedule, run_due_flows


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


def _seeded_flow_id(client, auth_headers, project_id: str, key: str) -> str:  # noqa: ANN001
    flows = client.get("/api/v1/flows", params={"project_id": project_id, "limit": 200}, headers=auth_headers).json()
    return next(flow["id"] for flow in flows["items"] if flow["key"] == key)


def _login(client, email: str) -> dict[str, str]:  # noqa: ANN001
    response = client.post("/api/v1/auth/login", json={"email": email, "password": "Demo!2024"})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


class TestSchedules:
    def test_daily_schedule_runs_next_at_the_set_time(self) -> None:
        schedule = normalise_schedule({"enabled": True, "frequency": "daily", "time": "02:00"})
        after = datetime(2026, 9, 17, 3, 30, tzinfo=UTC)

        assert next_run_after(schedule, after) == datetime(2026, 9, 18, 2, 0, tzinfo=UTC)
        assert describe_schedule(schedule) == "Daily at 02:00 UTC"

    def test_weekly_schedule_lands_on_the_chosen_weekday(self) -> None:
        schedule = normalise_schedule({"enabled": True, "frequency": "weekly", "time": "07:00", "weekday": 0})
        after = datetime(2026, 9, 17, 12, 0, tzinfo=UTC)  # a Thursday

        following = next_run_after(schedule, after)
        assert following.weekday() == 0 and following > after
        assert describe_schedule(schedule) == "Every Monday at 07:00 UTC"

    def test_a_disabled_schedule_has_no_next_run(self) -> None:
        assert next_run_after(normalise_schedule({}), datetime.now(UTC)) is None

    @pytest.mark.parametrize("raw", [{"frequency": "monthly"}, {"time": "25:00"}, {"time": "noon"}, {"weekday": 9}])
    def test_invalid_schedules_are_rejected(self, raw: dict) -> None:
        with pytest.raises(ValidationError):
            normalise_schedule({"enabled": True, **raw})


class TestSeededFlows:
    def test_every_seeded_flow_supplies_the_inputs_its_agents_require(self) -> None:
        """A flow started from Flow Studio runs with its default inputs, so they must be complete."""
        from app.agents.registry import AGENT_CLASS_BY_KEY  # noqa: PLC0415
        from app.seed.flows import FLOW_DEFINITIONS  # noqa: PLC0415

        missing = []
        for definition in FLOW_DEFINITIONS:
            variables = definition.get("variables", {})
            for node in definition["nodes"]:
                agent_class = AGENT_CLASS_BY_KEY.get(node.get("agent_key") or "")
                if agent_class is None:
                    continue
                mapping = node.get("input_mapping", {})
                for name in (agent_class.input_schema or {}).get("required") or []:
                    source = str(mapping.get(name, f"${name}")).lstrip("$")
                    if source not in variables:
                        missing.append(f"{definition['key']}.{node['node_key']} needs '{name}'")
        assert not missing, missing


class TestComposer:
    def test_a_description_becomes_a_valid_governed_flow(self, db, project) -> None:  # noqa: ANN001
        composition = FlowComposer(db).compose(
            "Check PAY-201 is ready for testing; if it scores below 75 get business sign-off; "
            "then generate scenarios, test cases and test data for Payments",
            project,
        )

        agent_keys = composition.agent_keys
        assert agent_keys == [
            "user-story-completeness",
            "test-scenario-generator",
            "test-design",
            "test-data-generator",
        ]
        validation = FlowGraph.from_payload(composition.nodes, composition.edges).validate()
        assert validation["valid"], validation

        branch = next(step for step in composition.steps if step.branch == "false")
        assert branch.node_type == "approval"
        review = next(node for node in composition.nodes if node["node_key"] == branch.node_key)
        assert review["approval_role"] == "business_user"
        assert composition.variables["requirement_key"] == "PAY-201"
        assert composition.variables["module"] == "Payments"
        assert composition.variables["completeness_threshold"] == 75

    def test_an_approval_asked_for_after_a_step_guards_that_step(self, db, project) -> None:  # noqa: ANN001
        composition = FlowComposer(db).compose(
            "Analyse the failures, find the root cause and raise defects after QE lead approval", project
        )
        order = [step.agent_key or step.node_type for step in composition.steps]

        assert order.index("approval") == order.index("jira-defect-assistant") - 1

    def test_how_often_the_flow_runs_becomes_a_suggested_schedule(self, db, project) -> None:  # noqa: ANN001
        composition = FlowComposer(db).compose("Every night pick the regression tests that matter", project)

        assert composition.schedule == {"enabled": True, "weekday": 0, "frequency": "daily", "time": "02:00"}

    def test_an_unrelated_description_explains_what_to_write(self, db, project) -> None:  # noqa: ANN001
        composition = FlowComposer(db).compose("hello there", project)

        assert composition.agent_keys == []
        assert composition.warnings


class TestFlowStudioApi:
    def test_template_gallery_describes_outcomes_steps_and_cost(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        response = client.get("/api/v1/flows/templates", params={"project_id": project_id}, headers=auth_headers)

        assert response.status_code == 200, response.text
        templates = {item["key"]: item for item in response.json()}
        assert {"requirement-to-automated-test", "story-readiness-gate"} <= set(templates)
        gate = templates["story-readiness-gate"]
        assert gate["outcome"] and gate["agent_count"] == 2 and gate["approval_gates"] == 1
        assert gate["estimated_cost_per_run_usd"] >= 0

    def test_compose_then_create_gives_an_owned_audited_flow(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        draft = client.post(
            "/api/v1/flows/compose",
            json={"project_id": project_id, "description": "Generate scenarios and test cases for PAY-201"},
            headers=auth_headers,
        )
        assert draft.status_code == 200, draft.text
        body = draft.json()
        assert body["validation"]["valid"] and body["agent_count"] == 2

        created = client.post(
            "/api/v1/flows",
            json={
                "project_id": project_id,
                "name": f"{body['name']} {uuid.uuid4().hex[:6]}",
                "description": body["description"],
                "nodes": body["nodes"],
                "edges": body["edges"],
                "variables": body["variables"],
                "schedule": {"enabled": True, "frequency": "daily", "time": "06:30"},
                "source": "composer",
            },
            headers=auth_headers,
        )
        assert created.status_code == 201, created.text
        flow = created.json()
        assert flow["owner"] == "alex.morgan@example.com"
        assert flow["schedule_description"] == "Daily at 06:30 UTC" and flow["next_run_at"]
        assert flow["validation_result"]["valid"]

        audit = client.get(f"/api/v1/flows/{flow['id']}/governance", headers=auth_headers).json()["audit"]
        assert any(entry["action"] == "flow.create" for entry in audit)

    def test_from_template_creates_an_editable_draft_with_its_own_settings(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        response = client.post(
            "/api/v1/flows/from-template",
            json={
                "project_id": project_id,
                "template_key": "story-readiness-gate",
                "name": f"Readiness gate {uuid.uuid4().hex[:6]}",
                "owner": "priya.raman@example.com",
                "governance": {"run_roles": ["qe_lead"], "budget_alert_percent": 60, "notify_on_failure": True},
            },
            headers=auth_headers,
        )

        assert response.status_code == 201, response.text
        flow = response.json()
        assert flow["status"] == "draft" and flow["owner"] == "priya.raman@example.com"
        assert flow["governance"]["run_roles"] == ["qe_lead"]
        assert flow["governance"]["budget_alert_percent"] == 60
        assert len([node for node in flow["nodes"] if node["node_type"] == "agent"]) == 2

    def test_run_roles_limit_who_can_start_a_flow(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow = client.post(
            "/api/v1/flows/from-template",
            json={
                "project_id": project_id,
                "template_key": "accessibility-compliance",
                "name": f"Leads only {uuid.uuid4().hex[:6]}",
                "governance": {"run_roles": ["qe_lead"]},
            },
            headers=auth_headers,
        ).json()

        engineer = _login(client, "tom.becker@example.com")
        response = client.post(f"/api/v1/flows/{flow['id']}/run", json={"inputs": {}}, headers=engineer)
        assert response.status_code == 403, response.text

    def test_settings_update_is_audited(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow = client.post(
            "/api/v1/flows/from-template",
            json={"project_id": project_id, "template_key": "uat-preparation", "name": f"UAT {uuid.uuid4().hex[:6]}"},
            headers=auth_headers,
        ).json()

        response = client.patch(
            f"/api/v1/flows/{flow['id']}/settings",
            json={
                "cost_budget_usd": 2.5,
                "schedule": {"enabled": True, "frequency": "weekly", "time": "08:00", "weekday": 4},
                "governance": {"run_roles": [], "budget_alert_percent": 70, "notify_on_failure": False},
            },
            headers=auth_headers,
        )
        assert response.status_code == 200, response.text
        updated = response.json()
        assert updated["cost_budget_usd"] == 2.5
        assert updated["schedule_description"] == "Every Friday at 08:00 UTC"
        assert updated["governance"]["notify_on_failure"] is False

        governance = client.get(f"/api/v1/flows/{flow['id']}/governance", headers=auth_headers).json()
        assert any(entry["action"] == "flow.settings.update" for entry in governance["audit"])
        failure_alerts = next(check for check in governance["posture"]["checks"] if check["key"] == "failure_alerts")
        assert failure_alerts["status"] == "warn"

    def test_seeded_flows_have_their_own_dashboard(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow_id = _seeded_flow_id(client, auth_headers, project_id, "failure-to-rca-defect")
        response = client.get(f"/api/v1/flows/{flow_id}/dashboard", headers=auth_headers)

        assert response.status_code == 200, response.text
        dashboard = response.json()
        assert dashboard["kpis"]["runs"] > 10
        assert 0 < dashboard["kpis"]["success_rate"] <= 1
        assert len(dashboard["daily"]) == 30
        assert sum(day["runs"] for day in dashboard["daily"]) == dashboard["kpis"]["runs"]
        assert {row["label"] for row in dashboard["step_health"]} >= {"Automation Failure Analysis"}
        assert dashboard["recent_runs"] and dashboard["flow"]["api_trigger_enabled"] is True

    def test_observability_separates_agent_time_from_human_wait(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow_id = _seeded_flow_id(client, auth_headers, project_id, "failure-to-rca-defect")
        body = client.get(f"/api/v1/flows/{flow_id}/observability", params={"window_days": 30}, headers=auth_headers).json()

        assert body["time_split"]["agent_ms"] > 0 and body["time_split"]["human_wait_ms"] > 0
        assert body["models"] and body["llm_totals"]["calls"] > 0
        assert body["slo"]["status"] in {"healthy", "at_risk"}
        assert body["events"]

    def test_report_is_available_as_json_and_markdown(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow_id = _seeded_flow_id(client, auth_headers, project_id, "requirement-to-automated-test")

        report = client.get(f"/api/v1/flows/{flow_id}/report", headers=auth_headers)
        assert report.status_code == 200, report.text
        assert report.json()["highlights"] and report.json()["recommendations"]

        markdown = client.get(f"/api/v1/flows/{flow_id}/report", params={"format": "markdown"}, headers=auth_headers)
        assert markdown.status_code == 200
        assert "attachment" in markdown.headers["content-disposition"]
        assert markdown.text.startswith("# Requirement to Automated Test")

    def test_overview_lists_every_flow_with_activity(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        body = client.get("/api/v1/flows/overview", params={"project_id": project_id}, headers=auth_headers).json()

        assert body["totals"]["flows"] >= 6 and body["totals"]["scheduled"] >= 2
        seeded = next(item for item in body["flows"] if item["key"] == "regression-intelligence")
        assert len(seeded["activity"]) == 14 and seeded["schedule_description"] == "Daily at 02:00 UTC"


class TestApiTrigger:
    def test_a_flow_starts_with_its_own_token_and_nothing_else(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow_id = _seeded_flow_id(client, auth_headers, project_id, "accessibility-compliance")
        issued = client.post(f"/api/v1/flows/{flow_id}/api-token", headers=auth_headers)
        assert issued.status_code == 200, issued.text
        token = issued.json()["token"]
        assert token.startswith("qef_") and issued.json()["endpoint"].endswith(f"/api/v1/hooks/flows/{flow_id}")

        assert client.post(f"/api/v1/hooks/flows/{flow_id}", headers={"X-Flow-Token": "qef_wrong"}).status_code == 401
        assert client.post(f"/api/v1/hooks/flows/{uuid.uuid4()}", headers={"X-Flow-Token": token}).status_code == 401

        started = client.post(
            f"/api/v1/hooks/flows/{flow_id}",
            json={"inputs": {"module": "Payments"}},
            headers={"X-Flow-Token": token},
        )
        assert started.status_code == 202, started.text
        run = client.get(started.json()["status_url"], headers=auth_headers).json()
        assert run["trigger"] == "api"

    def test_a_rotated_token_replaces_the_old_one(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow_id = _seeded_flow_id(client, auth_headers, project_id, "release-readiness")
        first = client.post(f"/api/v1/flows/{flow_id}/api-token", headers=auth_headers).json()["token"]
        client.post(f"/api/v1/flows/{flow_id}/api-token", headers=auth_headers)

        assert client.post(f"/api/v1/hooks/flows/{flow_id}", headers={"X-Flow-Token": first}).status_code == 401
        assert client.delete(f"/api/v1/flows/{flow_id}/api-token", headers=auth_headers).status_code == 200
        assert client.get(f"/api/v1/flows/{flow_id}", headers=auth_headers).json()["api_trigger_enabled"] is False


class TestScheduler:
    def test_a_due_published_flow_is_started_and_its_next_slot_moves_on(self, db, project) -> None:  # noqa: ANN001
        flow = db.execute(select(AgentFlow).where(AgentFlow.key == "release-readiness")).scalar_one()
        now = datetime.now(UTC)
        apply_schedule(flow, {"enabled": True, "frequency": "hourly", "time": "00:05"}, now=now - timedelta(hours=2))
        flow.next_run_at = now - timedelta(minutes=1)
        db.commit()

        started = run_due_flows(db, now)

        assert len(started) == 1
        run = db.get(AgentRun, started[0])
        assert run.trigger == "schedule" and run.flow_id == flow.id
        db.refresh(flow)
        assert flow.next_run_at.replace(tzinfo=UTC) > now

        # Leave the demo schedule as it was.
        apply_schedule(flow, {"enabled": True, "frequency": "weekly", "time": "07:00", "weekday": 0})
        db.commit()

    def test_a_draft_flow_is_not_run_on_schedule_and_the_refusal_is_audited(self, db, project) -> None:  # noqa: ANN001
        flow = create_from_template(
            db, project, "story-readiness-gate", name=f"Draft {uuid.uuid4().hex[:6]}", created_by="tester@example.com"
        )
        now = datetime.now(UTC)
        apply_schedule(flow, {"enabled": True, "frequency": "daily", "time": "01:00"})
        flow.next_run_at = now - timedelta(minutes=1)
        db.commit()

        assert run_due_flows(db, now) == []
        refusal = db.execute(
            select(AuditLog).where(
                AuditLog.entity_id == flow.id, AuditLog.action == "flow.trigger", AuditLog.outcome == "failure"
            )
        ).scalars().first()
        assert refusal is not None

        apply_schedule(flow, {})
        db.commit()
