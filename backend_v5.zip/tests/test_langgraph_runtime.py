"""Running flows on LangGraph.

`test_orchestration.py` and `test_collaboration.py` run on both engines, so the
behaviour they cover -- approval gates, resume, budgets, branch routing -- is held
to the original engine's answers. Nothing there exercises parallel branches or
joins, and that is exactly where a graph runtime differs from a worklist loop, so
this file covers it, along with what LangGraph itself introduces.

Most tests here run the *same flow* on both engines and compare, because the
native engine is the specification.
"""

from __future__ import annotations

import uuid
from collections import Counter
from datetime import datetime
from app.core.time import UTC
from typing import Any

import pytest
from pydantic import ValidationError
from sqlalchemy import select

from app.core.config import Settings, settings
from app.core.worker import CancellationToken
from app.models.flow import AgentFlow, AgentFlowEdge, AgentFlowNode
from app.models.governance import ApprovalRequest
from app.models.project import Project
from app.models.run import AgentMessage, AgentRun, AgentRunStep
from app.orchestration import langgraph_runtime
from app.orchestration.engine import FlowEngine
from app.orchestration.factory import build_engine
from app.orchestration.graph import FlowGraph
from app.orchestration.langgraph_runtime import (
    LangGraphFlowEngine,
    _changed,
    _merge_variables,
    graph_node_names,
)
from app.services.run_service import RunService

ENGINES = ["native", "langgraph"]


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


@pytest.fixture(params=ENGINES)
def engine(request) -> str:  # noqa: ANN001
    return request.param


# ---------------------------------------------------------------------------
# Building and running flows
# ---------------------------------------------------------------------------


def _flow(
    db,  # noqa: ANN001
    project: Project,
    nodes: list[tuple[str, str]],
    edges: list[tuple[str, str] | tuple[str, str, str]],
    *,
    node_extra: dict[str, dict[str, Any]] | None = None,
    edge_conditions: dict[tuple[str, str], str] | None = None,
) -> AgentFlow:
    """A flow from `(key, type)` nodes and `(source, target[, branch])` edges."""
    node_extra = node_extra or {}
    edge_conditions = edge_conditions or {}
    flow = AgentFlow(
        project_id=project.id,
        key=f"lg-{uuid.uuid4().hex[:10]}",
        name="LangGraph test flow",
        status="published",
        variables={},
    )
    db.add(flow)
    db.flush()
    db.add_all(
        AgentFlowNode(
            flow_id=flow.id,
            node_key=key,
            node_type=node_type,
            label=key,
            sequence=index,
            **node_extra.get(key, {}),
        )
        for index, (key, node_type) in enumerate(nodes)
    )
    for edge in edges:
        source, target, *branch = edge
        db.add(
            AgentFlowEdge(
                flow_id=flow.id,
                source_node_key=source,
                target_node_key=target,
                branch_label=branch[0] if branch else None,
                condition_expression=edge_conditions.get((source, target)),
            )
        )
    db.flush()
    db.refresh(flow)
    return flow


def _start(db, flow: AgentFlow) -> AgentRun:  # noqa: ANN001
    return RunService(db).start_flow_run(
        flow_id=flow.id, project_id=flow.project_id, triggered_by="tester@example.com"
    )


def _run(db, flow: AgentFlow, kind: str, **kwargs: Any) -> AgentRun:  # noqa: ANN001
    return build_engine(db, kind=kind, **kwargs).execute_run(_start(db, flow).id)


def _steps(db, run: AgentRun) -> list[AgentRunStep]:  # noqa: ANN001
    return list(
        db.execute(
            select(AgentRunStep).where(AgentRunStep.run_id == run.id).order_by(AgentRunStep.sequence)
        ).scalars()
    )


def _events(db, run: AgentRun, event_type: str) -> list[AgentMessage]:  # noqa: ANN001
    return list(
        db.execute(
            select(AgentMessage).where(AgentMessage.run_id == run.id, AgentMessage.event_type == event_type)
        ).scalars()
    )


def _outcome(db, run: AgentRun) -> tuple[str, list[tuple[str, str]]]:  # noqa: ANN001
    """What happened, order-insensitively: the run's status and each step's result."""
    return run.status, sorted((step.node_key, step.status) for step in _steps(db, run))


DIAMOND_NODES = [
    ("start", "start"),
    ("fan", "parallel"),
    ("left", "parallel"),
    ("right", "parallel"),
    ("meet", "join"),
    ("end", "end"),
]
DIAMOND_EDGES = [
    ("start", "fan"),
    ("fan", "left"),
    ("fan", "right"),
    ("left", "meet"),
    ("right", "meet"),
    ("meet", "end"),
]


# ---------------------------------------------------------------------------
# It really is LangGraph
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(("kind", "expected"), [("native", "native"), ("langgraph", "langgraph")])
def test_the_run_records_which_engine_executed_it(db, project, kind: str, expected: str) -> None:  # noqa: ANN001
    """A run on the wrong runtime would be indistinguishable in its results, so
    the engine is written to the run's own event log."""
    run = _run(db, _flow(db, project, [("start", "start"), ("end", "end")], [("start", "end")]), kind)

    (started,) = _events(db, run, "flow_started")
    assert started.payload["engine"] == expected


def test_the_default_runtime_is_langgraph() -> None:
    assert settings.orchestration_engine == "langgraph"


def test_a_stored_flow_compiles_to_a_langgraph_state_graph(db, project) -> None:  # noqa: ANN001
    """The structure is inspectable -- nodes, edges, the conditional routing --
    which is what a reader who wants to see LangGraph in use will look for."""
    flow = _flow(
        db,
        project,
        [("start", "start"), ("gate", "condition"), ("big", "parallel"), ("small", "parallel"), ("end", "end")],
        [("start", "gate"), ("gate", "big", "true"), ("gate", "small", "false"), ("big", "end"), ("small", "end")],
        node_extra={"gate": {"condition_expression": "1 == 1"}},
    )
    engine = LangGraphFlowEngine(db)
    walk = engine.new_walk(_start(db, flow), flow, FlowGraph.from_flow(flow), None, None)

    drawable = engine.compile(walk).get_graph()

    assert {"__start__", "start", "gate", "big", "small", "end"} <= set(drawable.nodes)
    edges = {(edge.source, edge.target): edge.conditional for edge in drawable.edges}
    assert ("__start__", "start") in edges
    assert edges[("gate", "big")] is True and edges[("gate", "small")] is True


def test_the_native_engine_does_not_need_langgraph(db, project) -> None:  # noqa: ANN001
    """The fallback must work on its own, so a deployment can drop the dependency."""
    assert type(build_engine(db, kind="native")) is FlowEngine
    assert isinstance(build_engine(db, kind="langgraph"), LangGraphFlowEngine)


# ---------------------------------------------------------------------------
# Parallel branches and joins -- what no other test covers
# ---------------------------------------------------------------------------


def test_parallel_branches_each_run_once_and_the_join_waits_for_both(db, project, engine: str) -> None:  # noqa: ANN001
    run = _run(db, _flow(db, project, DIAMOND_NODES, DIAMOND_EDGES), engine)

    keys = [step.node_key for step in _steps(db, run)]
    assert run.status == "succeeded"
    assert Counter(keys) == {"fan": 1, "left": 1, "right": 1, "meet": 1}
    assert keys[0] == "fan" and keys[-1] == "meet", "the join must run after both branches"


def test_a_node_reached_by_two_paths_runs_once(db, project, engine: str) -> None:  # noqa: ANN001
    """A diamond into an ordinary node: LangGraph can reach it twice where the
    worklist loop could not, so it must dedupe on its own."""
    flow = _flow(
        db,
        project,
        [("start", "start"), ("a", "parallel"), ("b", "parallel"), ("shared", "parallel"), ("end", "end")],
        [("start", "a"), ("start", "b"), ("a", "shared"), ("b", "shared"), ("shared", "end")],
    )
    run = _run(db, flow, engine)

    assert Counter(step.node_key for step in _steps(db, run))["shared"] == 1


def test_a_node_reached_at_different_depths_runs_once(db, project, engine: str) -> None:  # noqa: ANN001
    """The case the diamond above cannot reach. There both paths arrive in the
    same LangGraph step and LangGraph collapses them itself. Here `shared` is
    reached after one step from `a` and after two from `b -> x`, in *different*
    steps, so LangGraph would schedule it twice: only the node's own visited
    check stops the second run."""
    flow = _flow(
        db,
        project,
        [("start", "start"), ("a", "parallel"), ("b", "parallel"), ("x", "parallel"), ("shared", "parallel"), ("end", "end")],
        [("start", "a"), ("start", "b"), ("b", "x"), ("a", "shared"), ("x", "shared"), ("shared", "end")],
    )
    run = _run(db, flow, engine)

    assert Counter(step.node_key for step in _steps(db, run)) == {"a": 1, "b": 1, "x": 1, "shared": 1}


def test_a_join_that_only_one_branch_reaches_does_not_run(db, project, engine: str) -> None:  # noqa: ANN001
    """The join waits for every upstream path. When a condition means one of them
    is never taken, it never runs -- on either engine."""
    flow = _flow(
        db,
        project,
        [("start", "start"), ("gate", "condition"), ("a", "parallel"), ("b", "parallel"), ("meet", "join"), ("end", "end")],
        [("start", "gate"), ("gate", "a", "true"), ("gate", "b", "false"), ("a", "meet"), ("b", "meet"), ("meet", "end")],
        node_extra={"gate": {"condition_expression": "1 == 1"}},
    )
    run = _run(db, flow, engine)

    keys = [step.node_key for step in _steps(db, run)]
    assert keys == ["gate", "a"]


def test_both_engines_agree_on_a_branching_flow_with_a_join(db, project) -> None:  # noqa: ANN001
    """The generic parity check: same flow, two runtimes, same outcome."""
    outcomes = {}
    for kind in ENGINES:
        flow = _flow(db, project, DIAMOND_NODES, DIAMOND_EDGES)
        outcomes[kind] = _outcome(db, _run(db, flow, kind))

    assert outcomes["native"] == outcomes["langgraph"]


def test_parallel_branches_run_in_key_order_not_edge_order(db, project) -> None:  # noqa: ANN001
    """The documented difference, pinned so nobody 'fixes' it unawares.

    LangGraph runs the branches of one superstep in a deterministic order -- by
    node key -- where the native loop followed edge order. Either is a valid
    order for independent branches; this one is stable across databases.
    """
    flow = _flow(
        db,
        project,
        [("start", "start"), ("fan", "parallel"), ("zed", "parallel"), ("alpha", "parallel"), ("end", "end")],
        [("start", "fan"), ("fan", "zed"), ("fan", "alpha"), ("zed", "end"), ("alpha", "end")],
    )
    run = _run(db, flow, "langgraph")

    assert [step.node_key for step in _steps(db, run)] == ["fan", "alpha", "zed"]


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(("expression", "taken", "skipped"), [("1 == 1", "yes", "no"), ("1 == 2", "no", "yes")])
def test_a_condition_routes_to_exactly_one_branch(
    db, project, engine: str, expression: str, taken: str, skipped: str  # noqa: ANN001
) -> None:
    flow = _flow(
        db,
        project,
        [("start", "start"), ("gate", "condition"), ("yes", "parallel"), ("no", "parallel"), ("end", "end")],
        [("start", "gate"), ("gate", "yes", "true"), ("gate", "no", "false"), ("yes", "end"), ("no", "end")],
        node_extra={"gate": {"condition_expression": expression}},
    )
    keys = {step.node_key for step in _steps(db, _run(db, flow, engine))}

    assert taken in keys and skipped not in keys


def test_an_edge_condition_filters_its_target(db, project, engine: str) -> None:  # noqa: ANN001
    flow = _flow(
        db,
        project,
        [("start", "start"), ("blocked", "parallel"), ("open", "parallel"), ("end", "end")],
        [("start", "blocked"), ("start", "open"), ("blocked", "end"), ("open", "end")],
        edge_conditions={("start", "blocked"): "1 == 2"},
    )
    run = _run(db, flow, engine)

    assert [step.node_key for step in _steps(db, run)] == ["open"]
    assert _events(db, run, "edge_skipped"), "the skipped path should be recorded"


# ---------------------------------------------------------------------------
# Stopping
# ---------------------------------------------------------------------------


def _approval_flow(db, project) -> AgentFlow:  # noqa: ANN001
    """start -> fan -> (approve -> after, zsibling) -> end."""
    return _flow(
        db,
        project,
        [
            ("start", "start"),
            ("fan", "parallel"),
            ("approve", "approval"),
            ("zsibling", "parallel"),
            ("after", "parallel"),
            ("end", "end"),
        ],
        [
            ("start", "fan"),
            ("fan", "approve"),
            ("fan", "zsibling"),
            ("approve", "after"),
            ("after", "end"),
            ("zsibling", "end"),
        ],
    )


def test_an_approval_gate_pauses_the_run_and_halts_the_branches_beside_it(db, project, engine: str) -> None:  # noqa: ANN001
    """`approve` sorts before `zsibling`, so it runs first; once the flow is
    waiting on a person, nothing else in that step may go ahead."""
    run = _run(db, _approval_flow(db, project), engine)

    assert run.status == "awaiting_approval"
    executed = {step.node_key: step.status for step in _steps(db, run)}
    assert executed == {"fan": "succeeded", "approve": "awaiting_approval"}


def test_a_flow_resumes_after_an_approval_node_and_runs_the_rest_once(db, project, engine: str) -> None:  # noqa: ANN001
    flow = _approval_flow(db, project)
    run = _run(db, flow, engine)

    approval = db.execute(
        select(ApprovalRequest).where(ApprovalRequest.run_id == run.id, ApprovalRequest.status == "pending")
    ).scalar_one()
    approval.status = "approved"
    approval.decided_by = "priya.raman@example.com"
    approval.decided_at = datetime.now(UTC)
    run.status = "queued"
    db.flush()

    run = build_engine(db, kind=engine).execute_run(run.id)

    counts = Counter(step.node_key for step in _steps(db, run))
    assert run.status == "succeeded"
    assert counts == {"fan": 1, "approve": 1, "after": 1, "zsibling": 1}, "a resumed run must not repeat finished steps"


def test_a_cancelled_run_stops_before_running_anything(db, project, engine: str) -> None:  # noqa: ANN001
    token = CancellationToken()
    token.cancel()
    run = _run(db, _flow(db, project, DIAMOND_NODES, DIAMOND_EDGES), engine, cancellation=token)

    assert run.status == "cancelled"
    assert _steps(db, run) == []


def test_the_step_limit_stops_a_runaway_flow(db, project, monkeypatch: pytest.MonkeyPatch) -> None:  # noqa: ANN001
    """LangGraph raises when it hits its recursion limit; the run must still end
    in a terminal state, with the reason recorded, rather than crash."""
    monkeypatch.setattr(langgraph_runtime, "MAX_STEPS", 3)
    chain = [("start", "start")] + [(f"n{i}", "parallel") for i in range(8)] + [("end", "end")]
    edges = [(a[0], b[0]) for a, b in zip(chain, chain[1:], strict=False)]
    run = _run(db, _flow(db, project, chain, edges), "langgraph")

    assert _events(db, run, "flow_guard"), "the guard should be recorded"
    assert run.status in {"succeeded", "partially_succeeded", "failed"}
    assert len(_steps(db, run)) < 8, "the limit should have stopped the chain early"


# ---------------------------------------------------------------------------
# What LangGraph introduces
# ---------------------------------------------------------------------------


def test_parallel_updates_merge_instead_of_overwriting() -> None:
    """Two branches change different variables in one superstep; both survive."""
    assert _merge_variables({"x": 1}, {"y": 2}) == {"x": 1, "y": 2}
    assert _merge_variables(None, {"y": 2}) == {"y": 2}


def test_a_node_reports_only_what_it_changed() -> None:
    """The stale-copy hazard: if a sibling returned its whole dictionary, its old
    value for `x` would overwrite the fresh one this node wrote."""
    before = {"x": 1, "kept": "same"}
    after = {"x": 5, "kept": "same", "new": True}

    assert _changed(before, after) == {"x": 5, "new": True}
    assert _merge_variables(_merge_variables(before, _changed(before, after)), _changed(before, before)) == {
        "x": 5,
        "kept": "same",
        "new": True,
    }


def test_node_names_are_made_safe_and_stay_unique() -> None:
    """LangGraph rejects ':' and '|' in a node name and flow keys are free text.
    Two keys that sanitise to the same name must not collide."""
    graph = FlowGraph.from_payload(
        [{"node_key": key, "node_type": "agent"} for key in ["a:b", "a_b", "x|y", "plain", "__end__"]], []
    )
    names = graph_node_names(graph)

    assert len(set(names.values())) == len(names)
    assert not any(":" in name or "|" in name for name in names.values())
    assert "__end__" not in names.values(), "must not collide with LangGraph's reserved END"


def test_a_flow_with_awkward_node_keys_still_runs(db, project) -> None:  # noqa: ANN001
    flow = _flow(
        db,
        project,
        [("start", "start"), ("step:one", "parallel"), ("step|two", "parallel"), ("end", "end")],
        [("start", "step:one"), ("step:one", "step|two"), ("step|two", "end")],
    )
    run = _run(db, flow, "langgraph")

    assert run.status == "succeeded"
    assert [step.node_key for step in _steps(db, run)] == ["step:one", "step|two"]


# ---------------------------------------------------------------------------
# Choosing the runtime
# ---------------------------------------------------------------------------


def test_the_factory_follows_the_setting(db, monkeypatch: pytest.MonkeyPatch) -> None:  # noqa: ANN001
    monkeypatch.setattr(settings, "orchestration_engine", "native")
    assert type(build_engine(db)) is FlowEngine
    monkeypatch.setattr(settings, "orchestration_engine", "langgraph")
    assert isinstance(build_engine(db), LangGraphFlowEngine)


def test_an_unknown_engine_is_refused(db) -> None:  # noqa: ANN001
    with pytest.raises(ValueError, match="Unknown orchestration engine"):
        build_engine(db, kind="crewai")


def test_a_misspelt_engine_setting_fails_at_startup() -> None:
    """Not a silent fall-back to one runtime while the operator thinks it is the other."""
    with pytest.raises(ValidationError):
        Settings(_env_file=None, orchestration_engine="langraph")


def test_health_reports_the_runtime(client) -> None:  # noqa: ANN001
    assert client.get("/health").json()["orchestration"] == "langgraph"
