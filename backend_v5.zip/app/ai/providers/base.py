"""LLM provider contract.

No agent ever imports a vendor SDK. Agents ask the model router for a
capability; the router resolves a provider and calls this interface. Swapping
Mock -> Azure OpenAI -> OpenAI is therefore configuration, not code
(spec sections 3 and 21).
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Literal

Capability = Literal["classification", "structured_extraction", "generation", "reasoning", "embedding"]

CAPABILITIES: tuple[str, ...] = (
    "classification",
    "structured_extraction",
    "generation",
    "reasoning",
    "embedding",
)


@dataclass(slots=True)
class ChatMessage:
    role: Literal["system", "user", "assistant", "tool"]
    content: str
    name: str | None = None
    # Set on a "tool" message: which tool_call this is the result of.
    tool_call_id: str | None = None
    # Set on an "assistant" message that requested tools instead of answering.
    tool_calls: list[dict[str, Any]] | None = None

    def to_api(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.name:
            payload["name"] = self.name
        if self.tool_call_id:
            payload["tool_call_id"] = self.tool_call_id
        if self.tool_calls:
            payload["tool_calls"] = self.tool_calls
        return payload


@dataclass(slots=True)
class ModelSelection:
    """A fully resolved model target produced by the router."""

    provider: str
    model: str
    deployment: str | None
    capability: str
    temperature: float = 0.1
    max_tokens: int = 2500
    input_cost_per_1k: float = 0.0
    output_cost_per_1k: float = 0.0
    tier: str = "standard"

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "model": self.model,
            "deployment": self.deployment,
            "capability": self.capability,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "tier": self.tier,
        }


@dataclass(slots=True)
class TokenUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


@dataclass(slots=True)
class LLMResponse:
    """Uniform response shape across every provider."""

    content: str
    selection: ModelSelection
    usage: TokenUsage
    latency_ms: int
    finish_reason: str = "stop"
    structured: dict[str, Any] | None = None
    raw: dict[str, Any] = field(default_factory=dict)
    cache_hit: bool = False
    # Tool calls the model requested instead of (or alongside) answering.
    # Each entry: {"id": str, "name": str, "arguments": dict}.
    tool_calls: list[dict[str, Any]] = field(default_factory=list)

    @property
    def cost_usd(self) -> float:
        return round(
            (self.usage.prompt_tokens / 1000.0) * self.selection.input_cost_per_1k
            + (self.usage.completion_tokens / 1000.0) * self.selection.output_cost_per_1k,
            6,
        )


@dataclass(slots=True)
class EmbeddingResponse:
    vectors: list[list[float]]
    model: str
    provider: str
    deployment: str | None
    usage: TokenUsage
    latency_ms: int

    @property
    def dimensions(self) -> int:
        return len(self.vectors[0]) if self.vectors else 0


class LLMProvider(abc.ABC):
    """Base class implemented by MockLLMProvider, AzureOpenAIProvider, OpenAIProvider."""

    key: str = "base"
    display_name: str = "Base Provider"

    @abc.abstractmethod
    def chat(
        self,
        messages: list[ChatMessage],
        selection: ModelSelection,
        *,
        response_schema: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        timeout: int | None = None,
        deterministic_draft: dict[str, Any] | None = None,
    ) -> LLMResponse:
        """Single chat completion. `response_schema` requests structured JSON output.

        `deterministic_draft` is the agent's own state-derived answer. The demo
        provider returns it verbatim; real providers ignore it and let the model
        answer. It is never mixed into the prompt, so the two paths produce the
        same contract from genuinely different sources.
        """

    @abc.abstractmethod
    def embed(self, texts: list[str], selection: ModelSelection) -> EmbeddingResponse:
        """Embed a batch of texts."""

    @abc.abstractmethod
    def health_check(self) -> dict[str, Any]:
        """Report connectivity without ever returning secret values."""

    def is_configured(self) -> bool:
        return True
