"""Capability-based model router (spec sections 3, 17 and 21).

    Agent requests capability
            -> policy / budget check
            -> provider resolution
            -> model / deployment resolution
            -> LLM invocation
            -> usage / cost / latency recording

Configuration hierarchy, most specific wins:

    workflow node -> agent -> project -> global platform -> environment defaults
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.ai.cost.tracker import CostTracker, UsageContext, estimate_cost
from app.ai.providers.base import ChatMessage, EmbeddingResponse, LLMResponse, ModelSelection
from app.ai.providers.mock import estimate_tokens
from app.ai.providers.registry import find_model, full_catalog, get_provider
from app.core.config import settings
from app.core.errors import ProviderError
from app.core.logging import get_logger
from app.core.security import mask_pii
from app.models.llm import LLMRoutingPolicy

logger = get_logger(__name__)

# Capability -> preferred model tier when no explicit policy row matches.
_CAPABILITY_TIER_DEFAULTS: dict[str, str] = {
    "classification": "light",
    "structured_extraction": "standard",
    "generation": "standard",
    "reasoning": "premium",
    "embedding": "light",
}

_COMPLEXITY_TIER_UPGRADE: dict[str, str] = {"simple": "light", "standard": "standard", "complex": "premium"}


@dataclass(slots=True)
class RoutingRequest:
    """What an agent asks for -- a capability, never a hard-coded model."""

    capability: str
    complexity: str = "standard"
    temperature: float | None = None
    max_tokens: int | None = None
    # Configuration overrides, ordered most-specific first at resolution time.
    node_config: dict[str, Any] = field(default_factory=dict)
    agent_config: dict[str, Any] = field(default_factory=dict)
    project_config: dict[str, Any] = field(default_factory=dict)
    requires_approval: bool = False


@dataclass(slots=True)
class RoutingDecision:
    selection: ModelSelection
    fallback: ModelSelection | None
    source: str  # which tier of the hierarchy decided this
    policy_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            **self.selection.to_dict(),
            "resolved_from": self.source,
            "fallback": self.fallback.to_dict() if self.fallback else None,
            "policy_id": self.policy_id,
        }


class ModelRouter:
    """Resolves capabilities to concrete models and executes the invocation."""

    def __init__(self, session: Session) -> None:
        self.session = session
        self.cost_tracker = CostTracker(session)

    def pii_masking_required(self, project_id: str | None) -> bool:
        """Whether an enabled PII-masking policy covers this project."""
        from app.models.governance import GovernancePolicy  # noqa: PLC0415

        return (
            self.session.execute(
                select(GovernancePolicy.id).where(
                    GovernancePolicy.policy_type == "pii_masking",
                    GovernancePolicy.is_enabled.is_(True),
                    or_(GovernancePolicy.project_id == project_id, GovernancePolicy.project_id.is_(None)),
                )
            ).first()
            is not None
        )

    # ----- resolution --------------------------------------------------------
    def resolve(self, request: RoutingRequest, project_id: str | None = None) -> RoutingDecision:
        for source, config in (
            ("workflow_node", request.node_config),
            ("agent", request.agent_config),
            ("project", request.project_config),
        ):
            explicit = self._selection_from_config(config, request)
            if explicit is not None:
                return RoutingDecision(selection=explicit, fallback=self._fallback_for(request), source=source)

        policy = self._matching_policy(request, project_id)
        if policy is not None:
            selection = self._build_selection(
                provider_key=policy.provider_key,
                model_key=policy.model_key,
                capability=request.capability,
                temperature=request.temperature if request.temperature is not None else policy.temperature,
                max_tokens=request.max_tokens or policy.max_tokens,
            )
            fallback = None
            if policy.fallback_provider_key and policy.fallback_model_key:
                fallback = self._build_selection(
                    provider_key=policy.fallback_provider_key,
                    model_key=policy.fallback_model_key,
                    capability=request.capability,
                    temperature=request.temperature if request.temperature is not None else policy.temperature,
                    max_tokens=request.max_tokens or policy.max_tokens,
                )
            return RoutingDecision(
                selection=selection, fallback=fallback, source="routing_policy", policy_id=policy.id
            )

        return RoutingDecision(
            selection=self._default_selection(request),
            fallback=self._fallback_for(request),
            source="platform_default",
        )

    def _selection_from_config(self, config: dict[str, Any], request: RoutingRequest) -> ModelSelection | None:
        if not config:
            return None
        provider_key = config.get("provider")
        model_key = config.get("model")
        if not provider_key or not model_key:
            return None
        return self._build_selection(
            provider_key=provider_key,
            model_key=model_key,
            capability=request.capability,
            temperature=(
                request.temperature
                if request.temperature is not None
                else config.get("temperature", 0.1)
            ),
            max_tokens=request.max_tokens or config.get("max_tokens", 2500),
            deployment=config.get("deployment"),
        )

    def _matching_policy(self, request: RoutingRequest, project_id: str | None) -> LLMRoutingPolicy | None:
        """Project-scoped policies outrank global ones; then explicit complexity."""
        query = (
            select(LLMRoutingPolicy)
            .where(
                LLMRoutingPolicy.capability == request.capability,
                LLMRoutingPolicy.is_active.is_(True),
                LLMRoutingPolicy.complexity.in_([request.complexity, "any"]),
            )
            .order_by(LLMRoutingPolicy.priority.asc())
        )
        policies = list(self.session.execute(query).scalars().all())
        if not policies:
            return None
        scoped = [policy for policy in policies if project_id and policy.project_id == project_id]
        pool = scoped or [policy for policy in policies if policy.project_id is None]
        if not pool:
            return None
        exact = [policy for policy in pool if policy.complexity == request.complexity]
        return (exact or pool)[0]

    def _default_selection(self, request: RoutingRequest) -> ModelSelection:
        provider_key = settings.default_llm_provider
        tier = _COMPLEXITY_TIER_UPGRADE.get(
            request.complexity, _CAPABILITY_TIER_DEFAULTS.get(request.capability, "standard")
        )
        if request.capability == "embedding":
            tier = "light"
        candidates = [
            entry
            for entry in full_catalog()
            if entry["provider"] == provider_key and request.capability in entry["capabilities"]
        ]
        if not candidates:
            candidates = [
                entry for entry in full_catalog() if request.capability in entry["capabilities"]
            ]
        if not candidates:
            raise ProviderError(
                f"No model in the catalogue supports capability '{request.capability}'.",
                details={"capability": request.capability},
            )
        preferred = [entry for entry in candidates if entry["tier"] == tier] or candidates
        entry = preferred[0]
        return self._build_selection(
            provider_key=entry["provider"],
            model_key=entry["model_key"],
            capability=request.capability,
            temperature=request.temperature if request.temperature is not None else 0.1,
            max_tokens=request.max_tokens or 2500,
        )

    def _fallback_for(self, request: RoutingRequest) -> ModelSelection | None:
        """Mock is always a viable fallback so a run degrades rather than dies."""
        if settings.default_llm_provider == "mock":
            return None
        entry = next(
            (
                item
                for item in full_catalog()
                if item["provider"] == "mock" and request.capability in item["capabilities"]
            ),
            None,
        )
        if entry is None:
            return None
        return self._build_selection(
            provider_key="mock",
            model_key=entry["model_key"],
            capability=request.capability,
            temperature=request.temperature if request.temperature is not None else 0.1,
            max_tokens=request.max_tokens or 2500,
        )

    def _build_selection(
        self,
        *,
        provider_key: str,
        model_key: str,
        capability: str,
        temperature: float,
        max_tokens: int,
        deployment: str | None = None,
    ) -> ModelSelection:
        entry = find_model(provider_key, model_key) or {}
        return ModelSelection(
            provider=provider_key,
            model=model_key,
            # OpenAI has no deployments; Azure keeps model and deployment distinct.
            deployment=deployment or entry.get("deployment"),
            capability=capability,
            temperature=temperature,
            max_tokens=min(max_tokens, entry.get("max_output_tokens") or max_tokens),
            input_cost_per_1k=entry.get("input_cost_per_1k", 0.0),
            output_cost_per_1k=entry.get("output_cost_per_1k", 0.0),
            tier=entry.get("tier", "standard"),
        )

    # ----- invocation --------------------------------------------------------
    def complete(
        self,
        messages: list[ChatMessage],
        request: RoutingRequest,
        context: UsageContext,
        *,
        response_schema: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        deterministic_draft: dict[str, Any] | None = None,
        timeout: int | None = None,
        project_budget_usd: float | None = None,
        flow_budget_usd: float | None = None,
        agent_budget_usd: float | None = None,
    ) -> tuple[LLMResponse, RoutingDecision]:
        """Route, budget-check, invoke (with fallback) and record usage."""
        decision = self.resolve(request, project_id=context.project_id)

        if self.pii_masking_required(context.project_id):
            # The policy says personal data is masked before any provider sees
            # it. For a long time it was only a record: matched on every run,
            # shown on every run page as evaluated, and enforced nowhere. Every
            # chat call passes through here, so this is where it holds.
            messages = [
                ChatMessage(
                    role=message.role,
                    content=mask_pii(message.content),
                    name=message.name,
                    tool_call_id=message.tool_call_id,
                    tool_calls=message.tool_calls,
                )
                for message in messages
            ]

        projected_prompt_tokens = sum(estimate_tokens(message.content) for message in messages)
        projected_cost = estimate_cost(
            decision.selection, projected_prompt_tokens, decision.selection.max_tokens // 2
        )
        self.cost_tracker.check_budgets(
            context,
            project_budget_usd=project_budget_usd,
            flow_budget_usd=flow_budget_usd,
            agent_budget_usd=agent_budget_usd,
            projected_cost_usd=projected_cost,
        )

        attempts: list[tuple[ModelSelection, bool]] = [(decision.selection, False)]
        if decision.fallback is not None:
            attempts.append((decision.fallback, True))

        last_error: Exception | None = None
        for selection, is_fallback in attempts:
            provider = get_provider(selection.provider)
            started = time.perf_counter()
            try:
                response = provider.chat(
                    messages,
                    selection,
                    response_schema=response_schema,
                    tools=tools,
                    timeout=timeout,
                    deterministic_draft=deterministic_draft,
                )
            except Exception as exc:  # noqa: BLE001 - fall back rather than fail the run
                last_error = exc
                logger.warning(
                    "llm_attempt_failed",
                    provider=selection.provider,
                    model=selection.model,
                    fallback_available=decision.fallback is not None and not is_fallback,
                    error=str(exc)[:200],
                )
                continue

            self.cost_tracker.record(response, context, fallback_used=is_fallback)
            if is_fallback:
                decision = RoutingDecision(
                    selection=selection, fallback=None, source=f"{decision.source}+fallback"
                )
            logger.info(
                "llm_call",
                provider=selection.provider,
                model=selection.model,
                capability=request.capability,
                tokens=response.usage.total_tokens,
                cost=response.cost_usd,
                latency_ms=response.latency_ms,
                elapsed_ms=int((time.perf_counter() - started) * 1000),
            )
            return response, decision

        raise ProviderError(
            f"All model attempts failed for capability '{request.capability}': {last_error}",
            details={"capability": request.capability, "attempts": len(attempts)},
        )

    def embed(
        self,
        texts: list[str],
        context: UsageContext,
        *,
        project_config: dict[str, Any] | None = None,
    ) -> EmbeddingResponse:
        """Embed text through the configured embedding model and record usage."""
        request = RoutingRequest(capability="embedding", project_config=project_config or {})
        decision = self.resolve(request, project_id=context.project_id)
        provider = get_provider(decision.selection.provider)
        response = provider.embed(texts, decision.selection)

        synthetic = LLMResponse(
            content="",
            selection=decision.selection,
            usage=response.usage,
            latency_ms=response.latency_ms,
        )
        self.cost_tracker.record(synthetic, context, operation="embedding")
        return response
