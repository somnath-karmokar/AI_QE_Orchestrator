"""Adapter that lets a real LangGraph ReAct agent drive `ModelRouter`.

`create_react_agent` (langgraph.prebuilt) expects a LangChain `BaseChatModel`. This
wraps `ModelRouter.complete()` so every turn LangGraph triggers -- deciding whether to
call a tool, reading a tool's result, producing the final answer -- still goes through
this platform's own routing, budget checks, PII masking and cost recording. LangGraph
only controls *when* those calls happen and *what* gets fed back into the next one; it
never bypasses the governance that already lives inside `ModelRouter`.
"""

from __future__ import annotations

import json
from typing import Any

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.utils.function_calling import convert_to_openai_tool
from pydantic import ConfigDict, Field

from app.ai.cost.tracker import UsageContext
from app.ai.providers.base import ChatMessage, LLMResponse
from app.ai.router.model_router import ModelRouter, RoutingDecision, RoutingRequest


def to_langchain_messages(messages: list[ChatMessage]) -> list[BaseMessage]:
    """This platform's `ChatMessage` list -> the LangChain message list a graph needs."""
    converted: list[BaseMessage] = []
    for message in messages:
        if message.role == "system":
            converted.append(SystemMessage(content=message.content))
        elif message.role == "user":
            converted.append(HumanMessage(content=message.content))
        elif message.role == "assistant":
            tool_calls = [
                {"name": call["name"], "args": call.get("arguments", {}), "id": call["id"], "type": "tool_call"}
                for call in (message.tool_calls or [])
            ]
            converted.append(AIMessage(content=message.content, tool_calls=tool_calls))
        elif message.role == "tool":
            converted.append(ToolMessage(content=message.content, tool_call_id=message.tool_call_id or ""))
    return converted


def _from_langchain_messages(messages: list[BaseMessage]) -> list[ChatMessage]:
    """The reverse of `to_langchain_messages`, for the messages LangGraph hands back."""
    converted: list[ChatMessage] = []
    for message in messages:
        if isinstance(message, SystemMessage):
            converted.append(ChatMessage(role="system", content=str(message.content)))
        elif isinstance(message, HumanMessage):
            converted.append(ChatMessage(role="user", content=str(message.content)))
        elif isinstance(message, AIMessage):
            tool_calls = [
                {"id": call["id"], "name": call["name"], "arguments": call.get("args", {})}
                for call in (message.tool_calls or [])
            ]
            converted.append(
                ChatMessage(role="assistant", content=str(message.content or ""), tool_calls=tool_calls or None)
            )
        elif isinstance(message, ToolMessage):
            converted.append(
                ChatMessage(role="tool", content=str(message.content), tool_call_id=message.tool_call_id)
            )
    return converted


class QEChatModel(BaseChatModel):
    """A LangChain chat model whose every call is really `ModelRouter.complete()`."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    router: ModelRouter
    routing_request: RoutingRequest
    usage_context: UsageContext
    response_schema: dict[str, Any]
    deterministic_draft: dict[str, Any] | None
    budgets: dict[str, Any]
    timeout: int = 120
    # Populated as calls happen; the agent reads this afterward to sum cost/tokens
    # and take the last routing decision, since one agent run may make several calls.
    call_log: list[tuple[LLMResponse, RoutingDecision]] = Field(default_factory=list)

    @property
    def _llm_type(self) -> str:
        return "qe-model-router"

    def bind_tools(self, tools: list[Any], **kwargs: Any) -> Any:
        formatted = [convert_to_openai_tool(tool) for tool in tools]
        return self.bind(tools=formatted, **kwargs)

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        chat_messages = _from_langchain_messages(messages)
        tools = kwargs.get("tools")

        # Ground every call in the agent's real, state-derived draft -- except the
        # very first decision point of a tool-bearing agent, where the model (or the
        # deterministic mock standing in for it) must be free to choose to
        # investigate first. Every later call, once a tool result exists, is grounded
        # again. A zero-tool agent is always grounded: it only ever makes one call.
        already_used_a_tool = any(message.role == "tool" for message in chat_messages)
        draft = self.deterministic_draft if (not tools or already_used_a_tool) else None

        response, decision = self.router.complete(
            chat_messages,
            self.routing_request,
            self.usage_context,
            response_schema=self.response_schema,
            tools=tools,
            deterministic_draft=draft,
            timeout=self.timeout,
            **self.budgets,
        )
        self.call_log.append((response, decision))

        content = response.content
        if response.structured is not None and not content:
            content = json.dumps(response.structured, default=str)

        ai_message = AIMessage(
            content=content or "",
            tool_calls=[
                {"name": call["name"], "args": call.get("arguments", {}), "id": call["id"], "type": "tool_call"}
                for call in response.tool_calls
            ],
        )
        return ChatResult(generations=[ChatGeneration(message=ai_message)])
