"""Copilot service: plan a turn, execute it, and compose a spoken-friendly reply.

Execution goes through the same `RunService` and orchestration engine the Flow
Builder uses, so a conversational request is subject to identical governance,
budgets, approval gates and audit. The chat surface is a front door, not a
bypass.
"""

from __future__ import annotations

import time
from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.copilot import flow_answers
from app.copilot.flow_resolver import latest_run
from app.copilot.intent import INTENTS, extract_entities
from app.copilot.planner import FLOW_INTENTS, Plan, CopilotPlanner
from app.core.errors import NotFoundError, PolicyViolationError
from app.core.logging import get_logger
from app.governance.policy_engine import AuditService
from app.knowledge.service import KnowledgeService
from app.models.agent import Agent
from app.models.conversation import Conversation, ConversationMessage
from app.models.flow import AgentFlow
from app.models.project import Project
from app.models.run import AgentRun
from app.services.analytics_service import AnalyticsService
from app.services.run_service import RunService
from app.vectorstore.base import COLLECTION_KNOWLEDGE

logger = get_logger(__name__)

MAX_HISTORY_TURNS = 8


class CopilotService:
    def __init__(self, session: Session) -> None:
        self.session = session
        self.planner = CopilotPlanner(session)
        self.knowledge = KnowledgeService(session)
        self.runs = RunService(session)
        self.audit = AuditService(session)

    # ------------------------------------------------------------------
    # Conversations
    # ------------------------------------------------------------------
    def get_or_create_conversation(
        self, *, conversation_id: str | None, project_id: str, user_id: str | None,
        environment_id: str | None = None,
    ) -> Conversation:
        if conversation_id:
            conversation = self.session.get(Conversation, conversation_id)
            if conversation is None or conversation.is_deleted:
                raise NotFoundError(f"Conversation '{conversation_id}' was not found.")
            return conversation

        conversation = Conversation(
            project_id=project_id,
            user_id=user_id,
            environment_id=environment_id,
            title="New conversation",
        )
        self.session.add(conversation)
        self.session.flush()
        return conversation

    def _history(self, conversation: Conversation) -> list[dict[str, str]]:
        messages = sorted(conversation.messages, key=lambda item: item.sequence)[-MAX_HISTORY_TURNS * 2 :]
        return [{"role": message.role, "content": message.content} for message in messages]

    def _next_sequence(self, conversation: Conversation) -> int:
        current = self.session.execute(
            select(func.coalesce(func.max(ConversationMessage.sequence), 0)).where(
                ConversationMessage.conversation_id == conversation.id
            )
        ).scalar_one()
        return int(current) + 1

    # ------------------------------------------------------------------
    # Main turn
    # ------------------------------------------------------------------
    def handle_message(
        self,
        *,
        conversation: Conversation,
        message: str,
        project: Project,
        actor: str,
        is_voice: bool = False,
        auto_execute: bool = True,
    ) -> ConversationMessage:
        started = time.perf_counter()

        user_turn = ConversationMessage(
            conversation_id=conversation.id,
            sequence=self._next_sequence(conversation),
            role="user",
            content=message.strip(),
            is_voice=is_voice,
        )
        self.session.add(user_turn)
        self.session.flush()

        if conversation.title == "New conversation":
            conversation.title = message.strip()[:80]

        entities = extract_entities(self.session, message, project, conversation.context or {})
        plan = self.planner.plan(
            message, project=project, entities=entities, history=self._history(conversation)
        )

        try:
            reply = self._execute(plan, conversation=conversation, project=project,
                                  actor=actor, auto_execute=auto_execute)
        except PolicyViolationError as exc:
            reply = _Reply(
                content=(
                    f"I stopped before running that. {exc.message} "
                    "You can review and approve it in Governance."
                ),
                navigation={"route": "/governance?tab=approvals", "label": "Approvals"},
                policy_decision=exc.details.get("policy", {"effect": "deny", "reasons": [exc.message]}),
            )
            plan.kind = "refused"
        except Exception as exc:  # noqa: BLE001 - a failed turn must still answer
            logger.exception("copilot_turn_failed", error=str(exc))
            reply = _Reply(content=f"Something went wrong while handling that: {str(exc)[:200]}")
            plan.kind = "refused"

        assistant_turn = ConversationMessage(
            conversation_id=conversation.id,
            sequence=self._next_sequence(conversation),
            role="assistant",
            content=reply.content,
            plan_kind=plan.kind,
            intent=plan.intent,
            intent_confidence=plan.intent_confidence,
            considered_agents=[candidate.to_dict() for candidate in plan.considered],
            selected_agents=[candidate.to_dict() for candidate in plan.selected],
            extracted_entities=plan.entities.to_dict(),
            reasoning_summary=plan.reasoning,
            run_id=reply.run_id,
            evidence=reply.evidence,
            artifacts=reply.artifacts,
            suggestions=reply.suggestions or self._suggestions(plan, project),
            navigation=reply.navigation or plan.navigation,
            provider=reply.provider,
            model=reply.model,
            total_tokens=reply.tokens,
            cost_usd=reply.cost_usd,
            duration_ms=int((time.perf_counter() - started) * 1000),
            policy_decision=reply.policy_decision,
            is_voice=is_voice,
        )
        self.session.add(assistant_turn)

        # Carry resolved entities so follow-up turns keep their referent.
        conversation.context = {**(conversation.context or {}), **plan.entities.to_dict()}
        conversation.message_count += 2
        conversation.total_tokens += reply.tokens
        conversation.total_cost_usd = round(conversation.total_cost_usd + reply.cost_usd, 6)
        conversation.last_message_at = datetime.now(UTC)
        self.session.flush()

        self.audit.record(
            action="copilot.turn",
            entity_type="conversation",
            entity_id=conversation.id,
            entity_label=conversation.title,
            actor=actor,
            actor_type="user",
            project_id=project.id,
            reason=plan.summary,
            outcome="success" if plan.kind != "refused" else "blocked",
            input_summary={"message": message[:400], "voice": is_voice},
            output_summary={
                "plan": plan.kind,
                "intent": plan.intent,
                "agents": [candidate.agent_key for candidate in plan.selected],
            },
            confidence=plan.intent_confidence,
            policy_result=reply.policy_decision,
            run_id=reply.run_id,
        )
        return assistant_turn

    # ------------------------------------------------------------------
    # Plan execution
    # ------------------------------------------------------------------
    def _execute(
        self, plan: Plan, *, conversation: Conversation, project: Project, actor: str, auto_execute: bool
    ) -> _Reply:
        if plan.kind == "navigate":
            return _Reply(
                content=f"{plan.summary} You will find it under {plan.navigation.get('label')}.",
                navigation=plan.navigation,
            )

        if plan.kind == "clarify":
            lines = [plan.summary]
            if plan.entities.unresolved:
                lines.append(
                    f"I could not find {', '.join(plan.entities.unresolved)} in this project."
                )
            if plan.clarify_options:
                lines.append("Try one of these:")
                lines.extend(f"• {option}" for option in plan.clarify_options)
            return _Reply(content="\n".join(lines), suggestions=plan.clarify_options)

        if plan.kind == "answer":
            return self._answer(plan, project=project)

        if not auto_execute:
            names = ", ".join(candidate.name for candidate in plan.selected)
            return _Reply(
                content=f"I would run {names} for this. Confirm and I will start it.",
                suggestions=["Yes, run it", "Show me what it would do first"],
            )

        if plan.kind == "run_flow":
            return self._run_flow(plan, conversation=conversation, project=project, actor=actor)

        if plan.kind == "run_agent":
            return self._run_agent(plan, conversation=conversation, project=project, actor=actor)

        return _Reply(content="I could not determine how to help with that.")

    # ------------------------------------------------------------------
    def _answer(self, plan: Plan, *, project: Project) -> _Reply:
        """Answer from indexed knowledge plus live platform state."""
        if plan.intent in FLOW_INTENTS:
            return self._flow_answer(plan, project=project)

        if plan.intent == "quality_status":
            data = AnalyticsService(self.session).dashboard(project.id, window_days=30)
            kpis = data["kpis"]
            content = (
                f"{data['summary']}\n\n"
                f"Pass rate {kpis['test_pass_rate']:.1%}, automation coverage "
                f"{kpis['automation_coverage']:.1%}, requirement coverage "
                f"{kpis['requirement_coverage']:.1%}. "
                f"Flaky rate is {kpis['flaky_test_rate']:.2%} and AI spend over the window is "
                f"€{kpis['ai_cost_usd']:.2f}."
            )
            return _Reply(
                content=content,
                navigation={"route": "/", "label": "Quality Overview"},
                evidence=[{"type": "metrics", "detail": "Computed from executions, defects and usage records."}],
            )

        if plan.intent == "coverage_report":
            coverage = AnalyticsService(self.session).coverage(project.id)
            totals = coverage["totals"]
            uncovered = totals["requirements"] - totals["covered_requirements"]
            content = (
                f"Requirement coverage is {coverage['requirement_coverage']:.0%} "
                f"({totals['covered_requirements']} of {totals['requirements']}), automation coverage "
                f"{coverage['automation_coverage']:.0%}. "
                + (
                    f"{uncovered} requirement(s) have no test coverage yet."
                    if uncovered
                    else "Every requirement has at least one test case."
                )
            )
            return _Reply(
                content=content,
                navigation={"route": "/quality/traceability", "label": "Traceability Matrix"},
                evidence=[{"type": "coverage", "detail": "Derived from the requirement-to-defect chain."}],
            )

        # Knowledge question: search the user's actual words. Using a carried
        # entity here would answer a question they did not ask.
        query = plan.message.strip() or str(plan.agent_inputs.get("query") or plan.summary)
        block, evidence = self.knowledge.retrieve_context_block(
            query,
            project_id=project.id,
            collection=COLLECTION_KNOWLEDGE,
            limit=4,
        )
        if not block.strip():
            return _Reply(
                content=(
                    "I could not find anything in the project's indexed knowledge that answers that. "
                    "Try rephrasing, or check that the relevant source has been synced."
                ),
                navigation={"route": "/knowledge", "label": "Knowledge Fabric"},
            )

        # Lead with the strongest passage; the UI shows the full citation list.
        top = block.split("\n\n")[0]
        excerpt = top.split("\n", 1)[-1].strip()
        content = (
            f"{excerpt[:900]}\n\n"
            f"Source: {evidence[0]['title'] if evidence else 'project knowledge'}"
            + (f" ({len(evidence)} sources consulted)" if len(evidence) > 1 else "")
        )
        return _Reply(
            content=content,
            evidence=evidence,
            navigation={"route": "/knowledge", "label": "Knowledge Fabric"},
        )

    # ------------------------------------------------------------------
    def _flow_answer(self, plan: Plan, *, project: Project) -> _Reply:
        """Questions about the flows themselves: what they do, how they are doing, what a run did."""
        flow = self.session.get(AgentFlow, plan.entities.flow_id) if plan.entities.flow_id else None

        if plan.intent == "flow_inventory" or flow is None:
            answer = flow_answers.flow_inventory(self.session, project, plan.message)
        elif plan.intent == "flow_run_review":
            run = self.session.get(AgentRun, plan.entities.run_id) if plan.entities.run_id else None
            run = run or latest_run(self.session, flow)
            if run is None:
                answer = flow_answers.FlowAnswer(
                    content=f"{flow.name} has not run yet, so there is no run to review.",
                    navigation={"route": f"/flows/{flow.id}", "label": f"{flow.name} workspace"},
                    suggestions=[f"What does {flow.name} do?", f"Run {flow.name}"],
                )
            else:
                answer = flow_answers.review_run(self.session, run)
        elif plan.intent == "flow_governance":
            answer = flow_answers.flow_governance(self.session, flow)
        elif plan.intent == "flow_explain":
            answer = flow_answers.explain_flow(self.session, flow)
        else:
            answer = flow_answers.flow_health(self.session, flow)

        return _Reply(
            content=answer.content,
            evidence=answer.evidence,
            navigation=answer.navigation,
            suggestions=answer.suggestions,
        )

    def _run_agent(
        self, plan: Plan, *, conversation: Conversation, project: Project, actor: str
    ) -> _Reply:
        candidate = plan.selected[0]
        agent = self.session.get(Agent, candidate.agent_id)
        if agent is None:
            return _Reply(content="That agent is no longer available.")

        run = self.runs.start_agent_run(
            agent_id=agent.id,
            project_id=project.id,
            inputs=plan.agent_inputs,
            environment_id=conversation.environment_id,
            triggered_by=actor,
            kind="agent",
        )
        run = self.runs.run_synchronously(run)
        self.session.refresh(run)
        return self._reply_from_run(run, plan, headline=f"{agent.name} finished.")

    def _run_flow(
        self, plan: Plan, *, conversation: Conversation, project: Project, actor: str
    ) -> _Reply:
        flow = self.session.execute(
            select(AgentFlow).where(
                AgentFlow.project_id == project.id, AgentFlow.key == plan.flow_key
            )
        ).scalar_one_or_none()
        if flow is None:
            return _Reply(content="That workflow is not available in this project.")

        run = self.runs.start_flow_run(
            flow_id=flow.id,
            project_id=project.id,
            inputs=plan.agent_inputs,
            environment_id=conversation.environment_id,
            triggered_by=actor,
        )
        run = self.runs.run_synchronously(run)
        self.session.refresh(run)
        return self._reply_from_run(run, plan, headline=f"The '{flow.name}' flow ran.")

    def _reply_from_run(self, run: AgentRun, plan: Plan, *, headline: str) -> _Reply:
        """Compose a reply that reads well aloud as well as on screen."""
        steps = sorted(run.steps, key=lambda step: step.sequence)
        succeeded = [step for step in steps if step.status == "succeeded"]
        artifacts: list[dict[str, Any]] = []
        evidence: list[dict[str, Any]] = []
        for step in succeeded:
            artifacts.extend(step.artifacts or [])
            evidence.extend(step.evidence or [])

        if run.status == "awaiting_approval":
            pending = next((step for step in steps if step.status == "awaiting_approval"), None)
            content = (
                f"{headline.rstrip('.')} — and then paused. "
                f"'{pending.label if pending else 'A step'}' needs human approval before it can continue, "
                "because governance policy requires it for this action. "
                "Approve it in Governance and the run resumes from where it stopped."
            )
            return _Reply(
                content=content,
                run_id=run.id,
                artifacts=artifacts,
                evidence=evidence,
                navigation={"route": "/governance?tab=approvals", "label": "Approvals"},
                tokens=run.total_tokens,
                cost_usd=run.total_cost_usd,
                policy_decision=(pending.policy_decision if pending else {}),
                suggestions=["Why does this need approval?", "Show me the run"],
            )

        if run.status in {"failed", "cancelled"}:
            return _Reply(
                content=f"The run did not complete: {run.error or run.summary or 'no detail recorded'}.",
                run_id=run.id,
                navigation={"route": f"/runs/{run.id}", "label": "Run detail"},
                tokens=run.total_tokens,
                cost_usd=run.total_cost_usd,
            )

        # Lead with what each agent actually concluded.
        findings = [
            (step.output or {}).get("summary")
            for step in succeeded
            if (step.output or {}).get("summary")
        ]
        lines = [headline]
        lines.extend(f"• {summary}" for summary in findings[:4])
        if artifacts:
            kinds: dict[str, int] = {}
            for artifact in artifacts:
                kind = str(artifact.get("type", "artifact")).replace("_", " ")
                kinds[kind] = kinds.get(kind, 0) + 1
            produced = ", ".join(f"{count} {kind}" for kind, count in kinds.items())
            lines.append(f"Produced: {produced}.")

        return _Reply(
            content="\n".join(lines),
            run_id=run.id,
            artifacts=artifacts[:20],
            evidence=evidence[:10],
            navigation={"route": f"/runs/{run.id}", "label": "Run detail"},
            tokens=run.total_tokens,
            cost_usd=run.total_cost_usd,
            provider=succeeded[0].provider if succeeded else None,
            model=succeeded[0].model if succeeded else None,
        )

    # ------------------------------------------------------------------
    @staticmethod
    def _suggestions(plan: Plan, project: Project) -> list[str]:
        """Next steps that follow naturally from what just happened."""
        module = plan.entities.module or (project.modules or ["Payments"])[0]
        story = plan.entities.requirement_key

        by_intent: dict[str, list[str]] = {
            "assess_requirement": [
                f"Generate test scenarios for {story}" if story else "Generate test scenarios",
                "Which requirements are untested?",
            ],
            "generate_tests": [
                f"Automate these test cases for {module}",
                f"Generate test data for {module}",
            ],
            "generate_automation": [
                "Run the regression suite",
                "What is our automation coverage?",
            ],
            "generate_test_data": [f"Automate the {module} test cases", "Is any test data stale?"],
            "run_execution": ["Why did those tests fail?", "Show me the execution"],
            "diagnose_failure": ["Raise a defect for this", "Show similar historical failures"],
            "predict_risk": ["Optimise the regression suite", "Which requirements are untested?"],
            "optimize_regression": ["Run the optimised suite", "How much time does that save?"],
            "coverage_report": ["Generate tests for the uncovered requirements", "How is quality looking?"],
            "quality_status": ["Where is the risk in this release?", "What is our test coverage?"],
        }
        return by_intent.get(plan.intent, ["How is quality looking?", "Where is the risk in this release?"])[:3]


class _Reply:
    """Internal carrier for what a plan produced."""

    def __init__(
        self,
        content: str,
        *,
        run_id: str | None = None,
        evidence: list[dict[str, Any]] | None = None,
        artifacts: list[dict[str, Any]] | None = None,
        suggestions: list[str] | None = None,
        navigation: dict[str, Any] | None = None,
        tokens: int = 0,
        cost_usd: float = 0.0,
        provider: str | None = None,
        model: str | None = None,
        policy_decision: dict[str, Any] | None = None,
    ) -> None:
        self.content = content
        self.run_id = run_id
        self.evidence = evidence or []
        self.artifacts = artifacts or []
        self.suggestions = suggestions or []
        self.navigation = navigation or {}
        self.tokens = tokens
        self.cost_usd = cost_usd
        self.provider = provider
        self.model = model
        self.policy_decision = policy_decision or {}


def index_agent_catalog(session: Session, project: Project) -> int:
    """Embed each agent's capability description for conversational selection.

    Called during seeding and whenever an agent is published, so the copilot can
    discover new agents without a code change.
    """
    knowledge = KnowledgeService(session)
    agents = list(
        session.execute(
            select(Agent).where(
                Agent.is_deleted.is_(False),
                Agent.is_published.is_(True),
                (Agent.project_id.is_(None)) | (Agent.project_id == project.id),
            )
        )
        .scalars()
        .all()
    )
    if not agents:
        return 0

    items = []
    for agent in agents:
        # Include goal, instructions and example phrasings so the embedding
        # captures what the agent is *for*, not just its name.
        examples = " ".join(
            example
            for intent, spec in INTENTS.items()
            for example in spec["examples"]
            if agent.key in _agents_for_intent(intent)
        )
        content = " ".join(
            part
            for part in [
                agent.name,
                agent.category,
                agent.description or "",
                agent.goal or "",
                " ".join(agent.tags or []),
                examples,
            ]
            if part
        )
        items.append(
            {
                "id": f"{project.id}:{agent.key}",
                "content": content,
                "metadata": {
                    "source_type": "agent",
                    "source_id": agent.id,
                    "agent_key": agent.key,
                    "agent_id": agent.id,
                    "title": agent.name,
                    "module": agent.category,
                    "artifact_type": "agent_capability",
                    "risk_level": agent.risk_level,
                },
            }
        )

    from app.vectorstore.base import COLLECTION_AGENT_CATALOG  # noqa: PLC0415

    return knowledge.index_texts(
        project_id=project.id, collection=COLLECTION_AGENT_CATALOG, items=items
    )


def _agents_for_intent(intent: str) -> list[str]:
    from app.copilot.planner import INTENT_AGENTS  # noqa: PLC0415

    return INTENT_AGENTS.get(intent, [])
