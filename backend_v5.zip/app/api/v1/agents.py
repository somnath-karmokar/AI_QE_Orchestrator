"""Agent catalogue, marketplace, custom agent builder and agent cart."""

from __future__ import annotations

from datetime import datetime
from app.core.time import UTC
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, or_, select

from app.api.deps import DbSession, OptionalScopedProjectId, Pagination, ScopedProjectId, require_permission
from app.core.errors import ConflictError, NotFoundError, ValidationError
from app.core.security import Principal
from app.core.tenancy import assert_project_access
from app.models.agent import AGENT_CATEGORIES, Agent, AgentVersion
from app.models.flow import AgentCartItem, AgentFlow, AgentFlowEdge, AgentFlowNode, AgentFlowVersion
from app.models.project import Project
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import (
    AgentCreate,
    AgentDetail,
    AgentPublishRequest,
    AgentSummary,
    AgentTestRequest,
    AgentUpdate,
    AgentVersionOut,
    CartItemIn,
    CartItemOut,
    CartToFlowRequest,
    FlowDetail,
    RunDetail,
)
from app.services.api_access import agent_api_access
from app.services.run_service import RunService

router = APIRouter(tags=["Agents"])


def _visible_agents(project_id: str | None):  # noqa: ANN202
    """Global agents plus any belonging to the selected project."""
    statement = select(Agent).where(Agent.is_deleted.is_(False))
    if project_id:
        statement = statement.where(or_(Agent.project_id.is_(None), Agent.project_id == project_id))
    else:
        statement = statement.where(Agent.project_id.is_(None))
    return statement


# ---------------------------------------------------------------------------
# Marketplace
# ---------------------------------------------------------------------------


@router.get("/marketplace/agents", response_model=Page[AgentSummary], summary="Browse the agent marketplace")
def marketplace(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: OptionalScopedProjectId = None,
    search: Annotated[str | None, Query()] = None,
    category: Annotated[list[str] | None, Query()] = None,
    risk_level: Annotated[list[str] | None, Query()] = None,
    cost_tier: Annotated[list[str] | None, Query()] = None,
    tool: Annotated[str | None, Query()] = None,
    sort: Annotated[str, Query(pattern="^(popular|name|rating|cost|recent)$")] = "popular",
) -> Page[AgentSummary]:
    statement = _visible_agents(project_id).where(Agent.is_published.is_(True))

    if search:
        pattern = f"%{search}%"
        statement = statement.where(
            or_(Agent.name.ilike(pattern), Agent.description.ilike(pattern), Agent.key.ilike(pattern))
        )
    if category:
        statement = statement.where(Agent.category.in_(category))
    if risk_level:
        statement = statement.where(Agent.risk_level.in_(risk_level))
    if cost_tier:
        statement = statement.where(Agent.cost_tier.in_(cost_tier))

    order = {
        "popular": Agent.usage_count.desc(),
        "name": Agent.name.asc(),
        "rating": Agent.rating.desc(),
        "cost": Agent.avg_cost_usd.asc(),
        "recent": Agent.created_at.desc(),
    }[sort]

    rows = list(session.execute(statement.order_by(order)).scalars().all())
    # Tool filtering is applied in Python because supported_tools is a JSON column
    # whose containment operators differ between PostgreSQL and SQLite.
    if tool:
        rows = [row for row in rows if tool in (row.supported_tools or [])]

    total = len(rows)
    window = rows[pagination.offset : pagination.offset + pagination.limit]
    return Page(
        items=[AgentSummary.model_validate(row) for row in window],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/marketplace/facets", summary="Marketplace filter facets with counts")
def marketplace_facets(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: OptionalScopedProjectId = None,
) -> dict[str, Any]:
    rows = list(
        session.execute(_visible_agents(project_id).where(Agent.is_published.is_(True))).scalars().all()
    )

    def tally(attribute: str) -> dict[str, int]:
        counts: dict[str, int] = {}
        for row in rows:
            value = getattr(row, attribute)
            counts[value] = counts.get(value, 0) + 1
        return dict(sorted(counts.items()))

    tools: dict[str, int] = {}
    for row in rows:
        for entry in row.supported_tools or []:
            tools[entry] = tools.get(entry, 0) + 1

    return {
        "total": len(rows),
        "categories": [
            {"key": name, "count": tally("category").get(name, 0)} for name in AGENT_CATEGORIES
        ],
        "risk_levels": tally("risk_level"),
        "cost_tiers": tally("cost_tier"),
        "tools": dict(sorted(tools.items())),
    }


# ---------------------------------------------------------------------------
# Agent CRUD
# ---------------------------------------------------------------------------


@router.get("/agents", response_model=Page[AgentSummary], summary="List agents")
def list_agents(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: OptionalScopedProjectId = None,
    lifecycle_state: Annotated[str | None, Query()] = None,
    is_builtin: Annotated[bool | None, Query()] = None,
) -> Page[AgentSummary]:
    statement = _visible_agents(project_id)
    if lifecycle_state:
        statement = statement.where(Agent.lifecycle_state == lifecycle_state)
    if is_builtin is not None:
        statement = statement.where(Agent.is_builtin.is_(is_builtin))

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(Agent.category, Agent.name).limit(pagination.limit).offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[AgentSummary.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/agents/{agent_id}/api-access", summary="How a third party calls this agent")
def agent_api_access_route(
    agent_id: str,
    request: Request,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: ScopedProjectId,
) -> dict:
    """The endpoint, the contract and which API keys can already reach it."""
    agent = session.get(Agent, agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")
    # A built-in has no project and is shared; a project's own agent is its own.
    assert_project_access(session, principal, agent.project_id)
    return agent_api_access(session, agent, project_id=project_id, base_url=str(request.base_url))


@router.get("/agents/{agent_id}", response_model=AgentDetail, summary="Get agent details")
def get_agent(
    agent_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> AgentDetail:
    agent = session.get(Agent, agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")
    # A built-in has no project and is shared; a project's own agent is its own.
    assert_project_access(session, principal, agent.project_id)
    return AgentDetail.model_validate(agent)


@router.post("/agents", response_model=AgentDetail, status_code=201, summary="Create a custom agent")
def create_agent(
    payload: AgentCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:write"))],
) -> AgentDetail:
    assert_project_access(session, principal, payload.project_id)
    key = payload.name.lower().replace(" ", "-")[:70]
    existing = session.execute(
        select(Agent).where(Agent.key == key, Agent.project_id == payload.project_id)
    ).scalar_one_or_none()
    if existing is not None:
        raise ConflictError(f"An agent named '{payload.name}' already exists in this scope.")

    agent = Agent(
        **payload.model_dump(),
        key=key,
        # Custom agents start as drafts and run on ConfigurableAgent until published.
        is_builtin=False,
        is_published=False,
        lifecycle_state="draft",
        version="0.1.0",
        summary=(payload.description or payload.name)[:240],
        created_by=principal.email,
    )
    session.add(agent)
    session.flush()

    session.add(
        AgentVersion(
            agent_id=agent.id,
            version="0.1.0",
            lifecycle_state="draft",
            change_summary="Initial draft.",
            snapshot={"system_instructions": agent.system_instructions, "input_schema": agent.input_schema},
        )
    )
    session.flush()
    return AgentDetail.model_validate(agent)


@router.patch("/agents/{agent_id}", response_model=AgentDetail, summary="Update an agent")
def update_agent(
    agent_id: str,
    payload: AgentUpdate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:write"))],
) -> AgentDetail:
    agent = session.get(Agent, agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")
    # A built-in has no project and is shared; a project's own agent is its own.
    assert_project_access(session, principal, agent.project_id)
    if agent.is_builtin:
        raise ValidationError(
            "Built-in agents cannot be edited directly. Clone the agent to customise it.",
            details={"agent_id": agent_id, "hint": "POST /agents/{id}/clone"},
        )

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(agent, field, value)
    agent.updated_by = principal.email
    session.flush()
    return AgentDetail.model_validate(agent)


@router.post("/agents/{agent_id}/clone", response_model=AgentDetail, status_code=201, summary="Clone an agent")
def clone_agent(
    agent_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:write"))],
    project_id: OptionalScopedProjectId = None,
) -> AgentDetail:
    source = session.get(Agent, agent_id)
    if source is None or source.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")

    clone = Agent(
        key=f"{source.key}-copy",
        name=f"{source.name} (Copy)",
        description=source.description,
        summary=source.summary,
        category=source.category,
        icon=source.icon,
        project_id=project_id or source.project_id,
        goal=source.goal,
        system_instructions=source.system_instructions,
        # A clone keeps the original's behaviour by pointing at the same handler.
        handler_key=source.handler_key,
        capability=source.capability,
        input_schema=source.input_schema,
        output_schema=source.output_schema,
        default_config=source.default_config,
        llm_config=source.llm_config,
        temperature=source.temperature,
        max_tokens=source.max_tokens,
        token_budget=source.token_budget,
        cost_budget_usd=source.cost_budget_usd,
        retry_policy=source.retry_policy,
        timeout_seconds=source.timeout_seconds,
        guardrails=source.guardrails,
        supported_tools=source.supported_tools,
        mcp_servers=source.mcp_servers,
        tags=source.tags,
        risk_level=source.risk_level,
        cost_tier=source.cost_tier,
        requires_approval=source.requires_approval,
        is_builtin=False,
        is_published=False,
        lifecycle_state="draft",
        version="0.1.0",
        cloned_from_id=source.id,
        created_by=principal.email,
    )
    session.add(clone)
    session.flush()
    return AgentDetail.model_validate(clone)


@router.post("/agents/{agent_id}/test", response_model=RunDetail, summary="Test an agent against sample data")
def test_agent(
    agent_id: str,
    payload: AgentTestRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:write"))],
) -> RunDetail:
    """Run the agent once, synchronously, so the builder shows a real result."""
    agent = session.get(Agent, agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")
    # A built-in has no project and is shared; a project's own agent is its own.
    assert_project_access(session, principal, agent.project_id)
    if session.get(Project, payload.project_id) is None:
        raise NotFoundError(f"Project '{payload.project_id}' was not found.")
    # Where the run is *written* is a second decision from which agent runs: a
    # shared built-in must not be usable to drop a run into another tenant.
    assert_project_access(session, principal, payload.project_id)

    service = RunService(session)
    run = service.start_agent_run(
        agent_id=agent_id,
        project_id=payload.project_id,
        inputs=payload.inputs,
        environment_id=payload.environment_id,
        triggered_by=principal.email,
        kind="agent_test",
    )
    run = service.run_synchronously(run)
    session.refresh(run)

    if agent.lifecycle_state == "draft" and run.status == "succeeded":
        agent.lifecycle_state = "test"
    session.flush()
    return RunDetail.model_validate(run)


@router.post("/agents/{agent_id}/publish", response_model=AgentDetail, summary="Publish an agent version")
def publish_agent(
    agent_id: str,
    payload: AgentPublishRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:publish"))],
) -> AgentDetail:
    agent = session.get(Agent, agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")
    # A built-in has no project and is shared; a project's own agent is its own.
    assert_project_access(session, principal, agent.project_id)

    version = payload.version or _next_version(agent.version)
    if session.execute(
        select(AgentVersion).where(AgentVersion.agent_id == agent.id, AgentVersion.version == version)
    ).scalar_one_or_none():
        raise ConflictError(f"Version '{version}' already exists for this agent.")

    agent.version = version
    agent.lifecycle_state = "active"
    agent.is_published = True
    agent.updated_by = principal.email

    session.add(
        AgentVersion(
            agent_id=agent.id,
            version=version,
            lifecycle_state="published",
            change_summary=payload.change_summary or "Published from the agent builder.",
            snapshot={
                "system_instructions": agent.system_instructions,
                "input_schema": agent.input_schema,
                "output_schema": agent.output_schema,
                "capability": agent.capability,
                "supported_tools": agent.supported_tools,
            },
            published_at=datetime.now(UTC),
            published_by=principal.email,
        )
    )
    session.flush()
    return AgentDetail.model_validate(agent)


@router.get(
    "/agents/{agent_id}/versions",
    response_model=list[AgentVersionOut],
    summary="Agent version history",
)
def agent_versions(
    agent_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> list[AgentVersionOut]:
    rows = list(
        session.execute(
            select(AgentVersion)
            .where(AgentVersion.agent_id == agent_id)
            .order_by(AgentVersion.created_at.desc())
        )
        .scalars()
        .all()
    )
    return [AgentVersionOut.model_validate(row) for row in rows]


@router.delete("/agents/{agent_id}", response_model=MessageResponse, summary="Deprecate an agent")
def delete_agent(
    agent_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:write"))],
) -> MessageResponse:
    agent = session.get(Agent, agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{agent_id}' was not found.")
    # A built-in has no project and is shared; a project's own agent is its own.
    assert_project_access(session, principal, agent.project_id)
    if agent.is_builtin:
        raise ValidationError("Built-in agents cannot be removed; disable them with a governance policy.")

    agent.lifecycle_state = "deprecated"
    agent.is_published = False
    agent.soft_delete(principal.email)
    session.flush()
    return MessageResponse(message=f"Agent '{agent.name}' was deprecated.")


def _next_version(current: str) -> str:
    try:
        major, minor, patch = (int(part) for part in current.split("."))
    except ValueError:
        return "1.0.0"
    return f"{major}.{minor + 1}.0"


# ---------------------------------------------------------------------------
# Agent cart
# ---------------------------------------------------------------------------

cart_router = APIRouter(prefix="/agent-cart", tags=["Agent Cart"])


def _cart_item_out(session, item: AgentCartItem) -> CartItemOut:  # noqa: ANN001
    agent = session.get(Agent, item.agent_id)
    payload = CartItemOut.model_validate(item)
    payload.agent = AgentSummary.model_validate(agent) if agent else None
    return payload


@cart_router.get("", response_model=list[CartItemOut], summary="Get the current agent cart")
def get_cart(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: ScopedProjectId,
) -> list[CartItemOut]:
    rows = list(
        session.execute(
            select(AgentCartItem)
            .where(AgentCartItem.user_id == principal.user_id, AgentCartItem.project_id == project_id)
            .order_by(AgentCartItem.sequence)
        )
        .scalars()
        .all()
    )
    return [_cart_item_out(session, row) for row in rows]


@cart_router.post("", response_model=CartItemOut, status_code=201, summary="Add an agent to the cart")
def add_to_cart(
    payload: CartItemIn,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> CartItemOut:
    agent = session.get(Agent, payload.agent_id)
    if agent is None or agent.is_deleted:
        raise NotFoundError(f"Agent '{payload.agent_id}' was not found.")
    # The cart row echoes the agent back, so both ends need checking: whose
    # agent this is, and whose project it is being carted into.
    assert_project_access(session, principal, agent.project_id)
    assert_project_access(session, principal, payload.project_id)

    existing = session.execute(
        select(AgentCartItem).where(
            AgentCartItem.user_id == principal.user_id,
            AgentCartItem.project_id == payload.project_id,
            AgentCartItem.agent_id == payload.agent_id,
        )
    ).scalar_one_or_none()
    if existing is not None:
        raise ConflictError(f"'{agent.name}' is already in the cart.")

    next_sequence = payload.sequence
    if next_sequence is None:
        current = int(
            session.execute(
                select(func.coalesce(func.max(AgentCartItem.sequence), 0)).where(
                    AgentCartItem.user_id == principal.user_id,
                    AgentCartItem.project_id == payload.project_id,
                )
            ).scalar_one()
            or 0
        )
        next_sequence = current + 1

    item = AgentCartItem(
        user_id=principal.user_id,
        project_id=payload.project_id,
        agent_id=payload.agent_id,
        sequence=next_sequence,
        notes=payload.notes,
        config_overrides=payload.config_overrides,
    )
    session.add(item)
    session.flush()
    return _cart_item_out(session, item)


@cart_router.patch("/{item_id}", response_model=CartItemOut, summary="Reorder or reconfigure a cart item")
def update_cart_item(
    item_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    sequence: Annotated[int | None, Query()] = None,
    notes: Annotated[str | None, Query()] = None,
) -> CartItemOut:
    item = session.get(AgentCartItem, item_id)
    if item is None or item.user_id != principal.user_id:
        raise NotFoundError(f"Cart item '{item_id}' was not found.")
    if sequence is not None:
        item.sequence = sequence
    if notes is not None:
        item.notes = notes
    session.flush()
    return _cart_item_out(session, item)


@cart_router.delete("/{item_id}", response_model=MessageResponse, summary="Remove an agent from the cart")
def remove_from_cart(
    item_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> MessageResponse:
    item = session.get(AgentCartItem, item_id)
    if item is None or item.user_id != principal.user_id:
        raise NotFoundError(f"Cart item '{item_id}' was not found.")
    session.delete(item)
    session.flush()
    return MessageResponse(message="Agent removed from the cart.")


@cart_router.post("/build-flow", response_model=FlowDetail, status_code=201, summary="Turn the cart into a flow")
def build_flow_from_cart(
    payload: CartToFlowRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> FlowDetail:
    """Compose the selected agents into a runnable sequential flow."""
    assert_project_access(session, principal, payload.project_id)
    items = list(
        session.execute(
            select(AgentCartItem)
            .where(
                AgentCartItem.user_id == principal.user_id,
                AgentCartItem.project_id == payload.project_id,
            )
            .order_by(AgentCartItem.sequence)
        )
        .scalars()
        .all()
    )
    if not items:
        raise ValidationError("The agent cart is empty. Add agents before building a flow.")

    key = payload.name.lower().replace(" ", "-")[:70]
    if session.execute(
        select(AgentFlow).where(AgentFlow.project_id == payload.project_id, AgentFlow.key == key)
    ).scalar_one_or_none():
        raise ConflictError(f"A flow named '{payload.name}' already exists in this project.")

    # Surface every input the selected agents require as a run variable to fill in.
    required_inputs: dict[str, str] = {}
    for item in items:
        agent = session.get(Agent, item.agent_id)
        for field in ((agent.input_schema or {}).get("required") or []) if agent else []:
            required_inputs.setdefault(field, "")

    flow = AgentFlow(
        project_id=payload.project_id,
        key=key,
        name=payload.name,
        description=payload.description or f"Composed from {len(items)} selected agent(s).",
        category="Custom",
        status="draft",
        version="0.1.0",
        variables=required_inputs,
        created_by=principal.email,
        owner=principal.email,
        schedule={"enabled": False},
        governance={"run_roles": [], "budget_alert_percent": 80, "notify_on_failure": True, "slo_success_rate": 0.9},
    )
    session.add(flow)
    session.flush()

    # start -> agent... -> end, wired in cart order.
    session.add(
        AgentFlowNode(
            flow_id=flow.id, node_key="start", node_type="start", label="Start",
            position_x=120, position_y=80, sequence=0,
        )
    )
    previous_key = "start"
    for index, item in enumerate(items, start=1):
        agent = session.get(Agent, item.agent_id)
        node_key = f"step-{index}"
        session.add(
            AgentFlowNode(
                flow_id=flow.id,
                node_key=node_key,
                node_type="agent",
                label=agent.name if agent else node_key,
                agent_id=item.agent_id,
                agent_version=agent.version if agent else None,
                position_x=120,
                position_y=80 + index * 150,
                sequence=index,
                config=item.config_overrides or {},
                requires_approval=bool(agent and agent.requires_approval),
            )
        )
        session.add(
            AgentFlowEdge(flow_id=flow.id, source_node_key=previous_key, target_node_key=node_key)
        )
        previous_key = node_key

    session.add(
        AgentFlowNode(
            flow_id=flow.id, node_key="end", node_type="end", label="Complete",
            position_x=120, position_y=80 + (len(items) + 1) * 150, sequence=len(items) + 1,
        )
    )
    session.add(AgentFlowEdge(flow_id=flow.id, source_node_key=previous_key, target_node_key="end"))
    session.flush()

    from app.orchestration.graph import FlowGraph  # noqa: PLC0415

    from app.governance.policy_engine import AuditService  # noqa: PLC0415
    from app.services.flow_templates import default_environment_id  # noqa: PLC0415

    session.refresh(flow)
    flow.validation_result = FlowGraph.from_flow(flow).validate()
    project = session.get(Project, payload.project_id)
    if project is not None:
        flow.default_environment_id = default_environment_id(session, project)
    session.add(
        AgentFlowVersion(
            flow_id=flow.id,
            version=flow.version,
            change_summary="Built from the agent cart.",
            graph_snapshot={"nodes": [node.node_key for node in flow.nodes]},
            created_by=principal.email,
        )
    )
    AuditService(session).record(
        action="flow.create",
        entity_type="agent_flow",
        entity_id=flow.id,
        entity_label=flow.name,
        actor=principal.email,
        actor_type="user",
        project_id=flow.project_id,
        reason=f"Built from the agent cart ({len(items)} agents).",
        input_summary={"source": "cart", "agents": len(items)},
    )

    if payload.clear_cart:
        for item in items:
            session.delete(item)
    session.flush()
    session.refresh(flow)
    return FlowDetail.model_validate(flow)
