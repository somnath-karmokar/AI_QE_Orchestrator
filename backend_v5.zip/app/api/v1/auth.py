"""Authentication endpoints."""

from __future__ import annotations

from datetime import datetime
from app.core.time import UTC

from fastapi import APIRouter
from sqlalchemy import select

from app.api.deps import CurrentUser, DbSession
from app.core.config import settings
from app.core.errors import AuthenticationError
from app.core.security import ROLE_LABELS, create_access_token, permissions_for_role, verify_password
from app.models.identity import User
from app.schemas.entities import DemoUserOut, LoginRequest, LoginResponse, UserOut
from app.seed.catalog import DEMO_USERS

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        email=user.email,
        full_name=user.full_name,
        job_title=user.job_title,
        avatar_initials=user.avatar_initials,
        is_active=user.is_active,
        role_key=user.role_key,
        permissions=sorted(permissions_for_role(user.role_key)),
    )


@router.post("/login", response_model=LoginResponse, summary="Sign in and receive an access token")
def login(payload: LoginRequest, session: DbSession) -> LoginResponse:
    user = session.execute(
        select(User).where(User.email == payload.email.lower(), User.is_deleted.is_(False))
    ).scalar_one_or_none()

    # Same message for unknown user and wrong password: never reveal which.
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise AuthenticationError("The email address or password is incorrect.")
    if not user.is_active:
        raise AuthenticationError("This account is not active.")

    user.last_login_at = datetime.now(UTC)
    session.flush()

    token = create_access_token(
        {"sub": user.id, "email": user.email, "name": user.full_name, "role": user.role_key}
    )
    return LoginResponse(
        access_token=token,
        expires_in_minutes=settings.jwt_expiry_minutes,
        user=_user_out(user),
    )


@router.get("/me", response_model=UserOut, summary="Current authenticated user")
def me(principal: CurrentUser, session: DbSession) -> UserOut:
    user = session.get(User, principal.user_id)
    if user is None:
        raise AuthenticationError("The authenticated user no longer exists.")
    return _user_out(user)


@router.get(
    "/demo-users",
    response_model=list[DemoUserOut],
    summary="Seeded demo accounts",
    description="Available only while DEMO_MODE is enabled; returns an empty list otherwise.",
)
def demo_users() -> list[DemoUserOut]:
    if not settings.demo_mode:
        return []
    return [
        DemoUserOut(
            email=entry["email"],
            full_name=entry["full_name"],
            role=entry["role"],
            role_label=ROLE_LABELS.get(entry["role"], entry["role"]),
            job_title=entry["job_title"],
        )
        for entry in DEMO_USERS
    ]
