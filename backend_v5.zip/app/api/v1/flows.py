"""Flow Studio: creation, the builder, per-flow operations and run dispatch.

Static routes (`/templates`, `/compose`, `/overview`, ...) are declared before
`/{flow_id}` so they are never captured as a flow id.
"""

from __future__ import annotations

import json
from datetime import datetime
from app.core.time import UTC
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import PlainTextResponse
from sqlalchemy import func, select

from app.api.deps import DbSession, OptionalScopedProjectId, Pagination, ScopedProjectId, require_permission
from app.core.errors import AuthorizationError, ConflictError, NotFoundError
from app.core.security import Principal
from app.core.tenancy import assert_project_access
from app.governance.policy_engine import AuditService
from app.models.flow import AgentFlow, AgentFlowEdge, AgentFlowNode, AgentFlowVersion
from app.orchestration.composer import FlowComposer
from app.orchestration.graph import FlowGraph
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import (
    FlowApiTokenOut,
    FlowComposeRequest,
    FlowCreate,
    FlowDetail,
    FlowFromTemplateRequest,
    FlowRunRequest,
    FlowSettingsUpdate,
    FlowSummary,
    FlowUpdate,
    RunDetail,
    RunSummary,
)
from app.services import flow_templates
from app.services.api_access import flow_api_access
from app.services.flow_insights import FlowInsights, report_markdown, studio_overview
from app.services.flow_triggers import apply_schedule, issue_api_token, revoke_api_token, trigger_flow
from app.services.run_service import RunService, project_or_404

router = APIRouter(prefix="/flows", tags=["Flows"])


@router.get("/{flow_id}/api-access", summary="How a third party calls this flow")
def flow_api_access_route(
    flow_id: str,
    request: Request,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
) -> dict:
    """The endpoint, the contract and which API keys can already reach it."""
    flow = session.get(AgentFlow, flow_id)
    if flow is None or flow.is_deleted:
        raise NotFoundError(f"Flow '{flow_id}' was not found.")
    return flow_api_access(session, flow, base_url=str(request.base_url))

DEFAULT_GOVERNANCE = {"run_roles": [], "budget_alert_percent": 80, "notify_on_failure": True, "slo_success_rate": 0.9}


def _load_flow(session, flow_id: str, principal: Principal) -> AgentFlow:  # noqa: ANN001
    """The flow, if the caller is a member of the project that owns it.

    Every flow route goes through here, so the tenant check lives here too
    rather than being repeated thirteen times and forgotten once.
    """
    flow = session.get(AgentFlow, flow_id)
    if flow is None or flow.is_deleted:
        raise NotFoundError(f"Flow '{flow_id}' was not found.", details={"flow_id": flow_id})
    assert_project_access(session, principal, flow.project_id)
    return flow


def _structure(flow: AgentFlow) -> tuple:
    """What the flow does, ignoring where its nodes sit on the canvas."""
    nodes = sorted(
        json.dumps(
            {
                "key": node.node_key,
                "type": node.node_type,
                "label": node.label,
                "agent": node.agent_id,
                "version": node.agent_version,
                "condition": node.condition_expression,
                "config": node.config,
                "inputs": node.input_mapping,
                "outputs": node.output_mapping,
                "llm": node.llm_config,
                "retry": node.retry_policy,
                "timeout": node.timeout_seconds,
                "on_failure": node.on_failure,
                "approval": [node.requires_approval, node.approval_role],
                "cost_limit": node.cost_limit_usd,
            },
            sort_keys=True,
            default=str,
        )
        for node in flow.nodes
    )
    edges = sorted(
        (edge.source_node_key, edge.target_node_key, edge.branch_label or "", edge.condition_expression or "")
        for edge in flow.edges
    )
    return tuple(nodes), tuple(edges)


def _replace_graph(session, flow: AgentFlow, nodes, edges) -> None:  # noqa: ANN001
    """Replace the whole graph. The builder always sends the complete canvas."""
    session.query(AgentFlowNode).filter(AgentFlowNode.flow_id == flow.id).delete()
    session.query(AgentFlowEdge).filter(AgentFlowEdge.flow_id == flow.id).delete()
    session.flush()

    for node in nodes or []:
        session.add(AgentFlowNode(flow_id=flow.id, **node.model_dump()))
    for edge in edges or []:
        session.add(AgentFlowEdge(flow_id=flow.id, **edge.model_dump()))
    session.flush()


def _audit(session, flow: AgentFlow, principal: Principal, action: str, reason: str, **extra) -> None:  # noqa: ANN001, ANN003
    AuditService(session).record(
        action=action,
        entity_type="agent_flow",
        entity_id=flow.id,
        entity_label=flow.name,
        actor=principal.email,
        actor_type="user",
        project_id=flow.project_id,
        reason=reason,
        **extra,
    )


def _apply_operating_settings(
    flow: AgentFlow,
    *,
    owner: str | None,
    schedule: dict | None,
    governance: dict | None,
) -> None:
    if owner is not None:
        flow.owner = owner.strip() or None
    if schedule is not None:
        apply_schedule(flow, schedule)
    if governance is not None:
        flow.governance = {**DEFAULT_GOVERNANCE, **(flow.governance or {}), **governance}


def _check_run_role(flow: AgentFlow, principal: Principal) -> None:
    allowed = (flow.governance or {}).get("run_roles") or []
    if allowed and principal.role != "admin" and principal.role not in allowed:
        raise AuthorizationError(
            f"This flow can only be run by: {', '.join(allowed)}.",
            details={"role": principal.role, "allowed_roles": allowed},
        )


# ---------------------------------------------------------------------------
# Flow Studio: collection-level routes
# ---------------------------------------------------------------------------


@router.get("", response_model=Page[FlowSummary], summary="List flows")
def list_flows(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
    project_id: OptionalScopedProjectId = None,
    status: Annotated[str | None, Query()] = None,
    category: Annotated[str | None, Query()] = None,
) -> Page[FlowSummary]:
    statement = select(AgentFlow).where(AgentFlow.is_deleted.is_(False))
    if project_id:
        statement = statement.where(AgentFlow.project_id == project_id)
    if status:
        statement = statement.where(AgentFlow.status == status)
    if category:
        statement = statement.where(AgentFlow.category == category)

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(AgentFlow.updated_at.desc())
            .limit(pagination.limit)
            .offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[FlowSummary.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/overview", summary="Flow Studio overview: every flow with its own health")
def flows_overview(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
    project_id: ScopedProjectId,
    window_days: Annotated[int, Query(ge=1, le=180)] = 30,
) -> dict:
    return studio_overview(session, project_or_404(session, project_id), window_days)


@router.get("/templates", summary="Flow template gallery")
def list_flow_templates(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
    project_id: ScopedProjectId,
) -> list[dict]:
    return flow_templates.list_templates(session, project_or_404(session, project_id))


@router.post("/compose", summary="Draft a flow from a plain-English description")
def compose_flow(
    payload: FlowComposeRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> dict:
    project = project_or_404(session, payload.project_id, principal)
    composition = FlowComposer(session).compose(payload.description, project, name=payload.name)
    draft = composition.to_dict()
    draft["validation"] = FlowGraph.from_payload(composition.nodes, composition.edges).validate()
    return draft


@router.post("/from-template", response_model=FlowDetail, status_code=201, summary="Create a flow from a template")
def create_flow_from_template(
    payload: FlowFromTemplateRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> FlowDetail:
    project = project_or_404(session, payload.project_id, principal)
    flow = flow_templates.create_from_template(
        session,
        project,
        payload.template_key,
        name=payload.name,
        created_by=principal.email,
        description=payload.description,
        variables=payload.variables,
        cost_budget_usd=payload.cost_budget_usd,
    )
    _apply_operating_settings(
        flow,
        owner=payload.owner,
        schedule=payload.schedule,
        governance=payload.governance.model_dump() if payload.governance else None,
    )
    _audit(
        session,
        flow,
        principal,
        "flow.create",
        f"Created from the '{payload.template_key}' template.",
        input_summary={"source": "template", "template_key": payload.template_key},
    )
    session.flush()
    session.refresh(flow)
    return FlowDetail.model_validate(flow)


@router.post("", response_model=FlowDetail, status_code=201, summary="Create a flow")
def create_flow(
    payload: FlowCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> FlowDetail:
    project = project_or_404(session, payload.project_id, principal)
    if session.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == payload.project_id,
            AgentFlow.name == payload.name,
            AgentFlow.is_deleted.is_(False),
        )
    ).scalar_one_or_none():
        raise ConflictError(f"A flow named '{payload.name}' already exists in this project.")

    flow = AgentFlow(
        project_id=payload.project_id,
        key=flow_templates.unique_flow_key(session, project, payload.name),
        name=payload.name,
        description=payload.description,
        category=payload.category,
        variables=payload.variables,
        default_environment_id=payload.default_environment_id
        or flow_templates.default_environment_id(session, project),
        cost_budget_usd=payload.cost_budget_usd,
        token_budget=payload.token_budget,
        tags=payload.tags,
        status="draft",
        version="0.1.0",
        created_by=principal.email,
        owner=payload.owner or principal.email,
        schedule={"enabled": False},
        governance=dict(DEFAULT_GOVERNANCE),
    )
    session.add(flow)
    session.flush()

    _replace_graph(session, flow, payload.nodes, payload.edges)
    session.refresh(flow)
    flow.validation_result = FlowGraph.from_flow(flow).validate()
    _apply_operating_settings(flow, owner=None, schedule=payload.schedule, governance=payload.governance)
    session.add(
        AgentFlowVersion(
            flow_id=flow.id,
            version=flow.version,
            change_summary={
                "composer": "Drafted from a plain-English description.",
                "cart": "Built from the agent cart.",
            }.get(payload.source, "Created in Flow Studio."),
            graph_snapshot={"nodes": [node.node_key for node in flow.nodes]},
            created_by=principal.email,
        )
    )
    _audit(
        session,
        flow,
        principal,
        "flow.create",
        f"Created in Flow Studio ({payload.source}).",
        input_summary={"source": payload.source, "nodes": len(payload.nodes)},
    )
    session.flush()
    session.refresh(flow)
    return FlowDetail.model_validate(flow)


# ---------------------------------------------------------------------------
# A single flow
# ---------------------------------------------------------------------------


@router.get("/{flow_id}", response_model=FlowDetail, summary="Get a flow")
def get_flow(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
) -> FlowDetail:
    return FlowDetail.model_validate(_load_flow(session, flow_id, principal))


@router.patch("/{flow_id}", response_model=FlowDetail, summary="Update a flow")
def update_flow(
    flow_id: str,
    payload: FlowUpdate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> FlowDetail:
    flow = _load_flow(session, flow_id, principal)
    data = payload.model_dump(exclude_unset=True)
    nodes = data.pop("nodes", None)
    edges = data.pop("edges", None)

    for field, value in data.items():
        setattr(flow, field, value)
    flow.updated_by = principal.email

    if payload.nodes is not None or payload.edges is not None:
        before = _structure(flow)
        _replace_graph(session, flow, payload.nodes or [], payload.edges or [])
        session.refresh(flow)
        flow.validation_result = FlowGraph.from_flow(flow).validate()
        # Moving nodes is layout; changing steps means the published version no longer matches.
        if _structure(flow) != before and flow.status in {"published", "validated"}:
            flow.status = "draft"
            _audit(session, flow, principal, "flow.edit", "Steps changed; the flow is a draft until republished.")

    session.flush()
    session.refresh(flow)
    return FlowDetail.model_validate(flow)


@router.patch("/{flow_id}/settings", response_model=FlowDetail, summary="Update a flow's operating settings")
def update_flow_settings(
    flow_id: str,
    payload: FlowSettingsUpdate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> FlowDetail:
    flow = _load_flow(session, flow_id, principal)
    data = payload.model_dump(exclude_unset=True)
    changed = sorted(data)

    for field in ("name", "description", "tags", "variables", "default_environment_id", "cost_budget_usd", "token_budget"):
        if field in data:
            setattr(flow, field, data[field])
    _apply_operating_settings(
        flow,
        owner=data.get("owner"),
        schedule=data.get("schedule"),
        governance=data.get("governance"),
    )
    flow.updated_by = principal.email
    _audit(
        session,
        flow,
        principal,
        "flow.settings.update",
        "Updated " + ", ".join(field.replace("_", " ") for field in changed) + "." if changed else "No changes.",
        input_summary={field: data[field] for field in changed if field != "variables"},
        severity="warning" if {"governance", "cost_budget_usd", "schedule"} & set(changed) else "info",
    )
    session.flush()
    session.refresh(flow)
    return FlowDetail.model_validate(flow)


@router.get("/{flow_id}/dashboard", summary="The flow's own dashboard")
def flow_dashboard(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
    window_days: Annotated[int, Query(ge=1, le=180)] = 30,
) -> dict:
    return FlowInsights(session, _load_flow(session, flow_id, principal)).dashboard(window_days)


@router.get("/{flow_id}/observability", summary="Latency, reliability, model usage and events for one flow")
def flow_observability(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
    window_days: Annotated[int, Query(ge=1, le=180)] = 14,
) -> dict:
    return FlowInsights(session, _load_flow(session, flow_id, principal)).observability(window_days)


@router.get("/{flow_id}/governance", summary="Controls, approvals, budget and audit for one flow")
def flow_governance(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
    window_days: Annotated[int, Query(ge=1, le=365)] = 90,
) -> dict:
    return FlowInsights(session, _load_flow(session, flow_id, principal)).governance(window_days)


@router.get("/{flow_id}/report", summary="A shareable report for one flow")
def flow_report(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("report:read"))],
    window_days: Annotated[int, Query(ge=1, le=180)] = 30,
    format: Annotated[Literal["json", "markdown"], Query()] = "json",  # noqa: A002
):  # noqa: ANN201
    flow = _load_flow(session, flow_id, principal)
    report = FlowInsights(session, flow).report(window_days)
    if format == "markdown":
        filename = f"{flow.key}-report-{report['period']['to']}.md"
        return PlainTextResponse(
            report_markdown(report),
            media_type="text/markdown; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    return report


@router.post("/{flow_id}/api-token", response_model=FlowApiTokenOut, summary="Enable or rotate the API trigger")
def create_flow_api_token(
    flow_id: str,
    request: Request,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> FlowApiTokenOut:
    flow = _load_flow(session, flow_id, principal)
    token = issue_api_token(session, flow, principal.email)
    endpoint = str(request.base_url).rstrip("/") + f"/api/v1/hooks/flows/{flow.id}"
    example_inputs = json.dumps({"inputs": {key: value for key, value in (flow.variables or {}).items()}})
    return FlowApiTokenOut(
        token=token,
        hint=flow.webhook_token_hint or "",
        endpoint=endpoint,
        example=(
            f'curl -X POST "{endpoint}" -H "X-Flow-Token: {token}" '
            f"-H \"Content-Type: application/json\" -d '{example_inputs}'"
        ),
    )


@router.delete("/{flow_id}/api-token", response_model=MessageResponse, summary="Disable the API trigger")
def delete_flow_api_token(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> MessageResponse:
    flow = _load_flow(session, flow_id, principal)
    revoke_api_token(session, flow, principal.email)
    return MessageResponse(message=f"The API trigger for '{flow.name}' is disabled.")


@router.post("/{flow_id}/validate", summary="Validate a flow graph")
def validate_flow(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:read"))],
) -> dict:
    flow = _load_flow(session, flow_id, principal)
    result = FlowGraph.from_flow(flow).validate()
    flow.validation_result = result
    if result["valid"] and flow.status == "draft":
        flow.status = "validated"
    session.flush()
    return result


@router.post("/{flow_id}/publish", response_model=FlowDetail, summary="Publish a flow version")
def publish_flow(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
    change_summary: Annotated[str | None, Query()] = None,
) -> FlowDetail:
    flow = _load_flow(session, flow_id, principal)
    result = FlowGraph.from_flow(flow).validate()
    if not result["valid"]:
        raise ConflictError(
            "The flow cannot be published until its validation errors are resolved.",
            details={"validation": result},
        )

    try:
        major, minor, _ = (int(part) for part in flow.version.split("."))
        version = "1.0.0" if major == 0 else f"{major}.{minor + 1}.0"
    except ValueError:
        version = "1.0.0"
    existing = {item.version for item in flow.versions}
    while version in existing:
        major, minor, _ = (int(part) for part in version.split("."))
        version = f"{major}.{minor + 1}.0"

    flow.version = version
    flow.status = "published"
    flow.validation_result = result
    summary = change_summary or "Published from Flow Studio."
    session.add(
        AgentFlowVersion(
            flow_id=flow.id,
            version=version,
            change_summary=summary,
            created_by=principal.email,
            published_at=datetime.now(UTC),
            graph_snapshot={
                "nodes": [node.node_key for node in flow.nodes],
                "edges": [
                    {"source": edge.source_node_key, "target": edge.target_node_key}
                    for edge in flow.edges
                ],
            },
        )
    )
    _audit(session, flow, principal, "flow.publish", f"Published version {version}: {summary}")
    session.flush()
    session.refresh(flow)
    return FlowDetail.model_validate(flow)


@router.post("/{flow_id}/run", response_model=RunDetail, status_code=202, summary="Run a flow")
def run_flow(
    flow_id: str,
    payload: FlowRunRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:run"))],
) -> RunDetail:
    flow = _load_flow(session, flow_id, principal)
    _check_run_role(flow, principal)

    if payload.synchronous:
        service = RunService(session)
        run = service.start_flow_run(
            flow_id=flow.id,
            project_id=flow.project_id,
            inputs=payload.inputs,
            environment_id=payload.environment_id,
            triggered_by=principal.email,
        )
        run = service.run_synchronously(run)
        session.refresh(run)
        return RunDetail.model_validate(run)

    # Dispatch commits, so the client can poll or subscribe immediately.
    run = trigger_flow(
        session,
        flow,
        trigger="manual",
        triggered_by=principal.email,
        inputs=payload.inputs,
        environment_id=payload.environment_id,
    )
    session.refresh(run)
    return RunDetail.model_validate(run)


@router.get("/{flow_id}/runs", response_model=Page[RunSummary], summary="Runs of a flow")
def flow_runs(
    flow_id: str,
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("run:read"))],
    status: Annotated[str | None, Query()] = None,
) -> Page[RunSummary]:
    service = RunService(session)
    rows, total = service.list_runs(
        flow_id=flow_id, status=status, limit=pagination.limit, offset=pagination.offset
    )
    return Page(
        items=[RunSummary.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.delete("/{flow_id}", response_model=MessageResponse, summary="Archive a flow")
def delete_flow(
    flow_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("flow:write"))],
) -> MessageResponse:
    flow = _load_flow(session, flow_id, principal)
    flow.soft_delete(principal.email)
    flow.status = "archived"
    flow.schedule = {"enabled": False}
    flow.next_run_at = None
    flow.webhook_token_hash = None
    flow.webhook_token_hint = None
    _audit(session, flow, principal, "flow.archive", "Archived; schedule and API trigger switched off.")
    session.flush()
    return MessageResponse(message=f"Flow '{flow.name}' was archived.")
