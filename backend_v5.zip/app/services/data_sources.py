"""Connecting, reading and testing a tenant's own data sources.

Two rules hold this together, and everything else follows from them.

**A secret goes in and never comes out.** `create` and `update` accept
plaintext, split it by the kind's secret fields, and encrypt that half
immediately. Nothing in this module returns plaintext except `credentials`,
which exists for the adapter that is about to open the connection and is
documented as such. `describe` -- what the API serves -- cannot return a secret
because it never reads one.

**A data source belongs to exactly one project.** Every function takes a project
and filters by it, so "list the sources" and "load this source" cannot be asked
in a way that spans tenants. The API layer checks membership of that project
before it gets here, and `load` checks the source is in the project it was asked
for, so an id from another tenant reads as not found rather than as somebody
else's database.
"""

from __future__ import annotations

from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import crypto
from app.core.errors import ConflictError, NotFoundError, ValidationError
from app.core.logging import get_logger
from app.models.datasource import (
    DATA_SOURCE_KINDS,
    DataSource,
    secret_fields_for,
)

logger = get_logger(__name__)

# What each kind needs before it can be called connected. Kept here rather than
# in the model because it describes a form, not a row.
REQUIRED_CONFIG: dict[str, tuple[str, ...]] = {
    "postgres": ("host", "database"),
    "mysql": ("host", "database"),
    "sqlserver": ("host", "database"),
    "oracle": ("host", "service_name"),
    "mongodb": ("host",),
    "rest_api": ("base_url",),
    "graphql": ("endpoint",),
    "s3": ("bucket",),
    "azure_blob": ("account_name", "container"),
    "gcs": ("bucket",),
    "elasticsearch": ("host",),
    "snowflake": ("account", "warehouse"),
    "jira": ("base_url",),
    "confluence": ("base_url",),
    "git": ("repository_url",),
    "file_upload": (),
    "custom": (),
}


# Non-secret fields a kind accepts but can do without. Without these the
# connection form could only ask for what is mandatory, so there would be no way
# to supply a username, a port or a schema at all.
OPTIONAL_CONFIG: dict[str, tuple[str, ...]] = {
    "postgres": ("port", "username", "schema", "ssl_mode"),
    "mysql": ("port", "username"),
    "sqlserver": ("port", "username", "schema"),
    "oracle": ("port", "username"),
    "mongodb": ("port", "username", "database", "replica_set"),
    "rest_api": ("auth_header", "timeout_seconds"),
    "graphql": ("auth_header",),
    "s3": ("region", "prefix", "endpoint_url"),
    "azure_blob": ("prefix",),
    "gcs": ("prefix",),
    "elasticsearch": ("port", "username", "index"),
    "snowflake": ("database", "schema", "role", "username"),
    "jira": ("project_key", "email"),
    "confluence": ("space_key", "email"),
    "git": ("branch", "username"),
    "file_upload": (),
    "custom": ("base_url", "notes"),
}


def slug(value: str) -> str:
    """The stable key a name maps to; unique within a project."""
    return "".join(ch if ch.isalnum() else "-" for ch in value.lower()).strip("-")[:60]


def split_secrets(kind: str, values: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Separate a submitted connection form into (public config, secrets).

    The split is made here, from the kind, rather than taken from the caller.
    A client that put a password in the wrong half would otherwise have it
    stored in the clear and rendered back onto a screen.
    """
    secret_names = set(secret_fields_for(kind))
    config = {k: v for k, v in values.items() if k not in secret_names}
    secrets = {k: v for k, v in values.items() if k in secret_names and v not in (None, "")}
    return config, secrets


def _validate(kind: str, config: dict[str, Any]) -> None:
    if kind not in DATA_SOURCE_KINDS:
        raise ValidationError(
            f"'{kind}' is not a supported data source kind.",
            details={"supported": list(DATA_SOURCE_KINDS)},
        )
    missing = [field for field in REQUIRED_CONFIG.get(kind, ()) if not config.get(field)]
    if missing:
        raise ValidationError(
            f"A {kind} data source needs: {', '.join(missing)}.",
            details={"missing": missing},
        )


def list_for_project(session: Session, project_id: str) -> list[DataSource]:
    return list(
        session.execute(
            select(DataSource)
            .where(DataSource.project_id == project_id, DataSource.is_deleted.is_(False))
            .order_by(DataSource.name)
        )
        .scalars()
        .all()
    )


def load(session: Session, project_id: str, data_source_id: str) -> DataSource:
    """Load one source, scoped to its project.

    Filtering on `project_id` in the query rather than fetching by id and
    comparing afterwards means a caller cannot get a row back at all unless it
    is theirs -- there is no moment where another tenant's row is in hand.
    """
    row = session.execute(
        select(DataSource).where(
            DataSource.id == data_source_id,
            DataSource.project_id == project_id,
            DataSource.is_deleted.is_(False),
        )
    ).scalar_one_or_none()
    if row is None:
        raise NotFoundError(f"Data source '{data_source_id}' was not found.")
    return row


def create(
    session: Session,
    *,
    project_id: str,
    name: str,
    kind: str,
    connection: dict[str, Any],
    description: str | None = None,
    allow_writes: bool = False,
    actor: str | None = None,
) -> DataSource:
    config, secrets = split_secrets(kind, connection or {})
    _validate(kind, config)

    key = slug(name)
    if not key:
        raise ValidationError("A data source needs a name with at least one letter or digit.")
    existing = session.execute(
        select(DataSource).where(
            DataSource.project_id == project_id,
            DataSource.key == key,
            DataSource.is_deleted.is_(False),
        )
    ).scalar_one_or_none()
    if existing is not None:
        raise ConflictError(f"A data source named '{name}' already exists in this project.")

    now = datetime.now(UTC)
    source = DataSource(
        project_id=project_id,
        key=key,
        name=name,
        description=description,
        kind=kind,
        config=config,
        allow_writes=allow_writes,
        status="unverified",
        created_by=actor,
        secret_bundle=crypto.encrypt_mapping(secrets) if secrets else None,
        secret_fingerprint=crypto.fingerprint(secrets) if secrets else None,
        secret_updated_at=now if secrets else None,
        secret_updated_by=actor if secrets else None,
    )
    session.add(source)
    session.flush()
    logger.info(
        "data_source_created",
        project_id=project_id,
        kind=kind,
        key=key,
        has_credentials=bool(secrets),
    )
    return source


def update(
    session: Session,
    source: DataSource,
    *,
    name: str | None = None,
    description: str | None = None,
    connection: dict[str, Any] | None = None,
    allow_writes: bool | None = None,
    is_enabled: bool | None = None,
    actor: str | None = None,
) -> DataSource:
    """Apply an edit. Omitting `connection` leaves the stored credential alone.

    That is what makes an edit form usable at all: the screen cannot show the
    current password, so it cannot send it back, so a blank field has to mean
    "unchanged" rather than "clear it".
    """
    if name is not None:
        source.name = name
    if description is not None:
        source.description = description
    if allow_writes is not None:
        source.allow_writes = allow_writes
    if is_enabled is not None:
        source.is_enabled = is_enabled

    if connection is not None:
        config, secrets = split_secrets(source.kind, connection)
        merged = {**source.config, **config}
        _validate(source.kind, merged)
        source.config = merged
        if secrets:
            source.secret_bundle = crypto.encrypt_mapping(secrets)
            source.secret_fingerprint = crypto.fingerprint(secrets)
            source.secret_updated_at = datetime.now(UTC)
            source.secret_updated_by = actor
        # Connection details changed, so whatever the last test proved no
        # longer applies.
        source.status = "unverified"
        source.last_test_ok = None

    session.flush()
    return source


def credentials(source: DataSource) -> crypto.SecretBundle:
    """Decrypt this source's credentials, for an adapter about to connect.

    The one function in this module that yields plaintext. Call it as late as
    possible, keep the bundle out of anything that gets logged or returned, and
    do not put its contents into a dict that something else will serialise.
    """
    if not source.secret_bundle:
        return crypto.SecretBundle({})
    return crypto.SecretBundle(crypto.decrypt_mapping(source.secret_bundle))


def test_connection(session: Session, source: DataSource) -> dict[str, Any]:
    """Check a source is reachable and record the result.

    What this can prove depends on the kind. Rather than claim more than it
    checked, the result names the check that ran, so "connected" on screen
    always corresponds to something that actually happened.
    """
    from app.services.data_source_probes import probe  # noqa: PLC0415

    outcome = probe(source, credentials(source))

    source.last_tested_at = datetime.now(UTC)
    source.last_test_ok = outcome["ok"]
    source.status = "connected" if outcome["ok"] else "error"
    source.last_error = None if outcome["ok"] else outcome.get("detail")
    session.flush()

    logger.info(
        "data_source_tested",
        project_id=source.project_id,
        key=source.key,
        ok=outcome["ok"],
        check=outcome.get("check"),
    )
    return {**outcome, "tested_at": source.last_tested_at.isoformat()}


def describe(source: DataSource) -> dict[str, Any]:
    """The API view. Cannot leak a secret because it never decrypts one."""
    secret_names = secret_fields_for(source.kind)
    return {
        "id": source.id,
        "project_id": source.project_id,
        "key": source.key,
        "name": source.name,
        "description": source.description,
        "kind": source.kind,
        "status": source.status,
        "is_enabled": source.is_enabled,
        "allow_writes": source.allow_writes,
        "config": source.config,
        # Which credential fields this kind takes, and whether one is stored --
        # enough for a screen to render the form and say "a key is set", with
        # no way to read it back.
        "credential_fields": list(secret_names),
        "has_credentials": bool(source.secret_bundle),
        "credential_fingerprint": source.secret_fingerprint,
        "credential_updated_at": (
            source.secret_updated_at.isoformat() if source.secret_updated_at else None
        ),
        "credential_updated_by": source.secret_updated_by,
        "last_tested_at": source.last_tested_at.isoformat() if source.last_tested_at else None,
        "last_test_ok": source.last_test_ok,
        "last_error": source.last_error,
        "created_by": source.created_by,
        "created_at": source.created_at.isoformat(),
    }
