"""Healing analytics.

Every number here is counted from records the platform actually wrote. Nothing
is modelled, estimated or assumed — which matters more for this dashboard than
for most, because a self-healing platform that reports its own success rate has
an obvious incentive to flatter itself.

Two consequences worth stating:

  * **The success rate counts only validated repairs.** A heal that was applied
    before re-run validation existed is reported as unproven, not as a success.
  * **Effort saved is bounded and conservative.** It counts repairs that held,
    at a configured minutes-per-repair, and says what that assumption is. An
    unbounded "hours saved" headline would be marketing, not measurement.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.testing import Execution, ExecutionTest, HealingRecord

# What a person would have spent diagnosing and fixing one drifted locator by
# hand. Stated, not hidden, so a reader can disagree with it.
MINUTES_PER_MANUAL_REPAIR = 25

# Terminal states, for rate calculations.
DECIDED = {"applied", "rolled_back", "validation_failed", "rejected"}


@dataclass(slots=True)
class Window:
    days: int
    start: datetime

    @property
    def label(self) -> str:
        return f"last {self.days} days"


def window_start(now: datetime, days: int) -> Window:
    """Midnight-aligned, so a chart and a KPI over the same period agree."""
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return Window(days=days, start=midnight - timedelta(days=days - 1))


def dashboard(session: Session, project_id: str, *, days: int = 30) -> dict[str, Any]:
    """Everything the Healing Control Centre shows, counted from records."""
    now = datetime.now(UTC)
    window = window_start(now, days)

    records = list(
        session.execute(
            select(HealingRecord).where(
                HealingRecord.project_id == project_id,
                HealingRecord.created_at >= window.start,
            )
        )
        .scalars()
        .all()
    )

    return {
        "project_id": project_id,
        "window": {"days": days, "label": window.label, "start": window.start.isoformat()},
        "as_of": now.isoformat(),
        "totals": _totals(records),
        "by_change_type": _by_change_type(records),
        "by_strategy": _by_strategy(records),
        "by_failure_class": _count(records, lambda record: record.failure_class),
        "confidence": _confidence(records),
        "validation": _validation(records),
        "trend": _trend(records, window, days),
        "queue": _queue(session, project_id),
        "effort": _effort(records),
        "evidence": _evidence_quality(session, project_id, window),
        "recent": _recent(records),
    }


# ---------------------------------------------------------------------------


def _totals(records: list[HealingRecord]) -> dict[str, Any]:
    decided = [record for record in records if record.status in DECIDED]
    applied = [record for record in decided if record.status == "applied"]
    # Only a repair whose re-run passed counts as a success. An older record
    # applied without validation is unproven, and is reported as such.
    proven = [record for record in applied if record.validation_status == "passed"]

    return {
        "proposed": len(records),
        "decided": len(decided),
        "applied": len(applied),
        "proven": len(proven),
        "unproven_applied": len(applied) - len(proven),
        "rolled_back": sum(1 for record in decided if record.status == "rolled_back"),
        "rejected": sum(1 for record in decided if record.status == "rejected"),
        "blocked": sum(1 for record in records if record.status == "blocked"),
        "awaiting_decision": sum(1 for record in records if record.status == "proposed"),
        # The headline. Denominator is decided repairs, not proposals: a
        # proposal nobody looked at is not a failure.
        "success_rate": round(len(proven) / len(decided), 4) if decided else 0.0,
        "success_rate_basis": "repairs whose re-run passed, over repairs decided",
    }


def _by_change_type(records: list[HealingRecord]) -> list[dict[str, Any]]:
    grouped: dict[str, list[HealingRecord]] = defaultdict(list)
    for record in records:
        grouped[record.change_type].append(record)

    rows = []
    for change_type, items in grouped.items():
        decided = [item for item in items if item.status in DECIDED]
        proven = [
            item
            for item in decided
            if item.status == "applied" and item.validation_status == "passed"
        ]
        rows.append(
            {
                "change_type": change_type,
                "proposed": len(items),
                "decided": len(decided),
                "proven": len(proven),
                "success_rate": round(len(proven) / len(decided), 4) if decided else 0.0,
            }
        )
    return sorted(rows, key=lambda row: row["proposed"], reverse=True)


def _by_strategy(records: list[HealingRecord]) -> list[dict[str, Any]]:
    """Which rung of the ladder is doing the work, and how well it holds."""
    grouped: dict[str, list[HealingRecord]] = defaultdict(list)
    for record in records:
        grouped[record.locator_strategy or "unknown"].append(record)

    rows = []
    for strategy, items in grouped.items():
        decided = [item for item in items if item.status in DECIDED]
        proven = [
            item
            for item in decided
            if item.status == "applied" and item.validation_status == "passed"
        ]
        rows.append(
            {
                "strategy": strategy,
                "proposed": len(items),
                "proven": len(proven),
                "success_rate": round(len(proven) / len(decided), 4) if decided else 0.0,
                "mean_confidence": round(
                    sum(item.confidence for item in items) / len(items), 4
                ),
            }
        )
    return sorted(rows, key=lambda row: row["proposed"], reverse=True)


def _confidence(records: list[HealingRecord]) -> dict[str, Any]:
    """Does confidence predict whether a repair holds?

    The question a reviewer actually has about a confidence score. If proven and
    rolled-back repairs score the same, the number is decoration.
    """
    proven = [
        record.confidence
        for record in records
        if record.status == "applied" and record.validation_status == "passed"
    ]
    failed = [
        record.confidence
        for record in records
        if record.status in {"rolled_back", "validation_failed"}
    ]
    return {
        "mean_when_proven": round(sum(proven) / len(proven), 4) if proven else None,
        "mean_when_failed": round(sum(failed) / len(failed), 4) if failed else None,
        "sample_proven": len(proven),
        "sample_failed": len(failed),
        "separation": (
            round(sum(proven) / len(proven) - sum(failed) / len(failed), 4)
            if proven and failed
            else None
        ),
        "note": (
            "Positive separation means confidence predicted which repairs held. "
            "Near zero means the score is not earning its place."
        ),
    }


def _validation(records: list[HealingRecord]) -> dict[str, Any]:
    counts = _count(records, lambda record: record.validation_status)
    modes = _count(
        [record for record in records if record.validation_mode],
        lambda record: record.validation_mode,
    )
    attempts = [record.attempt_count for record in records if record.attempt_count]
    return {
        "by_status": counts,
        "by_mode": modes,
        "mean_attempts": round(sum(attempts) / len(attempts), 2) if attempts else 0.0,
        # Said plainly: a simulated re-run exercises the lifecycle but is not
        # evidence about a real browser.
        "simulated_share": (
            round(modes.get("simulated", 0) / sum(modes.values()), 4) if modes else None
        ),
    }


def _trend(records: list[HealingRecord], window: Window, days: int) -> list[dict[str, Any]]:
    buckets: dict[str, dict[str, int]] = {}
    for offset in range(days):
        day = (window.start + timedelta(days=offset)).date().isoformat()
        buckets[day] = {"proposed": 0, "proven": 0, "rolled_back": 0}

    for record in records:
        if record.created_at is None:
            continue
        day = record.created_at.date().isoformat()
        if day not in buckets:
            continue
        buckets[day]["proposed"] += 1
        if record.status == "applied" and record.validation_status == "passed":
            buckets[day]["proven"] += 1
        elif record.status in {"rolled_back", "validation_failed"}:
            buckets[day]["rolled_back"] += 1

    return [{"date": day, **counts} for day, counts in sorted(buckets.items())]


def _queue(session: Session, project_id: str) -> dict[str, Any]:
    """What is waiting on a person right now, regardless of the window."""
    waiting = list(
        session.execute(
            select(HealingRecord).where(
                HealingRecord.project_id == project_id,
                HealingRecord.status == "proposed",
            )
        )
        .scalars()
        .all()
    )
    now = datetime.now(UTC)
    ages = [
        (now - record.created_at).total_seconds() / 3600
        for record in waiting
        if record.created_at
    ]
    return {
        "awaiting_decision": len(waiting),
        "oldest_hours": round(max(ages), 1) if ages else 0.0,
        "by_change_type": _count(waiting, lambda record: record.change_type),
        "needing_approval_by_policy": sum(
            1
            for record in waiting
            if (record.policy_decision or {}).get("requires_approval")
        ),
    }


def _effort(records: list[HealingRecord]) -> dict[str, Any]:
    proven = [
        record
        for record in records
        if record.status == "applied" and record.validation_status == "passed"
    ]
    minutes = len(proven) * MINUTES_PER_MANUAL_REPAIR
    return {
        "repairs_that_held": len(proven),
        "minutes_per_repair": MINUTES_PER_MANUAL_REPAIR,
        "minutes_saved": minutes,
        "hours_saved": round(minutes / 60, 1),
        # The assumption is part of the number, not a footnote.
        "basis": (
            f"{len(proven)} repair(s) that passed their re-run, at an assumed "
            f"{MINUTES_PER_MANUAL_REPAIR} minutes to diagnose and fix by hand. "
            f"Repairs that did not hold are excluded."
        ),
    }


def _evidence_quality(session: Session, project_id: str, window: Window) -> dict[str, Any]:
    """How much of the healing was grounded in a real browser run.

    A high success rate on simulated evidence means something different from the
    same rate on captured pages, and the dashboard should not blur them.
    """
    executions = list(
        session.execute(
            select(Execution).where(
                Execution.project_id == project_id,
                Execution.created_at >= window.start,
            )
        )
        .scalars()
        .all()
    )
    modes = _count(executions, lambda execution: execution.mode)
    failures = int(
        session.execute(
            select(ExecutionTest)
            .join(Execution, Execution.id == ExecutionTest.execution_id)
            .where(
                Execution.project_id == project_id,
                Execution.created_at >= window.start,
                ExecutionTest.result == "failed",
            )
        )
        .scalars()
        .all()
        .__len__()
    )
    return {
        "executions_by_mode": modes,
        "failed_tests": failures,
        "real_browser_share": (
            round(modes.get("playwright", 0) / sum(modes.values()), 4) if modes else None
        ),
    }


def _recent(records: list[HealingRecord], limit: int = 10) -> list[dict[str, Any]]:
    ordered = sorted(
        records, key=lambda record: record.created_at or datetime.min.replace(tzinfo=UTC), reverse=True
    )
    return [
        {
            "id": record.id,
            "change_type": record.change_type,
            "failure_class": record.failure_class,
            "strategy": record.locator_strategy,
            "status": record.status,
            "validation_status": record.validation_status,
            "confidence": record.confidence,
            "from": record.original_locator,
            "to": record.proposed_locator,
            "approver": record.approver,
            "created_at": record.created_at.isoformat() if record.created_at else None,
        }
        for record in ordered[:limit]
    ]


def _count(items: list[Any], key) -> dict[str, int]:  # noqa: ANN001
    counts: dict[str, int] = defaultdict(int)
    for item in items:
        value = key(item)
        if value:
            counts[str(value)] += 1
    return dict(counts)
