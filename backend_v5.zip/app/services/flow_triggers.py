"""How a flow starts without anyone opening the builder: schedules and API calls.

A flow with a schedule is started by the in-process scheduler; a flow with an
API token can be started by CI or another tool with a single authenticated
POST. Both paths go through `trigger_flow`, so every run -- manual, scheduled
or API -- is validated, budgeted, governed and audited the same way.
"""

from __future__ import annotations

import secrets
import threading
from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import session_scope
from app.core.errors import AuthorizationError, ConflictError, ValidationError
from app.core.logging import get_logger
from app.core.security import hash_api_token
from app.governance.policy_engine import AuditService
from app.models.flow import AgentFlow
from app.models.run import AgentRun
from app.orchestration.schedule import describe_schedule, next_run_after, normalise_schedule
from app.services.run_service import ACTIVE_STATUSES, RunService

logger = get_logger(__name__)

TOKEN_PREFIX = "qef_"
RUNNABLE_STATUSES = {"published", "validated"}


def trigger_flow(
    session: Session,
    flow: AgentFlow,
    *,
    trigger: str,
    triggered_by: str,
    inputs: dict[str, Any] | None = None,
    title: str | None = None,
    role: str | None = None,
    environment_id: str | None = None,
) -> AgentRun:
    """Start and dispatch a run of the flow, enforcing the flow's own run controls."""
    if trigger in {"schedule", "api"} and flow.status not in RUNNABLE_STATUSES:
        raise ConflictError(
            f"'{flow.name}' is {flow.status}; only published flows run on a schedule or from the API."
        )
    allowed_roles = (flow.governance or {}).get("run_roles") or []
    if role and allowed_roles and role != "admin" and role not in allowed_roles:
        raise AuthorizationError(
            f"This flow can only be run by: {', '.join(allowed_roles)}.",
            details={"role": role, "allowed_roles": allowed_roles},
        )

    service = RunService(session)
    run = service.start_flow_run(
        flow_id=flow.id,
        project_id=flow.project_id,
        inputs=inputs or {},
        triggered_by=triggered_by,
        trigger=trigger,
        title=title,
        environment_id=environment_id,
    )
    AuditService(session).record(
        action="flow.trigger",
        entity_type="agent_flow",
        entity_id=flow.id,
        entity_label=flow.name,
        actor=triggered_by,
        actor_type="system" if trigger == "schedule" else "user",
        project_id=flow.project_id,
        reason=f"Run #{run.run_number} started by {trigger}.",
        input_summary={"trigger": trigger, "inputs": sorted((inputs or {}).keys())},
        run_id=run.id,
    )
    service.dispatch(run)
    return run


# ---------------------------------------------------------------------------
# Schedule
# ---------------------------------------------------------------------------


def apply_schedule(flow: AgentFlow, raw: dict[str, Any] | None, *, now: datetime | None = None) -> None:
    schedule = normalise_schedule(raw)
    flow.schedule = schedule
    flow.next_run_at = next_run_after(schedule, now or datetime.now(UTC))
    if schedule.get("enabled"):
        flow.trigger_type = "schedule"
    elif flow.trigger_type == "schedule":
        flow.trigger_type = "api" if flow.webhook_token_hash else "manual"


# ---------------------------------------------------------------------------
# API token
# ---------------------------------------------------------------------------


def issue_api_token(session: Session, flow: AgentFlow, actor: str) -> str:
    """Create (or rotate) the flow's API token. The plain token is returned once."""
    rotated = bool(flow.webhook_token_hash)
    token = TOKEN_PREFIX + secrets.token_urlsafe(24)
    flow.webhook_token_hash = hash_api_token(token)
    flow.webhook_token_hint = token[-4:]
    if flow.trigger_type == "manual":
        flow.trigger_type = "api"
    AuditService(session).record(
        action="flow.api_token.rotate" if rotated else "flow.api_token.create",
        entity_type="agent_flow",
        entity_id=flow.id,
        entity_label=flow.name,
        actor=actor,
        actor_type="user",
        project_id=flow.project_id,
        severity="warning",
        reason="API trigger token rotated; the previous token no longer works."
        if rotated
        else "API trigger enabled.",
    )
    session.flush()
    return token


def revoke_api_token(session: Session, flow: AgentFlow, actor: str) -> None:
    if not flow.webhook_token_hash:
        raise ValidationError("This flow has no API token to revoke.")
    flow.webhook_token_hash = None
    flow.webhook_token_hint = None
    if flow.trigger_type == "api":
        flow.trigger_type = "manual"
    AuditService(session).record(
        action="flow.api_token.revoke",
        entity_type="agent_flow",
        entity_id=flow.id,
        entity_label=flow.name,
        actor=actor,
        actor_type="user",
        project_id=flow.project_id,
        severity="warning",
        reason="API trigger disabled.",
    )
    session.flush()


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------


def run_due_flows(session: Session, now: datetime | None = None) -> list[str]:
    """Start every scheduled flow that is due. Returns the ids of the runs started.

    A flow whose previous run is still active is not started again; its next
    slot is simply moved on, so a slow run never stacks up duplicates.
    """
    now = now or datetime.now(UTC)
    due = list(
        session.execute(
            select(AgentFlow).where(
                AgentFlow.is_deleted.is_(False),
                AgentFlow.next_run_at.is_not(None),
                AgentFlow.next_run_at <= now,
            )
        ).scalars()
    )
    started: list[str] = []
    for flow in due:
        schedule = flow.schedule or {}
        flow.next_run_at = next_run_after(schedule, now)
        if not schedule.get("enabled"):
            continue

        busy = session.execute(
            select(AgentRun.id).where(AgentRun.flow_id == flow.id, AgentRun.status.in_(ACTIVE_STATUSES)).limit(1)
        ).first()
        if busy is not None:
            logger.info("scheduled_run_skipped_busy", flow_id=flow.id)
            session.commit()
            continue

        try:
            run = trigger_flow(
                session,
                flow,
                trigger="schedule",
                triggered_by="scheduler",
                title=f"{flow.name} ({describe_schedule(schedule).lower()})",
            )
            started.append(run.id)
        except Exception as exc:  # noqa: BLE001 - one bad flow must not stop the others
            session.rollback()
            flow = session.get(AgentFlow, flow.id)
            if flow is not None:
                flow.next_run_at = next_run_after(flow.schedule or {}, now)
                AuditService(session).record(
                    action="flow.trigger",
                    entity_type="agent_flow",
                    entity_id=flow.id,
                    entity_label=flow.name,
                    actor="scheduler",
                    project_id=flow.project_id,
                    outcome="failure",
                    severity="warning",
                    reason=f"Scheduled run could not start: {str(exc)[:300]}",
                )
                session.commit()
            logger.warning("scheduled_run_failed", flow_id=getattr(flow, "id", None), error=str(exc)[:200])
    session.commit()
    return started


class FlowScheduler:
    """A small in-process scheduler thread; one tick per interval."""

    def __init__(self, interval_seconds: int | None = None) -> None:
        self.interval = max(5, interval_seconds or settings.scheduler_interval_seconds)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="flow-scheduler", daemon=True)
        self._thread.start()
        logger.info("flow_scheduler_started", interval_seconds=self.interval)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                with session_scope() as session:
                    started = run_due_flows(session)
                if started:
                    logger.info("scheduled_runs_started", count=len(started))
            except Exception as exc:  # noqa: BLE001 - keep ticking
                logger.warning("flow_scheduler_tick_failed", error=str(exc)[:200])


flow_scheduler = FlowScheduler()
