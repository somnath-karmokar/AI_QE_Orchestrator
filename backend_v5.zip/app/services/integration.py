"""What another platform needs to know to use this one safely.

Three things, and the third is the one that matters:

  * a **manifest** -- what this platform is, how to authenticate, what the
    limits are, and where the contract is written down;
  * a **catalog** -- the flows and agents this particular key may invoke, each
    with the JSON Schema of what it takes and returns;
  * a **guardrail block** -- attached to every run response, saying what the
    governance layer decided, what it refused, what is waiting on a human, and
    what it cost.

The guardrail block exists because an integration that only reports success or
failure is not safe to build on. A caller has to be able to tell "this finished"
from "this is waiting for a person to approve it" from "policy refused this",
and to act differently in each case, without parsing prose.
"""

from __future__ import annotations

from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import ValidationError
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest, GovernancePolicy
from app.models.integration import SCOPES, IntegrationClient
from app.models.run import AgentRun

# A run's status, in terms a calling system can branch on without knowing this
# platform's vocabulary.
DISPOSITIONS: dict[str, str] = {
    "queued": "pending",
    "running": "pending",
    "paused": "waiting_for_approval",
    "awaiting_approval": "waiting_for_approval",
    "succeeded": "succeeded",
    "completed": "succeeded",
    "failed": "failed",
    "cancelled": "cancelled",
    "aborted": "cancelled",
    "blocked": "refused",
}

TERMINAL = {"succeeded", "failed", "cancelled", "refused"}


def disposition(status: str | None) -> str:
    """Map an internal status onto the small set a caller should branch on."""
    return DISPOSITIONS.get((status or "").lower(), "pending")


# ---------------------------------------------------------------------------
# Manifest
# ---------------------------------------------------------------------------


def _available_counts(session: Session, client: IntegrationClient) -> dict[str, int]:
    """How many flows and agents this key can actually invoke right now."""
    return {
        "flows": len(granted_flows(session, client)) if client.has_scope("flows:run") else 0,
        "agents": len(granted_agents(session, client)) if client.has_scope("agents:run") else 0,
    }


def build_manifest(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """Everything a calling platform needs before its first real request."""
    policies = list(
        session.execute(
            select(GovernancePolicy).where(GovernancePolicy.is_enabled.is_(True))
        )
        .scalars()
        .all()
    )
    project_policies = [
        policy for policy in policies if policy.project_id in (None, client.project_id)
    ]

    return {
        "platform": {
            "name": settings.app_name,
            "version": settings.app_version,
            "api_version": "v1",
            "base_path": f"{settings.api_prefix}/integration",
        },
        "client": {
            "name": client.name,
            "project_id": client.project_id,
            "platform": client.platform,
            "token_hint": client.token_hint,
            "expires_at": client.expires_at.isoformat() if client.expires_at else None,
        },
        "authentication": {
            "scheme": "api_key",
            "header": "X-API-Key",
            "scopes_granted": client.scopes or [],
            "scopes_available": SCOPES,
        },
        "limits": {
            "rate_limit_per_minute": client.rate_limit_per_minute,
            # Counted, not taken from the grant list: a project-wide grant has an
            # empty list and would otherwise advertise nothing to call.
            **{f"{name}_available": count for name, count in _available_counts(session, client).items()},
        },
        "guardrails": guardrail_contract(project_policies),
        "endpoints": {
            "manifest": "GET /integration/manifest",
            "catalog": "GET /integration/catalog",
            "start_flow": "POST /integration/flows/{flow_id}/runs",
            "invoke_agent": "POST /integration/agents/{agent_key}/runs",
            "run_status": "GET /integration/runs/{run_id}",
            "cancel_run": "POST /integration/runs/{run_id}/cancel",
            # The same agents and flows, for a caller that is an agent rather
            # than a pipeline. Advertised here so nobody has to be told.
            "mcp": "POST /mcp",
        },
        "conventions": {
            "run_dispositions": sorted(set(DISPOSITIONS.values())),
            "terminal_dispositions": sorted(TERMINAL),
            "correlation_header": "X-Correlation-ID",
            "idempotency_header": "X-Idempotency-Key",
            "protocols": {
                "rest": "v1",
                # Model Context Protocol, for agent platforms. Same scopes,
                # same governance, same run envelope.
                "mcp": "2024-11-05",
            },
            # Stated rather than implied: a caller that assumed callbacks worked
            # would wait for a message that never arrives.
            "result_delivery": {
                "poll": "GET /integration/runs/{run_id}",
                "callbacks": "not_available",
                "detail": (
                    "Outbound callbacks are not delivered yet. A key may carry a callback_url "
                    "for forward compatibility, but nothing is sent to it -- poll instead."
                ),
            },
            "error_shape": {
                "error": {"code": "string", "message": "string", "details": {}, "correlation_id": "string"}
            },
        },
        "documentation": "docs/integration/README.md",
    }


def owns_run(client: IntegrationClient):  # noqa: ANN201 - a SQLAlchemy condition
    """The condition matching runs this key started.

    Primarily the key's own id. The name match is a fallback for runs started
    before runs recorded the id, so an existing integration does not lose sight
    of its history -- it is not an identity, and two keys may share a name.
    """
    return or_(
        AgentRun.integration_client_id == client.id,
        and_(
            AgentRun.integration_client_id.is_(None),
            AgentRun.triggered_by == f"integration:{client.name}",
        ),
    )


def started_by(run: AgentRun, client: IntegrationClient) -> bool:
    """Whether this key started that run. The in-Python twin of `owns_run`."""
    if run.integration_client_id is not None:
        return run.integration_client_id == client.id
    return run.triggered_by == f"integration:{client.name}"


def claim_run(run: AgentRun, client: IntegrationClient) -> AgentRun:
    """Record which key started a run, at the moment it starts one."""
    run.integration_client_id = client.id
    return run


def describe_client(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """Who this key is and what it may do -- the answer to "is my key working?".

    A caller holds an opaque string and otherwise has to guess: whether it is
    live, what it may reach, when it expires, how much of its budget is left.
    Reaching any real endpoint to find out means starting work as a side effect
    of a health check, so this exists to be called instead.
    """
    counts = granted_counts(session, client)
    return {
        "authenticated": True,
        "client": {
            "name": client.name,
            "platform": client.platform,
            "description": client.description,
            "project_id": client.project_id,
            "token_hint": client.token_hint,
            "created_at": client.created_at.isoformat() if client.created_at else None,
        },
        "scopes": {
            "granted": sorted(client.scopes or []),
            # What each one permits, so a caller can explain a 403 without the docs.
            "meaning": {scope: SCOPES[scope] for scope in sorted(client.scopes or []) if scope in SCOPES},
        },
        "provisioned": {
            "flows": counts["flows"],
            "agents": counts["agents"],
            "all_flows_in_project": counts["all_flows_in_project"],
            "all_agents_in_project": counts["all_agents_in_project"],
        },
        "validity": {
            "active": bool(client.is_active),
            "expires_at": client.expires_at.isoformat() if client.expires_at else None,
            "expired": not client.is_usable(),
        },
        "limits": {"rate_limit_per_minute": client.rate_limit_per_minute},
        "usage": {
            "calls": client.call_count,
            "last_used_at": client.last_used_at.isoformat() if client.last_used_at else None,
        },
        "activity": _run_activity(session, client),
    }


def _run_activity(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """What this key has actually started, rolled up by disposition."""
    rows = list(
        session.execute(
            select(AgentRun.status, func.count(AgentRun.id), func.sum(AgentRun.total_cost_usd))
            .where(AgentRun.project_id == client.project_id, owns_run(client))
            .group_by(AgentRun.status)
        ).all()
    )

    by_disposition: dict[str, int] = {}
    total, cost = 0, 0.0
    for status, count, spend in rows:
        by_disposition[disposition(status)] = by_disposition.get(disposition(status), 0) + count
        total += count
        cost += float(spend or 0)

    last = session.execute(
        select(AgentRun.created_at)
        .where(AgentRun.project_id == client.project_id, owns_run(client))
        .order_by(AgentRun.created_at.desc())
        .limit(1)
    ).scalar()

    return {
        "runs_total": total,
        "runs_by_disposition": by_disposition,
        "in_flight": by_disposition.get("pending", 0) + by_disposition.get("waiting_for_approval", 0),
        "total_cost_usd": round(cost, 6),
        "last_run_at": last.isoformat() if last else None,
    }


def list_runs(
    session: Session,
    client: IntegrationClient,
    *,
    limit: int = 20,
    offset: int = 0,
    agent_key: str | None = None,
    flow_id: str | None = None,
    disposition_filter: str | None = None,
    since: datetime | None = None,
    until: datetime | None = None,
) -> dict[str, Any]:
    """The runs this key started, newest first, optionally narrowed.

    Scoped exactly as `GET /runs/{run_id}` is, so the list and the detail agree
    about what belongs to this key: its own runs, never another key's and never
    one a person started in the web app. Every filter narrows that set; none
    can widen it.
    """
    owned = [AgentRun.project_id == client.project_id, owns_run(client)]
    if flow_id:
        owned.append(AgentRun.flow_id == flow_id)
    if agent_key:
        owned.append(
            AgentRun.agent_id.in_(select(Agent.id).where(Agent.key == agent_key))
        )
    if disposition_filter:
        statuses = [status for status, state in DISPOSITIONS.items() if state == disposition_filter]
        if not statuses:
            raise ValidationError(
                f"'{disposition_filter}' is not a disposition.",
                details={"dispositions": sorted(set(DISPOSITIONS.values()))},
            )
        owned.append(AgentRun.status.in_(statuses))
    if since is not None:
        owned.append(AgentRun.created_at >= (since if since.tzinfo else since.replace(tzinfo=UTC)))
    if until is not None:
        owned.append(AgentRun.created_at < (until if until.tzinfo else until.replace(tzinfo=UTC)))
    total = session.execute(select(func.count(AgentRun.id)).where(*owned)).scalar() or 0
    rows = list(
        session.execute(
            select(AgentRun).where(*owned).order_by(AgentRun.created_at.desc()).limit(limit).offset(offset)
        )
        .scalars()
        .all()
    )
    return {
        "items": [run_envelope(session, run, include_outputs=False) for run in rows],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


def guardrail_contract(policies: list[GovernancePolicy]) -> dict[str, Any]:
    """The promises this platform makes to anything calling it.

    These are not descriptions of intent -- each one is enforced in code and has
    a test. They are stated here so an integrator can design around them rather
    than discover them.
    """
    return {
        "guarantees": [
            {
                "id": "human_approval_for_high_risk",
                "statement": (
                    "An action whose risk level requires approval pauses and waits for a named "
                    "person. The run reports 'waiting_for_approval'; it does not proceed and it "
                    "does not fail."
                ),
                "enforced_by": "app/governance/policy_engine.py",
            },
            {
                "id": "business_assertions_never_changed",
                "statement": (
                    "Self-healing repairs how a test finds and drives the application. It never "
                    "changes an assertion, a business rule or test logic, at any confidence, for "
                    "any caller."
                ),
                "enforced_by": "app/healing/policy.py",
            },
            {
                "id": "no_unvalidated_repair",
                "statement": (
                    "A repair is only applied after a re-run proves it. A failed re-run leaves the "
                    "test exactly as it was."
                ),
                "enforced_by": "app/healing/validation.py",
            },
            {
                "id": "everything_is_audited",
                "statement": (
                    "Every invocation, decision and refusal is written to an append-only audit log "
                    "with the caller, the inputs, the policy result and the outcome."
                ),
                "enforced_by": "app/governance/policy_engine.py",
            },
            {
                "id": "budgets_are_enforced",
                "statement": (
                    "Project, flow and agent budgets are checked before spending. Exceeding one "
                    "stops the run rather than continuing at cost."
                ),
                "enforced_by": "app/ai/cost/tracker.py",
            },
            {
                "id": "scopes_are_explicit",
                "statement": (
                    "A key may only invoke what it was explicitly granted. There is no wildcard "
                    "grant, and an ungranted flow is indistinguishable from one that does not exist."
                ),
                "enforced_by": "app/api/integration_auth.py",
            },
        ],
        "caller_obligations": [
            "Treat 'waiting_for_approval' as a normal outcome, not an error; a human decides next.",
            "Do not retry a run that is pending -- poll it. Callbacks are not delivered yet.",
            "Send X-Idempotency-Key on start requests so a network retry does not start a second run.",
            "Do not send secrets in inputs; reference them by name and hold them in your own vault.",
        ],
        "active_policies": [
            {
                "key": policy.key,
                "name": policy.name,
                "type": policy.policy_type,
                "effect": policy.effect,
                "severity": policy.severity,
            }
            for policy in policies
        ],
    }


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


def build_catalog(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """The flows and agents this key may invoke, with their contracts."""
    from app.agents.registry import builtin_catalog  # noqa: PLC0415

    # Only what `resolve_flow` and `resolve_agent` would actually let this key
    # run: a catalog that lists something the invoke endpoint then refuses is a
    # promise that fails.
    flows = []
    if client.has_scope("catalog:read"):
        flows = [_flow_descriptor(flow) for flow in granted_flows(session, client)]

    agents = []
    if client.has_scope("catalog:read"):
        reachable = {agent.handler_key for agent in catalogued_agents(session, client)}
        agents = [
            _agent_descriptor(entry)
            for entry in builtin_catalog()
            if entry.get("key") in reachable
        ]

    return {
        "project_id": client.project_id,
        "flows": flows,
        "agents": agents,
        "counts": {"flows": len(flows), "agents": len(agents)},
    }


def catalogued_agents(session: Session, client: IntegrationClient) -> list[Agent]:
    """The agents the catalog lists for this key: granted, and built in.

    Documentation about an agent -- its model card, its golden dataset -- is
    served for exactly this set, so a key can read about what it was shown and
    nothing else. The catalog and those endpoints share this function so the
    two cannot disagree.
    """
    from app.agents.registry import AGENT_CLASS_BY_KEY  # noqa: PLC0415

    return [agent for agent in granted_agents(session, client) if agent.handler_key in AGENT_CLASS_BY_KEY]


def catalogued_agent(session: Session, client: IntegrationClient, agent_key: str) -> Agent | None:
    if not client.has_scope("catalog:read"):
        return None
    return next((a for a in catalogued_agents(session, client) if a.handler_key == agent_key), None)


def catalogued_flow(session: Session, client: IntegrationClient, flow_id: str) -> AgentFlow | None:
    if not client.has_scope("catalog:read"):
        return None
    return next((f for f in granted_flows(session, client) if f.id == flow_id), None)


def granted_flows(session: Session, client: IntegrationClient) -> list[AgentFlow]:
    """Every flow this key's grants reach, whatever its scopes.

    A project-wide grant means every *published* flow: publishing is the act
    that says a flow is ready for someone else to run, and a draft is work in
    progress. A flow named explicitly is an operator's deliberate choice and is
    honoured whatever its status.
    """
    conditions = [AgentFlow.project_id == client.project_id, AgentFlow.is_deleted.is_(False)]
    if client.grants_all_flows:
        conditions.append(AgentFlow.status == "published")
    else:
        ids = list(client.allowed_flow_ids or [])
        if not ids:
            return []
        conditions.append(AgentFlow.id.in_(ids))

    return list(session.execute(select(AgentFlow).where(*conditions).order_by(AgentFlow.name)).scalars().all())


def resolve_flow(session: Session, client: IntegrationClient, flow_id: str) -> AgentFlow | None:
    """The flow this key may run as `flow_id`, or None.

    The one authorisation rule for flows, so what the catalog lists, what the
    OpenAPI document describes and what the endpoints accept cannot drift apart.
    """
    if not client.has_scope("flows:run"):
        return None

    flow = session.get(AgentFlow, flow_id)
    if flow is None or flow.is_deleted or flow.project_id != client.project_id:
        return None
    if flow_id in (client.allowed_flow_ids or []):
        return flow
    if client.grants_all_flows and flow.status == "published":
        return flow
    return None


def _reachable_agents(
    session: Session, client: IntegrationClient, keys: list[str] | None
) -> dict[str, Agent]:
    """The agent a key would run for each of `keys`, by handler key.

    An agent is either global (`project_id` NULL -- every built-in) or belongs to
    one project, and a key reaches both: the same rule the agents API, the
    composer and the copilot already use. This used to match
    `project_id == client.project_id` alone, so every built-in was unreachable
    while the catalog went on advertising it -- a key explicitly granted
    `user-story-completeness` was told "no such resource" for it, over REST and
    over MCP alike. Nothing exercised an agent call, so nothing noticed.

    A project's own agent wins over a built-in with the same key. Unpublished
    and deleted agents are never reachable.
    """
    if keys is not None and not keys:
        return {}
    conditions = [
        Agent.is_deleted.is_(False),
        Agent.is_published.is_(True),
        or_(Agent.project_id.is_(None), Agent.project_id == client.project_id),
    ]
    if keys is not None:
        conditions.append(Agent.handler_key.in_(keys))
    rows = session.execute(select(Agent).where(*conditions)).scalars().all()
    chosen: dict[str, Agent] = {}
    for agent in rows:
        current = chosen.get(agent.handler_key)
        own = agent.project_id == client.project_id
        if current is None or (own and current.project_id != client.project_id):
            chosen[agent.handler_key] = agent
    return chosen


def resolve_agent(session: Session, client: IntegrationClient, agent_key: str) -> Agent | None:
    """The agent this key may run as `agent_key`, or None.

    The one place that decides. The REST endpoint, the catalog and both MCP
    paths call it, so what is listed and what can be called cannot drift apart.
    """
    if not client.may_run_agent(agent_key):
        return None
    return _reachable_agents(session, client, [agent_key]).get(agent_key)


def granted_counts(session: Session, client: IntegrationClient) -> dict[str, Any]:
    """How much this key reaches, for the manifest and for an operator's review."""
    return {
        "flows": len(granted_flows(session, client)),
        "agents": len(granted_agents(session, client)),
        "all_flows_in_project": bool(client.grants_all_flows),
        "all_agents_in_project": bool(client.grants_all_agents),
    }


def granted_agents(session: Session, client: IntegrationClient) -> list[Agent]:
    """Every agent this key may run.

    In the order the grants were written, or by name for a project-wide grant,
    where there is no operator-chosen order to preserve.
    """
    if client.grants_all_agents:
        reachable = _reachable_agents(session, client, None)
        return sorted(reachable.values(), key=lambda agent: agent.name)

    keys = list(client.allowed_agent_keys or [])
    reachable = _reachable_agents(session, client, keys)
    return [reachable[key] for key in keys if key in reachable]


def _flow_descriptor(flow: AgentFlow) -> dict[str, Any]:
    """A flow as something another system can call, not as a diagram."""
    variables = flow.variables or {}
    return {
        "id": flow.id,
        "name": flow.name,
        "description": flow.description,
        "category": flow.category,
        "version": flow.version,
        "status": flow.status,
        "owner": flow.owner,
        "invoke": {
            "method": "POST",
            "path": f"/integration/flows/{flow.id}/runs",
            "scope": "flows:run",
        },
        # A flow's variables are its inputs; publishing them as a schema means a
        # caller can validate before sending rather than after failing.
        "input_schema": {
            "type": "object",
            "properties": {
                name: {
                    "type": _json_type(value),
                    "default": value,
                    "description": f"Flow variable '{name}'.",
                }
                for name, value in variables.items()
            },
            # False, and enforced: an input the flow does not declare is
            # refused rather than ignored, because ignoring it would run on the
            # default and return a confident answer about the wrong thing.
            "additionalProperties": False,
        },
        "guardrails": {
            "requires_approval": _flow_has_approval(flow),
            "risk_level": (flow.governance or {}).get("risk_level", "medium"),
            "cost_budget_usd": (flow.governance or {}).get("cost_budget_usd"),
        },
    }


def _agent_descriptor(entry: dict[str, Any]) -> dict[str, Any]:
    return {
        "key": entry.get("key"),
        "name": entry.get("name"),
        "description": entry.get("description"),
        "category": entry.get("category"),
        "invoke": {
            "method": "POST",
            "path": f"/integration/agents/{entry.get('key')}/runs",
            "scope": "agents:run",
        },
        "input_schema": entry.get("input_schema") or {"type": "object", "properties": {}},
        "output_schema": entry.get("output_schema") or {},
        "guardrails": {
            "requires_approval": bool(entry.get("requires_approval")),
            "risk_level": entry.get("risk_level", "medium"),
            "cost_tier": entry.get("cost_tier"),
        },
    }


def _flow_has_approval(flow: AgentFlow) -> bool:
    return any((node.node_type or "") == "approval" for node in (flow.nodes or []))


def _json_type(value: Any) -> str:  # noqa: ANN401
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "string"


# ---------------------------------------------------------------------------
# Run representation
# ---------------------------------------------------------------------------


def run_envelope(session: Session, run: AgentRun, *, include_outputs: bool = True) -> dict[str, Any]:
    """A run as a calling system should see it.

    Deliberately flat and stable: disposition, guardrails, outputs. The internal
    step graph is not part of this contract and may change without notice.
    """
    pending = list(
        session.execute(
            select(ApprovalRequest).where(
                ApprovalRequest.run_id == run.id, ApprovalRequest.status == "pending"
            )
        )
        .scalars()
        .all()
    )

    state = disposition(run.status)
    if pending and state == "pending":
        state = "waiting_for_approval"

    envelope: dict[str, Any] = {
        "run_id": run.id,
        "run_number": run.run_number,
        "title": run.title,
        "kind": run.kind,
        "status": run.status,
        "disposition": state,
        "is_terminal": state in TERMINAL,
        "flow_id": run.flow_id,
        "correlation_id": run.correlation_id,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "duration_ms": run.duration_ms,
        "summary": run.summary,
        "error": run.error,
        "progress": {
            "completed_steps": run.completed_step_count,
            "total_steps": run.step_count,
        },
        "guardrails": {
            "awaiting_approval": [
                {
                    "approval_id": approval.id,
                    "title": approval.title,
                    "reason": approval.reason,
                    "risk_level": approval.risk_level,
                    "required_role": approval.required_role,
                    "requested_at": approval.created_at.isoformat() if approval.created_at else None,
                    "expires_at": approval.expires_at.isoformat() if approval.expires_at else None,
                }
                for approval in pending
            ],
            "cost": {
                "total_cost_usd": round(run.total_cost_usd, 6),
                "total_tokens": run.total_tokens,
            },
            # Said plainly, because a caller must not mistake a pause for a finish.
            "note": (
                "This run is waiting for a named person to approve it. It has not failed, and it "
                "will continue once a decision is recorded."
                if state == "waiting_for_approval"
                else None
            ),
        },
        "links": {
            "self": f"{settings.api_prefix}/integration/runs/{run.id}",
            "cancel": f"{settings.api_prefix}/integration/runs/{run.id}/cancel",
        },
    }
    if include_outputs:
        envelope["outputs"] = run.outputs or {}
    return envelope
