"""Knowledge Fabric service: ingestion, indexing and retrieval.

    Sources -> Connectors -> Document processing -> Chunking / metadata
            -> Embeddings -> Vector search -> Knowledge Fabric -> Agents

Every agent that needs context calls `retrieve()`; nothing reaches the vector
store by another route, which is what keeps project isolation and the
prompt-injection defences in one place.
"""

from __future__ import annotations

from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.cost.tracker import UsageContext
from app.ai.router.model_router import ModelRouter
from app.core.logging import get_logger
from app.knowledge.chunking import checksum, chunk_document
from app.models.knowledge import KnowledgeChunk, KnowledgeCollection, KnowledgeDocument, KnowledgeSource
from app.vectorstore.base import (
    COLLECTION_KNOWLEDGE,
    SearchResult,
    VectorRecord,
    build_where,
)
from app.vectorstore.factory import get_vector_store

logger = get_logger(__name__)

# Retrieved text is untrusted input. These markers are neutralised before the
# content is placed in a prompt (spec section 30, prompt-injection defences).
_INJECTION_MARKERS = (
    "ignore previous instructions",
    "ignore all previous",
    "disregard the above",
    "system prompt:",
    "you are now",
    "new instructions:",
    "override your instructions",
)


def neutralize_untrusted(text: str, *, max_chars: int = 4000) -> str:
    """Defang instruction-like content retrieved from documents or tool output."""
    if not text:
        return ""
    cleaned = text[:max_chars]
    lowered = cleaned.lower()
    for marker in _INJECTION_MARKERS:
        start = 0
        while (position := lowered.find(marker, start)) != -1:
            cleaned = cleaned[:position] + "[filtered-instruction]" + cleaned[position + len(marker) :]
            lowered = cleaned.lower()
            start = position + len("[filtered-instruction]")
    return cleaned


class KnowledgeService:
    """Indexes documents into Chroma and retrieves grounded context for agents."""

    def __init__(self, session: Session) -> None:
        self.session = session
        self.store = get_vector_store()
        self.router = ModelRouter(session)

    # ------------------------------------------------------------------
    # Ingestion
    # ------------------------------------------------------------------
    def ingest_document(
        self,
        *,
        project_id: str,
        source: KnowledgeSource,
        external_id: str,
        title: str,
        content: str,
        module: str = "General",
        artifact_type: str = "document",
        url: str | None = None,
        author: str | None = None,
        environment: str | None = None,
        tags: list[str] | None = None,
        collection: str | None = None,
        doc_metadata: dict[str, Any] | None = None,
        embed: bool = True,
    ) -> KnowledgeDocument:
        """Create or update a document, then re-chunk and re-embed it."""
        collection_name = collection or source.collection_name or COLLECTION_KNOWLEDGE
        content_checksum = checksum(content)

        document = self.session.execute(
            select(KnowledgeDocument).where(
                KnowledgeDocument.source_id == source.id,
                KnowledgeDocument.external_id == external_id,
            )
        ).scalar_one_or_none()

        if document is None:
            document = KnowledgeDocument(
                project_id=project_id,
                source_id=source.id,
                external_id=external_id,
                title=title,
                content=content,
                source_type=source.source_type,
                artifact_type=artifact_type,
                module=module,
                environment=environment,
                url=url,
                author=author,
                tags=tags or [],
                access_scope=source.access_scope,
                doc_metadata=doc_metadata or {},
                checksum=content_checksum,
                index_status="pending",
            )
            self.session.add(document)
            self.session.flush()
        elif document.checksum == content_checksum and document.index_status == "indexed":
            return document  # unchanged, nothing to re-embed
        else:
            document.title = title
            document.content = content
            document.module = module
            document.tags = tags or []
            document.doc_metadata = doc_metadata or {}
            document.checksum = content_checksum
            document.version += 1
            document.index_status = "pending"
            self.session.flush()

        if embed:
            self.index_document(document, collection_name)
        return document

    def index_document(self, document: KnowledgeDocument, collection: str | None = None) -> int:
        """Chunk, embed and upsert one document; returns the chunk count."""
        collection_name = collection or COLLECTION_KNOWLEDGE
        document.index_status = "indexing"
        self.session.flush()

        # Replace rather than append, so re-indexing never leaves stale vectors.
        self.store.delete_by_document(collection_name, document_id=document.id)
        self.session.query(KnowledgeChunk).filter(KnowledgeChunk.document_id == document.id).delete()

        chunks = chunk_document(document.content, title=document.title)
        if not chunks:
            document.index_status = "indexed"
            document.chunk_count = 0
            document.indexed_at = datetime.now(UTC)
            self.session.flush()
            return 0

        try:
            embedding_response = self.router.embed(
                [chunk.content for chunk in chunks],
                UsageContext(project_id=document.project_id, correlation_id=document.id),
            )
        except Exception as exc:  # noqa: BLE001
            document.index_status = "failed"
            self.session.flush()
            logger.error("embedding_failed", document_id=document.id, error=str(exc)[:200])
            raise

        records: list[VectorRecord] = []
        now_iso = datetime.now(UTC).isoformat()

        for chunk, vector in zip(chunks, embedding_response.vectors, strict=False):
            chunk_row = KnowledgeChunk(
                project_id=document.project_id,
                document_id=document.id,
                chunk_index=chunk.index,
                content=chunk.content,
                token_estimate=chunk.token_estimate,
                collection_name=collection_name,
                embedding_model=embedding_response.model,
                chunk_metadata={"heading": chunk.heading},
            )
            self.session.add(chunk_row)
            self.session.flush()
            chunk_row.vector_id = chunk_row.id

            records.append(
                VectorRecord(
                    id=chunk_row.id,
                    content=chunk.content,
                    embedding=vector,
                    # Metadata mandated by spec section 8 -- drives project
                    # isolation and every filtered retrieval in the platform.
                    metadata={
                        "project_id": document.project_id,
                        "source_type": document.source_type,
                        "source_id": document.source_id,
                        "document_id": document.id,
                        "document_version": document.version,
                        "chunk_id": chunk_row.id,
                        "chunk_index": chunk.index,
                        "module": document.module,
                        "environment": document.environment or "",
                        "artifact_type": document.artifact_type,
                        "title": document.title,
                        "external_id": document.external_id,
                        "created_at": now_iso,
                        "tags": document.tags,
                        "access_scope": document.access_scope,
                    },
                )
            )

        self.store.upsert(collection_name, records)

        document.index_status = "indexed"
        document.chunk_count = len(records)
        document.indexed_at = datetime.now(UTC)
        self.session.flush()
        logger.info("document_indexed", document_id=document.id, chunks=len(records), collection=collection_name)
        return len(records)

    def index_text(
        self,
        *,
        project_id: str,
        collection: str,
        record_id: str,
        content: str,
        metadata: dict[str, Any],
    ) -> None:
        """Index a single non-document artifact (test case, defect, failure signature)."""
        embedding_response = self.router.embed([content], UsageContext(project_id=project_id))
        now_iso = datetime.now(UTC).isoformat()
        base_metadata = {
            "project_id": project_id,
            "document_id": record_id,
            "chunk_id": record_id,
            "document_version": 1,
            "created_at": now_iso,
            "access_scope": "project",
            **metadata,
        }
        self.store.upsert(
            collection,
            [VectorRecord(id=record_id, content=content, embedding=embedding_response.vectors[0], metadata=base_metadata)],
        )

    def index_texts(
        self,
        *,
        project_id: str,
        collection: str,
        items: list[dict[str, Any]],
        batch_size: int = 128,
    ) -> int:
        """Index many non-document artifacts in batches.

        One embedding call per batch rather than per record. Seeding indexes
        several hundred test cases, defects and failure signatures, so this is
        the difference between a demo reset taking minutes and taking seconds.
        """
        if not items:
            return 0

        now_iso = datetime.now(UTC).isoformat()
        indexed = 0

        for start in range(0, len(items), batch_size):
            batch = items[start : start + batch_size]
            embeddings = self.router.embed(
                [item["content"] for item in batch], UsageContext(project_id=project_id)
            )
            records = [
                VectorRecord(
                    id=item["id"],
                    content=item["content"],
                    embedding=vector,
                    metadata={
                        "project_id": project_id,
                        "document_id": item["id"],
                        "chunk_id": item["id"],
                        "document_version": 1,
                        "created_at": now_iso,
                        "access_scope": "project",
                        **item.get("metadata", {}),
                    },
                )
                for item, vector in zip(batch, embeddings.vectors, strict=False)
            ]
            self.store.upsert(collection, records)
            indexed += len(records)

        logger.info("texts_indexed", collection=collection, count=indexed)
        return indexed

    def delete_source(self, source: KnowledgeSource) -> int:
        removed = self.store.delete_by_source(
            source.collection_name, project_id=source.project_id, source_id=source.id
        )
        self.session.query(KnowledgeDocument).filter(KnowledgeDocument.source_id == source.id).delete()
        return removed

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------
    def retrieve(
        self,
        query: str,
        *,
        project_id: str,
        collection: str = COLLECTION_KNOWLEDGE,
        limit: int = 5,
        module: str | None = None,
        source_type: str | list[str] | None = None,
        artifact_type: str | None = None,
        min_score: float = 0.0,
        sanitize: bool = True,
    ) -> list[SearchResult]:
        """Semantic search, always scoped to one project."""
        if not query.strip():
            return []
        embedding = self.router.embed([query], UsageContext(project_id=project_id)).vectors[0]
        where = build_where(
            project_id=project_id, module=module, source_type=source_type, artifact_type=artifact_type
        )
        results = self.store.query(collection, embedding, limit=limit, where=where)
        filtered = [result for result in results if result.score >= min_score]
        if sanitize:
            for result in filtered:
                result.content = neutralize_untrusted(result.content)
        return filtered

    def retrieve_context_block(
        self,
        query: str,
        *,
        project_id: str,
        collection: str = COLLECTION_KNOWLEDGE,
        limit: int = 5,
        module: str | None = None,
        max_chars: int = 6000,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Return a prompt-ready context block plus citable evidence entries."""
        results = self.retrieve(
            query, project_id=project_id, collection=collection, limit=limit, module=module
        )
        blocks: list[str] = []
        evidence: list[dict[str, Any]] = []
        length = 0

        for index, result in enumerate(results, start=1):
            title = result.metadata.get("title") or result.metadata.get("external_id") or "Knowledge item"
            block = f"[{index}] {title}\n{result.content}"
            if length + len(block) > max_chars:
                break
            blocks.append(block)
            length += len(block)
            evidence.append(
                {
                    "ref": f"[{index}]",
                    "title": title,
                    "source_type": result.metadata.get("source_type"),
                    "external_id": result.metadata.get("external_id"),
                    "document_id": result.metadata.get("document_id"),
                    "module": result.metadata.get("module"),
                    "score": round(result.score, 3),
                }
            )

        return ("\n\n".join(blocks), evidence)

    def find_similar(
        self,
        text: str,
        *,
        project_id: str,
        collection: str,
        limit: int = 5,
        exclude_id: str | None = None,
        min_score: float = 0.0,
    ) -> list[SearchResult]:
        """Similarity search used for duplicate detection and RCA evidence."""
        results = self.retrieve(
            text, project_id=project_id, collection=collection, limit=limit + 1, min_score=min_score
        )
        return [result for result in results if result.id != exclude_id][:limit]

    # ------------------------------------------------------------------
    # Status / reporting
    # ------------------------------------------------------------------
    def overview(self, project_id: str) -> dict[str, Any]:
        sources = list(
            self.session.execute(
                select(KnowledgeSource).where(
                    KnowledgeSource.project_id == project_id, KnowledgeSource.is_deleted.is_(False)
                )
            )
            .scalars()
            .all()
        )
        document_count = (
            self.session.execute(
                select(func.count(KnowledgeDocument.id)).where(
                    KnowledgeDocument.project_id == project_id,
                    KnowledgeDocument.is_deleted.is_(False),
                )
            ).scalar_one()
            or 0
        )
        chunk_count = (
            self.session.execute(
                select(func.count(KnowledgeChunk.id)).where(KnowledgeChunk.project_id == project_id)
            ).scalar_one()
            or 0
        )
        indexed = (
            self.session.execute(
                select(func.count(KnowledgeDocument.id)).where(
                    KnowledgeDocument.project_id == project_id,
                    KnowledgeDocument.index_status == "indexed",
                )
            ).scalar_one()
            or 0
        )
        by_type = self.session.execute(
            select(KnowledgeDocument.source_type, func.count(KnowledgeDocument.id))
            .where(KnowledgeDocument.project_id == project_id)
            .group_by(KnowledgeDocument.source_type)
        ).all()

        return {
            "source_count": len(sources),
            "document_count": document_count,
            "chunk_count": chunk_count,
            "indexed_documents": indexed,
            "index_coverage": round(indexed / document_count, 4) if document_count else 0.0,
            "documents_by_source_type": {row[0]: row[1] for row in by_type},
            "vector_store": self.store.health(),
            "last_sync_at": max(
                (source.last_synced_at for source in sources if source.last_synced_at), default=None
            ),
        }

    def sync_collection_stats(self) -> None:
        """Refresh the `knowledge_collections` registry from live store counts."""
        for entry in self.store.list_collections():
            row = self.session.execute(
                select(KnowledgeCollection).where(KnowledgeCollection.name == entry["name"])
            ).scalar_one_or_none()
            if row is None:
                continue
            row.vector_count = entry.get("vector_count", 0)
            row.status = entry.get("status", "healthy")
            row.last_indexed_at = datetime.now(UTC)
        self.session.flush()
