"""Builds the synthetic demo project and its full history.

Deterministic: a fixed RNG seed means a reset reproduces the same demo exactly,
which is what makes the walkthroughs repeatable (spec §33).
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.providers.mock import stable_seed
from app.core.config import settings
from app.core.logging import get_logger
from app.core.storage import execution_dir as tenant_execution_dir
from app.execution.codegen import generate_playwright_script
from app.healing.config import ACCESSIBILITY_STRENGTH, healing_config
from app.healing.policy import ChangeType, evaluate_change
from app.models.agent import Agent
from app.models.defect import Defect, DefectAnalysis, DefectPrediction, RootCauseAnalysis
from app.models.governance import ApprovalRequest, AuditLog
from app.models.knowledge import KnowledgeSource
from app.models.llm import LLMUsage
from app.models.project import Environment, Integration, Project
from app.models.testing import (
    Execution,
    ExecutionArtifact,
    ExecutionTest,
    HealingRecord,
    RegressionAnalysis,
    Requirement,
    TestCase,
    TestDataSet,
    TestScenario,
    TestScript,
    TraceabilityLink,
)
from app.seed import content
from app.seed.catalog import seed_mcp_servers
from app.vectorstore.base import (
    COLLECTION_CODE_CONTEXT,
    COLLECTION_DEFECTS,
    COLLECTION_EXECUTION_HISTORY,
    COLLECTION_KNOWLEDGE,
    COLLECTION_REQUIREMENTS,
    COLLECTION_TEST_CASES,
)

logger = get_logger(__name__)

_FAILURE_MESSAGES: dict[str, str] = {
    "TIMEOUT_EXCEEDED": "Timeout 30000ms exceeded while waiting for element state 'visible'",
    "LOCATOR_NOT_FOUND": 'Locator resolved to 0 elements: page.get_by_test_id("payment-submit-btn")',
    "ASSERTION_FAILED": "AssertionError: expected confirmation to be visible, received HTTP 500",
    "CONNECTION_REFUSED": "net::ERR_CONNECTION_REFUSED - the service did not accept the connection",
    "DATA_PRECONDITION_FAILED": "Precondition failed: no such record for the account reference used",
    "A11Y_VIOLATION": "axe-core: serious violation (1.3.1 info-and-relationships) on the account list",
    "VALIDATION_FAILED": "AssertionError: expected field-level validation error, none was displayed",
    "SECURITY_VIOLATION": "AssertionError: sensitive value present in captured log output",
}

_FAILURE_CATEGORY_BY_SIGNATURE: dict[str, str] = {
    "TIMEOUT_EXCEEDED": "timing",
    "LOCATOR_NOT_FOUND": "locator_drift",
    "ASSERTION_FAILED": "application_defect",
    "CONNECTION_REFUSED": "environment",
    "DATA_PRECONDITION_FAILED": "test_data",
    "A11Y_VIOLATION": "application_defect",
    "VALIDATION_FAILED": "application_defect",
    "SECURITY_VIOLATION": "application_defect",
}


class DemoProjectBuilder:
    """Creates the ABC Retailer demo project end to end."""

    def __init__(self, session: Session) -> None:
        self.session = session
        self.rng = random.Random(settings.seed_random_state)
        self.now = datetime.now(UTC)

    # ------------------------------------------------------------------
    def build(self, users: dict[str, Any], agents: dict[str, Agent]) -> Project:
        project = self._project()
        environments = self._environments(project)
        self._integrations(project)
        seed_mcp_servers(self.session, project.id)

        requirements = self._requirements(project)
        scenarios = self._scenarios(project, requirements)
        cases = self._test_cases(project, scenarios)
        scripts = self._scripts(project, cases)
        self._test_data(project, environments)

        executions = self._executions(project, environments, cases, scripts)
        defects = self._defects(project, environments, executions, cases)
        self._rca_records(project, defects, executions)
        self._healing_records(project, scripts, executions)
        self._defect_predictions(project)
        self._regression_analysis(project, cases)
        self._traceability(project, requirements, scenarios, cases, scripts, defects)

        self._knowledge_sources(project, requirements, cases, defects, executions)
        self._llm_usage_history(project, agents)
        self._approvals_and_audit(project, users, agents)

        self.session.flush()
        logger.info(
            "seed_demo_project",
            project=project.key,
            requirements=len(requirements),
            scenarios=len(scenarios),
            test_cases=len(cases),
            scripts=len(scripts),
            executions=len(executions),
            defects=len(defects),
        )
        return project

    # ------------------------------------------------------------------
    def _project(self) -> Project:
        project = self.session.execute(
            select(Project).where(Project.key == content.PROJECT_KEY)
        ).scalar_one_or_none()
        if project is not None:
            return project

        project = Project(
            key=content.PROJECT_KEY,
            name=content.PROJECT_NAME,
            description=(
                "ABC Retailer digital channel covering authentication, account insight and money movement "
                "for retail customers across web and mobile web."
            ),
            status="active",
            business_domain="ABC Retailer",
            application_url="https://uat.abcr.example.test",
            jira_project_key="ABCR",
            confluence_space="ABCR",
            git_repository="https://git.example.com/abc-retailer/abcr-digital",
            onboarding_step=10,
            modules=content.MODULES,
            tags=["abc-retailer", "regulated", "critical"],
            llm_config={},
            qe_policies={
                "completeness_threshold": 80,
                "self_healing_confidence_threshold": 0.85,
                "max_flaky_rate": 0.02,
                "regression_risk_threshold": 0.35,
                "require_approval_for_defect_creation": True,
            },
            execution_config={
                "default_browser": "chromium",
                "default_parallelism": 4,
                "retry_failed_tests": 1,
                "capture_trace_on_failure": True,
            },
            cost_budget_usd=250.0,
        )
        self.session.add(project)
        self.session.flush()
        return project

    def _environments(self, project: Project) -> list[Environment]:
        rows: list[Environment] = []
        for entry in content.ENVIRONMENTS:
            existing = self.session.execute(
                select(Environment).where(
                    Environment.project_id == project.id, Environment.key == entry["key"]
                )
            ).scalar_one_or_none()
            if existing is not None:
                rows.append(existing)
                continue
            environment = Environment(
                project_id=project.id,
                key=entry["key"],
                name=entry["name"],
                description=entry["description"],
                base_url=entry["base_url"],
                api_base_url=entry["api_base_url"],
                database_alias=entry["database_alias"],
                is_production_like=entry["is_production_like"],
                allows_write_actions=entry["allows_write_actions"],
                health_status="healthy" if entry["key"] != "perf" else "degraded",
                # Credential references only; the values live in the secret store.
                secret_refs={
                    "test_username": f"secret://abcr/{entry['key']}/test-username",
                    "test_password": f"secret://abcr/{entry['key']}/test-password",
                },
                metadata_json={"region": "eu-west-1", "owner": "Digital Channels"},
            )
            self.session.add(environment)
            rows.append(environment)
        self.session.flush()
        return rows

    def _integrations(self, project: Project) -> None:
        definitions = [
            ("jira", "Jira Cloud", "https://jira.example.com", {"project_key": "ABCR", "issue_types": ["Story", "Bug"]}),
            ("confluence", "Confluence", "https://confluence.example.com", {"space": "ABCR"}),
            ("git", "Git Repository", "https://git.example.com", {"repository": "abc-retailer/abcr-digital", "default_branch": "main"}),
            ("database", "Test Database", None, {"dialect": "postgresql", "schema": "abcr"}),
            ("cicd", "Build Pipeline", "https://ci.example.com", {"pipeline": "abcr-regression"}),
        ]
        for kind, name, url, config in definitions:
            existing = self.session.execute(
                select(Integration).where(Integration.project_id == project.id, Integration.kind == kind)
            ).scalar_one_or_none()
            if existing is not None:
                continue
            self.session.add(
                Integration(
                    project_id=project.id,
                    kind=kind,
                    name=name,
                    description=f"{name} integration for {project.name}.",
                    connector_mode="demo",
                    status="connected",
                    base_url=url,
                    config=config,
                    secret_refs={"token": f"secret://abcr/{kind}/token"},
                    last_sync_at=self.now - timedelta(hours=self.rng.randint(1, 20)),
                )
            )
        self.session.flush()

    # ------------------------------------------------------------------
    def _requirements(self, project: Project) -> list[Requirement]:
        rows: list[Requirement] = []
        for entry in content.REQUIREMENTS:
            existing = self.session.execute(
                select(Requirement).where(
                    Requirement.project_id == project.id, Requirement.external_key == entry["key"]
                )
            ).scalar_one_or_none()
            if existing is not None:
                rows.append(existing)
                continue
            requirement = Requirement(
                project_id=project.id,
                external_key=entry["key"],
                title=entry["title"],
                description=entry["description"],
                module=entry["module"],
                source="jira",
                status=entry["status"],
                priority=entry["priority"],
                story_points=entry["points"],
                epic=entry["epic"],
                sprint=entry["sprint"],
                acceptance_criteria=entry["acceptance_criteria"],
                labels=entry["labels"],
                risk_score=entry["risk_score"],
                change_frequency=entry["change_frequency"],
            )
            self.session.add(requirement)
            rows.append(requirement)
        self.session.flush()
        return rows

    def _scenarios(self, project: Project, requirements: list[Requirement]) -> list[TestScenario]:
        """One positive scenario per acceptance criterion, plus negative and edge coverage."""
        rows: list[TestScenario] = []
        counter = 0

        for requirement in requirements:
            criteria = requirement.acceptance_criteria or []
            planned: list[tuple[str, str, str, str]] = []

            for criterion in criteria[:4]:
                condensed = criterion.split(", then")[0].replace("Given ", "").replace("when ", "")[:110]
                planned.append(("positive", f"Verify {condensed}", criterion, requirement.priority))

            if not criteria:
                planned.append(
                    (
                        "positive",
                        f"Verify {requirement.title[:100]} on the primary path",
                        requirement.description or requirement.title,
                        requirement.priority,
                    )
                )

            module_lower = requirement.module.lower()
            planned.append(
                (
                    "negative",
                    f"Reject invalid input in the {module_lower} flow",
                    "Invalid input must be rejected with a specific field-level message and no state change.",
                    "high" if requirement.priority in ("critical", "high") else "medium",
                )
            )
            if requirement.priority in ("critical", "high"):
                planned.append(
                    (
                        "edge",
                        f"Validate {module_lower} behaviour at boundary values",
                        "Exercise minimum, maximum and just-outside-range values for each bounded input.",
                        "medium",
                    )
                )

            for scenario_type, title, description, priority in planned:
                counter += 1
                scenario = TestScenario(
                    project_id=project.id,
                    requirement_id=requirement.id,
                    key=f"SCN-{counter:04d}",
                    title=title,
                    description=description,
                    scenario_type=scenario_type,
                    module=requirement.module,
                    priority=priority,
                    risk_level="high" if requirement.risk_score > 0.7 else "medium" if requirement.risk_score > 0.4 else "low",
                    generated_by_agent="test-scenario-generator",
                    confidence=round(0.82 + self.rng.random() * 0.14, 3),
                    tags=[requirement.module.lower().replace(" ", "-")],
                )
                self.session.add(scenario)
                rows.append(scenario)

        self.session.flush()
        return rows

    def _test_cases(self, project: Project, scenarios: list[TestScenario]) -> list[TestCase]:
        rows: list[TestCase] = []
        counter = 0

        for scenario in scenarios:
            counter += 1
            steps = [
                {"step": 1, "action": f"Navigate to the {scenario.module} screen.", "data": None},
                {"step": 2, "action": "Authenticate as the prepared test user.", "data": "test credentials"},
            ]
            if scenario.scenario_type == "positive":
                steps.append({"step": 3, "action": f"Complete the {scenario.module} flow with valid data.", "data": "valid data set"})
                expected = f"The {scenario.module} operation completes and the resulting record reflects the submitted values."
            elif scenario.scenario_type == "negative":
                steps.append({"step": 3, "action": f"Complete the {scenario.module} flow with invalid data.", "data": "invalid data set"})
                expected = "The operation is rejected, a specific validation message is displayed, and no state change is persisted."
            else:
                steps.append({"step": 3, "action": "Enter the boundary value under test.", "data": "boundary data set"})
                expected = "The system handles the boundary condition deterministically without error or data corruption."
            steps.append({"step": 4, "action": "Submit the request and wait for the response.", "data": None})
            steps.append({"step": 5, "action": "Verify the resulting state in the UI and backing data.", "data": None})

            test_type = "regression" if scenario.priority in ("critical", "high") else "functional"
            case = TestCase(
                project_id=project.id,
                scenario_id=scenario.id,
                requirement_id=scenario.requirement_id,
                key=f"TC-{counter:04d}",
                title=scenario.title.replace("Verify ", "Test ").replace("Reject ", "Test rejection of ")[:390],
                objective=scenario.description,
                preconditions=[
                    f"The {scenario.module} module is deployed and reachable in the target environment.",
                    "A test user with the required entitlements is available.",
                ],
                steps=steps,
                expected_result=expected,
                test_type=test_type,
                priority=scenario.priority,
                module=scenario.module,
                generated_by_agent="test-design",
                tags=scenario.tags,
            )
            self.session.add(case)
            rows.append(case)

        self.session.flush()
        return rows

    def _scripts(self, project: Project, cases: list[TestCase]) -> list[TestScript]:
        """Automate the higher-priority cases, leaving a realistic coverage gap."""
        rows: list[TestScript] = []
        automatable = [case for case in cases if case.priority in ("critical", "high")]
        # Automate ~80% of the critical/high cases so coverage metrics are not a flat 100%.
        target = automatable[: int(len(automatable) * 0.8)]

        for case in target:
            generated = generate_playwright_script(
                test_case_key=case.key,
                title=case.title,
                module=case.module,
                steps=case.steps or [],
                preconditions=case.preconditions or [],
                expected_result=case.expected_result or "",
                is_negative="rejection" in case.title.lower() or "invalid" in case.title.lower(),
                seed=project.id,
            )
            script = TestScript(
                project_id=project.id,
                test_case_id=case.id,
                name=generated.name,
                framework="playwright-python",
                language="python",
                file_path=generated.file_path,
                code=generated.code,
                page_objects=generated.to_page_objects(),
                locators=[locator.to_dict() for locator in generated.locators],
                generated_by_agent="auto-script-generator",
                quality_notes=generated.quality_notes,
            )
            self.session.add(script)
            rows.append(script)

            case.is_automated = True
            case.automation_status = "automated"

        self.session.flush()
        return rows

    def _test_data(self, project: Project, environments: list[Environment]) -> None:
        sit = next((env for env in environments if env.key == "sit"), None)
        definitions = [
            ("Login", ["user_id", "username", "password_hash", "account_status", "failed_attempts", "locked"], 18),
            ("Payments", ["payment_id", "account_id", "beneficiary_id", "amount", "currency", "status", "value_date"], 24),
            ("Beneficiaries", ["beneficiary_id", "account_id", "name", "iban_masked", "bank_code", "country", "verified"], 15),
            ("Accounts", ["account_id", "customer_id", "account_type", "balance", "currency", "status"], 20),
            ("Customer Profile", ["customer_id", "full_name", "email_masked", "phone_masked", "city", "kyc_status"], 12),
        ]

        for module, fields, count in definitions:
            existing = self.session.execute(
                select(TestDataSet).where(
                    TestDataSet.project_id == project.id, TestDataSet.module == module
                )
            ).scalar_one_or_none()
            if existing is not None:
                continue

            records: list[dict[str, Any]] = []
            for index in range(count):
                variant = "valid" if index % 4 < 2 else ("boundary" if index % 4 == 2 else "invalid")
                records.append({**self._record(module, fields, index, variant), "_variant": variant})

            contains_pii = any(
                any(hint in field for hint in ("name", "email", "phone", "iban")) for field in fields
            )
            # One deliberately stale set so the data management agent has a finding.
            age = timedelta(days=41) if module == "Customer Profile" else timedelta(days=self.rng.randint(1, 12))

            data_set = TestDataSet(
                project_id=project.id,
                name=f"{module} synthetic data set",
                description=f"Masked synthetic records supporting {module} test cases.",
                module=module,
                data_type="synthetic",
                environment_id=sit.id if sit else None,
                schema_definition={"fields": fields},
                records=records,
                record_count=len(records),
                contains_pii=contains_pii,
                masking_applied=True,
                refresh_policy="every_30_days",
                generated_by_agent="test-data-generator",
                tags=[module.lower().replace(" ", "-")],
                created_at=self.now - age,
                updated_at=self.now - age,
            )
            self.session.add(data_set)
        self.session.flush()

    def _record(self, module: str, fields: list[str], index: int, variant: str) -> dict[str, Any]:
        names = ["Alex Fernandes", "Priya Okafor", "Jordan Nakamura", "Mei Silva", "Samuel Kowalski"]
        record: dict[str, Any] = {}
        for field in fields:
            lowered = field.lower()
            if lowered.endswith("_id") or lowered == "id":
                record[field] = f"{field.replace('_id', '').upper()[:4]}-{1000 + index}"
            elif "password" in lowered:
                record[field] = "pbkdf2$masked$" + format(self.rng.getrandbits(48), "012x")
            elif "username" in lowered:
                record[field] = f"qa.user{index:03d}"
            elif "email" in lowered:
                record[field] = "[REDACTED_EMAIL]"
            elif "phone" in lowered:
                record[field] = "[REDACTED_PHONE]"
            elif "iban" in lowered:
                record[field] = f"GB29 **** **** **** {self.rng.randint(1000, 9999)}"
            elif "name" in lowered:
                record[field] = names[index % len(names)]
            elif "amount" in lowered or "balance" in lowered:
                if variant == "invalid":
                    record[field] = -round(self.rng.uniform(1, 400), 2)
                elif variant == "boundary":
                    record[field] = [0.0, 0.01, 999.99, 1000.00, 10000.00][index % 5]
                else:
                    record[field] = round(self.rng.uniform(25, 4200), 2)
            elif "currency" in lowered:
                record[field] = "XXX" if variant == "invalid" else ["EUR", "GBP", "USD"][index % 3]
            elif "status" in lowered:
                if "kyc" in lowered:
                    record[field] = ["VERIFIED", "PENDING", "REJECTED"][index % 3]
                else:
                    record[field] = "UNKNOWN" if variant == "invalid" else ["ACTIVE", "PENDING", "SUSPENDED", "CLOSED"][index % 4]
            elif "attempts" in lowered:
                record[field] = 5 if variant == "boundary" else self.rng.randint(0, 3)
            elif "locked" in lowered or "verified" in lowered:
                record[field] = index % 5 == 0
            elif "country" in lowered:
                record[field] = ["PT", "SG", "GB", "IN"][index % 4]
            elif "city" in lowered:
                record[field] = ["Lisbon", "Singapore", "Manchester", "Pune"][index % 4]
            elif "code" in lowered:
                record[field] = f"BNK{self.rng.randint(100, 999)}"
            elif "date" in lowered:
                record[field] = (self.now + timedelta(days=self.rng.randint(-60, 30))).date().isoformat()
            elif "type" in lowered:
                record[field] = ["CURRENT", "SAVINGS", "CREDIT"][index % 3]
            else:
                record[field] = f"{field}-{index}"
        return record

    # ------------------------------------------------------------------
    def _executions(
        self,
        project: Project,
        environments: list[Environment],
        cases: list[TestCase],
        scripts: list[TestScript],
    ) -> list[Execution]:
        """Generate 8 weeks of execution history with a believable quality trend."""
        automated = [case for case in cases if case.is_automated]
        if not automated:
            return []

        script_by_case = {script.test_case_id: script for script in scripts}
        sit = next((env for env in environments if env.key == "sit"), environments[0])
        uat = next((env for env in environments if env.key == "uat"), environments[0])

        executions: list[Execution] = []
        total_runs = 56

        for run_index in range(total_runs):
            days_ago = (total_runs - run_index) * 1.0
            started = self.now - timedelta(days=days_ago, hours=self.rng.randint(0, 8))

            # Quality improves over time, with a deliberate regression around
            # run 38 so the trend charts and the observability agent have a story.
            progress = run_index / total_runs
            base_failure_rate = 0.22 - (progress * 0.13)
            if 36 <= run_index <= 41:
                base_failure_rate += 0.14

            suite_type = "smoke" if run_index % 4 == 1 else "regression"
            environment = uat if run_index % 7 == 0 else sit
            pool = (
                [case for case in automated if case.priority == "critical"]
                if suite_type == "smoke"
                else automated
            )
            selected = pool if suite_type == "smoke" else pool[: int(len(pool) * 0.85)]
            if not selected:
                continue

            execution = Execution(
                project_id=project.id,
                environment_id=environment.id,
                name=f"{suite_type.title()} suite #{run_index + 1}",
                execution_number=run_index + 1,
                suite_type=suite_type,
                status="passed",
                browser=["chromium", "chromium", "firefox", "webkit"][run_index % 4],
                headless=True,
                parallelism=4,
                trigger="scheduled" if run_index % 3 else "manual",
                mode="simulated",
                total_tests=len(selected),
                started_at=started,
                triggered_by="ci-pipeline" if run_index % 3 else "tom.becker@example.com",
                created_at=started,
                updated_at=started,
            )
            self.session.add(execution)
            self.session.flush()

            passed = failed = skipped = flaky = healed = 0
            categories: dict[str, int] = {}
            duration_total = 0

            for case in selected:
                roll = self.rng.random()
                module_risk = 1.25 if case.module in ("Payments", "Beneficiaries") else 1.0
                failure_rate = min(0.6, base_failure_rate * module_risk)
                duration = self.rng.randint(1900, 9200)

                if roll < failure_rate * 0.72:
                    result = "failed"
                    signature = self._signature_for(case.module, run_index)
                    failed += 1
                    duration = self.rng.randint(4200, 31000)
                elif roll < failure_rate:
                    result = "flaky"
                    signature = "TIMEOUT_EXCEEDED"
                    flaky += 1
                elif roll > 0.985:
                    result = "skipped"
                    signature = None
                    skipped += 1
                else:
                    result = "passed"
                    signature = None
                    passed += 1

                category = _FAILURE_CATEGORY_BY_SIGNATURE.get(signature or "", None)
                if category:
                    categories[category] = categories.get(category, 0) + 1

                was_healed = result == "failed" and signature == "LOCATOR_NOT_FOUND" and self.rng.random() < 0.4
                if was_healed:
                    healed += 1

                test = ExecutionTest(
                    execution_id=execution.id,
                    test_case_id=case.id,
                    test_script_id=script_by_case[case.id].id if case.id in script_by_case else None,
                    name=case.title,
                    module=case.module,
                    result=result,
                    duration_ms=duration,
                    retry_count=1 if result == "flaky" else 0,
                    failure_message=_FAILURE_MESSAGES.get(signature) if signature else None,
                    failure_category=category,
                    failure_signature=signature,
                    stack_trace=(
                        f'  File "tests/{case.module.lower().replace(" ", "_")}/{case.key.lower()}.py", line 42\n'
                        f"    {_FAILURE_MESSAGES.get(signature, '')}"
                        if signature
                        else None
                    ),
                    console_logs=(
                        [{"level": "error", "message": _FAILURE_MESSAGES.get(signature, "")[:160]}]
                        if signature
                        else []
                    ),
                    healed=was_healed,
                    started_at=started,
                    created_at=started,
                    updated_at=started,
                )
                self.session.add(test)
                duration_total += duration

                case.execution_count += 1
                case.last_result = result
                case.last_executed_at = started
                if result in ("failed", "flaky"):
                    case.failure_count += 1
                case.avg_duration_ms = int(((case.avg_duration_ms or duration) + duration) / 2)

            self.session.flush()

            # Artifacts for the most recent runs only, mirroring a real retention policy.
            if run_index >= total_runs - 6 and failed:
                failing = list(
                    self.session.execute(
                        select(ExecutionTest).where(
                            ExecutionTest.execution_id == execution.id,
                            ExecutionTest.result == "failed",
                        )
                    )
                    .scalars()
                    .all()
                )
                for test in failing[:4]:
                    for artifact_type, extension, content_type in (
                        ("screenshot", "png", "image/png"),
                        ("trace", "zip", "application/zip"),
                    ):
                        self.session.add(
                            ExecutionArtifact(
                                execution_id=execution.id,
                                execution_test_id=test.id,
                                artifact_type=artifact_type,
                                name=f"{test.name[:36].replace(' ', '_').lower()}-{artifact_type}.{extension}",
                                storage_path=str(
                                    tenant_execution_dir(project.id, execution.id)
                                    / f"{test.id}-{artifact_type}.{extension}"
                                ),
                                content_type=content_type,
                                size_bytes=self.rng.randint(48_000, 900_000),
                                artifact_metadata={"captured_at": started.isoformat(), "materialized": False},
                            )
                        )

            execution.passed = passed
            execution.failed = failed
            execution.skipped = skipped
            execution.flaky = flaky
            execution.healed = healed
            execution.pass_rate = round((passed + flaky) / len(selected), 4)
            execution.failure_categories = categories
            execution.duration_ms = int(duration_total / max(1, execution.parallelism))
            execution.finished_at = started + timedelta(milliseconds=execution.duration_ms)
            execution.status = "failed" if failed else "passed"
            execution.defects_created = 1 if failed >= 3 else 0
            executions.append(execution)

        # Flakiness is derived from observed history rather than assigned.
        for case in automated:
            if case.execution_count:
                case.flakiness_score = round(min(1.0, case.failure_count / case.execution_count), 4)

        self.session.flush()
        return executions

    def _signature_for(self, module: str, run_index: int) -> str:
        """Bias failure signatures by module so RCA has genuine patterns to find."""
        if module == "Login":
            pool = ["TIMEOUT_EXCEEDED", "TIMEOUT_EXCEEDED", "ASSERTION_FAILED", "CONNECTION_REFUSED"]
        elif module == "Payments":
            pool = ["ASSERTION_FAILED", "ASSERTION_FAILED", "LOCATOR_NOT_FOUND", "DATA_PRECONDITION_FAILED"]
        elif module == "Beneficiaries":
            pool = ["ASSERTION_FAILED", "VALIDATION_FAILED", "LOCATOR_NOT_FOUND"]
        elif module == "Accounts":
            pool = ["ASSERTION_FAILED", "A11Y_VIOLATION", "TIMEOUT_EXCEEDED"]
        else:
            pool = ["ASSERTION_FAILED", "TIMEOUT_EXCEEDED", "LOCATOR_NOT_FOUND"]
        # The mid-history regression window is dominated by locator drift.
        if 36 <= run_index <= 41:
            pool = ["LOCATOR_NOT_FOUND"] * 3 + pool
        return pool[self.rng.randrange(len(pool))]

    # ------------------------------------------------------------------
    def _defects(
        self,
        project: Project,
        environments: list[Environment],
        executions: list[Execution],
        cases: list[TestCase],
    ) -> list[Defect]:
        rows: list[Defect] = []
        sit = next((env for env in environments if env.key == "sit"), None)
        recent_executions = executions[-12:] if executions else []

        for index, entry in enumerate(content.DEFECTS):
            existing = self.session.execute(
                select(Defect).where(
                    Defect.project_id == project.id, Defect.external_key == entry["key"]
                )
            ).scalar_one_or_none()
            if existing is not None:
                rows.append(existing)
                continue

            created = self.now - timedelta(days=entry["age_days"])
            module_cases = [case for case in cases if case.module == entry["module"]]
            linked_case = module_cases[index % len(module_cases)] if module_cases else None
            linked_execution = (
                recent_executions[index % len(recent_executions)] if recent_executions else None
            )

            defect = Defect(
                project_id=project.id,
                external_key=entry["key"],
                title=entry["title"],
                description=entry["description"],
                module=entry["module"],
                status=entry["status"],
                severity=entry["severity"],
                priority=entry["priority"],
                environment_id=sit.id if sit else None,
                execution_id=linked_execution.id if linked_execution else None,
                test_case_id=linked_case.id if linked_case else None,
                requirement_id=linked_case.requirement_id if linked_case else None,
                reported_by="tom.becker@example.com" if index % 3 else "automation",
                assigned_to=["dev.team", "payments.team", "identity.team"][index % 3],
                source="automation" if index % 2 else "manual",
                created_by_agent="jira-defect-assistant" if index % 5 == 0 else None,
                is_ai_suggested=index % 5 == 0,
                ai_confidence=round(0.78 + self.rng.random() * 0.18, 3) if index % 5 == 0 else None,
                cluster_key=entry["cluster"],
                failure_signature=entry["signature"],
                steps_to_reproduce=entry["steps"],
                evidence=[
                    {"type": "execution", "detail": f"Observed in {linked_execution.name}." if linked_execution else "Observed during manual testing."},
                    {"type": "signature", "detail": f"Failure signature: {entry['signature']}."},
                ],
                labels=[entry["module"].lower().replace(" ", "-"), entry["severity"]],
                resolved_at=created + timedelta(days=self.rng.randint(2, 9)) if entry["status"] == "resolved" else None,
                resolution_notes=entry.get("resolution"),
                jira_sync_state="synced_demo",
                created_at=created,
                updated_at=created + timedelta(days=1),
            )
            self.session.add(defect)
            self.session.flush()
            rows.append(defect)

            if index % 3 == 0:
                self.session.add(
                    DefectAnalysis(
                        defect_id=defect.id,
                        agent_key="jira-defect-assistant",
                        analysis_type="triage",
                        summary=f"Triaged as {entry['severity']} severity based on customer impact and affected journey.",
                        recommended_severity=entry["severity"],
                        recommended_priority=entry["priority"],
                        confidence=round(0.8 + self.rng.random() * 0.15, 3),
                        findings=[
                            {"field": "severity", "value": entry["severity"], "justification": "Impact on a critical customer journey."},
                            {"field": "cluster", "value": entry["cluster"], "justification": "Groups with related defects sharing this signature."},
                        ],
                        recommendations=[{"priority": "high", "action": "Assign to the owning team for the affected module."}],
                        accepted=True,
                        reviewed_by="priya.raman@example.com",
                    )
                )

        self.session.flush()
        return rows

    def _rca_records(
        self, project: Project, defects: list[Defect], executions: list[Execution]
    ) -> None:
        """RCA for the most significant defects, with evidence and confidence."""
        rca_specs = [
            ("DEF-0001", "Identity service connection pool exhaustion under peak load", "infrastructure", 0.91,
             "Increase the connection pool, add a directory lookup timeout and alert at 80 percent pool saturation."),
            ("DEF-0003", "Idempotency key applied after persistence rather than before", "application", 0.86,
             "Move the idempotency check ahead of the persistence step and key it on beneficiary, amount and reference."),
            ("DEF-0004", "Client-side navigation state permits re-submission without the confirmation gate", "application", 0.88,
             "Enforce the confirmation-of-payee acknowledgement server side rather than in client navigation state."),
            ("DEF-0005", "Null balance coerced to zero in the presentation layer", "application", 0.94,
             "Render an explicit unavailable state for a null balance; never coerce null to zero."),
            ("DEF-0006", "Filter predicate composed with OR where AND was intended", "application", 0.89,
             "Compose filter predicates with AND and add a test covering combined filters."),
            ("DEF-0008", "Contact record written before the verification step completes", "application", 0.9,
             "Hold the pending change in a staging record and commit only after successful verification."),
            ("DEF-0011", "Cooling-off cap evaluated at scheduling time rather than execution time", "application", 0.87,
             "Re-evaluate the beneficiary cooling-off window at payment execution."),
            ("DEF-0012", "Missing composite index on account and booking date", "infrastructure", 0.83,
             "Add a composite index on (account_id, booked_at) and re-baseline the query plan."),
            ("DEF-0013", "Session revocation not propagated to the token validation layer", "application", 0.92,
             "Add the token to the revocation list on sign-out and check it during validation."),
            ("DEF-0018", "Non-deterministic ordering for transactions sharing a timestamp", "application", 0.85,
             "Add a deterministic secondary sort key on transaction id."),
            ("DEF-0021", "UI refactor renamed a test id without a contract test", "automation", 0.95,
             "Adopt role-based locators and add a UI contract test asserting the presence of required test ids."),
            ("DEF-0002", "Daily limit keyed on calendar day rather than a rolling window", "application", 0.93,
             "Compute the limit over a rolling 24 hour window keyed on submission timestamp."),
        ]

        defect_by_key = {defect.external_key: defect for defect in defects}

        for key, cause, category, confidence, action in rca_specs:
            defect = defect_by_key.get(key)
            if defect is None:
                continue
            existing = self.session.execute(
                select(RootCauseAnalysis).where(RootCauseAnalysis.defect_id == defect.id)
            ).scalar_one_or_none()
            if existing is not None:
                continue

            occurrences = self.rng.randint(4, 18)
            # RCA lands hours after the defect, not "now" -- otherwise the
            # mean-time-to-diagnose KPI reads as weeks.
            diagnosed_at = defect.created_at + timedelta(
                hours=self.rng.randint(2, 30), minutes=self.rng.randint(0, 59)
            )
            self.session.add(
                RootCauseAnalysis(
                    project_id=project.id,
                    defect_id=defect.id,
                    execution_id=defect.execution_id,
                    title=f"RCA: {cause}",
                    probable_root_cause=cause,
                    category=category,
                    confidence=confidence,
                    evidence=[
                        {"type": "failure_count", "detail": f"{occurrences} similar failures with signature {defect.failure_signature}."},
                        {"type": "module_concentration", "detail": f"All occurrences confined to the {defect.module} module."},
                        {"type": "historical_match", "detail": f"Signature seen in {self.rng.randint(2, 6)} prior executions."},
                    ],
                    contributing_factors=[
                        {"signal": "Failure signature matched a known cause pattern", "weight": 0.18},
                        {"signal": f"{occurrences} similar historical failure(s) retrieved", "weight": 0.16},
                    ],
                    affected_tests=[{"module": defect.module, "count": occurrences}],
                    historical_similarity=[
                        {"score": round(0.72 + self.rng.random() * 0.2, 3), "excerpt": f"{defect.failure_signature} in {defect.module}"}
                    ],
                    recommended_action=action,
                    status="accepted" if defect.status == "resolved" else "proposed",
                    reviewed_by="priya.raman@example.com" if defect.status == "resolved" else None,
                    reviewed_at=diagnosed_at + timedelta(hours=self.rng.randint(1, 12))
                    if defect.status == "resolved"
                    else None,
                    agent_key="automated-defect-rca",
                    created_at=diagnosed_at,
                    updated_at=diagnosed_at,
                )
            )
        self.session.flush()

    def _healing_records(
        self, project: Project, scripts: list[TestScript], executions: list[Execution]
    ) -> None:
        """Healing history spanning approved, applied and human-review outcomes."""
        if not scripts:
            return

        failing_tests = list(
            self.session.execute(
                select(ExecutionTest)
                .where(ExecutionTest.failure_signature == "LOCATOR_NOT_FOUND")
                .limit(14)
            )
            .scalars()
            .all()
        )

        strategies = [
            ("test_id", 'page.get_by_test_id("payment-submit")', 0.96, "Dedicated test id is stable across styling and copy changes."),
            ("role", 'page.get_by_role("button", name="Continue")', 0.91, "Accessible role and name survive DOM restructuring."),
            ("label", 'page.get_by_label("Payment amount")', 0.88, "Associated label text is stable and accessibility-friendly."),
            ("text", 'page.get_by_text("Continue", exact=False)', 0.74, "Visible text is readable but breaks on copy changes."),
        ]

        config = healing_config()
        for index, test in enumerate(failing_tests):
            strategy, locator, confidence, rationale = strategies[index % len(strategies)]
            gate = evaluate_change(
                change_type=ChangeType.LOCATOR, confidence=confidence, config=config
            )
            # History the platform could actually have produced: most validated
            # heals held, one in seven did not and was rolled back with the script
            # untouched, and the low-confidence ones are still waiting on a human.
            if not gate.allowed:
                status = "blocked"
            elif gate.requires_approval:
                status = "proposed"
            elif index % 7 == 3:
                status = "rolled_back"
            else:
                status = "applied"

            validated = status == "applied"
            rolled_back = status == "rolled_back"
            decided = status in {"applied", "rolled_back"}

            self.session.add(
                HealingRecord(
                    project_id=project.id,
                    test_script_id=test.test_script_id,
                    execution_test_id=test.id,
                    status=status,
                    failure_class="locator_drift",
                    change_type=ChangeType.LOCATOR,
                    original_locator='page.get_by_test_id("payment-submit-btn")',
                    proposed_locator=locator,
                    locator_strategy=strategy,
                    candidates=[
                        {"strategy": item[0], "locator": item[1], "confidence": item[2]}
                        for item in strategies
                        if item[0] != strategy
                    ][:3],
                    reason=rationale,
                    confidence=confidence,
                    confidence_breakdown=config.breakdown(
                        {
                            "strategy_robustness": confidence,
                            "accessibility_match": ACCESSIBILITY_STRENGTH.get(strategy, 0.5),
                        }
                    ),
                    evidence=[
                        {"type": "failure_message", "detail": test.failure_message or ""},
                        {"type": "locator_ranking", "detail": f"{strategy} ranked highest at {confidence}."},
                    ],
                    policy_decision={"threshold": config.auto_apply_threshold, **gate.to_dict()},
                    patch={
                        "change_type": ChangeType.LOCATOR,
                        "from": 'page.get_by_test_id("payment-submit-btn")',
                        "to": locator,
                        "strategy": strategy,
                    }
                    if decided
                    else {},
                    result_before="failed",
                    result_after=("passed" if validated else "failed" if rolled_back else None),
                    validation_status=("passed" if validated else "failed" if rolled_back else "not_started"),
                    validation_mode="simulated" if decided else None,
                    validation_evidence=[
                        {
                            "type": "rerun",
                            "detail": (
                                f"Re-ran '{test.name}' with the proposed locator applied as a "
                                f"temporary patch. Result: {'passed' if validated else 'failed'}."
                            ),
                            "mode": "simulated",
                        }
                    ]
                    if decided
                    else [],
                    attempt_count=1 if decided else 0,
                    validated_at=self.now - timedelta(days=self.rng.randint(1, 12)) if validated else None,
                    rolled_back_at=self.now - timedelta(days=self.rng.randint(1, 12)) if rolled_back else None,
                    approver="priya.raman@example.com" if decided else None,
                    approved_at=self.now - timedelta(days=self.rng.randint(1, 14)) if decided else None,
                    script_version_before=1,
                    script_version_after=2 if validated else None,
                )
            )

        for script in scripts[:6]:
            script.healing_count = self.rng.randint(1, 3)
        self.session.flush()

    def _defect_predictions(self, project: Project) -> None:
        predictions = [
            ("Payments", 0.78, "high", "critical"),
            ("Beneficiaries", 0.71, "high", "critical"),
            ("Login", 0.44, "medium", "major"),
            ("Transaction History", 0.39, "medium", "major"),
            ("Accounts", 0.28, "low", "minor"),
            ("Customer Profile", 0.24, "low", "minor"),
        ]
        for module, probability, band, severity in predictions:
            existing = self.session.execute(
                select(DefectPrediction).where(
                    DefectPrediction.project_id == project.id, DefectPrediction.target_ref == module
                )
            ).scalar_one_or_none()
            if existing is not None:
                continue
            self.session.add(
                DefectPrediction(
                    project_id=project.id,
                    target_type="module",
                    target_ref=module,
                    module=module,
                    probability=probability,
                    predicted_severity=severity,
                    risk_band=band,
                    drivers=[
                        {"driver": "Recent defect density", "weight": round(probability * 0.35, 3), "detail": f"Defects raised against {module} in the last 90 days."},
                        {"driver": "Execution failure rate", "weight": round(probability * 0.28, 3), "detail": f"Failed and flaky results in {module}."},
                        {"driver": "Requirement churn", "weight": round(probability * 0.22, 3), "detail": f"Change frequency across {module} requirements."},
                    ],
                    recommended_actions=[
                        f"Prioritise {module} in the next regression cycle."
                        if band == "high"
                        else f"Maintain current {module} coverage and monitor trends."
                    ],
                    horizon_days=14,
                )
            )
        self.session.flush()

    def _regression_analysis(self, project: Project, cases: list[TestCase]) -> None:
        existing = self.session.execute(
            select(RegressionAnalysis).where(RegressionAnalysis.project_id == project.id)
        ).scalar_one_or_none()
        if existing is not None:
            return

        automated = [case for case in cases if case.is_automated]
        changed = ["Payments", "Beneficiaries"]
        selected: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        baseline = optimized = 0

        for case in automated:
            duration = case.avg_duration_ms or 4200
            baseline += duration
            failure_rate = (case.failure_count / case.execution_count) if case.execution_count else 0.0
            in_impact = case.module in changed
            risk = round(
                min(
                    1.0,
                    (0.45 if in_impact else 0.0)
                    + failure_rate * 0.3
                    + case.flakiness_score * 0.1
                    + {"critical": 1.0, "high": 0.8, "medium": 0.5, "low": 0.25}.get(case.priority, 0.5) * 0.25,
                ),
                3,
            )
            entry = {
                "test_case_id": case.id,
                "key": case.key,
                "title": case.title,
                "module": case.module,
                "priority": case.priority,
                "risk_score": risk,
                "historical_failure_rate": round(failure_rate, 3),
                "duration_ms": duration,
                "in_change_impact": in_impact,
            }
            if risk >= 0.35:
                entry["reason"] = "Selected: covers a changed module or carries elevated historical risk."
                selected.append(entry)
                optimized += duration
            else:
                entry["reason"] = "Deferred to nightly full regression; risk below threshold."
                skipped.append(entry)

        reduction = round((1 - (optimized / baseline)) * 100, 1) if baseline else 0.0
        self.session.add(
            RegressionAnalysis(
                project_id=project.id,
                name="Payments release regression optimisation",
                changed_modules=changed,
                changed_requirements=["PAY-201", "PAY-202", "BEN-401"],
                selected_tests=selected[:100],
                skipped_tests=skipped[:100],
                risk_score=round(sum(item["risk_score"] for item in selected) / max(1, len(selected)), 3),
                baseline_duration_ms=baseline,
                optimized_duration_ms=optimized,
                reduction_percent=reduction,
                rationale=(
                    "Tests were scored on change impact, historical failure rate, flakiness and business "
                    "priority. Those at or above a 0.35 risk threshold were selected."
                ),
            )
        )
        self.session.flush()

    def _traceability(
        self,
        project: Project,
        requirements: list[Requirement],
        scenarios: list[TestScenario],
        cases: list[TestCase],
        scripts: list[TestScript],
        defects: list[Defect],
    ) -> None:
        links: list[TraceabilityLink] = []
        for scenario in scenarios:
            if scenario.requirement_id:
                links.append(
                    TraceabilityLink(
                        project_id=project.id,
                        source_type="requirement",
                        source_id=scenario.requirement_id,
                        target_type="scenario",
                        target_id=scenario.id,
                        link_type="covers",
                        created_by_agent="test-scenario-generator",
                    )
                )
        for case in cases:
            if case.scenario_id:
                links.append(
                    TraceabilityLink(
                        project_id=project.id,
                        source_type="scenario",
                        source_id=case.scenario_id,
                        target_type="test_case",
                        target_id=case.id,
                        link_type="covers",
                        created_by_agent="test-design",
                    )
                )
        for script in scripts:
            if script.test_case_id:
                links.append(
                    TraceabilityLink(
                        project_id=project.id,
                        source_type="test_case",
                        source_id=script.test_case_id,
                        target_type="test_script",
                        target_id=script.id,
                        link_type="automated_by",
                        created_by_agent="auto-script-generator",
                    )
                )
        for defect in defects:
            if defect.test_case_id:
                links.append(
                    TraceabilityLink(
                        project_id=project.id,
                        source_type="test_case",
                        source_id=defect.test_case_id,
                        target_type="defect",
                        target_id=defect.id,
                        link_type="revealed",
                    )
                )
        self.session.add_all(links)
        self.session.flush()

    # ------------------------------------------------------------------
    def _knowledge_sources(
        self,
        project: Project,
        requirements: list[Requirement],
        cases: list[TestCase],
        defects: list[Defect],
        executions: list[Execution],
    ) -> None:
        """Register knowledge sources. Indexing happens in the runner."""
        definitions = [
            ("jira-stories", "Jira Stories", "jira", COLLECTION_REQUIREMENTS, "Requirements and acceptance criteria synchronised from Jira."),
            ("confluence-space", "Confluence Space ABCR", "confluence", COLLECTION_KNOWLEDGE, "Architecture, SOPs, business rules and standards."),
            ("git-repository", "Git Repository", "git", COLLECTION_CODE_CONTEXT, "Application and automation source context."),
            ("test-repository", "Test Repository", "test_case", COLLECTION_TEST_CASES, "Test scenarios and cases for reuse and duplicate detection."),
            ("defect-history", "Defect History", "defect", COLLECTION_DEFECTS, "Historical defects for similarity and triage."),
            ("execution-history", "Execution History", "execution", COLLECTION_EXECUTION_HISTORY, "Failure signatures and outcomes used as RCA evidence."),
        ]

        for key, name, source_type, collection, description in definitions:
            existing = self.session.execute(
                select(KnowledgeSource).where(
                    KnowledgeSource.project_id == project.id, KnowledgeSource.key == key
                )
            ).scalar_one_or_none()
            if existing is not None:
                continue
            self.session.add(
                KnowledgeSource(
                    project_id=project.id,
                    key=key,
                    name=name,
                    description=description,
                    source_type=source_type,
                    connector_mode="demo",
                    location=f"demo://{project.key}/{key}",
                    is_enabled=True,
                    sync_status="pending",
                    sync_schedule="on_change",
                    collection_name=collection,
                    access_scope="project",
                )
            )
        self.session.flush()

    def _llm_usage_history(self, project: Project, agents: dict[str, Agent]) -> None:
        """Cost history so the AI governance dashboards have real data."""
        existing = self.session.execute(
            select(LLMUsage).where(LLMUsage.project_id == project.id).limit(1)
        ).scalar_one_or_none()
        if existing is not None:
            return

        model_by_tier = {
            "low": ("qe-demo-light", 0.00015, 0.0006),
            "medium": ("qe-demo-standard", 0.0025, 0.01),
            "high": ("qe-demo-reasoning", 0.005, 0.015),
        }
        agent_list = list(agents.values())

        for day in range(45):
            timestamp = self.now - timedelta(days=45 - day)
            # Weekday-weighted volume so the cost chart is not flat.
            calls = self.rng.randint(4, 14) if timestamp.weekday() < 5 else self.rng.randint(0, 4)
            for _ in range(calls):
                agent = agent_list[self.rng.randrange(len(agent_list))]
                model, input_cost, output_cost = model_by_tier[agent.cost_tier]
                prompt_tokens = self.rng.randint(700, 5200)
                completion_tokens = self.rng.randint(180, 2100)
                self.session.add(
                    LLMUsage(
                        project_id=project.id,
                        agent_id=agent.id,
                        agent_key=agent.key,
                        provider=settings.default_llm_provider,
                        model=model,
                        deployment=None,
                        capability=agent.capability,
                        operation="chat",
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        total_tokens=prompt_tokens + completion_tokens,
                        estimated_cost_usd=round(
                            (prompt_tokens / 1000) * input_cost + (completion_tokens / 1000) * output_cost, 6
                        ),
                        latency_ms=self.rng.randint(280, 3400),
                        success=self.rng.random() > 0.02,
                        created_at=timestamp,
                        updated_at=timestamp,
                    )
                )
        self.session.flush()

    def _approvals_and_audit(
        self, project: Project, users: dict[str, Any], agents: dict[str, Agent]
    ) -> None:
        existing = self.session.execute(
            select(ApprovalRequest).where(ApprovalRequest.project_id == project.id).limit(1)
        ).scalar_one_or_none()
        if existing is None:
            approvals = [
                ("Approve defect creation for payment duplicate", "Creating a defect writes to the tracker, a system of record.", "high", "pending"),
                ("Approve locator replacement for payment submit", "Self-healing proposal at 74% confidence, below the 85% gate.", "medium", "pending"),
                ("Approve international payment agent execution", "High-risk agent operating on a regulated payment journey.", "high", "approved"),
                ("Approve pipeline trigger for regression suite", "Triggering CI consumes shared infrastructure.", "medium", "approved"),
                ("Approve Jira story status update", "Agent proposes moving PAY-202 to In Test.", "medium", "rejected"),
            ]
            for index, (title, reason, risk, status) in enumerate(approvals):
                created = self.now - timedelta(days=index * 2, hours=3)
                self.session.add(
                    ApprovalRequest(
                        project_id=project.id,
                        subject_type="agent" if index % 2 else "flow_node",
                        subject_ref=f"node-{index + 1}",
                        title=title,
                        reason=reason,
                        risk_level=risk,
                        status=status,
                        required_role="qe_lead",
                        requested_by="system",
                        decided_by="priya.raman@example.com" if status != "pending" else None,
                        decided_at=created + timedelta(hours=4) if status != "pending" else None,
                        decision_notes=(
                            "Approved after reviewing the evidence."
                            if status == "approved"
                            else "Rejected: the story is not ready to move." if status == "rejected" else None
                        ),
                        expires_at=created + timedelta(days=2),
                        context={"module": ["Payments", "Payments", "Payments", "Login", "Payments"][index]},
                        created_at=created,
                        updated_at=created,
                    )
                )

        audit_existing = self.session.execute(
            select(AuditLog).where(AuditLog.project_id == project.id).limit(1)
        ).scalar_one_or_none()
        if audit_existing is not None:
            self.session.flush()
            return

        actors = [
            ("alex.morgan@example.com", "user"),
            ("priya.raman@example.com", "user"),
            ("tom.becker@example.com", "user"),
            ("system", "system"),
        ]
        actions = [
            ("agent.execute", "agent", "success", "info"),
            ("flow.run", "agent_run", "success", "info"),
            ("execution.start", "execution", "success", "info"),
            ("defect.create", "defect", "success", "warning"),
            ("approval.decide", "approval_request", "success", "info"),
            ("policy.enforce", "governance_policy", "blocked", "warning"),
            ("knowledge.sync", "knowledge_source", "success", "info"),
            ("agent.publish", "agent", "success", "info"),
        ]
        agent_list = list(agents.values())

        for index in range(90):
            actor, actor_type = actors[index % len(actors)]
            action, entity_type, outcome, severity = actions[index % len(actions)]
            agent = agent_list[index % len(agent_list)]
            timestamp = self.now - timedelta(days=index // 3, hours=(index % 12) + 1)
            self.session.add(
                AuditLog(
                    project_id=project.id,
                    actor=actor,
                    actor_type=actor_type,
                    action=action,
                    entity_type=entity_type,
                    entity_id=agent.id if entity_type == "agent" else None,
                    entity_label=agent.name if entity_type == "agent" else f"{entity_type} record",
                    reason=f"{action.replace('.', ' ')} performed as part of the quality workflow.",
                    outcome=outcome,
                    severity=severity,
                    input_summary={"module": content.MODULES[index % len(content.MODULES)]},
                    output_summary={"result": outcome},
                    model_used=f"{settings.default_llm_provider}:qe-demo-standard" if entity_type == "agent" else None,
                    confidence=round(0.75 + self.rng.random() * 0.22, 3) if entity_type == "agent" else None,
                    policy_result={"effect": "deny" if outcome == "blocked" else "allow"},
                    correlation_id=f"seed-{stable_seed(project.id, index) % 10**8:08d}",
                    created_at=timestamp,
                    updated_at=timestamp,
                )
            )
        self.session.flush()
