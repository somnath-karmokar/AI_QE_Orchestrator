"""Sixty days of operating history for the demo flows.

Every flow workspace -- dashboard, observability, governance and report -- is
computed from real rows, so a fresh demo needs rows to compute from: runs that
walk each flow's actual graph, with steps, LLM usage, approvals, run events and
audit entries that agree with one another.

The history is deterministic (seeded RNG), and the most recent 30 days are a
little healthier than the 30 before, the way a team's flows improve once they
are watched. All approvals in the history are decided, so the demo's pending
approval queue is unchanged.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest, AuditLog
from app.models.llm import LLMUsage
from app.models.project import Project
from app.models.run import AgentMessage, AgentRun, AgentRunStep

logger = get_logger(__name__)

MODELS = {
    "low": ("qe-demo-light", 0.00015, 0.0006),
    "medium": ("qe-demo-standard", 0.0025, 0.01),
    "high": ("qe-demo-reasoning", 0.005, 0.015),
}

# The structured outputs each agent publishes to the shared run context, as
# (output field -> template placeholder). Decisions read these, so they must agree
# with the path the run took.
STEP_OUTPUTS: dict[str, dict[str, str]] = {
    "user-story-completeness": {"completeness_score": "score"},
    "test-knowledge": {"rules_retrieved": "n"},
    "test-scenario-generator": {"scenario_count": "n"},
    "test-design": {"test_case_count": "n"},
    "test-data-generator": {"record_count": "n"},
    "auto-script-generator": {"script_count": "n"},
    "automation-failure-analysis": {"failures_classified": "n", "product_defects": "defects"},
    "self-healing-automation": {"locator_fixes": "n"},
    "automated-rca": {"root_causes": "one"},
    "jira-defect-assistant": {"defects_drafted": "n"},
    "defect-prediction": {"modules_at_risk": "two"},
    "regression-suite-optimization": {"selected_tests": "n", "total_tests": "suite"},
    "traceability-coverage": {"coverage_percent": "score", "uncovered_stories": "n"},
    "observability": {"flaky_tests": "n"},
    "duplicate-test-detection": {"duplicates": "n"},
    "uat-assistant": {"uat_scripts": "n"},
    "accessibility-test": {"issues": "n", "serious_issues": "two"},
}

STEP_SUMMARIES: dict[str, list[str]] = {
    "user-story-completeness": [
        "Story scored {score}/100; acceptance criteria are testable.",
        "Story scored {score}/100; one ambiguous rule on cut-off times flagged.",
    ],
    "test-knowledge": ["Retrieved {n} business rules and 3 prior defects for context."],
    "test-scenario-generator": ["Generated {n} scenarios covering happy, negative and boundary paths."],
    "test-design": ["Designed {n} test cases with traceability to acceptance criteria."],
    "test-data-generator": ["Produced {n} synthetic records, PII-free, including negative cases."],
    "auto-script-generator": ["Generated {n} Playwright specs using page objects."],
    "automation-failure-analysis": ["Classified {n} failures: product, environment and locator issues."],
    "self-healing-automation": ["Proposed {n} locator replacements above the confidence gate."],
    "automated-rca": ["Root cause isolated to the payment limit validation service."],
    "jira-defect-assistant": ["Drafted {n} defects with evidence, steps and severity."],
    "defect-prediction": ["Payments and Beneficiaries carry the highest defect risk this cycle."],
    "regression-suite-optimization": ["Selected {n} of 412 regression tests for the changed modules."],
    "traceability-coverage": ["Requirement coverage at {score}%; {n} stories without linked tests."],
    "observability": ["Pass rate trend stable; {n} flaky tests quarantined."],
    "duplicate-test-detection": ["Found {n} near-duplicate test cases to merge."],
    "uat-assistant": ["Prepared {n} business-readable UAT scripts."],
    "accessibility-test": ["{n} WCAG 2.2 AA issues found; 2 serious (contrast, focus order)."],
}


@dataclass
class FlowProfile:
    runs_recent: int  # runs in the last 30 days
    runs_previous: int  # runs in the 30 days before
    success_recent: float
    success_previous: float
    triggers: dict[str, float]
    failures: list[tuple[str, str]]  # (node_key that fails, error)
    branch_true: float = 0.75  # probability a condition takes its "true" path
    scheduled: dict[str, Any] = field(default_factory=dict)  # {"hour": 2} or {"hour": 7, "weekday": 0}
    approvers: dict[str, str] = field(default_factory=dict)


PROFILES: dict[str, FlowProfile] = {
    "requirement-to-automated-test": FlowProfile(
        runs_recent=24, runs_previous=17, success_recent=0.92, success_previous=0.8,
        triggers={"manual": 0.55, "copilot": 0.3, "api": 0.15},
        failures=[
            ("scripts", "Selector strategy unresolved for 'Confirm payment' button; page object missing."),
            ("data", "Data policy blocked a generated IBAN outside the synthetic range."),
        ],
        branch_true=0.78,
        approvers={"business_user": "sara.lindqvist@example.com"},
    ),
    "failure-to-rca-defect": FlowProfile(
        runs_recent=27, runs_previous=21, success_recent=0.85, success_previous=0.71,
        triggers={"api": 0.62, "manual": 0.38},
        failures=[
            ("rca", "Execution logs for the failed test were not available within 120s."),
            ("analysis", "Execution report was empty; the CI job was cancelled before upload."),
        ],
        branch_true=0.64,
        approvers={"qe_lead": "priya.raman@example.com"},
    ),
    "regression-intelligence": FlowProfile(
        runs_recent=3, runs_previous=1, success_recent=0.94, success_previous=0.87,
        triggers={"manual": 1.0},
        failures=[("coverage", "Traceability snapshot older than 24h; coverage check refused stale data.")],
        scheduled={"hour": 2},
    ),
    "release-readiness": FlowProfile(
        runs_recent=2, runs_previous=2, success_recent=1.0, success_previous=0.8,
        triggers={"manual": 1.0},
        failures=[("observability", "Metrics endpoint timed out after 3 attempts.")],
        scheduled={"hour": 7, "weekday": 0},
    ),
    "uat-preparation": FlowProfile(
        runs_recent=9, runs_previous=6, success_recent=0.89, success_previous=0.67,
        triggers={"manual": 1.0},
        failures=[("signoff", "Business sign-off rejected: UAT scripts miss the standing-order journey.")],
        approvers={"business_user": "sara.lindqvist@example.com"},
    ),
    "accessibility-compliance": FlowProfile(
        runs_recent=11, runs_previous=8, success_recent=0.91, success_previous=0.75,
        triggers={"manual": 0.6, "api": 0.4},
        failures=[("audit", "Page 'Beneficiaries' did not reach network idle within 30s.")],
    ),
}

TRIGGERED_BY = {
    "manual": ["priya.raman@example.com", "tom.becker@example.com", "alex.morgan@example.com"],
    "copilot": ["priya.raman@example.com", "tom.becker@example.com"],
    "api": ["api-token …ci01"],
    "schedule": ["scheduler"],
}


class FlowHistoryBuilder:
    def __init__(self, session: Session, project: Project) -> None:
        self.session = session
        self.project = project
        self.rng = random.Random(settings.seed_random_state + 7)
        self.now = datetime.now(UTC).replace(second=0, microsecond=0)
        self.agents_by_id: dict[str, Agent] = {}

    # ------------------------------------------------------------------
    def build(self, flows: list[AgentFlow]) -> int:
        existing = self.session.execute(
            select(AgentRun.id).where(AgentRun.project_id == self.project.id).limit(1)
        ).first()
        if existing is not None:
            return 0

        self.agents_by_id = {
            agent.id: agent
            for agent in self.session.execute(select(Agent)).scalars()
        }

        planned: list[tuple[datetime, AgentFlow, FlowProfile, bool]] = []
        for flow in flows:
            profile = PROFILES.get(flow.key)
            if profile is None:
                continue
            for moment, recent in self._moments(profile):
                planned.append((moment, flow, profile, recent))
        planned.sort(key=lambda item: item[0])

        for number, (moment, flow, profile, recent) in enumerate(planned, start=1):
            self._run(number, moment, flow, profile, recent)

        for flow in flows:
            runs = [item for item in planned if item[1] is flow]
            if runs:
                flow.run_count = len(runs)
                flow.last_run_at = runs[-1][0]
        self.session.flush()
        logger.info("seed_flow_history", runs=len(planned))
        return len(planned)

    def _moments(self, profile: FlowProfile) -> list[tuple[datetime, bool]]:
        """When each run happened: schedule slots plus working-hours manual/API runs."""
        moments: list[tuple[datetime, bool]] = []
        for recent, count in ((True, profile.runs_recent), (False, profile.runs_previous)):
            offset = 0 if recent else 30
            if profile.scheduled:
                for day in range(1, 31):
                    slot = (self.now - timedelta(days=day + offset)).replace(hour=profile.scheduled["hour"], minute=0)
                    if slot.weekday() == profile.scheduled.get("weekday", slot.weekday()):
                        moments.append((slot, recent))
            for _ in range(count):
                for _attempt in range(6):
                    moment = (self.now - timedelta(days=self.rng.randint(1, 30) + offset)).replace(
                        hour=self.rng.randint(8, 18), minute=self.rng.randint(1, 59)
                    )
                    if moment.weekday() < 5 or self.rng.random() < 0.15:
                        break
                moments.append((moment, recent))
        return moments

    # ------------------------------------------------------------------
    def _path(self, flow: AgentFlow, profile: FlowProfile) -> list[tuple[Any, bool | None]]:
        """Walk the flow's real graph from start to end, choosing condition branches at random."""
        nodes = {node.node_key: node for node in flow.nodes}
        outgoing: dict[str, list[Any]] = {}
        for edge in flow.edges:
            outgoing.setdefault(edge.source_node_key, []).append(edge)

        path: list[tuple[Any, bool | None]] = []
        current = next(node.node_key for node in flow.nodes if node.node_type == "start")
        for _ in range(40):
            edges = outgoing.get(current, [])
            if not edges:
                break
            if nodes[current].node_type == "condition":
                decision = self.rng.random() < profile.branch_true
                path[-1] = (nodes[current], decision)
                label = "true" if decision else "false"
                edge = next((item for item in edges if item.branch_label == label), edges[0])
            else:
                edge = edges[0]
            target = nodes[edge.target_node_key]
            if target.node_type == "end":
                break
            path.append((target, None))
            current = target.node_key
        return path

    def _run(self, number: int, started: datetime, flow: AgentFlow, profile: FlowProfile, recent: bool) -> None:
        rng = self.rng
        # Schedule slots are on the hour; everything else is minutes past.
        if profile.scheduled and started.minute == 0:
            trigger = "schedule"
        else:
            trigger = self._pick(profile.triggers)
        triggered_by = rng.choice(TRIGGERED_BY[trigger])

        success_rate = profile.success_recent if recent else profile.success_previous
        path = self._path(flow, profile)
        fails = rng.random() > success_rate
        failing_key = None
        if fails:
            candidates = [key for key, _ in profile.failures if any(node.node_key == key for node, _ in path)]
            failing_key = rng.choice(candidates) if candidates else None
            fails = failing_key is not None

        run = AgentRun(
            project_id=self.project.id,
            flow_id=flow.id,
            flow_version=flow.version,
            environment_id=flow.default_environment_id,
            run_number=number,
            title=flow.name,
            kind="flow",
            status="running",
            trigger=trigger,
            correlation_id=f"seed-{flow.key}-{number}",
            inputs=dict(flow.variables or {}),
            variables={},
            step_count=sum(1 for node, _ in path if node.node_type == "agent"),
            triggered_by=triggered_by,
            prompt_tokens=0,
            completion_tokens=0,
            total_tokens=0,
            total_cost_usd=0.0,
            completed_step_count=0,
            started_at=started,
            created_at=started,
            updated_at=started,
        )
        self.session.add(run)
        self.session.flush()

        clock = started + timedelta(milliseconds=rng.randint(150, 600))
        sequence = 0
        messages: list[tuple[datetime, str, str]] = [(started, "flow_started", f"Flow '{flow.name}' started.")]
        status = "succeeded"
        error_text = None

        for node, decision in path:
            sequence += 1
            agent = self.agents_by_id.get(node.agent_id) if node.agent_id else None
            step = AgentRunStep(
                run_id=run.id,
                node_key=node.node_key,
                node_type=node.node_type,
                agent_id=node.agent_id,
                agent_key=agent.key if agent else None,
                agent_version=node.agent_version,
                label=node.label,
                sequence=sequence,
                status="succeeded",
                started_at=clock,
                created_at=clock,
                updated_at=clock,
            )

            if node.node_type == "condition":
                step.duration_ms = rng.randint(3, 25)
                step.output = {"result": bool(decision), "expression": node.condition_expression}
                step.reasoning_summary = f"Condition evaluated to {bool(decision)}."
                messages.append((clock, "condition_evaluated", f"Condition '{node.label}' -> {bool(decision)}"))

            elif node.node_type == "approval" or node.requires_approval:
                wait_ms = rng.randint(2, 24) * 60_000 + rng.randint(0, 59_000)
                role = node.approval_role or "qe_lead"
                rejected = fails and failing_key == node.node_key
                approver = profile.approvers.get(role, flow.owner or "priya.raman@example.com")
                if node.node_type == "approval":
                    step.duration_ms = wait_ms
                    step.status = "failed" if rejected else "succeeded"
                    step.output = {"decision": "rejected" if rejected else "approved", "approved_by": approver}
                self.session.add(step)
                self.session.flush()
                self.session.add(
                    ApprovalRequest(
                        project_id=self.project.id,
                        run_id=run.id,
                        step_id=step.id,
                        subject_type="flow_node",
                        subject_ref=node.node_key,
                        title=f"Approve: {node.label}",
                        reason=(node.config or {}).get("reason")
                        or f"'{node.label}' requires {role.replace('_', ' ')} approval before it proceeds.",
                        risk_level=agent.risk_level if agent else "medium",
                        status="rejected" if rejected else "approved",
                        required_role=role,
                        requested_by="system",
                        decided_by=approver,
                        decided_at=clock + timedelta(milliseconds=wait_ms),
                        decision_notes=(
                            dict(profile.failures).get(node.node_key) if rejected else "Evidence reviewed; approved."
                        ),
                        created_at=clock,
                        updated_at=clock + timedelta(milliseconds=wait_ms),
                    )
                )
                messages.append((clock, "approval_requested", f"Approval required at '{node.label}'."))
                if node.node_type == "approval":
                    clock += timedelta(milliseconds=wait_ms)
                    if rejected:
                        step.error = f"Rejected by {approver}."
                        step.finished_at = clock
                        status, error_text = "failed", dict(profile.failures).get(node.node_key)
                        break
                else:
                    clock += timedelta(milliseconds=wait_ms)
                    step.started_at = clock
                    step.created_at = clock

            if node.node_type == "agent" and agent is not None:
                model, input_cost, output_cost = MODELS.get(agent.cost_tier, MODELS["medium"])
                prompt_tokens = rng.randint(900, 5200)
                completion_tokens = rng.randint(220, 2300)
                cost = round((prompt_tokens / 1000) * input_cost + (completion_tokens / 1000) * output_cost, 6)
                duration = rng.randint(2_400, 16_000) + (9_000 if agent.cost_tier == "high" else 0)
                failed_here = fails and failing_key == node.node_key
                attempt = 2 if (failed_here or rng.random() < 0.06) else 1
                step.provider = settings.default_llm_provider
                step.model = model
                step.prompt_tokens = prompt_tokens
                step.completion_tokens = completion_tokens
                step.total_tokens = prompt_tokens + completion_tokens
                step.cost_usd = cost
                step.duration_ms = duration
                step.attempt = attempt
                step.confidence = None if failed_here else round(rng.uniform(0.78, 0.97), 3)
                # Numbers the next decision reads must agree with the branch it took.
                next_decision = next(
                    (decision for later, decision in path[path.index((node, decision)) + 1:] if later.node_type == "condition"),
                    None,
                )
                values = {
                    "n": rng.randint(3, 18),
                    "score": rng.randint(82, 96) if next_decision is not False else rng.randint(58, 77),
                    "defects": rng.randint(1, 4) if next_decision is not False else 0,
                    "one": 1,
                    "two": 2,
                    "suite": 412,
                }
                summary = rng.choice(STEP_SUMMARIES.get(agent.key, ["Completed."])).format(**values)
                outputs = {field: values[source] for field, source in STEP_OUTPUTS.get(agent.key, {}).items()}
                step.inputs = {
                    target: (flow.variables or {}).get(source[1:])
                    for target, source in (node.input_mapping or {}).items()
                    if isinstance(source, str) and source.startswith("$") and source[1:] in (flow.variables or {})
                }
                if failed_here:
                    step.status = "failed"
                    step.error = dict(profile.failures)[node.node_key]
                    messages.append((clock, "step_retry", f"'{node.label}' attempt 1 failed: {step.error}"))
                    messages.append((clock, "step_failed", f"'{node.label}' attempt 2 failed: {step.error}"))
                else:
                    step.output = {
                        "status": "succeeded",
                        "summary": summary,
                        "confidence": step.confidence,
                        "outputs": outputs,
                        "findings": [],
                        "recommendations": [],
                    }
                    step.reasoning_summary = summary
                    run.completed_step_count += 1
                    if attempt > 1:
                        messages.append((clock, "step_retry", f"'{node.label}' attempt 1 failed: transient timeout"))
                self.session.add(step)
                self.session.flush()
                self.session.add(
                    LLMUsage(
                        project_id=self.project.id,
                        run_id=run.id,
                        step_id=step.id,
                        agent_id=agent.id,
                        agent_key=agent.key,
                        flow_id=flow.id,
                        provider=settings.default_llm_provider,
                        model=model,
                        capability=agent.capability,
                        operation="chat",
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        total_tokens=prompt_tokens + completion_tokens,
                        estimated_cost_usd=cost,
                        latency_ms=int(duration * rng.uniform(0.55, 0.8)),
                        success=not failed_here,
                        fallback_used=rng.random() < 0.04,
                        correlation_id=run.correlation_id,
                        created_at=clock,
                        updated_at=clock,
                    )
                )
                run.prompt_tokens += prompt_tokens
                run.completion_tokens += completion_tokens
                run.total_tokens += prompt_tokens + completion_tokens
                run.total_cost_usd = round(run.total_cost_usd + cost, 6)
                clock += timedelta(milliseconds=duration)
                if failed_here:
                    step.finished_at = clock
                    status, error_text = "failed", step.error
                    break

            step.finished_at = clock if node.node_type != "condition" else clock + timedelta(
                milliseconds=step.duration_ms
            )
            self.session.add(step)

        run.status = status
        run.finished_at = clock
        run.duration_ms = int((clock - started).total_seconds() * 1000)
        run.error = error_text
        run.updated_at = clock
        run.summary = (
            f"Run {status}: {run.completed_step_count} step(s) succeeded"
            + (", 1 failed" if status == "failed" else "")
            + f", {run.total_tokens:,} tokens, €{run.total_cost_usd:.4f}."
        )
        messages.append((clock, "flow_finished" if status == "succeeded" else "flow_failed", run.summary))

        for index, (moment, event_type, content) in enumerate(messages, start=1):
            self.session.add(
                AgentMessage(
                    run_id=run.id,
                    role="system",
                    event_type=event_type,
                    content=content,
                    payload={},
                    sequence=index,
                    created_at=moment,
                    updated_at=moment,
                )
            )
        self.session.add(
            AuditLog(
                project_id=self.project.id,
                actor=triggered_by,
                actor_type="system" if trigger == "schedule" else "user",
                action="flow.run",
                entity_type="agent_run",
                entity_id=run.id,
                entity_label=run.title,
                reason=run.summary,
                outcome="success" if status == "succeeded" else "failure",
                severity="info" if status == "succeeded" else "warning",
                output_summary={"status": status, "trigger": trigger, "cost_usd": run.total_cost_usd},
                run_id=run.id,
                correlation_id=run.correlation_id,
                created_at=clock,
                updated_at=clock,
            )
        )
        self.session.flush()

    def _pick(self, weights: dict[str, float]) -> str:
        roll, total = self.rng.random(), 0.0
        for key, weight in weights.items():
            total += weight
            if roll <= total:
                return key
        return next(iter(weights))


def seed_flow_history(session: Session, project: Project, flows: list[AgentFlow]) -> int:
    return FlowHistoryBuilder(session, project).build(flows)
