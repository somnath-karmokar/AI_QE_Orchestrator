"""Pre-built agent flows covering the specification's demo journeys (spec §32).

Each flow is a real graph of nodes and edges -- conditions, approval gates,
input mappings and all -- so it opens in the Flow Builder, validates, and runs.
"""

from __future__ import annotations

import secrets
from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.core.security import hash_api_token
from app.orchestration.schedule import next_run_after, normalise_schedule
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.project import Environment, Project

logger = get_logger(__name__)

# How each demo flow is operated: who owns it and what triggers it besides a
# manual run. Schedules and API triggers are what let a flow work on its own.
FLOW_OPERATIONS: dict[str, dict[str, Any]] = {
    "requirement-to-automated-test": {"owner": "priya.raman@example.com"},
    "failure-to-rca-defect": {"owner": "tom.becker@example.com", "api_trigger": True},
    "regression-intelligence": {
        "owner": "priya.raman@example.com",
        "schedule": {"enabled": True, "frequency": "daily", "time": "02:00"},
    },
    "release-readiness": {
        "owner": "alex.morgan@example.com",
        "schedule": {"enabled": True, "frequency": "weekly", "time": "07:00", "weekday": 0},
    },
    "uat-preparation": {"owner": "sara.lindqvist@example.com"},
    "accessibility-compliance": {"owner": "tom.becker@example.com"},
}

# Canvas geometry for the React Flow layout.
_X = 340
_Y = 150


def _node(
    key: str,
    node_type: str,
    label: str,
    row: int,
    column: int = 0,
    **kwargs: Any,
) -> dict[str, Any]:
    return {
        "node_key": key,
        "node_type": node_type,
        "label": label,
        "position_x": 120 + column * _X,
        "position_y": 80 + row * _Y,
        "sequence": row,
        **kwargs,
    }


FLOW_DEFINITIONS: list[dict[str, Any]] = [
    {
        "key": "requirement-to-automated-test",
        "name": "Requirement to Automated Test",
        "category": "Test Engineering",
        "description": (
            "End-to-end journey from a Jira story to executable automation: completeness check, "
            "knowledge retrieval, scenario and case design, test data, script generation and execution."
        ),
        "tags": ["demo", "test-design", "automation"],
        # PAY-201 is a Payments story; the test data step needs the module it generates for.
        "variables": {"requirement_key": "PAY-201", "module": "Payments", "completeness_threshold": 80},
        "cost_budget_usd": 8.0,
        "nodes": [
            _node("start", "start", "Jira Story Selected", 0),
            _node(
                "completeness",
                "agent",
                "User Story Completeness",
                1,
                agent_key="user-story-completeness",
                input_mapping={"requirement_key": "$requirement_key", "threshold": "$completeness_threshold"},
            ),
            _node(
                "gate",
                "condition",
                "Score meets threshold?",
                2,
                condition_expression="user_story_completeness.outputs.completeness_score >= completeness_threshold",
            ),
            _node(
                "clarify",
                "approval",
                "Request Business Clarification",
                3,
                column=1,
                approval_role="business_user",
                config={"reason": "The story scored below the readiness threshold and needs clarification before test design."},
            ),
            _node(
                "knowledge",
                "agent",
                "Retrieve Domain Knowledge",
                3,
                agent_key="test-knowledge",
                input_mapping={"query": "$requirement_key", "module": "$module"},
            ),
            _node(
                "scenarios",
                "agent",
                "Generate Test Scenarios",
                4,
                agent_key="test-scenario-generator",
                input_mapping={"requirement_key": "$requirement_key"},
            ),
            _node(
                "design",
                "agent",
                "Design Test Cases",
                5,
                agent_key="test-design",
                input_mapping={"requirement_key": "$requirement_key"},
            ),
            _node(
                "data",
                "agent",
                "Generate Test Data",
                6,
                agent_key="test-data-generator",
                input_mapping={"module": "$module"},
            ),
            _node(
                "scripts",
                "agent",
                "Generate Playwright Scripts",
                7,
                agent_key="auto-script-generator",
                input_mapping={"module": "$module"},
                retry_policy={"max_attempts": 2, "backoff_seconds": 2},
            ),
            _node("end", "end", "Automation Ready", 8),
        ],
        "edges": [
            ("start", "completeness", None),
            ("completeness", "gate", None),
            ("gate", "knowledge", "true"),
            ("gate", "clarify", "false"),
            ("clarify", "knowledge", None),
            ("knowledge", "scenarios", None),
            ("scenarios", "design", None),
            ("design", "data", None),
            ("data", "scripts", None),
            ("scripts", "end", None),
        ],
    },
    {
        "key": "failure-to-rca-defect",
        "name": "Failed Test to RCA and Defect",
        "category": "Quality Intelligence",
        "description": (
            "Takes a failed execution through failure classification, historical comparison and root cause "
            "analysis, then drafts a defect behind an approval gate."
        ),
        "tags": ["demo", "rca", "defects"],
        "variables": {},
        "cost_budget_usd": 6.0,
        "nodes": [
            _node("start", "start", "Failed Execution", 0),
            _node(
                "analysis",
                "agent",
                "Automation Failure Analysis",
                1,
                agent_key="automation-failure-analysis",
                input_mapping={"execution_id": "$execution_id"},
            ),
            _node(
                "is_product_defect",
                "condition",
                "Product defect indicated?",
                2,
                condition_expression="automation_failure_analysis.outputs.product_defects > 0",
            ),
            _node(
                "heal",
                "agent",
                "Self Healing Automation",
                3,
                column=1,
                agent_key="self-healing-automation",
                input_mapping={"execution_id": "$execution_id"},
                requires_approval=True,
                approval_role="qe_lead",
            ),
            _node(
                "rca",
                "agent",
                "Automated RCA",
                3,
                agent_key="automated-rca",
                input_mapping={"execution_id": "$execution_id"},
            ),
            _node(
                "draft_defect",
                "agent",
                "Draft Defect",
                4,
                agent_key="jira-defect-assistant",
                requires_approval=True,
                approval_role="qe_lead",
            ),
            _node(
                "approve_defect",
                "approval",
                "Approve Defect Creation",
                5,
                approval_role="qe_lead",
                config={"reason": "Creating a defect writes to the tracker, a system of record."},
            ),
            _node("end", "end", "Defect Raised", 6),
        ],
        "edges": [
            ("start", "analysis", None),
            ("analysis", "is_product_defect", None),
            ("is_product_defect", "rca", "true"),
            ("is_product_defect", "heal", "false"),
            ("rca", "draft_defect", None),
            ("draft_defect", "approve_defect", None),
            ("approve_defect", "end", None),
            ("heal", "end", None),
        ],
    },
    {
        "key": "regression-intelligence",
        "name": "Payment Regression Intelligence",
        "category": "Quality Intelligence",
        "description": (
            "Predicts risk, selects an optimised regression suite for the changed modules and reports the "
            "time saved against a full run."
        ),
        "tags": ["demo", "regression", "risk"],
        "variables": {"changed_modules": ["Payments", "Beneficiaries"]},
        "cost_budget_usd": 5.0,
        "nodes": [
            _node("start", "start", "Change Detected", 0),
            _node(
                "prediction",
                "agent",
                "Defect Prediction",
                1,
                agent_key="defect-prediction",
                input_mapping={"modules": "$changed_modules"},
            ),
            _node(
                "optimize",
                "agent",
                "Regression Suite Optimization",
                2,
                agent_key="regression-suite-optimization",
                input_mapping={"changed_modules": "$changed_modules"},
            ),
            _node(
                "coverage",
                "agent",
                "Traceability and Coverage",
                3,
                agent_key="traceability-coverage",
            ),
            _node("end", "end", "Optimised Suite Ready", 4),
        ],
        "edges": [
            ("start", "prediction", None),
            ("prediction", "optimize", None),
            ("optimize", "coverage", None),
            ("coverage", "end", None),
        ],
    },
    {
        "key": "release-readiness",
        "name": "Release Readiness Assessment",
        "category": "Reporting",
        "description": (
            "Assembles the release quality picture: coverage, observability trends, duplicate test debt and "
            "defect risk, into a single readiness view."
        ),
        "tags": ["demo", "reporting", "governance"],
        "variables": {"window_days": 30},
        "cost_budget_usd": 4.0,
        "nodes": [
            _node("start", "start", "Release Candidate", 0),
            _node("coverage", "agent", "Traceability and Coverage", 1, agent_key="traceability-coverage"),
            _node(
                "observability",
                "agent",
                "Observability Analysis",
                2,
                agent_key="observability",
                input_mapping={"window_days": "$window_days"},
            ),
            _node("duplicates", "agent", "Duplicate Test Detection", 3, agent_key="duplicate-test-detection"),
            _node("prediction", "agent", "Defect Prediction", 4, agent_key="defect-prediction"),
            _node("end", "end", "Readiness Report", 5),
        ],
        "edges": [
            ("start", "coverage", None),
            ("coverage", "observability", None),
            ("observability", "duplicates", None),
            ("duplicates", "prediction", None),
            ("prediction", "end", None),
        ],
    },
    {
        "key": "uat-preparation",
        "name": "UAT Preparation Pack",
        "category": "UAT",
        "description": (
            "Prepares business-ready UAT scripts and the masked data set the business needs to execute them."
        ),
        "tags": ["demo", "uat"],
        "variables": {"module": "Payments"},
        "cost_budget_usd": 3.0,
        "nodes": [
            _node("start", "start", "UAT Requested", 0),
            _node(
                "data",
                "agent",
                "Prepare UAT Data",
                1,
                agent_key="test-data-generator",
                input_mapping={"module": "$module"},
            ),
            _node(
                "uat",
                "agent",
                "Generate UAT Scripts",
                2,
                agent_key="uat-assistant",
                input_mapping={"module": "$module"},
            ),
            _node(
                "signoff",
                "approval",
                "Business Sign-off",
                3,
                approval_role="business_user",
                config={"reason": "The business sponsor must accept the UAT pack before the session begins."},
            ),
            _node("end", "end", "UAT Pack Ready", 4),
        ],
        "edges": [
            ("start", "data", None),
            ("data", "uat", None),
            ("uat", "signoff", None),
            ("signoff", "end", None),
        ],
    },
    {
        "key": "accessibility-compliance",
        "name": "Accessibility Compliance Sweep",
        "category": "Accessibility",
        "description": "Audits a module against WCAG 2.2 AA and generates the automated checks to gate CI.",
        "tags": ["demo", "accessibility"],
        "variables": {"module": "Accounts"},
        "cost_budget_usd": 3.0,
        "nodes": [
            _node("start", "start", "Compliance Sweep", 0),
            _node(
                "audit",
                "agent",
                "Accessibility Audit",
                1,
                agent_key="accessibility-test",
                input_mapping={"module": "$module"},
            ),
            _node(
                "coverage",
                "agent",
                "Coverage Check",
                2,
                agent_key="traceability-coverage",
                input_mapping={"module": "$module"},
            ),
            _node("end", "end", "Compliance Report", 3),
        ],
        "edges": [
            ("start", "audit", None),
            ("audit", "coverage", None),
            ("coverage", "end", None),
        ],
    },
]


def seed_demo_flows(session: Session, project: Project, agents: dict[str, Agent]) -> list[AgentFlow]:
    """Create the pre-built flows for the demo project."""
    sit = session.execute(
        select(Environment).where(Environment.project_id == project.id, Environment.key == "sit")
    ).scalar_one_or_none()

    flows: list[AgentFlow] = []
    for definition in FLOW_DEFINITIONS:
        existing = session.execute(
            select(AgentFlow).where(
                AgentFlow.project_id == project.id, AgentFlow.key == definition["key"]
            )
        ).scalar_one_or_none()
        if existing is not None:
            flows.append(existing)
            continue

        from app.orchestration.materialize import materialize_flow  # noqa: PLC0415 - avoids a seed/orchestration cycle

        operating = FLOW_OPERATIONS.get(definition["key"], {})
        flow = materialize_flow(
            session,
            project,
            definition,
            agents,
            status="published",
            version="1.0.0",
            is_template=True,
            created_by=operating.get("owner", "alex.morgan@example.com"),
            owner=operating.get("owner", "alex.morgan@example.com"),
            default_environment_id=sit.id if sit else None,
            change_summary="Initial platform template.",
            pin_agent_versions=True,
        )
        if operating.get("schedule"):
            flow.schedule = normalise_schedule(operating["schedule"])
            flow.trigger_type = "schedule"
            flow.next_run_at = next_run_after(flow.schedule, datetime.now(UTC))
        if operating.get("api_trigger"):
            # A token nobody holds: the flow shows as API-triggered without a usable secret.
            token = secrets.token_urlsafe(24)
            flow.webhook_token_hash = hash_api_token(token)
            flow.webhook_token_hint = token[-4:]
        flows.append(flow)

    session.flush()
    logger.info("seed_flows", count=len(flows))
    return flows
