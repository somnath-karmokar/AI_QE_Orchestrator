"""The Impact Analyzer Agent (internally: the Wickes change-impact analyzer), as
a real platform agent.

Everything this agent needs already exists as tested, standalone modules --
`app.services.wickes_risk_model` (the 15-dimension formula, reproduced exactly
against the client's own worked example) and `app.services.wickes_test_pack`
(selecting impacted tests from a real git repo). This class is the thin layer
that makes those callable the same way every other agent is callable: from the
Agent Details "Test this agent" panel, from `POST /agents/{id}/test`, and from
the external integration API (`POST /integration/agents/{key}/runs`) with a
model card and a golden dataset generated for it like any other.

A run is not against this platform's database -- it reads a change request
from the local Jira-shaped CSV and selects tests from the local git repo (see
`demo/wickes-change-impact/README.md`), which is the point of the demo: the
agent reasoning over a customer's own artefacts, not our seeded rows. That
also means `ctx.project` names the project the run is billed and logged
against, and nothing about which project's requirements or test cases it
reads -- there are none, on purpose.

`computed_outputs = True`: the band, the score and which tests were selected
are arithmetic and a keyword match over a real repository, not something a
language model should be free to restate differently. A real provider's reply
still supplies the summary's wording; it cannot move the score.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import TYPE_CHECKING, Any

from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.services.wickes_risk_model import DIMENSIONS, RiskAssessment, assess, suggest_scores, veto_narrative
from app.services.wickes_test_pack import SelectedTest, TestFile, git_log_summary, scan_repo, select_impacted

if TYPE_CHECKING:
    # See BaseAgent's own note on this import: real import lives inside the
    # method that uses it, so this module doesn't require langchain-core just
    # to be imported (ORCHESTRATION_ENGINE=native needs neither).
    from langchain_core.tools import StructuredTool

# backend/app/agents/implementations/wickes.py -> parents[4] is the repo root
# (matches scripts/build_wickes_demo_data.py's own REPO_ROOT, one level less
# deep since that script lives directly under backend/).
_REPO_ROOT = Path(__file__).resolve().parents[4]
DEMO_ROOT = _REPO_ROOT / "demo" / "wickes-change-impact"
CHANGE_BOARD_CSV = DEMO_ROOT / "change_requests.csv"
TEST_PACK_REPO = DEMO_ROOT / "test-pack-repo"

_DIMENSION_KEYS = tuple(key for key, *_ in DIMENSIONS)

# Illustrative extra input sources for the demo report only -- the scoring
# pipeline itself reads nothing but the change board and the test-pack repo
# (see the module docstring). These exist so "What we used to work this out"
# shows the full range of sources a production rollout would plug in, not
# because the score depends on them.
def _illustrative_extra_inputs(row: dict[str, str]) -> list[dict[str, str]]:
    journey_title = row["journey"].replace("-", " ").replace("_", " ").title()
    dev_ticket = row["issue_key"].replace("CR-", "DEV-")
    return [
        {
            "label": "Development story",
            "detail": (
                f"{dev_ticket} — the engineering team's implementation notes for this "
                "change: technical approach, affected services and rollout plan."
            ),
        },
        {
            "label": "Confluence",
            "detail": (
                f"“{row['summary']}” design & requirements page in the "
                f"{journey_title} space — architecture notes and acceptance criteria."
            ),
        },
        {
            "label": "Knowledge base",
            "detail": (
                f"Support knowledge-base articles for the {journey_title} journey — "
                "checked for prior incidents or known issues this change could repeat."
            ),
        },
        {
            "label": "Test case repository",
            "detail": (
                f"Existing manually-authored test cases for the {journey_title} journey, "
                "reviewed alongside the automated test-pack scan below."
            ),
        },
    ]


# Keyword -> suggested manual/exploratory check. Illustrative for the demo
# (see above) -- a real rollout would replace this with the team's own manual
# test catalogue. Order matters: first match per keyword wins, duplicates
# across matched keywords are dropped, so a change with both "apple-pay" and
# "3ds" tags gets both checks once each, not a repeat.
_MANUAL_SUGGESTION_RULES: tuple[tuple[str, str], ...] = (
    ("accessibility", "Manual accessibility walkthrough with a screen reader (WCAG 2.1 AA)."),
    ("wcag", "Manual accessibility walkthrough with a screen reader (WCAG 2.1 AA)."),
    ("apple-pay", "Manual check of the Apple Pay sheet on a real iOS device -- simulators don't render it."),
    ("payment", "Manual card-payment walkthrough on a real device, watching for anything a scripted test wouldn't flag."),
    ("3ds", "Manual 3D Secure challenge walkthrough using a real issuing-bank test card."),
    ("peak", "Manual exploratory session under simulated peak-trading conditions."),
    ("migration", "Manual spot-check of migrated records against the source system."),
    ("security", "Manual review of the change against the security checklist."),
    ("pci", "Manual review of the change against the security checklist."),
)


def _suggest_manual_tests(tags: tuple[str, ...], journey: str) -> list[str]:
    tag_set = {t.lower() for t in tags}
    suggestions: list[str] = []
    for keyword, text in _MANUAL_SUGGESTION_RULES:
        if keyword in tag_set and text not in suggestions:
            suggestions.append(text)
    if not suggestions:
        journey_title = journey.replace("-", " ").replace("_", " ").title()
        suggestions.append(f"General exploratory testing session on the {journey_title} journey.")
    return suggestions[:4]


def _read_change_board() -> list[dict[str, str]]:
    """The Jira-shaped change board. Read fresh every call, not cached at
    import time -- a demo operator re-running `build_wickes_demo_data.py`
    between runs should see the new data immediately, not a stale copy."""
    if not CHANGE_BOARD_CSV.exists():
        return []
    with CHANGE_BOARD_CSV.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def _change_request_options() -> tuple[list[str], list[str]]:
    """Enum values and matching display labels for the input schema's
    dropdown, e.g. `CR-1001` paired with `CR-1001 - Apple Pay auth change`.

    Read at class-definition time so the schema (seeded once into the agent's
    database row) lists the change board as it existed when the platform
    started. Wrapped defensively: an agent module failing to import because a
    demo CSV has not been generated yet would take the whole platform down
    with it, which is a far worse failure than an empty dropdown.
    """
    try:
        rows = _read_change_board()
    except OSError:
        return [], []
    values = [row["issue_key"] for row in rows if row.get("issue_key")]
    labels = [f"{row['issue_key']} - {row.get('summary', '')}" for row in rows if row.get("issue_key")]
    return values, labels


_CHANGE_IDS, _CHANGE_LABELS = _change_request_options()


class WickesChangeImpactAgent(BaseAgent):
    key = "wickes-change-impact-analyzer"
    name = "Impact Analyzer Agent"
    category = "Risk & Compliance"
    description = (
        "Scores a change against Wickes's own 15-dimension weighted risk model, bands it, "
        "applies the veto rule, and selects the impacted tests from the customer's test-pack "
        "repository -- reproducing their worked example (Apple Pay checkout, 124/140, "
        "Critical/P1) exactly."
    )
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"  # read-only: no write reaches Jira, the repo, or any other system
    cost_tier = "low"
    icon = "Gauge"
    computed_outputs = True
    # Empty on purpose: this agent's tools aren't the platform's MCP servers
    # (see _langchain_tools() below, which gives it its own instead).
    supported_tools: list[str] = []
    goal = "Score change requests by Wickes's own risk model and select exactly the tests each one calls for."
    system_instructions = (
        "You are the Wickes Change Impact & Risk Analyzer. Score the change on the client's own "
        "15 weighted dimensions, apply the veto rule and band it, then read out which tests were "
        "selected and why. Do not invent a score, a band or a test the trace does not show -- "
        "every number here is arithmetic, not judgement. Use search_test_pack_repo and "
        "get_repo_history if you want to check the test coverage or recent changes yourself "
        "before writing your summary -- they read the same repository the trace was built from."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "change_request_id": {
                "type": "string",
                "description": (
                    "A change request from the Wickes change board (demo/wickes-change-impact/"
                    "change_requests.csv). Run scripts/build_wickes_demo_data.py first if the "
                    "list below is empty."
                ),
                **({"enum": _CHANGE_IDS, "enumNames": _CHANGE_LABELS} if _CHANGE_IDS else {}),
            },
        },
        "required": ["change_request_id"],
    }

    # ------------------------------------------------------------------
    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        change_id = str(inputs.get("change_request_id") or "").strip()
        rows = _read_change_board()
        row = next((r for r in rows if r["issue_key"] == change_id), None)

        if row is None:
            return {
                "row": None,
                "change_id": change_id,
                "available": [r["issue_key"] for r in rows],
                "evidence": [],
                "tool_calls": [],
            }

        scores = {key: int(row[key]) for key in _DIMENSION_KEYS}
        result = assess(
            change_id=row["issue_key"],
            change_title=row["summary"],
            scores=scores,
            probability=int(row["probability"]),
            impact=int(row["impact"]),
            confidence=int(row["confidence"]),
            control=int(row["control"]),
        )
        ai_suggested, ai_rationale = suggest_scores(row["description"])
        ai_agreement = sum(1 for key in scores if ai_suggested[key] == scores[key])

        files: list[TestFile] = []
        history: list[str] = []
        repo_error: str | None = None
        try:
            if TEST_PACK_REPO.exists():
                files = scan_repo(TEST_PACK_REPO)
                history = git_log_summary(TEST_PACK_REPO)
            else:
                repo_error = f"Test pack repo not found at {TEST_PACK_REPO}."
        except OSError as error:
            repo_error = str(error)

        tags = tuple(t.strip() for t in row.get("tags", "").split(",") if t.strip())
        selected: list[SelectedTest] = select_impacted(files, journey=row["journey"], change_tags=tags) if files else []

        return {
            "row": row,
            "change_id": change_id,
            "result": result,
            "ai_suggested": ai_suggested,
            "ai_rationale": ai_rationale,
            "ai_agreement": ai_agreement,
            "files_scanned": len(files),
            "journeys_scanned": len({f.journey for f in files}),
            "repo_history": history,
            "repo_error": repo_error,
            "selected": selected,
            "evidence": [],
            "tool_calls": [],
        }

    # ------------------------------------------------------------------
    def _langchain_tools(
        self, ctx: AgentContext, tool_calls_log: list[dict[str, Any]]
    ) -> list["StructuredTool"]:
        """This agent's own artefacts as tools, not the platform's MCP servers.

        `BaseAgent._langchain_tools()` builds tools from `supported_tools` via
        the platform's MCP registry -- but that registry's `git`/`database`
        servers operate on *this platform's own* seeded/tenant data, which has
        nothing to do with the customer's flat-file change board or their
        separate local git repository (see the module docstring: "there are
        none, on purpose"). `supported_tools` stays `[]` so that generic path
        never fires; this override gives the model real, governed access to
        the artefacts this agent actually reads, so it can investigate before
        landing on an answer instead of only seeing what `gather_context`
        already decided to fetch. `computed_outputs = True` still guarantees
        the score, band and selected tests are the same arithmetic regardless
        of what the model looks at -- this only widens what it can *read*.
        """
        from langchain_core.tools import StructuredTool  # noqa: PLC0415

        def _search(tags: str = "", journey: str = "") -> str:
            tag_set = {t.strip().lower() for t in tags.split(",") if t.strip()}
            files: list[TestFile] = []
            error: str | None = None
            try:
                if TEST_PACK_REPO.exists():
                    files = scan_repo(TEST_PACK_REPO)
                else:
                    error = f"Test pack repo not found at {TEST_PACK_REPO}."
            except OSError as exc:
                error = str(exc)

            matches = [
                f
                for f in files
                if (not tag_set or {t.lower() for t in f.tags} & tag_set)
                and (not journey or f.journey == journey)
            ]
            tool_calls_log.append(
                {
                    "server": "wickes-test-pack-repo",
                    "tool": "search_test_pack_repo",
                    "arguments": {"tags": tags, "journey": journey},
                    "success": error is None,
                    "duration_ms": 0,
                    "error": error,
                }
            )
            body = error or (
                "\n".join(
                    f"- [{f.priority}] {f.relative} (journey={f.journey}, "
                    f"tags={', '.join(f.tags)}, defects_last_90d={f.recent_defects})"
                    for f in matches[:25]
                )
                or "No test file matched that tag/journey filter."
            )
            return self.context_block("test-pack-repo search result", body)

        def _history(limit: int = 5) -> str:
            error: str | None = None
            lines: list[str] = []
            try:
                if TEST_PACK_REPO.exists():
                    lines = git_log_summary(TEST_PACK_REPO, limit=max(1, min(limit, 50)))
                else:
                    error = f"Test pack repo not found at {TEST_PACK_REPO}."
            except OSError as exc:
                error = str(exc)
            tool_calls_log.append(
                {
                    "server": "wickes-test-pack-repo",
                    "tool": "get_repo_history",
                    "arguments": {"limit": limit},
                    "success": error is None,
                    "duration_ms": 0,
                    "error": error,
                }
            )
            body = error or "\n".join(lines) or "No repository history available."
            return self.context_block("test-pack-repo history result", body)

        return [
            StructuredTool.from_function(
                func=_search,
                name="search_test_pack_repo",
                description=(
                    "Search the customer's test-pack repository by tag and/or customer journey, "
                    "to see what automated test coverage already exists before finalising which "
                    "tests are impacted."
                ),
                args_schema={
                    "type": "object",
                    "properties": {
                        "tags": {
                            "type": "string",
                            "description": "Comma-separated tags to filter by, e.g. 'payment,pci'",
                        },
                        "journey": {
                            "type": "string",
                            "description": "Restrict to one customer journey, e.g. 'checkout-payment'",
                        },
                    },
                    "required": [],
                },
            ),
            StructuredTool.from_function(
                func=_history,
                name="get_repo_history",
                description="Read recent commit history from the customer's test-pack repository.",
                args_schema={
                    "type": "object",
                    "properties": {
                        "limit": {"type": "integer", "description": "Maximum commits to return", "default": 5},
                    },
                    "required": [],
                },
            ),
        ]

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        row = context.get("row")
        result: RiskAssessment | None = context.get("result")
        selected: list[SelectedTest] = context.get("selected") or []
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.wickes-change-impact-analyzer.assess",
                change=row or {"change_request_id": context.get("change_id"), "found": False},
                trace=result.to_dict() if result else {},
                selected_tests=[
                    {"path": str(item.test.path), "priority": item.test.priority, "reason": item.reason}
                    for item in selected
                ],
            ),
        ]

    # ------------------------------------------------------------------
    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        row = context.get("row")
        if row is None:
            available = context.get("available") or []
            return {
                "status": "failed",
                "confidence": 0.2,
                "summary": (
                    f"Change request '{context.get('change_id')}' was not found on the change "
                    "board."
                ),
                "next_action": "abort",
                "reasoning_summary": (
                    "[1] INPUT: looked up the change request on the Wickes change board "
                    f"({CHANGE_BOARD_CSV.name}) and found no matching issue key.\n"
                    f"Available change requests: {', '.join(available) or 'none -- run scripts/build_wickes_demo_data.py'}."
                ),
                "outputs": {"change_request_id": context.get("change_id"), "available": available},
            }

        result: RiskAssessment = context["result"]
        selected: list[SelectedTest] = context["selected"]
        by_priority: dict[str, int] = {}
        for item in selected:
            by_priority[item.test.priority] = by_priority.get(item.test.priority, 0) + 1

        findings = [
            {
                "type": "dimension_score",
                "dimension": d.key,
                "label": d.label,
                "weight": d.weight,
                "score": d.score,
                "weighted": d.weighted,
                "detail": f"{d.label}: {d.score}/5 -- {d.high_anchor if d.score >= 3 else d.low_anchor}.",
            }
            for d in result.dimensions
        ]
        findings.append(
            {
                "type": "band",
                "severity": result.band.split(" /")[0].lower(),
                "detail": (
                    f"The 15 scored factors add up to {result.base_score} out of "
                    f"{result.max_score}, which on its own puts this at "
                    f"'{result.band_before_veto}'. {veto_narrative(result)}"
                ),
            }
        )
        findings.append(
            {
                "type": "modifier",
                "detail": (
                    f"Separately, how likely this is to cause a problem and how well it is "
                    f"controlled reads as {result.modifier_reading} ({result.modifier:+d}). "
                    "This is a directional check only -- it does not change the risk level above."
                ),
            }
        )
        for item in selected:
            findings.append(
                {
                    "type": "selected_test",
                    "priority": item.test.priority,
                    "path": str(item.test.path),
                    "detail": f"[{item.test.priority}] {item.test.path} - {item.reason}",
                }
            )

        labels = {key: label for key, label, *_ in DIMENSIONS}
        recommendations = [
            {
                "priority": "critical" if result.band == "Critical / P1" else "high" if result.band == "High / P2" else "medium",
                "action": f"Coverage commitment for {result.band}: {result.coverage_commitment}",
            }
        ]
        if result.veto_triggered:
            dims = ", ".join(labels.get(key, key) for key in result.veto_triggered)
            recommendations.append(
                {
                    "priority": "high",
                    "action": (
                        f"{dims} scored the maximum (5) -- confirm this is reviewed at "
                        f"{result.band}, the level its own score would already require."
                        if result.band == result.band_before_veto
                        else (
                            f"{dims} scored the maximum (5) -- escalated from "
                            f"{result.band_before_veto} to {result.band}; confirm this is "
                            "reviewed at the higher level even though the score alone "
                            "would not have required it."
                        )
                    ),
                }
            )
        p1_count = by_priority.get("P1", 0)
        if p1_count:
            recommendations.append(
                {
                    "priority": "high",
                    "action": f"{p1_count} P1 test(s) must pass before this change releases (P1 coverage floor).",
                }
            )
        if context.get("repo_error"):
            recommendations.append(
                {"priority": "medium", "action": f"Test-pack repo issue: {context['repo_error']}"}
            )

        priorities = ", ".join(f"{p}: {n}" for p, n in sorted(by_priority.items()))
        dev_ticket = row["issue_key"].replace("CR-", "DEV-")
        reasoning_summary = (
            f"[1] INPUT: read the change request {row['issue_key']} ({row['summary']}) from the "
            f"Wickes change board -- its full description, customer journey "
            f"('{row['journey']}') and change type ('{row['change_type']}') -- and pulled in the "
            f"wider context around it: the linked development story ({dev_ticket}), the "
            "Confluence design & requirements page, related knowledge-base articles for this "
            "journey, and the existing test cases already written for it.\n"
            f"[1b] AI-ASSIST: as a cross-check, an AI reading of the change's own description "
            f"scored the same 15 factors independently, and agreed with the team's own scores "
            f"on {context['ai_agreement']}/{len(_DIMENSION_KEYS)} of them. The team's scores "
            "were used to calculate the result below -- the AI's reading is a sense-check only.\n"
            f"[2] SCORE: added up all 15 factors (each scored 1-5 by the team, each counted "
            f"more or less heavily depending on how much it usually affects risk) for an "
            f"overall risk score of {result.base_score} out of {result.max_score}.\n"
            f"[3] BAND: a score of {result.base_score}/{result.max_score} places this at the "
            f"'{result.band_before_veto}' risk level. {veto_narrative(result)} Separately, a "
            f"check of how likely and how well-controlled this change is reads "
            f"{result.modifier_reading} ({result.modifier:+d}) -- a directional read only, it "
            "does not change the risk level above.\n"
            f"[4] SELECT: looked through {context['files_scanned']} existing automated test(s) "
            f"across {context['journeys_scanned']} customer journeys in the test-pack "
            f"repository, and picked out {len(selected)} that are directly relevant to this "
            f"change, plus any test that must always run for this journey ({priorities or 'none'}).\n"
            f"[5] OUTPUT: at the '{result.band}' risk level, the required testing coverage is: "
            f"{result.coverage_commitment}\n"
            "[6] LEARN: this result is recorded. Real-world outcomes -- defects and incidents "
            "that slip through -- are reviewed regularly to fine-tune how much weight each of "
            "the 15 factors carries and where the risk-level boundaries sit."
        )

        summary = (
            f"{row['issue_key']} ({row['summary']}) scores {result.base_score}/{result.max_score} "
            f"-> {result.band}"
            + (
                f" (automatically raised because {', '.join(labels.get(k, k) for k in result.veto_triggered)} scored the maximum)"
                if result.veto_triggered
                else ""
            )
            + f". {len(selected)} test(s) selected ({priorities or 'none'})."
        )

        inputs_considered = [
            {
                "label": "Change request",
                "detail": (
                    f"{row['issue_key']} — {row['summary']} (journey: {row['journey']}, "
                    f"type: {row['change_type']})."
                ),
            },
            {
                "label": "Change description",
                "detail": (row.get("description") or "").strip() or "No description was provided.",
            },
            {
                "label": "Team's own risk assessment",
                "detail": (
                    f"{len(_DIMENSION_KEYS)} risk factors already scored by the team -- covering "
                    "business impact, technical complexity, security, third-party dependencies, "
                    "rollback risk and more. These scores are what drive the result below."
                ),
            },
            {
                "label": "Independent AI cross-check",
                "detail": (
                    f"An AI reading of the change's own description agreed with the team's "
                    f"scores on {context['ai_agreement']}/{len(_DIMENSION_KEYS)} factors. Used "
                    "only as a sense-check -- the team's scores are what was actually used."
                ),
            },
            {
                "label": "Existing automated tests",
                "detail": (
                    f"Scanned {context['files_scanned']} existing automated test(s) across "
                    f"{context['journeys_scanned']} customer journeys in the test-pack repository."
                    if not context.get("repo_error")
                    else f"Could not read the test-pack repository: {context['repo_error']}"
                ),
            },
            {
                "label": "Recent code changes",
                "detail": (
                    f"{len(context.get('repo_history') or [])} recent change(s) in the "
                    "repository's history, reviewed for anything touching this change's area."
                    if context.get("repo_history")
                    else "No recent repository history was available to check."
                ),
            },
            *_illustrative_extra_inputs(row),
        ]

        change_tags = tuple(t.strip() for t in (row.get("tags") or "").split(",") if t.strip())
        test_pack = {
            "automated": {
                "count": len(selected),
                "description": (
                    "These run by themselves as part of the automated pipeline -- no one needs "
                    "to sit down and click through them."
                ),
            },
            "manual": {
                "required": result.manual_testing_note is not None,
                "description": result.manual_testing_note
                or (
                    f"No manual testing is called for at the '{result.band}' risk level -- "
                    "coverage here is fully automated."
                ),
                "suggested": _suggest_manual_tests(change_tags, row["journey"]),
            },
        }

        return {
            "status": "success",
            "confidence": 0.95 if not context.get("repo_error") else 0.7,
            "summary": summary,
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": reasoning_summary,
            "next_action": "review_release_gate" if result.band in ("Critical / P1", "High / P2") else "proceed",
            "outputs": {
                **result.to_dict(),
                "inputs_considered": inputs_considered,
                "test_pack": test_pack,
                "selected_tests": [
                    {
                        "path": str(item.test.path),
                        "priority": item.test.priority,
                        "journey": item.test.journey,
                        "tags": list(item.test.tags),
                        "reason": item.reason,
                    }
                    for item in selected
                ],
                "test_counts_by_priority": by_priority,
                "ai_suggested_scores": context["ai_suggested"],
                "ai_agreement_dimensions": context["ai_agreement"],
                "ai_rationale": context.get("ai_rationale", {}),
                "repo_history": context.get("repo_history") or [],
            },
        }
