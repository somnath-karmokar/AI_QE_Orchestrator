"""Automation agents (catalogue entries 10-16)."""

from __future__ import annotations

import re
import statistics
from datetime import datetime, timedelta
from app.core.time import UTC
from typing import Any

from sqlalchemy import func, select, or_

from app.agents.scoping import owned, owned_execution, owned_execution_test, project_executions
from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.execution.codegen import generate_playwright_script
from app.execution.failures import FAILURE_CATEGORIES as _FAILURE_CATEGORIES
from app.execution.failures import (
    classify,
    classify_failure,
    cluster_failures,
    triage_summary,
)
from app.core.config import settings
from app.healing.config import ACCESSIBILITY_STRENGTH, healing_config
from app.healing.data import propose_substitution
from app.healing.policy import ChangeType, change_type_for, evaluate_change
from app.healing.service import HealingService
from app.healing.strategies import StrategyLadder, propose_wait
from app.mcp.servers.playwright_server import build_locator_candidates
from app.models.testing import (
    Execution,
    ExecutionTest,
    FailureEvidence,
    HealingRecord,
    RegressionAnalysis,
    Requirement,
    TestCase,
    TestScript,
    TraceabilityLink,
)
from app.vectorstore.base import COLLECTION_EXECUTION_HISTORY

def _patch_extra(candidate: dict[str, Any]) -> dict[str, Any]:
    """What a non-locator repair needs carried into its patch.

    A locator swap is fully described by from/to. A timing or data repair is
    not, so the detail that makes it applicable travels alongside.
    """
    change_type = candidate.get("change_type")
    if change_type == ChangeType.TIMING:
        return {
            "wait_ms": candidate["wait_ms"],
            "observed_wait_ms": candidate["observed_wait_ms"],
        }
    if change_type == ChangeType.TEST_DATA:
        return {
            "dataset_id": candidate.get("dataset_id"),
            "substitute_reference": candidate.get("to"),
            "record": candidate.get("record", {}),
        }
    return {}


def _test_id_of(expression: str | None) -> str | None:
    """The test id a `get_by_test_id(...)` expression was looking for."""
    match = re.search(r'get_by_test_id\(\s*["\']([^"\']+)', expression or "")
    return match.group(1) if match else None


# The failure taxonomy lives in app/execution/failures.py, where the analysis
# agents, the execution service and healing can all reach it. Re-exported here
# because this module was its original home.
FAILURE_CATEGORIES = _FAILURE_CATEGORIES


class AutoScriptGeneratorAgent(BaseAgent):
    key = "auto-script-generator"
    name = "Auto Script Generator"
    category = "Automation"
    description = "Generates Playwright (Python) page objects and tests from designed test cases."
    capability = "generation"
    complexity = "complex"
    risk_level = "medium"
    cost_tier = "high"
    icon = "Code2"
    supported_tools = ["playwright", "knowledge", "git"]
    goal = "Turn manual test cases into maintainable automation."
    system_instructions = (
        "You are a senior automation engineer writing Python Playwright tests. "
        "Use the page object pattern, prefer test id / role / label locators over CSS or XPath, "
        "and use web-first assertions instead of sleeps."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "test_case_ids": {"type": "array", "description": "Specific test cases to automate"},
            "module": {"type": "string"},
            "limit": {"type": "integer", "default": 5},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        statement = select(TestCase).where(
            TestCase.project_id == ctx.project_id,
            TestCase.is_deleted.is_(False),
            TestCase.is_automated.is_(False),
        )
        if inputs.get("test_case_ids"):
            # Named cases replace the not-yet-automated filter, never the project one.
            statement = select(TestCase).where(
                TestCase.project_id == ctx.project_id,
                TestCase.is_deleted.is_(False),
                or_(TestCase.id.in_(inputs["test_case_ids"]), TestCase.key.in_(inputs["test_case_ids"])),
            )
        elif inputs.get("module"):
            statement = statement.where(TestCase.module == inputs["module"])

        cases = list(
            ctx.session.execute(statement.limit(int(inputs.get("limit", 5)))).scalars().all()
        )

        # Ask the Playwright MCP for locator candidates on the primary element,
        # which is what a real generator would do against a live page.
        inspection = None
        if cases:
            inspection = self.call_tool(
                ctx,
                "playwright",
                "inspect",
                {"description": f"{cases[0].module} primary action", "url": ctx.project.application_url or ""},
                tool_calls=tool_calls,
            )

        return {"cases": cases, "inspection": inspection, "tool_calls": tool_calls, "evidence": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        cases: list[TestCase] = context.get("cases", [])
        listing = "\n\n".join(
            f"{case.key} {case.title}\nModule: {case.module}\nSteps: "
            + "; ".join(str(step.get("action", "")) for step in (case.steps or []))
            + f"\nExpected: {case.expected_result}"
            for case in cases
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.auto-script-generator.generate",
                test_cases=listing or "none",
                locator_candidates=context.get("inspection"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        cases: list[TestCase] = context.get("cases", [])
        if not cases:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No un-automated test cases were found for the requested scope.",
                "recommendations": [{"action": "Run the Test Design Agent to create test cases first."}],
                "next_action": "design_tests",
            }

        scripts: list[dict[str, Any]] = []
        all_notes: list[str] = []

        for case in cases:
            is_negative = bool(
                case.scenario and case.scenario.scenario_type == "negative"
            ) or "invalid" in (case.title or "").lower() or "reject" in (case.title or "").lower()

            generated = generate_playwright_script(
                test_case_key=case.key,
                title=case.title,
                module=case.module,
                steps=case.steps or [],
                preconditions=case.preconditions or [],
                expected_result=case.expected_result or "The operation completes as specified.",
                is_negative=is_negative,
                seed=ctx.project_id,
            )
            scripts.append(
                {
                    "test_case_id": case.id,
                    "test_case_key": case.key,
                    "name": generated.name,
                    "file_path": generated.file_path,
                    "code": generated.code,
                    "page_objects": generated.to_page_objects(),
                    "locators": [locator.to_dict() for locator in generated.locators],
                    "quality_notes": generated.quality_notes,
                    "module": case.module,
                }
            )
            all_notes.extend(generated.quality_notes)

        total_locators = sum(len(script["locators"]) for script in scripts)
        resilient = sum(
            1
            for script in scripts
            for locator in script["locators"]
            if locator["strategy"] in {"test_id", "role", "label"}
        )

        return {
            "status": "success",
            "confidence": 0.86,
            "summary": (
                f"Generated {len(scripts)} Playwright test(s) with page objects; "
                f"{resilient}/{total_locators} locators use a resilient strategy."
            ),
            "findings": [
                {
                    "test_case": script["test_case_key"],
                    "file_path": script["file_path"],
                    "locator_count": len(script["locators"]),
                    "module": script["module"],
                }
                for script in scripts
            ],
            "recommendations": (
                [{"priority": "medium", "action": note} for note in dict.fromkeys(all_notes) if "harden" in note]
            ),
            "reasoning_summary": (
                "Each test case was mapped to a page object plus a pytest module. Locator strategy was chosen "
                "by robustness ranking, and assertions use retrying web-first expectations."
            ),
            "next_action": "execute_tests",
            "outputs": {"script_count": len(scripts), "scripts": scripts},
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        scripts = payload.get("outputs", {}).get("scripts", [])
        artifacts: list[dict[str, Any]] = []

        for script in scripts:
            row = TestScript(
                project_id=ctx.project_id,
                test_case_id=script.get("test_case_id"),
                name=script["name"],
                framework="playwright-python",
                language="python",
                file_path=script["file_path"],
                code=script["code"],
                page_objects=script.get("page_objects", []),
                locators=script.get("locators", []),
                generated_by_agent=self.key,
                generated_by_run_id=ctx.run_id,
                quality_notes=script.get("quality_notes", []),
            )
            ctx.session.add(row)
            ctx.session.flush()

            case = owned(ctx, TestCase, script.get("test_case_id"))
            if case is not None:
                case.is_automated = True
                case.automation_status = "automated"
                ctx.session.add(
                    TraceabilityLink(
                        project_id=ctx.project_id,
                        source_type="test_case",
                        source_id=case.id,
                        target_type="test_script",
                        target_id=row.id,
                        link_type="automated_by",
                        created_by_agent=self.key,
                    )
                )

            artifacts.append(
                {
                    "type": "test_script",
                    "label": row.file_path,
                    "entity_type": "test_script",
                    "entity_id": row.id,
                    "language": "python",
                }
            )

        ctx.session.flush()
        return artifacts


class AutomatedTestExecutionAgent(BaseAgent):
    key = "automated-test-execution"
    name = "Automated Test Execution"
    category = "Execution"
    description = "Executes an automated suite and summarises the outcome with failure categories."
    capability = "classification"
    complexity = "simple"
    risk_level = "medium"
    cost_tier = "low"
    icon = "PlayCircle"
    supported_tools = ["playwright", "cicd"]
    requires_approval = False
    goal = "Run the selected suite and report a decision-ready result."
    system_instructions = (
        "You are an execution coordinator. Summarise the run: what passed, what failed, "
        "which failure categories dominate and what should happen next."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "execution_id": {"type": "string", "description": "Existing execution to summarise"},
            "suite_type": {"type": "string", "default": "regression"},
            "module": {"type": "string"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        execution = None
        if inputs.get("execution_id"):
            execution = owned_execution(ctx, inputs["execution_id"])
        elif ctx.variables.get("execution_id"):
            execution = owned_execution(ctx, ctx.variables["execution_id"])
        else:
            execution = (
                ctx.session.execute(
                    select(Execution)
                    .where(Execution.project_id == ctx.project_id)
                    .order_by(Execution.created_at.desc())
                )
                .scalars()
                .first()
            )
        tests = list(execution.tests) if execution else []
        return {"execution": execution, "tests": tests, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        execution: Execution | None = context.get("execution")
        summary = "No execution available."
        if execution is not None:
            summary = (
                f"{execution.name}: {execution.passed} passed, {execution.failed} failed, "
                f"{execution.skipped} skipped, {execution.flaky} flaky out of {execution.total_tests}."
            )
        return [
            self.system_message(ctx),
            self.task_message("agent.test-execution.summarise", execution=summary),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        execution: Execution | None = context.get("execution")
        tests: list[ExecutionTest] = context.get("tests", [])

        if execution is None:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No execution record was available to report on.",
                "next_action": "start_execution",
            }

        # Group by root cause first. A redesign that breaks forty tests is one
        # problem, and triaging it forty times would cost forty times as much
        # for the same answer.
        clusters = cluster_failures(list(tests))
        triage = triage_summary(clusters)

        categories: dict[str, int] = {}
        for cluster in clusters:
            label = cluster.classification.label
            categories[label] = categories.get(label, 0) + cluster.size

        findings = [
            {
                "signature": cluster.signature,
                "tests_affected": cluster.size,
                "test": cluster.test_names[0] if cluster.test_names else "",
                "also_affects": cluster.test_names[1:6],
                "modules": cluster.modules,
                "category": cluster.classification.label,
                "category_key": cluster.classification.category,
                "owner": cluster.classification.owner,
                "healable": cluster.classification.healable,
                "confidence": cluster.classification.confidence,
                "needs_review": cluster.classification.needs_review,
                "guidance": cluster.classification.guidance,
                "message": cluster.representative_message[:220],
            }
            for cluster in clusters
        ]

        dominant = max(categories.items(), key=lambda item: item[1])[0] if categories else None
        pass_rate = execution.pass_rate
        uncertain = triage["needs_review_causes"]

        recommendations: list[dict[str, Any]] = []
        if clusters:
            recommendations.append(
                {
                    "priority": "high",
                    "action": (
                        f"Triage {triage['distinct_causes']} distinct cause(s) behind "
                        f"{triage['failures']} failure(s); most are '{dominant}'."
                    ),
                }
            )
            if triage["healable_causes"]:
                recommendations.append(
                    {
                        "priority": "medium",
                        "action": (
                            f"{triage['healable_failures']} failure(s) across "
                            f"{triage['healable_causes']} cause(s) are candidates for self-healing."
                        ),
                    }
                )
            if uncertain:
                recommendations.append(
                    {
                        "priority": "medium",
                        "action": (
                            f"{uncertain} cause(s) could not be classified from the message alone "
                            "and need a closer look."
                        ),
                    }
                )
        else:
            recommendations.append({"priority": "low", "action": "Suite is green; promote the build."})

        return {
            "status": "success" if execution.failed == 0 else "needs_review",
            "confidence": 0.94,
            "summary": (
                f"{execution.name}: {execution.passed}/{execution.total_tests} passed "
                f"({pass_rate * 100:.1f}%), {execution.failed} failed"
                + (
                    f"; {triage['failures']} failure(s) trace to {triage['distinct_causes']} "
                    f"distinct cause(s), most commonly {dominant}."
                    if clusters
                    else "."
                )
            ),
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": (
                f"Failures were normalised into signatures and grouped by root cause: "
                f"{triage['failures']} failure(s) reduced to {triage['distinct_causes']} "
                f"investigation(s). Classification is deterministic, from the message's own "
                f"vocabulary; {uncertain} cause(s) were not decided by it and are flagged."
            ),
            "next_action": "analyze_failures" if clusters else "report",
            "outputs": {
                "execution_id": execution.id,
                "total_tests": execution.total_tests,
                "passed": execution.passed,
                "failed": execution.failed,
                "skipped": execution.skipped,
                "flaky": execution.flaky,
                "pass_rate": pass_rate,
                "failure_categories": categories,
                "triage": triage,
                "clusters": [cluster.to_dict() for cluster in clusters],
            },
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        execution_id = payload.get("outputs", {}).get("execution_id")
        if not execution_id:
            return []
        execution = owned_execution(ctx, execution_id)
        if execution is None:
            return []
        execution.failure_categories = payload.get("outputs", {}).get("failure_categories", {})
        execution.ai_findings = payload.get("findings", [])[:20]
        ctx.session.flush()
        return []


class AutomationFailureAnalysisAgent(BaseAgent):
    key = "automation-failure-analysis"
    name = "Automation Failure Analysis"
    category = "Automation"
    description = "Classifies automation failures by cause and separates product defects from test debt."
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "SearchX"
    supported_tools = ["playwright", "knowledge"]
    goal = "Tell the team which failures are real defects and which are automation problems."
    system_instructions = (
        "You are an automation triage specialist. For each failure decide whether the product or the test "
        "is at fault, cite the evidence, and state the remedy."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "execution_id": {"type": "string"},
            "execution_test_id": {"type": "string"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tests: list[ExecutionTest] = []
        if inputs.get("execution_test_id"):
            test = owned_execution_test(ctx, inputs["execution_test_id"])
            tests = [test] if test else []
        else:
            execution_id = inputs.get("execution_id") or ctx.variables.get("execution_id")
            if execution_id:
                named = owned_execution(ctx, execution_id)
                execution_id = named.id if named else None
            else:
                execution = (
                    ctx.session.execute(
                        select(Execution)
                        .where(Execution.project_id == ctx.project_id, Execution.failed > 0)
                        .order_by(Execution.created_at.desc())
                    )
                    .scalars()
                    .first()
                )
                execution_id = execution.id if execution else None
            if execution_id:
                tests = list(
                    ctx.session.execute(
                        select(ExecutionTest).where(
                            ExecutionTest.execution_id == execution_id,
                            ExecutionTest.result.in_(["failed", "flaky"]),
                        )
                    )
                    .scalars()
                    .all()
                )

        # Group by root cause before doing anything expensive. Retrieval and
        # reasoning then happen once per cause, not once per failed test -- the
        # same answer for a fraction of the cost on a large suite.
        clusters = cluster_failures(tests)

        history: dict[str, list[dict[str, Any]]] = {}
        for cluster in clusters[:10]:
            if not cluster.representative_message:
                continue
            similar = ctx.knowledge.retrieve(
                cluster.representative_message,
                project_id=ctx.project_id,
                collection=COLLECTION_EXECUTION_HISTORY,
                limit=3,
            )
            history[cluster.signature] = [
                {
                    "signature": hit.metadata.get("failure_signature"),
                    "module": hit.metadata.get("module"),
                    "score": round(hit.score, 3),
                }
                for hit in similar
            ]

        return {
            "tests": tests,
            "clusters": clusters,
            "triage": triage_summary(clusters),
            "history": history,
            "evidence": [],
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        clusters = context.get("clusters", [])
        triage = context.get("triage", {})
        # One line per cause, not per failure. The deterministic reading is
        # included so the model corrects it where it is wrong rather than
        # starting from nothing.
        listing = "\n".join(
            f"- [{cluster.signature}] {cluster.size} test(s) in "
            f"{', '.join(cluster.modules)}: {cluster.representative_message[:200]}\n"
            f"    deterministic reading: {cluster.classification.label} "
            f"(confidence {cluster.classification.confidence:.2f}"
            f"{', uncertain' if cluster.classification.needs_review else ''})"
            for cluster in clusters
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.automation-failure-analysis.triage",
                {
                    "failure_count": int(triage.get("failures", 0)),
                    "cause_count": int(triage.get("distinct_causes", 0)),
                },
                failure_causes=listing or "none",
                historical_matches=context.get("history", {}),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        tests: list[ExecutionTest] = context.get("tests", [])
        history: dict[str, list[dict[str, Any]]] = context.get("history", {})

        if not tests:
            return {
                "status": "success",
                "confidence": 0.9,
                "summary": "No failing tests were found to analyse.",
                "next_action": "report",
                "outputs": {"analysed": 0},
            }

        clusters = context.get("clusters", [])
        triage = context.get("triage", {})

        findings: list[dict[str, Any]] = []
        by_owner: dict[str, int] = {}
        healable: list[dict[str, Any]] = []

        for cluster in clusters:
            classification = cluster.classification
            precedents = history.get(cluster.signature, [])
            # Having seen this signature before strengthens the reading; an
            # uncertain reading is not rescued by precedent alone.
            confidence = min(
                0.96,
                classification.confidence * 0.7 + 0.08 * len(precedents) + 0.12,
            )
            # Owner counts are per failing test, so a cause that broke forty
            # tests weighs forty, not one.
            by_owner[classification.owner] = by_owner.get(classification.owner, 0) + cluster.size

            finding = {
                "signature": cluster.signature,
                "execution_test_id": cluster.test_ids[0] if cluster.test_ids else None,
                "execution_test_ids": cluster.test_ids,
                "tests_affected": cluster.size,
                "test": cluster.test_names[0] if cluster.test_names else "",
                "also_affects": cluster.test_names[1:6],
                "module": cluster.modules[0] if cluster.modules else None,
                "modules": cluster.modules,
                "category": classification.label,
                "category_key": classification.category,
                "owner": classification.owner,
                "healable": classification.healable,
                "change_type": classification.change_type,
                "confidence": round(confidence, 3),
                "classification_confidence": classification.confidence,
                "needs_review": classification.needs_review,
                "verdict": "product_defect" if classification.owner == "development" else "test_debt",
                "remedy": classification.guidance,
                "message": cluster.representative_message[:220],
                "historical_matches": len(precedents),
            }
            findings.append(finding)
            if classification.healable:
                healable.append(finding)

        defect_tests = by_owner.get("development", 0)
        defect_causes = sum(1 for finding in findings if finding["owner"] == "development")
        uncertain = triage.get("needs_review_causes", 0)

        return {
            "status": "needs_review" if uncertain else "success",
            "confidence": round(
                statistics.fmean([finding["confidence"] for finding in findings]), 3
            ),
            "summary": (
                f"{triage.get('failures', len(tests))} failure(s) trace to {len(findings)} distinct "
                f"cause(s): {defect_causes} point at the product, "
                f"{len(findings) - defect_causes} at the automation or the environment, "
                f"{len(healable)} are candidates for self-healing."
            ),
            "findings": findings,
            "recommendations": (
                ([{"priority": "high", "action": f"Raise {defect_causes} defect(s) for development, covering {defect_tests} failing test(s)."}] if defect_causes else [])
                + ([{"priority": "medium", "action": f"Attempt self-healing on {sum(item['tests_affected'] for item in healable)} test(s) across {len(healable)} cause(s)."}] if healable else [])
                + ([{"priority": "medium", "action": f"{uncertain} cause(s) were not decided by the failure message and need a person."}] if uncertain else [])
            ),
            "reasoning_summary": (
                f"Failures were normalised into signatures and grouped by cause, turning "
                f"{triage.get('failures', len(tests))} failure(s) into {len(findings)} "
                f"investigation(s). Each cause was classified from its own vocabulary and "
                f"cross-checked against historically similar failures. Causes the message does "
                f"not decide are flagged rather than guessed."
            ),
            "next_action": "run_rca" if defect_causes else "self_heal",
            "outputs": {
                "analysed": triage.get("failures", len(tests)),
                "distinct_causes": len(findings),
                "investigations_saved": triage.get("investigations_saved", 0),
                "product_defects": defect_causes,
                "healable_count": len(healable),
                "healable": healable,
                "by_owner": by_owner,
                "triage": triage,
            },
        }


class SelfHealingAgent(BaseAgent):
    key = "self-healing-automation"
    name = "Self Healing Automation"
    category = "Automation"
    description = "Proposes replacement locators for drifted elements under a confidence and policy gate."
    capability = "reasoning"
    complexity = "complex"
    risk_level = "high"
    cost_tier = "high"
    icon = "Wrench"
    requires_approval = True
    supported_tools = ["playwright", "git"]
    goal = "Repair brittle locators without letting AI rewrite tests unsupervised."
    system_instructions = (
        "You are an automation maintenance specialist. Propose a single replacement locator per failure, "
        "justify it with evidence, and never propose a change you cannot defend."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "execution_test_id": {"type": "string"},
            "execution_id": {"type": "string"},
            "confidence_threshold": {"type": "number", "default": 0.85},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        tests: list[ExecutionTest] = []

        if inputs.get("execution_test_id"):
            test = owned_execution_test(ctx, inputs["execution_test_id"])
            tests = [test] if test else []
        else:
            execution_id = inputs.get("execution_id") or ctx.variables.get("execution_id")
            # This project's failures only. With no execution named this used to
            # take failed tests from every project.
            statement = select(ExecutionTest).where(
                ExecutionTest.result == "failed",
                ExecutionTest.execution_id.in_(project_executions(ctx)),
            )
            if execution_id:
                named = owned_execution(ctx, execution_id)
                statement = statement.where(ExecutionTest.execution_id == (named.id if named else None))
            tests = list(ctx.session.execute(statement.limit(10)).scalars().all())

        # Only locator/timing failures are healable at all.
        candidates = []
        for test in tests:
            category_key, spec = classify_failure(test.failure_message)
            if spec.get("healable"):
                candidates.append((test, category_key))

        # Prefer the page as it actually was when the test failed. Only when no
        # such evidence exists does this fall back to inspecting the application
        # live, and then to heuristics -- in that order, most grounded first.
        inspections: dict[str, Any] = {}
        evidence_rows: dict[str, FailureEvidence] = {}
        for test, _ in candidates[:5]:
            evidence = (
                ctx.session.execute(
                    select(FailureEvidence)
                    .where(FailureEvidence.execution_test_id == test.id)
                    .order_by(FailureEvidence.created_at.desc())
                    .limit(1)
                )
                .scalars()
                .first()
            )
            if evidence is not None and evidence.dom_html:
                evidence_rows[test.id] = evidence
                continue

            element_hint = (test.name or "element").replace("test_", "").replace("_", " ")
            inspection = self.call_tool(
                ctx,
                "playwright",
                "inspect",
                {"description": element_hint, "url": ctx.project.application_url or ""},
                tool_calls=tool_calls,
            )
            if inspection:
                inspections[test.id] = inspection

        return {
            "candidates": candidates,
            "inspections": inspections,
            "failure_evidence": evidence_rows,
            "tool_calls": tool_calls,
            "evidence": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        candidates = context.get("candidates", [])
        listing = "\n".join(
            f"- {test.name}: {(test.failure_message or '')[:180]}" for test, _ in candidates
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.self-healing.propose-locator",
                failures=listing or "none",
                locator_candidates=context.get("inspections", {}),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        candidates = context.get("candidates", [])
        inspections: dict[str, Any] = context.get("inspections", {})
        config = healing_config()
        # The agent proposes; configuration decides. A request may raise the bar
        # for a single run but never lower it below the deployment's threshold.
        threshold = max(
            float(inputs.get("confidence_threshold", config.auto_apply_threshold)),
            config.auto_apply_threshold,
        )

        if not candidates:
            return {
                "status": "success",
                "confidence": 0.88,
                "summary": "No healable locator failures were found.",
                "next_action": "report",
                "outputs": {"proposals": []},
            }

        evidence_rows: dict[str, Any] = context.get("failure_evidence", {})
        proposals: list[dict[str, Any]] = []
        for test, category_key in candidates[:5]:
            element_hint = (test.name or "element").replace("test_", "").replace("_", " ")
            inspection = inspections.get(test.id)
            evidence = evidence_rows.get(test.id)

            original = self._original_locator(ctx, test)
            grounded = False
            ladder_evidence: dict[str, str] | None = None
            timing: dict[str, Any] | None = None

            # A test whose fixture ran out needs a different record, not a
            # different locator. Checked first because the failure class says so
            # plainly and no page evidence is required.
            if category_key == "test_data":
                substitution = propose_substitution(
                    ctx.session,
                    project_id=ctx.project_id,
                    module=test.module,
                    failure_message=test.failure_message,
                )
                if substitution is not None:
                    ranked = [substitution]
                    grounded = True
                    original = substitution["from"]
                    ladder_evidence = {
                        "type": "strategy_ladder",
                        "detail": (
                            "Resolved without walking the locator ladder: the test data ran out, "
                            "so the repair is an equivalent record."
                        ),
                    }
                else:
                    # No honest substitute. A test that cannot run on equivalent
                    # data should stay failed and be looked at.
                    continue

            # An element that was late rather than missing needs a wait, not a
            # new locator. Proposing a locator here would be the wrong repair to
            # a correctly diagnosed problem.
            elif evidence is not None and evidence.observed_wait_ms:
                timing = propose_wait(
                    observed_wait_ms=evidence.observed_wait_ms,
                    current_timeout_ms=settings.playwright_timeout_ms,
                    config=config,
                )

            if timing is not None:
                original = evidence.failed_locator or original
                ranked = [timing]
                grounded = True
                ladder_evidence = {
                    "type": "strategy_ladder",
                    "detail": (
                        "Resolved without walking the locator ladder: the element was present, "
                        "only late, so the repair is a wait."
                    ),
                }
            elif not grounded and evidence is not None and evidence.dom_html:
                # Only reached when neither a data nor a timing repair applied.
                result = StrategyLadder(ctx.session, config=config).propose_locator(
                    project_id=ctx.project_id,
                    original_locator=evidence.failed_locator or original,
                    fingerprint=self._fingerprint(ctx, test, evidence),
                    dom_html=evidence.dom_html,
                    failure_message=test.failure_message,
                )
                ranked = result.candidates
                grounded = result.found
                ladder_evidence = result.evidence(config.strategy_ladder)
                if grounded:
                    original = evidence.failed_locator or original

            if not grounded:
                ranked = (
                    inspection.get("candidates")
                    if inspection
                    else build_locator_candidates(element_hint, seed=ctx.project_id)
                )
            if not ranked:
                # The element is not on the page. Saying so is the right answer.
                continue

            best = ranked[0]
            runner_up = ranked[1] if len(ranked) > 1 else None
            runner_up_confidence = runner_up["confidence"] if runner_up else 0.0
            margin = best["confidence"] - runner_up_confidence

            # Score only the signals actually measured; the config normalises over
            # them, so an unavailable signal weakens nothing and invents nothing.
            # Accessibility strength and DOM similarity describe a *locator*.
            # A timing or data repair chooses no locator, so feeding them in at
            # a default would quietly lower the score for no defensible reason.
            picks_a_locator = best.get("change_type") in (None, ChangeType.LOCATOR)
            signals: dict[str, float] = {"strategy_robustness": best["confidence"]}
            if picks_a_locator:
                signals["accessibility_match"] = ACCESSIBILITY_STRENGTH.get(best["strategy"], 0.5)
            if grounded:
                # Measured against the captured page, not assumed.
                signals.update(best.get("signals", {}))
                if picks_a_locator:
                    signals["dom_similarity"] = float(best.get("match_score", 0.0))
            elif inspection:
                signals["dom_similarity"] = float(inspection.get("match_score", best["confidence"]))
            confidence = config.score(signals)
            breakdown = config.breakdown(signals)

            # The candidate decides the change type when it is not a locator
            # swap; otherwise the failure class does.
            change_type = (
                best.get("change_type") or change_type_for(category_key) or ChangeType.LOCATOR
            )
            gate = evaluate_change(
                change_type=change_type,
                confidence=confidence,
                runner_up_confidence=runner_up_confidence,
                config=config,
            )

            proposals.append(
                {
                    "execution_test_id": test.id,
                    "test": test.name,
                    "module": test.module,
                    "failure_class": category_key,
                    "change_type": change_type,
                    "original_locator": original,
                    "proposed_locator": best["locator"],
                    "strategy": best["strategy"],
                    "confidence": confidence,
                    "confidence_breakdown": breakdown,
                    "threshold": threshold,
                    "decision": gate.decision,
                    "gate": gate.to_dict(),
                    "reason": best["rationale"],
                    "alternatives": ranked[1:3],
                    "grounded_in_evidence": grounded,
                    "evidence": [
                        {"type": "failure_message", "detail": (test.failure_message or "")[:200]},
                        {
                            "type": "page_evidence",
                            "detail": (
                                f"Candidates were read from the page captured when the test failed "
                                f"({evidence.page_url})."
                                if grounded
                                else "No captured page was available, so candidates came from "
                                "locator heuristics rather than the real DOM."
                            ),
                        },
                        {"type": "locator_ranking", "detail": f"{best['strategy']} ranked highest at {best['confidence']}."},
                        {"type": "margin", "detail": f"Margin over next candidate: {margin:.3f}."},
                        *([ladder_evidence] if ladder_evidence else []),
                        *({"type": "policy", "detail": reason} for reason in gate.reasons),
                    ],
                    # Carried through so validation can apply a change that is
                    # not a locator swap.
                    "patch_extra": _patch_extra(best),
                }
            )

        auto = [item for item in proposals if item["decision"] == "auto_apply"]
        return {
            "status": "needs_review" if len(auto) < len(proposals) else "success",
            "confidence": round(statistics.fmean([item["confidence"] for item in proposals]), 3),
            "summary": (
                f"Proposed {len(proposals)} locator replacement(s); {len(auto)} meet the "
                f"{threshold:.0%} confidence threshold, {len(proposals) - len(auto)} require human review."
            ),
            "findings": proposals,
            "recommendations": [
                {
                    "priority": "medium",
                    "action": f"Review the proposed locator for '{item['test']}' (confidence {item['confidence']:.0%}).",
                }
                for item in proposals
                if item["decision"] == "human_review"
            ],
            "reasoning_summary": (
                "Locator candidates were ranked by strategy robustness; the winner had to clear both the "
                f"{threshold:.0%} confidence gate and a margin over the runner-up before qualifying for "
                "automatic application. Every proposal is recorded for audit."
            ),
            "next_action": "validate_healing",
            "outputs": {"proposals": proposals, "auto_apply_count": len(auto)},
        }

    @staticmethod
    def _fingerprint(ctx: AgentContext, test: ExecutionTest, evidence: FailureEvidence) -> dict[str, Any]:
        """What the missing element looked like when the locator still resolved.

        The best source is the fingerprint recorded on the script during a run
        where the locator worked. Failing that, the locator's own declaration
        still says what was being looked for, which is weaker but honest.
        """
        if test.test_script_id:
            script = ctx.session.get(TestScript, test.test_script_id)
            for locator in (script.locators if script else None) or []:
                if locator.get("locator") != evidence.failed_locator:
                    continue
                if locator.get("fingerprint"):
                    return locator["fingerprint"]
                return {
                    "name": locator.get("description") or locator.get("name"),
                    "role": None,
                    "test_id": _test_id_of(evidence.failed_locator),
                    "tag": None,
                }
        return {
            "name": evidence.failed_locator_name,
            "role": None,
            "test_id": _test_id_of(evidence.failed_locator),
            "tag": None,
        }

    @staticmethod
    def _original_locator(ctx: AgentContext, test: ExecutionTest) -> str:
        if test.test_script_id:
            script = ctx.session.get(TestScript, test.test_script_id)
            if script and script.locators:
                return script.locators[0].get("locator", "unknown")
        return 'page.locator("#legacy-element")'

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        proposals = payload.get("outputs", {}).get("proposals", [])
        artifacts: list[dict[str, Any]] = []

        service = HealingService(ctx.session)

        for proposal in proposals:
            # A proposal naming a test outside this project is dropped, not
            # recorded: it would point a repair at another tenant's script.
            test = owned_execution_test(ctx, proposal.get("execution_test_id"))
            if test is None:
                continue
            gate = proposal.get("gate", {})
            record = HealingRecord(
                project_id=ctx.project_id,
                test_script_id=test.test_script_id if test else None,
                execution_test_id=test.id,
                # A proposal is never "approved" by the agent that made it. It is
                # either blocked by policy or waiting for a decision.
                status="blocked" if not gate.get("allowed", True) else "proposed",
                failure_class=proposal["failure_class"],
                change_type=proposal["change_type"],
                original_locator=proposal["original_locator"],
                proposed_locator=proposal["proposed_locator"],
                locator_strategy=proposal["strategy"],
                candidates=proposal.get("alternatives", []),
                reason=proposal["reason"],
                confidence=proposal["confidence"],
                confidence_breakdown=proposal.get("confidence_breakdown", []),
                evidence=proposal.get("evidence", []),
                policy_decision={
                    "threshold": proposal["threshold"],
                    **gate,
                    **proposal.get("patch_extra", {}),
                },
                result_before="failed",
            )
            ctx.session.add(record)
            ctx.session.flush()

            # Everything that needs a human goes into the one approval queue, so
            # healing is governed exactly like every other risky action.
            if gate.get("allowed", True) and gate.get("requires_approval", True):
                service.request_approval(record, requested_by=self.key)

            artifacts.append(
                {
                    "type": "healing_record",
                    "label": f"Locator proposal for {proposal['test']}",
                    "entity_type": "healing_record",
                    "entity_id": record.id,
                    "confidence": proposal["confidence"],
                }
            )
        return artifacts


class RegressionSuiteOptimizationAgent(BaseAgent):
    key = "regression-suite-optimization"
    name = "Regression Suite Optimization"
    category = "Automation"
    description = "Selects the minimum regression suite for a change using impact and historical failure risk."
    capability = "reasoning"
    complexity = "complex"
    risk_level = "medium"
    cost_tier = "high"
    icon = "Filter"
    supported_tools = ["git", "knowledge"]
    goal = "Cut regression runtime without losing risk coverage."
    system_instructions = (
        "You are a regression strategist. Select tests by change impact and historical failure probability, "
        "and justify every inclusion and exclusion."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "changed_modules": {"type": "array", "description": "Modules affected by the change"},
            "risk_threshold": {"type": "number", "default": 0.35},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        changed_modules = inputs.get("changed_modules") or []

        if not changed_modules:
            # Infer from recent requirement churn when the caller gives nothing.
            recent = list(
                ctx.session.execute(
                    select(Requirement.module, func.count(Requirement.id))
                    .where(
                        Requirement.project_id == ctx.project_id,
                        Requirement.updated_at >= datetime.now(UTC) - timedelta(days=21),
                    )
                    .group_by(Requirement.module)
                    .order_by(func.count(Requirement.id).desc())
                ).all()
            )
            changed_modules = [row[0] for row in recent[:2]]

        for module in changed_modules[:3]:
            self.call_tool(
                ctx, "git", "list_changed_files", {"module": module, "since_days": 21}, tool_calls=tool_calls
            )

        cases = list(
            ctx.session.execute(
                select(TestCase).where(
                    TestCase.project_id == ctx.project_id,
                    TestCase.is_deleted.is_(False),
                    TestCase.is_automated.is_(True),
                )
            )
            .scalars()
            .all()
        )
        return {
            "changed_modules": changed_modules,
            "cases": cases,
            "tool_calls": tool_calls,
            "evidence": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.regression-suite-optimization.select",
                changed_modules=", ".join(context.get("changed_modules", [])) or "none",
                candidate_tests=f"{len(context.get('cases', []))} automated tests",
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        changed_modules: list[str] = context.get("changed_modules", [])
        cases: list[TestCase] = context.get("cases", [])
        threshold = float(inputs.get("risk_threshold", 0.35))

        if not cases:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No automated tests are available to optimise.",
                "next_action": "generate_scripts",
            }

        priority_weight = {"critical": 1.0, "high": 0.8, "medium": 0.5, "low": 0.25}
        selected: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        baseline_ms = 0
        optimized_ms = 0

        for case in cases:
            duration = case.avg_duration_ms or 4200
            baseline_ms += duration

            in_impact = case.module in changed_modules
            failure_rate = (case.failure_count / case.execution_count) if case.execution_count else 0.0
            # Risk blends change impact, historical failure rate, flakiness and priority.
            risk = (
                (0.45 if in_impact else 0.0)
                + failure_rate * 0.3
                + case.flakiness_score * 0.1
                + priority_weight.get(case.priority, 0.5) * 0.25
            )
            risk = round(min(1.0, risk), 3)

            entry = {
                "test_case_id": case.id,
                "key": case.key,
                "title": case.title,
                "module": case.module,
                "priority": case.priority,
                "risk_score": risk,
                "historical_failure_rate": round(failure_rate, 3),
                "flakiness": round(case.flakiness_score, 3),
                "duration_ms": duration,
                "in_change_impact": in_impact,
            }

            if risk >= threshold:
                entry["reason"] = self._selection_reason(in_impact, failure_rate, case.priority)
                selected.append(entry)
                optimized_ms += duration
            else:
                entry["reason"] = (
                    f"Outside the change impact area with a {failure_rate:.0%} historical failure rate; "
                    f"risk {risk} is below the {threshold} threshold."
                )
                skipped.append(entry)

        selected.sort(key=lambda item: item["risk_score"], reverse=True)
        reduction = round((1 - (optimized_ms / baseline_ms)) * 100, 1) if baseline_ms else 0.0
        avg_risk = round(statistics.fmean([item["risk_score"] for item in selected]), 3) if selected else 0.0

        return {
            "status": "success",
            "confidence": 0.89,
            "summary": (
                f"Selected {len(selected)} of {len(cases)} automated tests "
                f"({reduction:.0f}% estimated runtime reduction) covering changes in "
                f"{', '.join(changed_modules) or 'no identified module'}."
            ),
            "findings": selected[:40],
            "recommendations": [
                {
                    "priority": "medium",
                    "action": f"Schedule the {len(skipped)} excluded test(s) in the nightly full regression.",
                }
            ]
            if skipped
            else [],
            "reasoning_summary": (
                "Each test was scored on change impact, historical failure rate, flakiness and business "
                f"priority. Tests scoring at or above {threshold} were selected; the rest were deferred."
            ),
            "next_action": "execute_tests",
            "outputs": {
                "changed_modules": changed_modules,
                "selected_count": len(selected),
                "skipped_count": len(skipped),
                "selected": selected,
                "skipped": skipped,
                "baseline_duration_ms": baseline_ms,
                "optimized_duration_ms": optimized_ms,
                "reduction_percent": reduction,
                "average_risk_score": avg_risk,
            },
        }

    @staticmethod
    def _selection_reason(in_impact: bool, failure_rate: float, priority: str) -> str:
        reasons: list[str] = []
        if in_impact:
            reasons.append("directly covers a changed module")
        if failure_rate > 0.15:
            reasons.append(f"historically fails {failure_rate:.0%} of runs")
        if priority in {"critical", "high"}:
            reasons.append(f"{priority} business priority")
        return "Selected because it " + ", ".join(reasons) + "." if reasons else "Selected on aggregate risk."

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        if not outputs.get("selected"):
            return []
        analysis = RegressionAnalysis(
            project_id=ctx.project_id,
            run_id=ctx.run_id,
            name=f"Regression optimisation {datetime.now(UTC).strftime('%Y-%m-%d %H:%M')}",
            changed_modules=outputs.get("changed_modules", []),
            selected_tests=outputs.get("selected", [])[:100],
            skipped_tests=outputs.get("skipped", [])[:100],
            risk_score=outputs.get("average_risk_score", 0.0),
            baseline_duration_ms=outputs.get("baseline_duration_ms", 0),
            optimized_duration_ms=outputs.get("optimized_duration_ms", 0),
            reduction_percent=outputs.get("reduction_percent", 0.0),
            rationale=payload.get("reasoning_summary"),
        )
        ctx.session.add(analysis)
        ctx.session.flush()
        return [
            {
                "type": "regression_analysis",
                "label": analysis.name,
                "entity_type": "regression_analysis",
                "entity_id": analysis.id,
            }
        ]


class PerformanceTestScriptGeneratorAgent(BaseAgent):
    key = "performance-test-generator"
    name = "Performance Test Script Generator"
    category = "Performance"
    description = "Generates load profiles and k6/Locust scripts with SLA thresholds for critical journeys."
    capability = "generation"
    complexity = "standard"
    risk_level = "medium"
    cost_tier = "medium"
    icon = "Gauge"
    supported_tools = ["knowledge", "git"]
    goal = "Define realistic load profiles and codify the performance SLA."
    system_instructions = (
        "You are a performance engineer. Define a load profile with explicit thresholds tied to the "
        "service level objective, and generate a runnable script."
    )
    input_schema = {
        "type": "object",
        "required": ["module"],
        "properties": {
            "module": {"type": "string"},
            "target_rps": {"type": "integer", "default": 50},
            "duration_minutes": {"type": "integer", "default": 15},
            "p95_ms": {"type": "integer", "default": 800},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
            f"{inputs['module']} performance response time throughput",
            project_id=ctx.project_id,
            limit=3,
            module=inputs["module"],
        )
        return {"knowledge": knowledge_block, "evidence": evidence, "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.performance-test-generator.generate",
                {
                    "target_rps": int(inputs.get("target_rps", 50)),
                    "p95_ms": int(inputs.get("p95_ms", 800)),
                },
                module=inputs["module"],
                performance_knowledge=context.get("knowledge"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        module = inputs["module"]
        target_rps = int(inputs.get("target_rps", 50))
        duration = int(inputs.get("duration_minutes", 15))
        p95 = int(inputs.get("p95_ms", 800))
        base_url = ctx.project.application_url or "https://app.example.test"
        path = "/" + module.lower().replace(" ", "-")

        stages = [
            {"phase": "ramp-up", "duration_minutes": max(1, duration // 5), "target_rps": target_rps // 2},
            {"phase": "steady", "duration_minutes": max(1, duration - (duration // 5) - 2), "target_rps": target_rps},
            {"phase": "peak", "duration_minutes": 2, "target_rps": int(target_rps * 1.5)},
        ]
        stage_code = ",\n".join(
            f"    {{ duration: '{stage['duration_minutes']}m', target: {stage['target_rps']} }}"
            for stage in stages
        )

        script = f"""import http from 'k6/http';
import {{ check, sleep }} from 'k6';

// Load profile for the {module} module.
export const options = {{
  stages: [
{stage_code}
  ],
  thresholds: {{
    http_req_duration: ['p(95)<{p95}'],
    http_req_failed: ['rate<0.01'],
  }},
}};

const BASE_URL = __ENV.BASE_URL || '{base_url}';

export default function () {{
  const response = http.get(`${{BASE_URL}}{path}`);
  check(response, {{
    'status is 200': (r) => r.status === 200,
    'p95 within SLA': (r) => r.timings.duration < {p95},
  }});
  sleep(1);
}}
"""

        return {
            "status": "success",
            "confidence": 0.85,
            "summary": (
                f"Generated a k6 load profile for {module}: ramp to {target_rps} RPS over {duration} minutes "
                f"with a p95 threshold of {p95}ms."
            ),
            "findings": stages,
            "recommendations": [
                {"priority": "medium", "action": f"Baseline {module} at current production load before enforcing the p95 gate."},
                {"priority": "low", "action": "Run the peak stage against a production-like data volume."},
            ],
            "reasoning_summary": (
                f"Built a three-stage profile (ramp, steady, peak at 1.5x) and encoded the SLA as k6 "
                f"thresholds so the run fails automatically when p95 exceeds {p95}ms."
            ),
            "next_action": "execute_tests",
            "outputs": {
                "module": module,
                "tool": "k6",
                "file_path": f"performance/{module.lower().replace(' ', '_')}_load.js",
                "script": script,
                "stages": stages,
                "thresholds": {"p95_ms": p95, "error_rate": 0.01},
            },
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        if not outputs.get("script"):
            return []
        row = TestScript(
            project_id=ctx.project_id,
            name=f"{outputs['module']} load test",
            framework="k6",
            language="javascript",
            file_path=outputs["file_path"],
            code=outputs["script"],
            generated_by_agent=self.key,
            generated_by_run_id=ctx.run_id,
            quality_notes=[f"Thresholds enforce p95 < {outputs['thresholds']['p95_ms']}ms."],
        )
        ctx.session.add(row)
        ctx.session.flush()
        return [
            {
                "type": "performance_script",
                "label": row.file_path,
                "entity_type": "test_script",
                "entity_id": row.id,
            }
        ]


class AccessibilityTestAgent(BaseAgent):
    key = "accessibility-test"
    name = "Accessibility Test Agent"
    category = "Accessibility"
    description = "Audits WCAG 2.2 AA conformance and generates axe-core checks for the module."
    capability = "structured_extraction"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "Accessibility"
    supported_tools = ["playwright", "knowledge"]
    goal = "Find accessibility barriers before users do."
    system_instructions = (
        "You are an accessibility specialist working to WCAG 2.2 AA. Report violations with their success "
        "criterion, severity and remedy."
    )
    input_schema = {
        "type": "object",
        "required": ["module"],
        "properties": {"module": {"type": "string"}, "standard": {"type": "string", "default": "WCAG 2.2 AA"}},
    }

    # Checks the agent runs, each tied to a real success criterion.
    _CHECKS: list[dict[str, Any]] = [
        {"criterion": "1.1.1", "name": "Non-text content", "severity": "critical", "check": "Every image, icon and chart has a meaningful text alternative."},
        {"criterion": "1.3.1", "name": "Info and relationships", "severity": "serious", "check": "Form fields are programmatically associated with visible labels."},
        {"criterion": "1.4.3", "name": "Contrast (minimum)", "severity": "serious", "check": "Text meets a 4.5:1 contrast ratio against its background."},
        {"criterion": "2.1.1", "name": "Keyboard", "severity": "critical", "check": "All interactive controls are operable by keyboard alone."},
        {"criterion": "2.4.7", "name": "Focus visible", "severity": "serious", "check": "Keyboard focus is always visible with a clear indicator."},
        {"criterion": "3.3.1", "name": "Error identification", "severity": "serious", "check": "Validation errors are announced to assistive technology."},
        {"criterion": "4.1.2", "name": "Name, role, value", "severity": "critical", "check": "Custom components expose a correct accessible name and role."},
    ]

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        self.call_tool(
            ctx,
            "playwright",
            "inspect",
            {"description": f"{inputs['module']} primary form", "url": ctx.project.application_url or ""},
            tool_calls=tool_calls,
        )
        knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
            f"{inputs['module']} accessibility requirements",
            project_id=ctx.project_id,
            limit=2,
            module=inputs["module"],
        )
        return {"knowledge": knowledge_block, "evidence": evidence, "tool_calls": tool_calls}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.accessibility-test.audit",
                module=inputs["module"],
                standard=inputs.get("standard", "WCAG 2.2 AA"),
                module_knowledge=context.get("knowledge"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        module = inputs["module"]
        standard = inputs.get("standard", "WCAG 2.2 AA")

        findings = [
            {
                "criterion": check["criterion"],
                "name": check["name"],
                "severity": check["severity"],
                "check": check["check"],
                "status": "to_verify",
                "module": module,
            }
            for check in self._CHECKS
        ]

        script = f'''"""Accessibility checks for the {module} module ({standard})."""

from __future__ import annotations

import pytest
from axe_playwright_python.sync_playwright import Axe
from playwright.sync_api import Page


@pytest.mark.accessibility
def test_{module.lower().replace(" ", "_")}_meets_wcag_aa(page: Page, base_url: str) -> None:
    """Fail on any critical or serious {standard} violation."""
    page.goto(f"{{base_url}}/{module.lower().replace(" ", "-")}")
    page.wait_for_load_state("networkidle")

    results = Axe().run(page, options={{"runOnly": ["wcag2a", "wcag2aa", "wcag22aa"]}})
    blocking = [
        violation
        for violation in results.response["violations"]
        if violation["impact"] in ("critical", "serious")
    ]

    assert not blocking, "\\n".join(
        f"{{violation['id']}} ({{violation['impact']}}): {{violation['help']}}" for violation in blocking
    )
'''

        critical = sum(1 for item in findings if item["severity"] == "critical")
        return {
            "status": "success",
            "confidence": 0.83,
            "summary": (
                f"Prepared {len(findings)} {standard} check(s) for {module}, "
                f"{critical} of them blocking-severity, plus an automated axe-core test."
            ),
            "findings": findings,
            "recommendations": [
                {"priority": "high", "action": f"Run the generated axe-core test against {module} in CI and gate on critical/serious violations."},
                {"priority": "medium", "action": "Complement automated checks with a manual keyboard-only walkthrough; roughly half of WCAG failures are not machine-detectable."},
            ],
            "reasoning_summary": (
                f"Selected the {standard} success criteria most frequently violated in transactional forms and "
                "encoded them as an axe-core test that fails the build on critical or serious impact."
            ),
            "next_action": "execute_tests",
            "outputs": {
                "module": module,
                "standard": standard,
                "checks": findings,
                "file_path": f"accessibility/test_{module.lower().replace(' ', '_')}_a11y.py",
                "script": script,
            },
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        if not outputs.get("script"):
            return []
        row = TestScript(
            project_id=ctx.project_id,
            name=f"{outputs['module']} accessibility checks",
            framework="playwright-axe",
            language="python",
            file_path=outputs["file_path"],
            code=outputs["script"],
            generated_by_agent=self.key,
            generated_by_run_id=ctx.run_id,
            quality_notes=[f"Gates on critical and serious {outputs['standard']} violations."],
        )
        ctx.session.add(row)
        ctx.session.flush()
        return [
            {
                "type": "accessibility_script",
                "label": row.file_path,
                "entity_type": "test_script",
                "entity_id": row.id,
            }
        ]
