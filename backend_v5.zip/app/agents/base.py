"""Base agent contract (spec section 34).

    BaseAgent
     |- validate_input()
     |- execute()
     |- validate_output()
     |- record_usage()
     +- emit_events()

Subclasses supply four things and inherit everything else -- routing, budgets,
governance, retrieval, tool access, persistence hooks, event streaming and the
structured output contract:

    gather_context()  what the agent needs to know (retrieval + tool calls)
    build_messages()  the prompt it would send to a real model
    draft()           a state-derived answer, returned verbatim in demo mode
    persist()         the database side effects of a successful run

No subclass talks to an LLM SDK, a vector store or an external system directly.
"""

from __future__ import annotations

import abc
import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from app.core.time import UTC
from typing import TYPE_CHECKING, Any

from sqlalchemy.orm import Session

from app.ai.cost.tracker import UsageContext
from app.ai.prompts import PromptBuilder, PromptError
from app.ai.prompts import get as get_prompt
from app.ai.providers.base import ChatMessage
from app.ai.router.model_router import ModelRouter, RoutingRequest
from app.core.config import settings
from app.core.errors import PolicyViolationError, ValidationError
from app.core.events import event_bus, run_topic
from app.core.logging import get_logger
from app.governance.policy_engine import AuditService, PolicyContext, PolicyDecision, PolicyEngine
from app.knowledge.service import KnowledgeService
from app.mcp.base import ToolDefinition
from app.mcp.registry import ADAPTERS, MCPRegistry
from app.models.agent import Agent
from app.models.project import Environment, Project

if TYPE_CHECKING:
    # Real imports for these live inside the methods that use them, and only run
    # when ORCHESTRATION_ENGINE=langgraph -- the platform's "native" mode is
    # documented to work with neither langgraph nor langchain-core installed
    # (see app/orchestration/factory.py), so this module must not require them
    # just to be imported.
    from langchain_core.tools import StructuredTool

logger = get_logger(__name__)

# One blank line between a task instruction and each fenced context block.
_BLOCK_SEPARATOR = chr(10) * 2

# Super-steps (agent-node + tool-node executions) allowed inside one agent's
# tool-calling loop before it's forced to a final answer -- roughly 3 full
# investigate/respond round trips.
MAX_AGENTIC_RECURSION = 6


def _tightest_budget(*limits: float | None) -> float | None:
    """The smallest positive limit; zero or missing means that scope sets none."""
    positive = [float(limit) for limit in limits if limit is not None and float(limit) > 0]
    return min(positive) if positive else None


# The structured envelope every agent returns (spec section 28).
AGENT_OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["status", "confidence", "summary"],
    "properties": {
        "status": {"type": "string", "enum": ["success", "partial", "failed", "needs_review"]},
        "confidence": {"type": "number", "description": "0.0-1.0 confidence in the result"},
        "summary": {"type": "string", "description": "One or two sentence outcome summary"},
        "findings": {"type": "array", "items": {"type": "object"}},
        "recommendations": {"type": "array", "items": {"type": "object"}},
        "artifacts": {"type": "array", "items": {"type": "object"}},
        "next_action": {"type": "string"},
    },
}


@dataclass
class AgentContext:
    """Everything an agent is allowed to touch, injected by the orchestrator."""

    session: Session
    project: Project
    environment: Environment | None = None
    run_id: str | None = None
    step_id: str | None = None
    node_key: str | None = None
    actor: str = "system"
    variables: dict[str, Any] = field(default_factory=dict)
    node_config: dict[str, Any] = field(default_factory=dict)
    correlation_id: str | None = None
    approval_granted: bool = False

    # Lazily constructed services
    _knowledge: KnowledgeService | None = field(default=None, repr=False)
    _mcp: MCPRegistry | None = field(default=None, repr=False)
    _router: ModelRouter | None = field(default=None, repr=False)
    _policy: PolicyEngine | None = field(default=None, repr=False)
    _audit: AuditService | None = field(default=None, repr=False)

    @property
    def project_id(self) -> str:
        return self.project.id

    @property
    def knowledge(self) -> KnowledgeService:
        if self._knowledge is None:
            self._knowledge = KnowledgeService(self.session)
        return self._knowledge

    @property
    def mcp(self) -> MCPRegistry:
        if self._mcp is None:
            self._mcp = MCPRegistry(
                self.session,
                self.project.id,
                environment_id=self.environment.id if self.environment else None,
                environment_allows_writes=(
                    self.environment.allows_write_actions if self.environment else True
                ),
            )
        return self._mcp

    @property
    def router(self) -> ModelRouter:
        if self._router is None:
            self._router = ModelRouter(self.session)
        return self._router

    @property
    def policy(self) -> PolicyEngine:
        if self._policy is None:
            self._policy = PolicyEngine(self.session)
        return self._policy

    @property
    def audit(self) -> AuditService:
        if self._audit is None:
            self._audit = AuditService(self.session)
        return self._audit

    def emit(self, event_type: str, payload: dict[str, Any]) -> None:
        """Stream an event to any UI watching this run."""
        if self.run_id:
            event_bus.publish(run_topic(self.run_id), event_type, {"run_id": self.run_id, **payload})


@dataclass
class AgentResult:
    """Normalised agent output plus its execution telemetry."""

    status: str = "success"
    confidence: float = 0.0
    summary: str = ""
    findings: list[dict[str, Any]] = field(default_factory=list)
    recommendations: list[dict[str, Any]] = field(default_factory=list)
    artifacts: list[dict[str, Any]] = field(default_factory=list)
    next_action: str | None = None

    # Telemetry
    reasoning_summary: str | None = None
    evidence: list[dict[str, Any]] = field(default_factory=list)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    outputs: dict[str, Any] = field(default_factory=dict)
    provider: str | None = None
    model: str | None = None
    deployment: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    duration_ms: int = 0
    policy_decision: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    @property
    def succeeded(self) -> bool:
        return self.status in {"success", "partial", "needs_review"}

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "confidence": round(self.confidence, 3),
            "summary": self.summary,
            "findings": self.findings,
            "recommendations": self.recommendations,
            "artifacts": self.artifacts,
            "next_action": self.next_action,
            "outputs": self.outputs,
        }


class BaseAgent(abc.ABC):
    """Shared execution pipeline for every agent in the catalogue."""

    key: str = "base-agent"
    name: str = "Base Agent"
    category: str = "Reporting"
    description: str = ""
    capability: str = "generation"
    complexity: str = "standard"
    risk_level: str = "low"
    cost_tier: str = "low"
    icon: str = "Bot"
    requires_approval: bool = False
    supported_tools: list[str] = []
    input_schema: dict[str, Any] = {"type": "object", "properties": {}}
    output_schema: dict[str, Any] = AGENT_OUTPUT_SCHEMA
    system_instructions: str = "You are a quality engineering assistant."
    goal: str = ""
    # Set by an agent whose `outputs` are computed from project state -- a test
    # selection, a schedule fitted to capacity. A real model answers in place of
    # the deterministic draft, and would otherwise re-derive or drop those
    # numbers; with this set, the model contributes judgement and wording
    # (summary, findings, recommendations) and the computed outputs stand.
    computed_outputs: bool = False

    def __init__(self, definition: Agent | None = None) -> None:
        # The database row is authoritative for anything a user can configure.
        self.definition = definition
        # Holds the fence nonce for the prompt being built. Replaced per run, so
        # content that observed one nonce cannot replay it into the next.
        self._prompt = PromptBuilder()

    # ------------------------------------------------------------------
    # Configuration resolution
    # ------------------------------------------------------------------
    @property
    def agent_id(self) -> str | None:
        return self.definition.id if self.definition else None

    def config_value(self, name: str, default: Any = None) -> Any:
        if self.definition is not None:
            if hasattr(self.definition, name):
                value = getattr(self.definition, name)
                if value not in (None, "", [], {}):
                    return value
            configured = (self.definition.default_config or {}).get(name)
            if configured is not None:
                return configured
        return default

    def resolved_instructions(self) -> str:
        return self.config_value("system_instructions", self.system_instructions) or self.system_instructions

    def allowed_tool_refs(self) -> list[str]:
        """Tools this agent may call, as `server` or `server.tool` strings."""
        if self.definition is not None and self.definition.supported_tools:
            return list(self.definition.supported_tools)
        return list(self.supported_tools)

    # ------------------------------------------------------------------
    # Contract hooks implemented by subclasses
    # ------------------------------------------------------------------
    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        """Retrieve knowledge and call tools. Returns the working context."""
        return {}

    @abc.abstractmethod
    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        """The prompt this agent would send to a production model."""

    @abc.abstractmethod
    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """A deterministic answer derived from real application state."""

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Write the agent's results to the database. Returns artifact descriptors."""
        return []

    # ------------------------------------------------------------------
    # Pipeline
    # ------------------------------------------------------------------
    def validate_input(self, inputs: dict[str, Any]) -> dict[str, Any]:
        """Check required fields and reject unknown types before any spend."""
        schema = self.config_value("input_schema", self.input_schema) or self.input_schema
        required = schema.get("required", [])
        missing = [field_name for field_name in required if inputs.get(field_name) in (None, "", [])]
        if missing:
            raise ValidationError(
                f"Agent '{self.key}' is missing required input(s): {', '.join(missing)}.",
                details={"agent": self.key, "missing": missing, "schema": schema},
            )

        properties = schema.get("properties", {})
        cleaned: dict[str, Any] = {}
        for name, value in inputs.items():
            expected = (properties.get(name) or {}).get("type")
            if expected == "integer" and isinstance(value, str) and value.isdigit():
                cleaned[name] = int(value)
            elif expected == "array" and isinstance(value, str):
                cleaned[name] = [item.strip() for item in value.split(",") if item.strip()]
            else:
                cleaned[name] = value
        return cleaned

    def validate_output(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Coerce a model response into the agent output contract."""
        if not isinstance(payload, dict):
            raise ValidationError(f"Agent '{self.key}' returned a non-object payload.")

        status = payload.get("status", "success")
        if status not in {"success", "partial", "failed", "needs_review"}:
            status = "success"

        try:
            confidence = float(payload.get("confidence", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0
        confidence = max(0.0, min(1.0, confidence))

        summary = str(payload.get("summary") or "").strip()
        if not summary:
            raise ValidationError(f"Agent '{self.key}' returned no summary.", details={"agent": self.key})

        def _as_list(value: Any) -> list[dict[str, Any]]:
            if isinstance(value, list):
                return [item if isinstance(item, dict) else {"value": item} for item in value]
            return []

        normalised = dict(payload)
        normalised.update(
            {
                "status": status,
                "confidence": confidence,
                "summary": summary,
                "findings": _as_list(payload.get("findings")),
                "recommendations": _as_list(payload.get("recommendations")),
                "artifacts": _as_list(payload.get("artifacts")),
            }
        )
        return normalised

    def check_policy(self, ctx: AgentContext, inputs: dict[str, Any]) -> PolicyDecision:
        context = PolicyContext(
            action=f"agent.{self.key}",
            project_id=ctx.project_id,
            agent_key=self.key,
            agent_id=self.agent_id,
            risk_level=str(self.config_value("risk_level", self.risk_level)),
            environment_key=ctx.environment.key if ctx.environment else None,
            environment_is_production_like=(
                ctx.environment.is_production_like if ctx.environment else False
            ),
            metadata={"inputs": list(inputs.keys())},
        )
        return ctx.policy.evaluate(context)

    def execute(self, ctx: AgentContext, inputs: dict[str, Any]) -> AgentResult:
        """Run the full agent pipeline and return a normalised result."""
        started = time.perf_counter()
        self.emit_events(ctx, "agent_started", {"agent": self.key, "name": self.name})

        try:
            validated_inputs = self.validate_input(inputs)

            decision = self.check_policy(ctx, validated_inputs)
            if decision.effect == "deny":
                raise PolicyViolationError(
                    f"Governance policy blocked agent '{self.name}'.",
                    details={"policy": decision.to_dict()},
                )
            if decision.requires_approval and not ctx.approval_granted:
                raise PolicyViolationError(
                    f"Agent '{self.name}' requires human approval before it can run.",
                    details={"policy": decision.to_dict(), "requires_approval": True},
                )

            context = self.gather_context(ctx, validated_inputs)
            self.emit_events(
                ctx,
                "agent_context_ready",
                {"agent": self.key, "evidence_count": len(context.get("evidence", []))},
            )

            self.begin_prompt()
            messages = self.build_messages(ctx, validated_inputs, context)
            self._report_prompt_safety(ctx)
            deterministic_draft = self.draft(ctx, validated_inputs, context)

            routing_request = RoutingRequest(
                capability=str(self.config_value("capability", self.capability)),
                complexity=self.complexity,
                temperature=self.config_value("temperature", 0.1),
                max_tokens=self.config_value("max_tokens", 2500),
                node_config=ctx.node_config.get("llm_config", {}) if ctx.node_config else {},
                agent_config=self.config_value("llm_config", {}) or {},
                project_config=ctx.project.llm_config or {},
            )
            usage_context = UsageContext(
                project_id=ctx.project_id,
                run_id=ctx.run_id,
                step_id=ctx.step_id,
                agent_id=self.agent_id,
                agent_key=self.key,
                flow_id=ctx.variables.get("_flow_id"),
                correlation_id=ctx.correlation_id,
            )

            tool_calls_log: list[dict[str, Any]] = list(context.get("tool_calls", []))
            budgets = {
                "project_budget_usd": ctx.project.cost_budget_usd,
                "flow_budget_usd": ctx.variables.get("_flow_budget_usd"),
                "agent_budget_usd": _tightest_budget(
                    self.config_value("cost_budget_usd"),
                    (ctx.node_config or {}).get("cost_limit_usd"),
                ),
            }
            timeout = int(self.config_value("timeout_seconds", 120))

            if settings.orchestration_engine == "langgraph":
                # A real LangGraph ReAct loop: the model decides whether/what tool
                # to call and sees the result before answering. Only imported here
                # -- ORCHESTRATION_ENGINE=native is documented to run without
                # langgraph/langchain-core installed at all (app/orchestration/factory.py).
                from langgraph.errors import GraphRecursionError  # noqa: PLC0415
                from langgraph.prebuilt import create_react_agent  # noqa: PLC0415

                from app.ai.router.langchain_model import QEChatModel, to_langchain_messages  # noqa: PLC0415

                qe_model = QEChatModel(
                    router=ctx.router,
                    routing_request=routing_request,
                    usage_context=usage_context,
                    response_schema=self.output_schema,
                    deterministic_draft=deterministic_draft,
                    timeout=timeout,
                    budgets=budgets,
                )
                tools = self._langchain_tools(ctx, tool_calls_log)
                graph = create_react_agent(model=qe_model, tools=tools, checkpointer=None)
                try:
                    result_state = graph.invoke(
                        {"messages": to_langchain_messages(messages)},
                        config={"recursion_limit": MAX_AGENTIC_RECURSION},
                    )
                    final_content = result_state["messages"][-1].content
                except GraphRecursionError:
                    # The model never settled on a final answer within the
                    # iteration budget -- same outcome as ignoring the schema
                    # below: fall back to the state-derived draft.
                    final_content = ""

                responses = [entry[0] for entry in qe_model.call_log]
                routing_decision = qe_model.call_log[-1][1]

                payload = None
                if final_content:
                    try:
                        payload = json.loads(final_content)
                    except (json.JSONDecodeError, TypeError):
                        payload = None
            else:
                # Native engine: one direct call, exactly as before this loop existed.
                response, routing_decision = ctx.router.complete(
                    messages,
                    routing_request,
                    usage_context,
                    response_schema=self.output_schema,
                    deterministic_draft=deterministic_draft,
                    timeout=timeout,
                    **budgets,
                )
                responses = [response]
                payload = response.structured
                if payload is None:
                    try:
                        payload = json.loads(response.content)
                    except (json.JSONDecodeError, TypeError):
                        payload = None

            if payload is None:
                # A real model that ignored the schema (or the recursion cap above)
                # must not break the run.
                payload = {
                    **deterministic_draft,
                    "status": "needs_review",
                    "summary": (
                        deterministic_draft.get("summary")
                        or "Model returned unstructured output; the state-derived result was used."
                    ),
                }

            payload = self.validate_output(payload)
            if self.computed_outputs and deterministic_draft.get("outputs") is not None:
                payload["outputs"] = deterministic_draft["outputs"]
            artifacts = self.persist(ctx, validated_inputs, payload)
            if artifacts:
                payload.setdefault("artifacts", [])
                payload["artifacts"] = list(payload["artifacts"]) + artifacts

            result = AgentResult(
                status=payload["status"],
                confidence=payload["confidence"],
                summary=payload["summary"],
                findings=payload.get("findings", []),
                recommendations=payload.get("recommendations", []),
                artifacts=payload.get("artifacts", []),
                next_action=payload.get("next_action"),
                reasoning_summary=payload.get("reasoning_summary") or context.get("reasoning_summary"),
                evidence=context.get("evidence", []),
                tool_calls=tool_calls_log,
                outputs=payload.get("outputs", {}) or {
                    key: value
                    for key, value in payload.items()
                    if key
                    not in {
                        "status",
                        "confidence",
                        "summary",
                        "findings",
                        "recommendations",
                        "artifacts",
                        "next_action",
                        "reasoning_summary",
                    }
                },
                provider=routing_decision.selection.provider,
                model=routing_decision.selection.model,
                deployment=routing_decision.selection.deployment,
                prompt_tokens=sum(response.usage.prompt_tokens for response in responses),
                completion_tokens=sum(response.usage.completion_tokens for response in responses),
                cost_usd=sum(response.cost_usd for response in responses),
                duration_ms=int((time.perf_counter() - started) * 1000),
                policy_decision=decision.to_dict(),
            )

            self.record_usage(ctx, result)
            self.emit_events(
                ctx,
                "agent_completed",
                {
                    "agent": self.key,
                    "status": result.status,
                    "confidence": result.confidence,
                    "summary": result.summary,
                    "cost_usd": result.cost_usd,
                    "duration_ms": result.duration_ms,
                },
            )
            return result

        except Exception as exc:  # noqa: BLE001 - converted into a failed result upstream
            duration_ms = int((time.perf_counter() - started) * 1000)
            logger.warning("agent_failed", agent=self.key, error=str(exc)[:250])
            self.emit_events(ctx, "agent_failed", {"agent": self.key, "error": str(exc)[:250]})
            ctx.audit.record(
                action="agent.execute",
                entity_type="agent",
                entity_id=self.agent_id,
                entity_label=self.name,
                actor=ctx.actor,
                actor_type="agent",
                project_id=ctx.project_id,
                outcome="failure",
                severity="warning",
                reason=str(exc)[:400],
                run_id=ctx.run_id,
            )
            raise

    def _report_prompt_safety(self, ctx: AgentContext) -> None:
        """Record untrusted content that read like an instruction.

        The fence is what stops it working; this is how anyone finds out it was
        tried. It earns an audit row rather than only a log line, because a run
        whose context tried to reprogram the agent is something a reviewer of
        that run's output needs to know.
        """
        attempts = self._prompt.injection_attempts
        if not attempts:
            return

        logger.warning(
            "prompt_injection_markers", agent=self.key, run_id=ctx.run_id, blocks=attempts
        )
        self.emit_events(ctx, "prompt_injection_detected", {"agent": self.key, "blocks": attempts})
        ctx.audit.record(
            action="agent.prompt_injection_detected",
            entity_type="agent",
            entity_id=self.agent_id,
            entity_label=self.name,
            actor=ctx.actor,
            actor_type="agent",
            project_id=ctx.project_id,
            outcome="success",
            severity="warning",
            reason=(
                "Untrusted context contained instruction-like text. It was fenced as data "
                "and the run continued."
            ),
            input_summary={"blocks": attempts},
            run_id=ctx.run_id,
        )

    def record_usage(self, ctx: AgentContext, result: AgentResult) -> None:
        """Audit the invocation. Token/cost rows are written by the router."""
        ctx.audit.record(
            action="agent.execute",
            entity_type="agent",
            entity_id=self.agent_id,
            entity_label=self.name,
            actor=ctx.actor,
            actor_type="agent",
            project_id=ctx.project_id,
            reason=result.summary[:400],
            outcome="success" if result.succeeded else "failure",
            input_summary={"node_key": ctx.node_key},
            output_summary={
                "status": result.status,
                "findings": len(result.findings),
                "artifacts": len(result.artifacts),
            },
            model_used=f"{result.provider}:{result.model}" if result.model else None,
            confidence=result.confidence,
            policy_result=result.policy_decision,
            run_id=ctx.run_id,
        )

        if self.definition is not None:
            # Marketplace statistics: rolling averages over observed runs.
            definition = self.definition
            previous = definition.usage_count
            definition.usage_count = previous + 1
            definition.avg_duration_ms = int(
                (definition.avg_duration_ms * previous + result.duration_ms) / (previous + 1)
            )
            definition.avg_cost_usd = round(
                (definition.avg_cost_usd * previous + result.cost_usd) / (previous + 1), 6
            )
            successes = definition.success_rate * previous + (1.0 if result.succeeded else 0.0)
            definition.success_rate = round(successes / (previous + 1), 4)

    def emit_events(self, ctx: AgentContext, event_type: str, payload: dict[str, Any]) -> None:
        ctx.emit(event_type, {"step_id": ctx.step_id, "node_key": ctx.node_key, **payload})

    # ------------------------------------------------------------------
    # Prompt helpers shared by subclasses
    # ------------------------------------------------------------------
    @property
    def prompt(self) -> PromptBuilder:
        """The builder for the prompt currently being assembled."""
        return self._prompt

    def begin_prompt(self) -> PromptBuilder:
        """Start a new prompt with a fresh fence nonce.

        Called once per run before `build_messages`. The nonce must not carry
        over between prompts: content that read one prompt's fence could
        otherwise use it to close a block in the next.
        """
        self._prompt = PromptBuilder()
        return self._prompt

    def system_message(self, ctx: AgentContext) -> ChatMessage:
        """System prompt including the output contract and safety rules."""
        template = get_prompt("shared.agent_system")
        return ChatMessage(
            role="system",
            content=template.render(
                instructions=self.resolved_instructions(),
                project_name=ctx.project.name,
                business_domain=ctx.project.business_domain or "enterprise application",
                environment_name=ctx.environment.name if ctx.environment else "not specified",
                untrusted_preamble=self._prompt.preamble,
                output_schema=json.dumps(self.output_schema, indent=2),
            ),
        )

    def context_block(self, title: str, body: Any) -> str:
        """Fence untrusted context so a model cannot mistake it for instruction.

        Everything passed here is content the platform does not control -- a
        failure message from the application under test, captured DOM, a
        retrieved document, inputs another platform supplied over the
        integration API. See `app.ai.prompts.safety` for why the fixed
        delimiter this used to emit was not enough.
        """
        return self._prompt.untrusted(title, body)

    def task_message(
        self, template_id: str, params: dict[str, Any] | None = None, **blocks: Any
    ) -> ChatMessage:
        """The user turn: a registered instruction plus fenced context blocks.

        Each keyword becomes one fenced block named after it, so a call site
        cannot embed untrusted content any way but safely.

        `params` fills placeholders in the instruction itself, which is outside
        the fence and therefore reads as operator text. Only numbers and
        booleans are allowed there. Call sites used to interpolate caller
        strings -- a module name, a query, a table -- straight into the
        instruction, and since the integration API those come from whichever
        platform called us. A free-text value in that position is the same
        injection the fence closes, one layer up. Strings go in a block.
        """
        values = dict(params or {})
        for name, value in values.items():
            if isinstance(value, bool) or isinstance(value, (int, float)):
                continue
            raise PromptError(
                f"{template_id}: instruction parameter '{name}' is a "
                f"{type(value).__name__}, but only numbers and booleans may be "
                "interpolated into an instruction. Pass it as a fenced block instead."
            )

        sections = [get_prompt(template_id).render(**values)]
        sections.extend(self.context_block(label, body) for label, body in blocks.items())
        return ChatMessage(role="user", content=_BLOCK_SEPARATOR.join(sections))

    def call_tool(
        self,
        ctx: AgentContext,
        server: str,
        tool: str,
        arguments: dict[str, Any] | None = None,
        *,
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any] | None:
        """Invoke an MCP tool, recording the call and tolerating failure."""
        try:
            result = ctx.mcp.invoke(
                server,
                tool,
                arguments or {},
                agent_allowed_tools=self.allowed_tool_refs(),
                approval_granted=ctx.approval_granted,
            )
        except PolicyViolationError as exc:
            entry = {"server": server, "tool": tool, "success": False, "error": exc.message}
            if tool_calls is not None:
                tool_calls.append(entry)
            return None

        if tool_calls is not None:
            tool_calls.append(
                {
                    "server": server,
                    "tool": tool,
                    "arguments": arguments or {},
                    "success": result.success,
                    "duration_ms": result.duration_ms,
                    "error": result.error,
                }
            )
        return result.data if result.success else None

    # ------------------------------------------------------------------
    # Tools exposed to the model for its own tool-calling loop
    # ------------------------------------------------------------------
    def _langchain_tools(
        self, ctx: AgentContext, tool_calls_log: list[dict[str, Any]]
    ) -> list[StructuredTool]:
        """This agent's allowed tools, as LangChain tools a ReAct loop can call.

        Governance is unaffected by who chooses to call a tool: every invocation
        still runs through `call_tool()` -> `MCPRegistry.invoke()`, the same
        allowlist/environment/approval gate a hard-coded call already goes through.
        """
        # server -> None (every tool on that server) or a set of allowed tool names.
        servers: dict[str, set[str] | None] = {}
        for ref in self.allowed_tool_refs():
            if ref == "knowledge":
                continue
            server, _, tool_name = ref.partition(".")
            if server not in ADAPTERS:
                continue
            if not tool_name:
                servers[server] = None
            elif server not in servers:
                servers[server] = {tool_name}
            elif servers[server] is not None:
                servers[server].add(tool_name)

        tools: list[StructuredTool] = []
        for server, allowed_names in servers.items():
            try:
                definitions = ctx.mcp.list_tools(server)
            except Exception:  # noqa: BLE001 - a misconfigured/disabled server exposes no tools
                continue
            for definition in definitions:
                if allowed_names is not None and definition.name not in allowed_names:
                    continue
                tools.append(self._mcp_tool(ctx, server, definition, tool_calls_log))

        if "knowledge" in self.allowed_tool_refs():
            tools.append(self._knowledge_search_tool(ctx))

        return tools

    def _mcp_tool(
        self,
        ctx: AgentContext,
        server: str,
        definition: ToolDefinition,
        tool_calls_log: list[dict[str, Any]],
    ) -> StructuredTool:
        from langchain_core.tools import StructuredTool  # noqa: PLC0415

        schema = definition.to_openai_tool()["function"]["parameters"]

        def _invoke(**kwargs: Any) -> str:
            result = self.call_tool(ctx, server, definition.name, kwargs, tool_calls=tool_calls_log)
            # Tool output is external content the same way a retrieved document or a
            # failure message is -- fence it so it can't be mistaken for an
            # instruction, and so it gets the same cost-bounding truncation.
            return self.context_block(f"{server}.{definition.name} result", result)

        return StructuredTool.from_function(
            func=_invoke,
            name=f"{server}__{definition.name}",
            description=definition.description,
            args_schema=schema,
        )

    def _knowledge_search_tool(self, ctx: AgentContext) -> StructuredTool:
        from langchain_core.tools import StructuredTool  # noqa: PLC0415

        def _invoke(query: str, collection: str | None = None, limit: int = 5) -> str:
            kwargs: dict[str, Any] = {"project_id": ctx.project_id, "limit": limit}
            if collection:
                kwargs["collection"] = collection
            hits = ctx.knowledge.retrieve(query, **kwargs)
            body = (
                "\n".join(f"- score {hit.score:.2f}: {hit.content[:400]}" for hit in hits)
                or "No matching knowledge found."
            )
            return self.context_block("knowledge_search result", body)

        return StructuredTool.from_function(
            func=_invoke,
            name="knowledge_search",
            description=(
                "Search this project's indexed requirements, docs, tests, defects and "
                "execution history for relevant context."
            ),
            args_schema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "What to search for"},
                    "collection": {
                        "type": "string",
                        "description": "Optional: restrict to one knowledge collection",
                    },
                    "limit": {"type": "integer", "description": "Maximum results", "default": 5},
                },
                "required": ["query"],
            },
        )

    @staticmethod
    def now_iso() -> str:
        return datetime.now(UTC).isoformat()
