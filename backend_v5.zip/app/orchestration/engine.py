"""Stateful flow orchestration engine.

Walks the flow graph, executing agent, condition, approval, parallel and tool
nodes. Responsibilities that belong here and nowhere else:

  * per-step state, retries, timeouts and failure policy;
  * pausing at approval gates and resuming from a stored token;
  * cancellation at step boundaries, leaving the run consistent;
  * streaming every transition to the UI event bus.

A failing agent never corrupts run state -- the step is marked failed and the
node's `on_failure` policy decides whether the flow continues (spec section 29).
"""

from __future__ import annotations

import time
from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.agents.base import AgentContext, AgentResult
from app.agents.registry import build_agent
from app.core.config import settings
from app.core.errors import NotFoundError, PolicyViolationError
from app.core.events import event_bus, run_topic
from app.core.logging import get_logger, set_correlation_id
from app.core.worker import CancellationToken
from app.governance.policy_engine import AuditService, PolicyEngine
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest, Notification
from app.models.project import Environment, Project
from app.models.run import AgentMessage, AgentRun, AgentRunStep
from app.orchestration.graph import FlowGraph, FlowNode, apply_mapping, evaluate_condition

logger = get_logger(__name__)

MAX_STEPS = 200  # hard stop against runaway graphs


def _variable_aliases(key: str) -> set[str]:
    """Names a step result can be referenced by in mappings and conditions."""
    if not key:
        return set()
    return {key, key.replace("-", "_")}


class FlowEngine:
    """Executes one run of one flow, walking the graph with an in-house worklist loop.

    `LangGraphFlowEngine` (app/orchestration/langgraph_runtime.py) replaces only
    the traversal in `_walk`; everything a node *does* lives in this class.
    """

    engine_name = "native"

    def __init__(self, session: Session, *, cancellation: CancellationToken | None = None) -> None:
        self.session = session
        self.cancellation = cancellation or CancellationToken()
        self.audit = AuditService(session)
        self.policy = PolicyEngine(session)
        self._message_sequence = 0

    def _checkpoint(self) -> None:
        """Commit progress at a step boundary.

        One transaction for a whole run would hide progress from every other
        session until the end, hold SQLite's write lock for the duration, and let
        a failing step's rollback erase the steps that already succeeded.
        """
        self.session.commit()

    def _steps(self, run: AgentRun) -> list[AgentRunStep]:
        """Live step rows.

        `run.steps` is a selectin relationship loaded when the run was fetched --
        before any step existed -- so it must not be used for status decisions.
        """
        return list(
            self.session.execute(
                select(AgentRunStep)
                .where(AgentRunStep.run_id == run.id)
                .order_by(AgentRunStep.sequence)
            )
            .scalars()
            .all()
        )

    # ------------------------------------------------------------------
    # Run lifecycle
    # ------------------------------------------------------------------
    def execute_run(self, run_id: str) -> AgentRun:
        run = self.session.get(AgentRun, run_id)
        if run is None:
            raise NotFoundError(f"Run '{run_id}' was not found.", details={"run_id": run_id})

        set_correlation_id(run.correlation_id)
        project = self.session.get(Project, run.project_id)
        environment = self.session.get(Environment, run.environment_id) if run.environment_id else None

        if run.flow_id is None:
            return self._execute_single_agent(run, project, environment)

        flow = self.session.get(AgentFlow, run.flow_id)
        if flow is None:
            raise NotFoundError(f"Flow '{run.flow_id}' was not found.", details={"flow_id": run.flow_id})

        graph = FlowGraph.from_flow(flow)
        validation = graph.validate()
        if not validation["valid"]:
            self._fail_run(run, "Flow validation failed: " + "; ".join(item["message"] for item in validation["errors"]))
            return run

        self._start_run(run, step_count=validation.get("agent_node_count", 0))
        self._log(
            run,
            "flow_started",
            f"Flow '{flow.name}' started.",
            {"flow_id": flow.id, "version": flow.version, "engine": self.engine_name},
        )

        # Run variables are the shared state every node reads and writes.
        variables: dict[str, Any] = {
            **(flow.variables or {}),
            **(run.variables or {}),
            **(run.inputs or {}),
            "_flow_id": flow.id,
            "_flow_budget_usd": flow.cost_budget_usd,
            "_run_id": run.id,
            "_project_key": project.key if project else None,
        }

        try:
            completed = self._walk(run, flow, graph, project, environment, variables)
        except Exception as exc:  # noqa: BLE001 - the run must always reach a terminal state
            logger.exception("flow_run_failed", run_id=run.id, error=str(exc))
            # Discard only the unfinished step's writes; completed steps are committed.
            self.session.rollback()
            self._fail_run(run, str(exc)[:1000])
            return run

        if completed == "awaiting_approval":
            self._pause_run(run, variables)
        elif completed == "cancelled":
            self._finish_run(run, "cancelled", variables)
        else:
            steps = self._steps(run)
            failed_steps = [step for step in steps if step.status == "failed"]
            succeeded_steps = [step for step in steps if step.status == "succeeded"]
            if not failed_steps:
                status = "succeeded"
            elif succeeded_steps:
                status = "partially_succeeded"
            else:
                status = "failed"
            self._finish_run(run, status, variables)

        flow.last_run_at = datetime.now(UTC)
        flow.run_count += 1
        self.session.flush()
        return run

    def _execute_single_agent(
        self, run: AgentRun, project: Project, environment: Environment | None
    ) -> AgentRun:
        """Ad-hoc execution of one agent (marketplace 'Test Agent' and API calls)."""
        definition = self.session.get(Agent, run.agent_id) if run.agent_id else None
        if definition is None:
            self._fail_run(run, "No agent was specified for this run.")
            return run

        self._start_run(run, step_count=1)
        variables: dict[str, Any] = {**(run.inputs or {}), "_run_id": run.id}
        node = FlowNode(key="agent", node_type="agent", label=definition.name, agent_id=definition.id)

        step = self._awaiting_step(run, node.key) or self._create_step(
            run, node, sequence=1, agent_key=definition.key
        )
        gate = self._agent_approval_gate(run, node, step, definition, variables, run.inputs or {})
        if gate == "awaiting_approval":
            self._pause_run(run, variables)
            return run
        if gate == "rejected":
            self._finish_run(run, "failed", variables)
            return run

        result = self._run_agent_node(run, node, step, definition, project, environment, variables, run.inputs or {})

        if result is not None and result.succeeded:
            for alias in _variable_aliases(definition.key):
                variables[alias] = result.to_dict()
            self._finish_run(run, "succeeded", variables)
        elif step.status == "awaiting_approval":
            self._pause_run(run, variables)
        else:
            self._finish_run(run, "failed", variables)
        return run

    # ------------------------------------------------------------------
    # Graph walk
    # ------------------------------------------------------------------
    def _walk(
        self,
        run: AgentRun,
        flow: AgentFlow,
        graph: FlowGraph,
        project: Project,
        environment: Environment | None,
        variables: dict[str, Any],
    ) -> str:
        # Resuming: skip nodes that already completed in a previous attempt.
        existing_steps = self._steps(run)
        completed_nodes = {
            step.node_key for step in existing_steps if step.status in {"succeeded", "skipped"}
        }
        pending = [node.key for node in graph.start_nodes()]
        visited: set[str] = set()
        sequence = len(existing_steps)
        guard = 0

        while pending:
            guard += 1
            if guard > MAX_STEPS:
                self._log(run, "flow_guard", f"Step limit of {MAX_STEPS} reached; stopping.", {})
                break

            if self.cancellation.is_cancelled:
                self._log(run, "flow_cancelled", "Run cancelled by request.", {})
                return "cancelled"

            node_key = pending.pop(0)
            if node_key in visited or node_key not in graph.nodes:
                continue

            # A join node waits until every upstream path has been resolved.
            node = graph.nodes[node_key]
            if node.node_type == "join":
                upstream = {edge.source for edge in graph.incoming(node_key)}
                if not upstream.issubset(visited | completed_nodes):
                    pending.append(node_key)
                    if all(candidate in pending for candidate in [node_key]) and len(pending) == 1:
                        # Nothing else can advance; break rather than spin.
                        break
                    continue

            visited.add(node_key)

            if node_key in completed_nodes:
                # Replay the finished step's state exactly as a live run left it. Pausing
                # drops `__` variables, so a condition's decision is restored from its
                # output; without it, routing would silently take the wrong branch.
                previous = next(step for step in existing_steps if step.node_key == node_key)
                self._replay_step(node, previous, variables)
                pending.extend(self._next_nodes(graph, node, variables, run))
                continue

            sequence += 1
            self._pace(node)
            outcome = self._execute_node(
                run, flow, graph, node, sequence, project, environment, variables
            )

            if outcome == "awaiting_approval":
                return "awaiting_approval"
            if outcome == "cancelled":
                return "cancelled"
            if outcome == "stop_flow":
                break

            pending.extend(self._next_nodes(graph, node, variables, run))

        return "completed"

    def _pace(self, node: FlowNode) -> None:
        """Demo pacing only: wait between steps, in slices so a cancel still lands promptly."""
        if settings.run_step_pause_ms and node.node_type not in {"start", "end"}:
            deadline = time.monotonic() + settings.run_step_pause_ms / 1000
            while time.monotonic() < deadline and not self.cancellation.is_cancelled:
                time.sleep(0.05)

    @staticmethod
    def _replay_step(node: FlowNode, previous: AgentRunStep, variables: dict[str, Any]) -> None:
        """Restore a finished step's state exactly as a live run left it.

        Pausing drops `__` variables, so a condition's decision is restored from
        its output; without it, routing would silently take the wrong branch.
        Shared by both runtimes so a resumed run replays identically on either.
        """
        if node.node_type == "condition":
            variables[f"__condition__{node.key}"] = bool((previous.output or {}).get("result"))
        elif previous.output:
            for alias in _variable_aliases(previous.agent_key or "") | _variable_aliases(node.key):
                variables[alias] = previous.output

    def _next_nodes(
        self, graph: FlowGraph, node: FlowNode, variables: dict[str, Any], run: AgentRun
    ) -> list[str]:
        """Follow outgoing edges, honouring branch conditions."""
        targets: list[str] = []
        edges = graph.outgoing(node.key)

        if node.node_type == "condition":
            decision = variables.get(f"__condition__{node.key}")
            branch = "true" if decision else "false"
            matched = [edge for edge in edges if (edge.branch_label or "true").lower() == branch]
            if not matched and decision:
                matched = [edge for edge in edges if edge.branch_label is None]
            return [edge.target for edge in matched]

        for edge in edges:
            if edge.condition_expression and not evaluate_condition(edge.condition_expression, variables):
                self._log(
                    run,
                    "edge_skipped",
                    f"Path {edge.source} -> {edge.target} skipped; condition not met.",
                    {"condition": edge.condition_expression},
                )
                continue
            targets.append(edge.target)
        return targets

    # ------------------------------------------------------------------
    # Node execution
    # ------------------------------------------------------------------
    def _execute_node(
        self,
        run: AgentRun,
        flow: AgentFlow,
        graph: FlowGraph,
        node: FlowNode,
        sequence: int,
        project: Project,
        environment: Environment | None,
        variables: dict[str, Any],
    ) -> str:
        if node.node_type in {"start", "end"}:
            return "continue"

        if node.node_type == "condition":
            return self._execute_condition_node(run, node, sequence, variables)

        if node.node_type == "approval":
            return self._execute_approval_node(run, node, sequence, project, variables)

        if node.node_type in {"parallel", "join", "loop"}:
            step = self._create_step(run, node, sequence)
            self._complete_step(step, status="succeeded", summary=f"{node.node_type.title()} node passed through.")
            return "continue"

        if node.node_type == "tool":
            return self._execute_tool_node(run, node, sequence, project, environment, variables)

        if node.node_type == "agent":
            definition = self.session.get(Agent, node.agent_id) if node.agent_id else None
            if definition is None:
                step = self._create_step(run, node, sequence)
                self._complete_step(step, status="failed", error=f"Agent for node '{node.label}' was not found.")
                return "stop_flow" if node.on_failure == "fail_flow" else "continue"

            # A step paused for approval resumes in place instead of being duplicated.
            step = self._awaiting_step(run, node.key) or self._create_step(
                run, node, sequence, agent_key=definition.key
            )
            agent_inputs = self._resolve_inputs(node, variables, run)
            gate = self._agent_approval_gate(run, node, step, definition, variables, agent_inputs)
            if gate == "awaiting_approval":
                return "awaiting_approval"
            if gate == "rejected":
                return "stop_flow"

            result = self._run_agent_node(
                run, node, step, definition, project, environment, variables, agent_inputs
            )

            if step.status == "awaiting_approval":
                return "awaiting_approval"
            if self.cancellation.is_cancelled:
                return "cancelled"

            if result is None or not result.succeeded:
                if node.on_failure == "continue":
                    self._log(run, "node_failure_ignored", f"Node '{node.label}' failed; flow continues by policy.", {})
                    return "continue"
                if node.on_failure == "skip_branch":
                    return "stop_branch"
                return "stop_flow"

            # Results are addressable three ways: by agent key, by node key, and
            # by an underscored alias. Agent keys contain hyphens, which a
            # condition expression would otherwise parse as subtraction.
            payload = result.to_dict()
            for alias in _variable_aliases(definition.key) | _variable_aliases(node.key):
                variables[alias] = payload
            if node.output_mapping:
                variables.update(apply_mapping(node.output_mapping, {**variables, "result": result.to_dict()}))
            return "continue"

        return "continue"

    def _execute_condition_node(
        self, run: AgentRun, node: FlowNode, sequence: int, variables: dict[str, Any]
    ) -> str:
        step = self._create_step(run, node, sequence)
        expression = node.condition_expression or node.config.get("expression")
        try:
            decision = evaluate_condition(expression, variables)
            error = None
        except Exception as exc:  # noqa: BLE001
            decision, error = False, str(exc)[:300]

        variables[f"__condition__{node.key}"] = decision
        step.output = {"expression": expression, "result": decision}
        step.reasoning_summary = (
            f"Evaluated '{expression}' against run state; result was {decision}."
            if expression
            else "No condition expression; defaulted to the true branch."
        )
        self._complete_step(
            step,
            status="failed" if error else "succeeded",
            error=error,
            summary=f"Condition evaluated to {decision}.",
        )
        self._log(
            run,
            "condition_evaluated",
            f"Condition '{node.label}' -> {decision}",
            {"expression": expression, "result": decision},
        )
        return "continue"

    def _execute_approval_node(
        self,
        run: AgentRun,
        node: FlowNode,
        sequence: int,
        project: Project,
        variables: dict[str, Any],
    ) -> str:
        """Create an approval request and pause, or resume when already decided."""
        existing = self.session.execute(
            select(ApprovalRequest).where(
                ApprovalRequest.run_id == run.id, ApprovalRequest.subject_ref == node.key
            )
        ).scalar_one_or_none()

        if existing is not None and existing.status == "approved":
            step = next(
                (item for item in self._steps(run) if item.node_key == node.key), None
            ) or self._create_step(run, node, sequence)
            step.output = {"approval": "approved", "decided_by": existing.decided_by}
            self._complete_step(step, status="succeeded", summary=f"Approved by {existing.decided_by}.")
            variables[f"__approval__{node.key}"] = True
            return "continue"

        if existing is not None and existing.status == "rejected":
            step = next(
                (item for item in self._steps(run) if item.node_key == node.key), None
            ) or self._create_step(run, node, sequence)
            step.output = {"approval": "rejected", "decided_by": existing.decided_by}
            self._complete_step(
                step, status="failed", error=f"Rejected by {existing.decided_by}: {existing.decision_notes or ''}"
            )
            variables[f"__approval__{node.key}"] = False
            return "stop_flow"

        step = self._create_step(run, node, sequence)
        approval = self.policy.request_approval(
            project_id=run.project_id,
            title=node.label,
            reason=node.config.get("reason") or f"Flow '{run.title}' requires approval at '{node.label}'.",
            risk_level=node.config.get("risk_level", "medium"),
            run_id=run.id,
            step_id=step.id,
            subject_type="flow_node",
            subject_ref=node.key,
            required_role=node.approval_role or "qe_lead",
            requested_by=run.triggered_by,
            context={"variables": {key: value for key, value in variables.items() if not key.startswith("_")}},
            proposed_action={"node": node.key, "label": node.label},
        )

        step.status = "awaiting_approval"
        step.policy_decision = {"approval_request_id": approval.id, "required_role": approval.required_role}
        self.session.flush()

        self._log(
            run,
            "approval_requested",
            f"Approval required at '{node.label}'.",
            {"approval_id": approval.id, "required_role": approval.required_role},
        )
        event_bus.publish(
            run_topic(run.id),
            "approval_required",
            {"run_id": run.id, "node_key": node.key, "approval_id": approval.id, "label": node.label},
        )
        return "awaiting_approval"

    def _execute_tool_node(
        self,
        run: AgentRun,
        node: FlowNode,
        sequence: int,
        project: Project,
        environment: Environment | None,
        variables: dict[str, Any],
    ) -> str:
        step = self._create_step(run, node, sequence)
        server = node.config.get("server")
        tool = node.config.get("tool")
        arguments = apply_mapping(node.input_mapping, variables) if node.input_mapping else node.config.get("arguments", {})

        if not server or not tool:
            self._complete_step(step, status="failed", error="Tool node is missing a server or tool name.")
            return "stop_flow" if node.on_failure == "fail_flow" else "continue"

        ctx = self._agent_context(run, node, step, project, environment, variables)
        try:
            result = ctx.mcp.invoke(server, tool, arguments, approval_granted=True)
            step.tool_calls = [result.to_dict()]
            step.output = {"data": result.data}
            variables[node.key] = {"tool": f"{server}.{tool}", "data": result.data}
            self._complete_step(
                step,
                status="succeeded" if result.success else "failed",
                error=result.error,
                summary=f"Tool {server}.{tool} {'succeeded' if result.success else 'failed'}.",
            )
            return "continue" if result.success or node.on_failure != "fail_flow" else "stop_flow"
        except PolicyViolationError as exc:
            self._complete_step(step, status="failed", error=exc.message)
            return "stop_flow" if node.on_failure == "fail_flow" else "continue"

    def _run_agent_node(
        self,
        run: AgentRun,
        node: FlowNode,
        step: AgentRunStep,
        definition: Agent,
        project: Project,
        environment: Environment | None,
        variables: dict[str, Any],
        agent_inputs: dict[str, Any],
    ) -> AgentResult | None:
        """Execute one agent with retry and timeout policy applied."""
        agent = build_agent(definition)
        retry_policy = node.retry_policy or definition.retry_policy or {}
        max_attempts = max(1, int(retry_policy.get("max_attempts", 1)))
        backoff_seconds = float(retry_policy.get("backoff_seconds", 1.0))
        timeout_seconds = node.timeout_seconds or definition.timeout_seconds or 120

        step.status = "running"
        step.started_at = datetime.now(UTC)
        step.inputs = agent_inputs
        self.session.flush()
        # A failed attempt rolls back to here, never past the steps before it.
        self._checkpoint()

        event_bus.publish(
            run_topic(run.id),
            "step_started",
            {
                "run_id": run.id,
                "step_id": step.id,
                "node_key": node.key,
                "label": node.label,
                "agent_key": definition.key,
                "sequence": step.sequence,
            },
        )

        last_error: str | None = None
        for attempt in range(1, max_attempts + 1):
            if self.cancellation.is_cancelled:
                self._complete_step(step, status="cancelled", error="Run cancelled.")
                return None

            step.attempt = attempt
            started = time.perf_counter()
            ctx = self._agent_context(run, node, step, project, environment, variables)

            try:
                result = agent.execute(ctx, agent_inputs)
            except PolicyViolationError as exc:
                if exc.details.get("requires_approval"):
                    # Governance demanded a human before this agent may run.
                    self._request_agent_approval(
                        run, node, step, definition, agent_inputs, reason=exc.message, policy=exc.details.get("policy")
                    )
                    return None

                self._complete_step(step, status="failed", error=exc.message)
                step.policy_decision = exc.details.get("policy", {"effect": "deny", "reasons": [exc.message]})
                self.session.flush()
                return None

            except Exception as exc:  # noqa: BLE001
                last_error = str(exc)[:800]
                elapsed = time.perf_counter() - started
                self.session.rollback()
                # Re-attach the step after the rollback so state stays coherent.
                step = self.session.get(AgentRunStep, step.id)
                logger.warning(
                    "agent_step_attempt_failed",
                    run_id=run.id,
                    node=node.key,
                    attempt=attempt,
                    error=last_error,
                )
                self._log(
                    run,
                    "step_retry" if attempt < max_attempts else "step_failed",
                    f"'{node.label}' attempt {attempt} failed: {last_error}",
                    {"attempt": attempt, "node_key": node.key},
                )
                if attempt < max_attempts:
                    time.sleep(min(backoff_seconds * attempt, 5.0))
                    continue
                self._complete_step(step, status="failed", error=last_error)
                return None

            duration_ms = int((time.perf_counter() - started) * 1000)
            if duration_ms > timeout_seconds * 1000:
                logger.warning("agent_step_exceeded_timeout", node=node.key, duration_ms=duration_ms)

            self._apply_result(run, step, result)
            return result

        self._complete_step(step, status="failed", error=last_error or "Agent execution failed.")
        return None

    # ------------------------------------------------------------------
    # Approvals for agent steps
    # ------------------------------------------------------------------
    def _approval_for(self, run: AgentRun, node_key: str) -> ApprovalRequest | None:
        """The most recent approval request raised for this node in this run."""
        return (
            self.session.execute(
                select(ApprovalRequest)
                .where(ApprovalRequest.run_id == run.id, ApprovalRequest.subject_ref == node_key)
                .order_by(ApprovalRequest.created_at.desc())
            )
            .scalars()
            .first()
        )

    def _awaiting_step(self, run: AgentRun, node_key: str) -> AgentRunStep | None:
        return next(
            (step for step in self._steps(run) if step.node_key == node_key and step.status == "awaiting_approval"),
            None,
        )

    def _agent_approval_gate(
        self,
        run: AgentRun,
        node: FlowNode,
        step: AgentRunStep,
        definition: Agent,
        variables: dict[str, Any],
        agent_inputs: dict[str, Any],
    ) -> str:
        """Decide whether an agent step may run: `run`, `rejected` or `awaiting_approval`.

        Approval is demanded either by the flow node itself or, at run time, by
        governance policy. On resume the recorded decision is looked up and handed
        to the agent, so an approved step runs rather than asking again.
        """
        approval = self._approval_for(run, node.key)
        if approval is not None:
            if approval.status == "approved":
                variables[f"__approval__{node.key}"] = True
                return "run"
            if approval.status == "rejected":
                self._complete_step(
                    step,
                    status="failed",
                    error=f"Rejected by {approval.decided_by}: {approval.decision_notes or 'no reason given'}",
                )
                return "rejected"
            step.status = "awaiting_approval"
            self.session.flush()
            return "awaiting_approval"

        if node.requires_approval:
            self._request_agent_approval(
                run,
                node,
                step,
                definition,
                agent_inputs,
                reason=f"'{node.label}' is configured to require human approval before it runs.",
            )
            return "awaiting_approval"
        return "run"

    def _request_agent_approval(
        self,
        run: AgentRun,
        node: FlowNode,
        step: AgentRunStep,
        definition: Agent,
        agent_inputs: dict[str, Any],
        *,
        reason: str,
        policy: dict[str, Any] | None = None,
    ) -> None:
        approval = self.policy.request_approval(
            project_id=run.project_id,
            title=f"Approve {definition.name}",
            reason=reason,
            risk_level=definition.risk_level,
            run_id=run.id,
            step_id=step.id,
            subject_type="agent",
            subject_ref=node.key,
            required_role=node.approval_role or "qe_lead",
            requested_by=run.triggered_by,
            context={"inputs": agent_inputs},
            proposed_action={"agent": definition.key, "node": node.key},
        )
        step.status = "awaiting_approval"
        step.inputs = agent_inputs
        step.policy_decision = {"approval_request_id": approval.id, "reason": reason, **(policy or {})}
        self.session.flush()
        self._log(
            run,
            "approval_requested",
            f"Approval required before '{node.label}'.",
            {"approval_id": approval.id, "required_role": approval.required_role},
        )
        event_bus.publish(
            run_topic(run.id),
            "approval_required",
            {"run_id": run.id, "node_key": node.key, "approval_id": approval.id, "label": definition.name},
        )

    # ------------------------------------------------------------------
    # State helpers
    # ------------------------------------------------------------------
    def _agent_context(
        self,
        run: AgentRun,
        node: FlowNode,
        step: AgentRunStep,
        project: Project,
        environment: Environment | None,
        variables: dict[str, Any],
    ) -> AgentContext:
        approval_granted = bool(variables.get(f"__approval__{node.key}")) or bool(
            variables.get("__approval_granted__")
        )
        return AgentContext(
            session=self.session,
            project=project,
            environment=environment,
            run_id=run.id,
            step_id=step.id,
            node_key=node.key,
            actor=run.triggered_by or "system",
            variables=variables,
            node_config={"llm_config": node.llm_config, **node.config, "cost_limit_usd": node.cost_limit_usd},
            correlation_id=run.correlation_id,
            approval_granted=approval_granted,
        )

    def _resolve_inputs(self, node: FlowNode, variables: dict[str, Any], run: AgentRun) -> dict[str, Any]:
        """Node input mapping first, then run inputs, then flow variables."""
        resolved: dict[str, Any] = {}
        resolved.update({key: value for key, value in (run.inputs or {}).items()})
        if node.input_mapping:
            resolved.update(apply_mapping(node.input_mapping, variables))
        resolved.update({key: value for key, value in node.config.get("inputs", {}).items()})
        return {key: value for key, value in resolved.items() if value is not None}

    def _create_step(
        self, run: AgentRun, node: FlowNode, sequence: int, agent_key: str | None = None
    ) -> AgentRunStep:
        step = AgentRunStep(
            run_id=run.id,
            node_key=node.key,
            node_type=node.node_type,
            agent_id=node.agent_id,
            agent_key=agent_key,
            agent_version=node.agent_version,
            label=node.label,
            sequence=sequence,
            status="pending",
        )
        self.session.add(step)
        self.session.flush()
        return step

    def _apply_result(self, run: AgentRun, step: AgentRunStep, result: AgentResult) -> None:
        step.output = result.to_dict()
        step.reasoning_summary = result.reasoning_summary
        step.evidence = result.evidence
        step.tool_calls = result.tool_calls
        step.artifacts = result.artifacts
        step.confidence = result.confidence
        step.policy_decision = result.policy_decision
        step.provider = result.provider
        step.model = result.model
        step.deployment = result.deployment
        step.prompt_tokens = result.prompt_tokens
        step.completion_tokens = result.completion_tokens
        step.total_tokens = result.total_tokens
        step.cost_usd = result.cost_usd

        run.prompt_tokens += result.prompt_tokens
        run.completion_tokens += result.completion_tokens
        run.total_tokens += result.total_tokens
        run.total_cost_usd = round(run.total_cost_usd + result.cost_usd, 6)

        self._complete_step(step, status="succeeded", summary=result.summary)

    def _complete_step(
        self,
        step: AgentRunStep,
        *,
        status: str,
        error: str | None = None,
        summary: str | None = None,
    ) -> None:
        step.status = status
        step.error = error
        step.finished_at = datetime.now(UTC)
        if step.started_at:
            step.duration_ms = int(
                (step.finished_at - step.started_at.replace(tzinfo=UTC)).total_seconds() * 1000
            )
        self.session.flush()

        run = self.session.get(AgentRun, step.run_id)
        # Progress is reported against the flow's agent steps, so only those count.
        if run is not None and status in {"succeeded", "skipped"} and step.node_type == "agent":
            run.completed_step_count += 1
            self.session.flush()
        self._checkpoint()

        event_bus.publish(
            run_topic(step.run_id),
            "step_completed",
            {
                "run_id": step.run_id,
                "step_id": step.id,
                "node_key": step.node_key,
                "label": step.label,
                "status": status,
                "summary": summary,
                "confidence": step.confidence,
                "duration_ms": step.duration_ms,
                "cost_usd": step.cost_usd,
                "error": error,
            },
        )

    def _start_run(self, run: AgentRun, step_count: int = 0) -> None:
        run.status = "running"
        # A resumed run keeps its original start, so duration spans the whole run.
        run.started_at = run.started_at or datetime.now(UTC)
        if step_count:
            run.step_count = step_count
        self.session.flush()
        self._checkpoint()
        event_bus.publish(
            run_topic(run.id),
            "run_started",
            {"run_id": run.id, "title": run.title, "step_count": run.step_count},
        )

    def _finish_run(self, run: AgentRun, status: str, variables: dict[str, Any]) -> None:
        run.status = status
        run.finished_at = datetime.now(UTC)
        if run.started_at:
            run.duration_ms = int(
                (run.finished_at - run.started_at.replace(tzinfo=UTC)).total_seconds() * 1000
            )
        run.variables = {key: value for key, value in variables.items() if not key.startswith("__")}
        run.outputs = self._collect_outputs(run)
        run.summary = self._summarize(run, status, self._steps(run))
        self.session.flush()

        self._log(run, "flow_finished", run.summary, {"status": status})
        self._checkpoint()
        event_bus.publish(
            run_topic(run.id),
            "run_completed",
            {
                "run_id": run.id,
                "status": status,
                "summary": run.summary,
                "duration_ms": run.duration_ms,
                "total_cost_usd": run.total_cost_usd,
                "total_tokens": run.total_tokens,
            },
        )
        self.audit.record(
            action="flow.run",
            entity_type="agent_run",
            entity_id=run.id,
            entity_label=run.title,
            actor=run.triggered_by or "system",
            project_id=run.project_id,
            outcome="success" if status in {"succeeded", "partially_succeeded"} else "failure",
            reason=run.summary,
            output_summary={"status": status, "steps": run.completed_step_count, "cost_usd": run.total_cost_usd},
            run_id=run.id,
        )
        self._flow_alerts(run, status)
        self._checkpoint()

    def _pause_run(self, run: AgentRun, variables: dict[str, Any]) -> None:
        run.status = "awaiting_approval"
        run.variables = {key: value for key, value in variables.items() if not key.startswith("__")}
        run.resume_token = run.id
        run.summary = "Paused: waiting for human approval."
        self.session.flush()
        self._checkpoint()
        event_bus.publish(
            run_topic(run.id), "run_paused", {"run_id": run.id, "status": "awaiting_approval"}
        )

    def _fail_run(self, run: AgentRun, error: str) -> None:
        run.status = "failed"
        run.error = error
        run.finished_at = datetime.now(UTC)
        run.summary = f"Run failed: {error[:300]}"
        if run.started_at:
            run.duration_ms = int(
                (run.finished_at - run.started_at.replace(tzinfo=UTC)).total_seconds() * 1000
            )
        self.session.flush()
        self._log(run, "flow_failed", run.summary, {"error": error[:500]})
        self._flow_alerts(run, "failed")
        self._checkpoint()
        event_bus.publish(run_topic(run.id), "run_failed", {"run_id": run.id, "error": error[:500]})

    def _flow_alerts(self, run: AgentRun, status: str) -> None:
        """Apply the flow's own governance settings: failure and budget notifications."""
        flow = self.session.get(AgentFlow, run.flow_id) if run.flow_id else None
        if flow is None:
            return
        governance = {"notify_on_failure": True, "budget_alert_percent": 80, **(flow.governance or {})}
        link = f"/flows/{flow.id}/runs"

        if status == "failed" and governance.get("notify_on_failure"):
            self.session.add(
                Notification(
                    project_id=run.project_id,
                    title=f"{flow.name}: run #{run.run_number} failed",
                    message=(run.error or run.summary or "The run failed.")[:500],
                    category="flow",
                    severity="error",
                    link=link,
                    payload={"flow_id": flow.id, "run_id": run.id, "owner": flow.owner},
                )
            )

        percent = float(governance.get("budget_alert_percent") or 0)
        if flow.cost_budget_usd and percent and run.total_cost_usd >= flow.cost_budget_usd * percent / 100:
            used = round(run.total_cost_usd / flow.cost_budget_usd * 100)
            self.session.add(
                Notification(
                    project_id=run.project_id,
                    title=f"{flow.name}: run #{run.run_number} used {used}% of its budget",
                    message=(
                        f"The run cost €{run.total_cost_usd:.2f} against a €{flow.cost_budget_usd:.2f} budget "
                        f"(alert at {percent:.0f}%)."
                    ),
                    category="budget",
                    severity="warning",
                    link=link,
                    payload={"flow_id": flow.id, "run_id": run.id, "owner": flow.owner},
                )
            )
            self.audit.record(
                action="flow.budget_alert",
                entity_type="agent_flow",
                entity_id=flow.id,
                entity_label=flow.name,
                project_id=run.project_id,
                outcome="warning",
                severity="warning",
                reason=f"Run #{run.run_number} used {used}% of the per-run budget.",
                run_id=run.id,
            )
        self.session.flush()

    def _collect_outputs(self, run: AgentRun) -> dict[str, Any]:
        outputs: dict[str, Any] = {}
        for step in self._steps(run):
            if step.status == "succeeded" and step.output:
                outputs[step.agent_key or step.node_key] = step.output
        return outputs

    @staticmethod
    def _summarize(run: AgentRun, status: str, steps: list[AgentRunStep]) -> str:
        succeeded = sum(1 for step in steps if step.status == "succeeded")
        failed = sum(1 for step in steps if step.status == "failed")
        parts = [f"{succeeded} step(s) succeeded"]
        if failed:
            parts.append(f"{failed} failed")
        parts.append(f"{run.total_tokens:,} tokens")
        parts.append(f"€{run.total_cost_usd:.4f}")
        return f"Run {status.replace('_', ' ')}: " + ", ".join(parts) + "."

    def _log(self, run: AgentRun, event_type: str, content: str, payload: dict[str, Any]) -> None:
        self._message_sequence += 1
        self.session.add(
            AgentMessage(
                run_id=run.id,
                role="system",
                event_type=event_type,
                content=content,
                payload=payload,
                sequence=self._message_sequence,
            )
        )
        self.session.flush()


def next_run_number(session: Session, project_id: str) -> int:
    current = session.execute(
        select(func.coalesce(func.max(AgentRun.run_number), 0)).where(AgentRun.project_id == project_id)
    ).scalar_one()
    return int(current) + 1
