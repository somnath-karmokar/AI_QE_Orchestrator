"""Authentication, password hashing and RBAC primitives (spec section 30).

Demo mode ships seeded users/roles; the contracts here (token issuance, role
resolution, project scoping) are the same ones an enterprise SSO/OIDC layer
would satisfy, so swapping in real identity does not touch call sites.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from app.core.time import UTC
from typing import Any

from app.core.config import settings
from app.core.errors import AuthenticationError, AuthorizationError

_PBKDF2_ROUNDS = 240_000

# ---------------------------------------------------------------------------
# Roles and permissions
# ---------------------------------------------------------------------------

PERMISSIONS: dict[str, set[str]] = {
    "admin": {"*"},
    "qe_lead": {
        "project:read", "project:write",
        "agent:read", "agent:write", "agent:publish",
        "flow:read", "flow:write", "flow:run",
        "run:read", "run:cancel",
        "test:read", "test:write",
        "execution:read", "execution:write",
        "defect:read", "defect:write",
        "knowledge:read", "knowledge:write",
        "governance:read", "approval:decide",
        "report:read",
    },
    "qe_engineer": {
        "project:read",
        "agent:read", "agent:write",
        "flow:read", "flow:write", "flow:run",
        "run:read", "run:cancel",
        "test:read", "test:write",
        "execution:read", "execution:write",
        "defect:read", "defect:write",
        "knowledge:read",
        "report:read",
    },
    "business_user": {
        "project:read", "agent:read", "flow:read", "run:read",
        "test:read", "execution:read", "defect:read", "knowledge:read", "report:read",
        "approval:decide",
    },
    "viewer": {
        "project:read", "agent:read", "flow:read", "run:read",
        "test:read", "execution:read", "defect:read", "knowledge:read", "report:read",
    },
}

ROLE_LABELS = {
    "admin": "Platform Administrator",
    "qe_lead": "QE Lead",
    "qe_engineer": "QE Engineer",
    "business_user": "Business / UAT User",
    "viewer": "Viewer",
}


@dataclass
class Principal:
    """The authenticated caller, resolved from a bearer token."""

    user_id: str
    email: str
    full_name: str
    role: str
    permissions: set[str] = field(default_factory=set)

    def has_permission(self, permission: str) -> bool:
        return "*" in self.permissions or permission in self.permissions

    def require(self, permission: str) -> None:
        if not self.has_permission(permission):
            raise AuthorizationError(
                f"Role {self.role} is not permitted to perform {permission}.",
                details={"required_permission": permission, "role": self.role},
            )


def permissions_for_role(role: str) -> set[str]:
    return set(PERMISSIONS.get(role, PERMISSIONS["viewer"]))


# ---------------------------------------------------------------------------
# Password hashing (PBKDF2-HMAC-SHA256, stdlib only)
# ---------------------------------------------------------------------------


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _PBKDF2_ROUNDS)
    return "$".join(["pbkdf2_sha256", str(_PBKDF2_ROUNDS), salt.hex(), digest.hex()])


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, rounds, salt_hex, digest_hex = stored.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        expected = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds))
        return hmac.compare_digest(expected.hex(), digest_hex)
    except (ValueError, AttributeError):
        return False


# ---------------------------------------------------------------------------
# API trigger tokens
# ---------------------------------------------------------------------------


def hash_api_token(token: str) -> str:
    """Keyed hash for a random API token.

    Tokens are 192 bits of randomness, so a slow password KDF adds nothing;
    the server secret as HMAC key means a leaked database alone cannot be used
    to check guesses.
    """
    return hmac.new(settings.jwt_secret.encode(), token.encode(), hashlib.sha256).hexdigest()


def verify_api_token(token: str, stored_hash: str | None) -> bool:
    if not token or not stored_hash:
        return False
    return hmac.compare_digest(hash_api_token(token), stored_hash)


# ---------------------------------------------------------------------------
# JWT (HS256)
# ---------------------------------------------------------------------------


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def create_access_token(claims: dict[str, Any], expires_minutes: int | None = None) -> str:
    expiry = datetime.now(UTC) + timedelta(minutes=expires_minutes or settings.jwt_expiry_minutes)
    payload = {**claims, "exp": int(expiry.timestamp()), "iat": int(datetime.now(UTC).timestamp())}
    header = {"alg": "HS256", "typ": "JWT"}
    segments = [
        _b64url_encode(json.dumps(header, separators=(",", ":")).encode()),
        _b64url_encode(json.dumps(payload, separators=(",", ":"), default=str).encode()),
    ]
    signing_input = ".".join(segments).encode()
    signature = hmac.new(settings.jwt_secret.encode(), signing_input, hashlib.sha256).digest()
    segments.append(_b64url_encode(signature))
    return ".".join(segments)


def decode_access_token(token: str) -> dict[str, Any]:
    try:
        header_b64, payload_b64, signature_b64 = token.split(".")
    except ValueError as exc:
        raise AuthenticationError("Malformed authentication token.") from exc

    signing_input = f"{header_b64}.{payload_b64}".encode()
    expected = hmac.new(settings.jwt_secret.encode(), signing_input, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, _b64url_decode(signature_b64)):
        raise AuthenticationError("Invalid token signature.")

    payload = json.loads(_b64url_decode(payload_b64))
    if payload.get("exp", 0) < int(datetime.now(UTC).timestamp()):
        raise AuthenticationError("Authentication token has expired.")
    return payload


def principal_from_token(token: str) -> Principal:
    payload = decode_access_token(token)
    role = payload.get("role", "viewer")
    return Principal(
        user_id=str(payload.get("sub", "")),
        email=payload.get("email", ""),
        full_name=payload.get("name", ""),
        role=role,
        permissions=permissions_for_role(role),
    )


# ---------------------------------------------------------------------------
# PII masking hooks (spec sections 18 and 30)
# ---------------------------------------------------------------------------

_PII_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("EMAIL", re.compile(r"[\w\.\-\+]+@[\w\-]+\.[\w\.\-]+")),
    ("CARD", re.compile(r"\b(?:\d[ -]*?){13,16}\b")),
    ("IBAN", re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
]


def mask_pii(text: str) -> str:
    """Replace obvious PII with typed placeholders before it reaches an LLM or log."""
    if not text:
        return text
    masked = text
    for label, pattern in _PII_PATTERNS:
        masked = pattern.sub("[REDACTED_" + label + "]", masked)
    return masked


_SECRET_MARKERS = (
    "api_key",
    "password",
    "passphrase",
    "secret",
    "token",
    "credential",
    "connection_string",
    "authorization",
    "private_key",
    "access_key",
)


def redact_secrets(payload: Any) -> Any:  # noqa: ANN401
    """Never return secret values to the browser (spec section 21).

    Recurses through lists as well as dicts. It used to stop at a list, so a
    secret one level inside one -- `{"deployments": [{"api_key": ...}]}` --
    came back whole. No payload has that shape today, which is precisely why
    it was worth fixing: this is the control that is supposed to hold whatever
    shape the payload takes next.
    """
    if isinstance(payload, dict):
        redacted: dict[str, Any] = {}
        for key, value in payload.items():
            if any(marker in key.lower() for marker in _SECRET_MARKERS):
                redacted[key] = "********" if value else None
            else:
                redacted[key] = redact_secrets(value)
        return redacted
    if isinstance(payload, list):
        return [redact_secrets(item) for item in payload]
    if isinstance(payload, tuple):
        return tuple(redact_secrets(item) for item in payload)
    return payload
