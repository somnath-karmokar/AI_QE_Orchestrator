"""UTC constant, importable regardless of Python version.

`datetime.UTC` only exists from Python 3.11 (this project's declared floor --
`pyproject.toml` has `requires-python = ">=3.11"`) -- but a server whose
interpreter is older hits `ImportError: cannot import name 'UTC' from
'datetime'` before anything else even runs. `timezone.utc` is the exact same
object `datetime.UTC` aliases to on 3.11+ (`datetime.UTC is
datetime.timezone.utc` is `True`) and has existed since Python 3.2, so every
module in this codebase imports `UTC` from here instead of straight from
`datetime` -- it costs nothing on a modern interpreter and works on an older
one too.
"""

from datetime import timezone

UTC = timezone.utc
