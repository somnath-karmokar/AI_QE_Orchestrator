"""In-process publish/subscribe bus used to stream run events to the UI.

The orchestrator emits events synchronously from worker threads; WebSocket and
SSE endpoints subscribe per run (or globally) and forward them to the browser.
A bounded replay buffer lets a client that connects mid-run catch up.
"""

from __future__ import annotations

import asyncio
import threading
from collections import defaultdict, deque
from datetime import datetime
from app.core.time import UTC
from typing import Any

from app.core.logging import get_logger

logger = get_logger(__name__)

GLOBAL_TOPIC = "*"
_REPLAY_SIZE = 400


class EventBus:
    """Thread-safe fan-out bus bridging sync workers to async consumers."""

    def __init__(self) -> None:
        self._subscribers: dict[str, list[asyncio.Queue]] = defaultdict(list)
        self._replay: dict[str, deque[dict[str, Any]]] = defaultdict(lambda: deque(maxlen=_REPLAY_SIZE))
        self._lock = threading.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Called once at startup so worker threads can hand events to the loop."""
        self._loop = loop

    # ----- publishing --------------------------------------------------------
    def publish(self, topic: str, event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
        event = {
            "topic": topic,
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "payload": payload,
        }
        with self._lock:
            self._replay[topic].append(event)
            queues = list(self._subscribers.get(topic, [])) + list(self._subscribers.get(GLOBAL_TOPIC, []))
        for queue in queues:
            self._deliver(queue, event)
        return event

    def _deliver(self, queue: asyncio.Queue, event: dict[str, Any]) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            loop.call_soon_threadsafe(queue.put_nowait, event)
        except RuntimeError:  # pragma: no cover - loop shutting down
            logger.debug("event_drop", topic=event["topic"], type=event["type"])

    # ----- subscribing -------------------------------------------------------
    def subscribe(self, topic: str, *, replay: bool = True) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(maxsize=1000)
        with self._lock:
            self._subscribers[topic].append(queue)
            history = list(self._replay.get(topic, [])) if replay else []
        for event in history:
            queue.put_nowait(event)
        return queue

    def unsubscribe(self, topic: str, queue: asyncio.Queue) -> None:
        with self._lock:
            if queue in self._subscribers.get(topic, []):
                self._subscribers[topic].remove(queue)

    def history(self, topic: str) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._replay.get(topic, []))

    def clear(self, topic: str) -> None:
        with self._lock:
            self._replay.pop(topic, None)


event_bus = EventBus()


def run_topic(run_id: str) -> str:
    return f"run:{run_id}"


def execution_topic(execution_id: str) -> str:
    return f"execution:{execution_id}"
