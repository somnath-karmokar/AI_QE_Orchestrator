"""Policy engine and audit trail (spec section 18).

Policies are database rows, not code. Each evaluation returns a decision that is
attached to the run step and written to the audit log, so every AI action can be
answered for: who, what, when, why, input, output, tool, model, confidence and
policy result.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from app.core.time import UTC
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_correlation_id, get_logger
from app.models.governance import ApprovalRequest, AuditLog, GovernancePolicy

logger = get_logger(__name__)

EFFECT_ORDER = {"deny": 3, "require_approval": 2, "warn": 1, "allow": 0}


@dataclass(slots=True)
class PolicyContext:
    """Everything a policy can match on."""

    action: str
    project_id: str | None = None
    agent_key: str | None = None
    agent_id: str | None = None
    risk_level: str = "low"
    tool: str | None = None
    mcp_server: str | None = None
    environment_key: str | None = None
    environment_is_production_like: bool = False
    model: str | None = None
    provider: str | None = None
    estimated_cost_usd: float = 0.0
    confidence: float | None = None
    mutating: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_match_values(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "agent_key": self.agent_key,
            "risk_level": self.risk_level,
            "tool": self.tool,
            "mcp_server": self.mcp_server,
            "environment_key": self.environment_key,
            "model": self.model,
            "provider": self.provider,
            "mutating": self.mutating,
            "environment_is_production_like": self.environment_is_production_like,
        }


@dataclass(slots=True)
class PolicyDecision:
    effect: str  # allow | warn | require_approval | deny
    reasons: list[str] = field(default_factory=list)
    matched_policies: list[dict[str, Any]] = field(default_factory=list)

    @property
    def allowed(self) -> bool:
        return self.effect in {"allow", "warn"}

    @property
    def requires_approval(self) -> bool:
        return self.effect == "require_approval"

    def to_dict(self) -> dict[str, Any]:
        return {
            "effect": self.effect,
            "allowed": self.allowed,
            "requires_approval": self.requires_approval,
            "reasons": self.reasons,
            "matched_policies": self.matched_policies,
            "evaluated_at": datetime.now(UTC).isoformat(),
        }


class PolicyEngine:
    """Evaluates governance policies for a single session."""

    def __init__(self, session: Session) -> None:
        self.session = session

    def _applicable_policies(self, project_id: str | None) -> list[GovernancePolicy]:
        rows = list(
            self.session.execute(
                select(GovernancePolicy)
                .where(GovernancePolicy.is_enabled.is_(True))
                .order_by(GovernancePolicy.priority.asc())
            )
            .scalars()
            .all()
        )
        # A project-scoped policy applies only to its project; global policies
        # (project_id is NULL) apply everywhere.
        return [policy for policy in rows if policy.project_id in (None, project_id)]

    @staticmethod
    def _matches(policy: GovernancePolicy, context: PolicyContext) -> bool:
        conditions = policy.conditions or {}
        if not conditions:
            return True
        values = context.as_match_values()
        for key, expected in conditions.items():
            actual = values.get(key, context.metadata.get(key))
            if isinstance(expected, list):
                if actual not in expected:
                    return False
            elif isinstance(expected, dict):
                if "min" in expected and (actual is None or actual < expected["min"]):
                    return False
                if "max" in expected and (actual is None or actual > expected["max"]):
                    return False
            elif actual != expected:
                return False
        return True

    def evaluate(self, context: PolicyContext) -> PolicyDecision:
        """Return the strongest effect among all matching policies."""
        decision = PolicyDecision(effect="allow")

        # Baseline rule from configuration: high-risk actions need a human.
        if context.risk_level in settings.approval_required_risk_levels:
            decision.effect = "require_approval"
            decision.reasons.append(
                f"Risk level '{context.risk_level}' requires human approval by platform policy."
            )

        for policy in self._applicable_policies(context.project_id):
            if not self._matches(policy, context):
                continue

            effect = policy.effect
            # Cost-limit policies only bite when the projected spend exceeds them.
            if policy.policy_type == "cost_limit":
                limit = float((policy.parameters or {}).get("max_cost_usd", 0) or 0)
                if limit and context.estimated_cost_usd <= limit:
                    continue

            decision.matched_policies.append(
                {
                    "id": policy.id,
                    "key": policy.key,
                    "name": policy.name,
                    "type": policy.policy_type,
                    "effect": effect,
                    "severity": policy.severity,
                }
            )
            if effect != "allow":
                decision.reasons.append(f"{policy.name}: {policy.description or effect}")
            if EFFECT_ORDER.get(effect, 0) > EFFECT_ORDER.get(decision.effect, 0):
                decision.effect = effect

            policy.enforcement_count += 1
            policy.last_enforced_at = datetime.now(UTC)

        self.session.flush()
        if decision.effect != "allow":
            logger.info(
                "policy_decision",
                action=context.action,
                effect=decision.effect,
                agent=context.agent_key,
                tool=context.tool,
            )
        return decision

    # ----- approvals ---------------------------------------------------------
    def request_approval(
        self,
        *,
        project_id: str,
        title: str,
        reason: str,
        risk_level: str = "medium",
        run_id: str | None = None,
        step_id: str | None = None,
        subject_type: str = "flow_node",
        subject_ref: str | None = None,
        required_role: str = "qe_lead",
        requested_by: str | None = None,
        context: dict[str, Any] | None = None,
        proposed_action: dict[str, Any] | None = None,
        expires_in_hours: int = 48,
    ) -> ApprovalRequest:
        approval = ApprovalRequest(
            project_id=project_id,
            run_id=run_id,
            step_id=step_id,
            subject_type=subject_type,
            subject_ref=subject_ref,
            title=title,
            reason=reason,
            risk_level=risk_level,
            required_role=required_role,
            requested_by=requested_by,
            context=context or {},
            proposed_action=proposed_action or {},
            expires_at=datetime.now(UTC) + timedelta(hours=expires_in_hours),
            status="pending",
        )
        self.session.add(approval)
        self.session.flush()
        logger.info("approval_requested", approval_id=approval.id, title=title, risk=risk_level)
        return approval


class AuditService:
    """Append-only audit writer."""

    def __init__(self, session: Session) -> None:
        self.session = session

    def record(
        self,
        *,
        action: str,
        entity_type: str,
        entity_id: str | None = None,
        entity_label: str | None = None,
        actor: str = "system",
        actor_type: str = "system",
        project_id: str | None = None,
        reason: str | None = None,
        outcome: str = "success",
        severity: str = "info",
        input_summary: dict[str, Any] | None = None,
        output_summary: dict[str, Any] | None = None,
        tool_used: str | None = None,
        model_used: str | None = None,
        confidence: float | None = None,
        policy_result: dict[str, Any] | None = None,
        run_id: str | None = None,
    ) -> AuditLog:
        entry = AuditLog(
            project_id=project_id,
            actor=actor,
            actor_type=actor_type,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            entity_label=entity_label,
            reason=reason,
            outcome=outcome,
            severity=severity,
            input_summary=_truncate_payload(input_summary or {}),
            output_summary=_truncate_payload(output_summary or {}),
            tool_used=tool_used,
            model_used=model_used,
            confidence=confidence,
            policy_result=policy_result or {},
            run_id=run_id,
            correlation_id=get_correlation_id(),
        )
        self.session.add(entry)
        self.session.flush()
        return entry


def _truncate_payload(payload: dict[str, Any], max_chars: int = 1200) -> dict[str, Any]:
    """Keep audit rows compact; the full artifacts live on the run step."""
    truncated: dict[str, Any] = {}
    for key, value in payload.items():
        if isinstance(value, str) and len(value) > max_chars:
            truncated[key] = value[:max_chars] + f"... [truncated {len(value) - max_chars} chars]"
        elif isinstance(value, list) and len(value) > 20:
            truncated[key] = value[:20] + [f"... {len(value) - 20} more"]
        else:
            truncated[key] = value
    return truncated
