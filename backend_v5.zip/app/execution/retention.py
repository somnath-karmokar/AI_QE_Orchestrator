"""Evidence retention.

Traces, screenshots and DOM snapshots are large and stop being useful once the
failure they explain is closed. This removes evidence older than the configured
window, deleting the files as well as the rows -- a database that points at
files nobody kept is worse than no record at all.

`ARTIFACT_RETENTION_DAYS=0` keeps everything, for deployments whose retention is
governed elsewhere.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from app.core.time import UTC
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.models.testing import ExecutionArtifact, FailureEvidence

logger = get_logger(__name__)


def sweep_expired_evidence(session: Session, *, now: datetime | None = None) -> dict[str, int]:
    """Delete evidence past its retention window. Returns what it removed."""
    if settings.artifact_retention_days <= 0:
        return {"artifacts": 0, "evidence": 0, "files": 0, "bytes": 0}

    cutoff = (now or datetime.now(UTC)) - timedelta(days=settings.artifact_retention_days)
    removed_files = 0
    removed_bytes = 0

    artifacts = list(
        session.execute(select(ExecutionArtifact).where(ExecutionArtifact.created_at < cutoff))
        .scalars()
        .all()
    )
    for artifact in artifacts:
        removed_files, removed_bytes = _unlink(artifact.storage_path, removed_files, removed_bytes)
        session.delete(artifact)

    evidence = list(
        session.execute(select(FailureEvidence).where(FailureEvidence.created_at < cutoff))
        .scalars()
        .all()
    )
    for row in evidence:
        for path in (row.screenshot_path, row.trace_path):
            removed_files, removed_bytes = _unlink(path, removed_files, removed_bytes)
        session.delete(row)

    session.flush()
    summary = {
        "artifacts": len(artifacts),
        "evidence": len(evidence),
        "files": removed_files,
        "bytes": removed_bytes,
    }
    if artifacts or evidence:
        logger.info("evidence_retention_sweep", cutoff=cutoff.isoformat(), **summary)
    return summary


def _managed_roots() -> tuple[Path, ...]:
    return (
        Path(settings.tenant_storage_dir).resolve(),
        Path(settings.execution_artifacts_dir).resolve(),
    )


def _is_managed(candidate: Path) -> bool:
    """Is this a file the platform wrote, under a directory it owns?

    The sweep deletes whatever path a row holds, and those rows are written by
    several code paths. Confining deletion to the storage roots means a wrong or
    tampered path fails to match rather than removing something else on the
    filesystem -- the difference between a stale row and an arbitrary delete.
    """
    resolved = candidate.resolve()
    return any(resolved.is_relative_to(root) for root in _managed_roots())


def _unlink(path: str | None, count: int, total_bytes: int) -> tuple[int, int]:
    if not path:
        return count, total_bytes
    candidate = Path(path)
    try:
        if not _is_managed(candidate):
            logger.warning("evidence_file_outside_storage", path=path)
            return count, total_bytes
        if candidate.is_file():
            size = candidate.stat().st_size
            candidate.unlink()
            return count + 1, total_bytes + size
    except OSError as error:  # noqa: PERF203 - one bad path must not stop the sweep
        logger.warning("evidence_file_not_removed", path=path, error=str(error))
    return count, total_bytes
