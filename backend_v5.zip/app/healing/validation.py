"""Prove a heal by re-running the test it claims to fix.

The lifecycle this module owns:

    temporary patch -> re-run the failing test -> read the real result
        -> persist to the script (pass)  |  roll back (fail)

Nothing else in the platform may write `HealingRecord.result_after` or
`validated_at`. They mean "a re-run produced this", and a re-run is the only
thing that sets them.

The patch is *temporary by construction*: it is stored on the healing record and
handed to the execution as configuration. The test script on disk and in the
database is untouched until the re-run has passed, so a failed heal needs no
undo -- there is nothing to undo.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from app.core.time import UTC
from typing import Any

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import session_scope
from app.core.errors import NotFoundError
from app.core.logging import get_logger
from app.execution.service import ExecutionService
from app.governance.policy_engine import AuditService
from app.healing.config import HealingConfig, healing_config
from app.healing.knowledge import index_healing_outcome
from app.models.testing import ExecutionTest, HealingRecord, TestDataSet, TestScript

logger = get_logger(__name__)


@dataclass(slots=True)
class ValidationOutcome:
    """What the re-run actually showed."""

    status: str  # passed | failed | inconclusive
    mode: str  # simulated | playwright
    execution_id: str | None = None
    result: str | None = None  # the re-run's own test result
    evidence: list[dict[str, Any]] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.status == "passed"


def build_patch(record: HealingRecord) -> dict[str, Any]:
    """The reversible change this record proposes, in the shape the execution
    service applies at run time."""
    patch = {
        "healing_record_id": record.id,
        "change_type": record.change_type,
        "test_script_id": record.test_script_id,
        "execution_test_id": record.execution_test_id,
        "failure_class": record.failure_class,
        "from": record.original_locator,
        "to": record.proposed_locator,
        "strategy": record.locator_strategy,
        "created_at": datetime.now(UTC).isoformat(),
    }
    decision = record.policy_decision or {}
    # A timing change does not swap a locator; it changes how long the test is
    # willing to wait for the one it already has.
    if record.change_type == "timing" and decision.get("wait_ms"):
        patch["wait_ms"] = int(decision["wait_ms"])
        patch["locator"] = record.original_locator
    # A data change swaps the record the test runs against, and touches neither
    # the locator nor the wait.
    elif record.change_type == "test_data":
        patch["dataset_id"] = decision.get("dataset_id")
        patch["substitute_reference"] = decision.get("substitute_reference")
        patch["record"] = decision.get("record", {})
    return patch


class HealingValidationService:
    """Applies a temporary patch, re-runs, and decides what becomes permanent."""

    def __init__(self, session: Session, *, config: HealingConfig | None = None) -> None:
        self.session = session
        self.config = config or healing_config()
        self.audit = AuditService(session)

    # ------------------------------------------------------------------
    def validate(self, record: HealingRecord, *, actor: str = "system") -> HealingRecord:
        """Run the full patch -> re-run -> persist-or-roll-back cycle."""
        if record.status not in {"approved", "validating"}:
            raise ValueError(
                f"Healing record '{record.id}' is '{record.status}'; only an approved "
                "record can be validated."
            )

        if record.attempt_count >= self.config.max_attempts_per_test:
            return self._give_up(record, actor=actor)

        record.attempt_count += 1
        record.status = "validating"
        record.validation_status = "running"
        record.patch = build_patch(record)
        self.session.flush()
        self.session.commit()

        outcome = self._rerun(record)

        record.validation_status = outcome.status
        record.validation_mode = outcome.mode
        record.validation_evidence = outcome.evidence
        record.validation_execution_id = outcome.execution_id

        if outcome.passed:
            self._persist(record, outcome)
        else:
            self._roll_back(record, outcome)

        self.session.flush()
        self._audit(record, outcome, actor=actor)

        # Learn from it, whichever way it went. A repair that did not hold is
        # as worth remembering as one that did.
        index_healing_outcome(self.session, record)
        return record

    # ------------------------------------------------------------------
    def _rerun(self, record: HealingRecord) -> ValidationOutcome:
        """Re-run just the affected test with the patch applied.

        The run happens in its own session so a long execution never holds the
        request's transaction open, and so the execution's own commits (which the
        live view reads) stay independent of the healing decision.
        """
        source_test = (
            self.session.get(ExecutionTest, record.execution_test_id)
            if record.execution_test_id
            else None
        )
        if source_test is None or not source_test.test_case_id:
            return ValidationOutcome(
                status="inconclusive",
                mode="simulated" if not settings.playwright_enabled else "playwright",
                evidence=[
                    {
                        "type": "validation_skipped",
                        "detail": (
                            "The failing test could not be identified, so the heal could not "
                            "be re-run. It stays unproven."
                        ),
                    }
                ],
            )

        project_id = record.project_id
        case_id = source_test.test_case_id
        test_name = source_test.name
        patch = record.patch

        with session_scope() as run_session:
            service = ExecutionService(run_session)
            execution = service.create(
                project_id=project_id,
                name=f"Healing validation - {test_name}",
                suite_type="healing_validation",
                test_case_ids=[case_id],
                trigger="healing_validation",
                triggered_by="self-healing",
            )
            # The patch travels with the execution; it is never written to the
            # TestScript row, so this run is the only place it exists.
            execution.config = {**(execution.config or {}), "healing_patch": patch}
            run_session.flush()
            service.run(execution.id)

            execution_id = execution.id
            mode = execution.mode
            rerun_test = next(iter(execution.tests), None)
            result = rerun_test.result if rerun_test else None
            failure_message = rerun_test.failure_message if rerun_test else None
            duration_ms = rerun_test.duration_ms if rerun_test else None

        evidence: list[dict[str, Any]] = [
            {
                "type": "rerun",
                "detail": (
                    f"Re-ran '{test_name}' with the proposed {record.change_type} change applied "
                    f"as a temporary patch. Result: {result or 'no result'}."
                ),
                "execution_id": execution_id,
                "mode": mode,
                "duration_ms": duration_ms,
            }
        ]
        if failure_message:
            label = "rerun_instability" if result == "flaky" else "rerun_failure"
            evidence.append({"type": label, "detail": failure_message[:400]})

        if mode == "simulated":
            # Say plainly what a simulated pass is and is not. It exercises the
            # whole lifecycle and proves the patch reached the run, but it is not
            # evidence that the locator resolves in a real browser.
            evidence.append(
                {
                    "type": "evidence_strength",
                    "detail": (
                        "Simulated execution: the re-run confirms the patch was applied and the "
                        "test no longer fails on this cause in the model of the application. "
                        "Set PLAYWRIGHT_ENABLED=true to validate against a real browser."
                    ),
                }
            )

        if result in {"passed", "healed"}:
            status = "passed"
        elif result == "failed":
            status = "failed"
        elif result == "flaky":
            # It only passed on a retry, so the heal is not proven and not
            # disproven. Unproven means not applied.
            status = "inconclusive"
            evidence.append(
                {
                    "type": "evidence_strength",
                    "detail": (
                        "The re-run needed a retry to pass, so it does not show the change fixed "
                        "the test. The change was not applied."
                    ),
                }
            )
        else:
            status = "inconclusive"

        return ValidationOutcome(
            status=status,
            mode=mode,
            execution_id=execution_id,
            result=result,
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    def _persist(self, record: HealingRecord, outcome: ValidationOutcome) -> None:
        """The re-run passed: make the patch permanent as a versioned change."""
        record.status = "applied"
        record.result_after = "passed"
        record.validated_at = datetime.now(UTC)

        # A data repair changes which record the test runs against, not the
        # test. Retiring the exhausted record is what makes it permanent, and
        # the script is left exactly as it was.
        if record.change_type == "test_data":
            self._retire_exhausted_record(record)
            return

        if not record.test_script_id:
            return
        script = self.session.get(TestScript, record.test_script_id)
        if script is None:
            return

        record.script_version_before = script.version
        script.version += 1
        script.healing_count += 1
        script.locators = [
            self._apply_to_locator(record, locator)
            if locator.get("locator") == record.original_locator
            else locator
            for locator in (script.locators or [])
        ]
        record.script_version_after = script.version
        logger.info(
            "healing_applied",
            healing_record_id=record.id,
            script_id=script.id,
            version=script.version,
            mode=outcome.mode,
        )

    def _retire_exhausted_record(self, record: HealingRecord) -> None:
        """Mark the record that ran out, so the next run does not pick it again.

        Without this the substitution holds for one run and the same failure
        returns tomorrow, which would make the heal look unreliable when in fact
        nothing had changed.
        """
        from app.healing.data import _identity_of  # noqa: PLC0415

        dataset_id = (record.policy_decision or {}).get("dataset_id")
        if not dataset_id:
            return
        dataset = self.session.get(TestDataSet, dataset_id)
        if dataset is None:
            return

        dataset.records = [
            {**item, "status": "exhausted"}
            if isinstance(item, dict) and _identity_of(item) == record.original_locator
            else item
            for item in (dataset.records or [])
        ]
        self.session.flush()
        logger.info(
            "test_data_retired",
            dataset_id=dataset_id,
            reference=record.original_locator,
            replaced_by=record.proposed_locator,
        )

    @staticmethod
    def _apply_to_locator(record: HealingRecord, locator: dict[str, Any]) -> dict[str, Any]:
        """Write the proven change into the script's locator entry.

        A timing repair must not touch the locator expression -- the locator was
        never wrong. It changes how long the test waits for it.
        """
        if record.change_type == "timing":
            wait_ms = (record.policy_decision or {}).get("wait_ms")
            return {**locator, "wait_ms": int(wait_ms)} if wait_ms else locator
        return {
            **locator,
            "locator": record.proposed_locator,
            "strategy": record.locator_strategy,
        }

    def _roll_back(self, record: HealingRecord, outcome: ValidationOutcome) -> None:
        """The re-run did not pass: discard the patch, leave the script alone."""
        record.status = "rolled_back" if outcome.status == "failed" else "validation_failed"
        record.result_after = "failed" if outcome.status == "failed" else None
        record.rolled_back_at = datetime.now(UTC)
        # The patch was never written to the script, so rolling back is simply
        # not applying it. Keep it on the record as evidence of what was tried.
        logger.info(
            "healing_rolled_back",
            healing_record_id=record.id,
            validation_status=outcome.status,
            attempt=record.attempt_count,
        )

    def _give_up(self, record: HealingRecord, *, actor: str) -> HealingRecord:
        record.status = "validation_failed"
        record.validation_status = "failed"
        record.validation_evidence = [
            *(record.validation_evidence or []),
            {
                "type": "attempts_exhausted",
                "detail": (
                    f"Stopped after {record.attempt_count} attempts, the configured maximum. "
                    "This test needs a person."
                ),
            },
        ]
        self.session.flush()
        self.audit.record(
            action="healing.attempts_exhausted",
            entity_type="healing_record",
            entity_id=record.id,
            entity_label=record.original_locator[:120],
            actor=actor,
            actor_type="system",
            project_id=record.project_id,
            outcome="failure",
            severity="warning",
            reason=f"Maximum of {self.config.max_attempts_per_test} healing attempts reached.",
        )
        return record

    # ------------------------------------------------------------------
    def _audit(self, record: HealingRecord, outcome: ValidationOutcome, *, actor: str) -> None:
        self.audit.record(
            action="healing.validated" if outcome.passed else "healing.validation_failed",
            entity_type="healing_record",
            entity_id=record.id,
            entity_label=f"{record.change_type}: {record.original_locator[:80]}",
            actor=actor,
            actor_type="system",
            project_id=record.project_id,
            outcome="success" if outcome.passed else "failure",
            severity="info" if outcome.passed else "warning",
            reason=record.reason,
            confidence=record.confidence,
            input_summary={
                "change_type": record.change_type,
                "from": record.original_locator,
                "to": record.proposed_locator,
                "strategy": record.locator_strategy,
                "attempt": record.attempt_count,
            },
            output_summary={
                "status": record.status,
                "validation_status": record.validation_status,
                "validation_mode": outcome.mode,
                "rerun_execution_id": outcome.execution_id,
                "rerun_result": outcome.result,
                "script_version_before": record.script_version_before,
                "script_version_after": record.script_version_after,
            },
            policy_result=record.policy_decision or {},
        )


def validate_healing_job(record_id: str, actor: str = "system") -> None:
    """Background entry point, used when `healing_validate_async` is on."""
    with session_scope() as session:
        record = session.get(HealingRecord, record_id)
        if record is None:
            raise NotFoundError(f"Healing record '{record_id}' was not found.")
        HealingValidationService(session).validate(record, actor=actor)
