"""The healing operations the API and agents call.

Two things this layer guarantees, which callers therefore do not have to:

  * A change the policy matrix forbids cannot be approved. Not by an agent, not
    by a confident model, not by a human clicking approve.
  * Approving a heal starts a validation; it does not declare one.
"""

from __future__ import annotations

from datetime import datetime
from app.core.time import UTC

from sqlalchemy.orm import Session

from app.core.errors import NotFoundError, ValidationError
from app.core.logging import get_logger
from app.core.worker import job_queue
from app.governance.policy_engine import AuditService, PolicyEngine
from app.healing.config import HealingConfig, healing_config
from app.healing.policy import evaluate_change
from app.healing.validation import HealingValidationService
from app.models.governance import ApprovalRequest
from app.models.testing import HealingRecord

logger = get_logger(__name__)

RISK_BY_CHANGE_TYPE = {
    "locator": "medium",
    "timing": "low",
    "navigation": "medium",
    "test_data": "high",
    "api_contract": "high",
}


class HealingService:
    def __init__(self, session: Session, *, config: HealingConfig | None = None) -> None:
        self.session = session
        self.config = config or healing_config()
        self.audit = AuditService(session)
        self.policies = PolicyEngine(session)

    # ------------------------------------------------------------------
    def request_approval(self, record: HealingRecord, *, requested_by: str | None = None) -> ApprovalRequest:
        """Put a proposal into the same approval queue flows use, so healing is
        visible everywhere approvals are, not only on the healing page."""
        approval = self.policies.request_approval(
            project_id=record.project_id,
            title=f"Heal {record.change_type}: {record.original_locator[:80]}",
            reason=record.reason,
            risk_level=RISK_BY_CHANGE_TYPE.get(record.change_type, "medium"),
            subject_type="healing_record",
            subject_ref=record.id,
            required_role="qe_lead",
            requested_by=requested_by or "self-healing-automation",
            context={
                "change_type": record.change_type,
                "failure_class": record.failure_class,
                "confidence": record.confidence,
                "confidence_breakdown": record.confidence_breakdown or [],
                "evidence": record.evidence or [],
            },
            proposed_action={
                "from": record.original_locator,
                "to": record.proposed_locator,
                "strategy": record.locator_strategy,
                "validation": "A re-run must pass before this is applied.",
            },
        )
        record.approval_request_id = approval.id
        self.session.flush()
        return approval

    # ------------------------------------------------------------------
    def decide(self, record_id: str, *, decision: str, actor: str) -> HealingRecord:
        record = self.session.get(HealingRecord, record_id)
        if record is None:
            raise NotFoundError(f"Healing record '{record_id}' was not found.")

        if record.status in {"applied", "rejected", "rolled_back"}:
            raise ValidationError(
                f"This healing proposal is already '{record.status}' and cannot be decided again."
            )

        if decision == "reject":
            return self._reject(record, actor=actor)
        return self._approve(record, actor=actor)

    # ------------------------------------------------------------------
    def _approve(self, record: HealingRecord, *, actor: str) -> HealingRecord:
        # Re-evaluate the gate at decision time. A policy may have tightened since
        # the proposal was made, and a forbidden change is never approvable.
        gate = evaluate_change(
            change_type=record.change_type,
            confidence=record.confidence,
            config=self.config,
        )
        if not gate.allowed:
            record.status = "blocked"
            record.policy_decision = gate.to_dict()
            self.session.flush()
            self._audit(
                record,
                action="healing.blocked",
                actor=actor,
                outcome="denied",
                severity="warning",
                reason="; ".join(gate.reasons),
            )
            raise ValidationError(
                "This change cannot be approved by anyone.",
                details={"reasons": gate.reasons, "change_type": record.change_type},
            )

        record.status = "approved"
        record.approver = actor
        record.approved_at = datetime.now(UTC)
        record.policy_decision = {**(record.policy_decision or {}), **gate.to_dict()}
        self._resolve_approval(record, status="approved", actor=actor)
        self.session.flush()
        self._audit(record, action="healing.approved", actor=actor, reason=record.reason)

        if not self.config.require_validation:
            # An explicit, audited downgrade: the change is applied unproven and
            # is recorded as unproven -- result_after stays empty.
            record.status = "applied"
            record.validation_status = "inconclusive"
            record.validation_evidence = [
                {
                    "type": "validation_disabled",
                    "detail": (
                        "HEALING_REQUIRE_VALIDATION is off, so this change was applied without "
                        "a re-run. It is not evidence that the test now passes."
                    ),
                }
            ]
            self.session.flush()
            return record

        if self.config.validate_async:
            record.status = "validating"
            record.validation_status = "running"
            self.session.flush()
            self.session.commit()
            job_queue.submit(
                f"healing-validation:{record.id}",
                _validate_job,
                record.id,
                actor,
                job_metadata={"healing_record_id": record.id, "project_id": record.project_id},
            )
            return record

        HealingValidationService(self.session, config=self.config).validate(record, actor=actor)
        return record

    def _reject(self, record: HealingRecord, *, actor: str) -> HealingRecord:
        record.status = "rejected"
        record.approver = actor
        record.approved_at = datetime.now(UTC)
        self._resolve_approval(record, status="rejected", actor=actor)
        self.session.flush()
        self._audit(
            record,
            action="healing.rejected",
            actor=actor,
            outcome="rejected",
            reason="A reviewer declined the proposed change.",
        )
        return record

    # ------------------------------------------------------------------
    def _resolve_approval(self, record: HealingRecord, *, status: str, actor: str) -> None:
        if not record.approval_request_id:
            return
        approval = self.session.get(ApprovalRequest, record.approval_request_id)
        if approval is None or approval.status != "pending":
            return
        approval.status = status
        approval.decided_by = actor
        approval.decided_at = datetime.now(UTC)
        approval.decision_notes = f"Healing proposal {status} from the healing queue."

    def _audit(
        self,
        record: HealingRecord,
        *,
        action: str,
        actor: str,
        outcome: str = "success",
        severity: str = "info",
        reason: str | None = None,
    ) -> None:
        self.audit.record(
            action=action,
            entity_type="healing_record",
            entity_id=record.id,
            entity_label=f"{record.change_type}: {record.original_locator[:80]}",
            actor=actor,
            actor_type="human",
            project_id=record.project_id,
            outcome=outcome,
            severity=severity,
            reason=reason,
            confidence=record.confidence,
            input_summary={
                "change_type": record.change_type,
                "failure_class": record.failure_class,
                "from": record.original_locator,
                "to": record.proposed_locator,
                "strategy": record.locator_strategy,
            },
            output_summary={"status": record.status, "validation_status": record.validation_status},
            policy_result=record.policy_decision or {},
        )


def _validate_job(record_id: str, actor: str) -> None:
    from app.healing.validation import validate_healing_job  # noqa: PLC0415 - avoids a cycle

    validate_healing_job(record_id, actor)
