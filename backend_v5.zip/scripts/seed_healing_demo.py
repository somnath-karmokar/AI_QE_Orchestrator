"""Seed a set of self-healing scenarios for a client demonstration.

Six scenarios, each showing one thing, together covering the whole lifecycle:

    S1  a heal that worked          -- applied, with the re-run that proved it
    S2  a heal that did not hold    -- rolled back, script untouched
    S3  an assertion change         -- cannot be approved by anyone
    S4  an ambiguous element        -- two candidates too close, so a human decides
    S5  a test-data substitution    -- always needs an approver, however confident
    S6  ready to heal               -- approve this one live; it re-runs and applies

S1 is produced by genuinely running the platform's own validation, so the record
the client sees is real rather than described. S2's failure is seeded history --
a validation failure cannot be forced on demand, which is rather the point.

Re-running the script replaces everything it created before, so a demo can be
reset between audiences.

    python scripts/seed_healing_demo.py            # seed
    python scripts/seed_healing_demo.py --reset    # remove, seed nothing
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta
from app.core.time import UTC
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select  # noqa: E402

from app.core.database import session_scope  # noqa: E402
from app.execution.failures import classify  # noqa: E402
from app.healing.config import ACCESSIBILITY_STRENGTH, healing_config  # noqa: E402
from app.healing.policy import ChangeType, evaluate_change  # noqa: E402
from app.healing.service import HealingService  # noqa: E402
from app.models.governance import ApprovalRequest  # noqa: E402
from app.models.project import Project  # noqa: E402
from app.models.testing import (  # noqa: E402
    Execution,
    ExecutionTest,
    HealingRecord,
    TestCase,
    TestScript,
)

MARKER = "demo_scenario"
EXECUTION_NAME = "Nightly regression (healing demo)"

ORIGINAL = 'page.get_by_test_id("checkout-submit-btn")'


def _clear(session) -> int:  # noqa: ANN001
    """Remove anything a previous run of this script created."""
    removed = 0
    for record in session.execute(select(HealingRecord)).scalars().all():
        if (record.policy_decision or {}).get(MARKER):
            for approval in (
                session.execute(
                    select(ApprovalRequest).where(ApprovalRequest.subject_ref == record.id)
                )
                .scalars()
                .all()
            ):
                session.delete(approval)
            session.delete(record)
            removed += 1

    for execution in (
        session.execute(select(Execution).where(Execution.name == EXECUTION_NAME)).scalars().all()
    ):
        for test in list(execution.tests):
            session.delete(test)
        session.delete(execution)
    session.flush()
    return removed


def _candidate_cases(session, project_id: str, count: int) -> list[tuple[TestCase, TestScript]]:
    """Automated cases with the cleanest history.

    A case with no recorded failures gives the simulated re-run a low residual
    failure probability, so a heal that should hold, holds -- in front of a client.
    """
    rows = list(
        session.execute(
            select(TestCase, TestScript)
            .join(TestScript, TestScript.test_case_id == TestCase.id)
            .where(
                TestCase.project_id == project_id,
                TestCase.is_automated.is_(True),
                TestCase.is_deleted.is_(False),
                TestScript.is_deleted.is_(False),
            )
        ).all()
    )
    rows.sort(key=lambda row: (row[0].failure_count / max(row[0].execution_count, 1), row[0].title))
    return rows[:count]


def _failing_execution(session, project_id: str, cases: list[tuple[TestCase, TestScript]]) -> Execution:
    """The run the heals came out of, so every proposal traces to a real failure."""
    sequence = (
        session.execute(
            select(Execution.execution_number)
            .where(Execution.project_id == project_id)
            .order_by(Execution.execution_number.desc())
            .limit(1)
        ).scalar()
        or 0
    )
    started = datetime.now(UTC) - timedelta(hours=9)
    execution = Execution(
        project_id=project_id,
        name=EXECUTION_NAME,
        execution_number=sequence + 1,
        suite_type="regression",
        status="failed",
        browser="chromium",
        headless=True,
        parallelism=4,
        trigger="scheduled",
        mode="simulated",
        total_tests=len(cases),
        failed=len(cases),
        pass_rate=0.0,
        triggered_by="scheduler",
        started_at=started,
        finished_at=started + timedelta(minutes=14),
        duration_ms=14 * 60 * 1000,
        failure_categories={"locator_drift": len(cases)},
        config={"note": "Seeded for the self-healing demonstration."},
    )
    session.add(execution)
    session.flush()

    for case, script in cases:
        session.add(
            ExecutionTest(
                execution_id=execution.id,
                test_case_id=case.id,
                test_script_id=script.id,
                name=case.title,
                module=case.module,
                result="failed",
                failure_category="locator_drift",
                failure_signature="LOCATOR_NOT_FOUND",
                failure_message=(
                    f'Locator resolved to 0 elements: {ORIGINAL} - waiting for locator to be visible'
                ),
                stack_trace=f'  File "{case.title[:30].replace(" ", "_").lower()}.py", line 63',
                duration_ms=31_500,
                started_at=started + timedelta(minutes=2),
            )
        )
    session.flush()
    return execution


def _record(
    *,
    session,  # noqa: ANN001
    project_id: str,
    test: ExecutionTest,
    scenario: str,
    headline: str,
    change_type: str,
    proposed: str,
    strategy: str,
    confidence: float,
    reason: str,
    runner_up: float = 0.0,
    alternatives: list[dict] | None = None,
    original: str | None = None,
) -> HealingRecord:
    config = healing_config()
    gate = evaluate_change(
        change_type=change_type,
        confidence=confidence,
        runner_up_confidence=runner_up,
        config=config,
    )
    record = HealingRecord(
        project_id=project_id,
        test_script_id=test.test_script_id,
        execution_test_id=test.id,
        status="proposed",
        failure_class=test.failure_category or "locator_drift",
        change_type=change_type,
        # "from" is whatever this change type replaces, not always a locator.
        original_locator=original or ORIGINAL,
        proposed_locator=proposed,
        locator_strategy=strategy,
        candidates=alternatives or [],
        reason=reason,
        confidence=confidence,
        confidence_breakdown=config.breakdown(
            {
                "strategy_robustness": confidence,
                "accessibility_match": ACCESSIBILITY_STRENGTH.get(strategy, 0.5),
            }
        ),
        evidence=[
            {"type": "failure_message", "detail": (test.failure_message or "")[:200]},
            {"type": "locator_ranking", "detail": f"{strategy} ranked highest at {confidence:.2f}."},
            *([{"type": "policy", "detail": reason} for reason in gate.reasons]),
        ],
        policy_decision={
            "threshold": config.auto_apply_threshold,
            **gate.to_dict(),
            MARKER: scenario,
            "demo_headline": headline,
        },
        result_before="failed",
    )
    session.add(record)
    session.flush()
    return record


def seed() -> None:
    config = healing_config()
    with session_scope() as session:
        project = session.execute(select(Project).where(Project.key == "ABCR")).scalar_one_or_none()
        if project is None:
            print("The demo project (ABCR) was not found. Seed the platform first.")
            return

        removed = _clear(session)
        cases = _candidate_cases(session, project.id, 6)
        if len(cases) < 6:
            print(f"Only {len(cases)} automated cases with scripts were found; need 6.")
            return

        execution = _failing_execution(session, project.id, cases)
        tests = list(execution.tests)
        service = HealingService(session)
        summary: list[tuple[str, str, str]] = []

        # --- S1: a heal that worked -------------------------------------------
        # Run the platform's own validation so the evidence is genuine.
        s1 = _record(
            session=session,
            project_id=project.id,
            test=tests[0],
            scenario="S1",
            headline="A heal that worked, proved by a re-run",
            change_type=ChangeType.LOCATOR,
            proposed='page.get_by_test_id("checkout-submit")',
            strategy="test_id",
            confidence=0.96,
            reason="The test id was renamed in the checkout redesign; the new id is dedicated to testing.",
            runner_up=0.78,
        )
        service.decide(s1.id, decision="approve", actor="priya.raman@example.com")
        session.refresh(s1)
        summary.append(
            ("S1", s1.status, f"validation {s1.validation_status}, script v{s1.script_version_before} -> v{s1.script_version_after}")
        )

        # --- S2: a heal that did not hold -------------------------------------
        # Seeded history: a validation failure cannot be produced on demand.
        s2 = _record(
            session=session,
            project_id=project.id,
            test=tests[1],
            scenario="S2",
            headline="A heal that did not hold, so nothing was applied",
            change_type=ChangeType.LOCATOR,
            proposed='page.get_by_role("button", name="Place order")',
            strategy="role",
            confidence=0.89,
            reason="The accessible name looked like a match for the submit control.",
            runner_up=0.61,
        )
        s2.status = "rolled_back"
        s2.approver = "priya.raman@example.com"
        s2.approved_at = datetime.now(UTC) - timedelta(hours=6)
        s2.attempt_count = 1
        s2.validation_status = "failed"
        s2.validation_mode = "simulated"
        s2.result_after = "failed"
        s2.rolled_back_at = datetime.now(UTC) - timedelta(hours=6)
        s2.patch = {"change_type": ChangeType.LOCATOR, "from": ORIGINAL, "to": s2.proposed_locator}
        s2.validation_evidence = [
            {
                "type": "rerun",
                "detail": (
                    f"Re-ran '{tests[1].name}' with the proposed locator applied as a temporary "
                    "patch. Result: failed."
                ),
                "mode": "simulated",
            },
            {
                "type": "rerun_failure",
                "detail": "The button resolved, but the order confirmation never appeared.",
            },
        ]
        session.flush()
        summary.append(("S2", s2.status, "the script stayed on its current version"))

        # --- S3: a change nobody may approve ----------------------------------
        # This test failed on its assertion, not on a locator: the application
        # and the test disagree about the order total.
        tests[2].failure_signature = "ASSERTION_FAILED"
        tests[2].failure_message = (
            'AssertionError: expected order total to be "1,180.00" but the page showed "1,240.00"'
        )
        tests[2].failure_category = classify(tests[2].failure_message).category
        s3 = _record(
            session=session,
            project_id=project.id,
            test=tests[2],
            scenario="S3",
            headline="An assertion change that no one can approve",
            change_type=ChangeType.ASSERTION,
            original='expect(order_total).to_have_text("1,180.00")',
            proposed='expect(order_total).to_have_text("1,240.00")',
            strategy="text",
            confidence=0.97,
            reason=(
                "The expected order total no longer matches the application. Changing the "
                "assertion would hide the difference rather than explain it."
            ),
        )
        summary.append(("S3", s3.status, "approving it returns a refusal, at 97% confidence"))

        # --- S4: an ambiguous element -----------------------------------------
        s4 = _record(
            session=session,
            project_id=project.id,
            test=tests[3],
            scenario="S4",
            headline="Two candidates too close to call",
            change_type=ChangeType.LOCATOR,
            proposed='page.get_by_role("button", name="Continue")',
            strategy="role",
            confidence=0.91,
            runner_up=0.89,
            reason="Two controls on the page match the description almost equally well.",
            alternatives=[
                {"strategy": "role", "locator": 'page.get_by_role("link", name="Continue")', "confidence": 0.89},
                {"strategy": "text", "locator": 'page.get_by_text("Continue")', "confidence": 0.74},
            ],
        )
        service.request_approval(s4, requested_by="self-healing-automation")
        summary.append(("S4", s4.status, "91% confidence, still routed to a human"))

        # --- S5: a test-data substitution --------------------------------------
        tests[4].failure_signature = "DATA_PRECONDITION_FAILED"
        tests[4].failure_message = (
            "Precondition failed: the loyalty account used by this test was closed overnight."
        )
        tests[4].failure_category = classify(tests[4].failure_message).category
        s5 = _record(
            session=session,
            project_id=project.id,
            test=tests[4],
            scenario="S5",
            headline="Test data always needs an approver",
            change_type=ChangeType.TEST_DATA,
            original="loyalty_account=LOY-2210 (closed overnight)",
            proposed="loyalty_account=LOY-4471 (active, same tier)",
            strategy="test_id",
            confidence=0.95,
            reason="An equivalent active loyalty account of the same tier is available.",
        )
        service.request_approval(s5, requested_by="self-healing-automation")
        summary.append(("S5", s5.status, "95% confidence, approval required by policy"))

        # --- S6: the one to approve live ---------------------------------------
        s6 = _record(
            session=session,
            project_id=project.id,
            test=tests[5],
            scenario="S6",
            headline="Approve this one live",
            change_type=ChangeType.LOCATOR,
            proposed='page.get_by_role("button", name="Pay now")',
            strategy="role",
            confidence=0.94,
            runner_up=0.62,
            reason="The control kept its accessible role and name when the markup was rebuilt.",
            alternatives=[
                {"strategy": "css", "locator": 'page.locator(".btn-primary")', "confidence": 0.62},
            ],
        )
        summary.append(("S6", s6.status, "approve this during the demo"))

        print(f"Removed {removed} scenario(s) from a previous run.\n")
        print(f"Seeded execution : {execution.name} (#{execution.execution_number})")
        print(f"Auto-apply gate  : {config.auto_apply_threshold:.0%}   "
              f"floor {config.propose_threshold:.0%}   "
              f"ambiguity margin {config.ambiguity_margin:.0%}\n")
        for scenario, status, note in summary:
            print(f"  {scenario}  {status:<14} {note}")
        print("\nOpen Quality Intelligence -> Defects -> Self-healing.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reset", action="store_true", help="remove the scenarios and stop")
    args = parser.parse_args()

    if args.reset:
        with session_scope() as session:
            removed = _clear(session)
        print(f"Removed {removed} demo healing scenario(s).")
        return 0

    seed()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
