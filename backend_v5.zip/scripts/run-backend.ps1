<#
.SYNOPSIS
    Set up (if needed) and run the AI QE Orchestrator backend, standalone.

.DESCRIPTION
    Self-contained: works from a copy of just this `backend/` folder on a
    machine that doesn't have the rest of the repository. Creates the Python
    virtual environment if it doesn't exist, installs dependencies, loads demo
    data (idempotent -- only adds what's missing, unless -Reset), and starts
    the API in the foreground on the given port. Runs with no AI credentials,
    no Chroma server and no external database: everything defaults to a
    local, demo-mode stand-in (see app/core/config.py). If a built web app
    happens to be present at ../frontend/dist it's served too; otherwise this
    is the API and its docs only.

    Ctrl+C, or closing the window, stops the server. There's no separate
    stop script -- this isn't a background process like the full-stack demo
    launcher (../start-demo.bat) is.

.PARAMETER Port
    Port to serve on. Default 8100.

.PARAMETER Reset
    Rebuild the demo data from scratch (discards runs, approvals and agents
    from earlier sessions) instead of the default, which only adds what's
    missing.

.PARAMETER SkipSeed
    Don't touch demo data at all, even to fill in what's missing.
#>
param(
    [int]$Port = 8100,
    [switch]$Reset,
    [switch]$SkipSeed
)

$ErrorActionPreference = 'Stop'
$BackendDir = Split-Path -Parent $PSScriptRoot
$VenvPython = Join-Path $BackendDir '.venv\Scripts\python.exe'

function Write-Step([string]$Message) { Write-Host "==> $Message" -ForegroundColor Cyan }
function Write-Done([string]$Message) { Write-Host "    $Message" -ForegroundColor Green }
function Write-Note([string]$Message) { Write-Host "    $Message" -ForegroundColor Yellow }
function Write-Failure([string]$Message) { Write-Host "    $Message" -ForegroundColor Red }

function Invoke-Checked([string]$What, [scriptblock]$Command) {
    # Native tools report failure through the exit code, not an exception.
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$What failed (exit code $LASTEXITCODE)." }
}

function Find-Python {
    # Prefer the Windows launcher's 3.12, then 3.11; `python` last, because on a
    # clean machine it can be the Microsoft Store placeholder rather than a
    # real interpreter.
    foreach ($candidate in @(@('py', '-3.12'), @('py', '-3.11'), @('python'))) {
        $exe = $candidate[0]
        $extra = @($candidate | Select-Object -Skip 1)
        if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
        $version = & $exe @extra -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -eq 0 -and "$version" -match '^3\.(11|12)$') { return ,$candidate }
    }
    return $null
}

function Get-PortOwner([int]$Port) {
    $connection = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($connection) { Get-Process -Id $connection.OwningProcess -ErrorAction SilentlyContinue }
}

try {
    Write-Host ''
    Write-Host 'AI QE Orchestrator - backend' -ForegroundColor White
    Write-Host ''

    $owner = Get-PortOwner $Port
    if ($owner) {
        throw "Port $Port is already in use by $($owner.ProcessName) (PID $($owner.Id)). Run this again on another port, for example:  run-backend.bat -Port 8200"
    }

    # ---- Python environment -----------------------------------------------------
    Write-Step 'Python environment'
    if (Test-Path $VenvPython) {
        Write-Done "Using $VenvPython"
    } else {
        $python = Find-Python
        if (-not $python) {
            throw 'Python 3.12 (or 3.11) is required. Install it from https://www.python.org/downloads/ (tick "Add python.exe to PATH") and run this again.'
        }
        $exe = $python[0]
        $extra = @($python | Select-Object -Skip 1)
        Invoke-Checked 'Creating the virtual environment' { & $exe @extra -m venv (Join-Path $BackendDir '.venv') }
        Write-Done 'Virtual environment created'
    }

    Write-Step 'Installing Python packages (the first run takes a few minutes)'
    Invoke-Checked 'pip install' {
        & $VenvPython -m pip install --disable-pip-version-check --quiet -r (Join-Path $BackendDir 'requirements.txt')
    }
    Write-Done 'Python packages installed'

    # ---- Demo data ----------------------------------------------------------------
    if ($SkipSeed) {
        Write-Note 'Skipping demo data (-SkipSeed).'
    } else {
        $label = if ($Reset) { 'Rebuilding demo data from scratch (a few minutes)' } else { 'Loading demo data (only adds what is missing)' }
        Write-Step $label
        Push-Location $BackendDir
        try {
            $seedArgs = if ($Reset) { @('--reset') } else { @() }
            Invoke-Checked 'Seeding demo data' { & $VenvPython -m app.seed @seedArgs }
        } finally {
            Pop-Location
        }
        Write-Done 'Demo data ready'
    }

    # ---- Server ---------------------------------------------------------------------
    $webAppIndex = Join-Path $BackendDir '..\frontend\dist\index.html'
    if (Test-Path $webAppIndex) {
        Write-Note 'A built web app was found alongside backend/ and will be served too.'
    } else {
        Write-Note 'No built web app found next to backend/ -- serving the API only.'
    }

    Write-Host ''
    Write-Host "Starting the API on http://127.0.0.1:$Port -- press Ctrl+C to stop." -ForegroundColor Green
    Write-Host "API docs:  http://127.0.0.1:$Port/api/docs" -ForegroundColor Green
    Write-Host ''

    Push-Location $BackendDir
    try {
        & $VenvPython -m uvicorn app.main:app --host 127.0.0.1 --port $Port
    } finally {
        Pop-Location
    }
} catch {
    Write-Host ''
    Write-Failure "Could not start the backend: $($_.Exception.Message)"
    exit 1
}
