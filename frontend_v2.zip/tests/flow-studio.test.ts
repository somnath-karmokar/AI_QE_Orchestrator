import { describe, expect, it } from 'vitest';
import {
  deltaDirection,
  describeSchedule,
  formatPoints,
  fromInputValue,
  initials,
  personName,
  shortDate,
} from '@/features/flow-studio/format';

describe('describeSchedule', () => {
  it('matches the server wording', () => {
    expect(describeSchedule({ enabled: true, frequency: 'daily', time: '02:00' })).toBe('Daily at 02:00 UTC');
    expect(describeSchedule({ enabled: true, frequency: 'weekly', time: '07:00', weekday: 0 })).toBe('Every Monday at 07:00 UTC');
    expect(describeSchedule({ enabled: true, frequency: 'hourly', time: '00:15' })).toBe('Every hour at :15');
  });

  it('says so when a flow is not scheduled', () => {
    expect(describeSchedule({ enabled: false, frequency: 'daily' })).toBe('Not scheduled');
    expect(describeSchedule(null)).toBe('Not scheduled');
  });
});

describe('people', () => {
  it('turns an email into a readable name and initials', () => {
    expect(personName('priya.raman@example.com')).toBe('Priya Raman');
    expect(initials('priya.raman@example.com')).toBe('PR');
    expect(personName(null)).toBe('Unassigned');
    expect(personName('scheduler')).toBe('scheduler');
  });
});

describe('deltaDirection', () => {
  it('treats a rise as good news only when higher is better', () => {
    expect(deltaDirection(0.05)).toBe('better');
    expect(deltaDirection(0.05, false)).toBe('worse');
    expect(deltaDirection(-1200, false)).toBe('better');
  });

  it('ignores changes inside the tolerance and missing comparisons', () => {
    expect(deltaDirection(0.0004, true, 0.001)).toBe('flat');
    expect(deltaDirection(null)).toBe('flat');
  });
});

describe('formatting', () => {
  it('formats percentage-point changes with a sign', () => {
    expect(formatPoints(0.079)).toBe('+7.9 pts');
    expect(formatPoints(-0.02)).toBe('−2.0 pts');
    expect(formatPoints(null)).toBe('—');
  });

  it('shows API calendar days without shifting them across time zones', () => {
    expect(shortDate('2026-09-01')).toBe('1 Sep');
  });

  it('keeps numeric inputs numeric when edited as text', () => {
    expect(fromInputValue('75', 80)).toBe(75);
    expect(fromInputValue('', 80)).toBe(80);
    expect(fromInputValue('PAY-202', 'PAY-201')).toBe('PAY-202');
  });
});
