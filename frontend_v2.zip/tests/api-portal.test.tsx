/**
 * The API user portal.
 *
 * This is an authentication surface for someone with no account here, so what
 * matters is what it does with the key: hold it for this tab only, refuse a bad
 * one in words rather than a blank page, and never render it back out.
 */
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import ApiPortalPage from '@/pages/ApiPortalPage';
import { ApiError, portalApi } from '@/services/api';
import type { ApiCatalog, ApiIdentity, ApiRunPage } from '@/types';

const KEY = 'qei_a-real-looking-key';

function identity(overrides: Partial<ApiIdentity> = {}): ApiIdentity {
  return {
    authenticated: true,
    client: {
      name: 'acme-release-pipeline',
      platform: 'jenkins',
      description: null,
      project_id: 'project-1',
      token_hint: 'k3Yz',
      created_at: '2026-09-01T00:00:00Z',
    },
    scopes: {
      granted: ['catalog:read', 'flows:run'],
      meaning: { 'catalog:read': 'Discover the flows and agents.', 'flows:run': 'Start a flow run.' },
    },
    provisioned: { flows: 9, agents: 23, all_flows_in_project: true, all_agents_in_project: true },
    validity: { active: true, expires_at: null, expired: false },
    limits: { rate_limit_per_minute: 60 },
    usage: { calls: 12, last_used_at: '2026-09-21T10:00:00Z' },
    activity: {
      runs_total: 3,
      runs_by_disposition: { succeeded: 2, pending: 1 },
      in_flight: 1,
      total_cost_usd: 0.42,
      last_run_at: '2026-09-21T09:00:00Z',
    },
    ...overrides,
  };
}

const CATALOG: ApiCatalog = {
  project_id: 'project-1',
  counts: { flows: 1, agents: 0 },
  flows: [
    {
      id: 'flow-1',
      name: 'Requirement to Automated Test',
      description: 'End to end.',
      category: 'Test Engineering',
      status: 'published',
      invoke: { method: 'POST', path: '/integration/flows/flow-1/runs', scope: 'flows:run' },
      input_schema: { type: 'object', properties: { requirement_key: { type: 'string' } } },
      guardrails: { requires_approval: true },
    },
  ],
  agents: [],
};

const RUNS: ApiRunPage = {
  items: [
    {
      run_id: 'run-abcdef12',
      run_number: 7,
      title: 'PAY-201 readiness',
      kind: 'flow',
      status: 'awaiting_approval',
      disposition: 'waiting_for_approval',
      is_terminal: false,
      flow_id: 'flow-1',
      started_at: '2026-09-21T09:00:00Z',
      finished_at: null,
      duration_ms: null,
      summary: null,
      error: null,
      progress: { completed_steps: 2, total_steps: 3 },
      guardrails: { awaiting_approval: [{ title: 'Approve test data', required_role: 'qe_lead' }] },
      links: { self: '/api/v1/integration/runs/run-abcdef12', cancel: '' },
    },
  ],
  total: 1,
  limit: 20,
  offset: 0,
};

function renderPortal() {
  return render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <ApiPortalPage />
    </QueryClientProvider>,
  );
}

function signIn(key = KEY) {
  fireEvent.change(screen.getByLabelText(/Your API key/i), { target: { value: key } });
  fireEvent.click(screen.getByRole('button', { name: /Sign in/i }));
}

beforeEach(() => {
  window.sessionStorage.clear();
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('ApiPortalPage', () => {
  it('asks for a key before showing anything', () => {
    const me = vi.spyOn(portalApi, 'me');

    renderPortal();

    expect(screen.getByLabelText(/Your API key/i)).toBeInTheDocument();
    expect(me).not.toHaveBeenCalled();
  });

  it('shows what the key is provisioned with once signed in', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity());
    vi.spyOn(portalApi, 'catalog').mockResolvedValue(CATALOG);
    vi.spyOn(portalApi, 'runs').mockResolvedValue(RUNS);

    renderPortal();
    signIn();

    expect(await screen.findByText('acme-release-pipeline')).toBeInTheDocument();
    expect(screen.getByText('9 flows · 23 agents')).toBeInTheDocument();
    expect(await screen.findByText('Requirement to Automated Test')).toBeInTheDocument();
    expect(screen.getByText('/integration/flows/flow-1/runs')).toBeInTheDocument();
  });

  it('explains each scope rather than only naming it', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity());
    vi.spyOn(portalApi, 'catalog').mockResolvedValue(CATALOG);
    vi.spyOn(portalApi, 'runs').mockResolvedValue(RUNS);

    renderPortal();
    signIn();

    expect(await screen.findByText('Start a flow run.')).toBeInTheDocument();
  });

  it('shows the runs this key started, and what they are waiting on', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity());
    vi.spyOn(portalApi, 'catalog').mockResolvedValue(CATALOG);
    vi.spyOn(portalApi, 'runs').mockResolvedValue(RUNS);

    renderPortal();
    signIn();

    expect(await screen.findByText('PAY-201 readiness')).toBeInTheDocument();
    expect(screen.getByText('waiting for approval')).toBeInTheDocument();
    expect(screen.getByText(/waiting on qe_lead/)).toBeInTheDocument();
  });

  it('refuses a rejected key in words, and does not keep it', async () => {
    vi.spyOn(portalApi, 'me').mockRejectedValue(
      new ApiError(401, 'unauthenticated', 'A valid X-API-Key header is required.', {}, 'cid'),
    );

    renderPortal();
    signIn('qei_wrong');

    expect(await screen.findByText(/was not accepted/i)).toBeInTheDocument();
    expect(window.sessionStorage.getItem('aiqe.portal.key')).toBeNull();
  });

  it('never renders the key back out', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity());
    vi.spyOn(portalApi, 'catalog').mockResolvedValue(CATALOG);
    vi.spyOn(portalApi, 'runs').mockResolvedValue(RUNS);

    const { container } = renderPortal();
    signIn();
    await screen.findByText('acme-release-pipeline');

    expect(container.textContent).not.toContain(KEY);
    // Only the hint the rest of the platform shows.
    expect(screen.getByText('…k3Yz')).toBeInTheDocument();
  });

  it('keeps the key for this tab only, and forgets it on sign out', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity());
    vi.spyOn(portalApi, 'catalog').mockResolvedValue(CATALOG);
    vi.spyOn(portalApi, 'runs').mockResolvedValue(RUNS);

    renderPortal();
    signIn();
    await screen.findByText('acme-release-pipeline');

    expect(window.sessionStorage.getItem('aiqe.portal.key')).toBe(KEY);
    expect(window.localStorage.getItem('aiqe.portal.key')).toBeNull();

    fireEvent.click(screen.getByRole('button', { name: /Sign out/i }));

    await waitFor(() => expect(screen.getByLabelText(/Your API key/i)).toBeInTheDocument());
    expect(window.sessionStorage.getItem('aiqe.portal.key')).toBeNull();
  });

  it('says so when a valid key has been granted nothing', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(
      identity({
        provisioned: { flows: 0, agents: 0, all_flows_in_project: false, all_agents_in_project: false },
      }),
    );
    vi.spyOn(portalApi, 'catalog').mockResolvedValue({
      project_id: 'project-1',
      flows: [],
      agents: [],
      counts: { flows: 0, agents: 0 },
    });
    vi.spyOn(portalApi, 'runs').mockResolvedValue({ items: [], total: 0, limit: 20, offset: 0 });

    renderPortal();
    signIn();

    expect(await screen.findByText(/Nothing provisioned yet/i)).toBeInTheDocument();
    expect(screen.getByText(/No runs yet/i)).toBeInTheDocument();
  });
});
