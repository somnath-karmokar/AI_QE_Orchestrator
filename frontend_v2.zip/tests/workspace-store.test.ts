import { beforeEach, describe, expect, it } from 'vitest';
import { useWorkspace } from '@/store';
import type { Environment, ProjectSummary } from '@/types';

const project = (id: string) => ({ id, key: id.toUpperCase(), name: id }) as ProjectSummary;
const environments = [
  { id: 'env-dev', key: 'dev', name: 'Development' },
  { id: 'env-sit', key: 'sit', name: 'System Integration Test' },
] as Environment[];

describe('workspace store', () => {
  beforeEach(() => {
    useWorkspace.setState({ projectId: null, project: null, environments: [], environmentId: null });
  });

  it('defaults to the SIT environment', () => {
    useWorkspace.getState().setProject(project('abcr'));
    useWorkspace.getState().setEnvironments(environments);
    expect(useWorkspace.getState().environmentId).toBe('env-sit');
  });

  it('keeps environments when the persisted project is re-hydrated after a reload', () => {
    // A reload restores projectId, loads the environments, then re-selects the same project.
    useWorkspace.setState({ projectId: 'abcr', environmentId: 'env-dev' });
    useWorkspace.getState().setEnvironments(environments);
    useWorkspace.getState().setProject(project('abcr'));

    const state = useWorkspace.getState();
    expect(state.environments).toHaveLength(2);
    expect(state.environmentId).toBe('env-dev');
  });

  it('clears the environment selection when switching to another project', () => {
    useWorkspace.getState().setProject(project('abcr'));
    useWorkspace.getState().setEnvironments(environments);
    useWorkspace.getState().setProject(project('other'));

    const state = useWorkspace.getState();
    expect(state.environments).toEqual([]);
    expect(state.environmentId).toBeNull();
  });
});
