/**
 * The governance side of the API user portal: model cards and golden datasets
 * to download, the log of each run, and the metrics strip.
 *
 * What matters is what the page does with the key and with a refusal: documents
 * are fetched with the key in a header (a link would put it in a URL), a key
 * without the logs scope is told which scope it lacks, and metrics only appear
 * for a key that may see them.
 */
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import ApiPortalPage from '@/pages/ApiPortalPage';
import { ApiError, portalApi } from '@/services/api';
import type { ApiCatalog, ApiIdentity, ApiMetrics, ApiRunLog, ApiRunPage } from '@/types';

const KEY = 'qei_governance-test-key';

function identity(scopes: string[]): ApiIdentity {
  return {
    authenticated: true,
    client: {
      name: 'acme-governance', platform: 'siem', description: null, project_id: 'project-1',
      token_hint: 'z9Yx', created_at: '2026-09-01T00:00:00Z',
    },
    scopes: { granted: scopes, meaning: Object.fromEntries(scopes.map((s) => [s, s])) },
    provisioned: { flows: 1, agents: 1, all_flows_in_project: false, all_agents_in_project: false },
    validity: { active: true, expires_at: null, expired: false },
    limits: { rate_limit_per_minute: 60 },
    usage: { calls: 3, last_used_at: '2026-09-21T10:00:00Z' },
    activity: { runs_total: 1, runs_by_disposition: { succeeded: 1 }, in_flight: 0, total_cost_usd: 0.01, last_run_at: null },
  };
}

const CATALOG: ApiCatalog = {
  project_id: 'project-1',
  counts: { flows: 0, agents: 1 },
  flows: [],
  agents: [
    {
      key: 'impact-analyzer',
      name: 'Impact Analyzer Agent',
      description: 'Traces a change.',
      category: 'Planning',
      invoke: { method: 'POST', path: '/integration/agents/impact-analyzer/runs', scope: 'agents:run' },
      input_schema: { type: 'object', properties: {} },
    },
  ],
};

const RUNS: ApiRunPage = {
  items: [
    {
      run_id: 'run-12345678', run_number: 1, title: 'Impact of login change', kind: 'agent',
      status: 'succeeded', disposition: 'succeeded', is_terminal: true, flow_id: null,
      started_at: '2026-09-21T09:00:00Z', finished_at: '2026-09-21T09:00:02Z', duration_ms: 2000,
      summary: 'High risk.', error: null, progress: { completed_steps: 1, total_steps: 1 },
      guardrails: { awaiting_approval: [] }, links: { self: '', cancel: '' },
    },
  ],
  total: 1, limit: 20, offset: 0,
};

const LOG: ApiRunLog = {
  schema_version: '1.0',
  run: { run_id: 'run-12345678', disposition: 'succeeded', duration_ms: 2000, correlation_id: 'c1' },
  activities: [
    {
      sequence: 1, node_key: 'agent', kind: 'agent', label: 'Impact Analyzer Agent',
      agent: { key: 'impact-analyzer', version: '1.0.0' }, status: 'succeeded', attempt: 1,
      started_at: null, finished_at: null, duration_ms: 1700, confidence: 0.9,
      model: { provider: 'bedrock', model: 'claude-haiku', deployment: null },
      usage: { prompt_tokens: 3000, completion_tokens: 400, total_tokens: 3400, cost_usd: 0.0123 },
      tools: [], policy: { effect: 'allow', requires_approval: false, policies: [] }, error: null,
    },
  ],
  timeline: [],
  approvals: [],
  audit: [{ event_id: 'a1', at: '2026-09-21T09:00:00Z', action: 'integration.agent_invoked', outcome: 'success' }],
  usage: { total_tokens: 3400, total_cost_usd: 0.0123, by_model: [] },
  redaction: { masked: {}, omitted: ['prompts and model responses', 'tool call arguments'] },
};

const METRICS: ApiMetrics = {
  schema_version: '1.0',
  window: { days: 30 },
  runs: { total: 4, by_disposition: { succeeded: 3, failed: 1 }, success_rate: 0.75, duration_ms: { p50: 1500, p95: 4200 }, total_cost_usd: 0.05 },
  by_model: [{ provider: 'bedrock', model: 'claude-haiku', calls: 6, failed_calls: 0, fallback_calls: 1 }],
  approvals: { requested: 2, pending: 1, median_wait_seconds: 300 },
};

function renderPortal() {
  return render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <ApiPortalPage />
    </QueryClientProvider>,
  );
}

function signIn() {
  fireEvent.change(screen.getByLabelText(/Your API key/i), { target: { value: KEY } });
  fireEvent.click(screen.getByRole('button', { name: /Sign in/i }));
}

beforeEach(() => {
  window.sessionStorage.clear();
  vi.spyOn(portalApi, 'catalog').mockResolvedValue(CATALOG);
  vi.spyOn(portalApi, 'runs').mockResolvedValue(RUNS);
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('ApiPortalPage governance', () => {
  it('fetches a model card with the key, not through a link', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity(['catalog:read', 'runs:read']));
    const document = vi.spyOn(portalApi, 'document').mockResolvedValue({ name: 'Impact Analyzer Agent' });
    const createUrl = vi.fn(() => 'blob:card');
    Object.assign(URL, { createObjectURL: createUrl, revokeObjectURL: vi.fn() });

    const { container } = renderPortal();
    signIn();
    fireEvent.click(await screen.findByRole('button', { name: /Model card/i }));

    await waitFor(() => expect(document).toHaveBeenCalledWith(KEY, '/integration/agents/impact-analyzer/model-card'));
    expect(createUrl).toHaveBeenCalled();
    // A link carrying the key would show up in the page as an href.
    expect(container.innerHTML).not.toContain(KEY);
  });

  it('offers the golden dataset beside the model card', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity(['catalog:read']));
    const document = vi.spyOn(portalApi, 'document').mockResolvedValue({});
    Object.assign(URL, { createObjectURL: vi.fn(() => 'blob:x'), revokeObjectURL: vi.fn() });

    renderPortal();
    signIn();
    fireEvent.click(await screen.findByRole('button', { name: /Golden dataset/i }));

    await waitFor(() =>
      expect(document).toHaveBeenCalledWith(KEY, '/integration/agents/impact-analyzer/golden-dataset'),
    );
  });

  it('shows what each agent in a run did, on which model, at what cost', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity(['runs:read', 'runs:logs']));
    vi.spyOn(portalApi, 'metrics').mockResolvedValue(METRICS);
    vi.spyOn(portalApi, 'runLog').mockResolvedValue(LOG);

    renderPortal();
    signIn();
    fireEvent.click(await screen.findByRole('button', { name: /^Log$/i }));

    // Wait on something only the log renders: the agent's name also appears in
    // the catalogue above, so finding it proves nothing about the log.
    expect(await screen.findByText('bedrock/claude-haiku')).toBeInTheDocument();
    expect(screen.getAllByText('Impact Analyzer Agent').length).toBeGreaterThan(1);
    expect(screen.getByText('3,400')).toBeInTheDocument();
    expect(screen.getByText(/tool call arguments/)).toBeInTheDocument();
  });

  it('tells a key without runs:logs which scope it needs', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity(['runs:read']));
    vi.spyOn(portalApi, 'runLog').mockRejectedValue(
      new ApiError(403, 'forbidden', "This API key does not have the 'runs:logs' scope.", { required_scope: 'runs:logs' }),
    );

    renderPortal();
    signIn();
    fireEvent.click(await screen.findByRole('button', { name: /^Log$/i }));

    expect(await screen.findByText(/does not have the runs:logs scope/i)).toBeInTheDocument();
  });

  it('shows metrics only to a key that may see them', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity(['runs:read']));
    const metrics = vi.spyOn(portalApi, 'metrics').mockResolvedValue(METRICS);

    renderPortal();
    signIn();
    await screen.findByText('acme-governance');

    expect(metrics).not.toHaveBeenCalled();
    expect(screen.queryByText('Success rate')).not.toBeInTheDocument();
  });

  it('shows success rate and p95 when the key holds runs:logs', async () => {
    vi.spyOn(portalApi, 'me').mockResolvedValue(identity(['runs:read', 'runs:logs']));
    vi.spyOn(portalApi, 'metrics').mockResolvedValue(METRICS);

    renderPortal();
    signIn();

    expect(await screen.findByText('75%')).toBeInTheDocument();
    expect(screen.getByText('4.2s')).toBeInTheDocument();
    expect(screen.getByText(/1 fell back to another model/)).toBeInTheDocument();
  });
});
