import { describe, expect, it } from 'vitest';
import { formatCurrency, formatPercent } from '@/hooks';
import { toSpeakable } from '@/hooks/useVoice';

describe('formatCurrency', () => {
  it('shows euros', () => {
    expect(formatCurrency(2.5)).toBe('€2.50');
    expect(formatCurrency(0.02051, 4)).toBe('€0.0205');
  });

  it('shows tiny non-zero amounts as a bound rather than €0.00', () => {
    expect(formatCurrency(0.004)).toBe('<€0.01');
    expect(formatCurrency(0)).toBe('€0.00');
  });

  it('shows a dash for missing values', () => {
    expect(formatCurrency(null)).toBe('—');
  });
});

describe('formatPercent', () => {
  it('formats ratios as percentages', () => {
    expect(formatPercent(0.851)).toBe('85.1%');
  });
});

describe('toSpeakable', () => {
  it('reads amounts, percentages and story keys as words', () => {
    expect(toSpeakable('PAY-201 costs €2.98 at 85%')).toBe('P A Y 201 costs 2.98 euros at 85 percent');
    expect(toSpeakable('Cost <€0.01')).toBe('Cost under 0.01 euros');
  });
});
