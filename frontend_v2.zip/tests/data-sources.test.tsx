/**
 * The data sources screen.
 *
 * A customer's credential passes through this page on its way to being
 * encrypted, and must never come back. So what is asserted here is mostly what
 * the page does *not* do: it does not put a secret in a readable input, it does
 * not send an empty field as a deliberate blanking, and it does not present a
 * reachability check as proof that a password works.
 */
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import DataSourcesPage from '@/pages/DataSourcesPage';
import { api } from '@/services/api';
import type { DataSource, DataSourceKind } from '@/types';

vi.mock('@/hooks', async () => {
  const actual = await vi.importActual<typeof import('@/hooks')>('@/hooks');
  return { ...actual, useProjectId: () => 'project-1' };
});

const KINDS: DataSourceKind[] = [
  {
    kind: 'postgres',
    required_fields: ['host', 'database'],
    optional_fields: ['port', 'username'],
    credential_fields: ['password'],
  },
  {
    kind: 'rest_api',
    required_fields: ['base_url'],
    optional_fields: [],
    credential_fields: ['api_key', 'bearer_token'],
  },
];

function source(overrides: Partial<DataSource> = {}): DataSource {
  return {
    id: 'ds-1',
    project_id: 'project-1',
    key: 'order-warehouse',
    name: 'Order warehouse',
    description: 'The reporting replica.',
    kind: 'postgres',
    status: 'connected',
    is_enabled: true,
    allow_writes: false,
    config: { host: 'warehouse.acme.example', database: 'orders' },
    credential_fields: ['password'],
    has_credentials: true,
    credential_fingerprint: 'a1b2c3d4e5f6',
    credential_updated_at: '2026-09-20T10:00:00Z',
    credential_updated_by: 'alex.morgan@example.com',
    last_tested_at: '2026-09-21T10:00:00Z',
    last_test_ok: true,
    last_error: null,
    created_by: 'alex.morgan@example.com',
    created_at: '2026-09-01T00:00:00Z',
    ...overrides,
  };
}

function renderPage() {
  return render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <DataSourcesPage />
    </QueryClientProvider>,
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('DataSourcesPage', () => {
  it('shows a connected source without offering its credential', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([source()]);

    renderPage();

    expect(await screen.findByText('Order warehouse')).toBeInTheDocument();
    expect(screen.getByText(/Credential stored, encrypted/i)).toBeInTheDocument();
    // The fingerprint stands in for the secret; the secret itself is nowhere.
    expect(screen.getByText('a1b2c3d4e5f6')).toBeInTheDocument();
    expect(screen.getByText(/cannot be read back/i)).toBeInTheDocument();
  });

  it('renders credential fields as password inputs, driven by the kind', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([]);

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Connect a data source/i }));

    const password = await screen.findByLabelText(/^Password$/i);
    // A readable input is a credential on a screen somebody can shoulder-surf,
    // and one the browser will offer to autofill elsewhere.
    expect(password).toHaveAttribute('type', 'password');
    // An ordinary setting stays readable: masking the host as well would make
    // the form unusable without protecting anything.
    expect(screen.getByLabelText(/^Host\*?$/i)).not.toHaveAttribute('type', 'password');
  });

  it('asks the server which fields are secret rather than deciding itself', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([]);

    renderPage();
    fireEvent.click(await screen.findByRole('button', { name: /Connect a data source/i }));

    fireEvent.change(screen.getByLabelText(/^Kind$/i), { target: { value: 'rest_api' } });

    // Both of the REST kind's credential fields appear, and the Postgres one
    // is gone -- because the list came from the server's own answer.
    expect(await screen.findByLabelText(/^Api key$/i)).toHaveAttribute('type', 'password');
    expect(screen.getByLabelText(/^Bearer token$/i)).toHaveAttribute('type', 'password');
    expect(screen.queryByLabelText(/^Password$/i)).not.toBeInTheDocument();
  });

  it('offers a kind’s optional settings, not only its required ones', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([]);

    renderPage();
    fireEvent.click(await screen.findByRole('button', { name: /Connect a data source/i }));

    // Without these there is no way to give a Postgres source a username or a
    // non-default port, and the connection would be unusable.
    expect(await screen.findByLabelText(/^Username$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^Port$/i)).toBeInTheDocument();
  });

  it('does not send blank credential fields, so they are not cleared', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([]);
    const connect = vi.spyOn(api, 'connectDataSource').mockResolvedValue(source());

    renderPage();
    fireEvent.click(await screen.findByRole('button', { name: /Connect a data source/i }));

    fireEvent.change(await screen.findByLabelText(/^Name$/i), {
      target: { value: 'Order warehouse' },
    });
    fireEvent.change(screen.getByLabelText(/^Host\*?$/i), { target: { value: 'db.acme.example' } });
    fireEvent.change(screen.getByLabelText(/^Database\*?$/i), { target: { value: 'orders' } });
    // Password deliberately left blank.
    fireEvent.click(screen.getByRole('button', { name: /^Connect$/i }));

    await waitFor(() => expect(connect).toHaveBeenCalled());
    const [, body] = connect.mock.calls[0];
    expect(body.connection).toEqual({ host: 'db.acme.example', database: 'orders' });
    expect(body.connection).not.toHaveProperty('password');
  });

  it('reports what a connection test actually proved', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([source()]);
    vi.spyOn(api, 'testDataSource').mockResolvedValue({
      ok: true,
      check: 'tcp',
      detail: 'A service is listening on warehouse.acme.example:5432.',
      proves: 'The host is reachable. The credentials were not used.',
      tested_at: '2026-09-22T09:00:00Z',
    });

    renderPage();
    fireEvent.click(await screen.findByRole('button', { name: /Test connection/i }));

    // The distinction that stops somebody believing the password was checked.
    expect(await screen.findByText(/The credentials were not used/i)).toBeInTheDocument();
  });

  it('warns that disconnecting destroys the credential, and does nothing if declined', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([source()]);
    const disconnect = vi.spyOn(api, 'disconnectDataSource');
    vi.spyOn(window, 'confirm').mockReturnValue(false);

    renderPage();
    fireEvent.click(await screen.findByRole('button', { name: /Disconnect/i }));

    expect(window.confirm).toHaveBeenCalledWith(expect.stringMatching(/credential is destroyed/i));
    expect(disconnect).not.toHaveBeenCalled();
  });

  it('says a source is read-only unless it was opened up', async () => {
    vi.spyOn(api, 'dataSourceKinds').mockResolvedValue(KINDS);
    vi.spyOn(api, 'dataSources').mockResolvedValue([
      source(),
      source({ id: 'ds-2', name: 'Writable store', allow_writes: true }),
    ]);

    renderPage();

    expect(await screen.findByText('Read-only')).toBeInTheDocument();
    expect(screen.getByText('Writes allowed')).toBeInTheDocument();
  });
});
