/**
 * The API endpoint card.
 *
 * Two things matter enough to pin. It must not fetch until it is opened --
 * otherwise every agent and flow page makes a request for a panel almost
 * nobody expands. And when a resource cannot be called it must say so, rather
 * than present an endpoint that would answer 404.
 */
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { ApiAccessCard } from '@/components/ApiAccessCard';
import { api } from '@/services/api';
import type { ApiAccess } from '@/types';

function access(overrides: Partial<ApiAccess> = {}): ApiAccess {
  return {
    kind: 'flow',
    id: 'flow-1',
    name: 'Requirement to Automated Test',
    available: true,
    unavailable_reason: null,
    endpoint: {
      method: 'POST',
      path: '/api/v1/integration/flows/flow-1/runs',
      url: 'https://qe.example.com/api/v1/integration/flows/flow-1/runs',
    },
    authentication: {
      scheme: 'api_key',
      header: 'X-API-Key',
      scope_required: 'flows:run',
      issued_by: 'an operator',
    },
    input_schema: { type: 'object', properties: {} },
    example: { body: { inputs: {} }, curl: 'curl -X POST ...' },
    polling: { note: '202 means accepted, not finished.', path: '/api/v1/integration/runs/{run_id}' },
    mcp: { tool: 'run_flow_requirement', endpoint: 'POST /api/v1/mcp', note: '' },
    documentation: { quickstart: 'docs', openapi: 'openapi', swagger: 'swagger' },
    keys: [
      {
        name: 'acme-partner',
        platform: 'acme',
        token_hint: 'jBVk',
        grant: 'project-wide',
        expires_at: null,
      },
    ],
    ...overrides,
  };
}

function renderCard(props: { resource?: 'agent' | 'flow'; id?: string } = {}) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <ApiAccessCard resource={props.resource ?? 'flow'} id={props.id ?? 'flow-1'} />
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  window.localStorage.clear();
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('ApiAccessCard', () => {
  it('shows nothing and fetches nothing until it is opened', () => {
    const fetcher = vi.spyOn(api, 'flowApiAccess').mockResolvedValue(access());

    renderCard();

    expect(fetcher).not.toHaveBeenCalled();
    expect(screen.getByRole('button', { name: /API endpoint/i })).toHaveAttribute('aria-expanded', 'false');
    expect(screen.queryByText(/X-API-Key/)).not.toBeInTheDocument();
  });

  it('reveals the endpoint, the scope and the MCP tool when shown', async () => {
    vi.spyOn(api, 'flowApiAccess').mockResolvedValue(access());

    renderCard();
    fireEvent.click(screen.getByRole('button', { name: /API endpoint/i }));

    expect(await screen.findByText('/api/v1/integration/flows/flow-1/runs')).toBeInTheDocument();
    expect(screen.getByText('flows:run')).toBeInTheDocument();
    expect(screen.getByText('run_flow_requirement')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /API endpoint/i })).toHaveAttribute('aria-expanded', 'true');
  });

  it('hides it again on a second click', async () => {
    vi.spyOn(api, 'flowApiAccess').mockResolvedValue(access());

    renderCard();
    const toggle = screen.getByRole('button', { name: /API endpoint/i });

    fireEvent.click(toggle);
    expect(await screen.findByText('flows:run')).toBeInTheDocument();

    fireEvent.click(toggle);
    await waitFor(() => expect(screen.queryByText('flows:run')).not.toBeInTheDocument());
    expect(toggle).toHaveAttribute('aria-expanded', 'false');
  });

  it('remembers that it was opened', async () => {
    vi.spyOn(api, 'flowApiAccess').mockResolvedValue(access());

    const first = renderCard();
    fireEvent.click(screen.getByRole('button', { name: /API endpoint/i }));
    await screen.findByText('flows:run');
    first.unmount();

    renderCard();

    await waitFor(() =>
      expect(screen.getByRole('button', { name: /API endpoint/i })).toHaveAttribute('aria-expanded', 'true'),
    );
  });

  it('names the keys that can call it, and how they were granted', async () => {
    vi.spyOn(api, 'flowApiAccess').mockResolvedValue(access());

    renderCard();
    fireEvent.click(screen.getByRole('button', { name: /API endpoint/i }));

    expect(await screen.findByText('acme-partner')).toBeInTheDocument();
    expect(screen.getByText('project-wide')).toBeInTheDocument();
    expect(screen.getByText('…jBVk')).toBeInTheDocument();
  });

  it('says why a resource cannot be called rather than implying it can', async () => {
    vi.spyOn(api, 'flowApiAccess').mockResolvedValue(
      access({
        available: false,
        keys: [],
        unavailable_reason: 'This flow is a draft, so a project-wide grant does not reach it.',
      }),
    );

    renderCard();
    fireEvent.click(screen.getByRole('button', { name: /API endpoint/i }));

    expect(await screen.findByText(/This flow is a draft/)).toBeInTheDocument();
    expect(screen.getByText(/No key can call this yet/)).toBeInTheDocument();
  });

  it('asks the agent endpoint for an agent', async () => {
    const agents = vi.spyOn(api, 'agentApiAccess').mockResolvedValue(access({ kind: 'agent' }));
    const flows = vi.spyOn(api, 'flowApiAccess');

    render(
      <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
        <ApiAccessCard resource="agent" id="agent-1" projectId="project-1" />
      </QueryClientProvider>,
    );
    fireEvent.click(screen.getByRole('button', { name: /API endpoint/i }));

    await waitFor(() => expect(agents).toHaveBeenCalledWith('agent-1', 'project-1'));
    expect(flows).not.toHaveBeenCalled();
  });

  it('reports a failure instead of rendering an empty panel', async () => {
    vi.spyOn(api, 'flowApiAccess').mockRejectedValue(new Error('nope'));

    renderCard();
    fireEvent.click(screen.getByRole('button', { name: /API endpoint/i }));

    expect(await screen.findByText(/could not be loaded/i)).toBeInTheDocument();
  });
});
