import { describe, expect, it } from 'vitest';
import {
  connect, createNode, insertAfter, insertionPoint, parseMappingValue, removeNodes, toPayload, uniqueNodeKey,
  type DraftEdge, type DraftNode, type FlowDraft,
} from '@/features/flow-builder/graph';
import type { AgentSummary } from '@/types';

function node(key: string, type: string, y: number): DraftNode {
  return {
    node_key: key, node_type: type, label: key, agent_id: null, agent_version: null,
    position_x: 120, position_y: y, sequence: 0, config: {}, input_mapping: {}, output_mapping: {},
    condition_expression: null, llm_config: {}, retry_policy: {}, timeout_seconds: null,
    on_failure: 'fail_flow', requires_approval: false, approval_role: null, cost_limit_usd: null,
  };
}

function edge(source: string, target: string, branch: string | null = null): DraftEdge {
  return { id: `${source}->${target}`, source_node_key: source, target_node_key: target, branch_label: branch, condition_expression: null };
}

const pairs = (draft: FlowDraft) => draft.edges.map((item) => `${item.source_node_key}->${item.target_node_key}`).sort();

/** start -> review -> end */
const linear: FlowDraft = {
  nodes: [node('start', 'start', 80), node('review', 'agent', 230), node('end', 'end', 380)],
  edges: [edge('start', 'review'), edge('review', 'end')],
};

const agent = { id: 'a1', key: 'test-data-generator', name: 'Test Data Generator', requires_approval: false } as AgentSummary;

describe('insertAfter', () => {
  it('splices a step into a single path and moves later steps down', () => {
    const added = createNode(linear, 'agent', { x: 0, y: 0 }, agent);
    const next = insertAfter(linear, added, 'review');

    expect(pairs(next)).toEqual(['review->test_data_generator', 'start->review', 'test_data_generator->end']);
    const placed = next.nodes.find((item) => item.node_key === 'test_data_generator')!;
    expect(placed.position_y).toBe(380);
    expect(next.nodes.find((item) => item.node_key === 'end')!.position_y).toBe(530);
  });

  it('gives a new condition a true branch onward', () => {
    const next = insertAfter(linear, createNode(linear, 'condition', { x: 0, y: 0 }), 'review');
    const onward = next.edges.find((item) => item.source_node_key === 'condition');
    expect(onward?.branch_label).toBe('true');
  });
});

describe('insertionPoint', () => {
  it('prefers the selected step', () => {
    expect(insertionPoint(linear, 'start')).toBe('start');
  });

  it('falls back to the step that leads into the end, so clicks build a sequence', () => {
    expect(insertionPoint(linear, null)).toBe('review');
    expect(insertionPoint(linear, 'end')).toBe('review');
  });
});

describe('connect', () => {
  it('labels a condition\'s first path true and its second false', () => {
    const draft: FlowDraft = {
      nodes: [node('gate', 'condition', 0), node('yes', 'agent', 150), node('no', 'agent', 150)],
      edges: [],
    };
    const next = connect(connect(draft, 'gate', 'yes'), 'gate', 'no');
    expect(next.edges.map((item) => item.branch_label)).toEqual(['true', 'false']);
  });

  it('ignores self-loops and duplicates', () => {
    expect(connect(linear, 'review', 'review')).toBe(linear);
    expect(connect(linear, 'start', 'review')).toBe(linear);
  });
});

describe('removeNodes', () => {
  it('bridges a removed middle step so the sequence stays connected', () => {
    expect(pairs(removeNodes(linear, ['review']))).toEqual(['start->end']);
  });

  it('keeps the incoming branch label when bridging', () => {
    const draft: FlowDraft = {
      nodes: [node('gate', 'condition', 0), node('step', 'agent', 150), node('end', 'end', 300)],
      edges: [edge('gate', 'step', 'false'), edge('step', 'end')],
    };
    const [bridge] = removeNodes(draft, ['step']).edges;
    expect(bridge.branch_label).toBe('false');
  });
});

describe('keys and payload', () => {
  it('makes readable keys that are safe in expressions', () => {
    expect(uniqueNodeKey('test-data-generator', [])).toBe('test_data_generator');
    expect(uniqueNodeKey('Human approval', ['human_approval'])).toBe('human_approval_2');
  });

  it('orders the saved sequence top to bottom', () => {
    const shuffled: FlowDraft = { ...linear, nodes: [...linear.nodes].reverse() };
    expect(toPayload(shuffled).nodes.map((item) => [item.node_key, item.sequence])).toEqual([
      ['start', 0],
      ['review', 1],
      ['end', 2],
    ]);
  });

  it('keeps typed mapping values typed and references as strings', () => {
    expect(parseMappingValue('80')).toBe(80);
    expect(parseMappingValue('true')).toBe(true);
    expect(parseMappingValue('$requirement_key')).toBe('$requirement_key');
  });
});
