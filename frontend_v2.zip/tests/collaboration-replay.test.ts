import { describe, expect, it } from 'vitest';
import { dwellMs, frameAt, handoffPairs } from '@/features/collaboration/replay';
import type { CollaborationMessage, RunCollaboration } from '@/types';

function message(partial: Partial<CollaborationMessage> & Pick<CollaborationMessage, 'kind' | 'from'>): CollaborationMessage {
  return { id: partial.kind + partial.from, index: 0, at: '2026-09-17T10:00:00Z', to: [], text: '', edges: [], data: {}, ...partial };
}

const collaboration: RunCollaboration = {
  run: { id: 'r', run_number: 1, title: 'Run', status: 'succeeded', trigger: 'manual', duration_ms: 1, is_live: false },
  graph: {
    nodes: [
      { node_key: 'start', node_type: 'start', label: 'Start', position_x: 0, position_y: 0, state: 'succeeded', duration_ms: 0, cost_usd: 0, tokens: 0 },
      { node_key: 'check', node_type: 'agent', label: 'Check', position_x: 0, position_y: 150, state: 'succeeded', duration_ms: 10, cost_usd: 0, tokens: 0 },
      { node_key: 'ready', node_type: 'condition', label: 'Ready?', position_x: 0, position_y: 300, state: 'succeeded', duration_ms: 0, cost_usd: 0, tokens: 0, decision: true },
      { node_key: 'design', node_type: 'agent', label: 'Design', position_x: 0, position_y: 450, state: 'succeeded', duration_ms: 10, cost_usd: 0, tokens: 0 },
      { node_key: 'clarify', node_type: 'approval', label: 'Clarify', position_x: 340, position_y: 450, state: 'not_reached', duration_ms: 0, cost_usd: 0, tokens: 0 },
    ],
    edges: [
      { id: 'start->check', source: 'start', target: 'check', state: 'traversed' },
      { id: 'check->ready', source: 'check', target: 'ready', state: 'traversed' },
      { id: 'ready->design', source: 'ready', target: 'design', branch_label: 'true', state: 'traversed' },
      { id: 'ready->clarify', source: 'ready', target: 'clarify', branch_label: 'false', state: 'not_taken' },
    ],
  },
  participants: [],
  conversation: [
    message({ kind: 'kickoff', from: 'orchestrator', to: ['check'], node_key: 'start', node_state: 'succeeded', edges: ['start->check'] }),
    message({ kind: 'acknowledge', from: 'check', node_key: 'check', node_state: 'running' }),
    message({ kind: 'handoff', from: 'check', to: ['ready'], node_key: 'check', node_state: 'succeeded', edges: ['check->ready'] }),
    message({ kind: 'decision', from: 'ready', to: ['design'], node_key: 'ready', node_state: 'succeeded', edges: ['ready->design'] }),
    message({ kind: 'handoff', from: 'design', to: ['orchestrator'], node_key: 'design', node_state: 'succeeded' }),
  ],
  context: [],
  stats: { agents: 2, messages: 5, handoffs: 2, decisions: 1, human_decisions: 0, shared_facts: 0 },
};

describe('frameAt', () => {
  it('starts with nothing done and shows the first hand-off travelling', () => {
    const frame = frameAt(collaboration, 0);
    expect(frame.nodeStates.check).toBe('pending');
    expect(frame.edgeStates['start->check']).toBe('active');
    expect(frame.pulses['start->check']).toBe('once');
    expect(frame.complete).toBe(false);
  });

  it('marks a working agent, then the path a decision did not take', () => {
    expect(frameAt(collaboration, 1).nodeStates.check).toBe('running');
    const afterDecision = frameAt(collaboration, 3);
    expect(afterDecision.edgeStates['check->ready']).toBe('traversed');
    expect(afterDecision.edgeStates['ready->clarify']).toBe('not_taken');
    expect(afterDecision.revealed.has('ready')).toBe(true);
    expect(afterDecision.revealed.has('design')).toBe(false);
  });

  it('uses the recorded final state once every message is shown', () => {
    const frame = frameAt(collaboration, 99);
    expect(frame.complete).toBe(true);
    expect(frame.nodeStates.clarify).toBe('not_reached');
    expect(frame.edgeStates['ready->clarify']).toBe('not_taken');
  });
});

describe('replay helpers', () => {
  it('dwells longer on hand-offs and speeds up', () => {
    expect(dwellMs('handoff', 1)).toBeGreaterThan(dwellMs('acknowledge', 1));
    expect(dwellMs('handoff', 4)).toBe(Math.round(dwellMs('handoff', 1) / 4));
  });

  it('pairs agents that handed work to each other', () => {
    const pairs = handoffPairs(collaboration);
    expect(pairs.map((pair) => `${pair.from}->${pair.to}`)).toEqual(['check->ready', 'ready->design', 'design->orchestrator']);
  });
});
