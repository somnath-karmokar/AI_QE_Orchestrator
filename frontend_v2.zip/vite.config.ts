import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  build: {
    // Monaco (~2.3 MB) is bundled for offline use but only loads with the
    // Automation page, so the default 500 kB warning is noise.
    chunkSizeWarningLimit: 2500,
  },
  server: {
    port: 5173,
    proxy: {
      // Keeps the browser on one origin in development, so cookies, CORS and
      // WebSocket upgrades behave the same as they would behind a reverse proxy.
      // Override with VITE_API_TARGET when the API runs on a non-default port.
      '/api': {
        target: process.env.VITE_API_TARGET ?? 'http://127.0.0.1:8000',
        changeOrigin: true,
        ws: true,
      },
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./tests/setup.ts'],
  },
});
