/**
 * Typed API client.
 *
 * All backend access goes through here: one place for auth headers, error
 * normalisation and correlation IDs. The UI never calls `fetch` directly and
 * never touches the database.
 */
import type {
  AgentDetail,
  AgentSummary,
  ApiAccess,
  ApiCatalog,
  ApiIdentity,
  ApiMetrics,
  ApiRunLog,
  ApiRunPage,
  ApprovalRequest,
  IntegrationClientCreate,
  IntegrationClientCreated,
  IntegrationClientOut,
  AuditLogEntry,
  CartItem,
  CostBreakdown,
  DashboardData,
  DataSource,
  DataSourceKind,
  DataSourceTestResult,
  DefectInsights,
  DefectPrediction,
  DefectRecord,
  ExecutionDetail,
  ExecutionTriage,
  HealingAnalytics,
  ExecutionSummary,
  FlowApiToken,
  FlowComposition,
  FlowDashboard,
  FlowDetail,
  FlowGovernance,
  FlowObservability,
  FlowReport,
  FlowStudioOverview,
  FlowSummary,
  FlowTemplate,
  GovernancePolicy,
  HealingRecord,
  KnowledgeDocument,
  KnowledgeOverview,
  KnowledgeSearchHit,
  KnowledgeSource,
  LoginResponse,
  McpServer,
  Page,
  ProjectDetail,
  ProjectSummary,
  CopilotCapabilities,
  CopilotMessage,
  CopilotConversation,
  CopilotTurn,
  ProviderStatus,
  RcaRecord,
  RegressionAnalysis,
  RequirementRecord,
  RunCollaboration,
  RunDetail,
  RunSummary,
  ScenarioRecord,
  SystemInfo,
  TestCaseRecord,
  TestDataSet,
  TestScript,
  TraceabilityMatrix,
  VectorCollection,
  VectorHealth,
} from '@/types';

const API_BASE = '/api/v1';
const TOKEN_KEY = 'aiqe.token';

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details: Record<string, unknown> = {},
    public correlationId?: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }

  /** True when re-authenticating would plausibly fix this. */
  get isAuthError() {
    return this.status === 401;
  }
}

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage can be unavailable in private mode; the session still works */
  }
}

type RequestOptions = {
  method?: string;
  body?: unknown;
  query?: Record<string, string | number | boolean | string[] | undefined | null>;
  signal?: AbortSignal;
};

function buildUrl(path: string, query?: RequestOptions['query']): string {
  const url = new URL(API_BASE + path, window.location.origin);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value === undefined || value === null || value === '') continue;
      if (Array.isArray(value)) {
        // Repeated keys, which FastAPI reads as a list.
        value.forEach((item) => url.searchParams.append(key, String(item)));
      } else {
        url.searchParams.set(key, String(value));
      }
    }
  }
  return url.pathname + url.search;
}

/**
 * A request authenticated by an integration key rather than a user session.
 *
 * The portal is used by someone who holds a key and has no account here, so it
 * cannot go through `request`. The key is supplied per call and is never kept
 * in this module.
 */
async function keyedRequest<T>(path: string, apiKey: string): Promise<T> {
  const response = await fetch(API_BASE + path, {
    headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
  });

  const correlationId = response.headers.get('X-Correlation-ID') ?? undefined;
  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;

  if (!response.ok) {
    const error = payload?.error ?? {};
    throw new ApiError(
      response.status,
      error.code ?? 'unknown_error',
      error.message ?? `Request failed with status ${response.status}`,
      error.details ?? {},
      error.correlation_id ?? correlationId,
    );
  }
  return payload as T;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, query, signal } = options;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(buildUrl(path, query), {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  });

  const correlationId = response.headers.get('X-Correlation-ID') ?? undefined;

  if (response.status === 204) return undefined as T;

  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;

  if (!response.ok) {
    const error = payload?.error ?? {};
    throw new ApiError(
      response.status,
      error.code ?? 'unknown_error',
      error.message ?? `Request failed with status ${response.status}`,
      error.details ?? {},
      error.correlation_id ?? correlationId,
    );
  }

  return payload as T;
}

/* -------------------------------------------------------------------------- */

export const api = {
  // ---- system / auth ----
  systemInfo: () => request<SystemInfo>('/system/info'),
  demoUsers: () =>
    request<{ email: string; full_name: string; role: string; role_label: string; job_title: string }[]>(
      '/auth/demo-users',
    ),
  login: (email: string, password: string) =>
    request<LoginResponse>('/auth/login', { method: 'POST', body: { email, password } }),
  me: () => request<LoginResponse['user']>('/auth/me'),

  // ---- copilot ----
  copilotMessage: (body: {
    project_id: string;
    message: string;
    conversation_id?: string;
    environment_id?: string;
    is_voice?: boolean;
    auto_execute?: boolean;
  }) => request<CopilotTurn>('/copilot/message', { method: 'POST', body }),
  copilotCapabilities: (projectId: string) =>
    request<CopilotCapabilities>('/copilot/capabilities', { query: { project_id: projectId } }),
  copilotConversations: (projectId: string) =>
    request<Page<CopilotConversation>>('/copilot/conversations', { query: { project_id: projectId, limit: 30 } }),
  copilotConversation: (id: string) =>
    request<CopilotConversation & { messages: unknown[] }>(`/copilot/conversations/${id}`),
  copilotReindexAgents: (projectId: string) =>
    request<{ message: string }>('/copilot/reindex-agents', { method: 'POST', query: { project_id: projectId } }),
  copilotFeedback: (messageId: string, rating: 'up' | 'down', note?: string) =>
    request<CopilotMessage>(`/copilot/messages/${messageId}/feedback`, { method: 'POST', body: { rating, note } }),

  // ---- projects ----
  listProjects: () => request<Page<ProjectSummary>>('/projects', { query: { limit: 100 } }),
  getProject: (id: string) => request<ProjectDetail>(`/projects/${id}`),
  updateProject: (id: string, body: Record<string, unknown>) =>
    request<ProjectDetail>(`/projects/${id}`, { method: 'PATCH', body }),
  createProject: (body: Record<string, unknown>) =>
    request<ProjectDetail>('/projects', { method: 'POST', body }),

  // ---- marketplace / agents ----
  marketplace: (query: Record<string, string | number | string[] | undefined>) =>
    request<Page<AgentSummary>>('/marketplace/agents', { query }),
  marketplaceFacets: (projectId?: string) =>
    request<{
      total: number;
      categories: { key: string; count: number }[];
      risk_levels: Record<string, number>;
      cost_tiers: Record<string, number>;
      tools: Record<string, number>;
    }>('/marketplace/facets', { query: { project_id: projectId } }),
  listAgents: (query: Record<string, string | number | boolean | undefined>) =>
    request<Page<AgentSummary>>('/agents', { query }),
  getAgent: (id: string) => request<AgentDetail>(`/agents/${id}`),
  agentApiAccess: (id: string, projectId: string) =>
    request<ApiAccess>(`/agents/${id}/api-access`, { query: { project_id: projectId } }),
  createAgent: (body: Record<string, unknown>) =>
    request<AgentDetail>('/agents', { method: 'POST', body }),
  updateAgent: (id: string, body: Record<string, unknown>) =>
    request<AgentDetail>(`/agents/${id}`, { method: 'PATCH', body }),
  cloneAgent: (id: string, projectId?: string) =>
    request<AgentDetail>(`/agents/${id}/clone`, { method: 'POST', query: { project_id: projectId } }),
  testAgent: (id: string, body: { project_id: string; inputs: Record<string, unknown> }) =>
    request<RunDetail>(`/agents/${id}/test`, { method: 'POST', body }),
  publishAgent: (id: string, body: { change_summary?: string }) =>
    request<AgentDetail>(`/agents/${id}/publish`, { method: 'POST', body }),
  agentVersions: (id: string) =>
    request<{ id: string; version: string; lifecycle_state: string; change_summary?: string; created_at: string }[]>(
      `/agents/${id}/versions`,
    ),

  // ---- cart ----
  getCart: (projectId: string) => request<CartItem[]>('/agent-cart', { query: { project_id: projectId } }),
  addToCart: (body: { agent_id: string; project_id: string; notes?: string }) =>
    request<CartItem>('/agent-cart', { method: 'POST', body }),
  removeFromCart: (itemId: string) =>
    request<{ message: string }>(`/agent-cart/${itemId}`, { method: 'DELETE' }),
  reorderCartItem: (itemId: string, sequence: number) =>
    request<CartItem>(`/agent-cart/${itemId}`, { method: 'PATCH', query: { sequence } }),
  buildFlowFromCart: (body: { project_id: string; name: string; description?: string }) =>
    request<FlowDetail>('/agent-cart/build-flow', { method: 'POST', body }),

  // ---- flows ----
  listFlows: (projectId: string) =>
    request<Page<FlowSummary>>('/flows', { query: { project_id: projectId, limit: 100 } }),
  getFlow: (id: string) => request<FlowDetail>(`/flows/${id}`),
  flowApiAccess: (id: string) => request<ApiAccess>(`/flows/${id}/api-access`),

  // ---- API keys, as an operator manages them ----
  integrationClients: (projectId: string) =>
    request<{ items: IntegrationClientOut[]; total: number }>('/integration-clients', {
      query: { project_id: projectId, limit: 100 },
    }),
  createIntegrationClient: (body: IntegrationClientCreate) =>
    request<IntegrationClientCreated>('/integration-clients', { method: 'POST', body }),
  rotateIntegrationClient: (id: string) =>
    request<IntegrationClientCreated>(`/integration-clients/${id}/rotate`, { method: 'POST' }),
  revokeIntegrationClient: (id: string) =>
    request<{ message: string }>(`/integration-clients/${id}`, { method: 'DELETE' }),
  createFlow: (body: Record<string, unknown>) => request<FlowDetail>('/flows', { method: 'POST', body }),
  updateFlow: (id: string, body: Record<string, unknown>) =>
    request<FlowDetail>(`/flows/${id}`, { method: 'PATCH', body }),
  validateFlow: (id: string) =>
    request<{ valid: boolean; errors: { code: string; message: string }[]; warnings: { code: string; message: string }[] }>(
      `/flows/${id}/validate`,
      { method: 'POST' },
    ),
  publishFlow: (id: string, changeSummary?: string) =>
    request<FlowDetail>(`/flows/${id}/publish`, { method: 'POST', query: { change_summary: changeSummary } }),
  runFlow: (id: string, body: { inputs: Record<string, unknown>; environment_id?: string; synchronous?: boolean }) =>
    request<RunDetail>(`/flows/${id}/run`, { method: 'POST', body }),
  deleteFlow: (id: string) => request<{ message: string }>(`/flows/${id}`, { method: 'DELETE' }),

  // ---- flow studio ----
  flowOverview: (projectId: string, windowDays = 30) =>
    request<FlowStudioOverview>('/flows/overview', { query: { project_id: projectId, window_days: windowDays } }),
  flowTemplates: (projectId: string) =>
    request<FlowTemplate[]>('/flows/templates', { query: { project_id: projectId } }),
  composeFlow: (body: { project_id: string; description: string; name?: string }) =>
    request<FlowComposition>('/flows/compose', { method: 'POST', body }),
  createFlowFromTemplate: (body: Record<string, unknown>) =>
    request<FlowDetail>('/flows/from-template', { method: 'POST', body }),
  updateFlowSettings: (id: string, body: Record<string, unknown>) =>
    request<FlowDetail>(`/flows/${id}/settings`, { method: 'PATCH', body }),
  flowDashboard: (id: string, windowDays = 30) =>
    request<FlowDashboard>(`/flows/${id}/dashboard`, { query: { window_days: windowDays } }),
  flowObservability: (id: string, windowDays = 14) =>
    request<FlowObservability>(`/flows/${id}/observability`, { query: { window_days: windowDays } }),
  flowGovernance: (id: string, windowDays = 90) =>
    request<FlowGovernance>(`/flows/${id}/governance`, { query: { window_days: windowDays } }),
  flowReport: (id: string, windowDays = 30) =>
    request<FlowReport>(`/flows/${id}/report`, { query: { window_days: windowDays } }),
  flowReportMarkdown: async (id: string, windowDays = 30): Promise<{ filename: string; text: string }> => {
    const token = getToken();
    const response = await fetch(buildUrl(`/flows/${id}/report`, { window_days: windowDays, format: 'markdown' }), {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!response.ok) throw new ApiError(response.status, 'report_failed', 'The report could not be downloaded.');
    const disposition = response.headers.get('Content-Disposition') ?? '';
    const filename = /filename="([^"]+)"/.exec(disposition)?.[1] ?? 'flow-report.md';
    return { filename, text: await response.text() };
  },
  flowRuns: (id: string, query: Record<string, string | number | undefined>) =>
    request<Page<RunSummary>>(`/flows/${id}/runs`, { query }),
  createFlowApiToken: (id: string) => request<FlowApiToken>(`/flows/${id}/api-token`, { method: 'POST' }),
  revokeFlowApiToken: (id: string) => request<{ message: string }>(`/flows/${id}/api-token`, { method: 'DELETE' }),

  // ---- runs ----
  listRuns: (query: Record<string, string | number | undefined>) =>
    request<Page<RunSummary>>('/runs', { query }),
  getRun: (id: string) => request<RunDetail>(`/runs/${id}`),
  runCollaboration: (id: string) => request<RunCollaboration>(`/runs/${id}/collaboration`),
  runMessages: (id: string) =>
    request<{ id: string; event_type: string; content: string; created_at: string }[]>(`/runs/${id}/messages`),
  cancelRun: (id: string) => request<RunDetail>(`/runs/${id}/cancel`, { method: 'POST' }),
  resumeRun: (id: string) => request<RunDetail>(`/runs/${id}/resume`, { method: 'POST' }),

  // ---- test engineering ----
  listRequirements: (query: Record<string, string | number | undefined>) =>
    request<Page<RequirementRecord>>('/requirements', { query }),
  getRequirement: (id: string) => request<RequirementRecord>(`/requirements/${id}`),
  listScenarios: (query: Record<string, string | number | undefined>) =>
    request<Page<ScenarioRecord>>('/scenarios', { query }),
  listTestCases: (query: Record<string, string | number | boolean | undefined>) =>
    request<Page<TestCaseRecord>>('/test-cases', { query }),
  getTestCase: (id: string) => request<TestCaseRecord>(`/test-cases/${id}`),
  listScripts: (query: Record<string, string | number | undefined>) =>
    request<Page<TestScript>>('/test-scripts', { query }),
  getScript: (id: string) => request<TestScript>(`/test-scripts/${id}`),
  listTestData: (query: Record<string, string | number | undefined>) =>
    request<Page<TestDataSet>>('/test-data', { query }),

  // ---- executions ----
  listExecutions: (query: Record<string, string | number | undefined>) =>
    request<Page<ExecutionSummary>>('/executions', { query }),
  getExecution: (id: string) => request<ExecutionDetail>(`/executions/${id}`),
  startExecution: (body: Record<string, unknown>) =>
    request<ExecutionDetail>('/executions', { method: 'POST', body }),
  cancelExecution: (id: string) => request<ExecutionDetail>(`/executions/${id}/cancel`, { method: 'POST' }),
  retryFailed: (id: string) => request<ExecutionDetail>(`/executions/${id}/retry-failed`, { method: 'POST' }),
  healingAnalytics: (projectId: string, windowDays = 30) =>
    request<HealingAnalytics>('/healing/analytics', { query: { project_id: projectId, window_days: windowDays } }),
  executionTriage: (id: string) => request<ExecutionTriage>(`/executions/${id}/triage`),
  executionArtifacts: (id: string) =>
    request<{ id: string; artifact_type: string; name: string; size_bytes: number; metadata: Record<string, unknown> }[]>(
      `/executions/${id}/artifacts`,
    ),

  // ---- quality intelligence ----
  listDefects: (query: Record<string, string | number | undefined>) =>
    request<Page<DefectRecord>>('/defects', { query }),
  getDefect: (id: string) => request<DefectRecord>(`/defects/${id}`),
  defectInsights: (projectId: string) =>
    request<DefectInsights>('/defects/insights', { query: { project_id: projectId } }),
  defectAnalyses: (id: string) =>
    request<
      {
        id: string;
        agent_key: string;
        analysis_type: string;
        summary: string;
        confidence: number;
        findings: Record<string, unknown>[];
        recommendations: Record<string, unknown>[];
      }[]
    >(`/defects/${id}/analyses`),
  analyzeDefect: (body: Record<string, unknown>) =>
    request<RunDetail>('/defects/analyze', { method: 'POST', body }),
  listRca: (query: Record<string, string | number | undefined>) => request<Page<RcaRecord>>('/rca', { query }),
  getRca: (id: string) => request<RcaRecord>(`/rca/${id}`),
  decideRca: (id: string, decision: 'accept' | 'reject', notes?: string) =>
    request<RcaRecord>(`/rca/${id}/decide`, { method: 'POST', body: { decision, notes } }),
  listPredictions: (projectId: string) =>
    request<DefectPrediction[]>('/predictions', { query: { project_id: projectId } }),
  listHealing: (query: Record<string, string | number | undefined>) =>
    request<Page<HealingRecord>>('/healing', { query }),
  decideHealing: (id: string, decision: 'approve' | 'reject') =>
    request<HealingRecord>(`/healing/${id}/decide`, { method: 'POST', query: { decision } }),
  listRegression: (projectId: string) =>
    request<Page<RegressionAnalysis>>('/regression', { query: { project_id: projectId, limit: 20 } }),
  traceability: (projectId: string, module?: string) =>
    request<TraceabilityMatrix>('/traceability', { query: { project_id: projectId, module } }),
  coverage: (projectId: string) =>
    request<Record<string, unknown>>('/coverage', { query: { project_id: projectId } }),

  // ---- knowledge ----
  knowledgeOverview: (projectId: string) =>
    request<KnowledgeOverview>('/knowledge', { query: { project_id: projectId } }),
  knowledgeSources: (projectId: string) =>
    request<KnowledgeSource[]>('/knowledge/sources', { query: { project_id: projectId } }),
  knowledgeDocuments: (query: Record<string, string | number | undefined>) =>
    request<Page<KnowledgeDocument>>('/knowledge/documents', { query }),
  knowledgeDocument: (id: string) =>
    request<KnowledgeDocument & { content: string; chunks: { index: number; content: string; tokens: number }[] }>(
      `/knowledge/documents/${id}`,
    ),
  knowledgeSearch: (projectId: string, body: { query: string; collection?: string; limit?: number; module?: string }) =>
    request<KnowledgeSearchHit[]>('/knowledge/search', { method: 'POST', body, query: { project_id: projectId } }),
  knowledgeSync: (projectId: string) =>
    request<{ message: string; details: Record<string, unknown> }>('/knowledge/sync', {
      method: 'POST',
      query: { project_id: projectId },
    }),

  // ---- governance ----
  listPolicies: (projectId?: string) =>
    request<GovernancePolicy[]>('/governance/policies', { query: { project_id: projectId } }),
  updatePolicy: (id: string, body: Record<string, unknown>) =>
    request<GovernancePolicy>(`/governance/policies/${id}`, { method: 'PATCH', body }),
  listApprovals: (query: Record<string, string | number | undefined>) =>
    request<Page<ApprovalRequest>>('/governance/approvals', { query }),
  decideApproval: (id: string, decision: 'approve' | 'reject', notes?: string) =>
    request<ApprovalRequest>(`/governance/approvals/${id}/decide`, {
      method: 'POST',
      body: { decision, notes, resume_run: true },
    }),
  listAudit: (query: Record<string, string | number | undefined>) =>
    request<Page<AuditLogEntry>>('/audit', { query }),

  // ---- platform ----
  dashboard: (projectId: string, windowDays = 30) =>
    request<DashboardData>('/dashboard', { query: { project_id: projectId, window_days: windowDays } }),
  aiProviders: () =>
    request<{ default_provider: string; demo_mode: boolean; providers: ProviderStatus[] }>('/ai/providers'),
  testProvider: (provider: string) =>
    request<ProviderStatus>('/ai/providers/test', { method: 'POST', query: { provider } }),
  aiModels: (provider?: string) =>
    request<
      {
        provider: string;
        model_key: string;
        display_name: string;
        tier: string;
        capabilities: string[];
        context_window: number;
        input_cost_per_1k: number;
        output_cost_per_1k: number;
        deployment: string | null;
      }[]
    >('/ai/models', { query: { provider } }),
  aiRouting: (projectId?: string) =>
    request<
      {
        id: string;
        name: string;
        capability: string;
        complexity: string;
        provider_key: string;
        model_key: string;
        fallback_model_key: string | null;
        max_tokens: number;
        temperature: number;
        notes: string | null;
      }[]
    >('/ai/routing', { query: { project_id: projectId } }),
  llmUsage: (projectId: string, days = 30) =>
    request<CostBreakdown>('/llm/usage', { query: { project_id: projectId, days } }),
  vectorHealth: () => request<VectorHealth>('/vector/health'),
  vectorCollections: () => request<VectorCollection[]>('/vector/collections'),
  reindex: (projectId: string) =>
    request<{ message: string }>('/vector/reindex', { method: 'POST', query: { project_id: projectId } }),
  mcpServers: (projectId: string) =>
    request<McpServer[]>('/mcp/servers', { query: { project_id: projectId } }),
  invokeTool: (projectId: string, server: string, tool: string, args: Record<string, unknown>) =>
    request<{ tool: string; server: string; success: boolean; data: unknown; error: string | null; duration_ms: number }>(
      '/mcp/invoke',
      { method: 'POST', body: args, query: { project_id: projectId, server, tool } },
    ),
  systemJobs: () =>
    request<{ jobs: { job_id: string; name: string; status: string; submitted_at: string }[] }>('/system/jobs'),
  resetDemo: () => request<{ message: string }>('/system/demo/reset', { method: 'POST' }),

  // ----- Connected data sources ---------------------------------------------
  // `connection` carries the credential fields alongside the ordinary ones.
  // The server decides which are secret from the kind, so nothing here has to
  // be trusted to sort them, and no response ever carries one back.
  dataSourceKinds: () => request<DataSourceKind[]>('/data-sources/kinds'),
  dataSources: (projectId: string) =>
    request<DataSource[]>('/data-sources', { query: { project_id: projectId } }),
  connectDataSource: (
    projectId: string,
    body: {
      name: string;
      kind: string;
      description?: string;
      connection: Record<string, unknown>;
      allow_writes?: boolean;
    },
  ) => request<DataSource>('/data-sources', { method: 'POST', body, query: { project_id: projectId } }),
  updateDataSource: (
    projectId: string,
    id: string,
    body: {
      name?: string;
      description?: string;
      connection?: Record<string, unknown>;
      allow_writes?: boolean;
      is_enabled?: boolean;
    },
  ) =>
    request<DataSource>(`/data-sources/${id}`, {
      method: 'PATCH',
      body,
      query: { project_id: projectId },
    }),
  testDataSource: (projectId: string, id: string) =>
    request<DataSourceTestResult>(`/data-sources/${id}/test`, {
      method: 'POST',
      query: { project_id: projectId },
    }),
  disconnectDataSource: (projectId: string, id: string) =>
    request<{ message: string }>(`/data-sources/${id}`, {
      method: 'DELETE',
      query: { project_id: projectId },
    }),
};

/** WebSocket URL for live run/execution events, carrying the token as a query param. */
/**
 * The self-service portal an API consumer uses.
 *
 * These call the same integration endpoints a pipeline calls, authenticating
 * with the caller's own `X-API-Key` rather than an operator's session. The key
 * is passed in on every call and never stored by this module.
 */
export const portalApi = {
  me: (key: string) => keyedRequest<ApiIdentity>('/integration/me', key),
  catalog: (key: string) => keyedRequest<ApiCatalog>('/integration/catalog', key),
  runs: (key: string, limit = 20) =>
    keyedRequest<ApiRunPage>(`/integration/runs?limit=${limit}`, key),
  // Needs the runs:logs scope; a key without it gets a 403 naming the scope.
  runLog: (key: string, runId: string) =>
    keyedRequest<ApiRunLog>(`/integration/runs/${encodeURIComponent(runId)}/log`, key),
  metrics: (key: string, days = 30) =>
    keyedRequest<ApiMetrics>(`/integration/metrics?days=${days}`, key),
  /** A model card, golden dataset or other governance document, by its API path. */
  document: (key: string, path: string) => keyedRequest<Record<string, unknown>>(path, key),
};


export function streamUrl(path: string): string {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const token = getToken() ?? '';
  return `${protocol}//${window.location.host}${API_BASE}${path}?token=${encodeURIComponent(token)}`;
}
