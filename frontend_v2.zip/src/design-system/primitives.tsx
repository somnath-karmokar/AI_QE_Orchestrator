/**
 * Enterprise design-system primitives.
 *
 * Restrained on purpose (spec §25): moderate radii, 1px borders, minimal
 * shadow, semantic colour used sparingly. Status is never conveyed by colour
 * alone -- every badge carries a text label, and icon-only controls carry an
 * accessible name.
 */
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import {
  forwardRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react';
import { Check, Copy, Loader2 } from 'lucide-react';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/* -------------------------------------------------------------------------- */
/* Button                                                                     */
/* -------------------------------------------------------------------------- */

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'subtle';
type ButtonSize = 'sm' | 'md' | 'lg' | 'icon';

const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary:
    'bg-navy-700 text-ink-inverse border border-navy-700 hover:bg-navy-800 active:bg-navy-900 disabled:bg-navy-700/50 disabled:border-transparent',
  secondary:
    'bg-surface text-ink border border-line-strong hover:bg-surface-muted active:bg-surface-sunken',
  ghost: 'bg-transparent text-ink-secondary border border-transparent hover:bg-surface-sunken hover:text-ink',
  danger:
    'bg-danger text-ink-inverse border border-danger hover:bg-danger-text active:bg-danger-text',
  subtle: 'bg-brand-50 text-brand-700 border border-brand-100 hover:bg-brand-100',
};

const BUTTON_SIZES: Record<ButtonSize, string> = {
  sm: 'h-8 px-3 text-xs gap-1.5',
  md: 'h-9 px-3.5 text-sm gap-2',
  lg: 'h-10 px-5 text-base gap-2',
  icon: 'h-9 w-9 p-0 justify-center',
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant = 'secondary', size = 'md', loading, icon, children, disabled, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cn(
        'inline-flex items-center justify-center rounded font-medium transition-colors',
        'disabled:cursor-not-allowed disabled:opacity-60',
        BUTTON_VARIANTS[variant],
        BUTTON_SIZES[size],
        className,
      )}
      {...props}
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> : icon}
      {children}
    </button>
  );
});

/* -------------------------------------------------------------------------- */
/* Card                                                                       */
/* -------------------------------------------------------------------------- */

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn('rounded-lg border border-line bg-surface shadow-card', className)}
      {...props}
    />
  );
}

export function CardHeader({
  title,
  description,
  actions,
  className,
  icon,
}: {
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  className?: string;
  icon?: ReactNode;
}) {
  return (
    <div className={cn('flex items-start justify-between gap-4 border-b border-line px-5 py-4', className)}>
      <div className="flex min-w-0 items-start gap-3">
        {icon ? <div className="mt-0.5 text-ink-secondary">{icon}</div> : null}
        <div className="min-w-0">
          <h3 className="truncate text-md font-semibold text-ink">{title}</h3>
          {description ? (
            <p className="mt-0.5 text-sm text-ink-secondary">{description}</p>
          ) : null}
        </div>
      </div>
      {actions ? <div className="flex shrink-0 items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function CardBody({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('p-5', className)} {...props} />;
}

/* -------------------------------------------------------------------------- */
/* Badge                                                                      */
/* -------------------------------------------------------------------------- */

type BadgeTone = 'neutral' | 'brand' | 'success' | 'warning' | 'danger' | 'info';

const BADGE_TONES: Record<BadgeTone, string> = {
  neutral: 'bg-surface-sunken text-ink-secondary border-line',
  brand: 'bg-brand-50 text-brand-700 border-brand-100',
  success: 'bg-success-bg text-success-text border-success-border',
  warning: 'bg-warning-bg text-warning-text border-warning-border',
  danger: 'bg-danger-bg text-danger-text border-danger-border',
  info: 'bg-info-bg text-info-text border-info-border',
};

export function Badge({
  tone = 'neutral',
  className,
  children,
  dot,
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: BadgeTone; dot?: boolean }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded border px-2 py-0.5 text-2xs font-medium',
        BADGE_TONES[tone],
        className,
      )}
      {...props}
    >
      {dot ? <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden /> : null}
      {children}
    </span>
  );
}

/** Maps domain vocabularies onto badge tones consistently across the app. */
export const TONE_BY_STATUS: Record<string, BadgeTone> = {
  // run / execution
  succeeded: 'success', passed: 'success', active: 'success', published: 'success',
  connected: 'success', healthy: 'success', approved: 'success', applied: 'success',
  accepted: 'success', indexed: 'success', online: 'success', resolved: 'success', closed: 'success',
  running: 'info', queued: 'info', indexing: 'info', validated: 'info', in_progress: 'info',
  triage: 'info', test: 'info', review: 'info',
  awaiting_approval: 'warning', pending: 'warning', proposed: 'warning', partial: 'warning',
  partially_succeeded: 'warning', flaky: 'warning', degraded: 'warning', stale: 'warning',
  draft: 'warning', needs_review: 'warning', not_configured: 'warning', open: 'warning',
  failed: 'danger', error: 'danger', rejected: 'danger', aborted: 'danger', blocked: 'danger',
  cancelled: 'neutral', skipped: 'neutral', deprecated: 'neutral', archived: 'neutral',
};

export function statusTone(status?: string | null): BadgeTone {
  if (!status) return 'neutral';
  return TONE_BY_STATUS[status.toLowerCase()] ?? 'neutral';
}

export const TONE_BY_RISK: Record<string, BadgeTone> = {
  low: 'success', medium: 'warning', high: 'danger', critical: 'danger',
};

export const TONE_BY_SEVERITY: Record<string, BadgeTone> = {
  blocker: 'danger', critical: 'danger', major: 'warning', minor: 'info', trivial: 'neutral',
};

/** Humanises snake_case / kebab-case values for display. */
export function humanize(value?: string | null): string {
  if (!value) return '';
  return value.replace(/[_-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

/* -------------------------------------------------------------------------- */
/* Form controls                                                              */
/* -------------------------------------------------------------------------- */

const FIELD_BASE =
  'w-full rounded border border-line-strong bg-surface px-3 text-base text-ink placeholder:text-ink-tertiary ' +
  'transition-colors hover:border-ink-tertiary focus:border-brand-500 disabled:cursor-not-allowed disabled:bg-surface-sunken';

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return <input ref={ref} className={cn(FIELD_BASE, 'h-9', className)} {...props} />;
  },
);

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, ...props }, ref) {
    return <textarea ref={ref} className={cn(FIELD_BASE, 'py-2 leading-6', className)} {...props} />;
  },
);

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(
  function Select({ className, children, ...props }, ref) {
    return (
      <select ref={ref} className={cn(FIELD_BASE, 'h-9 pr-8', className)} {...props}>
        {children}
      </select>
    );
  },
);

export function Field({
  label,
  hint,
  error,
  required,
  htmlFor,
  children,
  className,
}: {
  label: string;
  hint?: string;
  error?: string;
  required?: boolean;
  htmlFor?: string;
  children: ReactNode;
  className?: string;
}) {
  const describedBy = error ? `${htmlFor}-error` : hint ? `${htmlFor}-hint` : undefined;
  return (
    <div className={cn('space-y-1.5', className)}>
      <label htmlFor={htmlFor} className="block text-sm font-medium text-ink">
        {label}
        {required ? (
          <span className="ml-1 text-danger" aria-label="required">
            *
          </span>
        ) : null}
      </label>
      {/* aria-describedby is wired by the caller passing the same htmlFor. */}
      <div aria-describedby={describedBy}>{children}</div>
      {hint && !error ? (
        <p id={`${htmlFor}-hint`} className="text-xs text-ink-secondary">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={`${htmlFor}-error`} role="alert" className="text-xs font-medium text-danger-text">
          {error}
        </p>
      ) : null}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Layout helpers                                                             */
/* -------------------------------------------------------------------------- */

export function PageHeader({
  title,
  description,
  actions,
  breadcrumb,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
  breadcrumb?: ReactNode;
}) {
  return (
    <header className="mb-6">
      {breadcrumb ? <div className="mb-2">{breadcrumb}</div> : null}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-3xl font-semibold tracking-[-0.02em] text-ink">{title}</h1>
          {description ? (
            <p className="mt-1.5 max-w-3xl text-md text-ink-secondary text-balance">{description}</p>
          ) : null}
        </div>
        {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
      </div>
    </header>
  );
}

export function SectionTitle({
  children,
  actions,
  className,
}: {
  children: ReactNode;
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('mb-3 flex items-center justify-between gap-3', className)}>
      <h2 className="text-xl font-semibold text-ink">{children}</h2>
      {actions}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex flex-col items-center justify-center px-6 py-14 text-center', className)}>
      {icon ? (
        <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-lg border border-line bg-surface-muted text-ink-tertiary">
          {icon}
        </div>
      ) : null}
      <h3 className="text-md font-semibold text-ink">{title}</h3>
      {description ? (
        <p className="mt-1 max-w-md text-sm text-ink-secondary text-balance">{description}</p>
      ) : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton h-4 w-full', className)} aria-hidden />;
}

export function LoadingBlock({ rows = 4, className }: { rows?: number; className?: string }) {
  return (
    <div className={cn('space-y-3 p-5', className)} role="status" aria-label="Loading">
      {Array.from({ length: rows }).map((_, index) => (
        <Skeleton key={index} className={index === 0 ? 'w-1/3' : undefined} />
      ))}
      <span className="sr-only">Loading</span>
    </div>
  );
}

export function ErrorState({
  title = 'Something went wrong',
  message,
  onRetry,
}: {
  title?: string;
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <div role="alert" className="rounded-lg border border-danger-border bg-danger-bg px-5 py-4">
      <h3 className="text-sm font-semibold text-danger-text">{title}</h3>
      {message ? <p className="mt-1 text-sm text-danger-text/90">{message}</p> : null}
      {onRetry ? (
        <Button size="sm" variant="secondary" className="mt-3" onClick={onRetry}>
          Try again
        </Button>
      ) : null}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Data display                                                               */
/* -------------------------------------------------------------------------- */

export function ProgressBar({
  value,
  tone = 'brand',
  label,
  className,
}: {
  value: number;
  tone?: 'brand' | 'success' | 'warning' | 'danger';
  label?: string;
  className?: string;
}) {
  const percent = Math.max(0, Math.min(100, value * 100));
  const fill = {
    brand: 'bg-brand-500',
    success: 'bg-success',
    warning: 'bg-warning',
    danger: 'bg-danger',
  }[tone];
  return (
    <div
      className={cn('h-1.5 w-full overflow-hidden rounded-full bg-surface-sunken', className)}
      role="progressbar"
      aria-valuenow={Math.round(percent)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
    >
      <div className={cn('h-full rounded-full transition-all', fill)} style={{ width: `${percent}%` }} />
    </div>
  );
}

export function Tooltip({ label, children }: { label: string; children: ReactNode }) {
  return (
    <span className="group relative inline-flex">
      {children}
      <span
        role="tooltip"
        className="pointer-events-none absolute bottom-full left-1/2 z-30 mb-1.5 -translate-x-1/2 whitespace-nowrap
                   rounded bg-navy-800 px-2 py-1 text-2xs font-medium text-ink-inverse opacity-0
                   shadow-popover transition-opacity group-hover:opacity-100 group-focus-within:opacity-100"
      >
        {label}
      </span>
    </span>
  );
}

/** Copies text and says so, briefly. Used wherever the UI shows something
 *  meant to be pasted somewhere else: a token, a URL, a request body. */
export function CopyButton({
  text,
  label,
  className,
}: {
  text: string;
  label: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={() => {
        void navigator.clipboard?.writeText(text).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 1600);
        });
      }}
      className={cn(
        'inline-flex h-7 shrink-0 items-center gap-1 rounded border border-line bg-surface px-2',
        'text-2xs font-medium text-ink-secondary transition-colors hover:bg-surface-muted',
        'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand-500',
        className,
      )}
      aria-label={label}
    >
      {copied ? <Check className="h-3 w-3 text-success" aria-hidden /> : <Copy className="h-3 w-3" aria-hidden />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}


export function KeyValue({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="py-2">
      <dt className="text-xs font-medium uppercase tracking-wide text-ink-tertiary">{label}</dt>
      <dd className="mt-1 text-sm text-ink">{children}</dd>
    </div>
  );
}
