/**
 * Settings: AI provider status, model catalogue, routing policy and vector store.
 * Secret values are never returned by the API and are never rendered here.
 */
import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { AlertTriangle, Cpu, Database, KeyRound, RefreshCw, Route, Server, Zap } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, useSystemInfo, formatNumber } from '@/hooks';
import { useSession } from '@/store';
import {
  Badge, Button, Card, CardBody, CardHeader, KeyValue, LoadingBlock,
  PageHeader, statusTone,
} from '@/design-system/primitives';

export default function SettingsPage() {
  const projectId = useProjectId();
  const user = useSession((state) => state.user);
  const { data: systemInfo } = useSystemInfo();
  const [resetMessage, setResetMessage] = useState<string | null>(null);

  const { data: providers, isLoading } = useQuery({ queryKey: ['ai-providers'], queryFn: api.aiProviders });
  const { data: models } = useQuery({ queryKey: ['ai-models'], queryFn: () => api.aiModels() });
  const { data: routing } = useQuery({
    queryKey: ['ai-routing', projectId],
    queryFn: () => api.aiRouting(projectId ?? undefined),
  });
  const { data: vector } = useQuery({ queryKey: ['vector-health'], queryFn: api.vectorHealth });

  const testProvider = useMutation({ mutationFn: (provider: string) => api.testProvider(provider) });
  const resetDemo = useMutation({
    mutationFn: api.resetDemo,
    onSuccess: (result) => setResetMessage(result.message),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  return (
    <div>
      <PageHeader
        title="Settings"
        description="Platform configuration: AI providers, model routing, vector store and demo controls."
      />

      <div className="space-y-5">
        <Card>
          <CardHeader title="Your account" icon={<KeyRound className="h-4 w-4" />} />
          <CardBody>
            <dl className="grid gap-x-8 sm:grid-cols-2">
              <KeyValue label="Name">{user?.full_name}</KeyValue>
              <KeyValue label="Email">{user?.email}</KeyValue>
              <KeyValue label="Role">{user?.job_title ?? user?.role_key}</KeyValue>
              <KeyValue label="Permissions">
                {user?.permissions.includes('*') ? 'All permissions' : `${user?.permissions.length} granted`}
              </KeyValue>
            </dl>
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="AI providers"
            description="Connectivity status. Secret values stay server-side and are never returned to the browser."
            icon={<Cpu className="h-4 w-4" />}
          />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {(providers?.providers ?? []).map((provider) => (
                <li key={provider.provider} className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-semibold text-ink">{provider.display_name ?? provider.provider}</span>
                      <Badge tone={statusTone(provider.status)} dot>{provider.status.replace(/_/g, ' ')}</Badge>
                      {provider.is_default ? <Badge tone="brand">default</Badge> : null}
                    </p>
                    <p className="mt-0.5 text-sm text-ink-secondary">{provider.detail}</p>
                    {provider.endpoint ? (
                      <p className="mt-0.5 font-mono text-xs text-ink-tertiary">{provider.endpoint}</p>
                    ) : null}
                    {provider.deployments ? (
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {Object.entries(provider.deployments).map(([capability, deployment]) => (
                          <span key={capability} className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink-secondary">
                            {capability}: {deployment ?? 'not set'}
                          </span>
                        ))}
                      </div>
                    ) : null}
                  </div>
                  <Button
                    size="sm"
                    variant="secondary"
                    loading={testProvider.isPending && testProvider.variables === provider.provider}
                    onClick={() => testProvider.mutate(provider.provider)}
                  >
                    Test connection
                  </Button>
                </li>
              ))}
            </ul>
            {testProvider.data ? (
              <div className="border-t border-line px-5 py-3">
                <p className="text-sm">
                  <Badge tone={statusTone(testProvider.data.status)}>{testProvider.data.status}</Badge>
                  <span className="ml-2 text-ink-secondary">{testProvider.data.detail}</span>
                </p>
              </div>
            ) : null}
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Capability routing"
            description="Agents request a capability; the router resolves the provider, model and deployment."
            icon={<Route className="h-4 w-4" />}
          />
          <CardBody className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-sm">
                <thead>
                  <tr className="border-b border-line bg-surface-muted text-left">
                    {['Capability', 'Provider', 'Model', 'Fallback', 'Max tokens', 'Temperature'].map((header) => (
                      <th key={header} scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(routing ?? []).map((policy) => (
                    <tr key={policy.id} className="data-grid-row">
                      <td className="px-5 py-3">
                        <p className="font-medium text-ink">{policy.capability.replace(/_/g, ' ')}</p>
                        {policy.notes ? <p className="text-xs text-ink-tertiary">{policy.notes}</p> : null}
                      </td>
                      <td className="px-5 py-3 text-ink-secondary">{policy.provider_key}</td>
                      <td className="px-5 py-3 font-mono text-xs text-ink">{policy.model_key}</td>
                      <td className="px-5 py-3 font-mono text-xs text-ink-tertiary">{policy.fallback_model_key ?? '—'}</td>
                      <td className="tabular px-5 py-3 text-ink-secondary">{policy.max_tokens.toLocaleString()}</td>
                      <td className="tabular px-5 py-3 text-ink-secondary">{policy.temperature}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Model catalogue" description="Available models and their pricing" icon={<Zap className="h-4 w-4" />} />
          <CardBody className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] text-sm">
                <thead>
                  <tr className="border-b border-line bg-surface-muted text-left">
                    {['Model', 'Provider', 'Tier', 'Deployment', 'Capabilities', 'Input / 1k', 'Output / 1k'].map((header) => (
                      <th key={header} scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(models ?? []).map((model) => (
                    <tr key={`${model.provider}-${model.model_key}`} className="data-grid-row">
                      <td className="px-5 py-3">
                        <p className="font-medium text-ink">{model.display_name}</p>
                        <code className="font-mono text-2xs text-ink-tertiary">{model.model_key}</code>
                      </td>
                      <td className="px-5 py-3 text-ink-secondary">{model.provider}</td>
                      <td className="px-5 py-3">
                        <Badge tone={model.tier === 'premium' ? 'warning' : model.tier === 'light' ? 'success' : 'neutral'}>
                          {model.tier}
                        </Badge>
                      </td>
                      <td className="px-5 py-3 font-mono text-xs text-ink-tertiary">{model.deployment ?? '—'}</td>
                      <td className="px-5 py-3">
                        <span className="flex flex-wrap gap-1">
                          {model.capabilities.map((capability) => (
                            <span key={capability} className="rounded border border-line bg-surface-muted px-1.5 py-0.5 text-2xs text-ink-secondary">
                              {capability.replace(/_/g, ' ')}
                            </span>
                          ))}
                        </span>
                      </td>
                      <td className="tabular px-5 py-3 text-ink-secondary">€{model.input_cost_per_1k.toFixed(5)}</td>
                      <td className="tabular px-5 py-3 text-ink-secondary">€{model.output_cost_per_1k.toFixed(5)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardBody>
        </Card>

        <div className="grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader title="Vector store" description="Chroma configuration and health" icon={<Database className="h-4 w-4" />} />
            <CardBody>
              <dl className="divide-y divide-line">
                <KeyValue label="Provider">{vector?.provider}</KeyValue>
                <KeyValue label="Status">
                  <Badge tone={statusTone(vector?.status)} dot>{vector?.status}</Badge>
                </KeyValue>
                <KeyValue label="Mode">{vector?.mode}</KeyValue>
                {vector?.persist_directory ? (
                  <KeyValue label="Persist directory">
                    <code className="font-mono text-xs">{vector.persist_directory}</code>
                  </KeyValue>
                ) : null}
                {vector?.host ? <KeyValue label="Host">{vector.host}:{vector.port}</KeyValue> : null}
                <KeyValue label="Total vectors">{formatNumber(vector?.total_vectors)}</KeyValue>
                <KeyValue label="Collections">{vector?.collections.length ?? 0}</KeyValue>
              </dl>
              {vector?.status === 'degraded' ? (
                <div role="alert" className="mt-3 flex gap-2 rounded border border-warning-border bg-warning-bg px-3 py-2">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning-text" />
                  <p className="text-xs text-warning-text">{vector.detail}</p>
                </div>
              ) : null}
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Platform" description="Runtime configuration" icon={<Server className="h-4 w-4" />} />
            <CardBody>
              <dl className="divide-y divide-line">
                <KeyValue label="Version">{systemInfo?.version}</KeyValue>
                <KeyValue label="Environment">{systemInfo?.environment}</KeyValue>
                <KeyValue label="Database">{systemInfo?.database}</KeyValue>
                <KeyValue label="Default LLM provider">{systemInfo?.default_llm_provider}</KeyValue>
                <KeyValue label="Playwright execution">
                  {systemInfo?.playwright_enabled ? (
                    <Badge tone="success">Live browser</Badge>
                  ) : (
                    <Badge tone="info">Simulated</Badge>
                  )}
                </KeyValue>
                <KeyValue label="Demo mode">
                  {systemInfo?.demo_mode ? <Badge tone="info">Enabled</Badge> : <Badge tone="neutral">Disabled</Badge>}
                </KeyValue>
              </dl>

              {systemInfo?.demo_mode ? (
                <div className="mt-4 border-t border-line pt-4">
                  <p className="text-sm font-medium text-ink">Reset demo data</p>
                  <p className="mt-0.5 text-xs text-ink-secondary">
                    Rebuilds every project, execution history and vector index from the deterministic seed.
                    Anything created during this session is discarded.
                  </p>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="mt-3"
                    icon={<RefreshCw className="h-3.5 w-3.5" />}
                    loading={resetDemo.isPending}
                    onClick={() => resetDemo.mutate()}
                  >
                    Reset demo data
                  </Button>
                  {resetMessage ? (
                    <p role="status" className="mt-2 text-xs text-info-text">{resetMessage}</p>
                  ) : null}
                </div>
              ) : null}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
