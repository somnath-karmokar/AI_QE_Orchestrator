/** Executive dashboard (spec §16). Every value is computed server-side from real state. */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  ResponsiveContainer, Tooltip as RechartsTooltip, XAxis, YAxis,
} from 'recharts';
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, Bot, ClipboardCheck, BadgeEuro,
  Gauge, Minus, Network, ShieldCheck, Sparkles, Timer, TrendingUp, Zap,
} from 'lucide-react';
import { useDashboard, formatCurrency, formatDuration, formatNumber, formatPercent } from '@/hooks';
import { useWorkspace } from '@/store';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, ErrorState,
  LoadingBlock, PageHeader, ProgressBar, Select, Tooltip,
} from '@/design-system/primitives';

const AXIS = { stroke: '#8B95A3', fontSize: 11 };
const GRID = '#E8EEF4';

export default function DashboardPage() {
  const [windowDays, setWindowDays] = useState(30);
  const project = useWorkspace((state) => state.project);
  const { data, isLoading, error, refetch } = useDashboard(windowDays);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <LoadingBlock rows={2} className="rounded-lg border border-line bg-surface" />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          {Array.from({ length: 5 }).map((_, index) => (
            <Card key={index}>
              <LoadingBlock rows={2} />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return <ErrorState message={(error as Error).message} onRetry={() => void refetch()} />;
  }
  if (!data) {
    return <EmptyState title="No project selected" description="Choose a project to see its quality picture." />;
  }

  const { kpis, charts, totals, deltas } = data;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Quality Overview"
        description={project ? `${project.name} · ${project.business_domain ?? 'Enterprise application'}` : undefined}
        actions={
          <>
            <Select
              aria-label="Reporting window"
              className="w-36"
              value={windowDays}
              onChange={(event) => setWindowDays(Number(event.target.value))}
            >
              <option value={7}>Last 7 days</option>
              <option value={30}>Last 30 days</option>
              <option value={90}>Last 90 days</option>
            </Select>
            <Link
              to="/flows"
              className="inline-flex h-9 items-center gap-2 rounded border border-navy-700 bg-navy-700 px-3.5
                         text-sm font-medium text-ink-inverse transition-colors hover:bg-navy-800"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Run a flow
            </Link>
          </>
        }
      />

      {/* Quality Intelligence Summary — narrative generated from the metrics. */}
      {data.summary ? (
        <Card className="border-brand-100 bg-brand-50/50">
          <CardBody className="flex gap-3.5 py-4">
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded bg-brand-500">
              <Sparkles className="h-3.5 w-3.5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-brand-800">Quality Intelligence Summary</h2>
              <p className="mt-1 text-sm leading-relaxed text-ink">{data.summary}</p>
            </div>
          </CardBody>
        </Card>
      ) : null}

      {/* KPI row */}
      <section aria-label="Key performance indicators" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <Kpi
          icon={<Bot className="h-4 w-4" />}
          label="Automation Coverage"
          value={formatPercent(kpis.automation_coverage)}
          detail={`${totals.automated_test_cases} of ${totals.test_cases} cases automated`}
          progress={kpis.automation_coverage}
        />
        <Kpi
          icon={<ClipboardCheck className="h-4 w-4" />}
          label="Requirement Coverage"
          value={formatPercent(kpis.requirement_coverage)}
          detail={`${totals.covered_requirements} of ${totals.requirements} requirements`}
          progress={kpis.requirement_coverage}
        />
        <Kpi
          icon={<Gauge className="h-4 w-4" />}
          label="Test Pass Rate"
          value={formatPercent(kpis.test_pass_rate)}
          detail={`${formatNumber(totals.tests_executed)} tests executed`}
          delta={deltas.test_pass_rate_pp}
          progress={kpis.test_pass_rate}
        />
        <Kpi
          icon={<Zap className="h-4 w-4" />}
          label="Flaky Test Rate"
          value={formatPercent(kpis.flaky_test_rate, 2)}
          detail={kpis.flaky_test_rate > 0.02 ? 'Above the 2% threshold' : 'Within threshold'}
          tone={kpis.flaky_test_rate > 0.02 ? 'warning' : 'success'}
        />
        <Kpi
          icon={<TrendingUp className="h-4 w-4" />}
          label="Regression Optimisation"
          value={formatPercent(kpis.regression_optimization, 0)}
          detail="Suite duration reduction"
          tone="success"
        />
      </section>

      <section aria-label="Secondary indicators" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <Kpi
          icon={<Timer className="h-4 w-4" />}
          label="Mean Time to Diagnose"
          value={kpis.mean_time_to_diagnose_hours ? `${kpis.mean_time_to_diagnose_hours.toFixed(1)}h` : '—'}
          detail="Defect raised to root cause"
        />
        <Kpi
          icon={<Sparkles className="h-4 w-4" />}
          label="AI Automation Rate"
          value={formatPercent(kpis.ai_automation_rate, 0)}
          detail="Artifacts generated by agents"
        />
        <Kpi
          icon={<BadgeEuro className="h-4 w-4" />}
          label="AI Cost"
          value={formatCurrency(kpis.ai_cost_usd)}
          detail={`over ${data.window_days} days`}
        />
        <Kpi
          icon={<ShieldCheck className="h-4 w-4" />}
          label="Human Approval Rate"
          value={formatPercent(kpis.human_approval_rate, 0)}
          detail={`${totals.pending_approvals} awaiting decision`}
          tone={totals.pending_approvals > 0 ? 'warning' : undefined}
        />
        <Kpi
          icon={<Network className="h-4 w-4" />}
          label="Defect Prediction Accuracy"
          value={kpis.defect_prediction_accuracy === null ? 'Not yet measurable' : formatPercent(kpis.defect_prediction_accuracy, 0)}
          detail={
            kpis.defect_prediction_accuracy === null
              ? 'Awaiting observed outcomes'
              : 'Against observed outcomes'
          }
          muted={kpis.defect_prediction_accuracy === null}
        />
      </section>

      {/* Trends */}
      <div className="grid gap-5 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader
            title="Execution trend"
            description="Pass rate and outcome mix across recent suite runs"
            actions={
              <Link to="/executions" className="text-sm font-medium text-brand-600 hover:text-brand-700">
                All executions <ArrowRight className="inline h-3 w-3" />
              </Link>
            }
          />
          <CardBody className="pt-2">
            {charts.execution_trend.length ? (
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={charts.execution_trend} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="passRate" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#145DA0" stopOpacity={0.22} />
                      <stop offset="100%" stopColor="#145DA0" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke={GRID} vertical={false} />
                  <XAxis dataKey="date" tick={AXIS} tickLine={false} axisLine={{ stroke: GRID }} minTickGap={28} />
                  <YAxis tick={AXIS} tickLine={false} axisLine={false} domain={[0, 100]} unit="%" />
                  <RechartsTooltip content={<ChartTooltip suffix="%" />} />
                  <Area
                    type="monotone"
                    dataKey="pass_rate"
                    name="Pass rate"
                    stroke="#145DA0"
                    strokeWidth={2}
                    fill="url(#passRate)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <EmptyState title="No executions yet" description="Run a suite to start building trend data." />
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Failure categories" description="What is actually breaking" />
          <CardBody className="pt-2">
            {charts.failure_categories.length ? (
              <div className="space-y-3.5">
                {charts.failure_categories.map((entry) => (
                  <div key={entry.category}>
                    <div className="mb-1.5 flex items-baseline justify-between gap-2">
                      <span className="text-sm text-ink">{entry.label}</span>
                      <span className="tabular text-sm font-medium text-ink-secondary">
                        {entry.count}
                        <span className="ml-1.5 text-xs text-ink-tertiary">{formatPercent(entry.share, 0)}</span>
                      </span>
                    </div>
                    <ProgressBar
                      value={entry.share}
                      tone={entry.category === 'application_defect' ? 'danger' : entry.category === 'environment' ? 'warning' : 'brand'}
                      label={`${entry.label}: ${entry.count} failures`}
                    />
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState title="No failures recorded" description="Nothing has failed in this window." />
            )}
          </CardBody>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <Card>
          <CardHeader title="Defect trend" description="Opened against resolved" />
          <CardBody className="pt-2">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={charts.defect_trend} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                <CartesianGrid stroke={GRID} vertical={false} />
                <XAxis dataKey="date" tick={AXIS} tickLine={false} axisLine={{ stroke: GRID }} minTickGap={34} />
                <YAxis tick={AXIS} tickLine={false} axisLine={false} allowDecimals={false} />
                <RechartsTooltip content={<ChartTooltip />} />
                <Legend wrapperStyle={{ fontSize: 11, paddingTop: 8 }} iconType="plainline" />
                <Line type="monotone" dataKey="open" name="Open" stroke="#C53030" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="opened" name="Raised" stroke="#B7791F" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="resolved" name="Resolved" stroke="#238636" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Quality risk by module"
            description="Predicted defect likelihood"
            actions={
              <Link to="/quality/defects" className="text-sm font-medium text-brand-600 hover:text-brand-700">
                Details
              </Link>
            }
          />
          <CardBody className="pt-2">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart
                data={charts.quality_risk}
                layout="vertical"
                margin={{ top: 4, right: 16, left: 8, bottom: 0 }}
              >
                <CartesianGrid stroke={GRID} horizontal={false} />
                <XAxis type="number" domain={[0, 1]} tick={AXIS} tickLine={false} axisLine={false} tickFormatter={(v) => `${Math.round(v * 100)}%`} />
                <YAxis type="category" dataKey="module" width={104} tick={AXIS} tickLine={false} axisLine={false} />
                <RechartsTooltip content={<ChartTooltip percent />} />
                <Bar dataKey="probability" name="Risk" radius={[0, 3, 3, 0]} barSize={14}>
                  {charts.quality_risk.map((entry) => (
                    <Cell
                      key={entry.module}
                      fill={entry.risk_band === 'high' ? '#C53030' : entry.risk_band === 'medium' ? '#B7791F' : '#238636'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Agent utilisation"
            description="Invocations and spend by agent"
            actions={
              <Link to="/governance?tab=cost" className="text-sm font-medium text-brand-600 hover:text-brand-700">
                Cost
              </Link>
            }
          />
          <CardBody className="max-h-[220px] overflow-y-auto pt-2">
            {charts.agent_utilization.length ? (
              <ul className="space-y-2.5">
                {charts.agent_utilization.slice(0, 7).map((entry) => (
                  <li key={entry.agent_key} className="flex items-center justify-between gap-3">
                    <span className="min-w-0">
                      <span className="block truncate text-sm text-ink">{entry.agent_name}</span>
                      <span className="block text-xs text-ink-tertiary">
                        {entry.invocations} calls · {formatDuration(entry.avg_latency_ms)} avg
                      </span>
                    </span>
                    <span className="tabular shrink-0 text-sm font-medium text-ink-secondary">
                      {formatCurrency(entry.cost_usd, 3)}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="No agent activity" description="Run a flow to populate this." />
            )}
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Coverage by module"
          description="Requirement coverage and automation depth per functional area"
          actions={
            <Link to="/quality/traceability" className="text-sm font-medium text-brand-600 hover:text-brand-700">
              Traceability matrix <ArrowRight className="inline h-3 w-3" />
            </Link>
          }
        />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-line bg-surface-muted text-left">
                <th scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Module</th>
                <th scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Requirements</th>
                <th scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Test cases</th>
                <th scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Defects</th>
                <th scope="col" className="w-48 px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Coverage</th>
                <th scope="col" className="w-48 px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Automation</th>
              </tr>
            </thead>
            <tbody>
              {charts.coverage_by_module.map((row) => (
                <tr key={row.module} className="data-grid-row">
                  <td className="px-5 py-3 font-medium text-ink">{row.module}</td>
                  <td className="tabular px-5 py-3 text-ink-secondary">{row.requirements}</td>
                  <td className="tabular px-5 py-3 text-ink-secondary">{row.test_cases}</td>
                  <td className="px-5 py-3">
                    {row.defects > 0 ? (
                      <Badge tone={row.defects > 4 ? 'danger' : 'warning'}>{row.defects}</Badge>
                    ) : (
                      <span className="text-ink-tertiary">0</span>
                    )}
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <ProgressBar value={row.coverage} className="flex-1" label={`${row.module} coverage`} />
                      <span className="tabular w-11 shrink-0 text-right text-xs text-ink-secondary">
                        {formatPercent(row.coverage, 0)}
                      </span>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <ProgressBar
                        value={row.automation}
                        tone={row.automation < 0.5 ? 'warning' : 'success'}
                        className="flex-1"
                        label={`${row.module} automation`}
                      />
                      <span className="tabular w-11 shrink-0 text-right text-xs text-ink-secondary">
                        {formatPercent(row.automation, 0)}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function Kpi({
  icon,
  label,
  value,
  detail,
  delta,
  progress,
  tone,
  muted,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  detail?: string;
  delta?: number;
  progress?: number;
  tone?: 'success' | 'warning' | 'danger';
  muted?: boolean;
}) {
  const DeltaIcon = delta === undefined ? null : delta > 0 ? ArrowUpRight : delta < 0 ? ArrowDownRight : Minus;
  return (
    <Card>
      <CardBody className="p-4">
        <div className="flex items-start justify-between gap-2">
          <span className="flex items-center gap-2 text-xs font-medium text-ink-secondary">
            <span className="text-ink-tertiary">{icon}</span>
            {label}
          </span>
          {delta !== undefined && DeltaIcon ? (
            <Tooltip label="Change versus the start of the window">
              <span
                className={cn(
                  'flex items-center gap-0.5 text-xs font-medium',
                  delta > 0 ? 'text-success-text' : delta < 0 ? 'text-danger-text' : 'text-ink-tertiary',
                )}
              >
                <DeltaIcon className="h-3 w-3" />
                {Math.abs(delta).toFixed(1)}pp
              </span>
            </Tooltip>
          ) : null}
        </div>
        <p
          className={cn(
            'tabular mt-2 text-2xl font-semibold',
            muted ? 'text-ink-tertiary' : tone === 'warning' ? 'text-warning-text' : tone === 'danger' ? 'text-danger-text' : tone === 'success' ? 'text-success-text' : 'text-ink',
            muted && 'text-base font-medium',
          )}
        >
          {value}
        </p>
        {progress !== undefined ? <ProgressBar value={progress} className="mt-2.5" label={label} /> : null}
        {detail ? <p className="mt-1.5 text-xs text-ink-tertiary">{detail}</p> : null}
      </CardBody>
    </Card>
  );
}

function ChartTooltip({
  active,
  payload,
  label,
  suffix,
  percent,
}: {
  active?: boolean;
  payload?: { name: string; value: number; color: string }[];
  label?: string;
  suffix?: string;
  percent?: boolean;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded border border-line bg-surface px-3 py-2 shadow-popover">
      {label ? <p className="mb-1 text-xs font-medium text-ink">{label}</p> : null}
      {payload.map((entry) => (
        <p key={entry.name} className="flex items-center gap-2 text-xs text-ink-secondary">
          <span className="h-2 w-2 rounded-full" style={{ background: entry.color }} aria-hidden />
          {entry.name}:{' '}
          <span className="tabular font-medium text-ink">
            {percent ? `${Math.round(entry.value * 100)}%` : `${entry.value}${suffix ?? ''}`}
          </span>
        </p>
      ))}
    </div>
  );
}
