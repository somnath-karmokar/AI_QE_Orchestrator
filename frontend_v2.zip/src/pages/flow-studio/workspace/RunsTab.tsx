/** Every run of this flow, filterable by outcome. */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Activity } from 'lucide-react';
import { api } from '@/services/api';
import { formatCurrency, formatDateTime, formatDuration, formatNumber, formatRelativeTime } from '@/hooks';
import { Column, DataTable } from '@/components/DataTable';
import { Badge, Card, humanize, Select, statusTone } from '@/design-system/primitives';
import { TRIGGER_LABELS, personName } from '@/features/flow-studio/format';
import type { RunSummary } from '@/types';

const STATUSES = ['', 'running', 'queued', 'awaiting_approval', 'succeeded', 'failed', 'cancelled'];

export default function RunsTab({ flowId }: { flowId: string }) {
  const navigate = useNavigate();
  const [status, setStatus] = useState('');
  const { data, isLoading } = useQuery({
    queryKey: ['flow-runs', flowId, status],
    queryFn: () => api.flowRuns(flowId, { status: status || undefined, limit: 200 }),
    refetchInterval: 10000,
  });

  const columns: Column<RunSummary>[] = [
    {
      key: 'run',
      header: 'Run',
      render: (run) => (
        <div className="min-w-0">
          <Link to={`/runs/${run.id}`} onClick={(event) => event.stopPropagation()} className="font-medium text-ink hover:text-brand-600">
            #{run.run_number}
          </Link>
          {run.summary ? <p className="mt-0.5 line-clamp-1 max-w-md text-xs text-ink-secondary">{run.summary}</p> : null}
        </div>
      ),
    },
    { key: 'status', header: 'Status', render: (run) => <Badge tone={statusTone(run.status)} dot>{humanize(run.status)}</Badge> },
    {
      key: 'trigger',
      header: 'Trigger',
      render: (run) => (
        <div>
          <p className="text-ink">{TRIGGER_LABELS[run.trigger] ?? humanize(run.trigger)}</p>
          <p className="text-2xs text-ink-tertiary">{personName(run.triggered_by)}</p>
        </div>
      ),
    },
    {
      key: 'started',
      header: 'Started',
      render: (run) => (
        <span className="text-ink-secondary" title={formatDateTime(run.started_at ?? run.created_at)}>
          {formatRelativeTime(run.started_at ?? run.created_at)}
        </span>
      ),
    },
    { key: 'steps', header: 'Steps', numeric: true, render: (run) => <span className="text-ink-secondary">{run.completed_step_count}/{run.step_count || '—'}</span> },
    { key: 'duration', header: 'Duration', numeric: true, render: (run) => <span className="text-ink-secondary">{formatDuration(run.duration_ms)}</span> },
    { key: 'tokens', header: 'Tokens', numeric: true, render: (run) => <span className="text-ink-secondary">{formatNumber(run.total_tokens)}</span> },
    { key: 'cost', header: 'Cost', numeric: true, render: (run) => <span className="text-ink-secondary">{formatCurrency(run.total_cost_usd, 3)}</span> },
  ];

  return (
    <Card>
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-3">
        <p className="text-sm text-ink-secondary">{data ? `${data.total} run${data.total === 1 ? '' : 's'}` : 'Loading runs'}</p>
        <Select aria-label="Filter by status" className="w-52" value={status} onChange={(event) => setStatus(event.target.value)}>
          {STATUSES.map((value) => (
            <option key={value} value={value}>
              {value ? humanize(value) : 'All outcomes'}
            </option>
          ))}
        </Select>
      </div>
      <DataTable
        columns={columns}
        rows={data?.items ?? []}
        keyOf={(run) => run.id}
        loading={isLoading}
        onRowClick={(run) => navigate(`/runs/${run.id}`)}
        caption="Runs of this flow"
        emptyIcon={<Activity className="h-5 w-5" />}
        emptyTitle="No runs match"
        emptyDescription="Run the flow, or choose another outcome."
        minWidth={900}
      />
    </Card>
  );
}
