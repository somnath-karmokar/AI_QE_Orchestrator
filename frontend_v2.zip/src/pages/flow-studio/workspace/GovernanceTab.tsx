/** Is this flow under control? Posture checks, controls per step, approvals, budget, policies, versions and audit. */
import { useQuery } from '@tanstack/react-query';
import { BadgeEuro, GitCommitVertical, Lock, ScrollText, ShieldCheck, UserCheck } from 'lucide-react';
import { api } from '@/services/api';
import { formatCurrency, formatDateTime, formatRelativeTime } from '@/hooks';
import {
  Badge,
  Card,
  CardBody,
  CardHeader,
  EmptyState,
  ErrorState,
  humanize,
  LoadingBlock,
  ProgressBar,
  statusTone,
  TONE_BY_RISK,
} from '@/design-system/primitives';
import { MiniTable } from '@/features/flow-studio/charts';
import { ScoreRing, StepIcon } from '@/features/flow-studio/components';
import { ROLE_LABELS, personName } from '@/features/flow-studio/format';
import { PostureList } from './shared';

export default function GovernanceTab({ flowId }: { flowId: string }) {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['flow-governance', flowId],
    queryFn: () => api.flowGovernance(flowId, 90),
  });

  if (isLoading) return <LoadingBlock rows={8} className="rounded-lg border border-line bg-surface" />;
  if (error || !data) return <ErrorState message={(error as Error)?.message} onRetry={() => void refetch()} />;

  const { posture, settings, budget, approvals } = data;
  const failing = posture.checks.filter((check) => check.status === 'fail').length;
  const ringTone = failing ? 'danger' : posture.passed < posture.total ? 'warning' : 'brand';
  const avgUse = budget.per_run_budget_usd ? budget.avg_run_cost_usd / budget.per_run_budget_usd : 0;

  return (
    <div className="space-y-5">
      <div className="grid gap-5 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader icon={<ShieldCheck className="h-4 w-4" />} title="Governance posture" description="Checks run against this flow's current version and its last 90 days." />
          <CardBody className="grid gap-6 sm:grid-cols-[auto_1fr]">
            <div className="flex flex-col items-center gap-2">
              <ScoreRing score={posture.score} size={96} label={`${posture.passed} of ${posture.total} checks passed`} tone={ringTone} />
              <p className="text-sm font-medium text-ink">
                {posture.passed} of {posture.total} passed
              </p>
              <p className="text-2xs text-ink-tertiary">{failing ? `${failing} to fix` : 'No blocking issues'}</p>
            </div>
            <PostureList checks={posture.checks} />
          </CardBody>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader icon={<BadgeEuro className="h-4 w-4" />} title="Budget" />
            <CardBody className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-ink-secondary">Per-run ceiling</span>
                <span className="font-semibold text-ink tabular">{formatCurrency(budget.per_run_budget_usd)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-secondary">Alert at {settings.budget_alert_percent}%</span>
                <span className="text-ink tabular">{formatCurrency(budget.alert_threshold_usd)}</span>
              </div>
              <div>
                <div className="mb-1 flex justify-between text-xs text-ink-secondary">
                  <span>Average run uses</span>
                  <span className="tabular">
                    {formatCurrency(budget.avg_run_cost_usd, 3)} · max {formatCurrency(budget.max_run_cost_usd, 3)}
                  </span>
                </div>
                <ProgressBar value={avgUse} tone={avgUse > settings.budget_alert_percent / 100 ? 'warning' : 'brand'} label="Average budget use" />
              </div>
              <p className="text-xs text-ink-secondary">
                {budget.runs_over_alert
                  ? `${budget.runs_over_alert} run(s) crossed the alert threshold.`
                  : 'No run has crossed the alert threshold.'}
              </p>
            </CardBody>
          </Card>
          <Card>
            <CardHeader icon={<Lock className="h-4 w-4" />} title="Access" />
            <CardBody className="space-y-2 text-sm">
              <div className="flex justify-between gap-3">
                <span className="text-ink-secondary">Owner</span>
                <span className="text-right text-ink">{personName(settings.owner)}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-ink-secondary">Can run</span>
                <span className="text-right text-ink">
                  {settings.run_roles.length ? settings.run_roles.map((role) => ROLE_LABELS[role] ?? role).join(', ') : 'Anyone with run permission'}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-ink-secondary">Failure alerts</span>
                <span className="text-ink">{settings.notify_on_failure ? 'On' : 'Off'}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-ink-secondary">API trigger</span>
                <span className="text-ink">{data.flow.api_trigger_enabled ? 'Enabled (token hashed)' : 'Off'}</span>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader title="Controls on each step" description="Risk, human gates, pinned versions and limits, as they will apply to the next run." />
        <div className="p-4">
          <MiniTable
            caption="Controls per step"
            maxHeight={480}
            rows={data.controls}
            columns={[
              {
                header: 'Step',
                render: (row) => (
                  <span className="flex items-center gap-2 font-medium">
                    <StepIcon type={row.node_type} className="text-ink-tertiary" />
                    {row.label}
                  </span>
                ),
              },
              { header: 'Risk', render: (row) => (row.risk_level ? <Badge tone={TONE_BY_RISK[row.risk_level] ?? 'neutral'}>{row.risk_level}</Badge> : '—') },
              {
                header: 'Human gate',
                render: (row) =>
                  row.human_gate ? (
                    <Badge tone="warning">
                      <UserCheck className="h-3 w-3" aria-hidden /> {ROLE_LABELS[row.approval_role ?? 'qe_lead'] ?? row.approval_role}
                    </Badge>
                  ) : (
                    <span className="text-ink-tertiary">None</span>
                  ),
              },
              {
                header: 'Agent version',
                render: (row) =>
                  row.node_type === 'agent' ? (
                    <span>
                      {row.agent_version ?? '—'}{' '}
                      <span className="text-ink-tertiary">{row.version_pinned ? '(pinned)' : '(follows latest)'}</span>
                    </span>
                  ) : (
                    '—'
                  ),
              },
              { header: 'Retries', render: (row) => row.retry ?? '—', numeric: true },
              { header: 'Cost limit', render: (row) => (row.cost_limit_usd ? formatCurrency(row.cost_limit_usd) : '—'), numeric: true },
            ]}
          />
        </div>
      </Card>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader icon={<UserCheck className="h-4 w-4" />} title="Human approvals" description="Decisions taken at this flow's gates in the last 90 days." />
          <CardBody>
            <dl className="mb-4 grid grid-cols-3 gap-3">
              <div className="rounded-lg border border-line bg-surface-muted p-3">
                <dt className="text-2xs text-ink-tertiary">Decisions</dt>
                <dd className="text-xl font-semibold text-ink tabular">{approvals.total}</dd>
              </div>
              <div className="rounded-lg border border-line bg-surface-muted p-3">
                <dt className="text-2xs text-ink-tertiary">Approved / rejected</dt>
                <dd className="text-xl font-semibold text-ink tabular">
                  {approvals.by_status.approved ?? 0} / {approvals.by_status.rejected ?? 0}
                </dd>
              </div>
              <div className="rounded-lg border border-line bg-surface-muted p-3">
                <dt className="text-2xs text-ink-tertiary">Median decision</dt>
                <dd className="text-xl font-semibold text-ink tabular">
                  {approvals.median_decision_hours === null ? '—' : approvals.median_decision_hours < 1 ? `${Math.round(approvals.median_decision_hours * 60)} min` : `${approvals.median_decision_hours} h`}
                </dd>
              </div>
            </dl>
            {approvals.recent.length ? (
              <ul className="divide-y divide-line-subtle">
                {approvals.recent.slice(0, 6).map((approval) => (
                  <li key={approval.id} className="flex items-start justify-between gap-3 py-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-ink">{approval.title}</p>
                      <p className="text-xs text-ink-tertiary">
                        {approval.decided_by ? `${personName(approval.decided_by)} · ` : ''}
                        {formatRelativeTime(approval.decided_at ?? approval.created_at)}
                      </p>
                    </div>
                    <Badge tone={statusTone(approval.status)}>{humanize(approval.status)}</Badge>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="No approvals yet" className="py-6" />
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader icon={<ShieldCheck className="h-4 w-4" />} title="Policies in force" description="Project and platform policies every run of this flow is checked against." />
          <CardBody>
            <ul className="divide-y divide-line-subtle">
              {data.policies.map((policy) => (
                <li key={policy.key} className="flex items-center justify-between gap-3 py-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-ink">{policy.name}</p>
                    <p className="text-xs text-ink-tertiary">
                      {humanize(policy.policy_type)} · enforced {policy.enforcement_count}×
                    </p>
                  </div>
                  <Badge tone={policy.effect === 'deny' ? 'danger' : policy.effect === 'require_approval' ? 'warning' : 'neutral'}>
                    {humanize(policy.effect)}
                  </Badge>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_2fr]">
        <Card>
          <CardHeader icon={<GitCommitVertical className="h-4 w-4" />} title="Version history" />
          <CardBody>
            <ol className="relative space-y-4 border-l border-line pl-4">
              {data.versions.map((version) => (
                <li key={version.version} className="relative">
                  <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-surface bg-brand-500" aria-hidden />
                  <p className="flex items-center gap-2 text-sm font-medium text-ink">
                    v{version.version}
                    {version.published_at ? <Badge tone="success">Published</Badge> : <Badge tone="warning">Draft</Badge>}
                  </p>
                  <p className="text-xs text-ink-secondary">{version.change_summary}</p>
                  <p className="text-2xs text-ink-tertiary">
                    {formatDateTime(version.published_at ?? version.created_at)}
                    {version.created_by ? ` · ${personName(version.created_by)}` : ''}
                  </p>
                </li>
              ))}
            </ol>
          </CardBody>
        </Card>

        <Card>
          <CardHeader icon={<ScrollText className="h-4 w-4" />} title="Audit trail" description="Who changed, ran or approved what. Append-only." />
          <div className="p-4">
            <MiniTable
              caption="Audit trail"
              maxHeight={420}
              rows={data.audit}
              columns={[
                { header: 'When', render: (entry) => <span title={formatDateTime(entry.created_at)}>{formatRelativeTime(entry.created_at)}</span> },
                { header: 'Actor', render: (entry) => personName(entry.actor) },
                { header: 'Action', render: (entry) => <code className="font-mono text-2xs">{entry.action}</code> },
                {
                  header: 'Outcome',
                  render: (entry) => (
                    <Badge tone={entry.outcome === 'success' ? 'success' : entry.outcome === 'warning' ? 'warning' : 'danger'}>
                      {entry.outcome}
                    </Badge>
                  ),
                },
                { header: 'Detail', render: (entry) => <span className="line-clamp-1 max-w-[320px] text-ink-secondary">{entry.reason}</span> },
              ]}
            />
          </div>
        </Card>
      </div>
    </div>
  );
}
