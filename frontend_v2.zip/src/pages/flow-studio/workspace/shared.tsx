/** Small pieces shared by the flow workspace tabs. */
import { CheckCircle2, CircleAlert, CircleX, KeyRound } from 'lucide-react';
import { cn, CopyButton, Select } from '@/design-system/primitives';
import type { FlowApiToken, PostureCheck } from '@/types';

export function WindowSelect({
  value,
  onChange,
  options = [7, 30, 90],
}: {
  value: number;
  onChange: (value: number) => void;
  options?: number[];
}) {
  return (
    <Select aria-label="Time window" className="w-36" value={value} onChange={(event) => onChange(Number(event.target.value))}>
      {options.map((days) => (
        <option key={days} value={days}>
          Last {days} days
        </option>
      ))}
    </Select>
  );
}

/** Shows a freshly issued API token once, with a ready-to-paste example. */
export function ApiTokenReveal({ token }: { token: FlowApiToken }) {
  return (
    <div className="rounded-lg border border-info-border bg-info-bg p-4">
      <p className="flex items-center gap-2 text-sm font-semibold text-info-text">
        <KeyRound className="h-4 w-4" aria-hidden /> Copy this token now. It will not be shown again.
      </p>
      <div className="mt-3 space-y-2">
        <div className="flex items-center gap-2">
          <code className="min-w-0 flex-1 truncate rounded border border-line bg-surface px-2.5 py-1.5 font-mono text-xs text-ink">
            {token.token}
          </code>
          <CopyButton text={token.token} label="Copy token" />
        </div>
        <div className="flex items-start gap-2">
          <code className="min-w-0 flex-1 whitespace-pre-wrap break-all rounded border border-line bg-navy-800 px-2.5 py-2 font-mono text-2xs leading-5 text-navy-50">
            {token.example}
          </code>
          <CopyButton text={token.example} label="Copy example request" />
        </div>
      </div>
    </div>
  );
}

const CHECK_ICON = { pass: CheckCircle2, warn: CircleAlert, fail: CircleX };
const CHECK_STYLE = { pass: 'text-success', warn: 'text-warning', fail: 'text-danger' };
const CHECK_LABEL = { pass: 'Passed', warn: 'Warning', fail: 'Failed' };

export function PostureList({ checks, className }: { checks: PostureCheck[]; className?: string }) {
  return (
    <ul className={cn('divide-y divide-line-subtle', className)}>
      {checks.map((check) => {
        const Icon = CHECK_ICON[check.status];
        return (
          <li key={check.key} className="flex items-start gap-2.5 py-2.5">
            <Icon className={cn('mt-0.5 h-4 w-4 shrink-0', CHECK_STYLE[check.status])} aria-label={CHECK_LABEL[check.status]} />
            <div className="min-w-0">
              <p className="text-sm font-medium text-ink">{check.title}</p>
              <p className="text-xs text-ink-secondary">{check.detail}</p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
