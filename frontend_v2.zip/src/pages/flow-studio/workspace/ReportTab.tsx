/** A shareable flow report: read it here, print it to PDF, or download it as Markdown. */
import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Download, Printer } from 'lucide-react';
import { api } from '@/services/api';
import { formatCurrency, formatDateTime, formatDuration, formatPercent } from '@/hooks';
import { Badge, Button, cn, ErrorState, humanize, LoadingBlock } from '@/design-system/primitives';
import { OUTCOME_LEGEND, OutcomeColumns } from '@/features/flow-studio/charts';
import { formatPoints, personName } from '@/features/flow-studio/format';
import { PostureList, WindowSelect } from './shared';

const PRIORITY_TONE = { high: 'danger', medium: 'warning', low: 'neutral' } as const;

export default function ReportTab({ flowId }: { flowId: string }) {
  const [windowDays, setWindowDays] = useState(30);
  const { data: report, isLoading, error, refetch } = useQuery({
    queryKey: ['flow-report', flowId, windowDays],
    queryFn: () => api.flowReport(flowId, windowDays),
  });

  const download = useMutation({
    mutationFn: () => api.flowReportMarkdown(flowId, windowDays),
    onSuccess: ({ filename, text }) => {
      const url = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    },
  });

  if (isLoading) return <LoadingBlock rows={10} className="rounded-lg border border-line bg-surface" />;
  if (error || !report) return <ErrorState message={(error as Error)?.message} onRetry={() => void refetch()} />;

  const { kpis } = report;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <p className="text-sm text-ink-secondary">Share with stakeholders, attach to a release pack or file with an audit.</p>
        <div className="flex flex-wrap items-center gap-2">
          <WindowSelect value={windowDays} onChange={setWindowDays} />
          <Button icon={<Download className="h-3.5 w-3.5" />} loading={download.isPending} onClick={() => download.mutate()}>
            Download Markdown
          </Button>
          <Button variant="primary" icon={<Printer className="h-3.5 w-3.5" />} onClick={() => window.print()}>
            Print or save as PDF
          </Button>
        </div>
      </div>

      <article
        className="mx-auto max-w-5xl rounded-xl border border-line bg-surface px-8 py-8 shadow-card print:max-w-none print:border-0 print:px-0 print:py-0 print:shadow-none"
        aria-label="Flow report"
      >
        <header className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-brand-600">Flow report</p>
            <h2 className="mt-1 text-4xl font-semibold tracking-[-0.02em] text-ink">{report.flow.name}</h2>
            <p className="mt-1 text-sm text-ink-secondary">
              {report.project} · {report.period.from} to {report.period.to} ({report.period.days} days)
            </p>
          </div>
          <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs">
            <dt className="text-ink-tertiary">Owner</dt>
            <dd className="text-ink">{personName(report.flow.owner)}</dd>
            <dt className="text-ink-tertiary">Version</dt>
            <dd className="text-ink">
              v{report.flow.version} ({humanize(report.flow.status)})
            </dd>
            <dt className="text-ink-tertiary">Triggers</dt>
            <dd className="text-ink">
              Manual{report.flow.schedule.enabled ? ` · ${report.flow.schedule_description}` : ''}
              {report.flow.api_trigger_enabled ? ' · API' : ''}
            </dd>
            <dt className="text-ink-tertiary">Generated</dt>
            <dd className="text-ink">{formatDateTime(report.generated_at)}</dd>
          </dl>
        </header>

        <section className="mt-6" aria-labelledby="report-highlights">
          <h3 id="report-highlights" className="text-lg font-semibold text-ink">
            Highlights
          </h3>
          <ul className="mt-2 space-y-1.5">
            {report.highlights.map((line) => (
              <li key={line} className="flex gap-2 text-md text-ink">
                <span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" aria-hidden />
                {line}
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4" aria-label="Key figures">
          <ReportFigure label="Runs" value={String(kpis.runs)} note={`${report.deltas.runs >= 0 ? '+' : '−'}${Math.abs(report.deltas.runs)} vs previous`} />
          <ReportFigure label="Success rate" value={formatPercent(kpis.success_rate, 0)} note={`${formatPoints(report.deltas.success_rate)} vs previous`} />
          <ReportFigure label="Typical duration" value={formatDuration(kpis.p50_duration_ms)} note={`p95 ${formatDuration(kpis.p95_duration_ms)}`} />
          <ReportFigure label="Cost per run" value={formatCurrency(kpis.avg_cost_usd)} note={`${formatCurrency(kpis.total_cost_usd)} total`} />
          <ReportFigure label="Agent steps" value={String(kpis.automated_steps)} note="completed" />
          <ReportFigure label="Effort saved" value={`${kpis.hours_saved} h`} note="estimated" />
          <ReportFigure
            label="Reliability SLO"
            value={report.slo.status === 'healthy' ? 'Met' : report.slo.status === 'at_risk' ? 'At risk' : '—'}
            note={`target ${formatPercent(report.slo.target_success_rate, 0)}`}
          />
          <ReportFigure label="Governance" value={`${report.posture.passed}/${report.posture.total}`} note="checks passed" />
        </section>

        <section className="mt-7 break-inside-avoid" aria-labelledby="report-outcomes">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h3 id="report-outcomes" className="text-lg font-semibold text-ink">
              Run outcomes
            </h3>
            <ul className="flex flex-wrap gap-4" aria-label="Legend">
              {OUTCOME_LEGEND.map((item) => (
                <li key={item.label} className="flex items-center gap-1.5 text-xs text-ink-secondary">
                  <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: item.color }} aria-hidden />
                  {item.label}
                </li>
              ))}
            </ul>
          </div>
          <div className="mt-2">
            <OutcomeColumns daily={report.daily} height={200} />
          </div>
        </section>

        <section className="mt-7 break-inside-avoid" aria-labelledby="report-steps">
          <h3 id="report-steps" className="text-lg font-semibold text-ink">
            Step health
          </h3>
          <table className="mt-2 w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs text-ink-secondary">
                <th scope="col" className="py-2 pr-3 font-medium">Step</th>
                <th scope="col" className="py-2 pr-3 text-right font-medium">Executions</th>
                <th scope="col" className="py-2 pr-3 text-right font-medium">Success</th>
                <th scope="col" className="py-2 pr-3 text-right font-medium">p95</th>
                <th scope="col" className="py-2 pr-3 text-right font-medium">Avg cost</th>
                <th scope="col" className="py-2 text-right font-medium">Confidence</th>
              </tr>
            </thead>
            <tbody>
              {report.step_health.map((row) => (
                <tr key={row.node_key} className="border-b border-line-subtle">
                  <td className="py-2 pr-3 text-ink">{row.label}</td>
                  <td className="py-2 pr-3 text-right tabular">{row.executions}</td>
                  <td className={cn('py-2 pr-3 text-right tabular', (row.success_rate ?? 1) < 0.9 && 'font-semibold text-danger-text')}>
                    {formatPercent(row.success_rate, 0)}
                  </td>
                  <td className="py-2 pr-3 text-right tabular">{formatDuration(row.p95_duration_ms)}</td>
                  <td className="py-2 pr-3 text-right tabular">{row.node_type === 'agent' ? formatCurrency(row.avg_cost_usd, 3) : '—'}</td>
                  <td className="py-2 text-right tabular">{formatPercent(row.avg_confidence, 0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <div className="mt-7 grid gap-8 md:grid-cols-2">
          <section className="break-inside-avoid" aria-labelledby="report-governance">
            <h3 id="report-governance" className="text-lg font-semibold text-ink">
              Governance
            </h3>
            <p className="mt-1 text-sm text-ink-secondary">
              {report.approvals.total} human decisions
              {report.approvals.median_decision_hours !== null ? `, median ${report.approvals.median_decision_hours} h to decide` : ''}.
            </p>
            <PostureList checks={report.posture.checks} className="mt-2" />
          </section>

          <section className="break-inside-avoid" aria-labelledby="report-recommendations">
            <h3 id="report-recommendations" className="text-lg font-semibold text-ink">
              Recommendations
            </h3>
            <ol className="mt-2 space-y-3">
              {report.recommendations.map((item, index) => (
                <li key={item.title} className="flex gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-navy-700 text-2xs font-semibold text-white">
                    {index + 1}
                  </span>
                  <div>
                    <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink">
                      {item.title}
                      <Badge tone={PRIORITY_TONE[item.priority]}>{item.priority}</Badge>
                    </p>
                    <p className="text-sm text-ink-secondary">{item.detail}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        </div>

        <footer className="mt-8 border-t border-line pt-3 text-2xs text-ink-tertiary">
          Effort saved assumes {report.assumptions.minutes_saved_per_step} minutes of manual work per successful agent step.
          Costs are estimates from token usage. Generated by AI QE Orchestrator from recorded runs, approvals and audit entries.
        </footer>
      </article>
    </div>
  );
}

function ReportFigure({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="rounded-lg border border-line bg-surface-muted px-4 py-3 print:bg-white">
      <p className="text-2xs font-medium uppercase tracking-wide text-ink-tertiary">{label}</p>
      <p className="mt-1 text-2xl font-semibold tracking-[-0.01em] text-ink tabular">{value}</p>
      {note ? <p className="text-2xs text-ink-secondary">{note}</p> : null}
    </div>
  );
}
