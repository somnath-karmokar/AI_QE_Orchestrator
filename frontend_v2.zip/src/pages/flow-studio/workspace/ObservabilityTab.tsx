/** Reliability, latency, where time goes, model usage, failures and the live event feed. */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Bot, Cpu, HeartPulse, RefreshCw, Timer, TriangleAlert } from 'lucide-react';
import { api } from '@/services/api';
import { formatCurrency, formatDuration, formatNumber, formatPercent, formatRelativeTime } from '@/hooks';
import {
  Badge,
  Card,
  CardBody,
  CardHeader,
  cn,
  EmptyState,
  ErrorState,
  LoadingBlock,
  ProgressBar,
} from '@/design-system/primitives';
import { ChartCard, MetricTile, MiniTable, RankedBars, ShareBar, TrendLine } from '@/features/flow-studio/charts';
import { SERIES_COLORS, humanizeEvent, shortDate } from '@/features/flow-studio/format';
import { WindowSelect } from './shared';

const EVENT_TONE: Record<string, string> = {
  flow_failed: 'bg-danger',
  step_failed: 'bg-danger',
  step_retry: 'bg-warning',
  approval_requested: 'bg-warning',
  flow_finished: 'bg-brand-500',
  flow_started: 'bg-ink-tertiary',
  condition_evaluated: 'bg-ink-tertiary',
};

export default function ObservabilityTab({ flowId }: { flowId: string }) {
  const [windowDays, setWindowDays] = useState(14);
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['flow-observability', flowId, windowDays],
    queryFn: () => api.flowObservability(flowId, windowDays),
    refetchInterval: 15000,
  });

  if (isLoading) return <LoadingBlock rows={8} className="rounded-lg border border-line bg-surface" />;
  if (error || !data) return <ErrorState message={(error as Error)?.message} onRetry={() => void refetch()} />;

  const { slo, latency, time_split: split, llm_totals: llm } = data;
  const sloTone = slo.status === 'healthy' ? 'success' : slo.status === 'at_risk' ? 'danger' : 'neutral';

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-secondary">Telemetry from every run, step and model call of this flow.</p>
        <WindowSelect value={windowDays} onChange={setWindowDays} options={[7, 14, 30, 90]} />
      </div>

      <section aria-label="Service levels" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card className="flex flex-col gap-3 p-4">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-ink-tertiary">
              <HeartPulse className="h-3.5 w-3.5 text-ink-secondary" aria-hidden /> Reliability SLO
            </p>
            <Badge tone={sloTone}>{slo.status === 'healthy' ? 'Healthy' : slo.status === 'at_risk' ? 'At risk' : 'No data'}</Badge>
          </div>
          <p className="text-[28px] font-semibold leading-none tracking-[-0.02em] text-ink tabular">
            {formatPercent(slo.success_rate, 0)}
            <span className="ml-1.5 text-sm font-normal text-ink-secondary">target {formatPercent(slo.target_success_rate, 0)}</span>
          </p>
          <div>
            <div className="mb-1 flex justify-between text-2xs text-ink-secondary">
              <span>Error budget left</span>
              <span className="tabular">{formatPercent(Math.max(0, slo.error_budget_remaining), 0)}</span>
            </div>
            <ProgressBar
              value={Math.max(0, slo.error_budget_remaining)}
              tone={slo.error_budget_remaining > 0.5 ? 'brand' : slo.error_budget_remaining > 0 ? 'warning' : 'danger'}
              label="Error budget remaining"
            />
          </div>
        </Card>
        <MetricTile
          label="Run latency"
          icon={<Timer className="h-3.5 w-3.5" />}
          value={formatDuration(latency.p50_ms)}
          hint={`p90 ${formatDuration(latency.p90_ms)} · p95 ${formatDuration(latency.p95_ms)} · max ${formatDuration(latency.max_ms)}`}
        />
        <MetricTile
          label="Model calls"
          icon={<Cpu className="h-3.5 w-3.5" />}
          value={formatNumber(llm.calls)}
          hint={`${formatNumber(llm.tokens)} tokens · ${formatCurrency(llm.cost_usd)}`}
        />
        <MetricTile
          label="Retries and fallbacks"
          icon={<RefreshCw className="h-3.5 w-3.5" />}
          value={`${data.retries} / ${llm.fallbacks}`}
          hint={`${llm.errors} model error${llm.errors === 1 ? '' : 's'} recovered or failed`}
        />
      </section>

      <Card>
        <CardHeader
          title="Where run time goes"
          description="Agents working versus people deciding at approval gates, across finished runs."
        />
        <CardBody>
          <ShareBar
            label="Share of run time"
            format={(value) => formatDuration(value)}
            segments={[
              {
                label: 'Agents working',
                value: split.agent_ms,
                color: SERIES_COLORS[0],
                note: `≈ ${formatDuration(split.avg_agent_ms_per_run)} per run`,
              },
              {
                label: 'Waiting for approval',
                value: split.human_wait_ms,
                color: SERIES_COLORS[1],
                note: `≈ ${formatDuration(split.avg_human_wait_ms_per_run)} per run`,
              },
              { label: 'Orchestration', value: split.orchestration_ms, color: SERIES_COLORS[2], note: 'Routing, checkpoints, conditions' },
            ]}
          />
        </CardBody>
      </Card>

      <div className="grid gap-5 xl:grid-cols-2">
        <ChartCard
          title="Typical run duration"
          description="Median duration of finished runs, per day."
          table={
            <MiniTable
              caption="Median run duration per day"
              rows={[...data.daily].reverse().filter((day) => day.p50_duration_ms)}
              columns={[
                { header: 'Day', render: (day) => shortDate(day.date) },
                { header: 'Median', render: (day) => formatDuration(day.p50_duration_ms), numeric: true },
                { header: 'Runs', render: (day) => day.runs, numeric: true },
              ]}
            />
          }
        >
          <TrendLine data={data.daily} dataKey="p50_duration_ms" name="Median duration" format={(value) => formatDuration(value)} />
        </ChartCard>
        <ChartCard
          title="AI cost per day"
          description="Estimated model cost of this flow's runs."
          table={
            <MiniTable
              caption="AI cost per day"
              rows={[...data.daily].reverse().filter((day) => day.runs)}
              columns={[
                { header: 'Day', render: (day) => shortDate(day.date) },
                { header: 'Cost', render: (day) => formatCurrency(day.cost_usd, 3), numeric: true },
                { header: 'Tokens', render: (day) => formatNumber(day.tokens), numeric: true },
              ]}
            />
          }
        >
          <TrendLine data={data.daily} dataKey="cost_usd" name="AI cost" format={(value) => `€${value.toFixed(2)}`} />
        </ChartCard>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <ChartCard
          title="Slowest steps"
          description="95th percentile duration per step."
          table={
            <MiniTable
              caption="Step latency"
              rows={data.step_latency}
              columns={[
                { header: 'Step', render: (row) => row.label },
                { header: 'Runs', render: (row) => row.executions, numeric: true },
                { header: 'p50', render: (row) => formatDuration(row.p50_duration_ms), numeric: true },
                { header: 'p95', render: (row) => formatDuration(row.p95_duration_ms), numeric: true },
                { header: 'Retries', render: (row) => row.retries, numeric: true },
              ]}
            />
          }
        >
          <div className="px-2 pt-2">
            {data.step_latency.length ? (
              <RankedBars
                label="p95 duration by step"
                rows={[...data.step_latency]
                  .sort((a, b) => b.p95_duration_ms - a.p95_duration_ms)
                  .map((row) => ({ label: row.label, value: row.p95_duration_ms, secondary: `p50 ${formatDuration(row.p50_duration_ms)}` }))}
                format={(value) => formatDuration(value)}
              />
            ) : (
              <EmptyState title="No step timings yet" />
            )}
          </div>
        </ChartCard>

        <Card>
          <CardHeader icon={<Bot className="h-4 w-4" />} title="Models used" description="Routed by capability; fallbacks keep runs alive." />
          <div className="p-4">
            {data.models.length ? (
              <MiniTable
                caption="Model usage"
                rows={data.models}
                columns={[
                  { header: 'Model', render: (row) => <span className="font-medium">{row.model}</span> },
                  { header: 'Calls', render: (row) => row.calls, numeric: true },
                  { header: 'Tokens', render: (row) => formatNumber(row.tokens), numeric: true },
                  { header: 'Cost', render: (row) => formatCurrency(row.cost_usd), numeric: true },
                  { header: 'p95 latency', render: (row) => formatDuration(row.p95_latency_ms), numeric: true },
                  { header: 'Errors', render: (row) => formatPercent(row.error_rate, 0), numeric: true },
                ]}
              />
            ) : (
              <EmptyState title="No model calls in this window" />
            )}
          </div>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader icon={<TriangleAlert className="h-4 w-4" />} title="Failure signatures" description="Grouped by step and error, most frequent first." />
          <CardBody>
            {data.failures.length ? (
              <ul className="space-y-2">
                {data.failures.map((failure) => (
                  <li key={`${failure.step}-${failure.signature}`} className="flex items-start justify-between gap-3 rounded-lg border border-line p-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-ink">{failure.step}</p>
                      <p className="text-xs text-danger-text">{failure.signature}</p>
                    </div>
                    <Badge tone="danger">{failure.count}×</Badge>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="No failures in this window" description="Every step completed or recovered." className="py-8" />
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Event feed" description="The latest orchestration events across runs." />
          <CardBody className="max-h-[420px] overflow-y-auto">
            {data.events.length ? (
              <ol className="relative space-y-3 border-l border-line pl-4">
                {data.events.map((event) => (
                  <li key={event.id} className="relative">
                    <span
                      className={cn('absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-surface', EVENT_TONE[event.event_type] ?? 'bg-ink-tertiary')}
                      aria-hidden
                    />
                    <p className="text-xs text-ink-tertiary">
                      {humanizeEvent(event.event_type)} ·{' '}
                      <Link to={`/runs/${event.run_id}`} className="hover:text-brand-600">
                        run #{event.run_number ?? '—'}
                      </Link>{' '}
                      · {formatRelativeTime(event.created_at)}
                    </p>
                    <p className="text-sm text-ink">{event.content}</p>
                  </li>
                ))}
              </ol>
            ) : (
              <EmptyState title="No events yet" className="py-8" />
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
