/** How this flow operates: identity, budget, inputs, triggers, governance, and archiving. */
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Archive, CalendarClock, Check, KeyRound, RefreshCw, Save, ShieldCheck, SlidersHorizontal, Webhook } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useSession } from '@/store';
import { Badge, Button, Card, CardBody, CardHeader, Field, Input, Select, Textarea } from '@/design-system/primitives';
import { DEFAULT_GOVERNANCE, GovernanceFields, ScheduleFields } from '@/features/flow-studio/components';
import { fromInputValue, toInputValue } from '@/features/flow-studio/format';
import { ApiTokenReveal } from './shared';
import type { FlowApiToken, FlowDetail, FlowGovernanceSettings, FlowSchedule } from '@/types';

export default function SettingsTab({ flow }: { flow: FlowDetail }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const can = useSession((state) => state.can);
  const canWrite = can('flow:write');

  const initial = useMemo(
    () => ({
      name: flow.name,
      description: flow.description ?? '',
      owner: flow.owner ?? flow.created_by ?? '',
      cost_budget_usd: flow.cost_budget_usd,
      token_budget: flow.token_budget,
      variables: flow.variables ?? {},
      schedule: { frequency: 'daily', time: '07:00', weekday: 0, ...flow.schedule } as FlowSchedule,
      governance: { ...DEFAULT_GOVERNANCE, ...flow.governance } as FlowGovernanceSettings,
    }),
    [flow],
  );
  const [form, setForm] = useState(initial);
  const [saved, setSaved] = useState(false);
  const [token, setToken] = useState<FlowApiToken | null>(null);
  useEffect(() => setForm(initial), [initial]);

  const dirty = JSON.stringify(form) !== JSON.stringify(initial);
  const people = useQuery({ queryKey: ['demo-users'], queryFn: api.demoUsers, staleTime: Infinity });

  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ['flow', flow.id] });
    void queryClient.invalidateQueries({ queryKey: ['flow-governance', flow.id] });
    void queryClient.invalidateQueries({ queryKey: ['flow-overview'] });
  };

  const save = useMutation({
    mutationFn: () =>
      api.updateFlowSettings(flow.id, {
        name: form.name,
        description: form.description,
        owner: form.owner,
        cost_budget_usd: form.cost_budget_usd,
        token_budget: form.token_budget,
        variables: form.variables,
        schedule: form.schedule,
        governance: form.governance,
      }),
    onSuccess: () => {
      refresh();
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    },
  });
  const issueToken = useMutation({
    mutationFn: () => api.createFlowApiToken(flow.id),
    onSuccess: (issued) => {
      setToken(issued);
      refresh();
    },
  });
  const revokeToken = useMutation({
    mutationFn: () => api.revokeFlowApiToken(flow.id),
    onSuccess: () => {
      setToken(null);
      refresh();
    },
  });
  const archive = useMutation({
    mutationFn: () => api.deleteFlow(flow.id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['flow-overview'] });
      navigate('/flows');
    },
  });

  const errorMessage = (caught: unknown) => (caught instanceof ApiError ? caught.message : 'Something went wrong.');
  const variableKeys = Object.keys(form.variables);

  return (
    <div className="space-y-5">
      <div className="sticky top-14 z-20 -mx-1 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-line bg-surface/95 px-4 py-2.5 shadow-card backdrop-blur">
        <p className="text-sm text-ink-secondary">
          {dirty ? 'You have unsaved changes.' : saved ? 'Saved. Changes are recorded in the audit trail.' : 'Changes apply to the next run and are audited.'}
        </p>
        <div className="flex items-center gap-2">
          {dirty ? (
            <Button variant="ghost" onClick={() => setForm(initial)}>
              Discard
            </Button>
          ) : null}
          <Button
            variant="primary"
            icon={saved && !dirty ? <Check className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />}
            disabled={!dirty || !canWrite || form.name.trim().length < 2}
            loading={save.isPending}
            onClick={() => save.mutate()}
          >
            Save changes
          </Button>
        </div>
      </div>
      {save.error ? (
        <p role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2 text-sm text-danger-text">
          {errorMessage(save.error)}
        </p>
      ) : null}

      <div className="grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader icon={<SlidersHorizontal className="h-4 w-4" />} title="General" />
          <CardBody className="space-y-4">
            <Field label="Name" htmlFor="settings-name" required>
              <Input id="settings-name" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
            </Field>
            <Field label="Description" htmlFor="settings-description">
              <Textarea
                id="settings-description"
                rows={3}
                value={form.description}
                onChange={(event) => setForm({ ...form, description: event.target.value })}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Owner" htmlFor="settings-owner" className="sm:col-span-3">
                <Select id="settings-owner" value={form.owner} onChange={(event) => setForm({ ...form, owner: event.target.value })}>
                  {!people.data?.some((person) => person.email === form.owner) && form.owner ? (
                    <option value={form.owner}>{form.owner}</option>
                  ) : null}
                  {(people.data ?? []).map((person) => (
                    <option key={person.email} value={person.email}>
                      {person.full_name} · {person.role_label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Budget per run (€)" htmlFor="settings-budget" className="sm:col-span-2">
                <Input
                  id="settings-budget"
                  type="number"
                  min={0.5}
                  step={0.5}
                  value={form.cost_budget_usd}
                  onChange={(event) => setForm({ ...form, cost_budget_usd: Number(event.target.value) })}
                />
              </Field>
              <Field label="Token budget" htmlFor="settings-tokens">
                <Input
                  id="settings-tokens"
                  type="number"
                  min={1000}
                  step={1000}
                  value={form.token_budget}
                  onChange={(event) => setForm({ ...form, token_budget: Number(event.target.value) })}
                />
              </Field>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Default run inputs" description="Used by scheduled and API runs, and pre-filled for manual runs." />
          <CardBody className="space-y-3">
            {variableKeys.length ? (
              variableKeys.map((key) => (
                <Field key={key} label={key.replace(/_/g, ' ')} htmlFor={`settings-var-${key}`}>
                  <Input
                    id={`settings-var-${key}`}
                    value={toInputValue(form.variables[key])}
                    onChange={(event) =>
                      setForm({
                        ...form,
                        variables: { ...form.variables, [key]: fromInputValue(event.target.value, initial.variables[key]) },
                      })
                    }
                  />
                </Field>
              ))
            ) : (
              <p className="text-sm text-ink-secondary">This flow takes no inputs. Add input mappings in the designer.</p>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader icon={<CalendarClock className="h-4 w-4" />} title="Schedule" description="Only published versions run on a schedule." />
          <CardBody>
            <ScheduleFields value={form.schedule} onChange={(schedule) => setForm({ ...form, schedule })} />
          </CardBody>
        </Card>

        <Card>
          <CardHeader icon={<Webhook className="h-4 w-4" />} title="API trigger" description="Let CI or another tool start this flow. The token is stored only as a keyed hash." />
          <CardBody className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm">
                <KeyRound className="h-4 w-4 text-ink-tertiary" aria-hidden />
                {flow.api_trigger_enabled ? (
                  <>
                    <Badge tone="info">Enabled</Badge>
                    <span className="text-ink-secondary">token ending …{flow.webhook_token_hint}</span>
                  </>
                ) : (
                  <Badge tone="neutral">Off</Badge>
                )}
              </div>
              {canWrite ? (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    icon={<RefreshCw className="h-3.5 w-3.5" />}
                    loading={issueToken.isPending}
                    onClick={() => issueToken.mutate()}
                  >
                    {flow.api_trigger_enabled ? 'Rotate token' : 'Enable and create token'}
                  </Button>
                  {flow.api_trigger_enabled ? (
                    <Button size="sm" variant="ghost" loading={revokeToken.isPending} onClick={() => revokeToken.mutate()}>
                      Disable
                    </Button>
                  ) : null}
                </div>
              ) : null}
            </div>
            {flow.api_trigger_enabled && flow.status !== 'published' ? (
              <p className="text-xs text-warning-text">API calls are refused until the flow is published.</p>
            ) : null}
            {token ? <ApiTokenReveal token={token} /> : null}
            {issueToken.error || revokeToken.error ? (
              <p role="alert" className="text-sm text-danger-text">
                {errorMessage(issueToken.error ?? revokeToken.error)}
              </p>
            ) : null}
          </CardBody>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader icon={<ShieldCheck className="h-4 w-4" />} title="Governance" />
          <CardBody>
            <GovernanceFields value={form.governance} onChange={(governance) => setForm({ ...form, governance })} />
          </CardBody>
        </Card>

        {canWrite ? (
          <Card className="border-danger-border xl:col-span-2">
            <CardBody className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-ink">Archive this flow</p>
                <p className="text-xs text-ink-secondary">
                  Stops its schedule and API trigger. Run history, reports and audit entries are kept.
                </p>
              </div>
              <Button
                variant="danger"
                icon={<Archive className="h-3.5 w-3.5" />}
                loading={archive.isPending}
                onClick={() => {
                  if (window.confirm(`Archive "${flow.name}"? Its schedule and API trigger will stop.`)) archive.mutate();
                }}
              >
                Archive flow
              </Button>
            </CardBody>
          </Card>
        ) : null}
      </div>
    </div>
  );
}
