/** One flow, operated on its own: overview, runs, observability, governance, report and settings. */
import { useState } from 'react';
import { Link, NavLink, useLocation, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  CalendarClock,
  CheckCircle2,
  FileText,
  Gauge,
  PencilRuler,
  Play,
  Radar,
  Rocket,
  Settings2,
  ShieldCheck,
  X,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { formatDateTime, formatRelativeTime } from '@/hooks';
import { useSession } from '@/store';
import { Badge, Button, cn, EmptyState, humanize, LoadingBlock, statusTone } from '@/design-system/primitives';
import { OwnerChip, RunFlowDialog, TriggerBadges } from '@/features/flow-studio/components';
import { ApiTokenReveal } from './workspace/shared';
import OverviewTab from './workspace/OverviewTab';
import RunsTab from './workspace/RunsTab';
import ObservabilityTab from './workspace/ObservabilityTab';
import GovernanceTab from './workspace/GovernanceTab';
import ReportTab from './workspace/ReportTab';
import SettingsTab from './workspace/SettingsTab';
import type { FlowApiToken } from '@/types';

const TABS = [
  { key: 'overview', label: 'Overview', icon: Gauge },
  { key: 'runs', label: 'Runs', icon: Activity },
  { key: 'observability', label: 'Observability', icon: Radar },
  { key: 'governance', label: 'Governance', icon: ShieldCheck },
  { key: 'report', label: 'Report', icon: FileText },
  { key: 'settings', label: 'Settings', icon: Settings2 },
] as const;

type TabKey = (typeof TABS)[number]['key'];

export default function FlowWorkspacePage() {
  const { flowId, tab } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const can = useSession((state) => state.can);
  const [runOpen, setRunOpen] = useState(false);
  const created = (location.state as { created?: boolean; apiToken?: FlowApiToken | null } | null) ?? null;
  const [banner, setBanner] = useState(Boolean(created?.created));
  const active: TabKey = (TABS.find((item) => item.key === tab)?.key ?? 'overview') as TabKey;

  const { data: flow, isLoading, error } = useQuery({
    queryKey: ['flow', flowId],
    queryFn: () => api.getFlow(flowId!),
    enabled: Boolean(flowId),
  });

  const publish = useMutation({
    mutationFn: () => api.publishFlow(flowId!, 'Published from the flow workspace.'),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['flow', flowId] });
      void queryClient.invalidateQueries({ queryKey: ['flow-governance', flowId] });
    },
  });

  if (isLoading) return <LoadingBlock rows={8} />;
  if (error || !flow) {
    return (
      <EmptyState
        title="Flow not found"
        description={error instanceof ApiError ? error.message : 'This flow may have been archived.'}
        action={
          <Link to="/flows" className="text-sm font-medium text-brand-600">
            Back to Flow Studio
          </Link>
        }
      />
    );
  }

  const agentSteps = flow.nodes.filter((node) => node.node_type === 'agent').length;
  const gates = flow.nodes.filter((node) => node.node_type === 'approval' || node.requires_approval).length;

  return (
    <div className="space-y-5">
      <div className="print:hidden">
        <Link to="/flows" className="text-sm text-ink-secondary hover:text-brand-600">
          ← Flow Studio
        </Link>
      </div>

      {/* Header */}
      <header className="rounded-xl border border-line bg-surface shadow-card print:hidden">
        <div className="flex flex-wrap items-start justify-between gap-4 px-6 pt-5">
          <div className="min-w-0 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-3xl font-semibold tracking-[-0.02em] text-ink">{flow.name}</h1>
              <Badge tone={statusTone(flow.status)}>{humanize(flow.status)}</Badge>
              <Badge tone="neutral">v{flow.version}</Badge>
              {flow.validation_result?.valid === false ? <Badge tone="danger">Needs fixes</Badge> : null}
            </div>
            {flow.description ? <p className="mt-1 text-md text-ink-secondary">{flow.description}</p> : null}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="secondary" icon={<PencilRuler className="h-3.5 w-3.5" />} onClick={() => navigate(`/flows/${flow.id}/designer`)}>
              Open designer
            </Button>
            {can('flow:write') && flow.status !== 'published' ? (
              <Button
                variant="secondary"
                icon={<Rocket className="h-3.5 w-3.5" />}
                loading={publish.isPending}
                disabled={flow.validation_result?.valid === false}
                onClick={() => publish.mutate()}
              >
                Publish
              </Button>
            ) : null}
            {can('flow:run') ? (
              <Button
                variant="primary"
                icon={<Play className="h-3.5 w-3.5" />}
                disabled={flow.validation_result?.valid === false}
                onClick={() => setRunOpen(true)}
              >
                Run flow
              </Button>
            ) : null}
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 px-6 pb-4 text-xs text-ink-secondary">
          <OwnerChip email={flow.owner ?? flow.created_by} />
          <span>
            {agentSteps} agent{agentSteps === 1 ? '' : 's'} · {gates} approval gate{gates === 1 ? '' : 's'}
          </span>
          <TriggerBadges schedule={flow.schedule} scheduleDescription={flow.schedule_description} apiEnabled={flow.api_trigger_enabled} />
          {flow.next_run_at ? (
            <span className="flex items-center gap-1" title={formatDateTime(flow.next_run_at)}>
              <CalendarClock className="h-3.5 w-3.5" aria-hidden /> Next run {formatRelativeTimeFuture(flow.next_run_at)}
            </span>
          ) : null}
          <span>Last run {formatRelativeTime(flow.last_run_at)}</span>
        </div>
        {publish.error ? (
          <p role="alert" className="mx-6 mb-3 rounded border border-danger-border bg-danger-bg px-3 py-2 text-sm text-danger-text">
            {publish.error instanceof ApiError ? publish.error.message : 'Publishing failed.'}
          </p>
        ) : null}
        <nav className="flex gap-1 overflow-x-auto border-t border-line px-4" aria-label="Flow workspace">
          {TABS.map((item) => (
            <NavLink
              key={item.key}
              to={item.key === 'overview' ? `/flows/${flow.id}` : `/flows/${flow.id}/${item.key}`}
              end
              className={() =>
                cn(
                  'flex items-center gap-1.5 whitespace-nowrap border-b-2 px-3 py-2.5 text-sm font-medium transition-colors',
                  active === item.key
                    ? 'border-brand-500 text-brand-700'
                    : 'border-transparent text-ink-secondary hover:border-line-strong hover:text-ink',
                )
              }
              aria-current={active === item.key ? 'page' : undefined}
            >
              <item.icon className="h-3.5 w-3.5" aria-hidden />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </header>

      {banner ? (
        <div className="space-y-3 rounded-xl border border-success-border bg-success-bg p-4 print:hidden" role="status">
          <div className="flex items-start justify-between gap-3">
            <p className="flex items-center gap-2 text-sm font-semibold text-success-text">
              <CheckCircle2 className="h-4 w-4" aria-hidden />
              {flow.name} is ready{flow.status === 'published' ? ' and published' : ' as a draft'}. This is its workspace.
            </p>
            <button type="button" onClick={() => setBanner(false)} aria-label="Dismiss" className="text-success-text">
              <X className="h-4 w-4" />
            </button>
          </div>
          {created?.apiToken ? <ApiTokenReveal token={created.apiToken} /> : null}
        </div>
      ) : null}

      {active === 'overview' ? <OverviewTab flow={flow} /> : null}
      {active === 'runs' ? <RunsTab flowId={flow.id} /> : null}
      {active === 'observability' ? <ObservabilityTab flowId={flow.id} /> : null}
      {active === 'governance' ? <GovernanceTab flowId={flow.id} /> : null}
      {active === 'report' ? <ReportTab flowId={flow.id} /> : null}
      {active === 'settings' ? <SettingsTab flow={flow} /> : null}

      <RunFlowDialog open={runOpen} onClose={() => setRunOpen(false)} flowId={flow.id} flowName={flow.name} variables={flow.variables} />
    </div>
  );
}

function formatRelativeTimeFuture(iso: string): string {
  const diff = Math.round((new Date(iso).getTime() - Date.now()) / 1000);
  if (Number.isNaN(diff)) return '—';
  if (diff <= 60) return 'any moment';
  if (diff < 3600) return `in ${Math.round(diff / 60)}m`;
  if (diff < 86400) return `in ${Math.round(diff / 3600)}h`;
  return `in ${Math.round(diff / 86400)}d`;
}
