/** Create a flow in four steps: how to start, what it does, how it operates, review. */
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Bot,
  CalendarClock,
  Check,
  CheckCircle2,
  GitBranch,
  LayoutTemplate,
  PencilRuler,
  RefreshCw,
  Rocket,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  UserCheck,
  Webhook,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { formatCurrency, useProjectId } from '@/hooks';
import { useCartBadge, useSession } from '@/store';
import {
  Badge,
  Button,
  Card,
  CardBody,
  CardHeader,
  cn,
  ErrorState,
  Field,
  Input,
  LoadingBlock,
  PageHeader,
  Select,
  Textarea,
  TONE_BY_RISK,
} from '@/design-system/primitives';
import {
  DEFAULT_GOVERNANCE,
  GovernanceFields,
  ScheduleFields,
  StepIcon,
  TemplateGlyph,
  Toggle,
} from '@/features/flow-studio/components';
import { ROLE_LABELS, describeSchedule, fromInputValue, personName, toInputValue } from '@/features/flow-studio/format';
import { TemplateCard } from './FlowStudioPage';
import { FlowGraphView } from '@/features/flow-graph/FlowGraphView';
import type { FlowComposition, FlowGovernanceSettings, FlowSchedule, FlowTemplate } from '@/types';

type Mode = 'describe' | 'template' | 'blank';
type Step = 0 | 1 | 2 | 3;

const STEPS = ['Start', 'Design', 'Operate', 'Review'];

export default function NewFlowPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const user = useSession((state) => state.user);
  const cartCount = useCartBadge((state) => state.count);

  const initialMode = params.get('mode') as Mode | null;
  const [mode, setMode] = useState<Mode | null>(initialMode);
  const [step, setStep] = useState<Step>(initialMode ? 1 : 0);

  // Design
  const [description, setDescription] = useState(params.get('text') ?? '');
  const [composition, setComposition] = useState<FlowComposition | null>(null);
  const [draftView, setDraftView] = useState<'steps' | 'graph'>('graph');
  const [templateKey, setTemplateKey] = useState<string | null>(params.get('template'));

  // Shared settings
  const [name, setName] = useState('');
  const [summary, setSummary] = useState('');
  const [variables, setVariables] = useState<Record<string, unknown>>({});
  const [owner, setOwner] = useState(user?.email ?? '');
  const [budget, setBudget] = useState(5);
  const [schedule, setSchedule] = useState<FlowSchedule>({ enabled: false, frequency: 'daily', time: '07:00', weekday: 0 });
  const [governance, setGovernance] = useState<FlowGovernanceSettings>(DEFAULT_GOVERNANCE);
  const [apiTrigger, setApiTrigger] = useState(false);
  const [publishNow, setPublishNow] = useState(false);

  const templates = useQuery({
    queryKey: ['flow-templates', projectId],
    queryFn: () => api.flowTemplates(projectId!),
    enabled: Boolean(projectId),
    staleTime: 5 * 60 * 1000,
  });
  const people = useQuery({ queryKey: ['demo-users'], queryFn: api.demoUsers, staleTime: Infinity });
  const agentCatalogue = useQuery({
    queryKey: ['agents-catalogue', projectId],
    queryFn: () => api.listAgents({ project_id: projectId ?? undefined, limit: 200 }),
    enabled: Boolean(projectId),
    staleTime: 5 * 60 * 1000,
  });
  const agentIconByKey = useMemo(
    () => Object.fromEntries((agentCatalogue.data?.items ?? []).map((agent) => [agent.key, agent.icon])),
    [agentCatalogue.data],
  );
  const template = useMemo(
    () => templates.data?.find((item) => item.key === templateKey) ?? null,
    [templates.data, templateKey],
  );

  const compose = useMutation({
    mutationFn: (text: string) => api.composeFlow({ project_id: projectId!, description: text }),
    onSuccess: (draft) => {
      setComposition(draft);
      setName(draft.name);
      setSummary(draft.description);
      setVariables(draft.variables);
      if (draft.schedule) setSchedule(draft.schedule);
      setPublishNow(draft.validation.valid);
    },
  });

  // Arriving with a description (from the Flow Studio home) drafts straight away.
  useEffect(() => {
    if (mode === 'describe' && description.trim().length >= 8 && !composition && !compose.isPending && projectId) {
      compose.mutate(description);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  // Choosing a template fills in its inputs and budget.
  useEffect(() => {
    if (!template) return;
    setName(template.name);
    setSummary(template.description);
    setVariables(template.variables);
    setBudget(template.cost_budget_usd);
  }, [template]);

  const chooseMode = (next: Mode) => {
    setMode(next);
    setStep(1);
    setParams(next === 'describe' ? { mode: next } : { mode: next }, { replace: true });
    if (next === 'blank') {
      setName('');
      setSummary('');
      setVariables({});
    }
  };

  const create = useMutation({
    mutationFn: async () => {
      const operating = {
        owner: owner || undefined,
        schedule,
        governance,
        cost_budget_usd: budget,
      };
      let flow;
      if (mode === 'template' && template) {
        flow = await api.createFlowFromTemplate({
          project_id: projectId,
          template_key: template.key,
          name,
          description: summary,
          variables,
          ...operating,
        });
      } else if (mode === 'describe' && composition) {
        flow = await api.createFlow({
          project_id: projectId,
          name,
          description: summary,
          category: 'Custom',
          tags: ['composed'],
          nodes: composition.nodes,
          edges: composition.edges,
          variables,
          source: 'composer',
          ...operating,
        });
      } else {
        flow = await api.createFlow({
          project_id: projectId,
          name,
          description: summary,
          category: 'Custom',
          nodes: [
            { node_key: 'start', node_type: 'start', label: 'Start', position_x: 120, position_y: 80 },
            { node_key: 'end', node_type: 'end', label: 'Complete', position_x: 120, position_y: 380 },
          ],
          edges: [{ source_node_key: 'start', target_node_key: 'end' }],
          variables: {},
          source: 'blank',
          ...operating,
        });
      }
      let apiToken = null;
      if (apiTrigger) apiToken = await api.createFlowApiToken(flow.id);
      if (publishNow && mode !== 'blank') {
        try {
          flow = await api.publishFlow(flow.id, 'Published when the flow was created.');
        } catch {
          /* stays a draft; the workspace shows what needs fixing */
        }
      }
      return { flow, apiToken };
    },
    onSuccess: ({ flow, apiToken }) => {
      if (mode === 'blank') navigate(`/flows/${flow.id}/designer`);
      else navigate(`/flows/${flow.id}`, { state: { created: true, apiToken } });
    },
  });

  const designReady =
    (mode === 'describe' && composition && composition.agent_count > 0) ||
    (mode === 'template' && template) ||
    (mode === 'blank' && name.trim().length >= 2);

  const operateReady = name.trim().length >= 2 && budget > 0;

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Create a flow"
        description="From idea to a governed, runnable flow in a few minutes."
        breadcrumb={
          <Link to="/flows" className="text-sm text-ink-secondary hover:text-brand-600">
            ← Flow Studio
          </Link>
        }
      />

      <Stepper step={step} onJump={(target) => target < step && setStep(target)} />

      {step === 0 ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <MethodCard
            icon={<Sparkles className="h-5 w-5" />}
            title="Describe it"
            badge="Fastest"
            text="Write what the flow should do. The studio drafts the steps, decisions and approvals, and explains each choice."
            onClick={() => chooseMode('describe')}
          />
          <MethodCard
            icon={<LayoutTemplate className="h-5 w-5" />}
            title="Start from a template"
            text="Proven QE journeys with governance already in place: story to automation, failure to defect, and more."
            onClick={() => chooseMode('template')}
          />
          <MethodCard
            icon={<PencilRuler className="h-5 w-5" />}
            title="Blank canvas"
            text="Name the flow, set how it operates, then design every node yourself in the visual designer."
            onClick={() => chooseMode('blank')}
          />
          <MethodCard
            icon={<ShoppingCart className="h-5 w-5" />}
            title="From the agent cart"
            badge={cartCount ? `${cartCount} in cart` : undefined}
            text="Pick agents in the marketplace, then build them into a sequential flow from the cart."
            onClick={() => navigate(cartCount ? '/cart' : '/marketplace')}
          />
        </div>
      ) : null}

      {step === 1 && mode === 'describe' ? (
        <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
          <Card>
            <CardHeader
              icon={<Sparkles className="h-4 w-4 text-brand-500" />}
              title="Describe the flow"
              description="Name the work in order. Mention decisions (“if it scores below 80”) and approvals (“after QE lead sign-off”)."
            />
            <CardBody className="space-y-3">
              <Textarea
                aria-label="Flow description"
                rows={4}
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="Check PAY-201 is ready for testing; if it scores below 80 get business sign-off; then generate scenarios, test cases and test data for Payments"
              />
              <div className="flex justify-end">
                <Button
                  variant={composition ? 'secondary' : 'primary'}
                  icon={composition ? <RefreshCw className="h-3.5 w-3.5" /> : <Sparkles className="h-3.5 w-3.5" />}
                  loading={compose.isPending}
                  disabled={description.trim().length < 8}
                  onClick={() => compose.mutate(description)}
                >
                  {composition ? 'Redraft' : 'Draft my flow'}
                </Button>
              </div>
              {compose.error ? (
                <ErrorState message={compose.error instanceof ApiError ? compose.error.message : 'Drafting failed.'} />
              ) : null}
              {compose.isPending && !composition ? <LoadingBlock rows={5} /> : null}
              {composition ? (
                <>
                  <div role="tablist" aria-label="Draft view" className="flex gap-1 border-b border-line">
                    {(['steps', 'graph'] as const).map((option) => (
                      <button
                        key={option}
                        type="button"
                        role="tab"
                        aria-selected={draftView === option}
                        onClick={() => setDraftView(option)}
                        className={cn(
                          '-mb-px border-b-2 px-3 py-2 text-sm font-medium',
                          draftView === option ? 'border-brand-500 text-brand-700' : 'border-transparent text-ink-secondary hover:text-ink',
                        )}
                      >
                        {option === 'steps' ? 'Steps and reasons' : 'Flow graph'}
                      </button>
                    ))}
                  </div>
                  {draftView === 'steps' ? (
                    <ComposedSteps composition={composition} />
                  ) : (
                    <FlowGraphView
                      height={Math.min(640, Math.max(360, composition.nodes.length * 95))}
                      label={`Graph of the drafted flow ${name}`}
                      nodes={composition.nodes.map((node) => {
                        const step = composition.steps.find((item) => item.node_key === node.node_key);
                        return {
                          node_key: node.node_key,
                          node_type: node.node_type,
                          label: node.label,
                          position_x: Number(node.position_x ?? 0),
                          position_y: Number(node.position_y ?? 0),
                          subtitle:
                            node.node_type === 'approval'
                              ? `Approval · ${ROLE_LABELS[String(node.approval_role ?? 'qe_lead')] ?? 'QE Lead'}`
                              : step?.agent_name ?? undefined,
                          icon: step?.agent_key ? agentIconByKey[step.agent_key] : undefined,
                        };
                      })}
                      edges={composition.edges.map((edge) => ({
                        id: `${edge.source_node_key}->${edge.target_node_key}`,
                        source: edge.source_node_key,
                        target: edge.target_node_key,
                        branch_label: edge.branch_label,
                        state: 'static' as const,
                      }))}
                    />
                  )}
                </>
              ) : null}
            </CardBody>
          </Card>
          <aside className="space-y-4">
            {composition ? (
              <>
                <Card>
                  <CardHeader title="Draft summary" />
                  <CardBody className="space-y-3">
                    <Field label="Flow name" htmlFor="draft-name">
                      <Input id="draft-name" value={name} onChange={(event) => setName(event.target.value)} />
                    </Field>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <SummaryStat icon={<Bot className="h-3.5 w-3.5" />} label="Agents" value={composition.agent_count} />
                      <SummaryStat icon={<UserCheck className="h-3.5 w-3.5" />} label="Approvals" value={composition.approval_gates} />
                      <SummaryStat icon={<GitBranch className="h-3.5 w-3.5" />} label="Decisions" value={composition.conditions} />
                    </div>
                    <ValidationNote valid={composition.validation.valid} errors={composition.validation.errors} />
                    {composition.schedule ? (
                      <p className="flex items-center gap-1.5 rounded border border-brand-100 bg-brand-50 px-3 py-2 text-xs text-brand-800">
                        <CalendarClock className="h-3.5 w-3.5" aria-hidden />
                        Suggested schedule: {describeSchedule(composition.schedule)}
                      </p>
                    ) : null}
                    {composition.warnings.map((warning) => (
                      <p key={warning} className="flex gap-1.5 text-xs text-warning-text">
                        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden /> {warning}
                      </p>
                    ))}
                  </CardBody>
                </Card>
                <VariablesCard variables={variables} onChange={setVariables} />
              </>
            ) : (
              <Card>
                <CardBody className="space-y-2 text-sm text-ink-secondary">
                  <p className="font-medium text-ink">What the studio understands</p>
                  <ul className="list-inside list-disc space-y-1">
                    <li>Work: readiness, scenarios, test cases, test data, Playwright scripts, execution, failure analysis, root cause, defects, regression, coverage, accessibility, UAT</li>
                    <li>Decisions: “if it scores below 80”, “only when confidence is above 90”</li>
                    <li>Approvals: “after QE lead approval”, “get business sign-off”</li>
                    <li>Timing: “every night”, “every Monday”</li>
                  </ul>
                </CardBody>
              </Card>
            )}
          </aside>
        </div>
      ) : null}

      {step === 1 && mode === 'template' ? (
        <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
          <div>
            {templates.isLoading ? (
              <LoadingBlock rows={6} />
            ) : (
              <div className="grid gap-3 md:grid-cols-2">
                {(templates.data ?? []).map((item) => (
                  <TemplateCard key={item.key} template={item} selected={item.key === templateKey} onSelect={() => setTemplateKey(item.key)} />
                ))}
              </div>
            )}
          </div>
          <aside>
            {template ? <TemplatePreview template={template} variables={variables} onVariables={setVariables} /> : (
              <Card>
                <CardBody className="text-sm text-ink-secondary">Choose a template to see its steps, inputs and cost.</CardBody>
              </Card>
            )}
          </aside>
        </div>
      ) : null}

      {step === 1 && mode === 'blank' ? (
        <Card className="max-w-2xl">
          <CardHeader icon={<PencilRuler className="h-4 w-4" />} title="Name your flow" description="You'll design the steps in the visual designer next." />
          <CardBody className="space-y-4">
            <Field label="Flow name" htmlFor="blank-name" required>
              <Input id="blank-name" value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Payments release gate" />
            </Field>
            <Field label="What it is for" htmlFor="blank-description">
              <Textarea id="blank-description" rows={3} value={summary} onChange={(event) => setSummary(event.target.value)} />
            </Field>
          </CardBody>
        </Card>
      ) : null}

      {step === 2 ? (
        <div className="grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader icon={<UserCheck className="h-4 w-4" />} title="Ownership and budget" />
            <CardBody className="space-y-4">
              <Field label="Flow name" htmlFor="operate-name" required>
                <Input id="operate-name" value={name} onChange={(event) => setName(event.target.value)} />
              </Field>
              <Field label="Description" htmlFor="operate-description">
                <Textarea id="operate-description" rows={2} value={summary} onChange={(event) => setSummary(event.target.value)} />
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Owner" htmlFor="operate-owner" hint="Accountable for the flow's results and alerts.">
                  <Select id="operate-owner" value={owner} onChange={(event) => setOwner(event.target.value)}>
                    {(people.data ?? []).map((person) => (
                      <option key={person.email} value={person.email}>
                        {person.full_name} · {person.role_label}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Budget per run (€)" htmlFor="operate-budget" hint="A run stops before it spends more.">
                  <Input
                    id="operate-budget"
                    type="number"
                    min={0.5}
                    step={0.5}
                    value={budget}
                    onChange={(event) => setBudget(Number(event.target.value))}
                  />
                </Field>
              </div>
            </CardBody>
          </Card>
          <Card>
            <CardHeader icon={<CalendarClock className="h-4 w-4" />} title="Triggers" description="Every flow can be run by hand. Add a schedule or an API trigger so it works on its own." />
            <CardBody className="space-y-5">
              <ScheduleFields value={schedule} onChange={setSchedule} />
              <div className="border-t border-line-subtle pt-4">
                <Toggle
                  checked={apiTrigger}
                  onChange={setApiTrigger}
                  label="API trigger"
                  description="Issue a token so CI or another tool can start this flow with one authenticated POST. The token is shown once."
                />
              </div>
            </CardBody>
          </Card>
          <Card className="lg:col-span-2">
            <CardHeader icon={<ShieldCheck className="h-4 w-4" />} title="Governance" description="Controls that apply to this flow in addition to project policies." />
            <CardBody>
              <GovernanceFields value={governance} onChange={setGovernance} />
            </CardBody>
          </Card>
        </div>
      ) : null}

      {step === 3 ? (
        <Card className="mx-auto max-w-3xl">
          <CardHeader icon={<CheckCircle2 className="h-4 w-4 text-brand-500" />} title="Review and create" />
          <CardBody className="space-y-5">
            <dl className="grid gap-4 sm:grid-cols-2">
              <ReviewItem label="Name">{name}</ReviewItem>
              <ReviewItem label="Built from">
                {mode === 'describe' ? 'Your description' : mode === 'template' ? `Template: ${template?.name}` : 'Blank canvas'}
              </ReviewItem>
              <ReviewItem label="Owner">{personName(owner)}</ReviewItem>
              <ReviewItem label="Budget per run">{formatCurrency(budget)} · alert at {governance.budget_alert_percent}%</ReviewItem>
              <ReviewItem label="Triggers">
                <span className="flex flex-wrap gap-1.5">
                  <Badge tone="neutral">Manual</Badge>
                  {schedule.enabled ? <Badge tone="brand">{describeSchedule(schedule)}</Badge> : null}
                  {apiTrigger ? (
                    <Badge tone="info">
                      <Webhook className="h-3 w-3" aria-hidden /> API
                    </Badge>
                  ) : null}
                </span>
              </ReviewItem>
              <ReviewItem label="Who can run it">
                {governance.run_roles.length ? governance.run_roles.map((role) => ROLE_LABELS[role]).join(', ') : 'Anyone with run permission'}
              </ReviewItem>
            </dl>
            {mode === 'describe' && composition ? <ComposedSteps composition={composition} compact /> : null}
            {mode === 'template' && template ? (
              <ol className="space-y-1.5">
                {template.steps.map((item, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm text-ink">
                    <StepIcon type={item.requires_approval ? 'approval' : item.node_type} className="text-ink-tertiary" />
                    {item.label}
                  </li>
                ))}
              </ol>
            ) : null}
            {mode !== 'blank' ? (
              <div className="rounded-lg border border-line bg-surface-muted p-4">
                <Toggle
                  checked={publishNow}
                  onChange={setPublishNow}
                  label="Publish version 1.0.0 now"
                  description="Published flows can run on their schedule and from the API. Leave off to review it in the designer first."
                />
              </div>
            ) : null}
            {create.error ? (
              <ErrorState title="The flow was not created" message={create.error instanceof ApiError ? create.error.message : String(create.error)} />
            ) : null}
          </CardBody>
        </Card>
      ) : null}

      {step > 0 ? (
        <div className="mt-6 flex items-center justify-between border-t border-line pt-4">
          <Button variant="ghost" icon={<ArrowLeft className="h-3.5 w-3.5" />} onClick={() => setStep((step - 1) as Step)}>
            Back
          </Button>
          {step < 3 ? (
            <Button
              variant="primary"
              disabled={(step === 1 && !designReady) || (step === 2 && !operateReady)}
              onClick={() => setStep((step + 1) as Step)}
            >
              Continue <ArrowRight className="h-3.5 w-3.5" aria-hidden />
            </Button>
          ) : (
            <Button
              variant="primary"
              icon={<Rocket className="h-3.5 w-3.5" />}
              loading={create.isPending}
              disabled={!operateReady}
              onClick={() => create.mutate()}
            >
              {mode === 'blank' ? 'Create and open designer' : publishNow ? 'Create and publish' : 'Create flow'}
            </Button>
          )}
        </div>
      ) : null}
    </div>
  );
}

/* -------------------------------------------------------------------------- */

function Stepper({ step, onJump }: { step: Step; onJump: (step: Step) => void }) {
  return (
    <ol className="mb-6 flex flex-wrap items-center gap-2" aria-label="Progress">
      {STEPS.map((label, index) => {
        const state = index < step ? 'done' : index === step ? 'current' : 'todo';
        return (
          <li key={label} className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onJump(index as Step)}
              disabled={state !== 'done'}
              aria-current={state === 'current' ? 'step' : undefined}
              className={cn(
                'flex items-center gap-2 rounded-full border px-3 py-1 text-sm transition-colors',
                state === 'current' && 'border-navy-700 bg-navy-700 text-white',
                state === 'done' && 'border-brand-200 bg-brand-50 text-brand-700 hover:bg-brand-100',
                state === 'todo' && 'border-line text-ink-tertiary',
              )}
            >
              <span
                className={cn(
                  'flex h-5 w-5 items-center justify-center rounded-full text-2xs font-semibold',
                  state === 'current' ? 'bg-white text-navy-700' : state === 'done' ? 'bg-brand-500 text-white' : 'bg-surface-sunken',
                )}
              >
                {state === 'done' ? <Check className="h-3 w-3" aria-hidden /> : index + 1}
              </span>
              {label}
            </button>
            {index < STEPS.length - 1 ? <span className="h-px w-6 bg-line-strong" aria-hidden /> : null}
          </li>
        );
      })}
    </ol>
  );
}

function MethodCard({
  icon,
  title,
  text,
  badge,
  onClick,
}: {
  icon: ReactNode;
  title: string;
  text: string;
  badge?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex h-full flex-col rounded-xl border border-line bg-surface p-5 text-left shadow-card transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-raised"
    >
      <div className="flex items-center justify-between">
        <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-navy-700 text-white">{icon}</span>
        {badge ? <Badge tone="brand">{badge}</Badge> : null}
      </div>
      <p className="mt-4 text-md font-semibold text-ink">{title}</p>
      <p className="mt-1 text-sm text-ink-secondary">{text}</p>
      <span className="mt-auto flex items-center gap-1 pt-4 text-sm font-medium text-brand-600">
        Choose <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" aria-hidden />
      </span>
    </button>
  );
}

function ComposedSteps({ composition, compact }: { composition: FlowComposition; compact?: boolean }) {
  const nodes = Object.fromEntries(composition.nodes.map((node) => [node.node_key, node]));
  return (
    <ol className="relative space-y-2" aria-label="Drafted steps">
      {composition.steps.map((item, index) => {
        const node = nodes[item.node_key] as { approval_role?: string; condition_expression?: string } | undefined;
        const isBranch = item.branch === 'false';
        return (
          <li
            key={item.node_key}
            className={cn(
              'relative flex gap-3 rounded-lg border bg-surface p-3',
              isBranch ? 'ml-8 border-dashed border-warning-border bg-warning-bg/40' : 'border-line',
            )}
          >
            <span
              className={cn(
                'flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold',
                item.node_type === 'agent' && 'bg-brand-50 text-brand-700',
                item.node_type === 'approval' && 'bg-warning-bg text-warning-text',
                item.node_type === 'condition' && 'bg-surface-sunken text-ink-secondary',
              )}
              aria-hidden
            >
              {isBranch ? <StepIcon type="approval" /> : <StepIcon type={item.node_type} />}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <p className="text-sm font-medium text-ink">
                  {isBranch ? 'If not met: ' : `${index + 1}. `}
                  {item.label}
                </p>
                {item.risk_level ? <Badge tone={TONE_BY_RISK[item.risk_level] ?? 'neutral'}>{item.risk_level} risk</Badge> : null}
                {node?.approval_role ? <Badge tone="warning">{ROLE_LABELS[node.approval_role] ?? node.approval_role}</Badge> : null}
              </div>
              {!compact ? <p className="mt-0.5 text-xs text-ink-secondary">{item.reason}</p> : null}
              {node?.condition_expression && !compact ? (
                <code className="mt-1 inline-block rounded bg-surface-sunken px-1.5 py-0.5 font-mono text-2xs text-ink-secondary">
                  {node.condition_expression}
                </code>
              ) : null}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function SummaryStat({ icon, label, value }: { icon: ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-lg border border-line bg-surface-muted px-2 py-2">
      <p className="flex items-center justify-center gap-1 text-2xs text-ink-tertiary">
        <span aria-hidden>{icon}</span>
        {label}
      </p>
      <p className="text-xl font-semibold text-ink tabular">{value}</p>
    </div>
  );
}

function ValidationNote({ valid, errors }: { valid: boolean; errors: { message: string }[] }) {
  if (valid) {
    return (
      <p className="flex items-center gap-1.5 text-xs font-medium text-success-text">
        <CheckCircle2 className="h-3.5 w-3.5" aria-hidden /> The graph validates and is ready to run
      </p>
    );
  }
  return (
    <div className="text-xs text-danger-text">
      <p className="flex items-center gap-1.5 font-medium">
        <AlertTriangle className="h-3.5 w-3.5" aria-hidden /> Needs attention before it can run
      </p>
      <ul className="ml-5 list-disc">
        {errors.map((error) => (
          <li key={error.message}>{error.message}</li>
        ))}
      </ul>
    </div>
  );
}

function VariablesCard({
  variables,
  onChange,
}: {
  variables: Record<string, unknown>;
  onChange: (variables: Record<string, unknown>) => void;
}) {
  const keys = Object.keys(variables);
  if (!keys.length) return null;
  return (
    <Card>
      <CardHeader title="Run inputs" description="Defaults for every run; each run can override them." />
      <CardBody className="space-y-3">
        {keys.map((key) => (
          <Field key={key} label={key.replace(/_/g, ' ')} htmlFor={`var-${key}`}>
            <Input
              id={`var-${key}`}
              value={toInputValue(variables[key])}
              onChange={(event) => onChange({ ...variables, [key]: fromInputValue(event.target.value, variables[key]) })}
            />
          </Field>
        ))}
      </CardBody>
    </Card>
  );
}

function TemplatePreview({
  template,
  variables,
  onVariables,
}: {
  template: FlowTemplate;
  variables: Record<string, unknown>;
  onVariables: (variables: Record<string, unknown>) => void;
}) {
  return (
    <div className="space-y-4 lg:sticky lg:top-20">
      <Card>
        <CardBody>
          <div className="flex items-start gap-3">
            <TemplateGlyph icon={template.icon} />
            <div>
              <p className="text-md font-semibold text-ink">{template.name}</p>
              <p className="text-sm text-brand-700">{template.outcome}</p>
            </div>
          </div>
          <p className="mt-3 text-sm text-ink-secondary">{template.description}</p>
          <ol className="mt-4 space-y-2 border-l border-line pl-4">
            {template.steps.map((item, index) => (
              <li key={index} className="relative">
                <span className="absolute -left-[22px] top-1 flex h-3 w-3 items-center justify-center rounded-full border-2 border-surface bg-brand-500" aria-hidden />
                <p className="flex items-center gap-1.5 text-sm text-ink">
                  <StepIcon type={item.requires_approval ? 'approval' : item.node_type} className="text-ink-tertiary" />
                  {item.label}
                  {item.risk_level === 'high' ? <Badge tone="danger">high risk</Badge> : null}
                </p>
                {item.agent_name && item.agent_name !== item.label ? (
                  <p className="text-2xs text-ink-tertiary">{item.agent_name}</p>
                ) : null}
              </li>
            ))}
          </ol>
          <dl className="mt-4 grid grid-cols-3 gap-2 border-t border-line pt-3 text-center">
            <div>
              <dt className="text-2xs text-ink-tertiary">Agents</dt>
              <dd className="font-semibold text-ink">{template.agent_count}</dd>
            </div>
            <div>
              <dt className="text-2xs text-ink-tertiary">Gates</dt>
              <dd className="font-semibold text-ink">{template.approval_gates}</dd>
            </div>
            <div>
              <dt className="text-2xs text-ink-tertiary">Est. / run</dt>
              <dd className="font-semibold text-ink">{formatCurrency(template.estimated_cost_per_run_usd)}</dd>
            </div>
          </dl>
        </CardBody>
      </Card>
      <VariablesCard variables={variables} onChange={onVariables} />
    </div>
  );
}

function ReviewItem({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-medium uppercase tracking-wide text-ink-tertiary">{label}</dt>
      <dd className="mt-1 text-sm text-ink">{children}</dd>
    </div>
  );
}
