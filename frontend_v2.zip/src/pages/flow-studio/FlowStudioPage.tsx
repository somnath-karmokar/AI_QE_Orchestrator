/** Flow Studio: every flow as its own product, plus the fastest ways to create a new one. */
import { useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  ArrowRight,
  BadgeEuro,
  CalendarClock,
  Clock,
  Gauge,
  LayoutTemplate,
  Play,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Timer,
  Webhook,
  Workflow,
} from 'lucide-react';
import { api } from '@/services/api';
import { formatCurrency, formatDuration, formatPercent, formatRelativeTime, useProjectId } from '@/hooks';
import { useSession } from '@/store';
import {
  Badge,
  Button,
  Card,
  cn,
  EmptyState,
  ErrorState,
  humanize,
  Input,
  LoadingBlock,
  statusTone,
  Textarea,
} from '@/design-system/primitives';
import { OwnerChip, RunFlowDialog, StepChain, TemplateGlyph, TriggerBadges } from '@/features/flow-studio/components';
import type { FlowCardSummary, FlowTemplate } from '@/types';

const EXAMPLES = [
  'Check PAY-201 is ready for testing; if it scores below 80 get business sign-off; then generate scenarios, test cases and test data',
  'Every night pick the regression tests Payments needs, run them and analyse the failures',
  'Find the root cause of failed tests and raise defects after QE lead approval',
];

type Filter = 'all' | 'scheduled' | 'api' | 'attention';

export default function FlowStudioPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const can = useSession((state) => state.can);
  const [description, setDescription] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [search, setSearch] = useState('');
  const [runTarget, setRunTarget] = useState<FlowCardSummary | null>(null);

  const overview = useQuery({
    queryKey: ['flow-overview', projectId],
    queryFn: () => api.flowOverview(projectId!),
    enabled: Boolean(projectId),
    refetchInterval: 20000,
  });
  const templates = useQuery({
    queryKey: ['flow-templates', projectId],
    queryFn: () => api.flowTemplates(projectId!),
    enabled: Boolean(projectId),
    staleTime: 5 * 60 * 1000,
  });
  const runTargetFlow = useQuery({
    queryKey: ['flow', runTarget?.id],
    queryFn: () => api.getFlow(runTarget!.id),
    enabled: Boolean(runTarget),
  });

  const flows = useMemo(() => {
    const items = overview.data?.flows ?? [];
    const term = search.trim().toLowerCase();
    return items.filter((flow) => {
      if (term && !`${flow.name} ${flow.description ?? ''} ${flow.owner ?? ''}`.toLowerCase().includes(term)) return false;
      if (filter === 'scheduled') return flow.schedule?.enabled;
      if (filter === 'api') return flow.api_trigger_enabled;
      if (filter === 'attention')
        return flow.pending_approvals > 0 || flow.last_status === 'failed' || flow.status !== 'published' || !flow.validation_valid;
      return true;
    });
  }, [overview.data, filter, search]);

  const canWrite = can('flow:write');
  const totals = overview.data?.totals;

  const startDescribe = (text: string) => {
    const params = new URLSearchParams({ mode: 'describe' });
    if (text.trim()) params.set('text', text.trim());
    navigate(`/flows/new?${params.toString()}`);
  };

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section
        className="relative overflow-hidden rounded-xl border border-navy-800 bg-navy-700 px-6 py-7 text-white lg:px-8"
        aria-labelledby="studio-title"
      >
        <div
          className="pointer-events-none absolute -right-24 -top-32 h-80 w-80 rounded-full bg-brand-400/20 blur-3xl"
          aria-hidden
        />
        <div className="relative grid gap-8 lg:grid-cols-[1.2fr_1fr] lg:items-center">
          <div>
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-navy-200">
              <Workflow className="h-3.5 w-3.5" aria-hidden /> Flow Studio
            </p>
            <h1 id="studio-title" className="mt-2 text-4xl font-semibold tracking-[-0.02em] text-white">
              Agentic QE flows that run themselves
            </h1>
            <p className="mt-2 max-w-xl text-md text-navy-100">
              Describe a flow or start from a proven template. Each flow gets its own dashboard, observability,
              governance and report, and can run on a schedule or from your pipeline.
            </p>
            {canWrite ? (
              <div className="mt-5 flex flex-wrap gap-2">
                <Link
                  to="/flows/new"
                  className="inline-flex h-10 items-center gap-2 rounded bg-white px-4 text-sm font-semibold text-navy-800 transition-colors hover:bg-navy-50"
                >
                  <Plus className="h-4 w-4" aria-hidden /> Create a flow
                </Link>
                <Link
                  to="/flows/new?mode=template"
                  className="inline-flex h-10 items-center gap-2 rounded border border-white/25 px-4 text-sm font-medium text-white transition-colors hover:bg-white/10"
                >
                  <LayoutTemplate className="h-4 w-4" aria-hidden /> Browse templates
                </Link>
              </div>
            ) : null}
          </div>
          <dl className="grid grid-cols-2 gap-3" aria-label={`Last ${overview.data?.window_days ?? 30} days`}>
            <HeroStat
              icon={<Workflow className="h-4 w-4" />}
              label="Live flows"
              value={totals ? `${totals.published}` : '—'}
              note={totals ? `${totals.scheduled} scheduled · ${totals.api_enabled} API` : undefined}
            />
            <HeroStat
              icon={<Gauge className="h-4 w-4" />}
              label="Success rate · 30d"
              value={totals ? formatPercent(totals.success_rate, 0) : '—'}
              note={totals ? `${totals.runs} runs` : undefined}
            />
            <HeroStat
              icon={<Timer className="h-4 w-4" />}
              label="Effort saved · 30d"
              value={totals ? `${Math.round(totals.hours_saved)} h` : '—'}
              note="Estimated from completed agent steps"
            />
            <HeroStat
              icon={<BadgeEuro className="h-4 w-4" />}
              label="AI spend · 30d"
              value={totals ? formatCurrency(totals.total_cost_usd) : '—'}
              note={
                totals?.pending_approvals
                  ? `${totals.pending_approvals} approval${totals.pending_approvals === 1 ? '' : 's'} waiting`
                  : 'Within budgets'
              }
            />
          </dl>
        </div>
      </section>

      {/* Describe */}
      {canWrite ? (
        <Card className="overflow-hidden">
          <div className="grid gap-0 lg:grid-cols-[1fr_320px]">
            <form
              className="p-5"
              onSubmit={(event) => {
                event.preventDefault();
                startDescribe(description);
              }}
            >
              <label htmlFor="describe-flow" className="flex items-center gap-2 text-md font-semibold text-ink">
                <Sparkles className="h-4 w-4 text-brand-500" aria-hidden /> Describe the flow you need
              </label>
              <p className="mt-0.5 text-sm text-ink-secondary">
                Plain English is enough. The studio picks the agents, adds decisions and approval gates, and shows
                why it chose each step before anything is saved.
              </p>
              <Textarea
                id="describe-flow"
                rows={3}
                className="mt-3 resize-none"
                placeholder="e.g. Check the story is ready; if it scores below 80 get business sign-off; then generate scenarios and test data"
                value={description}
                onChange={(event) => setDescription(event.target.value)}
              />
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5">
                  {EXAMPLES.map((example) => (
                    <button
                      key={example}
                      type="button"
                      onClick={() => setDescription(example)}
                      className="max-w-[260px] truncate rounded-full border border-line bg-surface-muted px-2.5 py-1 text-2xs text-ink-secondary transition-colors hover:border-brand-200 hover:text-brand-700"
                      title={example}
                    >
                      {example}
                    </button>
                  ))}
                </div>
                <Button type="submit" variant="primary" icon={<Sparkles className="h-3.5 w-3.5" />} disabled={description.trim().length < 8}>
                  Draft my flow
                </Button>
              </div>
            </form>
            <div className="border-t border-line bg-surface-muted p-5 lg:border-l lg:border-t-0">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Every flow comes with</p>
              <ul className="mt-3 space-y-2.5 text-sm text-ink">
                {[
                  [Gauge, 'Its own dashboard and shareable report'],
                  [Clock, 'Observability: latency, models, failures'],
                  [ShieldCheck, 'Governance: owner, gates, budget, audit'],
                  [CalendarClock, 'Schedule and API triggers'],
                ].map(([Icon, text]) => {
                  const IconComponent = Icon as typeof Gauge;
                  return (
                    <li key={text as string} className="flex items-center gap-2.5">
                      <span className="flex h-6 w-6 items-center justify-center rounded bg-brand-50 text-brand-600">
                        <IconComponent className="h-3.5 w-3.5" aria-hidden />
                      </span>
                      {text as string}
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </Card>
      ) : null}

      {/* Flows */}
      <section aria-labelledby="flows-title">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 id="flows-title" className="text-xl font-semibold text-ink">
              Your flows
            </h2>
            <p className="text-sm text-ink-secondary">Open a flow for its dashboard, runs, observability, governance and report.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div role="group" aria-label="Filter flows" className="inline-flex rounded border border-line bg-surface p-0.5">
              {(
                [
                  ['all', 'All'],
                  ['scheduled', 'Scheduled'],
                  ['api', 'API'],
                  ['attention', 'Needs attention'],
                ] as [Filter, string][]
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  aria-pressed={filter === key}
                  onClick={() => setFilter(key)}
                  className={cn(
                    'h-7 rounded px-2.5 text-xs font-medium transition-colors',
                    filter === key ? 'bg-navy-700 text-white' : 'text-ink-secondary hover:bg-surface-sunken',
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-ink-tertiary" aria-hidden />
              <Input
                aria-label="Search flows"
                placeholder="Search flows"
                className="w-56 pl-8"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </div>
          </div>
        </div>

        {overview.isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, index) => (
              <Card key={index}>
                <LoadingBlock rows={4} />
              </Card>
            ))}
          </div>
        ) : overview.error ? (
          <ErrorState message={(overview.error as Error).message} onRetry={() => void overview.refetch()} />
        ) : flows.length === 0 ? (
          <Card>
            <EmptyState
              icon={<Workflow className="h-5 w-5" />}
              title={overview.data?.flows.length ? 'No flows match' : 'No flows yet'}
              description={
                overview.data?.flows.length
                  ? 'Try another filter or search term.'
                  : 'Describe a flow or start from a template to create your first one.'
              }
            />
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
            {flows.map((flow) => (
              <FlowCard key={flow.id} flow={flow} onRun={can('flow:run') ? () => setRunTarget(flow) : undefined} />
            ))}
          </div>
        )}
      </section>

      {/* Templates */}
      {canWrite ? (
        <section aria-labelledby="templates-title">
          <div className="mb-3 flex items-end justify-between gap-3">
            <div>
              <h2 id="templates-title" className="text-xl font-semibold text-ink">
                Start from a proven template
              </h2>
              <p className="text-sm text-ink-secondary">Governance gates, inputs and budgets are already in place.</p>
            </div>
            <Link to="/flows/new?mode=template" className="inline-flex items-center gap-1 text-sm font-medium text-brand-600 hover:text-brand-700">
              All templates <ArrowRight className="h-3.5 w-3.5" aria-hidden />
            </Link>
          </div>
          {templates.isLoading ? (
            <LoadingBlock rows={3} />
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {(templates.data ?? []).slice(0, 4).map((template) => (
                <TemplateCard key={template.key} template={template} />
              ))}
            </div>
          )}
        </section>
      ) : null}

      {runTarget && runTargetFlow.data ? (
        <RunFlowDialog
          open
          onClose={() => setRunTarget(null)}
          flowId={runTarget.id}
          flowName={runTarget.name}
          variables={runTargetFlow.data.variables}
        />
      ) : null}
    </div>
  );
}

function HeroStat({ icon, label, value, note }: { icon: ReactNode; label: string; value: string; note?: string }) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/[0.06] p-4">
      <dt className="flex items-center gap-1.5 text-2xs font-medium uppercase tracking-wide text-navy-200">
        <span aria-hidden>{icon}</span>
        {label}
      </dt>
      <dd className="mt-1.5 text-3xl font-semibold tracking-[-0.02em] text-white tabular">{value}</dd>
      {note ? <dd className="mt-0.5 text-2xs text-navy-200">{note}</dd> : null}
    </div>
  );
}

function ActivityBars({ values, label }: { values: number[]; label: string }) {
  const max = Math.max(...values, 1);
  return (
    <div className="flex h-8 items-end gap-[2px]" role="img" aria-label={label}>
      {values.map((value, index) => (
        <span
          key={index}
          className={cn('w-full rounded-t-[2px]', value ? 'bg-brand-500' : 'bg-surface-sunken')}
          style={{ height: `${value ? Math.max(18, (value / max) * 100) : 12}%` }}
        />
      ))}
    </div>
  );
}

function FlowCard({ flow, onRun }: { flow: FlowCardSummary; onRun?: () => void }) {
  const navigate = useNavigate();
  const lastRunsText = flow.activity.reduce((sum, value) => sum + value, 0);
  return (
    <Card className="group flex flex-col transition-shadow hover:shadow-raised">
      <div className="flex-1 p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <Link to={`/flows/${flow.id}`} className="text-md font-semibold text-ink hover:text-brand-600">
              {flow.name}
            </Link>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              <Badge tone={statusTone(flow.status)}>{humanize(flow.status)}</Badge>
              <Badge tone="neutral">v{flow.version}</Badge>
              {flow.pending_approvals ? <Badge tone="warning">{flow.pending_approvals} awaiting approval</Badge> : null}
              {!flow.validation_valid ? <Badge tone="danger">Invalid</Badge> : null}
            </div>
          </div>
          <OwnerChip email={flow.owner} className="shrink-0" />
        </div>
        {flow.description ? <p className="mt-2 line-clamp-2 text-sm text-ink-secondary">{flow.description}</p> : null}

        <TriggerBadges
          className="mt-3"
          schedule={flow.schedule}
          scheduleDescription={flow.schedule_description}
          apiEnabled={flow.api_trigger_enabled}
        />

        <dl className="mt-4 grid grid-cols-4 gap-2 border-t border-line-subtle pt-3">
          <CardMetric label="Runs · 30d" value={String(flow.runs)} />
          <CardMetric label="Success" value={formatPercent(flow.success_rate, 0)} />
          <CardMetric label="Avg cost" value={formatCurrency(flow.avg_cost_usd)} />
          <CardMetric label="Typical" value={flow.p50_duration_ms ? formatDuration(flow.p50_duration_ms) : '—'} />
        </dl>

        <div className="mt-3">
          <ActivityBars values={flow.activity} label={`${lastRunsText} runs in the last 14 days`} />
          <p className="mt-1 text-2xs text-ink-tertiary">Runs per day · last 14 days</p>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2 border-t border-line px-5 py-2.5">
        <p className="flex items-center gap-1.5 text-xs text-ink-secondary">
          {flow.last_status ? (
            <>
              <Badge tone={statusTone(flow.last_status)} dot>
                {humanize(flow.last_status)}
              </Badge>
              {formatRelativeTime(flow.last_run_at)}
            </>
          ) : (
            'Not run yet'
          )}
          {flow.api_trigger_enabled ? <Webhook className="ml-1 h-3 w-3 text-ink-tertiary" aria-label="API trigger on" /> : null}
        </p>
        <div className="flex items-center gap-1.5">
          {onRun ? (
            <Button size="sm" variant="ghost" icon={<Play className="h-3.5 w-3.5" />} onClick={onRun} aria-label={`Run ${flow.name}`}>
              Run
            </Button>
          ) : null}
          <Button size="sm" variant="secondary" onClick={() => navigate(`/flows/${flow.id}`)}>
            Open
          </Button>
        </div>
      </div>
    </Card>
  );
}

function CardMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="truncate text-2xs text-ink-tertiary">{label}</dt>
      <dd className="text-sm font-semibold text-ink tabular">{value}</dd>
    </div>
  );
}

export function TemplateCard({
  template,
  selected,
  onSelect,
}: {
  template: FlowTemplate;
  selected?: boolean;
  onSelect?: () => void;
}) {
  const navigate = useNavigate();
  const choose = onSelect ?? (() => navigate(`/flows/new?mode=template&template=${template.key}`));
  return (
    <button
      type="button"
      onClick={choose}
      aria-pressed={selected}
      className={cn(
        'flex h-full flex-col rounded-lg border bg-surface p-4 text-left shadow-card transition-all hover:border-brand-300 hover:shadow-raised',
        selected ? 'border-brand-500 ring-2 ring-brand-100' : 'border-line',
      )}
    >
      <div className="flex items-start gap-3">
        <TemplateGlyph icon={template.icon} />
        <div className="min-w-0">
          <p className="text-sm font-semibold text-ink">{template.name}</p>
          <p className="text-xs text-brand-700">{template.outcome}</p>
        </div>
      </div>
      <p className="mt-2 line-clamp-2 text-xs text-ink-secondary">{template.description}</p>
      <StepChain className="mt-3" steps={template.steps} max={4} />
      <div className="mt-auto flex flex-wrap gap-x-3 gap-y-1 pt-3 text-2xs text-ink-tertiary">
        <span>{template.agent_count} agents</span>
        <span>{template.approval_gates} approval gate{template.approval_gates === 1 ? '' : 's'}</span>
        <span>≈ {formatCurrency(template.estimated_cost_per_run_usd)} / run</span>
      </div>
    </button>
  );
}
