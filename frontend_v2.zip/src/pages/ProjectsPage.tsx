/** Project list and configuration overview (spec §19). */
import { useQuery } from '@tanstack/react-query';
import { Check, GitBranch, Globe, Server } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatCurrency } from '@/hooks';
import { useWorkspace } from '@/store';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, KeyValue, LoadingBlock,
  PageHeader, statusTone,
} from '@/design-system/primitives';

export default function ProjectsPage() {
  const projectId = useProjectId();
  const setProject = useWorkspace((state) => state.setProject);

  const { data: projects, isLoading } = useQuery({ queryKey: ['projects'], queryFn: api.listProjects });
  const { data: detail } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => api.getProject(projectId!),
    enabled: Boolean(projectId),
  });

  if (isLoading) return <LoadingBlock rows={6} />;

  return (
    <div>
      <PageHeader
        title="Projects"
        description="Each project is an isolated workspace: its own requirements, agents, knowledge, executions and governance."
      />

      <div className="mb-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {projects?.items.map((project) => {
          const active = project.id === projectId;
          return (
            <Card key={project.id} className={cn(active && 'border-brand-300 ring-1 ring-brand-200')}>
              <CardBody className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="flex items-center gap-2">
                      <code className="font-mono text-xs font-semibold text-brand-600">{project.key}</code>
                      <Badge tone={statusTone(project.status)}>{project.status}</Badge>
                    </p>
                    <h3 className="mt-1 truncate text-md font-semibold text-ink">{project.name}</h3>
                  </div>
                  {active ? (
                    <Badge tone="brand">
                      <Check className="h-3 w-3" /> Active
                    </Badge>
                  ) : null}
                </div>

                <p className="mt-2 line-clamp-2 text-sm text-ink-secondary">{project.description}</p>

                {project.modules?.length ? (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {project.modules.slice(0, 5).map((module) => (
                      <span key={module} className="rounded border border-line bg-surface-muted px-1.5 py-0.5 text-2xs text-ink-secondary">
                        {module}
                      </span>
                    ))}
                    {project.modules.length > 5 ? (
                      <span className="text-2xs text-ink-tertiary">+{project.modules.length - 5}</span>
                    ) : null}
                  </div>
                ) : null}

                {!active ? (
                  <Button variant="secondary" size="sm" className="mt-4 w-full" onClick={() => setProject(project)}>
                    Switch to this project
                  </Button>
                ) : null}
              </CardBody>
            </Card>
          );
        })}
      </div>

      {detail ? (
        <div className="grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader title="Configuration" description="What makes this project specific" />
            <CardBody>
              <dl className="divide-y divide-line">
                <KeyValue label="Business domain">{detail.business_domain ?? '—'}</KeyValue>
                <KeyValue label="Application URL">
                  {detail.application_url ? (
                    <span className="flex items-center gap-1.5 font-mono text-xs">
                      <Globe className="h-3 w-3 text-ink-tertiary" />
                      {detail.application_url}
                    </span>
                  ) : '—'}
                </KeyValue>
                <KeyValue label="Jira project">{detail.jira_project_key ?? '—'}</KeyValue>
                <KeyValue label="Confluence space">{detail.confluence_space ?? '—'}</KeyValue>
                <KeyValue label="Git repository">
                  {detail.git_repository ? (
                    <span className="flex items-center gap-1.5 font-mono text-xs">
                      <GitBranch className="h-3 w-3 text-ink-tertiary" />
                      {detail.git_repository}
                    </span>
                  ) : '—'}
                </KeyValue>
                <KeyValue label="AI cost budget">{formatCurrency(detail.cost_budget_usd)}</KeyValue>
              </dl>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="QE policies" description="Thresholds agents and flows enforce" />
            <CardBody>
              <dl className="divide-y divide-line">
                {Object.entries(detail.qe_policies ?? {}).map(([key, value]) => (
                  <KeyValue key={key} label={key.replace(/_/g, ' ')}>
                    {typeof value === 'boolean' ? (value ? 'Yes' : 'No') : String(value)}
                  </KeyValue>
                ))}
              </dl>
            </CardBody>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader title="Environments" description="Where tests run, and what agents may do there" icon={<Server className="h-4 w-4" />} />
            <CardBody className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[760px] text-sm">
                  <thead>
                    <tr className="border-b border-line bg-surface-muted text-left">
                      {['Environment', 'Base URL', 'Type', 'Agent writes', 'Health'].map((header) => (
                        <th key={header} scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {detail.environments.map((environment) => (
                      <tr key={environment.id} className="data-grid-row">
                        <td className="px-5 py-3">
                          <p className="font-medium text-ink">{environment.name}</p>
                          <p className="text-xs text-ink-tertiary">{environment.description}</p>
                        </td>
                        <td className="px-5 py-3 font-mono text-xs text-ink-secondary">{environment.base_url}</td>
                        <td className="px-5 py-3">
                          <Badge tone={environment.is_production_like ? 'warning' : 'neutral'}>
                            {environment.is_production_like ? 'Production-like' : 'Non-production'}
                          </Badge>
                        </td>
                        <td className="px-5 py-3">
                          {environment.allows_write_actions ? (
                            <Badge tone="success">Permitted</Badge>
                          ) : (
                            <Badge tone="danger">Blocked by policy</Badge>
                          )}
                        </td>
                        <td className="px-5 py-3">
                          <Badge tone={statusTone(environment.health_status)}>{environment.health_status}</Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>
        </div>
      ) : null}
    </div>
  );
}
