/**
 * Healing Control Centre.
 *
 * Every figure here is counted from records the platform wrote — nothing is
 * modelled. That matters more here than elsewhere: a self-healing platform
 * reporting its own success rate has an obvious incentive to flatter itself, so
 * the page shows what each number is made of rather than only the number.
 */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Activity, AlertTriangle, CheckCircle2, Clock, Wrench } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatPercent } from '@/hooks';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, PageHeader, Select,
} from '@/design-system/primitives';
import { ChartCard, MetricTile, MiniTable, RankedBars, TrendLine } from '@/features/flow-studio/charts';
import type { HealingAnalytics } from '@/types';

const WINDOWS = [7, 30, 90];

export default function HealingPage() {
  const projectId = useProjectId();
  const [days, setDays] = useState(30);

  const { data, isLoading } = useQuery({
    queryKey: ['healing-analytics', projectId, days],
    queryFn: () => api.healingAnalytics(projectId!, days),
    enabled: Boolean(projectId),
  });

  if (isLoading || !data) {
    return (
      <div className="p-6">
        <PageHeader title="Healing Control Centre" description="Loading…" />
      </div>
    );
  }

  const { totals, effort, confidence, validation, queue } = data;
  const predictive = confidence.separation !== null && confidence.separation > 0.02;

  return (
    <div className="p-6">
      <PageHeader
        title="Healing Control Centre"
        description="Counted from healing records. A repair counts as successful only once a re-run has proved it."
        actions={
          <Select
            aria-label="Window"
            className="w-44"
            value={String(days)}
            onChange={(event) => setDays(Number(event.target.value))}
          >
            {WINDOWS.map((option) => (
              <option key={option} value={option}>
                Last {option} days
              </option>
            ))}
          </Select>
        }
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricTile
          label="Repairs that held"
          value={totals.proven}
          icon={<CheckCircle2 className="h-4 w-4" />}
          hint={`of ${totals.decided} decided`}
        />
        <MetricTile
          label="Success rate"
          value={formatPercent(totals.success_rate, 0)}
          icon={<Activity className="h-4 w-4" />}
          hint={totals.success_rate_basis}
        />
        <MetricTile
          label="Awaiting a person"
          value={queue.awaiting_decision}
          icon={<Clock className="h-4 w-4" />}
          hint={queue.oldest_hours ? `oldest ${queue.oldest_hours}h` : 'nothing waiting'}
        />
        <MetricTile
          label="Effort saved"
          value={`${effort.hours_saved}h`}
          icon={<Wrench className="h-4 w-4" />}
          hint={`${effort.repairs_that_held} × ${effort.minutes_per_repair} min`}
        />
      </div>

      {/* The number most likely to be misread, so it is stated rather than implied. */}
      {totals.unproven_applied > 0 ? (
        <Card className="mb-5">
          <CardBody className="flex items-start gap-3 text-sm">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning-text" />
            <p className="text-ink-secondary">
              <span className="font-medium text-ink">{totals.unproven_applied} applied repair(s) are unproven.</span>{' '}
              They were applied before a re-run was required, so nothing demonstrated they worked. They are
              excluded from the success rate and from effort saved.
            </p>
          </CardBody>
        </Card>
      ) : null}

      <div className="mb-5 grid gap-4 lg:grid-cols-2">
        <ChartCard
          title="Repairs over time"
          description={`Proposed against those that held, ${data.window.label}`}
          table={
            <MiniTable
              caption="Repairs per day"
              columns={[
                { header: 'Date', render: (row: (typeof data.trend)[number]) => row.date },
                { header: 'Proposed', numeric: true, render: (row) => row.proposed },
                { header: 'Held', numeric: true, render: (row) => row.proven },
                { header: 'Rolled back', numeric: true, render: (row) => row.rolled_back },
              ]}
              rows={data.trend}
            />
          }
        >
          <TrendLine
            data={data.trend}
            dataKey="proven"
            name="Repairs that held"
            format={(value) => String(value)}
          />
        </ChartCard>

        <ChartCard
          title="Which rung did the work"
          description="The strategy that produced each repair, and how often it held"
          table={
            <MiniTable
              caption="Repairs by strategy"
              columns={[
                { header: 'Strategy', render: (row: (typeof data.by_strategy)[number]) => row.strategy },
                { header: 'Proposed', numeric: true, render: (row) => row.proposed },
                { header: 'Held', numeric: true, render: (row) => row.proven },
                { header: 'Success', numeric: true, render: (row) => formatPercent(row.success_rate, 0) },
              ]}
              rows={data.by_strategy}
            />
          }
        >
          <RankedBars
            label="Repairs by strategy"
            rows={data.by_strategy.map((row) => ({
              label: row.strategy.replace(/_/g, ' '),
              value: row.proposed,
              secondary: `${formatPercent(row.success_rate, 0)} held`,
            }))}
            format={(value) => String(value)}
          />
        </ChartCard>
      </div>

      <div className="mb-5 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Does confidence predict anything?"
            description="If repairs that held and repairs that did not score alike, the number is decoration"
          />
          <CardBody>
            {confidence.separation === null ? (
              <p className="text-sm text-ink-secondary">
                Not enough decided repairs yet to say.
              </p>
            ) : (
              <>
                <p className="flex flex-wrap items-center gap-2 text-sm">
                  <Badge tone={predictive ? 'success' : 'warning'}>
                    {predictive ? 'Predictive' : 'Not predictive'}
                  </Badge>
                  <span className="text-ink-secondary">
                    {formatPercent(confidence.mean_when_proven ?? 0, 0)} mean when held,{' '}
                    {formatPercent(confidence.mean_when_failed ?? 0, 0)} when not
                  </span>
                </p>
                <p className="mt-2 text-xs text-ink-tertiary">
                  Separation {confidence.separation > 0 ? '+' : ''}
                  {confidence.separation.toFixed(3)} across {confidence.sample_proven} held and{' '}
                  {confidence.sample_failed} failed. {confidence.note}
                </p>
              </>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="What proved it"
            description="A simulated re-run exercises the lifecycle; it is not evidence about a real browser"
          />
          <CardBody className="space-y-2 text-sm">
            {Object.entries(validation.by_mode).length ? (
              Object.entries(validation.by_mode).map(([mode, count]) => (
                <p key={mode} className="flex items-center justify-between">
                  <span className="text-ink-secondary">{mode}</span>
                  <span className="tabular font-medium text-ink">{count}</span>
                </p>
              ))
            ) : (
              <p className="text-ink-secondary">Nothing validated in this window.</p>
            )}
            <p className="pt-1 text-xs text-ink-tertiary">
              Mean attempts per repair: {validation.mean_attempts}.{' '}
              {data.evidence.real_browser_share !== null
                ? `${formatPercent(data.evidence.real_browser_share, 0)} of runs used a real browser.`
                : null}
            </p>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Most recent decisions"
          description="What changed, what proved it, and who decided"
        />
        <CardBody className="p-0">
          {data.recent.length ? (
            <ul className="divide-y divide-line-subtle">
              {data.recent.map((row) => (
                <li key={row.id} className="px-5 py-3">
                  <p className="flex flex-wrap items-center gap-2 text-xs">
                    <Badge tone={row.status === 'applied' ? 'success' : row.status === 'rolled_back' ? 'danger' : 'neutral'}>
                      {row.status.replace(/_/g, ' ')}
                    </Badge>
                    <Badge tone="brand">changes {row.change_type.replace(/_/g, ' ')}</Badge>
                    <span className="text-ink-tertiary">{row.strategy}</span>
                    <span className={cn('tabular font-medium', row.confidence >= 0.85 ? 'text-success-text' : 'text-warning-text')}>
                      {formatPercent(row.confidence, 0)}
                    </span>
                    {row.approver ? <span className="text-ink-tertiary">by {row.approver}</span> : null}
                  </p>
                  <p className="mt-1 font-mono text-xs text-ink-secondary">
                    {row.from} → {row.to}
                  </p>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState
              icon={<Wrench className="h-5 w-5" />}
              title="No healing activity"
              description="Locator, timing and data failures produce repairs here."
            />
          )}
        </CardBody>
      </Card>
    </div>
  );
}

export type { HealingAnalytics };
