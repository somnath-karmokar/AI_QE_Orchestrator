/** Interactive traceability matrix (spec §14): requirement → scenario → case → automation → defect. */
import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronRight, Network, Search, TriangleAlert } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatPercent } from '@/hooks';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, Input, LoadingBlock,
  PageHeader, ProgressBar, Select, TONE_BY_SEVERITY,
} from '@/design-system/primitives';
import type { TraceabilityRow } from '@/types';

export default function TraceabilityPage() {
  const projectId = useProjectId();
  const [module, setModule] = useState('');
  const [search, setSearch] = useState('');
  const [onlyUncovered, setOnlyUncovered] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['traceability', projectId, module],
    queryFn: () => api.traceability(projectId!, module || undefined),
    enabled: Boolean(projectId),
  });

  const { data: coverage } = useQuery({
    queryKey: ['coverage', projectId],
    queryFn: () => api.coverage(projectId!),
    enabled: Boolean(projectId),
  });

  const rows = useMemo(() => {
    let result = data?.rows ?? [];
    if (onlyUncovered) result = result.filter((row) => row.status === 'uncovered');
    if (search.trim()) {
      const term = search.trim().toLowerCase();
      result = result.filter(
        (row) =>
          row.requirement.key.toLowerCase().includes(term) ||
          row.requirement.title.toLowerCase().includes(term),
      );
    }
    return result;
  }, [data, onlyUncovered, search]);

  if (isLoading) return <LoadingBlock rows={8} />;

  const summary = data?.summary;

  return (
    <div>
      <PageHeader
        title="Traceability Matrix"
        description="Follow every requirement through its scenarios, test cases, automation and defects. Broken chains are where risk hides."
      />

      {coverage ? (
        <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
          {(
            [
              ['Requirement', 'requirement_coverage'],
              ['Scenario', 'scenario_coverage'],
              ['Automation', 'automation_coverage'],
              ['Execution', 'execution_coverage'],
              ['Defect', 'defect_coverage'],
              ['Risk-weighted', 'risk_coverage'],
            ] as const
          ).map(([label, key]) => {
            const value = Number(coverage[key] ?? 0);
            return (
              <Card key={key}>
                <CardBody className="p-4">
                  <p className="text-xs font-medium text-ink-secondary">{label} coverage</p>
                  <p className="tabular mt-1 text-xl font-semibold text-ink">{formatPercent(value, 0)}</p>
                  <ProgressBar
                    value={value}
                    tone={value > 0.8 ? 'success' : value > 0.5 ? 'warning' : 'danger'}
                    className="mt-2"
                    label={`${label} coverage`}
                  />
                </CardBody>
              </Card>
            );
          })}
        </div>
      ) : null}

      {summary && summary.uncovered > 0 ? (
        <div role="alert" className="mb-5 flex items-start gap-3 rounded-lg border border-warning-border bg-warning-bg px-4 py-3">
          <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-warning-text" />
          <div>
            <p className="text-sm font-semibold text-warning-text">
              {summary.uncovered} requirement{summary.uncovered === 1 ? '' : 's'} without test coverage
            </p>
            <p className="mt-0.5 text-sm text-warning-text/90">
              {summary.uncovered_keys.slice(0, 8).join(', ')}
              {summary.uncovered_keys.length > 8 ? ` and ${summary.uncovered_keys.length - 8} more` : ''}
            </p>
          </div>
        </div>
      ) : null}

      <Card>
        <CardHeader
          title="Requirements"
          description={`${rows.length} of ${summary?.requirements ?? 0} shown`}
          actions={
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" aria-hidden />
                <Input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Filter requirements"
                  aria-label="Filter requirements"
                  className="h-8 w-48 pl-8 text-sm"
                />
              </div>
              <Select aria-label="Filter by module" className="h-8 w-40 text-sm" value={module} onChange={(event) => setModule(event.target.value)}>
                <option value="">All modules</option>
                {summary?.modules.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </Select>
              <label className="flex items-center gap-1.5 text-sm text-ink-secondary">
                <input
                  type="checkbox"
                  checked={onlyUncovered}
                  onChange={(event) => setOnlyUncovered(event.target.checked)}
                  className="h-3.5 w-3.5 rounded border-line-strong text-brand-500 focus:ring-brand-500"
                />
                Uncovered only
              </label>
            </div>
          }
        />
        <CardBody className="p-0">
          {rows.length ? (
            <ul className="divide-y divide-line-subtle">
              {rows.map((row) => (
                <MatrixRow
                  key={row.requirement.id}
                  row={row}
                  expanded={expanded === row.requirement.id}
                  onToggle={() => setExpanded(expanded === row.requirement.id ? null : row.requirement.id)}
                />
              ))}
            </ul>
          ) : (
            <EmptyState icon={<Network className="h-5 w-5" />} title="No requirements match" description="Adjust the filters above." />
          )}
        </CardBody>
      </Card>
    </div>
  );
}

function MatrixRow({ row, expanded, onToggle }: { row: TraceabilityRow; expanded: boolean; onToggle: () => void }) {
  const { requirement, counts } = row;
  const uncovered = row.status === 'uncovered';

  return (
    <li>
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        className="flex w-full items-center gap-4 px-5 py-3 text-left transition-colors hover:bg-surface-muted"
      >
        <ChevronRight className={cn('h-4 w-4 shrink-0 text-ink-tertiary transition-transform', expanded && 'rotate-90')} />

        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <code className="font-mono text-xs font-semibold text-brand-600">{requirement.key}</code>
            <span className="truncate text-sm font-medium text-ink">{requirement.title}</span>
          </span>
          <span className="mt-0.5 flex flex-wrap items-center gap-2 text-2xs text-ink-tertiary">
            <span>{requirement.module}</span>
            <span>· {requirement.priority} priority</span>
            <span>· {requirement.acceptance_criteria_count} acceptance criteria</span>
            {requirement.risk_score > 0.7 ? <span className="text-danger-text">· high risk</span> : null}
          </span>
        </span>

        <span className="hidden shrink-0 items-center gap-2 sm:flex">
          <ChainStep label="Scenarios" count={counts.scenarios} />
          <ChainArrow />
          <ChainStep label="Cases" count={counts.test_cases} />
          <ChainArrow />
          <ChainStep label="Automated" count={counts.automated} />
          <ChainArrow />
          <ChainStep label="Executed" count={counts.executed} />
          <ChainArrow />
          <ChainStep label="Defects" count={counts.defects} tone={counts.defects > 0 ? 'danger' : undefined} />
        </span>

        <Badge tone={uncovered ? 'danger' : 'success'} className="shrink-0">
          {uncovered ? 'Uncovered' : 'Covered'}
        </Badge>
      </button>

      {expanded ? (
        <div className="space-y-3 border-t border-line-subtle bg-surface-muted px-5 py-4 pl-12">
          {row.scenarios.length ? (
            row.scenarios.map((scenario) => (
              <div key={scenario.id} className="rounded border border-line bg-surface p-3">
                <p className="flex flex-wrap items-center gap-2">
                  <code className="font-mono text-2xs text-ink-tertiary">{scenario.key}</code>
                  <span className="text-sm font-medium text-ink">{scenario.title}</span>
                  <Badge tone={scenario.type === 'negative' ? 'warning' : scenario.type === 'edge' ? 'info' : 'neutral'}>
                    {scenario.type}
                  </Badge>
                </p>

                {scenario.test_cases.length ? (
                  <ul className="mt-2 space-y-1.5 border-t border-line-subtle pt-2">
                    {scenario.test_cases.map((testCase) => (
                      <li key={testCase.id} className="flex flex-wrap items-center gap-2 text-xs">
                        <code className="font-mono text-ink-tertiary">{testCase.key}</code>
                        <span className="text-ink-secondary">{testCase.title}</span>
                        {testCase.is_automated ? (
                          <Badge tone="success">automated</Badge>
                        ) : (
                          <Badge tone="neutral">manual</Badge>
                        )}
                        {testCase.last_result ? (
                          <Badge tone={testCase.last_result === 'passed' ? 'success' : testCase.last_result === 'failed' ? 'danger' : 'warning'}>
                            {testCase.last_result}
                          </Badge>
                        ) : null}
                        {testCase.defects.map((defect) => (
                          <Badge key={defect.id} tone={TONE_BY_SEVERITY[defect.severity] ?? 'danger'}>
                            {defect.key ?? 'defect'}
                          </Badge>
                        ))}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-xs text-ink-tertiary">No test cases derived from this scenario yet.</p>
                )}
              </div>
            ))
          ) : (
            <p className="text-sm text-ink-secondary">
              No scenarios exist for this requirement. Run the Test Scenario Generator to close the gap.
            </p>
          )}
        </div>
      ) : null}
    </li>
  );
}

function ChainStep({ label, count, tone }: { label: string; count: number; tone?: 'danger' }) {
  return (
    <span className="text-center" title={`${count} ${label}`}>
      <span
        className={cn(
          'tabular block text-sm font-semibold',
          count === 0 ? 'text-ink-tertiary' : tone === 'danger' ? 'text-danger-text' : 'text-ink',
        )}
      >
        {count}
      </span>
      <span className="block text-[10px] uppercase tracking-wide text-ink-tertiary">{label}</span>
    </span>
  );
}

function ChainArrow() {
  return <ChevronRight className="h-3 w-3 shrink-0 text-line-strong" aria-hidden />;
}
