/** Regression optimisation (spec §15): what was selected, what was skipped, and why. */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Filter, TrendingDown } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatDuration, formatPercent } from '@/hooks';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, LoadingBlock,
  PageHeader, ProgressBar,
} from '@/design-system/primitives';

export default function RegressionPage() {
  const projectId = useProjectId();
  const [showSkipped, setShowSkipped] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['regression', projectId],
    queryFn: () => api.listRegression(projectId!),
    enabled: Boolean(projectId),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  const analysis = data?.items[0];

  if (!analysis) {
    return (
      <div>
        <PageHeader title="Regression Intelligence" description="Risk-based suite selection." />
        <Card>
          <EmptyState
            icon={<Filter className="h-5 w-5" />}
            title="No optimisation analysis yet"
            description="Run the Payment Regression Intelligence flow to produce one."
          />
        </Card>
      </div>
    );
  }

  const tests = (showSkipped ? analysis.skipped_tests : analysis.selected_tests) as Record<string, unknown>[];
  const savedMs = analysis.baseline_duration_ms - analysis.optimized_duration_ms;

  return (
    <div>
      <PageHeader
        title="Regression Intelligence"
        description="The suite the platform would run for this change, and the reasoning behind every inclusion and exclusion."
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardBody className="p-4">
            <p className="text-xs font-medium text-ink-secondary">Runtime reduction</p>
            <p className="tabular mt-1 text-2xl font-semibold text-success-text">
              {analysis.reduction_percent.toFixed(0)}%
            </p>
            <p className="mt-1 text-xs text-ink-tertiary">
              {formatDuration(savedMs)} saved per full run
            </p>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="p-4">
            <p className="text-xs font-medium text-ink-secondary">Tests selected</p>
            <p className="tabular mt-1 text-2xl font-semibold text-ink">
              {analysis.selected_tests.length}
              <span className="ml-1 text-base font-normal text-ink-tertiary">
                / {analysis.selected_tests.length + analysis.skipped_tests.length}
              </span>
            </p>
            <ProgressBar
              value={analysis.selected_tests.length / Math.max(1, analysis.selected_tests.length + analysis.skipped_tests.length)}
              className="mt-2"
              label="Selected proportion"
            />
          </CardBody>
        </Card>
        <Card>
          <CardBody className="p-4">
            <p className="text-xs font-medium text-ink-secondary">Average risk score</p>
            <p className="tabular mt-1 text-2xl font-semibold text-ink">{analysis.risk_score.toFixed(2)}</p>
            <p className="mt-1 text-xs text-ink-tertiary">across selected tests</p>
          </CardBody>
        </Card>
        <Card>
          <CardBody className="p-4">
            <p className="text-xs font-medium text-ink-secondary">Changed modules</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {analysis.changed_modules.map((module) => (
                <Badge key={module} tone="warning">{module}</Badge>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>

      {analysis.rationale ? (
        <Card className="mb-5 border-brand-100 bg-brand-50/50">
          <CardBody className="flex gap-3 py-4">
            <TrendingDown className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
            <div>
              <p className="text-sm font-semibold text-brand-800">Selection method</p>
              <p className="mt-1 text-sm text-ink">{analysis.rationale}</p>
            </div>
          </CardBody>
        </Card>
      ) : null}

      <Card>
        <CardHeader
          title={showSkipped ? 'Deferred tests' : 'Selected tests'}
          description={`${tests.length} test${tests.length === 1 ? '' : 's'}`}
          actions={
            <div className="flex gap-1 rounded border border-line p-0.5">
              {([
                [false, `Selected (${analysis.selected_tests.length})`],
                [true, `Deferred (${analysis.skipped_tests.length})`],
              ] as const).map(([value, label]) => (
                <button
                  key={String(value)}
                  onClick={() => setShowSkipped(value)}
                  aria-pressed={showSkipped === value}
                  className={cn(
                    'rounded px-3 py-1 text-xs font-medium transition-colors',
                    showSkipped === value ? 'bg-navy-700 text-white' : 'text-ink-secondary hover:bg-surface-muted',
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          }
        />
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-b border-line bg-surface-muted text-left">
                  {['Test', 'Module', 'Priority', 'Risk', 'Failure rate', 'Duration', 'Reason'].map((header) => (
                    <th key={header} scope="col" className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {tests.slice(0, 60).map((test, index) => (
                  <tr key={String(test.test_case_id ?? index)} className="data-grid-row">
                    <td className="px-5 py-3">
                      <code className="font-mono text-2xs text-ink-tertiary">{String(test.key ?? '')}</code>
                      <p className="truncate text-sm text-ink">{String(test.title ?? '')}</p>
                    </td>
                    <td className="px-5 py-3 text-ink-secondary">{String(test.module ?? '')}</td>
                    <td className="px-5 py-3">
                      <Badge tone={test.priority === 'critical' || test.priority === 'high' ? 'warning' : 'neutral'}>
                        {String(test.priority ?? '')}
                      </Badge>
                    </td>
                    <td className="px-5 py-3">
                      <span className="flex items-center gap-2">
                        <ProgressBar
                          value={Number(test.risk_score ?? 0)}
                          tone={Number(test.risk_score ?? 0) > 0.6 ? 'danger' : Number(test.risk_score ?? 0) > 0.35 ? 'warning' : 'success'}
                          className="w-14"
                          label="Risk score"
                        />
                        <span className="tabular text-xs text-ink-secondary">{Number(test.risk_score ?? 0).toFixed(2)}</span>
                      </span>
                    </td>
                    <td className="tabular px-5 py-3 text-ink-secondary">
                      {formatPercent(Number(test.historical_failure_rate ?? 0), 0)}
                    </td>
                    <td className="tabular px-5 py-3 text-ink-secondary">{formatDuration(Number(test.duration_ms ?? 0))}</td>
                    <td className="max-w-xs px-5 py-3 text-xs text-ink-secondary">{String(test.reason ?? '')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
