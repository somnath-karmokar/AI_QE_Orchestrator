/** Root cause analysis records with evidence, confidence and accept/reject decisions. */
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Check, GitCommit, Microscope, X } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatPercent, formatRelativeTime } from '@/hooks';
import {
  Badge, Button, Card, CardBody, EmptyState, LoadingBlock,
  PageHeader, ProgressBar, Select, statusTone,
} from '@/design-system/primitives';

const CATEGORY_TONE: Record<string, 'danger' | 'warning' | 'info' | 'neutral'> = {
  application: 'danger', infrastructure: 'warning', automation: 'info', test_data: 'neutral',
};

export default function RcaPage() {
  const projectId = useProjectId();
  const queryClient = useQueryClient();
  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['rca', projectId, status, category],
    queryFn: () =>
      api.listRca({
        project_id: projectId!,
        status: status || undefined,
        category: category || undefined,
        limit: 50,
      }),
    enabled: Boolean(projectId),
  });

  const decide = useMutation({
    mutationFn: ({ id, decision }: { id: string; decision: 'accept' | 'reject' }) =>
      api.decideRca(id, decision),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['rca', projectId] }),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  return (
    <div>
      <PageHeader
        title="Root Cause Analysis"
        description="Every RCA states a probable cause, the evidence behind it, and a confidence you can weigh before acting."
        actions={
          <div className="flex gap-2">
            <Select aria-label="Filter by status" className="w-36" value={status} onChange={(event) => setStatus(event.target.value)}>
              <option value="">All statuses</option>
              {['proposed', 'accepted', 'rejected'].map((value) => (
                <option key={value} value={value}>{value}</option>
              ))}
            </Select>
            <Select aria-label="Filter by category" className="w-40" value={category} onChange={(event) => setCategory(event.target.value)}>
              <option value="">All categories</option>
              {['application', 'infrastructure', 'automation', 'test_data'].map((value) => (
                <option key={value} value={value}>{value.replace(/_/g, ' ')}</option>
              ))}
            </Select>
          </div>
        }
      />

      {data?.items.length ? (
        <div className="space-y-4">
          {data.items.map((rca) => (
            <Card key={rca.id}>
              <CardBody className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge tone={CATEGORY_TONE[rca.category] ?? 'neutral'}>{rca.category.replace(/_/g, ' ')}</Badge>
                      <Badge tone={statusTone(rca.status)}>{rca.status}</Badge>
                      {rca.agent_key ? <Badge tone="brand">{rca.agent_key}</Badge> : null}
                      <span className="text-xs text-ink-tertiary">{formatRelativeTime(rca.created_at)}</span>
                    </div>

                    <h3 className="mt-2.5 text-lg font-semibold text-ink">{rca.probable_root_cause}</h3>

                    <div className="mt-3 flex items-center gap-3">
                      <span className="text-xs font-medium text-ink-secondary">Confidence</span>
                      <ProgressBar
                        value={rca.confidence}
                        tone={rca.confidence > 0.85 ? 'success' : rca.confidence > 0.65 ? 'warning' : 'danger'}
                        className="w-32"
                        label="RCA confidence"
                      />
                      <span className="tabular text-sm font-semibold text-ink">{formatPercent(rca.confidence, 0)}</span>
                    </div>
                  </div>

                  {rca.status === 'proposed' ? (
                    <div className="flex shrink-0 gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        icon={<X className="h-3 w-3" />}
                        loading={decide.isPending && decide.variables?.id === rca.id}
                        onClick={() => decide.mutate({ id: rca.id, decision: 'reject' })}
                      >
                        Reject
                      </Button>
                      <Button
                        size="sm"
                        variant="primary"
                        icon={<Check className="h-3 w-3" />}
                        loading={decide.isPending && decide.variables?.id === rca.id}
                        onClick={() => decide.mutate({ id: rca.id, decision: 'accept' })}
                      >
                        Accept
                      </Button>
                    </div>
                  ) : rca.reviewed_by ? (
                    <span className="shrink-0 text-xs text-ink-tertiary">Reviewed by {rca.reviewed_by}</span>
                  ) : null}
                </div>

                <div className="mt-4 grid gap-4 border-t border-line pt-4 md:grid-cols-2">
                  {rca.evidence?.length ? (
                    <section>
                      <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Evidence</h4>
                      <ul className="space-y-1">
                        {rca.evidence.slice(0, 5).map((item, index) => (
                          <li key={index} className="text-sm text-ink-secondary">
                            <span className="text-ink-tertiary">{item.type?.replace(/_/g, ' ')}: </span>
                            {item.detail}
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}

                  <section className="space-y-3">
                    {rca.affected_tests?.length ? (
                      <div>
                        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Impact</h4>
                        <p className="text-sm text-ink-secondary">
                          {rca.affected_tests.length === 1 && 'count' in rca.affected_tests[0]
                            ? `${String(rca.affected_tests[0].count)} affected test(s) in ${String(rca.affected_tests[0].module ?? '')}`
                            : `${rca.affected_tests.length} affected test(s)`}
                        </p>
                      </div>
                    ) : null}

                    {rca.related_code_changes?.length ? (
                      <div>
                        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Related changes</h4>
                        <ul className="space-y-0.5">
                          {rca.related_code_changes.slice(0, 3).map((commit, index) => (
                            <li key={index} className="flex items-center gap-1.5 text-xs text-ink-secondary">
                              <GitCommit className="h-3 w-3 shrink-0 text-ink-tertiary" />
                              <code className="font-mono text-ink-tertiary">{commit.sha}</code>
                              <span className="truncate">{commit.message}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : null}

                    {rca.historical_similarity?.length ? (
                      <div>
                        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                          Historical precedent
                        </h4>
                        <ul className="space-y-0.5">
                          {rca.historical_similarity.slice(0, 3).map((entry, index) => (
                            <li key={index} className="flex items-center gap-2 text-xs text-ink-secondary">
                              <span className="tabular shrink-0 text-ink-tertiary">{formatPercent(entry.score, 0)}</span>
                              <span className="truncate">{entry.excerpt}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : null}
                  </section>
                </div>

                {rca.recommended_action ? (
                  <div className="mt-4 rounded border border-brand-100 bg-brand-50 px-4 py-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Recommended action</p>
                    <p className="mt-1 text-sm text-ink">{rca.recommended_action}</p>
                  </div>
                ) : null}
              </CardBody>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <EmptyState
            icon={<Microscope className="h-5 w-5" />}
            title="No root cause analyses yet"
            description="Run RCA from a failed execution or a defect to produce one."
          />
        </Card>
      )}
    </div>
  );
}
