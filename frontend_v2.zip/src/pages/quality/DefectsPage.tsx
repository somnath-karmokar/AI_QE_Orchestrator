/** Defect intelligence (spec §13): triage, clustering, prediction and self-healing. */
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Bug, Check, Microscope, Search, Sparkles, Wrench, X } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useDebounced, useProjectId, formatPercent, formatRelativeTime } from '@/hooks';
import { Column, DataTable } from '@/components/DataTable';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Input,
  PageHeader, ProgressBar, Select, statusTone, TONE_BY_SEVERITY,
} from '@/design-system/primitives';
import type { DefectRecord, HealingRecord } from '@/types';

type Tab = 'defects' | 'predictions' | 'healing';

export default function DefectsPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [tab, setTab] = useState<Tab>('defects');
  const [status, setStatus] = useState('');
  const [severity, setSeverity] = useState('');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<DefectRecord | null>(null);
  const debounced = useDebounced(search, 300);

  const { data: insights } = useQuery({
    queryKey: ['defect-insights', projectId],
    queryFn: () => api.defectInsights(projectId!),
    enabled: Boolean(projectId),
  });

  const { data: defects, isLoading } = useQuery({
    queryKey: ['defects', projectId, status, severity, debounced],
    queryFn: () =>
      api.listDefects({
        project_id: projectId!,
        status: status || undefined,
        severity: severity || undefined,
        search: debounced || undefined,
        limit: 100,
      }),
    enabled: Boolean(projectId) && tab === 'defects',
  });

  const { data: predictions } = useQuery({
    queryKey: ['predictions', projectId],
    queryFn: () => api.listPredictions(projectId!),
    enabled: Boolean(projectId) && tab === 'predictions',
  });

  const { data: healing } = useQuery({
    queryKey: ['healing', projectId],
    queryFn: () => api.listHealing({ project_id: projectId!, limit: 60 }),
    enabled: Boolean(projectId) && tab === 'healing',
  });

  /** Refusals matter here: policy can decline an approval, and the reviewer
   *  needs to be told why rather than watching the button do nothing. */
  const [healingError, setHealingError] = useState<{ id: string; message: string; reasons: string[] } | null>(null);

  const decideHealing = useMutation({
    mutationFn: ({ id, decision }: { id: string; decision: 'approve' | 'reject' }) =>
      api.decideHealing(id, decision),
    onMutate: () => setHealingError(null),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['healing', projectId] }),
    onError: (error, variables) => {
      const reasons = error instanceof ApiError ? (error.details?.reasons as string[] | undefined) ?? [] : [];
      setHealingError({
        id: variables.id,
        message: error instanceof Error ? error.message : 'The decision could not be recorded.',
        reasons,
      });
      void queryClient.invalidateQueries({ queryKey: ['healing', projectId] });
    },
  });

  const analyze = useMutation({
    mutationFn: (defectId: string) =>
      api.analyzeDefect({ project_id: projectId, defect_id: defectId, synchronous: true }),
    onSuccess: (run) => navigate(`/runs/${run.id}`),
  });

  const columns: Column<DefectRecord>[] = [
    {
      key: 'key',
      header: 'Defect',
      render: (defect) => (
        <div className="min-w-0">
          <p className="flex items-center gap-2">
            <code className="font-mono text-xs font-semibold text-brand-600">{defect.external_key ?? 'DRAFT'}</code>
            {defect.is_ai_suggested ? (
              <Badge tone="brand">
                <Sparkles className="h-3 w-3" /> AI
              </Badge>
            ) : null}
          </p>
          <p className="mt-0.5 truncate text-sm font-medium text-ink">{defect.title}</p>
        </div>
      ),
    },
    { key: 'module', header: 'Module', render: (d) => <span className="text-ink-secondary">{d.module}</span> },
    { key: 'severity', header: 'Severity', render: (d) => <Badge tone={TONE_BY_SEVERITY[d.severity] ?? 'neutral'}>{d.severity}</Badge> },
    { key: 'status', header: 'Status', render: (d) => <Badge tone={statusTone(d.status)}>{d.status.replace(/_/g, ' ')}</Badge> },
    { key: 'cluster', header: 'Cluster', render: (d) => (d.cluster_key ? <span className="font-mono text-2xs text-ink-tertiary">{d.cluster_key}</span> : <span className="text-ink-tertiary">—</span>) },
    { key: 'assigned', header: 'Assigned', render: (d) => <span className="text-ink-secondary">{d.assigned_to ?? '—'}</span> },
    { key: 'created', header: 'Raised', render: (d) => <span className="text-ink-secondary">{formatRelativeTime(d.created_at)}</span> },
  ];

  return (
    <div>
      <PageHeader
        title="Defect Intelligence"
        description="Triage, clustering, duplicate detection, risk prediction and governed self-healing."
      />

      {insights ? (
        <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <Stat label="Total defects" value={insights.total} />
          <Stat label="Open" value={insights.open} tone="danger" />
          <Stat label="Resolved" value={insights.resolved} tone="success" />
          <Stat label="AI-suggested" value={insights.ai_suggested} />
          <Stat
            label="Mean resolution"
            value={insights.mean_resolution_days ? `${insights.mean_resolution_days.toFixed(1)}d` : '—'}
            isText
          />
        </div>
      ) : null}

      <div className="mb-4 flex gap-1 border-b border-line" role="tablist">
        {([
          ['defects', 'Defects'],
          ['predictions', 'Risk predictions'],
          ['healing', 'Self-healing'],
        ] as const).map(([value, label]) => (
          <button
            key={value}
            role="tab"
            aria-selected={tab === value}
            onClick={() => setTab(value)}
            className={cn(
              '-mb-px border-b-2 px-4 py-2 text-sm font-medium transition-colors',
              tab === value
                ? 'border-brand-500 text-brand-700'
                : 'border-transparent text-ink-secondary hover:border-line-strong hover:text-ink',
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'defects' ? (
        <div className={cn('grid gap-5', selected && 'lg:grid-cols-[1fr_400px]')}>
          <Card>
            <CardHeader
              title="Defects"
              description={`${defects?.total ?? 0} recorded`}
              actions={
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" aria-hidden />
                    <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search defects" aria-label="Search defects" className="h-8 w-44 pl-8 text-sm" />
                  </div>
                  <Select aria-label="Filter by status" className="h-8 w-32 text-sm" value={status} onChange={(event) => setStatus(event.target.value)}>
                    <option value="">All statuses</option>
                    {['open', 'triage', 'in_progress', 'resolved', 'closed'].map((value) => (
                      <option key={value} value={value}>{value.replace(/_/g, ' ')}</option>
                    ))}
                  </Select>
                  <Select aria-label="Filter by severity" className="h-8 w-32 text-sm" value={severity} onChange={(event) => setSeverity(event.target.value)}>
                    <option value="">All severities</option>
                    {['blocker', 'critical', 'major', 'minor', 'trivial'].map((value) => (
                      <option key={value} value={value}>{value}</option>
                    ))}
                  </Select>
                </div>
              }
            />
            <DataTable
              columns={columns}
              rows={defects?.items ?? []}
              keyOf={(defect) => defect.id}
              loading={isLoading}
              onRowClick={setSelected}
              caption="Defect list"
              emptyIcon={<Bug className="h-5 w-5" />}
              emptyTitle="No defects match"
              minWidth={860}
            />
          </Card>

          {selected ? (
            <DefectPanel
              defect={selected}
              onClose={() => setSelected(null)}
              onAnalyze={() => analyze.mutate(selected.id)}
              analyzing={analyze.isPending}
            />
          ) : null}
        </div>
      ) : null}

      {tab === 'predictions' ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {(predictions ?? []).map((prediction) => (
            <Card key={prediction.id}>
              <CardBody className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-md font-semibold text-ink">{prediction.module}</h3>
                  <Badge tone={prediction.risk_band === 'high' ? 'danger' : prediction.risk_band === 'medium' ? 'warning' : 'success'}>
                    {prediction.risk_band} risk
                  </Badge>
                </div>
                <p className="tabular mt-2 text-3xl font-semibold text-ink">{formatPercent(prediction.probability, 0)}</p>
                <p className="text-xs text-ink-tertiary">
                  likelihood over the next {prediction.horizon_days} days
                </p>
                <ProgressBar
                  value={prediction.probability}
                  tone={prediction.risk_band === 'high' ? 'danger' : prediction.risk_band === 'medium' ? 'warning' : 'success'}
                  className="mt-3"
                  label={`${prediction.module} risk`}
                />

                <div className="mt-4 border-t border-line pt-3">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Drivers</p>
                  <ul className="space-y-1.5">
                    {prediction.drivers.map((driver, index) => (
                      <li key={index} className="text-xs">
                        <span className="font-medium text-ink">{driver.driver}</span>
                        <span className="tabular ml-1.5 text-ink-tertiary">+{driver.weight}</span>
                        <p className="text-ink-secondary">{driver.detail}</p>
                      </li>
                    ))}
                  </ul>
                </div>

                {prediction.recommended_actions?.length ? (
                  <p className="mt-3 rounded border border-line bg-surface-muted px-3 py-2 text-xs text-ink-secondary">
                    {prediction.recommended_actions[0]}
                  </p>
                ) : null}
              </CardBody>
            </Card>
          ))}
          {!predictions?.length ? (
            <Card className="md:col-span-2 xl:col-span-3">
              <EmptyState title="No predictions yet" description="Run the Defect Prediction agent to score module risk." />
            </Card>
          ) : null}
        </div>
      ) : null}

      {tab === 'healing' ? (
        <Card>
          <CardHeader
            title="Self-healing proposals"
            description="Approving does not apply a change — it re-runs the test with the change patched in, and only a passing re-run is applied (spec §11)"
          />
          <CardBody className="p-0">
            {healing?.items.length ? (
              <ul className="divide-y divide-line-subtle">
                {healing.items.map((record) => (
                  <li key={record.id} className="px-5 py-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="flex flex-wrap items-center gap-2">
                          <Badge tone={statusTone(record.status)}>{record.status.replace(/_/g, ' ')}</Badge>
                          <Badge tone="neutral">{record.failure_class.replace(/_/g, ' ')}</Badge>
                          {/* What policy acts on, which is not always what failed. */}
                          <Badge tone="brand">changes {record.change_type.replace(/_/g, ' ')}</Badge>
                          <span className={cn('tabular text-xs font-medium', record.confidence >= 0.85 ? 'text-success-text' : 'text-warning-text')}>
                            {formatPercent(record.confidence, 0)} confidence
                          </span>
                        </p>

                        <div className="mt-2.5 space-y-1.5">
                          <p className="font-mono text-xs">
                            <span className="text-ink-tertiary">from </span>
                            <span className="rounded bg-danger-bg px-1.5 py-0.5 text-danger-text line-through">
                              {record.original_locator}
                            </span>
                          </p>
                          <p className="font-mono text-xs">
                            <span className="text-ink-tertiary">to </span>
                            <span className="rounded bg-success-bg px-1.5 py-0.5 text-success-text">
                              {record.proposed_locator}
                            </span>
                          </p>
                        </div>

                        <p className="mt-2 text-xs text-ink-secondary">{record.reason}</p>

                        <HealingValidation record={record} />

                        {healingError?.id === record.id ? (
                          <div className="mt-2 rounded-md bg-danger-bg px-2.5 py-2 text-xs text-danger-text">
                            <p className="font-medium">{healingError.message}</p>
                            {healingError.reasons.map((reason) => (
                              <p key={reason} className="mt-0.5">{reason}</p>
                            ))}
                          </div>
                        ) : null}
                      </div>

                      {record.status === 'proposed' ? (
                        <div className="flex shrink-0 gap-2">
                          <Button
                            size="sm"
                            variant="secondary"
                            icon={<X className="h-3 w-3" />}
                            loading={decideHealing.isPending && decideHealing.variables?.id === record.id}
                            onClick={() => decideHealing.mutate({ id: record.id, decision: 'reject' })}
                          >
                            Reject
                          </Button>
                          <Button
                            size="sm"
                            variant="primary"
                            icon={<Check className="h-3 w-3" />}
                            loading={decideHealing.isPending && decideHealing.variables?.id === record.id}
                            onClick={() => decideHealing.mutate({ id: record.id, decision: 'approve' })}
                          >
                            Approve
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={<Wrench className="h-5 w-5" />} title="No healing proposals" description="Locator failures produce proposals here." />
            )}
          </CardBody>
        </Card>
      ) : null}
    </div>
  );
}

/** What a re-run actually showed — never what we hope it would show. */
const VALIDATION_COPY: Record<HealingRecord['validation_status'], { tone: 'success' | 'danger' | 'warning' | 'neutral'; label: string }> = {
  passed: { tone: 'success', label: 'Re-run passed' },
  failed: { tone: 'danger', label: 'Re-run failed' },
  running: { tone: 'warning', label: 'Re-running' },
  inconclusive: { tone: 'warning', label: 'Unproven' },
  not_started: { tone: 'neutral', label: 'Not yet re-run' },
};

function HealingValidation({ record }: { record: HealingRecord }) {
  const validation = VALIDATION_COPY[record.validation_status] ?? VALIDATION_COPY.not_started;
  const rerun = record.validation_evidence?.find((item) => item.type === 'rerun');
  const strength = record.validation_evidence?.find((item) => item.type === 'evidence_strength');
  const blocked = record.status === 'blocked';

  if (blocked) {
    const reasons = (record.policy_decision?.reasons as string[] | undefined) ?? [];
    return (
      <p className="mt-2 rounded-md bg-danger-bg px-2.5 py-2 text-xs text-danger-text">
        Healing may not change {record.change_type.replace(/_/g, ' ')}. {reasons[0] ?? ''}
      </p>
    );
  }

  return (
    <div className="mt-2 space-y-1.5">
      <p className="flex flex-wrap items-center gap-2 text-xs text-ink-tertiary">
        <Badge tone={validation.tone}>{validation.label}</Badge>
        {record.validation_mode ? <span>{record.validation_mode} run</span> : null}
        {record.attempt_count > 0 ? <span>attempt {record.attempt_count}</span> : null}
        {record.script_version_after ? (
          <span>
            script v{record.script_version_before} → v{record.script_version_after}
          </span>
        ) : null}
        {record.approver ? <span>decided by {record.approver}</span> : null}
      </p>
      {rerun ? <p className="text-xs text-ink-secondary">{rerun.detail}</p> : null}
      {strength ? <p className="text-xs text-ink-tertiary">{strength.detail}</p> : null}
      {record.status === 'rolled_back' ? (
        <p className="text-xs text-warning-text">
          The change was discarded and the script left untouched.
        </p>
      ) : null}
      {record.status === 'applied' && record.validation_status === 'inconclusive' ? (
        <p className="text-xs text-warning-text">
          Applied before a re-run was required, so nothing proved it worked.
        </p>
      ) : null}
    </div>
  );
}

function Stat({ label, value, tone, isText }: { label: string; value: number | string; tone?: 'success' | 'danger'; isText?: boolean }) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p className={cn('tabular mt-1 font-semibold', isText ? 'text-lg' : 'text-2xl', tone === 'danger' ? 'text-danger-text' : tone === 'success' ? 'text-success-text' : 'text-ink')}>
          {value}
        </p>
      </CardBody>
    </Card>
  );
}

function DefectPanel({
  defect,
  onClose,
  onAnalyze,
  analyzing,
}: {
  defect: DefectRecord;
  onClose: () => void;
  onAnalyze: () => void;
  analyzing: boolean;
}) {
  const { data: analyses } = useQuery({
    queryKey: ['defect-analyses', defect.id],
    queryFn: () => api.defectAnalyses(defect.id),
  });

  return (
    <Card className="self-start">
      <CardHeader
        title={defect.external_key ?? 'Draft defect'}
        description={defect.title}
        actions={
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close panel">
            <X className="h-4 w-4" />
          </Button>
        }
      />
      <CardBody className="space-y-4">
        <div className="flex flex-wrap gap-1.5">
          <Badge tone={TONE_BY_SEVERITY[defect.severity] ?? 'neutral'}>{defect.severity}</Badge>
          <Badge tone={statusTone(defect.status)}>{defect.status.replace(/_/g, ' ')}</Badge>
          <Badge tone="neutral">{defect.module}</Badge>
          {defect.failure_signature ? <Badge tone="neutral">{defect.failure_signature}</Badge> : null}
        </div>

        {defect.description ? (
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-ink-secondary">{defect.description}</p>
        ) : null}

        {defect.steps_to_reproduce?.length ? (
          <section>
            <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Steps to reproduce</h4>
            <ol className="list-inside list-decimal space-y-1">
              {defect.steps_to_reproduce.map((step, index) => (
                <li key={index} className="text-sm text-ink-secondary">{step}</li>
              ))}
            </ol>
          </section>
        ) : null}

        {defect.resolution_notes ? (
          <div className="rounded border border-success-border bg-success-bg px-3 py-2">
            <p className="text-xs font-semibold text-success-text">Resolution</p>
            <p className="mt-0.5 text-sm text-success-text/90">{defect.resolution_notes}</p>
          </div>
        ) : null}

        {analyses?.length ? (
          <section className="border-t border-line pt-3">
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">AI analyses</h4>
            {analyses.map((analysis) => (
              <div key={analysis.id} className="mb-2 rounded border border-line bg-surface-muted px-3 py-2">
                <p className="flex items-center gap-2 text-xs">
                  <Badge tone="brand">{analysis.analysis_type}</Badge>
                  <span className="tabular text-ink-tertiary">{formatPercent(analysis.confidence, 0)} confidence</span>
                </p>
                <p className="mt-1 text-sm text-ink-secondary">{analysis.summary}</p>
              </div>
            ))}
          </section>
        ) : null}

        <Button variant="primary" className="w-full" loading={analyzing} onClick={onAnalyze} icon={<Microscope className="h-3.5 w-3.5" />}>
          Run root cause analysis
        </Button>
      </CardBody>
    </Card>
  );
}
