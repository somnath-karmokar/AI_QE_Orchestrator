/**
 * The portal an API user signs into with their key.
 *
 * Whoever holds a key has no account here — that is the point of a key — so this
 * page authenticates with the key itself against the same endpoints a pipeline
 * calls. It answers the three questions a new integrator actually has: is my key
 * live, what was I given, and what have my calls been doing.
 *
 * The key is held in `sessionStorage`, so it survives a reload of this tab and
 * nothing more: not another tab's session, not the next time the browser opens.
 * It is never sent anywhere but this platform, and never written to a log.
 */
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Activity, BadgeEuro, ChevronDown, ChevronRight, CircleAlert, Clock, Download, FileCheck2, Gauge,
  KeyRound, LogOut, PlugZap, ShieldCheck, Workflow,
} from 'lucide-react';
import { ApiError, portalApi } from '@/services/api';
import { formatCurrency, formatRelativeTime } from '@/hooks';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, CopyButton, EmptyState, Field,
  Input, LoadingBlock, statusTone,
} from '@/design-system/primitives';
import type { ApiCatalogEntry, ApiRunLog } from '@/types';

const STORAGE_KEY = 'aiqe.portal.key';

const DISPOSITION_TONE: Record<string, 'success' | 'danger' | 'warning' | 'info' | 'neutral'> = {
  succeeded: 'success',
  failed: 'danger',
  waiting_for_approval: 'warning',
  pending: 'info',
  cancelled: 'neutral',
  refused: 'danger',
};

function Stat({
  label,
  value,
  icon,
  hint,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  hint?: string;
}) {
  return (
    <Card>
      <CardBody className="py-4">
        <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
          {icon}
          {label}
        </p>
        <p className="mt-1 text-xl font-semibold text-ink">{value}</p>
        {hint ? <p className="mt-0.5 text-xs text-ink-tertiary">{hint}</p> : null}
      </CardBody>
    </Card>
  );
}

/**
 * Fetch a governance document with the key and save it as a file.
 *
 * A plain link cannot carry the X-API-Key header, and putting the key in a URL
 * would write it into browser history and server logs -- so the document is
 * fetched here and handed to the browser as a download.
 */
function DownloadDocument({
  apiKey,
  path,
  filename,
  label,
}: {
  apiKey: string;
  path: string;
  filename: string;
  label: string;
}) {
  const [state, setState] = useState<'idle' | 'busy' | 'error'>('idle');
  const download = async () => {
    setState('busy');
    try {
      const body = await portalApi.document(apiKey, path);
      const url = URL.createObjectURL(new Blob([JSON.stringify(body, null, 2)], { type: 'application/json' }));
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      anchor.click();
      URL.revokeObjectURL(url);
      setState('idle');
    } catch {
      setState('error');
    }
  };
  return (
    <Button
      variant="ghost"
      size="sm"
      icon={<Download className="h-3.5 w-3.5" />}
      onClick={download}
      disabled={state === 'busy'}
      title={state === 'error' ? 'Could not download; this key may lack catalog:read.' : undefined}
    >
      {state === 'error' ? `${label} (failed)` : label}
    </Button>
  );
}

function RunLogPanel({ apiKey, runId }: { apiKey: string; runId: string }) {
  const log = useQuery({
    queryKey: ['portal-run-log', apiKey, runId],
    queryFn: () => portalApi.runLog(apiKey, runId),
    retry: false,
  });

  if (log.isLoading) return <LoadingBlock rows={2} />;
  if (log.error) {
    const missingScope = log.error instanceof ApiError && log.error.status === 403;
    return (
      <p className="flex items-center gap-2 text-xs text-ink-secondary" role="status">
        <CircleAlert className="h-3.5 w-3.5 shrink-0" aria-hidden />
        {missingScope
          ? 'This key does not have the runs:logs scope. Ask the operator who issued it to grant it.'
          : 'The log could not be loaded.'}
      </p>
    );
  }
  const data = log.data as ApiRunLog;
  const agents = data.activities.filter((activity) => activity.agent);

  return (
    <div className="space-y-3">
      <table className="w-full text-left text-xs">
        <thead className="text-ink-tertiary">
          <tr>
            <th className="py-1 pr-3 font-medium">Agent</th>
            <th className="py-1 pr-3 font-medium">Status</th>
            <th className="py-1 pr-3 font-medium">Model</th>
            <th className="py-1 pr-3 text-right font-medium">Duration</th>
            <th className="py-1 pr-3 text-right font-medium">Tokens</th>
            <th className="py-1 text-right font-medium">Cost</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-line-subtle text-ink">
          {agents.map((activity) => (
            <tr key={`${activity.sequence}-${activity.attempt ?? 0}`}>
              <td className="py-1.5 pr-3">{activity.label ?? activity.agent!.key}</td>
              <td className="py-1.5 pr-3">
                <Badge tone={statusTone(activity.status)}>{activity.status}</Badge>
              </td>
              <td className="py-1.5 pr-3 font-mono text-2xs text-ink-secondary">
                {activity.model ? `${activity.model.provider}/${activity.model.model}` : '—'}
              </td>
              <td className="py-1.5 pr-3 text-right tabular-nums">
                {activity.duration_ms != null ? `${(activity.duration_ms / 1000).toFixed(1)}s` : '—'}
              </td>
              <td className="py-1.5 pr-3 text-right tabular-nums">{activity.usage.total_tokens.toLocaleString()}</td>
              <td className="py-1.5 text-right tabular-nums">{formatCurrency(activity.usage.cost_usd, 4)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="text-xs text-ink-secondary">
        {data.approvals.length} approval(s) · {data.audit.length} audit entr{data.audit.length === 1 ? 'y' : 'ies'} ·{' '}
        {data.timeline.length} event(s). Masked: secrets and personal data. Not included:{' '}
        {data.redaction.omitted.join('; ')}.
      </p>
      <DownloadDocument
        apiKey={apiKey}
        path={`/integration/runs/${runId}/log`}
        filename={`run-${runId.slice(0, 8)}-log.json`}
        label="Download log"
      />
    </div>
  );
}

/** An agent is addressed by key, a flow by id -- as their invoke paths are. */
function documentBase(entry: ApiCatalogEntry): string {
  return entry.key ? `/integration/agents/${entry.key}` : `/integration/flows/${entry.id}`;
}

function Capability({ entry, apiKey }: { entry: ApiCatalogEntry; apiKey: string }) {
  const inputs = Object.keys(
    (entry.input_schema as { properties?: Record<string, unknown> })?.properties ?? {},
  );
  return (
    <li className="px-5 py-3.5">
      <p className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-medium text-ink">{entry.name}</span>
        {entry.category ? <Badge tone="neutral">{entry.category}</Badge> : null}
        {entry.guardrails?.requires_approval ? <Badge tone="warning">pauses for approval</Badge> : null}
      </p>
      {entry.description ? (
        <p className="mt-0.5 line-clamp-2 text-xs text-ink-secondary">{entry.description}</p>
      ) : null}
      <div className="mt-2 flex items-center gap-2">
        <Badge tone="brand">{entry.invoke.method}</Badge>
        <code className="min-w-0 flex-1 truncate font-mono text-2xs text-ink-secondary">
          {entry.invoke.path}
        </code>
        <CopyButton text={entry.invoke.path} label={`Copy the path for ${entry.name}`} />
      </div>
      <div className="mt-1.5 flex flex-wrap gap-1">
        <DownloadDocument
          apiKey={apiKey}
          path={`${documentBase(entry)}/model-card`}
          filename={`${entry.key ?? entry.id}-model-card.json`}
          label="Model card"
        />
        <DownloadDocument
          apiKey={apiKey}
          path={`${documentBase(entry)}/golden-dataset`}
          filename={`${entry.key ?? entry.id}-golden-dataset.json`}
          label="Golden dataset"
        />
      </div>
      {inputs.length ? (
        <p className="mt-1.5 flex flex-wrap gap-1">
          {inputs.map((input) => (
            <code
              key={input}
              className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink-tertiary"
            >
              {input}
            </code>
          ))}
        </p>
      ) : null}
    </li>
  );
}

function SignIn({ onSubmit, error }: { onSubmit: (key: string) => void; error: string | null }) {
  const [value, setValue] = useState('');
  return (
    <div className="flex min-h-screen items-center justify-center bg-surface-muted px-4">
      <Card className="w-full max-w-md">
        <CardBody className="space-y-4 py-7">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-brand-100 bg-brand-50 text-brand-700">
              <PlugZap className="h-5 w-5" aria-hidden />
            </span>
            <div>
              <h1 className="text-lg font-semibold text-ink">API user portal</h1>
              <p className="text-sm text-ink-secondary">See what your key can do here.</p>
            </div>
          </div>

          <form
            onSubmit={(event) => {
              event.preventDefault();
              if (value.trim()) onSubmit(value.trim());
            }}
            className="space-y-3"
          >
            <Field label="Your API key" htmlFor="portal-key" required>
              <Input
                id="portal-key"
                type="password"
                autoComplete="off"
                spellCheck={false}
                value={value}
                onChange={(event) => setValue(event.target.value)}
                placeholder="qei_…"
              />
            </Field>
            {error ? (
              <p className="flex items-start gap-2 rounded-lg border border-danger-border bg-danger-bg px-3 py-2 text-sm text-danger-text">
                <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
                {error}
              </p>
            ) : null}
            <Button type="submit" className="w-full" disabled={!value.trim()}>
              Sign in
            </Button>
          </form>

          <p className="text-xs text-ink-tertiary">
            Your key stays in this browser tab and is sent only to this platform. An operator issues
            and rotates it; it cannot be recovered here.
          </p>
        </CardBody>
      </Card>
    </div>
  );
}

export default function ApiPortalPage() {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [signInError, setSignInError] = useState<string | null>(null);

  useEffect(() => {
    try {
      setApiKey(window.sessionStorage.getItem(STORAGE_KEY));
    } catch {
      /* a blocked store just means signing in again */
    }
  }, []);

  const signIn = (key: string) => {
    try {
      window.sessionStorage.setItem(STORAGE_KEY, key);
    } catch {
      /* the portal still works for this page view */
    }
    setSignInError(null);
    setApiKey(key);
  };

  const signOut = () => {
    try {
      window.sessionStorage.removeItem(STORAGE_KEY);
    } catch {
      /* nothing to forget */
    }
    setApiKey(null);
  };

  const identity = useQuery({
    queryKey: ['portal-me', apiKey],
    queryFn: () => portalApi.me(apiKey!),
    enabled: Boolean(apiKey),
    retry: false,
  });

  const catalog = useQuery({
    queryKey: ['portal-catalog', apiKey],
    queryFn: () => portalApi.catalog(apiKey!),
    enabled: Boolean(apiKey) && identity.isSuccess,
    retry: false,
  });

  const [openLog, setOpenLog] = useState<string | null>(null);
  const hasLogs = Boolean(identity.data?.scopes.granted.includes('runs:logs'));
  const metrics = useQuery({
    queryKey: ['portal-metrics', apiKey],
    queryFn: () => portalApi.metrics(apiKey!),
    enabled: Boolean(apiKey) && hasLogs,
    retry: false,
    refetchInterval: 60_000,
  });

  const runs = useQuery({
    queryKey: ['portal-runs', apiKey],
    queryFn: () => portalApi.runs(apiKey!),
    enabled: Boolean(apiKey) && identity.isSuccess,
    retry: false,
    refetchInterval: 15_000,
  });

  // A key that stops working must not leave someone staring at a dead page.
  useEffect(() => {
    if (!identity.isError) return;
    const error = identity.error;
    setSignInError(
      error instanceof ApiError && error.status === 401
        ? 'That key was not accepted. It may have been revoked, expired, or mistyped.'
        : 'Could not reach the platform. Try again in a moment.',
    );
    if (error instanceof ApiError && error.status === 401) signOut();
  }, [identity.isError, identity.error]);

  if (!apiKey) return <SignIn onSubmit={signIn} error={signInError} />;

  if (identity.isLoading) {
    return (
      <div className="mx-auto max-w-5xl px-6 py-10">
        <LoadingBlock rows={6} />
      </div>
    );
  }

  const me = identity.data;
  if (!me) return <SignIn onSubmit={signIn} error={signInError} />;

  const provisioned = [...(catalog.data?.flows ?? []), ...(catalog.data?.agents ?? [])];

  return (
    <div className="min-h-screen bg-surface-muted">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-3 px-6 py-4">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-brand-100 bg-brand-50 text-brand-700">
            <PlugZap className="h-4 w-4" aria-hidden />
          </span>
          <div className="min-w-0 flex-1">
            <p className="flex flex-wrap items-center gap-2">
              <span className="text-md font-semibold text-ink">{me.client.name}</span>
              <code className="font-mono text-2xs text-ink-tertiary">…{me.client.token_hint}</code>
              {me.validity.expired ? (
                <Badge tone="danger">expired</Badge>
              ) : (
                <Badge tone="success" dot>
                  key active
                </Badge>
              )}
            </p>
            <p className="text-xs text-ink-secondary">
              {me.client.platform ? `${me.client.platform} · ` : ''}
              {me.validity.expires_at
                ? `expires ${new Date(me.validity.expires_at).toLocaleDateString()}`
                : 'no expiry'}
              {` · ${me.limits.rate_limit_per_minute} calls/min`}
            </p>
          </div>
          <Button variant="secondary" size="sm" icon={<LogOut className="h-3.5 w-3.5" />} onClick={signOut}>
            Sign out
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-5 px-6 py-6">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat
            label="Provisioned"
            icon={<Workflow className="h-3.5 w-3.5" />}
            value={`${me.provisioned.flows} flows · ${me.provisioned.agents} agents`}
            hint={
              me.provisioned.all_flows_in_project || me.provisioned.all_agents_in_project
                ? 'Everything published in this project'
                : 'Named for this key'
            }
          />
          <Stat
            label="Runs started"
            icon={<Activity className="h-3.5 w-3.5" />}
            value={String(me.activity.runs_total)}
            hint={me.activity.in_flight ? `${me.activity.in_flight} in flight` : 'none in flight'}
          />
          <Stat
            label="Spend"
            icon={<BadgeEuro className="h-3.5 w-3.5" />}
            value={formatCurrency(me.activity.total_cost_usd, 2)}
            hint="across every run this key started"
          />
          <Stat
            label="Last call"
            icon={<Clock className="h-3.5 w-3.5" />}
            value={me.usage.last_used_at ? formatRelativeTime(me.usage.last_used_at) : 'never'}
            hint={`${me.usage.calls} calls in total`}
          />
        </section>

        {hasLogs && metrics.data ? (
          <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Last 30 days">
            <Stat
              label="Success rate"
              icon={<FileCheck2 className="h-3.5 w-3.5" />}
              value={metrics.data.runs.success_rate != null ? `${Math.round(metrics.data.runs.success_rate * 100)}%` : '—'}
              hint={`of finished runs, last ${metrics.data.window.days} days`}
            />
            <Stat
              label="p95 duration"
              icon={<Gauge className="h-3.5 w-3.5" />}
              value={metrics.data.runs.duration_ms.p95 != null ? `${(metrics.data.runs.duration_ms.p95 / 1000).toFixed(1)}s` : '—'}
              hint={metrics.data.runs.duration_ms.p50 != null ? `median ${(metrics.data.runs.duration_ms.p50 / 1000).toFixed(1)}s` : 'no finished runs yet'}
            />
            <Stat
              label="Model calls"
              icon={<Activity className="h-3.5 w-3.5" />}
              value={String(metrics.data.by_model.reduce((sum, row) => sum + row.calls, 0))}
              hint={`${metrics.data.by_model.reduce((sum, row) => sum + row.fallback_calls, 0)} fell back to another model`}
            />
            <Stat
              label="Approvals"
              icon={<ShieldCheck className="h-3.5 w-3.5" />}
              value={`${metrics.data.approvals.requested} requested`}
              hint={`${metrics.data.approvals.pending} pending`}
            />
          </section>
        ) : null}

        <Card>
          <CardHeader
            title="What you may do"
            description="Each scope your key was granted, and what it permits."
            icon={<ShieldCheck className="h-4 w-4" />}
          />
          <CardBody className="space-y-1.5">
            {me.scopes.granted.map((scope) => (
              <p key={scope} className="flex flex-wrap items-baseline gap-2">
                <code className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink">
                  {scope}
                </code>
                <span className="text-sm text-ink-secondary">{me.scopes.meaning[scope]}</span>
              </p>
            ))}
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Your agents and flows"
            description="Everything this key may invoke, with the endpoint for each."
            icon={<KeyRound className="h-4 w-4" />}
          />
          <CardBody className="p-0">
            {catalog.isLoading ? (
              <div className="p-5">
                <LoadingBlock rows={3} />
              </div>
            ) : provisioned.length === 0 ? (
              <EmptyState
                icon={<KeyRound className="h-5 w-5" />}
                title="Nothing provisioned yet"
                description="Your key is valid, but no flow or agent has been granted to it. Ask the platform's operator."
              />
            ) : (
              <ul className="divide-y divide-line-subtle">
                {provisioned.map((entry) => (
                  <Capability key={entry.id ?? entry.key} entry={entry} apiKey={apiKey} />
                ))}
              </ul>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Your runs"
            description="Work this key started. Updates every 15 seconds."
            icon={<Activity className="h-4 w-4" />}
          />
          <CardBody className="p-0">
            {runs.isLoading ? (
              <div className="p-5">
                <LoadingBlock rows={3} />
              </div>
            ) : (runs.data?.items.length ?? 0) === 0 ? (
              <EmptyState
                icon={<Activity className="h-5 w-5" />}
                title="No runs yet"
                description="Start one by calling any endpoint above with your key."
              />
            ) : (
              <ul className="divide-y divide-line-subtle">
                {runs.data!.items.map((run) => (
                  <li key={run.run_id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="flex flex-wrap items-center gap-2">
                        <span className="truncate text-sm font-medium text-ink">
                          {run.title ?? `Run #${run.run_number}`}
                        </span>
                        <Badge tone={DISPOSITION_TONE[run.disposition] ?? statusTone(run.status)}>
                          {run.disposition.replace(/_/g, ' ')}
                        </Badge>
                      </p>
                      <p className="mt-0.5 text-xs text-ink-tertiary">
                        {run.progress.completed_steps}/{run.progress.total_steps} steps
                        {run.started_at ? ` · started ${formatRelativeTime(run.started_at)}` : ''}
                        {run.guardrails.awaiting_approval.length
                          ? ` · waiting on ${run.guardrails.awaiting_approval[0].required_role}`
                          : ''}
                      </p>
                      {run.error ? (
                        <p className="mt-0.5 line-clamp-2 text-xs text-danger-text">{run.error}</p>
                      ) : null}
                    </div>
                    <code
                      className={cn('shrink-0 font-mono text-2xs text-ink-tertiary')}
                      title={run.run_id}
                    >
                      {run.run_id.slice(0, 8)}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      icon={
                        openLog === run.run_id ? (
                          <ChevronDown className="h-3.5 w-3.5" />
                        ) : (
                          <ChevronRight className="h-3.5 w-3.5" />
                        )
                      }
                      aria-expanded={openLog === run.run_id}
                      onClick={() => setOpenLog(openLog === run.run_id ? null : run.run_id)}
                    >
                      Log
                    </Button>
                    {openLog === run.run_id ? (
                      <div className="basis-full rounded-lg border border-line bg-surface-muted/60 p-3">
                        <RunLogPanel apiKey={apiKey} runId={run.run_id} />
                      </div>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </main>
    </div>
  );
}
