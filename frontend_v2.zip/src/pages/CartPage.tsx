/** Agent Cart (spec §6): review selected agents, order them, and build a flow. */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ArrowDown, ArrowRight, ArrowUp, Info, ShieldAlert, ShoppingCart, Trash2, Workflow,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId, formatCurrency } from '@/hooks';
import { AgentIcon } from '@/components/AgentIcon';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Field, Input,
  LoadingBlock, PageHeader, Textarea, TONE_BY_RISK,
} from '@/design-system/primitives';

/** "~€0.023", but "<€0.01" rather than "~<€0.01" when the amount is already a bound. */
function approximateCost(value: number): string {
  const formatted = formatCurrency(value, 3);
  return formatted.startsWith('<') ? formatted : `~${formatted}`;
}

export default function CartPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);

  const { data: cart, isLoading } = useQuery({
    queryKey: ['cart', projectId],
    queryFn: () => api.getCart(projectId!),
    enabled: Boolean(projectId),
  });

  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ['cart', projectId] });

  const remove = useMutation({ mutationFn: api.removeFromCart, onSuccess: invalidate });
  const reorder = useMutation({
    mutationFn: ({ id, sequence }: { id: string; sequence: number }) => api.reorderCartItem(id, sequence),
    onSuccess: invalidate,
  });

  const buildFlow = useMutation({
    mutationFn: () =>
      api.buildFlowFromCart({ project_id: projectId!, name: name.trim(), description: description.trim() || undefined }),
    onSuccess: (flow) => {
      invalidate();
      void queryClient.invalidateQueries({ queryKey: ['flows', projectId] });
      navigate(`/flows/${flow.id}/designer`);
    },
    onError: (caught) =>
      setError(caught instanceof ApiError ? caught.message : 'Could not build the flow.'),
  });

  const items = cart ?? [];
  const estimatedCost = items.reduce((total, item) => total + (item.agent?.avg_cost_usd ?? 0), 0);
  const approvalCount = items.filter((item) => item.agent?.requires_approval).length;
  const highestRisk = items.some((item) => item.agent?.risk_level === 'high' || item.agent?.risk_level === 'critical');

  function move(index: number, direction: -1 | 1) {
    const target = items[index + direction];
    const current = items[index];
    if (!target || !current) return;
    // Swap the two sequences so the visual order matches execution order.
    reorder.mutate({ id: current.id, sequence: target.sequence });
    reorder.mutate({ id: target.id, sequence: current.sequence });
  }

  if (isLoading) return <LoadingBlock rows={6} />;

  return (
    <div>
      <PageHeader
        title="Agent Cart"
        description="The agents you have selected, in the order they will run. Build them into a flow to configure conditions, approval gates and model policy."
        actions={
          <Link
            to="/marketplace"
            className="inline-flex h-9 items-center gap-2 rounded border border-line-strong bg-surface px-3.5 text-sm font-medium text-ink transition-colors hover:bg-surface-muted"
          >
            Browse marketplace
          </Link>
        }
      />

      {!items.length ? (
        <Card>
          <EmptyState
            icon={<ShoppingCart className="h-5 w-5" />}
            title="No agents selected yet"
            description="Add agents from the marketplace to compose a quality engineering workflow."
            action={
              <Link
                to="/marketplace"
                className="inline-flex h-9 items-center gap-2 rounded border border-navy-700 bg-navy-700 px-4 text-sm font-medium text-ink-inverse hover:bg-navy-800"
              >
                Open marketplace <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            }
          />
        </Card>
      ) : (
        <div className="grid gap-5 lg:grid-cols-3">
          <div className="space-y-3 lg:col-span-2">
            <p className="text-sm text-ink-secondary">
              {items.length} agent{items.length === 1 ? '' : 's'} selected · executes top to bottom
            </p>

            {items.map((item, index) => (
              <Card key={item.id}>
                <CardBody className="flex items-start gap-4 p-4">
                  <div className="flex flex-col items-center gap-1 pt-0.5">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-navy-700 text-2xs font-semibold text-white">
                      {index + 1}
                    </span>
                    <div className="flex flex-col">
                      <button
                        type="button"
                        onClick={() => move(index, -1)}
                        disabled={index === 0}
                        aria-label={`Move ${item.agent?.name} earlier`}
                        className="rounded p-0.5 text-ink-tertiary hover:bg-surface-sunken hover:text-ink disabled:opacity-30"
                      >
                        <ArrowUp className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => move(index, 1)}
                        disabled={index === items.length - 1}
                        aria-label={`Move ${item.agent?.name} later`}
                        className="rounded p-0.5 text-ink-tertiary hover:bg-surface-sunken hover:text-ink disabled:opacity-30"
                      >
                        <ArrowDown className="h-3 w-3" />
                      </button>
                    </div>
                  </div>

                  <AgentIcon name={item.agent?.icon} className="h-9 w-9 shrink-0" />

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link
                        to={`/marketplace/${item.agent_id}`}
                        className="text-md font-semibold text-ink hover:text-brand-600"
                      >
                        {item.agent?.name}
                      </Link>
                      <Badge tone={TONE_BY_RISK[item.agent?.risk_level ?? 'low'] ?? 'neutral'}>
                        {item.agent?.risk_level} risk
                      </Badge>
                      {item.agent?.requires_approval ? (
                        <Badge tone="warning">
                          <ShieldAlert className="h-3 w-3" /> Approval gate
                        </Badge>
                      ) : null}
                    </div>
                    <p className="mt-1 line-clamp-2 text-sm text-ink-secondary">
                      {item.agent?.summary ?? item.agent?.description}
                    </p>
                    <p className="mt-1.5 text-xs text-ink-tertiary">
                      {item.agent?.category} · {approximateCost(item.agent?.avg_cost_usd ?? 0)} per run
                    </p>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => remove.mutate(item.id)}
                    aria-label={`Remove ${item.agent?.name} from the cart`}
                    className="text-ink-tertiary hover:text-danger-text"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </CardBody>
              </Card>
            ))}
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader title="Build flow" description="Turn the selection into an editable workflow" />
              <CardBody className="space-y-4">
                <Field label="Flow name" htmlFor="flow-name" required>
                  <Input
                    id="flow-name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="e.g. Payment release verification"
                  />
                </Field>
                <Field label="Description" htmlFor="flow-description" hint="Optional. Explains what the flow is for.">
                  <Textarea
                    id="flow-description"
                    rows={3}
                    value={description}
                    onChange={(event) => setDescription(event.target.value)}
                    placeholder="What this flow achieves and when to run it"
                  />
                </Field>

                {error ? (
                  <p role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2 text-sm text-danger-text">
                    {error}
                  </p>
                ) : null}

                <Button
                  variant="primary"
                  className="w-full"
                  disabled={!name.trim()}
                  loading={buildFlow.isPending}
                  onClick={() => {
                    setError(null);
                    buildFlow.mutate();
                  }}
                  icon={<Workflow className="h-3.5 w-3.5" />}
                >
                  Build flow
                </Button>
                <p className="text-xs text-ink-tertiary">
                  Creates a draft flow wired in this order. You can then add conditions, approval gates
                  and branching in the Flow Builder.
                </p>
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Selection summary" />
              <CardBody className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-ink-secondary">Agents</span>
                  <span className="tabular font-medium text-ink">{items.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-ink-secondary">Estimated cost per run</span>
                  <span className="tabular font-medium text-ink">{formatCurrency(estimatedCost, 3)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-ink-secondary">Approval gates</span>
                  <span className={cn('tabular font-medium', approvalCount ? 'text-warning-text' : 'text-ink')}>
                    {approvalCount}
                  </span>
                </div>

                {highestRisk ? (
                  <div className="flex gap-2 rounded border border-warning-border bg-warning-bg px-3 py-2">
                    <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning-text" />
                    <p className="text-xs text-warning-text">
                      This selection includes a high-risk agent. Governance policy will require human
                      approval before it executes.
                    </p>
                  </div>
                ) : null}
              </CardBody>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
