/** Governance centre (spec §18): policies, approval queue, audit trail and AI cost. */
import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip as RechartsTooltip, XAxis, YAxis } from 'recharts';
import { Check, FileClock, Scale, ShieldCheck, Wallet, X } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatCurrency, formatNumber, formatRelativeTime } from '@/hooks';
import { Column, DataTable } from '@/components/DataTable';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, LoadingBlock,
  PageHeader, statusTone, Textarea, TONE_BY_RISK,
} from '@/design-system/primitives';
import type { AuditLogEntry } from '@/types';

type Tab = 'policies' | 'approvals' | 'audit' | 'cost';

const EFFECT_TONE: Record<string, 'danger' | 'warning' | 'success' | 'info'> = {
  deny: 'danger', require_approval: 'warning', warn: 'warning', allow: 'success',
};

export default function GovernancePage() {
  const projectId = useProjectId();
  const queryClient = useQueryClient();
  const [params, setParams] = useSearchParams();
  const tab = (params.get('tab') as Tab) ?? 'policies';
  const [notes, setNotes] = useState<Record<string, string>>({});

  const setTab = (next: Tab) => setParams({ tab: next });

  const { data: policies, isLoading: policiesLoading } = useQuery({
    queryKey: ['policies', projectId],
    queryFn: () => api.listPolicies(projectId ?? undefined),
    enabled: tab === 'policies',
  });

  const { data: approvals, isLoading: approvalsLoading } = useQuery({
    queryKey: ['approvals-all', projectId],
    queryFn: () => api.listApprovals({ project_id: projectId!, limit: 60 }),
    enabled: Boolean(projectId) && tab === 'approvals',
  });

  const { data: audit, isLoading: auditLoading } = useQuery({
    queryKey: ['audit', projectId],
    queryFn: () => api.listAudit({ project_id: projectId!, limit: 100 }),
    enabled: Boolean(projectId) && tab === 'audit',
  });

  const { data: cost } = useQuery({
    queryKey: ['llm-usage', projectId],
    queryFn: () => api.llmUsage(projectId!, 45),
    enabled: Boolean(projectId) && tab === 'cost',
  });

  const togglePolicy = useMutation({
    mutationFn: ({ id, enabled }: { id: string; enabled: boolean }) =>
      api.updatePolicy(id, { is_enabled: enabled }),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['policies', projectId] }),
  });

  const decide = useMutation({
    mutationFn: ({ id, decision }: { id: string; decision: 'approve' | 'reject' }) =>
      api.decideApproval(id, decision, notes[id]),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['approvals-all', projectId] });
      void queryClient.invalidateQueries({ queryKey: ['approvals', projectId, 'pending'] });
    },
  });

  const auditColumns: Column<AuditLogEntry>[] = [
    { key: 'when', header: 'When', render: (row) => <span className="text-ink-secondary">{formatRelativeTime(row.created_at)}</span> },
    { key: 'actor', header: 'Who', render: (row) => (
      <div>
        <p className="truncate text-sm text-ink">{row.actor}</p>
        <p className="text-2xs text-ink-tertiary">{row.actor_type}</p>
      </div>
    )},
    { key: 'action', header: 'What', render: (row) => <code className="font-mono text-xs text-ink">{row.action}</code> },
    { key: 'entity', header: 'Entity', render: (row) => (
      <div>
        <p className="truncate text-sm text-ink-secondary">{row.entity_label ?? row.entity_type}</p>
        <p className="text-2xs text-ink-tertiary">{row.entity_type}</p>
      </div>
    )},
    { key: 'outcome', header: 'Outcome', render: (row) => <Badge tone={statusTone(row.outcome)}>{row.outcome}</Badge> },
    { key: 'model', header: 'Model', render: (row) => row.model_used ? <code className="font-mono text-2xs text-ink-tertiary">{row.model_used}</code> : <span className="text-ink-tertiary">—</span> },
    { key: 'confidence', header: 'Confidence', numeric: true, render: (row) => row.confidence !== null && row.confidence !== undefined ? <span className="text-ink-secondary">{(row.confidence * 100).toFixed(0)}%</span> : <span className="text-ink-tertiary">—</span> },
    { key: 'policy', header: 'Policy', render: (row) => {
      const effect = row.policy_result?.effect as string | undefined;
      return effect ? <Badge tone={EFFECT_TONE[effect] ?? 'neutral'}>{effect.replace(/_/g, ' ')}</Badge> : <span className="text-ink-tertiary">—</span>;
    }},
  ];

  const pending = (approvals?.items ?? []).filter((item) => item.status === 'pending');
  const decided = (approvals?.items ?? []).filter((item) => item.status !== 'pending');

  return (
    <div>
      <PageHeader
        title="Governance"
        description="Policies that constrain what agents may do, the approvals they trigger, and a complete audit trail of every AI action."
      />

      <div className="mb-5 flex gap-1 border-b border-line" role="tablist">
        {([
          ['policies', 'Policies', Scale],
          ['approvals', 'Approvals', ShieldCheck],
          ['audit', 'Audit trail', FileClock],
          ['cost', 'AI cost', Wallet],
        ] as const).map(([value, label, Icon]) => (
          <button
            key={value}
            role="tab"
            aria-selected={tab === value}
            onClick={() => setTab(value)}
            className={cn(
              '-mb-px flex items-center gap-2 border-b-2 px-4 py-2 text-sm font-medium transition-colors',
              tab === value ? 'border-brand-500 text-brand-700' : 'border-transparent text-ink-secondary hover:border-line-strong hover:text-ink',
            )}
          >
            <Icon className="h-3.5 w-3.5" />
            {label}
            {value === 'approvals' && pending.length ? (
              <span className="rounded-full bg-danger px-1.5 text-2xs font-semibold text-white">{pending.length}</span>
            ) : null}
          </button>
        ))}
      </div>

      {tab === 'policies' ? (
        policiesLoading ? <LoadingBlock rows={6} /> : (
          <div className="space-y-3">
            {(policies ?? []).map((policy) => (
              <Card key={policy.id}>
                <CardBody className="flex flex-wrap items-start justify-between gap-4 p-5">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-md font-semibold text-ink">{policy.name}</h3>
                      <Badge tone={EFFECT_TONE[policy.effect] ?? 'neutral'}>{policy.effect.replace(/_/g, ' ')}</Badge>
                      <Badge tone="neutral">{policy.policy_type.replace(/_/g, ' ')}</Badge>
                      <Badge tone={TONE_BY_RISK[policy.severity] ?? 'neutral'}>{policy.severity}</Badge>
                      {policy.project_id ? <Badge tone="brand">project</Badge> : <Badge tone="neutral">global</Badge>}
                    </div>
                    <p className="mt-1.5 text-sm text-ink-secondary">{policy.description}</p>

                    {Object.keys(policy.conditions ?? {}).length ? (
                      <p className="mt-2 font-mono text-2xs text-ink-tertiary">
                        when {JSON.stringify(policy.conditions)}
                      </p>
                    ) : null}

                    <p className="mt-2 text-xs text-ink-tertiary">
                      Enforced {policy.enforcement_count} time{policy.enforcement_count === 1 ? '' : 's'}
                      {policy.last_enforced_at ? ` · last ${formatRelativeTime(policy.last_enforced_at)}` : ''}
                    </p>
                  </div>

                  <label className="flex shrink-0 items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={policy.is_enabled}
                      onChange={(event) => togglePolicy.mutate({ id: policy.id, enabled: event.target.checked })}
                      className="h-4 w-4 rounded border-line-strong text-brand-500 focus:ring-brand-500"
                      aria-label={`${policy.is_enabled ? 'Disable' : 'Enable'} ${policy.name}`}
                    />
                    <span className={policy.is_enabled ? 'text-success-text' : 'text-ink-tertiary'}>
                      {policy.is_enabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </label>
                </CardBody>
              </Card>
            ))}
          </div>
        )
      ) : null}

      {tab === 'approvals' ? (
        approvalsLoading ? <LoadingBlock rows={6} /> : (
          <div className="space-y-5">
            <Card>
              <CardHeader title="Awaiting decision" description={`${pending.length} request${pending.length === 1 ? '' : 's'}`} />
              <CardBody className="p-0">
                {pending.length ? (
                  <ul className="divide-y divide-line-subtle">
                    {pending.map((approval) => (
                      <li key={approval.id} className="px-5 py-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <h4 className="text-sm font-semibold text-ink">{approval.title}</h4>
                              <Badge tone={TONE_BY_RISK[approval.risk_level] ?? 'neutral'}>{approval.risk_level} risk</Badge>
                              <Badge tone="neutral">{approval.required_role.replace(/_/g, ' ')}</Badge>
                            </div>
                            <p className="mt-1 text-sm text-ink-secondary">{approval.reason}</p>
                            <p className="mt-1 text-xs text-ink-tertiary">
                              Requested {formatRelativeTime(approval.created_at)}
                              {approval.run_id ? (
                                <>
                                  {' · '}
                                  <Link to={`/runs/${approval.run_id}`} className="text-brand-600 hover:text-brand-700">
                                    view run
                                  </Link>
                                </>
                              ) : null}
                            </p>
                            <Textarea
                              rows={2}
                              className="mt-2 text-xs"
                              placeholder="Decision notes (optional)"
                              aria-label={`Notes for ${approval.title}`}
                              value={notes[approval.id] ?? ''}
                              onChange={(event) => setNotes((current) => ({ ...current, [approval.id]: event.target.value }))}
                            />
                          </div>

                          <div className="flex shrink-0 gap-2">
                            <Button
                              size="sm"
                              variant="secondary"
                              icon={<X className="h-3 w-3" />}
                              loading={decide.isPending && decide.variables?.id === approval.id}
                              onClick={() => decide.mutate({ id: approval.id, decision: 'reject' })}
                            >
                              Reject
                            </Button>
                            <Button
                              size="sm"
                              variant="primary"
                              icon={<Check className="h-3 w-3" />}
                              loading={decide.isPending && decide.variables?.id === approval.id}
                              onClick={() => decide.mutate({ id: approval.id, decision: 'approve' })}
                            >
                              Approve
                            </Button>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState icon={<ShieldCheck className="h-5 w-5" />} title="Nothing awaiting approval" description="Approval gates appear here when a governed action needs a human." />
                )}
              </CardBody>
            </Card>

            {decided.length ? (
              <Card>
                <CardHeader title="Decision history" />
                <CardBody className="p-0">
                  <ul className="divide-y divide-line-subtle">
                    {decided.map((approval) => (
                      <li key={approval.id} className="flex items-center gap-3 px-5 py-3">
                        <Badge tone={statusTone(approval.status)}>{approval.status}</Badge>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm text-ink">{approval.title}</p>
                          <p className="text-xs text-ink-tertiary">
                            {approval.decided_by} · {formatRelativeTime(approval.decided_at)}
                            {approval.decision_notes ? ` · ${approval.decision_notes}` : ''}
                          </p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </CardBody>
              </Card>
            ) : null}
          </div>
        )
      ) : null}

      {tab === 'audit' ? (
        <Card>
          <CardHeader title="Audit trail" description={`${audit?.total ?? 0} recorded actions — who, what, when, why, with what model and policy outcome`} />
          <DataTable
            columns={auditColumns}
            rows={audit?.items ?? []}
            keyOf={(row) => row.id}
            loading={auditLoading}
            caption="Audit log"
            emptyTitle="No audit records"
            minWidth={1000}
          />
        </Card>
      ) : null}

      {tab === 'cost' && cost ? (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <CostStat label="Total spend" value={formatCurrency(cost.total_cost_usd, 4)} detail={`over ${cost.window_days} days`} />
            <CostStat label="Invocations" value={formatNumber(cost.total_calls)} detail="AI calls recorded" />
            <CostStat label="Tokens" value={formatNumber(cost.total_tokens)} detail="prompt + completion" />
            <CostStat label="Average latency" value={`${cost.avg_latency_ms}ms`} detail="per invocation" />
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <CardHeader title="Cost by agent" />
              <CardBody className="pt-2">
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={cost.by_agent.slice(0, 10)} layout="vertical" margin={{ left: 12, right: 16 }}>
                    <CartesianGrid stroke="#E8EEF4" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 11, fill: '#8B95A3' }} tickLine={false} axisLine={false} />
                    <YAxis type="category" dataKey="key" width={150} tick={{ fontSize: 11, fill: '#8B95A3' }} tickLine={false} axisLine={false} />
                    <RechartsTooltip formatter={(value: number) => formatCurrency(value, 4)} />
                    <Bar dataKey="cost_usd" name="Cost" radius={[0, 3, 3, 0]} barSize={13} fill="#145DA0" />
                  </BarChart>
                </ResponsiveContainer>
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Cost by model and capability" />
              <CardBody className="space-y-4">
                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">By model</p>
                  <ul className="space-y-1.5">
                    {cost.by_model.map((entry) => (
                      <li key={entry.key} className="flex items-center justify-between gap-3 text-sm">
                        <code className="truncate font-mono text-xs text-ink">{entry.key}</code>
                        <span className="tabular shrink-0 text-ink-secondary">
                          {formatCurrency(entry.cost_usd, 4)}
                          <span className="ml-2 text-xs text-ink-tertiary">{entry.calls} calls</span>
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="border-t border-line pt-3">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">By capability</p>
                  <ul className="space-y-1.5">
                    {cost.by_capability.map((entry) => (
                      <li key={entry.key} className="flex items-center justify-between gap-3 text-sm">
                        <span className="text-ink-secondary">{entry.key.replace(/_/g, ' ')}</span>
                        <span className="tabular text-ink-secondary">{formatCurrency(entry.cost_usd, 4)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function CostStat({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p className="tabular mt-1 text-2xl font-semibold text-ink">{value}</p>
        <p className="mt-1 text-xs text-ink-tertiary">{detail}</p>
      </CardBody>
    </Card>
  );
}
