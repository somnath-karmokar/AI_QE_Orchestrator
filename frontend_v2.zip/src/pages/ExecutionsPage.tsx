/** Test Execution Center (spec §12): configure and launch runs, watch progress. */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PlayCircle, Rocket } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId, formatDuration, formatPercent, formatRelativeTime } from '@/hooks';
import { useWorkspace } from '@/store';
import { Column, DataTable } from '@/components/DataTable';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, Field, PageHeader,
  ProgressBar, Select, statusTone,
} from '@/design-system/primitives';
import type { ExecutionSummary } from '@/types';

export default function ExecutionsPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { environments, environmentId, project } = useWorkspace();

  const [suiteType, setSuiteType] = useState('regression');
  const [browser, setBrowser] = useState('chromium');
  const [module, setModule] = useState('');
  const [parallelism, setParallelism] = useState(4);
  const [error, setError] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['executions', projectId],
    queryFn: () => api.listExecutions({ project_id: projectId!, limit: 60 }),
    enabled: Boolean(projectId),
    refetchInterval: 8000,
  });

  const start = useMutation({
    mutationFn: () =>
      api.startExecution({
        project_id: projectId,
        suite_type: suiteType,
        browser,
        headless: true,
        parallelism,
        environment_id: environmentId ?? undefined,
        module: module || undefined,
      }),
    onSuccess: (execution) => {
      void queryClient.invalidateQueries({ queryKey: ['executions', projectId] });
      navigate(`/executions/${execution.id}`);
    },
    onError: (caught) =>
      setError(caught instanceof ApiError ? caught.message : 'Could not start the execution.'),
  });

  const columns: Column<ExecutionSummary>[] = [
    {
      key: 'name',
      header: 'Execution',
      render: (execution) => (
        <div>
          <Link
            to={`/executions/${execution.id}`}
            className="font-medium text-ink hover:text-brand-600"
            onClick={(event) => event.stopPropagation()}
          >
            {execution.name}
          </Link>
          <p className="mt-0.5 text-xs text-ink-tertiary">
            {execution.suite_type} · {execution.browser} · {execution.mode}
          </p>
        </div>
      ),
    },
    { key: 'status', header: 'Status', render: (e) => <Badge tone={statusTone(e.status)} dot>{e.status}</Badge> },
    {
      key: 'results',
      header: 'Results',
      render: (execution) => (
        <div className="flex items-center gap-1.5">
          <ResultChip label="passed" count={execution.passed} tone="success" />
          <ResultChip label="failed" count={execution.failed} tone="danger" />
          <ResultChip label="flaky" count={execution.flaky} tone="warning" />
          <ResultChip label="skipped" count={execution.skipped} tone="neutral" />
        </div>
      ),
    },
    {
      key: 'pass_rate',
      header: 'Pass rate',
      render: (execution) => (
        <div className="flex items-center gap-2">
          <ProgressBar
            value={execution.pass_rate}
            tone={execution.pass_rate > 0.9 ? 'success' : execution.pass_rate > 0.7 ? 'warning' : 'danger'}
            className="w-16"
            label={`${execution.name} pass rate`}
          />
          <span className="tabular text-xs text-ink-secondary">{formatPercent(execution.pass_rate, 0)}</span>
        </div>
      ),
    },
    { key: 'duration', header: 'Duration', numeric: true, render: (e) => <span className="text-ink-secondary">{formatDuration(e.duration_ms)}</span> },
    { key: 'when', header: 'Started', render: (e) => <span className="text-ink-secondary">{formatRelativeTime(e.started_at ?? e.created_at)}</span> },
  ];

  const modules = project?.modules ?? [];

  return (
    <div>
      <PageHeader
        title="Execution Center"
        description="Launch automated suites, watch them run live and inspect every failure with its evidence."
      />

      <div className="grid gap-5 lg:grid-cols-[300px_1fr]">
        <Card className="self-start">
          <CardHeader title="New execution" icon={<Rocket className="h-4 w-4" />} />
          <CardBody className="space-y-4">
            <Field label="Suite" htmlFor="suite">
              <Select id="suite" value={suiteType} onChange={(event) => setSuiteType(event.target.value)}>
                <option value="regression">Regression</option>
                <option value="smoke">Smoke (critical and high only)</option>
                <option value="functional">Functional</option>
              </Select>
            </Field>

            <Field label="Module" htmlFor="module" hint="Leave blank to run every module.">
              <Select id="module" value={module} onChange={(event) => setModule(event.target.value)}>
                <option value="">All modules</option>
                {modules.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Browser" htmlFor="browser">
              <Select id="browser" value={browser} onChange={(event) => setBrowser(event.target.value)}>
                <option value="chromium">Chromium</option>
                <option value="firefox">Firefox</option>
                <option value="webkit">WebKit</option>
              </Select>
            </Field>

            <Field label="Parallel workers" htmlFor="parallelism">
              <Select id="parallelism" value={parallelism} onChange={(event) => setParallelism(Number(event.target.value))}>
                {[1, 2, 4, 8].map((value) => (
                  <option key={value} value={value}>
                    {value}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Environment" htmlFor="environment">
              <Select id="environment" value={environmentId ?? ''} disabled>
                {environments.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </Select>
            </Field>
            <p className="-mt-2 text-xs text-ink-tertiary">Change the environment from the header selector.</p>

            {error ? (
              <p role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2 text-sm text-danger-text">
                {error}
              </p>
            ) : null}

            <Button
              variant="primary"
              className="w-full"
              loading={start.isPending}
              onClick={() => {
                setError(null);
                start.mutate();
              }}
              icon={<PlayCircle className="h-3.5 w-3.5" />}
            >
              Start execution
            </Button>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Recent executions" description={`${data?.total ?? 0} recorded`} />
          <DataTable
            columns={columns}
            rows={data?.items ?? []}
            keyOf={(execution) => execution.id}
            loading={isLoading}
            onRowClick={(execution) => navigate(`/executions/${execution.id}`)}
            caption="Execution history"
            emptyIcon={<PlayCircle className="h-5 w-5" />}
            emptyTitle="No executions yet"
            emptyDescription="Start a suite to see results here."
            minWidth={820}
          />
        </Card>
      </div>
    </div>
  );
}

function ResultChip({ label, count, tone }: { label: string; count: number; tone: 'success' | 'danger' | 'warning' | 'neutral' }) {
  if (!count) return null;
  const styles = {
    success: 'bg-success-bg text-success-text border-success-border',
    danger: 'bg-danger-bg text-danger-text border-danger-border',
    warning: 'bg-warning-bg text-warning-text border-warning-border',
    neutral: 'bg-surface-sunken text-ink-secondary border-line',
  }[tone];
  return (
    <span className={cn('tabular rounded border px-1.5 py-0.5 text-2xs font-medium', styles)} title={`${count} ${label}`}>
      {count} {label}
    </span>
  );
}
