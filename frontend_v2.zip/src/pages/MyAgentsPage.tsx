/** Custom agents owned by this project, with their lifecycle state. */
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Bot, Plus } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatCurrency, formatPercent } from '@/hooks';
import { AgentIcon } from '@/components/AgentIcon';
import { Column, DataTable } from '@/components/DataTable';
import { Badge, Card, CardHeader, PageHeader, statusTone, TONE_BY_RISK } from '@/design-system/primitives';
import type { AgentSummary } from '@/types';

export default function MyAgentsPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery({
    queryKey: ['agents-mine', projectId],
    queryFn: () => api.listAgents({ project_id: projectId ?? undefined, is_builtin: false, limit: 100 }),
    enabled: Boolean(projectId),
  });

  const { data: builtins } = useQuery({
    queryKey: ['agents-builtin', projectId],
    queryFn: () => api.listAgents({ project_id: projectId ?? undefined, is_builtin: true, limit: 100 }),
    enabled: Boolean(projectId),
  });

  const columns: Column<AgentSummary>[] = [
    {
      key: 'name',
      header: 'Agent',
      render: (agent) => (
        <div className="flex items-center gap-3">
          <AgentIcon name={agent.icon} className="h-8 w-8 shrink-0" />
          <div className="min-w-0">
            <p className="truncate font-medium text-ink">{agent.name}</p>
            <p className="truncate text-xs text-ink-secondary">{agent.summary ?? agent.description}</p>
          </div>
        </div>
      ),
    },
    { key: 'category', header: 'Category', render: (agent) => <span className="text-ink-secondary">{agent.category}</span> },
    { key: 'state', header: 'Lifecycle', render: (agent) => <Badge tone={statusTone(agent.lifecycle_state)}>{agent.lifecycle_state}</Badge> },
    { key: 'version', header: 'Version', render: (agent) => <span className="font-mono text-xs text-ink-secondary">v{agent.version}</span> },
    { key: 'risk', header: 'Risk', render: (agent) => <Badge tone={TONE_BY_RISK[agent.risk_level] ?? 'neutral'}>{agent.risk_level}</Badge> },
    { key: 'runs', header: 'Runs', numeric: true, render: (agent) => <span className="text-ink-secondary">{agent.usage_count}</span> },
    { key: 'success', header: 'Success', numeric: true, render: (agent) => <span className="text-ink-secondary">{formatPercent(agent.success_rate, 0)}</span> },
    { key: 'cost', header: 'Avg cost', numeric: true, render: (agent) => <span className="text-ink-secondary">{formatCurrency(agent.avg_cost_usd, 4)}</span> },
  ];

  return (
    <div>
      <PageHeader
        title="My Agents"
        description="Agents your team has created or cloned. Built-in platform agents are listed below for reference."
        actions={
          <Link
            to="/agents/new"
            className="inline-flex h-9 items-center gap-2 rounded border border-navy-700 bg-navy-700 px-3.5 text-sm font-medium text-ink-inverse hover:bg-navy-800"
          >
            <Plus className="h-3.5 w-3.5" /> Create agent
          </Link>
        }
      />

      <Card className="mb-6">
        <CardHeader title="Custom agents" description={`${data?.total ?? 0} created in this project`} />
        <DataTable
          columns={columns}
          rows={data?.items ?? []}
          keyOf={(agent) => agent.id}
          loading={isLoading}
          onRowClick={(agent) => navigate(`/agents/${agent.id}/edit`)}
          caption="Custom agents"
          emptyIcon={<Bot className="h-5 w-5" />}
          emptyTitle="No custom agents yet"
          emptyDescription="Create one from scratch, or clone a built-in agent and adapt it."
          emptyAction={
            <Link
              to="/agents/new"
              className="inline-flex h-9 items-center rounded border border-navy-700 bg-navy-700 px-4 text-sm font-medium text-ink-inverse hover:bg-navy-800"
            >
              Create agent
            </Link>
          }
          minWidth={900}
        />
      </Card>

      <Card>
        <CardHeader title="Platform agents" description={`${builtins?.total ?? 0} built-in agents available to every project`} />
        <DataTable
          columns={columns}
          rows={builtins?.items ?? []}
          keyOf={(agent) => agent.id}
          onRowClick={(agent) => navigate(`/marketplace/${agent.id}`)}
          caption="Built-in platform agents"
          minWidth={900}
        />
      </Card>
    </div>
  );
}
