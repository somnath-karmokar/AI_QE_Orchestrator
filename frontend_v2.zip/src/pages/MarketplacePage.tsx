/** Agent Marketplace (spec §5): browse, search, filter, inspect and stage agents. */
import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Check, Clock, Plus, Search, ShieldAlert, ShoppingCart, SlidersHorizontal, Sparkles, Star, X,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useDebounced, useProjectId, formatCurrency, formatDuration, formatPercent } from '@/hooks';
import { useSession } from '@/store';
import { AgentIcon } from '@/components/AgentIcon';
import {
  Badge, Button, Card, CardBody, cn, EmptyState, Input, LoadingBlock, PageHeader,
  Select, TONE_BY_RISK, Tooltip,
} from '@/design-system/primitives';
import type { AgentSummary } from '@/types';

const SORTS = [
  { value: 'popular', label: 'Most used' },
  { value: 'rating', label: 'Highest rated' },
  { value: 'name', label: 'Name (A–Z)' },
  { value: 'cost', label: 'Lowest cost' },
  { value: 'recent', label: 'Recently added' },
];

const COST_LABEL: Record<string, string> = { low: 'Low cost', medium: 'Medium cost', high: 'High cost' };

export default function MarketplacePage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const can = useSession((state) => state.can);

  const [search, setSearch] = useState('');
  const [categories, setCategories] = useState<string[]>([]);
  const [risks, setRisks] = useState<string[]>([]);
  const [costs, setCosts] = useState<string[]>([]);
  const [tool, setTool] = useState<string>('');
  const [sort, setSort] = useState('popular');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [feedback, setFeedback] = useState<{ tone: 'success' | 'danger'; message: string } | null>(null);

  const debouncedSearch = useDebounced(search, 300);

  const { data: facets } = useQuery({
    queryKey: ['marketplace-facets', projectId],
    queryFn: () => api.marketplaceFacets(projectId ?? undefined),
    enabled: Boolean(projectId),
  });

  const { data, isLoading } = useQuery({
    queryKey: ['marketplace', projectId, debouncedSearch, categories, risks, costs, tool, sort],
    queryFn: () =>
      api.marketplace({
        project_id: projectId ?? undefined,
        search: debouncedSearch || undefined,
        category: categories.length ? categories : undefined,
        risk_level: risks.length ? risks : undefined,
        cost_tier: costs.length ? costs : undefined,
        tool: tool || undefined,
        sort,
        limit: 60,
      }),
    enabled: Boolean(projectId),
  });

  const { data: cart } = useQuery({
    queryKey: ['cart', projectId],
    queryFn: () => api.getCart(projectId!),
    enabled: Boolean(projectId),
  });

  const inCart = useMemo(() => new Set((cart ?? []).map((item) => item.agent_id)), [cart]);

  const addToCart = useMutation({
    mutationFn: (agent: AgentSummary) => api.addToCart({ agent_id: agent.id, project_id: projectId! }),
    onSuccess: (_result, agent) => {
      void queryClient.invalidateQueries({ queryKey: ['cart', projectId] });
      setFeedback({ tone: 'success', message: `${agent.name} added to your agent cart.` });
    },
    onError: (error) =>
      setFeedback({
        tone: 'danger',
        message: error instanceof ApiError ? error.message : 'Could not add the agent.',
      }),
  });

  const activeFilters = categories.length + risks.length + costs.length + (tool ? 1 : 0);

  function toggle(list: string[], setList: (next: string[]) => void, value: string) {
    setList(list.includes(value) ? list.filter((item) => item !== value) : [...list, value]);
  }

  function clearFilters() {
    setCategories([]);
    setRisks([]);
    setCosts([]);
    setTool('');
  }

  return (
    <div>
      <PageHeader
        title="Agent Marketplace"
        description="Discover quality engineering agents, review what they do and how they behave, then compose them into a governed flow."
        actions={
          <>
            <Link
              to="/cart"
              className="inline-flex h-9 items-center gap-2 rounded border border-line-strong bg-surface px-3.5 text-sm font-medium text-ink transition-colors hover:bg-surface-muted"
            >
              <ShoppingCart className="h-3.5 w-3.5" />
              Agent Cart
              {cart?.length ? (
                <span className="rounded-full bg-brand-500 px-1.5 py-0.5 text-2xs font-semibold text-white">
                  {cart.length}
                </span>
              ) : null}
            </Link>
            {can('agent:write') ? (
              <Link
                to="/agents/new"
                className="inline-flex h-9 items-center gap-2 rounded border border-navy-700 bg-navy-700 px-3.5 text-sm font-medium text-ink-inverse transition-colors hover:bg-navy-800"
              >
                <Plus className="h-3.5 w-3.5" />
                Create agent
              </Link>
            ) : null}
          </>
        }
      />

      {feedback ? (
        <div
          role="status"
          className={cn(
            'mb-4 flex items-center justify-between gap-3 rounded-lg border px-4 py-2.5 text-sm',
            feedback.tone === 'success'
              ? 'border-success-border bg-success-bg text-success-text'
              : 'border-danger-border bg-danger-bg text-danger-text',
          )}
        >
          <span className="flex items-center gap-2">
            {feedback.tone === 'success' ? <Check className="h-3.5 w-3.5" /> : <ShieldAlert className="h-3.5 w-3.5" />}
            {feedback.message}
          </span>
          <div className="flex items-center gap-2">
            {feedback.tone === 'success' ? (
              <Button size="sm" variant="secondary" onClick={() => navigate('/cart')}>
                Open cart
              </Button>
            ) : null}
            <button onClick={() => setFeedback(null)} aria-label="Dismiss" className="rounded p-1 hover:bg-black/5">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      ) : null}

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <div className="relative min-w-[240px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" aria-hidden />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search agents by name, purpose or capability…"
            aria-label="Search agents"
            className="pl-9"
          />
        </div>
        <Button
          variant={filtersOpen || activeFilters ? 'subtle' : 'secondary'}
          icon={<SlidersHorizontal className="h-3.5 w-3.5" />}
          onClick={() => setFiltersOpen((open) => !open)}
          aria-expanded={filtersOpen}
        >
          Filters
          {activeFilters ? (
            <span className="ml-1 rounded-full bg-brand-500 px-1.5 text-2xs font-semibold text-white">
              {activeFilters}
            </span>
          ) : null}
        </Button>
        <Select aria-label="Sort agents" className="w-44" value={sort} onChange={(event) => setSort(event.target.value)}>
          {SORTS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </Select>
      </div>

      {filtersOpen ? (
        <Card className="mb-5">
          <CardBody className="space-y-4">
            <FilterGroup
              label="Category"
              options={(facets?.categories ?? []).filter((item) => item.count > 0).map((item) => ({ value: item.key, label: item.key, count: item.count }))}
              selected={categories}
              onToggle={(value) => toggle(categories, setCategories, value)}
            />
            <div className="grid gap-4 sm:grid-cols-3">
              <FilterGroup
                label="Risk level"
                options={Object.entries(facets?.risk_levels ?? {}).map(([value, count]) => ({ value, label: value, count }))}
                selected={risks}
                onToggle={(value) => toggle(risks, setRisks, value)}
              />
              <FilterGroup
                label="Cost"
                options={Object.entries(facets?.cost_tiers ?? {}).map(([value, count]) => ({ value, label: COST_LABEL[value] ?? value, count }))}
                selected={costs}
                onToggle={(value) => toggle(costs, setCosts, value)}
              />
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Tool</p>
                <Select aria-label="Filter by tool" value={tool} onChange={(event) => setTool(event.target.value)}>
                  <option value="">Any tool</option>
                  {Object.entries(facets?.tools ?? {}).map(([key, count]) => (
                    <option key={key} value={key}>
                      {key} ({count})
                    </option>
                  ))}
                </Select>
              </div>
            </div>
            {activeFilters ? (
              <div className="flex justify-end border-t border-line pt-3">
                <Button size="sm" variant="ghost" onClick={clearFilters}>
                  Clear all filters
                </Button>
              </div>
            ) : null}
          </CardBody>
        </Card>
      ) : null}

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <Card key={index}>
              <LoadingBlock rows={4} />
            </Card>
          ))}
        </div>
      ) : data?.items.length ? (
        <>
          <p className="mb-3 text-sm text-ink-secondary">
            {data.total} agent{data.total === 1 ? '' : 's'}
            {activeFilters ? ' matching your filters' : ' available'}
          </p>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {data.items.map((agent) => (
              <AgentCard
                key={agent.id}
                agent={agent}
                inCart={inCart.has(agent.id)}
                onAdd={() => addToCart.mutate(agent)}
                adding={addToCart.isPending && addToCart.variables?.id === agent.id}
              />
            ))}
          </div>
        </>
      ) : (
        <Card>
          <EmptyState
            icon={<Search className="h-5 w-5" />}
            title="No agents match those filters"
            description="Try a broader search term or clear some filters."
            action={activeFilters ? <Button onClick={clearFilters}>Clear filters</Button> : undefined}
          />
        </Card>
      )}
    </div>
  );
}

function FilterGroup({
  label,
  options,
  selected,
  onToggle,
}: {
  label: string;
  options: { value: string; label: string; count: number }[];
  selected: string[];
  onToggle: (value: string) => void;
}) {
  return (
    <fieldset>
      <legend className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">{label}</legend>
      <div className="flex flex-wrap gap-1.5">
        {options.map((option) => {
          const active = selected.includes(option.value);
          return (
            <button
              key={option.value}
              type="button"
              aria-pressed={active}
              onClick={() => onToggle(option.value)}
              className={cn(
                'rounded border px-2.5 py-1 text-xs font-medium transition-colors',
                active
                  ? 'border-brand-500 bg-brand-50 text-brand-700'
                  : 'border-line-strong bg-surface text-ink-secondary hover:border-ink-tertiary hover:text-ink',
              )}
            >
              {option.label}
              <span className="ml-1.5 text-ink-tertiary">{option.count}</span>
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

function AgentCard({
  agent,
  inCart,
  onAdd,
  adding,
}: {
  agent: AgentSummary;
  inCart: boolean;
  onAdd: () => void;
  adding: boolean;
}) {
  return (
    <Card className="flex flex-col transition-shadow hover:shadow-raised">
      <CardBody className="flex flex-1 flex-col p-5">
        <div className="flex items-start gap-3">
          <AgentIcon name={agent.icon} className="h-9 w-9 shrink-0" />
          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-2">
              <Link
                to={`/marketplace/${agent.id}`}
                className="truncate text-md font-semibold text-ink hover:text-brand-600"
              >
                {agent.name}
              </Link>
              {agent.rating > 0 ? (
                <span className="flex shrink-0 items-center gap-1 text-xs text-ink-secondary">
                  <Star className="h-3 w-3 fill-warning text-warning" aria-hidden />
                  {agent.rating.toFixed(1)}
                </span>
              ) : null}
            </div>
            <p className="mt-0.5 text-xs text-ink-tertiary">
              {agent.category} · v{agent.version}
            </p>
          </div>
        </div>

        <p className="mt-3 line-clamp-2 flex-1 text-sm leading-relaxed text-ink-secondary">
          {agent.summary ?? agent.description}
        </p>

        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          <Badge tone={TONE_BY_RISK[agent.risk_level] ?? 'neutral'}>{agent.risk_level} risk</Badge>
          <Badge tone="neutral">{COST_LABEL[agent.cost_tier] ?? agent.cost_tier}</Badge>
          {agent.requires_approval ? (
            <Tooltip label="A human must approve before this agent runs">
              <Badge tone="warning">
                <ShieldAlert className="h-3 w-3" /> Approval
              </Badge>
            </Tooltip>
          ) : null}
          {!agent.is_builtin ? <Badge tone="brand">Custom</Badge> : null}
        </div>

        {agent.supported_tools.length ? (
          <div className="mt-3 flex flex-wrap gap-1">
            {agent.supported_tools.slice(0, 4).map((toolName) => (
              <span
                key={toolName}
                className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink-secondary"
              >
                {toolName}
              </span>
            ))}
          </div>
        ) : null}

        <dl className="mt-4 grid grid-cols-3 gap-2 border-t border-line pt-3 text-center">
          <div>
            <dt className="text-2xs text-ink-tertiary">Runs</dt>
            <dd className="tabular text-sm font-medium text-ink">{agent.usage_count}</dd>
          </div>
          <div>
            <dt className="text-2xs text-ink-tertiary">Success</dt>
            <dd className="tabular text-sm font-medium text-ink">{formatPercent(agent.success_rate, 0)}</dd>
          </div>
          <div>
            <dt className="text-2xs text-ink-tertiary">Avg cost</dt>
            <dd className="tabular text-sm font-medium text-ink">{formatCurrency(agent.avg_cost_usd, 3)}</dd>
          </div>
        </dl>

        <p className="mt-2 flex items-center justify-center gap-1 text-2xs text-ink-tertiary">
          <Clock className="h-3 w-3" /> {formatDuration(agent.avg_duration_ms)} typical duration
        </p>
      </CardBody>

      <div className="flex gap-2 border-t border-line px-5 py-3">
        <Link
          to={`/marketplace/${agent.id}`}
          className="inline-flex h-8 flex-1 items-center justify-center rounded border border-line-strong bg-surface px-3 text-xs font-medium text-ink transition-colors hover:bg-surface-muted"
        >
          View details
        </Link>
        <Button
          size="sm"
          variant={inCart ? 'subtle' : 'primary'}
          className="flex-1"
          disabled={inCart}
          loading={adding}
          onClick={onAdd}
          icon={inCart ? <Check className="h-3.5 w-3.5" /> : <Sparkles className="h-3.5 w-3.5" />}
        >
          {inCart ? 'In flow' : 'Add to flow'}
        </Button>
      </div>
    </Card>
  );
}
