/**
 * Onboarding an API user, and looking after the keys already issued.
 *
 * Issuing a key is the moment a third party gains standing on this platform, so
 * the form makes the two questions that matter explicit rather than defaulted:
 * what it may *do* (scopes) and what it may *reach* (this project, or nothing
 * until named). The token is shown exactly once, here, and never again.
 */
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle, KeyRound, Plug, RefreshCw, ShieldCheck, Trash2, UserPlus,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId, formatRelativeTime } from '@/hooks';
import { useSession } from '@/store';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, CopyButton, EmptyState, Field,
  Input, LoadingBlock, PageHeader, Select,
} from '@/design-system/primitives';
import type { IntegrationClientCreated, IntegrationClientOut } from '@/types';

const SCOPES: { scope: string; label: string; hint: string }[] = [
  { scope: 'catalog:read', label: 'Discover', hint: 'List the flows and agents this key may invoke' },
  { scope: 'flows:run', label: 'Run flows', hint: 'Start a flow run' },
  { scope: 'agents:run', label: 'Run agents', hint: 'Invoke a single agent' },
  { scope: 'runs:read', label: 'Read runs', hint: 'Status, result and guardrail outcome' },
  { scope: 'runs:cancel', label: 'Cancel runs', hint: 'Cancel a run this key started' },
  { scope: 'approvals:read', label: 'See approvals', hint: 'Approvals blocking this key’s runs' },
  { scope: 'runs:logs', label: 'Read run logs', hint: 'Governance log, audit feed and metrics of this key’s runs' },
];

const DEFAULT_SCOPES = ['catalog:read', 'flows:run', 'runs:read', 'approvals:read'];

function KeyReveal({ created }: { created: IntegrationClientCreated }) {
  return (
    <Card className="border-success-border bg-success-bg/40">
      <CardBody className="space-y-3">
        <p className="flex items-center gap-2 text-sm font-semibold text-success-text">
          <ShieldCheck className="h-4 w-4" aria-hidden />
          {created.name} is onboarded. Copy the key now — it is never shown again.
        </p>
        <div className="flex items-center gap-2">
          <code className="min-w-0 flex-1 truncate rounded border border-line bg-surface px-3 py-2 font-mono text-xs text-ink">
            {created.token}
          </code>
          <CopyButton text={created.token} label="Copy the API key" />
        </div>
        <p className="text-xs text-ink-secondary">
          Only a hash is stored. If it is lost, rotate the key rather than reissuing it, so the audit
          trail keeps one identity for this integration.
        </p>
      </CardBody>
    </Card>
  );
}

function reach(client: IntegrationClientOut): { label: string; tone: 'info' | 'neutral' | 'warning' } {
  if (client.grants_all_flows && client.grants_all_agents) {
    return { label: 'All flows and agents', tone: 'info' };
  }
  if (client.grants_all_flows) return { label: 'All flows', tone: 'info' };
  if (client.grants_all_agents) return { label: 'All agents', tone: 'info' };

  const named = client.allowed_flow_ids.length + client.allowed_agent_keys.length;
  return named
    ? { label: `${named} named`, tone: 'neutral' }
    : { label: 'Nothing yet', tone: 'warning' };
}

export default function ApiAccessPage() {
  const projectId = useProjectId();
  const queryClient = useQueryClient();
  const can = useSession((state) => state.can);
  const mayManage = can('governance:write');

  const [name, setName] = useState('');
  const [platform, setPlatform] = useState('');
  const [scopes, setScopes] = useState<string[]>(DEFAULT_SCOPES);
  const [wholeProject, setWholeProject] = useState(true);
  const [expiresInDays, setExpiresInDays] = useState('365');
  const [rateLimit, setRateLimit] = useState('60');
  const [created, setCreated] = useState<IntegrationClientCreated | null>(null);
  const [problem, setProblem] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['integration-clients', projectId],
    queryFn: () => api.integrationClients(projectId!),
    enabled: Boolean(projectId),
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['integration-clients', projectId] });
  const fail = (error: unknown) =>
    setProblem(error instanceof ApiError ? error.message : 'That did not work.');

  const onboard = useMutation({
    mutationFn: () =>
      api.createIntegrationClient({
        project_id: projectId!,
        name: name.trim(),
        platform: platform.trim() || null,
        scopes,
        grants_all_flows: wholeProject,
        grants_all_agents: wholeProject,
        rate_limit_per_minute: Number(rateLimit) || 60,
        expires_in_days: expiresInDays ? Number(expiresInDays) : null,
      }),
    onSuccess: (client) => {
      setCreated(client);
      setProblem(null);
      setName('');
      setPlatform('');
      void refresh();
    },
    onError: fail,
  });

  const rotate = useMutation({
    mutationFn: (id: string) => api.rotateIntegrationClient(id),
    onSuccess: (client) => {
      setCreated(client);
      setProblem(null);
      void refresh();
    },
    onError: fail,
  });

  const revoke = useMutation({
    mutationFn: (id: string) => api.revokeIntegrationClient(id),
    onSuccess: () => {
      setProblem(null);
      void refresh();
    },
    onError: fail,
  });

  const clients = data?.items ?? [];

  return (
    <div>
      <PageHeader
        title="API access"
        description="Keys that let another platform call this project's agents and flows. Each one is a named identity in the audit trail."
        actions={
          <a
            href="/portal"
            target="_blank"
            rel="noreferrer"
            className="inline-flex h-9 items-center gap-2 rounded border border-line-strong bg-surface px-3.5 text-sm font-medium text-ink hover:bg-surface-muted"
          >
            <Plug className="h-3.5 w-3.5" aria-hidden /> Open the API user portal
          </a>
        }
      />

      {problem ? (
        <p className="mb-4 flex items-center gap-2 rounded-lg border border-danger-border bg-danger-bg px-4 py-2.5 text-sm text-danger-text">
          <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden />
          {problem}
        </p>
      ) : null}

      {created ? (
        <div className="mb-5">
          <KeyReveal created={created} />
        </div>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <Card>
          <CardHeader
            title="Issued keys"
            description={`${clients.length} in this project`}
            icon={<KeyRound className="h-4 w-4" />}
          />
          <CardBody className="p-0">
            {isLoading ? (
              <div className="p-5">
                <LoadingBlock rows={4} />
              </div>
            ) : clients.length === 0 ? (
              <EmptyState
                icon={<KeyRound className="h-5 w-5" />}
                title="No API users yet"
                description="Onboard one to let another platform call this project's agents and flows."
              />
            ) : (
              <ul className="divide-y divide-line-subtle">
                {clients.map((client) => {
                  const scope = reach(client);
                  const expired =
                    Boolean(client.expires_at) && new Date(client.expires_at!) < new Date();
                  return (
                    <li key={client.id} className="px-5 py-4">
                      <div className="flex flex-wrap items-start gap-3">
                        <div className="min-w-0 flex-1">
                          <p className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-semibold text-ink">{client.name}</span>
                            <code className="font-mono text-2xs text-ink-tertiary">…{client.token_hint}</code>
                            {client.platform ? <Badge tone="neutral">{client.platform}</Badge> : null}
                            <Badge tone={scope.tone}>{scope.label}</Badge>
                            {!client.is_active ? (
                              <Badge tone="danger">revoked</Badge>
                            ) : expired ? (
                              <Badge tone="warning">expired</Badge>
                            ) : (
                              <Badge tone="success" dot>
                                active
                              </Badge>
                            )}
                          </p>
                          <p className="mt-1 flex flex-wrap gap-1.5">
                            {client.scopes.map((granted) => (
                              <code
                                key={granted}
                                className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink-secondary"
                              >
                                {granted}
                              </code>
                            ))}
                          </p>
                          <p className="mt-1.5 text-xs text-ink-tertiary">
                            {client.call_count} call{client.call_count === 1 ? '' : 's'}
                            {client.last_used_at
                              ? ` · last used ${formatRelativeTime(client.last_used_at)}`
                              : ' · never used'}
                            {client.expires_at
                              ? ` · expires ${new Date(client.expires_at).toLocaleDateString()}`
                              : ' · no expiry'}
                          </p>
                        </div>
                        {mayManage && client.is_active ? (
                          <div className="flex shrink-0 gap-2">
                            <Button
                              size="sm"
                              variant="secondary"
                              icon={<RefreshCw className="h-3.5 w-3.5" />}
                              loading={rotate.isPending && rotate.variables === client.id}
                              onClick={() => rotate.mutate(client.id)}
                            >
                              Rotate
                            </Button>
                            <Button
                              size="sm"
                              variant="danger"
                              icon={<Trash2 className="h-3.5 w-3.5" />}
                              loading={revoke.isPending && revoke.variables === client.id}
                              onClick={() => revoke.mutate(client.id)}
                            >
                              Revoke
                            </Button>
                          </div>
                        ) : null}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardBody>
        </Card>

        <Card className="self-start">
          <CardHeader title="Onboard an API user" icon={<UserPlus className="h-4 w-4" />} />
          <CardBody className="space-y-4">
            <Field label="Name" htmlFor="client-name" required hint="Identifies this integration in every audit entry.">
              <Input
                id="client-name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="acme-release-pipeline"
              />
            </Field>

            <Field
              label="Kind of system"
              htmlFor="client-platform"
              hint="Optional label, e.g. jenkins, azure-devops, a partner platform. It appears beside this key and in the audit trail; it grants nothing."
            >
              <Input
                id="client-platform"
                value={platform}
                onChange={(event) => setPlatform(event.target.value)}
                placeholder="jenkins"
              />
            </Field>

            <fieldset>
              <legend className="mb-1.5 text-sm font-medium text-ink">What it may do</legend>
              <div className="space-y-1.5">
                {SCOPES.map((item) => (
                  <label key={item.scope} className="flex cursor-pointer items-start gap-2.5">
                    <input
                      type="checkbox"
                      className="mt-0.5 h-3.5 w-3.5 rounded border-line-strong text-brand-500"
                      checked={scopes.includes(item.scope)}
                      onChange={(event) =>
                        setScopes((current) =>
                          event.target.checked
                            ? [...current, item.scope]
                            : current.filter((value) => value !== item.scope),
                        )
                      }
                    />
                    <span className="min-w-0">
                      <span className="block text-sm text-ink">{item.label}</span>
                      <span className="block text-xs text-ink-tertiary">{item.hint}</span>
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend className="mb-1.5 text-sm font-medium text-ink">What it may reach</legend>
              <label className="flex cursor-pointer items-start gap-2.5">
                <input
                  type="checkbox"
                  className="mt-0.5 h-3.5 w-3.5 rounded border-line-strong text-brand-500"
                  checked={wholeProject}
                  onChange={(event) => setWholeProject(event.target.checked)}
                />
                <span className="min-w-0">
                  <span className="block text-sm text-ink">This whole project</span>
                  <span className="block text-xs text-ink-tertiary">
                    Every published flow and agent, including ones published later. Drafts stay
                    private. Leave this off to grant nothing until specific flows are named through
                    the API.
                  </span>
                </span>
              </label>
            </fieldset>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Expires in" htmlFor="client-expiry">
                <Select
                  id="client-expiry"
                  value={expiresInDays}
                  onChange={(event) => setExpiresInDays(event.target.value)}
                >
                  <option value="30">30 days</option>
                  <option value="90">90 days</option>
                  <option value="365">1 year</option>
                  <option value="">Never</option>
                </Select>
              </Field>
              <Field label="Calls / minute" htmlFor="client-rate">
                <Input
                  id="client-rate"
                  type="number"
                  min={1}
                  value={rateLimit}
                  onChange={(event) => setRateLimit(event.target.value)}
                />
              </Field>
            </div>

            <Button
              className={cn('w-full')}
              disabled={!mayManage || !name.trim() || scopes.length === 0}
              loading={onboard.isPending}
              onClick={() => onboard.mutate()}
              icon={<UserPlus className="h-3.5 w-3.5" />}
            >
              Onboard and issue key
            </Button>
            {!mayManage ? (
              <p className="text-xs text-ink-tertiary">
                Issuing keys needs the <code className="font-mono">governance:write</code> permission.
              </p>
            ) : null}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
