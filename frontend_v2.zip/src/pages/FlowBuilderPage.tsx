/**
 * Visual flow builder (spec §6): compose agents, conditions, approval gates and
 * tool calls on a React Flow canvas, configure each step, then save, validate,
 * publish and run the flow.
 */
import { useCallback, useEffect, useMemo, useState, type DragEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import ReactFlow, {
  Background, BackgroundVariant, Controls, MarkerType, MiniMap,
  type Connection, type Edge, type EdgeChange, type Node, type NodeChange, type ReactFlowInstance,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { AlertTriangle, Check, Play, Rocket, Save, ShieldCheck, X } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId, formatCurrency } from '@/hooks';
import { useWorkspace } from '@/store';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Field, KeyValue, LoadingBlock,
  PageHeader, statusTone, Textarea,
} from '@/design-system/primitives';
import type { FlowDetail } from '@/types';
import { FlowNodeCard, type FlowNodeData } from '@/features/flow-builder/FlowNodeCard';
import { EdgeInspector, NodeInspector, type ModelOption } from '@/features/flow-builder/Inspector';
import { NodePalette, PALETTE_MIME, type PaletteItem } from '@/features/flow-builder/NodePalette';
import {
  conditionVariables, connect, createNode, draftFromFlow, insertAfter, insertionPoint, removeEdges,
  removeNodes, ROW_HEIGHT, toPayload, updateEdge, updateNode, type DraftEdge, type DraftNode, type FlowDraft,
} from '@/features/flow-builder/graph';

const NODE_TYPES = { flowNode: FlowNodeCard };

type Selection = { kind: 'node'; key: string } | { kind: 'edge'; id: string } | null;
type Notice = { tone: 'success' | 'danger'; text: string } | null;

function describeError(caught: unknown): string {
  if (caught instanceof ApiError) return caught.message;
  return caught instanceof Error ? caught.message : 'Something went wrong.';
}

export default function FlowBuilderPage() {
  const { flowId } = useParams<{ flowId: string }>();
  const projectId = useProjectId();
  const environmentId = useWorkspace((state) => state.environmentId);
  const environments = useWorkspace((state) => state.environments);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [draft, setDraft] = useState<FlowDraft | null>(null);
  const [dirty, setDirty] = useState(false);
  const [selection, setSelection] = useState<Selection>(null);
  const [runInputs, setRunInputs] = useState('{}');
  const [notice, setNotice] = useState<Notice>(null);
  const [instance, setInstance] = useState<ReactFlowInstance | null>(null);

  const { data: flow, isLoading } = useQuery({
    queryKey: ['flow', flowId],
    queryFn: () => api.getFlow(flowId!),
    enabled: Boolean(flowId),
  });
  const { data: agentPage } = useQuery({
    queryKey: ['agents-all', projectId],
    queryFn: () => api.listAgents({ project_id: projectId ?? undefined, limit: 200 }),
    enabled: Boolean(projectId),
  });
  const { data: providers } = useQuery({ queryKey: ['ai-providers'], queryFn: api.aiProviders });
  const { data: modelCatalog } = useQuery({ queryKey: ['ai-models'], queryFn: () => api.aiModels() });
  const { data: mcpServers } = useQuery({
    queryKey: ['mcp-servers', projectId],
    queryFn: () => api.mcpServers(projectId!),
    enabled: Boolean(projectId),
  });

  const agents = useMemo(
    () => (agentPage?.items ?? []).filter((agent) => agent.lifecycle_state !== 'deprecated'),
    [agentPage],
  );
  const agentsById = useMemo(() => new Map(agents.map((agent) => [agent.id, agent])), [agents]);

  // Only models from providers that can actually serve a call are offered.
  const models: ModelOption[] = useMemo(() => {
    const usable = new Set((providers?.providers ?? []).filter((item) => item.configured).map((item) => item.provider));
    return (modelCatalog ?? [])
      .filter((model) => usable.has(model.provider) && !model.capabilities.every((capability) => capability === 'embedding'))
      .map((model) => ({ value: `${model.provider}:${model.model_key}`, label: `${model.display_name} (${model.provider})` }));
  }, [providers, modelCatalog]);

  // Server state replaces the draft only while there are no unsaved edits.
  useEffect(() => {
    if (flow && !dirty) {
      setDraft(draftFromFlow(flow));
      setRunInputs(JSON.stringify(flow.variables ?? {}, null, 2));
    }
  }, [flow, dirty]);

  useEffect(() => {
    if (!dirty) return undefined;
    const warn = (event: BeforeUnloadEvent) => event.preventDefault();
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  const edit = useCallback((change: (current: FlowDraft) => FlowDraft) => {
    setDraft((current) => (current ? change(current) : current));
    setDirty(true);
  }, []);

  /* ---- canvas -------------------------------------------------------------- */

  const nodes: Node<FlowNodeData>[] = useMemo(
    () =>
      (draft?.nodes ?? []).map((node) => ({
        id: node.node_key,
        type: 'flowNode',
        position: { x: node.position_x, y: node.position_y },
        data: { node, agent: node.agent_id ? agentsById.get(node.agent_id) : undefined },
        selected: selection?.kind === 'node' && selection.key === node.node_key,
        deletable: node.node_type !== 'start',
      })),
    [draft, agentsById, selection],
  );

  const edges: Edge[] = useMemo(
    () =>
      (draft?.edges ?? []).map((edge) => {
        const color = edge.branch_label === 'false' ? '#B7791F' : edge.branch_label === 'true' ? '#238636' : '#94A3B8';
        return {
          id: edge.id,
          source: edge.source_node_key,
          target: edge.target_node_key,
          label: edge.branch_label ?? (edge.condition_expression ? 'if…' : undefined),
          selected: selection?.kind === 'edge' && selection.id === edge.id,
          animated: edge.branch_label === 'true',
          markerEnd: { type: MarkerType.ArrowClosed, color, width: 16, height: 16 },
          style: { stroke: color, strokeWidth: 1.6 },
          labelStyle: { fontSize: 11, fill: '#334155', fontWeight: 600 },
          labelBgStyle: { fill: '#FFFFFF' },
          labelBgPadding: [4, 2] as [number, number],
        };
      }),
    [draft, selection],
  );

  const onNodesChange = useCallback(
    (changes: NodeChange[]) => {
      if (!draft) return;
      // A click also reports a "position" at the same spot; only a real move is an edit.
      const positions = new Map(draft.nodes.map((node) => [node.node_key, node]));
      const moved = changes.flatMap((change) => {
        if (change.type !== 'position' || !change.position) return [];
        const node = positions.get(change.id);
        const x = Math.round(change.position.x);
        const y = Math.round(change.position.y);
        return node && (node.position_x !== x || node.position_y !== y) ? [{ key: change.id, x, y }] : [];
      });
      const removed = changes.filter((change) => change.type === 'remove').map((change) => change.id);
      if (!moved.length && !removed.length) return;

      edit((current) => {
        let next = current;
        for (const move of moved) next = updateNode(next, move.key, { position_x: move.x, position_y: move.y });
        return removed.length ? removeNodes(next, removed) : next;
      });
      if (removed.length) setSelection(null);
    },
    [draft, edit],
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange[]) => {
      const removed = changes.filter((change) => change.type === 'remove').map((change) => change.id);
      if (!removed.length) return;
      edit((current) => removeEdges(current, removed));
      setSelection(null);
    },
    [edit],
  );

  const onConnect = useCallback(
    (connection: Connection) => {
      if (connection.source && connection.target) {
        edit((current) => connect(current, connection.source!, connection.target!));
      }
    },
    [edit],
  );

  function addStep(item: PaletteItem, dropPosition?: { x: number; y: number }) {
    if (!draft) return;
    const agent = item.agentId ? agentsById.get(item.agentId) : undefined;
    if (item.type === 'agent' && !agent) return;

    const lowest = draft.nodes.reduce((max, node) => Math.max(max, node.position_y), 0);
    const node = createNode(draft, item.type, dropPosition ?? { x: 120, y: lowest + ROW_HEIGHT }, agent);
    const selectedKey = selection?.kind === 'node' ? selection.key : null;
    const next = dropPosition
      ? { ...draft, nodes: [...draft.nodes, node] }
      : insertAfter(draft, node, insertionPoint(draft, selectedKey));

    setDraft(next);
    setDirty(true);
    setSelection({ kind: 'node', key: node.node_key });
    if (!dropPosition) window.requestAnimationFrame(() => instance?.fitView({ padding: 0.18, duration: 300 }));
  }

  function onDrop(event: DragEvent) {
    const raw = event.dataTransfer.getData(PALETTE_MIME);
    if (!raw || !instance) return;
    event.preventDefault();
    const point = instance.screenToFlowPosition({ x: event.clientX, y: event.clientY });
    // Centre the 240px-wide card under the pointer.
    addStep(JSON.parse(raw) as PaletteItem, { x: point.x - 120, y: point.y - 30 });
  }

  /* ---- persistence ----------------------------------------------------------- */

  function parsedInputs(): Record<string, unknown> {
    try {
      const value = JSON.parse(runInputs || '{}');
      if (value && typeof value === 'object' && !Array.isArray(value)) return value as Record<string, unknown>;
    } catch {
      // fall through to the error below
    }
    throw new Error('Run inputs must be a JSON object, for example {"requirement_key": "PAY-201"}.');
  }

  async function persist(): Promise<FlowDetail> {
    const saved = await api.updateFlow(flow!.id, { ...toPayload(draft!), variables: parsedInputs() });
    queryClient.setQueryData(['flow', flowId], saved);
    void queryClient.invalidateQueries({ queryKey: ['flows'] });
    setDraft(draftFromFlow(saved));
    setDirty(false);
    // Saved edges get server ids, so an edge selection would now point nowhere.
    setSelection((current) => (current?.kind === 'edge' ? null : current));
    return saved;
  }

  const save = useMutation({
    mutationFn: persist,
    onSuccess: (saved) =>
      setNotice(
        saved.validation_result?.valid === false
          ? { tone: 'danger', text: 'Saved, but the flow has validation errors to resolve before it can run.' }
          : { tone: 'success', text: 'Flow saved.' },
      ),
    onError: (caught) => setNotice({ tone: 'danger', text: describeError(caught) }),
  });

  const validate = useMutation({
    mutationFn: async () => {
      if (dirty) await persist();
      return api.validateFlow(flow!.id);
    },
    onSuccess: (result) => {
      void queryClient.invalidateQueries({ queryKey: ['flow', flowId] });
      setNotice({
        tone: result.valid ? 'success' : 'danger',
        text: result.valid
          ? `Flow is valid${result.warnings.length ? ` with ${result.warnings.length} warning${result.warnings.length === 1 ? '' : 's'}` : ''}.`
          : `${result.errors.length} validation error${result.errors.length === 1 ? '' : 's'} must be resolved.`,
      });
    },
    onError: (caught) => setNotice({ tone: 'danger', text: describeError(caught) }),
  });

  const publish = useMutation({
    mutationFn: async () => {
      if (dirty) await persist();
      return api.publishFlow(flow!.id, 'Published from the flow builder.');
    },
    onSuccess: (published) => {
      queryClient.setQueryData(['flow', flowId], published);
      void queryClient.invalidateQueries({ queryKey: ['flows'] });
      setNotice({ tone: 'success', text: `Published version ${published.version}.` });
    },
    onError: (caught) => setNotice({ tone: 'danger', text: describeError(caught) }),
  });

  const run = useMutation({
    mutationFn: async () => {
      const inputs = parsedInputs();
      if (dirty) await persist();
      return api.runFlow(flow!.id, { inputs, environment_id: environmentId ?? undefined });
    },
    onSuccess: (started) => navigate(`/runs/${started.id}`),
    onError: (caught) => setNotice({ tone: 'danger', text: describeError(caught) }),
  });

  /* ---- render ---------------------------------------------------------------- */

  if (isLoading || (flow && !draft)) return <LoadingBlock rows={8} />;
  if (!flow || !draft) return <EmptyState title="Flow not found" description="This flow may have been archived." />;

  const validation = flow.validation_result;
  const busy = save.isPending || validate.isPending || publish.isPending || run.isPending;
  const selectedNode: DraftNode | undefined =
    selection?.kind === 'node' ? draft.nodes.find((node) => node.node_key === selection.key) : undefined;
  const selectedEdge: DraftEdge | undefined =
    selection?.kind === 'edge' ? draft.edges.find((edge) => edge.id === selection.id) : undefined;
  const labelFor = (key: string) => draft.nodes.find((node) => node.node_key === key)?.label ?? key;
  const environment = environments.find((item) => item.id === environmentId);
  const agentSteps = draft.nodes.filter((node) => node.node_type === 'agent').length;
  const approvalGates = draft.nodes.filter(
    (node) => node.node_type === 'approval' || (node.node_type === 'agent' && node.requires_approval),
  ).length;

  return (
    <div className="flex h-[calc(100vh-8rem)] min-h-[640px] flex-col">
      <PageHeader
        title={flow.name}
        description={flow.description ?? undefined}
        breadcrumb={
          <Link to={`/flows/${flow.id}`} className="text-sm text-ink-secondary hover:text-brand-600">
            ← {flow.name} workspace
          </Link>
        }
        actions={
          <>
            <Badge tone={statusTone(flow.status)}>{flow.status}</Badge>
            <Badge tone="neutral">v{flow.version}</Badge>
            {dirty ? <Badge tone="warning">Unsaved changes</Badge> : null}
            <Button
              variant="secondary"
              icon={<Save className="h-3.5 w-3.5" />}
              disabled={!dirty || busy}
              loading={save.isPending}
              onClick={() => save.mutate()}
            >
              Save
            </Button>
            <Button variant="secondary" disabled={busy} loading={validate.isPending} onClick={() => validate.mutate()}>
              Validate
            </Button>
            <Button
              variant="secondary"
              icon={<Rocket className="h-3.5 w-3.5" />}
              disabled={busy}
              loading={publish.isPending}
              onClick={() => publish.mutate()}
            >
              Publish
            </Button>
            <Button
              variant="primary"
              icon={<Play className="h-3.5 w-3.5" />}
              loading={run.isPending}
              disabled={busy || (!dirty && validation?.valid === false)}
              onClick={() => run.mutate()}
            >
              Run flow
            </Button>
          </>
        }
      />

      {notice ? (
        <div
          role="status"
          className={cn(
            'mb-3 flex items-center justify-between rounded-lg border px-4 py-2 text-sm',
            notice.tone === 'success'
              ? 'border-success-border bg-success-bg text-success-text'
              : 'border-danger-border bg-danger-bg text-danger-text',
          )}
        >
          <span className="flex items-center gap-2">
            {notice.tone === 'success' ? <Check className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}
            {notice.text}
          </span>
          <button onClick={() => setNotice(null)} aria-label="Dismiss">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      ) : null}

      {!dirty && validation && validation.valid === false ? (
        <div role="alert" className="mb-3 rounded-lg border border-danger-border bg-danger-bg px-4 py-3">
          <p className="text-sm font-semibold text-danger-text">This flow cannot run yet</p>
          <ul className="mt-1.5 list-inside list-disc space-y-0.5">
            {validation.errors.map((issue, index) => (
              <li key={index} className="text-sm text-danger-text">
                {issue.message}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className="grid min-h-0 flex-1 gap-4 lg:grid-cols-[230px_minmax(0,1fr)_320px] 2xl:grid-cols-[260px_minmax(0,1fr)_350px]">
        <NodePalette agents={agents} onAdd={(item) => addStep(item)} />

        <Card className="min-h-[420px] overflow-hidden" onDragOver={(event) => {
          if (event.dataTransfer.types.includes(PALETTE_MIME)) {
            event.preventDefault();
            event.dataTransfer.dropEffect = 'move';
          }
        }} onDrop={onDrop}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={NODE_TYPES}
            onInit={setInstance}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={(_event, node) => setSelection({ kind: 'node', key: node.id })}
            onEdgeClick={(_event, edge) => setSelection({ kind: 'edge', id: edge.id })}
            onPaneClick={() => setSelection(null)}
            deleteKeyCode={['Backspace', 'Delete']}
            fitView
            fitViewOptions={{ padding: 0.18 }}
            minZoom={0.25}
            maxZoom={1.6}
            proOptions={{ hideAttribution: true }}
            className="bg-surface-muted"
          >
            <Background variant={BackgroundVariant.Dots} gap={18} size={1} color="#D9E1EA" />
            <Controls showInteractive={false} />
            <MiniMap
              pannable
              zoomable
              className="!border !border-line !bg-surface"
              nodeColor={(node) => {
                const type = (node.data as FlowNodeData)?.node.node_type;
                if (type === 'condition') return '#B7791F';
                if (type === 'approval') return '#2563EB';
                if (type === 'start') return '#238636';
                return '#145DA0';
              }}
            />
          </ReactFlow>
        </Card>

        <div className="min-h-0 space-y-4 overflow-y-auto pb-2">
          {selectedNode ? (
            <NodeInspector
              key={selectedNode.node_key}
              node={selectedNode}
              agents={agents}
              agentsById={agentsById}
              models={models}
              mcpServers={mcpServers ?? []}
              conditionNames={conditionVariables(draft, safeObject(runInputs), agentsById)}
              outgoing={draft.edges.filter((edge) => edge.source_node_key === selectedNode.node_key)}
              labelFor={labelFor}
              onChange={(patch) => edit((current) => updateNode(current, selectedNode.node_key, patch))}
              onEdgeChange={(id, patch) => edit((current) => updateEdge(current, id, patch))}
              onDelete={() => {
                edit((current) => removeNodes(current, [selectedNode.node_key]));
                setSelection(null);
              }}
            />
          ) : selectedEdge ? (
            <EdgeInspector
              key={selectedEdge.id}
              edge={selectedEdge}
              fromCondition={draft.nodes.some(
                (node) => node.node_key === selectedEdge.source_node_key && node.node_type === 'condition',
              )}
              labelFor={labelFor}
              onChange={(patch) => edit((current) => updateEdge(current, selectedEdge.id, patch))}
              onDelete={() => {
                edit((current) => removeEdges(current, [selectedEdge.id]));
                setSelection(null);
              }}
            />
          ) : (
            <Card>
              <CardHeader title="Run configuration" description="Saved with the flow and passed to every step" />
              <CardBody className="space-y-4">
                <Field
                  label="Run inputs (JSON)"
                  htmlFor="run-inputs"
                  hint='Available to every step as variables, e.g. {"requirement_key": "PAY-201", "module": "Payments"}'
                >
                  <Textarea
                    id="run-inputs"
                    rows={7}
                    value={runInputs}
                    onChange={(event) => {
                      setRunInputs(event.target.value);
                      setDirty(true);
                    }}
                    className="font-mono text-xs"
                    spellCheck={false}
                  />
                </Field>
                <dl className="divide-y divide-line">
                  <KeyValue label="Environment">{environment?.name ?? 'Project default'}</KeyValue>
                  <KeyValue label="Agent steps">{agentSteps}</KeyValue>
                  <KeyValue label="Approval gates">
                    <span className="inline-flex items-center gap-1.5">
                      <ShieldCheck className="h-3.5 w-3.5 text-info-text" />
                      {approvalGates}
                    </span>
                  </KeyValue>
                  <KeyValue label="Cost budget per run">{formatCurrency(flow.cost_budget_usd)}</KeyValue>
                  <KeyValue label="Runs">{flow.run_count}</KeyValue>
                </dl>
                {!dirty && validation?.warnings?.length ? (
                  <div className="rounded border border-warning-border bg-warning-bg px-3 py-2">
                    <p className="text-xs font-semibold text-warning-text">Warnings</p>
                    <ul className="mt-1 space-y-0.5">
                      {validation.warnings.map((warning, index) => (
                        <li key={index} className="text-xs text-warning-text">
                          • {warning.message}
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
                <div className="rounded border border-line bg-surface-muted px-3 py-2 text-xs leading-5 text-ink-secondary">
                  <p className="font-medium text-ink">Editing the canvas</p>
                  <p>Drag from a node&apos;s bottom handle to another node to connect them.</p>
                  <p>Click a node or connection to configure it; press Delete to remove it.</p>
                </div>
              </CardBody>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function safeObject(text: string): Record<string, unknown> {
  try {
    const value = JSON.parse(text);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch {
    return {};
  }
}
