/** Run history across flows and ad-hoc agent invocations. */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Activity } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatCurrency, formatDuration, formatNumber, formatRelativeTime } from '@/hooks';
import { Column, DataTable } from '@/components/DataTable';
import { Badge, Card, PageHeader, Select, statusTone } from '@/design-system/primitives';
import type { RunSummary } from '@/types';

const STATUSES = ['', 'running', 'queued', 'awaiting_approval', 'succeeded', 'partially_succeeded', 'failed', 'cancelled'];

export default function RunsPage() {
  const projectId = useProjectId();
  const navigate = useNavigate();
  const [status, setStatus] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['runs', projectId, status],
    queryFn: () => api.listRuns({ project_id: projectId!, status: status || undefined, limit: 100 }),
    enabled: Boolean(projectId),
    // Keep the list fresh while anything is in flight.
    refetchInterval: 10000,
  });

  const columns: Column<RunSummary>[] = [
    {
      key: 'title',
      header: 'Run',
      render: (run) => (
        <div className="min-w-0">
          <Link
            to={`/runs/${run.id}`}
            className="font-medium text-ink hover:text-brand-600"
            onClick={(event) => event.stopPropagation()}
          >
            #{run.run_number} {run.title}
          </Link>
          {run.summary ? (
            <p className="mt-0.5 line-clamp-1 max-w-lg text-xs text-ink-secondary">{run.summary}</p>
          ) : null}
        </div>
      ),
    },
    { key: 'kind', header: 'Type', render: (run) => <Badge tone="neutral">{run.kind.replace(/_/g, ' ')}</Badge> },
    {
      key: 'status',
      header: 'Status',
      render: (run) => <Badge tone={statusTone(run.status)} dot>{run.status.replace(/_/g, ' ')}</Badge>,
    },
    {
      key: 'steps',
      header: 'Steps',
      numeric: true,
      render: (run) => (
        <span className="text-ink-secondary">
          {run.completed_step_count}/{run.step_count || '—'}
        </span>
      ),
    },
    { key: 'duration', header: 'Duration', numeric: true, render: (run) => <span className="text-ink-secondary">{formatDuration(run.duration_ms)}</span> },
    { key: 'tokens', header: 'Tokens', numeric: true, render: (run) => <span className="text-ink-secondary">{formatNumber(run.total_tokens)}</span> },
    { key: 'cost', header: 'Cost', numeric: true, render: (run) => <span className="text-ink-secondary">{formatCurrency(run.total_cost_usd, 4)}</span> },
    { key: 'when', header: 'Started', render: (run) => <span className="text-ink-secondary">{formatRelativeTime(run.started_at ?? run.created_at)}</span> },
  ];

  return (
    <div>
      <PageHeader
        title="Agent Runs"
        description="Every flow and agent execution, with its cost, duration and outcome."
        actions={
          <Select aria-label="Filter by status" className="w-52" value={status} onChange={(event) => setStatus(event.target.value)}>
            {STATUSES.map((value) => (
              <option key={value} value={value}>
                {value ? value.replace(/_/g, ' ') : 'All statuses'}
              </option>
            ))}
          </Select>
        }
      />

      <Card>
        <DataTable
          columns={columns}
          rows={data?.items ?? []}
          keyOf={(run) => run.id}
          loading={isLoading}
          onRowClick={(run) => navigate(`/runs/${run.id}`)}
          caption="Agent run history"
          emptyIcon={<Activity className="h-5 w-5" />}
          emptyTitle="No runs yet"
          emptyDescription="Run a flow to see its execution timeline here."
          minWidth={900}
        />
      </Card>
    </div>
  );
}
