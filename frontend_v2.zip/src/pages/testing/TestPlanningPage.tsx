/** Test Planning: requirements with readiness scores and coverage gaps. */
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';
import { ClipboardCheck, Search, Sparkles, TriangleAlert } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useDebounced, useProjectId, formatRelativeTime } from '@/hooks';
import { useWorkspace } from '@/store';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Input, LoadingBlock,
  PageHeader, ProgressBar, Select, statusTone,
} from '@/design-system/primitives';

/** The seeded flow that takes one story all the way to Playwright scripts. */
const AUTOMATION_FLOW_KEY = 'requirement-to-automated-test';
const READINESS_AGENT_KEY = 'user-story-completeness';
import type { RequirementRecord } from '@/types';

export default function TestPlanningPage() {
  const projectId = useProjectId();
  const project = useWorkspace((state) => state.project);

  const [module, setModule] = useState('');
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<RequirementRecord | null>(null);
  const debounced = useDebounced(search, 300);

  const { data, isLoading } = useQuery({
    queryKey: ['requirements', projectId, module, status, debounced],
    queryFn: () =>
      api.listRequirements({
        project_id: projectId!,
        module: module || undefined,
        status: status || undefined,
        search: debounced || undefined,
        limit: 100,
      }),
    enabled: Boolean(projectId),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  const requirements = data?.items ?? [];
  const scored = requirements.filter((item) => item.completeness_score !== null);
  const belowThreshold = scored.filter((item) => (item.completeness_score ?? 0) < 80);

  return (
    <div>
      <PageHeader
        title="Test Planning"
        description="Requirements in scope, how ready they are for test design, and where the risk sits."
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Requirements" value={requirements.length} />
        <Stat label="Assessed" value={`${scored.length}/${requirements.length}`} isText />
        <Stat label="Below threshold" value={belowThreshold.length} tone={belowThreshold.length ? 'warning' : undefined} />
        <Stat
          label="High risk"
          value={requirements.filter((item) => item.risk_score > 0.7).length}
          tone="danger"
        />
      </div>

      <div className={cn('grid gap-5', selected && 'lg:grid-cols-[1fr_420px]')}>
        <Card>
          <CardHeader
            title="Requirements"
            description={`${requirements.length} in scope`}
            actions={
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" aria-hidden />
                  <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search" aria-label="Search requirements" className="h-8 w-40 pl-8 text-sm" />
                </div>
                <Select aria-label="Filter by module" className="h-8 w-36 text-sm" value={module} onChange={(event) => setModule(event.target.value)}>
                  <option value="">All modules</option>
                  {(project?.modules ?? []).map((item) => (
                    <option key={item} value={item}>{item}</option>
                  ))}
                </Select>
                <Select aria-label="Filter by status" className="h-8 w-36 text-sm" value={status} onChange={(event) => setStatus(event.target.value)}>
                  <option value="">All statuses</option>
                  {['refinement', 'ready', 'in_development', 'in_test', 'done'].map((value) => (
                    <option key={value} value={value}>{value.replace(/_/g, ' ')}</option>
                  ))}
                </Select>
              </div>
            }
          />
          <CardBody className="p-0">
            {requirements.length ? (
              <ul className="divide-y divide-line-subtle">
                {requirements.map((requirement) => (
                  <li key={requirement.id}>
                    <button
                      type="button"
                      onClick={() => setSelected(requirement)}
                      aria-current={selected?.id === requirement.id ? 'true' : undefined}
                      className={cn(
                        'flex w-full items-center gap-4 px-5 py-3 text-left transition-colors',
                        selected?.id === requirement.id ? 'bg-brand-50' : 'hover:bg-surface-muted',
                      )}
                    >
                      <span className="min-w-0 flex-1">
                        <span className="flex flex-wrap items-center gap-2">
                          <code className="font-mono text-xs font-semibold text-brand-600">{requirement.external_key}</code>
                          <span className="truncate text-sm font-medium text-ink">{requirement.title}</span>
                        </span>
                        <span className="mt-0.5 flex flex-wrap items-center gap-2 text-2xs text-ink-tertiary">
                          <span>{requirement.module}</span>
                          <span>· {requirement.acceptance_criteria.length} acceptance criteria</span>
                          {requirement.sprint ? <span>· {requirement.sprint}</span> : null}
                        </span>
                      </span>

                      <Badge tone={requirement.priority === 'critical' || requirement.priority === 'high' ? 'warning' : 'neutral'} className="shrink-0">
                        {requirement.priority}
                      </Badge>
                      <Badge tone={statusTone(requirement.status)} className="shrink-0">
                        {requirement.status.replace(/_/g, ' ')}
                      </Badge>

                      <span className="hidden w-28 shrink-0 sm:block">
                        {requirement.completeness_score !== null && requirement.completeness_score !== undefined ? (
                          <>
                            <span className="mb-1 flex items-baseline justify-between">
                              <span className="text-2xs text-ink-tertiary">Readiness</span>
                              <span className={cn('tabular text-xs font-semibold', requirement.completeness_score >= 80 ? 'text-success-text' : 'text-warning-text')}>
                                {requirement.completeness_score.toFixed(0)}
                              </span>
                            </span>
                            <ProgressBar
                              value={requirement.completeness_score / 100}
                              tone={requirement.completeness_score >= 80 ? 'success' : 'warning'}
                              label="Readiness score"
                            />
                          </>
                        ) : (
                          <span className="text-2xs text-ink-tertiary">Not assessed</span>
                        )}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={<ClipboardCheck className="h-5 w-5" />} title="No requirements match" />
            )}
          </CardBody>
        </Card>

        {selected ? <RequirementPanel requirement={selected} onClose={() => setSelected(null)} /> : null}
      </div>
    </div>
  );
}

function Stat({ label, value, tone, isText }: { label: string; value: number | string; tone?: 'warning' | 'danger'; isText?: boolean }) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p className={cn('tabular mt-1 font-semibold', isText ? 'text-xl' : 'text-2xl', tone === 'warning' ? 'text-warning-text' : tone === 'danger' ? 'text-danger-text' : 'text-ink')}>
          {value}
        </p>
      </CardBody>
    </Card>
  );
}

function RequirementPanel({ requirement, onClose }: { requirement: RequirementRecord; onClose: () => void }) {
  const gaps = requirement.completeness_findings?.filter((finding) => finding.status === 'gap') ?? [];
  const projectId = useProjectId();
  const environmentId = useWorkspace((state) => state.environmentId);
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  const onError = (caught: unknown) =>
    setError(caught instanceof ApiError || caught instanceof Error ? caught.message : 'The run could not be started.');

  const checkReadiness = useMutation({
    mutationFn: async () => {
      const agents = await api.listAgents({ project_id: projectId!, limit: 200 });
      const agent = agents.items.find((item) => item.key === READINESS_AGENT_KEY);
      if (!agent) throw new Error('The User Story Completeness agent is not available in this project.');
      return api.testAgent(agent.id, { project_id: projectId!, inputs: { requirement_key: requirement.external_key } });
    },
    onSuccess: (run) => navigate(`/runs/${run.id}`),
    onError,
  });

  const automate = useMutation({
    mutationFn: async () => {
      const flows = await api.listFlows(projectId!);
      const flow = flows.items.find((item) => item.key === AUTOMATION_FLOW_KEY);
      if (!flow) throw new Error('The "Requirement to Automated Test" flow is not available in this project.');
      return api.runFlow(flow.id, {
        inputs: { requirement_key: requirement.external_key, module: requirement.module },
        environment_id: environmentId ?? undefined,
      });
    },
    onSuccess: (run) => navigate(`/runs/${run.id}`),
    onError,
  });

  const busy = checkReadiness.isPending || automate.isPending;

  return (
    // Sticky, so the panel stays in view when the story was picked far down the list.
    <Card className="self-start lg:sticky lg:top-20 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto">
      <CardHeader
        title={requirement.external_key}
        description={requirement.title}
        actions={
          <button onClick={onClose} aria-label="Close panel" className="rounded p-1 text-ink-tertiary hover:bg-surface-sunken hover:text-ink">
            ×
          </button>
        }
      />
      <CardBody className="space-y-4">
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="secondary"
              icon={<ClipboardCheck className="h-3.5 w-3.5" />}
              loading={checkReadiness.isPending}
              disabled={busy}
              onClick={() => {
                setError(null);
                checkReadiness.mutate();
              }}
            >
              Check readiness
            </Button>
            <Button
              variant="primary"
              icon={<Sparkles className="h-3.5 w-3.5" />}
              loading={automate.isPending}
              disabled={busy}
              onClick={() => {
                setError(null);
                automate.mutate();
              }}
            >
              Automate end to end
            </Button>
          </div>
          <p className="text-xs text-ink-tertiary">
            Automating runs the governed flow: readiness, domain knowledge, scenarios, test cases, test data and Playwright scripts.
          </p>
          {error ? (
            <p role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2 text-xs text-danger-text">
              {error}
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-1.5">
          <Badge tone="neutral">{requirement.module}</Badge>
          <Badge tone={statusTone(requirement.status)}>{requirement.status.replace(/_/g, ' ')}</Badge>
          <Badge tone={requirement.priority === 'critical' ? 'danger' : 'warning'}>{requirement.priority}</Badge>
          {requirement.risk_score > 0.7 ? <Badge tone="danger">high risk</Badge> : null}
        </div>

        {requirement.completeness_score !== null && requirement.completeness_score !== undefined ? (
          <div className="rounded border border-line bg-surface-muted p-3">
            <p className="flex items-center justify-between">
              <span className="text-sm font-medium text-ink">Test readiness</span>
              <span className={cn('tabular text-lg font-semibold', requirement.completeness_score >= 80 ? 'text-success-text' : 'text-warning-text')}>
                {requirement.completeness_score.toFixed(0)}/100
              </span>
            </p>
            <ProgressBar
              value={requirement.completeness_score / 100}
              tone={requirement.completeness_score >= 80 ? 'success' : 'warning'}
              className="mt-2"
              label="Readiness"
            />
            <p className="mt-1.5 text-xs text-ink-tertiary">
              Assessed {formatRelativeTime(requirement.last_analyzed_at)}
            </p>
          </div>
        ) : null}

        {gaps.length ? (
          <section>
            <h4 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-warning-text">
              <TriangleAlert className="h-3 w-3" /> Gaps blocking test design
            </h4>
            <ul className="space-y-1.5">
              {gaps.map((gap, index) => (
                <li key={index} className="rounded border border-warning-border bg-warning-bg px-3 py-2 text-xs text-warning-text">
                  <span className="font-semibold">{String(gap.check)}</span>: {String(gap.detail)}
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {requirement.acceptance_criteria.length ? (
          <section>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
              Acceptance criteria ({requirement.acceptance_criteria.length})
            </h4>
            <ul className="space-y-1.5">
              {requirement.acceptance_criteria.map((criterion, index) => (
                <li key={index} className="flex gap-2 text-sm text-ink-secondary">
                  <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-surface-sunken text-[10px] font-semibold text-ink-tertiary">
                    {index + 1}
                  </span>
                  {criterion}
                </li>
              ))}
            </ul>
          </section>
        ) : (
          <p className="rounded border border-warning-border bg-warning-bg px-3 py-2 text-xs text-warning-text">
            This story has no acceptance criteria. Scenario generation will have little to work from.
          </p>
        )}

        {requirement.description ? (
          <section>
            <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Description</h4>
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-ink-secondary">{requirement.description}</p>
          </section>
        ) : null}
      </CardBody>
    </Card>
  );
}
