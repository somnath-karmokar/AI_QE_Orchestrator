/** Test Design: scenarios and the test cases derived from them. */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileText, ListTree, Search } from 'lucide-react';
import { api } from '@/services/api';
import { useDebounced, useProjectId, formatDuration, formatPercent } from '@/hooks';
import { useWorkspace } from '@/store';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, Input, LoadingBlock,
  PageHeader, Select,
} from '@/design-system/primitives';
import type { TestCaseRecord } from '@/types';

const TYPE_TONE: Record<string, 'success' | 'warning' | 'info' | 'neutral'> = {
  positive: 'success', negative: 'warning', edge: 'info',
};

export default function TestDesignPage() {
  const projectId = useProjectId();
  const project = useWorkspace((state) => state.project);

  const [view, setView] = useState<'cases' | 'scenarios'>('cases');
  const [module, setModule] = useState('');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<TestCaseRecord | null>(null);
  const debounced = useDebounced(search, 300);

  const { data: cases, isLoading } = useQuery({
    queryKey: ['test-cases', projectId, module, debounced],
    queryFn: () =>
      api.listTestCases({
        project_id: projectId!,
        module: module || undefined,
        search: debounced || undefined,
        limit: 150,
      }),
    enabled: Boolean(projectId),
  });

  // Both lists load up front so each tab label shows its real count.
  const { data: scenarios } = useQuery({
    queryKey: ['scenarios', projectId, module],
    queryFn: () => api.listScenarios({ project_id: projectId!, module: module || undefined, limit: 150 }),
    enabled: Boolean(projectId),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  const duplicates = (cases?.items ?? []).filter((item) => item.duplicate_of_id);

  return (
    <div>
      <PageHeader
        title="Test Design"
        description="Scenarios generated from requirements, and the executable test cases derived from them."
        actions={
          <div className="flex gap-1 rounded border border-line p-0.5">
            {([
              ['cases', `Test cases (${cases?.total ?? 0})`],
              ['scenarios', `Scenarios (${scenarios?.total ?? 0})`],
            ] as const).map(([value, label]) => (
              <button
                key={value}
                onClick={() => setView(value)}
                aria-pressed={view === value}
                className={cn(
                  'rounded px-3 py-1.5 text-xs font-medium transition-colors',
                  view === value ? 'bg-navy-700 text-white' : 'text-ink-secondary hover:bg-surface-muted',
                )}
              >
                {label}
              </button>
            ))}
          </div>
        }
      />

      {duplicates.length ? (
        <div role="status" className="mb-4 rounded-lg border border-warning-border bg-warning-bg px-4 py-2.5 text-sm text-warning-text">
          {duplicates.length} test case{duplicates.length === 1 ? ' is' : 's are'} flagged as likely duplicates by
          the Duplicate Test Case Detection agent. They are flagged, not deleted — consolidation stays a human decision.
        </div>
      ) : null}

      <div className={cn('grid gap-5', selected && 'lg:grid-cols-[1fr_420px]')}>
        <Card>
          <CardHeader
            title={view === 'cases' ? 'Test cases' : 'Test scenarios'}
            actions={
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" aria-hidden />
                  <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search" aria-label="Search" className="h-8 w-40 pl-8 text-sm" />
                </div>
                <Select aria-label="Filter by module" className="h-8 w-36 text-sm" value={module} onChange={(event) => setModule(event.target.value)}>
                  <option value="">All modules</option>
                  {(project?.modules ?? []).map((item) => (
                    <option key={item} value={item}>{item}</option>
                  ))}
                </Select>
              </div>
            }
          />
          <CardBody className="p-0">
            {view === 'cases' ? (
              cases?.items.length ? (
                <ul className="divide-y divide-line-subtle">
                  {cases.items.map((testCase) => (
                    <li key={testCase.id}>
                      <button
                        type="button"
                        onClick={() => setSelected(testCase)}
                        className={cn(
                          'flex w-full items-center gap-3 px-5 py-3 text-left transition-colors',
                          selected?.id === testCase.id ? 'bg-brand-50' : 'hover:bg-surface-muted',
                        )}
                      >
                        <span className="min-w-0 flex-1">
                          <span className="flex flex-wrap items-center gap-2">
                            <code className="font-mono text-xs text-ink-tertiary">{testCase.key}</code>
                            <span className="truncate text-sm font-medium text-ink">{testCase.title}</span>
                          </span>
                          <span className="mt-0.5 flex flex-wrap items-center gap-2 text-2xs text-ink-tertiary">
                            <span>{testCase.module}</span>
                            <span>· {testCase.steps.length} steps</span>
                            {testCase.execution_count > 0 ? (
                              <span>· run {testCase.execution_count}×</span>
                            ) : null}
                            {testCase.flakiness_score > 0.15 ? (
                              <span className="text-warning-text">· flaky {formatPercent(testCase.flakiness_score, 0)}</span>
                            ) : null}
                          </span>
                        </span>
                        {testCase.duplicate_of_id ? <Badge tone="warning" className="shrink-0">duplicate?</Badge> : null}
                        {testCase.is_automated ? (
                          <Badge tone="success" className="shrink-0">automated</Badge>
                        ) : (
                          <Badge tone="neutral" className="shrink-0">manual</Badge>
                        )}
                        {testCase.last_result ? (
                          <Badge
                            tone={testCase.last_result === 'passed' ? 'success' : testCase.last_result === 'failed' ? 'danger' : 'warning'}
                            className="shrink-0"
                          >
                            {testCase.last_result}
                          </Badge>
                        ) : null}
                      </button>
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState icon={<FileText className="h-5 w-5" />} title="No test cases match" />
              )
            ) : scenarios?.items.length ? (
              <ul className="divide-y divide-line-subtle">
                {scenarios.items.map((scenario) => (
                  <li key={scenario.id} className="px-5 py-3">
                    <p className="flex flex-wrap items-center gap-2">
                      <code className="font-mono text-xs text-ink-tertiary">{scenario.key}</code>
                      <span className="text-sm font-medium text-ink">{scenario.title}</span>
                      <Badge tone={TYPE_TONE[scenario.scenario_type] ?? 'neutral'}>{scenario.scenario_type}</Badge>
                      <Badge tone="neutral">{scenario.module}</Badge>
                      {scenario.confidence ? (
                        <span className="tabular text-2xs text-ink-tertiary">
                          {formatPercent(scenario.confidence, 0)} confidence
                        </span>
                      ) : null}
                    </p>
                    {scenario.description ? (
                      <p className="mt-1 text-xs text-ink-secondary">{scenario.description}</p>
                    ) : null}
                    {scenario.generated_by_agent ? (
                      <p className="mt-1 text-2xs text-ink-tertiary">Generated by {scenario.generated_by_agent}</p>
                    ) : null}
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={<ListTree className="h-5 w-5" />} title="No scenarios yet" />
            )}
          </CardBody>
        </Card>

        {selected ? (
          <Card className="self-start">
            <CardHeader
              title={selected.key}
              description={selected.title}
              actions={
                <button onClick={() => setSelected(null)} aria-label="Close panel" className="rounded p-1 text-ink-tertiary hover:bg-surface-sunken hover:text-ink">
                  ×
                </button>
              }
            />
            <CardBody className="space-y-4">
              <div className="flex flex-wrap gap-1.5">
                <Badge tone="neutral">{selected.module}</Badge>
                <Badge tone="neutral">{selected.test_type}</Badge>
                <Badge tone={selected.priority === 'critical' ? 'danger' : 'warning'}>{selected.priority}</Badge>
                {selected.is_automated ? <Badge tone="success">automated</Badge> : null}
              </div>

              {selected.objective ? (
                <p className="text-sm leading-relaxed text-ink-secondary">{selected.objective}</p>
              ) : null}

              {selected.preconditions.length ? (
                <section>
                  <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Preconditions</h4>
                  <ul className="space-y-1">
                    {selected.preconditions.map((item, index) => (
                      <li key={index} className="text-sm text-ink-secondary">• {item}</li>
                    ))}
                  </ul>
                </section>
              ) : null}

              <section>
                <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Steps</h4>
                <ol className="space-y-1.5">
                  {selected.steps.map((step) => (
                    <li key={step.step} className="flex gap-2.5 text-sm">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-surface-sunken text-2xs font-semibold text-ink-secondary">
                        {step.step}
                      </span>
                      <span className="text-ink-secondary">
                        {step.action}
                        {step.data ? <span className="ml-1 text-ink-tertiary">({step.data})</span> : null}
                      </span>
                    </li>
                  ))}
                </ol>
              </section>

              {selected.expected_result ? (
                <section className="rounded border border-success-border bg-success-bg px-3 py-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wide text-success-text">Expected result</h4>
                  <p className="mt-1 text-sm text-success-text/90">{selected.expected_result}</p>
                </section>
              ) : null}

              <dl className="grid grid-cols-2 gap-x-4 border-t border-line pt-2 text-sm">
                <div className="py-1.5">
                  <dt className="text-2xs uppercase text-ink-tertiary">Executions</dt>
                  <dd className="tabular text-ink">{selected.execution_count}</dd>
                </div>
                <div className="py-1.5">
                  <dt className="text-2xs uppercase text-ink-tertiary">Failures</dt>
                  <dd className="tabular text-ink">{selected.failure_count}</dd>
                </div>
                <div className="py-1.5">
                  <dt className="text-2xs uppercase text-ink-tertiary">Flakiness</dt>
                  <dd className="tabular text-ink">{formatPercent(selected.flakiness_score, 0)}</dd>
                </div>
                <div className="py-1.5">
                  <dt className="text-2xs uppercase text-ink-tertiary">Avg duration</dt>
                  <dd className="tabular text-ink">{formatDuration(selected.avg_duration_ms)}</dd>
                </div>
              </dl>
            </CardBody>
          </Card>
        ) : null}
      </div>
    </div>
  );
}
