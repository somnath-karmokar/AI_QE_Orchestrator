/** Test Data: synthetic data sets, masking status and generated SQL. */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Database, ShieldCheck, Table } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatRelativeTime } from '@/hooks';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, LoadingBlock, PageHeader,
} from '@/design-system/primitives';
import type { TestDataSet } from '@/types';

const VARIANT_TONE: Record<string, 'success' | 'danger' | 'warning'> = {
  valid: 'success', invalid: 'danger', boundary: 'warning',
};

export default function TestDataPage() {
  const projectId = useProjectId();
  const [selected, setSelected] = useState<TestDataSet | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['test-data', projectId],
    queryFn: () => api.listTestData({ project_id: projectId!, limit: 50 }),
    enabled: Boolean(projectId),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  const dataSets = data?.items ?? [];
  const active = selected ?? dataSets[0] ?? null;
  const fields = active?.schema_definition?.fields ?? (active?.records[0] ? Object.keys(active.records[0]).filter((key) => key !== '_variant') : []);

  return (
    <div>
      <PageHeader
        title="Test Data"
        description="Synthetic, masked data sets covering valid, invalid and boundary conditions. No production personal data ever enters a non-production environment."
      />

      <div className="grid gap-5 lg:grid-cols-[300px_1fr]">
        <Card className="self-start">
          <CardHeader title="Data sets" description={`${dataSets.length} available`} />
          <CardBody className="p-2">
            {dataSets.length ? (
              <ul className="space-y-0.5">
                {dataSets.map((dataSet) => {
                  const stale =
                    dataSet.updated_at &&
                    Date.now() - new Date(dataSet.updated_at).getTime() > 30 * 86400 * 1000;
                  return (
                    <li key={dataSet.id}>
                      <button
                        type="button"
                        onClick={() => setSelected(dataSet)}
                        className={cn(
                          'w-full rounded px-3 py-2.5 text-left transition-colors',
                          active?.id === dataSet.id ? 'bg-brand-50' : 'hover:bg-surface-muted',
                        )}
                      >
                        <span className="block truncate text-sm font-medium text-ink">{dataSet.name}</span>
                        <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-2xs text-ink-tertiary">
                          <span>{dataSet.record_count} records</span>
                          {dataSet.contains_pii ? (
                            dataSet.masking_applied ? (
                              <Badge tone="success">masked</Badge>
                            ) : (
                              <Badge tone="danger">unmasked PII</Badge>
                            )
                          ) : null}
                          {stale ? <Badge tone="warning">stale</Badge> : null}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <EmptyState icon={<Database className="h-5 w-5" />} title="No data sets" description="Run the Test Data Generator agent." />
            )}
          </CardBody>
        </Card>

        {active ? (
          <div className="space-y-5">
            <Card>
              <CardHeader
                title={active.name}
                description={active.description ?? undefined}
                actions={
                  <div className="flex items-center gap-2">
                    {active.masking_applied ? (
                      <Badge tone="success">
                        <ShieldCheck className="h-3 w-3" /> Masking applied
                      </Badge>
                    ) : null}
                    <Badge tone="neutral">{active.data_type}</Badge>
                  </div>
                }
              />
              <CardBody className="p-0">
                <div className="flex flex-wrap gap-4 border-b border-line px-5 py-3 text-sm">
                  <span className="text-ink-secondary">
                    Module: <span className="font-medium text-ink">{active.module}</span>
                  </span>
                  <span className="text-ink-secondary">
                    Records: <span className="tabular font-medium text-ink">{active.record_count}</span>
                  </span>
                  <span className="text-ink-secondary">
                    Fields: <span className="tabular font-medium text-ink">{fields.length}</span>
                  </span>
                  <span className="text-ink-secondary">
                    Refreshed: <span className="font-medium text-ink">{formatRelativeTime(active.updated_at)}</span>
                  </span>
                  {active.generated_by_agent ? (
                    <span className="text-ink-secondary">
                      By: <span className="font-medium text-ink">{active.generated_by_agent}</span>
                    </span>
                  ) : null}
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-sm" style={{ minWidth: Math.max(720, fields.length * 140) }}>
                    <thead>
                      <tr className="border-b border-line bg-surface-muted text-left">
                        <th scope="col" className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                          Variant
                        </th>
                        {fields.map((field) => (
                          <th key={field} scope="col" className="px-4 py-2 font-mono text-xs font-semibold text-ink-tertiary">
                            {field}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {active.records.slice(0, 25).map((record, index) => (
                        <tr key={index} className="data-grid-row">
                          <td className="px-4 py-2">
                            <Badge tone={VARIANT_TONE[String(record._variant ?? 'valid')] ?? 'neutral'}>
                              {String(record._variant ?? 'valid')}
                            </Badge>
                          </td>
                          {fields.map((field) => {
                            const value = String(record[field] ?? '');
                            const redacted = value.startsWith('[REDACTED') || value.includes('****') || value.startsWith('pbkdf2$');
                            return (
                              <td
                                key={field}
                                className={cn('px-4 py-2 font-mono text-xs', redacted ? 'text-ink-tertiary' : 'text-ink-secondary')}
                              >
                                {value}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {active.records.length > 25 ? (
                  <p className="border-t border-line px-5 py-2 text-xs text-ink-tertiary">
                    Showing 25 of {active.records.length} records.
                  </p>
                ) : null}
              </CardBody>
            </Card>

            {active.sql_scripts?.length ? (
              <Card>
                <CardHeader title="Generated SQL" description="Parameterised setup, validation and cleanup" icon={<Table className="h-4 w-4" />} />
                <CardBody className="space-y-3">
                  {active.sql_scripts.map((script) => (
                    <div key={script.name}>
                      <p className="mb-1 flex items-center gap-2">
                        <Badge tone="brand">{script.name}</Badge>
                        <span className="text-xs text-ink-secondary">{script.purpose}</span>
                      </p>
                      <pre className="overflow-x-auto rounded border border-line bg-surface-sunken px-3 py-2 font-mono text-xs text-ink">
                        {script.sql}
                      </pre>
                    </div>
                  ))}
                </CardBody>
              </Card>
            ) : null}
          </div>
        ) : null}
      </div>
    </div>
  );
}
