/** Automation: generated Playwright scripts, their locator quality and page objects. */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Code2, FileCode2, ShieldCheck, TriangleAlert } from 'lucide-react';
import { api } from '@/services/api';
import { CodeEditor } from '@/components/CodeEditor';
import { useProjectId, formatPercent } from '@/hooks';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, LoadingBlock, PageHeader,
} from '@/design-system/primitives';

// Ordered by resilience; anything below `text` is flagged as brittle.
const STRATEGY_TONE: Record<string, 'success' | 'info' | 'warning' | 'danger'> = {
  test_id: 'success', role: 'success', label: 'success',
  placeholder: 'info', text: 'warning', css: 'warning', xpath: 'danger',
};

export default function AutomationPage() {
  const projectId = useProjectId();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tab, setTab] = useState<'test' | 'page_object'>('test');

  const { data, isLoading } = useQuery({
    queryKey: ['scripts', projectId],
    queryFn: () => api.listScripts({ project_id: projectId!, limit: 100 }),
    enabled: Boolean(projectId),
  });

  const scripts = data?.items ?? [];
  const active = scripts.find((script) => script.id === selectedId) ?? scripts[0] ?? null;

  if (isLoading) return <LoadingBlock rows={8} />;

  const allLocators = scripts.flatMap((script) => script.locators ?? []);
  const resilient = allLocators.filter((locator) => ['test_id', 'role', 'label'].includes(locator.strategy));
  const brittle = allLocators.filter((locator) => ['xpath', 'text'].includes(locator.strategy));

  return (
    <div>
      <PageHeader
        title="Automation"
        description="Playwright test code generated from designed test cases, using the page object pattern and resilient locators."
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Scripts" value={scripts.length} />
        <Stat label="Locators" value={allLocators.length} />
        <Stat
          label="Resilient locators"
          value={allLocators.length ? formatPercent(resilient.length / allLocators.length, 0) : '—'}
          tone="success"
          isText
        />
        <Stat label="Brittle locators" value={brittle.length} tone={brittle.length ? 'warning' : undefined} />
      </div>

      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <Card className="self-start">
          <CardHeader title="Generated scripts" description={`${scripts.length} files`} />
          <CardBody className="max-h-[600px] overflow-y-auto p-2">
            {scripts.length ? (
              <ul className="space-y-0.5">
                {scripts.map((script) => (
                  <li key={script.id}>
                    <button
                      type="button"
                      onClick={() => setSelectedId(script.id)}
                      className={cn(
                        'w-full rounded px-3 py-2.5 text-left transition-colors',
                        active?.id === script.id ? 'bg-brand-50' : 'hover:bg-surface-muted',
                      )}
                    >
                      <span className="block truncate font-mono text-xs text-ink">{script.file_path}</span>
                      <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-2xs text-ink-tertiary">
                        <span>{script.framework}</span>
                        <span>· v{script.version}</span>
                        {script.healing_count > 0 ? (
                          <span className="text-success-text">· healed {script.healing_count}×</span>
                        ) : null}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={<Code2 className="h-5 w-5" />} title="No scripts yet" description="Run the Auto Script Generator agent." />
            )}
          </CardBody>
        </Card>

        {active ? (
          <div className="space-y-5">
            <Card className="overflow-hidden">
              <CardHeader
                title={active.name}
                description={active.file_path}
                actions={
                  <div className="flex gap-1 rounded border border-line p-0.5">
                    {([
                      ['test', 'Test'],
                      ['page_object', 'Page object'],
                    ] as const).map(([value, label]) => (
                      <button
                        key={value}
                        onClick={() => setTab(value)}
                        aria-pressed={tab === value}
                        disabled={value === 'page_object' && !active.page_objects?.length}
                        className={cn(
                          'rounded px-3 py-1 text-xs font-medium transition-colors disabled:opacity-40',
                          tab === value ? 'bg-navy-700 text-white' : 'text-ink-secondary hover:bg-surface-muted',
                        )}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                }
              />
              <div className="h-[440px] border-t border-line">
                <CodeEditor
                  height="100%"
                  defaultLanguage={active.language === 'javascript' ? 'javascript' : 'python'}
                  language={active.language === 'javascript' ? 'javascript' : 'python'}
                  value={tab === 'test' ? active.code : active.page_objects?.[0]?.code ?? ''}
                  theme="vs"
                  options={{
                    readOnly: true,
                    minimap: { enabled: false },
                    fontSize: 12,
                    fontFamily: 'JetBrains Mono, monospace',
                    lineNumbers: 'on',
                    scrollBeyondLastLine: false,
                    renderLineHighlight: 'none',
                    padding: { top: 12, bottom: 12 },
                  }}
                />
              </div>
            </Card>

            <div className="grid gap-5 md:grid-cols-2">
              <Card>
                <CardHeader title="Locators" description="Strategy chosen per element, ranked by resilience" />
                <CardBody className="p-0">
                  <ul className="divide-y divide-line-subtle">
                    {(active.locators ?? []).map((locator) => (
                      <li key={locator.name} className="px-5 py-2.5">
                        <p className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-medium text-ink">{locator.description}</span>
                          <Badge tone={STRATEGY_TONE[locator.strategy] ?? 'neutral'}>{locator.strategy}</Badge>
                          <span className="tabular ml-auto text-2xs text-ink-tertiary">
                            {formatPercent(locator.confidence, 0)}
                          </span>
                        </p>
                        <code className="mt-1 block overflow-x-auto whitespace-nowrap font-mono text-2xs text-ink-secondary">
                          {locator.locator}
                        </code>
                      </li>
                    ))}
                  </ul>
                </CardBody>
              </Card>

              <Card>
                <CardHeader title="Quality notes" description="How this code was built to stay maintainable" icon={<ShieldCheck className="h-4 w-4" />} />
                <CardBody>
                  <ul className="space-y-2">
                    {(active.quality_notes ?? []).map((note, index) => {
                      const warning = note.toLowerCase().includes('harden') || note.toLowerCase().includes('brittle');
                      return (
                        <li key={index} className="flex gap-2 text-sm">
                          {warning ? (
                            <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />
                          ) : (
                            <FileCode2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-tertiary" />
                          )}
                          <span className={warning ? 'text-warning-text' : 'text-ink-secondary'}>{note}</span>
                        </li>
                      );
                    })}
                  </ul>
                </CardBody>
              </Card>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function Stat({ label, value, tone, isText }: { label: string; value: number | string; tone?: 'success' | 'warning'; isText?: boolean }) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p className={cn('tabular mt-1 font-semibold', isText ? 'text-xl' : 'text-2xl', tone === 'success' ? 'text-success-text' : tone === 'warning' ? 'text-warning-text' : 'text-ink')}>
          {value}
        </p>
      </CardBody>
    </Card>
  );
}
