/**
 * Custom Agent Builder (spec §7) with progressive disclosure (spec §26):
 * the simple view covers goal, instructions and contract; advanced settings
 * (model, budgets, guardrails, retry) are behind a toggle.
 */
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowRight, ChevronDown, FlaskConical, Rocket, Save, Settings2, X } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId } from '@/hooks';
import { useWorkspace } from '@/store';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, Field, Input, LoadingBlock,
  PageHeader, Select, statusTone, Textarea,
} from '@/design-system/primitives';

const CATEGORIES = [
  'Requirements', 'Planning', 'Test Design', 'Test Data', 'Automation', 'Execution',
  'Defect Intelligence', 'RCA', 'UAT', 'Performance', 'Accessibility', 'Governance', 'Reporting',
];
const CAPABILITIES = ['classification', 'structured_extraction', 'generation', 'reasoning'];
const TOOLS = ['jira', 'confluence', 'git', 'database', 'cicd', 'playwright', 'knowledge'];

export default function AgentBuilderPage() {
  const { agentId } = useParams<{ agentId: string }>();
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isEditing = Boolean(agentId);

  const project = useWorkspace((state) => state.project);
  const [advanced, setAdvanced] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);
  const [testInputs, setTestInputs] = useState<Record<string, string>>({});
  const [form, setForm] = useState({
    name: '',
    description: '',
    category: 'Test Design',
    goal: '',
    system_instructions: '',
    capability: 'generation',
    risk_level: 'low',
    cost_tier: 'low',
    requires_approval: false,
    supported_tools: [] as string[],
    temperature: 0.1,
    max_tokens: 2500,
    token_budget: 40000,
    cost_budget_usd: 2,
    timeout_seconds: 120,
    guardrails: [
      'Ground all claims in retrieved project context.',
      'Never expose secrets, credentials or raw personal data.',
    ] as string[],
    input_fields: 'module\nrequirement_key',
  });

  const { data: existing, isLoading } = useQuery({
    queryKey: ['agent', agentId],
    queryFn: () => api.getAgent(agentId!),
    enabled: isEditing,
  });

  useEffect(() => {
    if (!existing) return;
    setForm({
      name: existing.name,
      description: existing.description ?? '',
      category: existing.category,
      goal: existing.goal ?? '',
      system_instructions: existing.system_instructions ?? '',
      capability: existing.capability,
      risk_level: existing.risk_level,
      cost_tier: existing.cost_tier,
      requires_approval: existing.requires_approval,
      supported_tools: existing.supported_tools ?? [],
      temperature: existing.temperature,
      max_tokens: existing.max_tokens,
      token_budget: existing.token_budget,
      cost_budget_usd: existing.cost_budget_usd,
      timeout_seconds: existing.timeout_seconds,
      guardrails: existing.guardrails ?? [],
      input_fields: Object.keys(existing.input_schema?.properties ?? {}).join('\n'),
    });
  }, [existing]);

  function buildPayload() {
    const fields = form.input_fields
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean);
    return {
      name: form.name.trim(),
      description: form.description.trim() || undefined,
      category: form.category,
      goal: form.goal.trim() || undefined,
      system_instructions: form.system_instructions.trim() || undefined,
      capability: form.capability,
      risk_level: form.risk_level,
      cost_tier: form.cost_tier,
      requires_approval: form.requires_approval,
      supported_tools: form.supported_tools,
      mcp_servers: form.supported_tools,
      temperature: form.temperature,
      max_tokens: form.max_tokens,
      token_budget: form.token_budget,
      cost_budget_usd: form.cost_budget_usd,
      timeout_seconds: form.timeout_seconds,
      guardrails: form.guardrails,
      // Field list becomes a JSON Schema the runtime validates against.
      input_schema: {
        type: 'object',
        required: fields.slice(0, 1),
        properties: Object.fromEntries(
          fields.map((field) => [field, { type: 'string', description: `Value for ${field.replace(/_/g, ' ')}` }]),
        ),
      },
      project_id: projectId,
    };
  }

  const save = useMutation({
    mutationFn: () =>
      isEditing ? api.updateAgent(agentId!, buildPayload()) : api.createAgent(buildPayload()),
    onSuccess: (agent) => {
      void queryClient.invalidateQueries({ queryKey: ['agents-mine', projectId] });
      void queryClient.invalidateQueries({ queryKey: ['agent', agent.id] });
      if (!isEditing) navigate(`/agents/${agent.id}/edit`);
      else setError(null);
    },
    onError: (caught) =>
      setError(caught instanceof ApiError ? caught.message : 'Could not save the agent.'),
  });

  const testAgent = useMutation({
    mutationFn: () =>
      api.testAgent(agentId!, {
        project_id: projectId!,
        inputs: Object.fromEntries(Object.entries(testInputs).filter(([, value]) => value.trim())),
      }),
    onSuccess: (run) => navigate(`/runs/${run.id}`),
    onError: (caught) =>
      setError(caught instanceof ApiError ? caught.message : 'The test run failed.'),
  });

  const publish = useMutation({
    mutationFn: () => api.publishAgent(agentId!, { change_summary: 'Published from the agent builder.' }),
    onSuccess: (published) => {
      void queryClient.invalidateQueries({ queryKey: ['agent', agentId] });
      void queryClient.invalidateQueries({ queryKey: ['agents-mine', projectId] });
      void queryClient.invalidateQueries({ queryKey: ['agents-all', projectId] });
      setError(null);
      setNotice(`Published version ${published.version}. It is now in the Agent Marketplace and can be added to flows.`);
    },
    onError: (caught) =>
      setError(caught instanceof ApiError ? caught.message : 'Could not publish the agent.'),
  });

  if (isEditing && isLoading) return <LoadingBlock rows={8} />;

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  const inputNames = form.input_fields
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);

  function openTest() {
    setError(null);
    setNotice(null);
    // Pre-fill what the demo project can answer, so a first test run just works.
    setTestInputs((current) =>
      Object.fromEntries(
        inputNames.map((name) => [name, current[name] ?? (name === 'module' ? project?.modules?.[0] ?? '' : '')]),
      ),
    );
    setTesting(true);
  }

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title={isEditing ? `Edit ${existing?.name ?? 'agent'}` : 'Create an agent'}
        description="Define what the agent does, what it needs, and the policy it runs under. It becomes available in the marketplace once published."
        breadcrumb={
          <Link to="/my-agents" className="text-sm text-ink-secondary hover:text-brand-600">
            ← My agents
          </Link>
        }
        actions={
          <>
            {existing ? <Badge tone={statusTone(existing.lifecycle_state)}>{existing.lifecycle_state}</Badge> : null}
            {isEditing ? (
              <>
                <Button variant="secondary" icon={<FlaskConical className="h-3.5 w-3.5" />} onClick={openTest}>
                  Test
                </Button>
                <Button variant="secondary" icon={<Rocket className="h-3.5 w-3.5" />} loading={publish.isPending} onClick={() => publish.mutate()}>
                  Publish
                </Button>
              </>
            ) : null}
            <Button
              variant="primary"
              icon={<Save className="h-3.5 w-3.5" />}
              disabled={!form.name.trim()}
              loading={save.isPending}
              onClick={() => {
                setError(null);
                save.mutate();
              }}
            >
              {isEditing ? 'Save changes' : 'Create agent'}
            </Button>
          </>
        }
      />

      {error ? (
        <div role="alert" className="mb-4 rounded-lg border border-danger-border bg-danger-bg px-4 py-2.5 text-sm text-danger-text">
          {error}
        </div>
      ) : null}

      {notice ? (
        <div role="status" className="mb-4 flex items-center justify-between gap-3 rounded-lg border border-success-border bg-success-bg px-4 py-2.5 text-sm text-success-text">
          <span>{notice}</span>
          <Link to={`/marketplace/${agentId}`} className="inline-flex shrink-0 items-center gap-1 font-medium hover:underline">
            View in marketplace <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      ) : null}

      {testing && isEditing ? (
        <Card className="mb-5">
          <CardHeader
            title="Test this agent"
            description="Runs the saved version once against this project's data and opens the run."
            icon={<FlaskConical className="h-4 w-4" />}
            actions={
              <Button variant="ghost" size="sm" icon={<X className="h-3.5 w-3.5" />} onClick={() => setTesting(false)}>
                Close
              </Button>
            }
          />
          <CardBody className="space-y-4">
            {inputNames.length ? (
              <div className="grid gap-4 sm:grid-cols-2">
                {inputNames.map((name, index) => (
                  <Field key={name} label={name.replace(/_/g, ' ')} htmlFor={`test-${name}`} required={index === 0}>
                    <Input
                      id={`test-${name}`}
                      value={testInputs[name] ?? ''}
                      placeholder={name === 'requirement_key' ? 'e.g. PAY-201' : name === 'module' ? 'e.g. Payments' : ''}
                      onChange={(event) => setTestInputs((current) => ({ ...current, [name]: event.target.value }))}
                    />
                  </Field>
                ))}
              </div>
            ) : (
              <p className="text-sm text-ink-secondary">This agent takes no inputs.</p>
            )}
            <Button
              variant="primary"
              icon={<FlaskConical className="h-3.5 w-3.5" />}
              loading={testAgent.isPending}
              disabled={Boolean(inputNames[0]) && !testInputs[inputNames[0]]?.trim()}
              onClick={() => testAgent.mutate()}
            >
              Run test
            </Button>
          </CardBody>
        </Card>
      ) : null}

      <div className="space-y-5">
        <Card>
          <CardHeader title="Definition" description="What this agent is and what it aims to achieve" />
          <CardBody className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Agent name" htmlFor="name" required>
                <Input id="name" value={form.name} onChange={(event) => set('name', event.target.value)} placeholder="e.g. API Contract Validator" />
              </Field>
              <Field label="Category" htmlFor="category">
                <Select id="category" value={form.category} onChange={(event) => set('category', event.target.value)}>
                  {CATEGORIES.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>

            <Field label="Description" htmlFor="description" hint="Shown on the marketplace card.">
              <Textarea id="description" rows={2} value={form.description} onChange={(event) => set('description', event.target.value)} />
            </Field>

            <Field label="Goal" htmlFor="goal" hint="One sentence: what a successful run achieves.">
              <Input id="goal" value={form.goal} onChange={(event) => set('goal', event.target.value)} />
            </Field>

            <Field
              label="System instructions"
              htmlFor="instructions"
              hint="How the agent should reason and what standards to hold itself to."
            >
              <Textarea
                id="instructions"
                rows={5}
                value={form.system_instructions}
                onChange={(event) => set('system_instructions', event.target.value)}
                placeholder="You are a ... Your job is to ... Always ..."
              />
            </Field>

            <Field
              label="Input fields"
              htmlFor="inputs"
              hint="One per line. The first becomes required. These form the agent's input contract."
            >
              <Textarea
                id="inputs"
                rows={3}
                value={form.input_fields}
                onChange={(event) => set('input_fields', event.target.value)}
                className="font-mono text-xs"
              />
            </Field>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Tools" description="MCP servers this agent is permitted to call" />
          <CardBody>
            <div className="flex flex-wrap gap-2">
              {TOOLS.map((tool) => {
                const active = form.supported_tools.includes(tool);
                return (
                  <button
                    key={tool}
                    type="button"
                    aria-pressed={active}
                    onClick={() =>
                      set(
                        'supported_tools',
                        active ? form.supported_tools.filter((item) => item !== tool) : [...form.supported_tools, tool],
                      )
                    }
                    className={cn(
                      'rounded border px-3 py-1.5 font-mono text-xs font-medium transition-colors',
                      active
                        ? 'border-brand-500 bg-brand-50 text-brand-700'
                        : 'border-line-strong bg-surface text-ink-secondary hover:border-ink-tertiary hover:text-ink',
                    )}
                  >
                    {tool}
                  </button>
                );
              })}
            </div>
            <p className="mt-3 text-xs text-ink-tertiary">
              Tool access is enforced at run time: the agent can only call tools it declares here, and
              governance policy still gates mutating operations.
            </p>
          </CardBody>
        </Card>

        {/* Progressive disclosure: advanced settings stay collapsed by default. */}
        <Card>
          <button
            type="button"
            onClick={() => setAdvanced((open) => !open)}
            aria-expanded={advanced}
            className="flex w-full items-center justify-between px-5 py-4 text-left transition-colors hover:bg-surface-muted"
          >
            <span className="flex items-center gap-2.5">
              <Settings2 className="h-4 w-4 text-ink-secondary" />
              <span>
                <span className="block text-md font-semibold text-ink">Advanced configuration</span>
                <span className="block text-sm text-ink-secondary">
                  Model policy, budgets, risk classification and guardrails
                </span>
              </span>
            </span>
            <ChevronDown className={cn('h-4 w-4 text-ink-tertiary transition-transform', advanced && 'rotate-180')} />
          </button>

          {advanced ? (
            <CardBody className="space-y-4 border-t border-line">
              <div className="grid gap-4 sm:grid-cols-3">
                <Field label="Capability" htmlFor="capability" hint="Routes to a model tier.">
                  <Select id="capability" value={form.capability} onChange={(event) => set('capability', event.target.value)}>
                    {CAPABILITIES.map((capability) => (
                      <option key={capability} value={capability}>
                        {capability.replace(/_/g, ' ')}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Risk level" htmlFor="risk">
                  <Select id="risk" value={form.risk_level} onChange={(event) => set('risk_level', event.target.value)}>
                    {['low', 'medium', 'high', 'critical'].map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Cost tier" htmlFor="cost">
                  <Select id="cost" value={form.cost_tier} onChange={(event) => set('cost_tier', event.target.value)}>
                    {['low', 'medium', 'high'].map((tier) => (
                      <option key={tier} value={tier}>
                        {tier}
                      </option>
                    ))}
                  </Select>
                </Field>
              </div>

              <div className="grid gap-4 sm:grid-cols-4">
                <Field label="Temperature" htmlFor="temperature">
                  <Input id="temperature" type="number" step="0.05" min="0" max="1" value={form.temperature} onChange={(event) => set('temperature', Number(event.target.value))} />
                </Field>
                <Field label="Max tokens" htmlFor="max_tokens">
                  <Input id="max_tokens" type="number" step="100" value={form.max_tokens} onChange={(event) => set('max_tokens', Number(event.target.value))} />
                </Field>
                <Field label="Cost budget (€)" htmlFor="cost_budget">
                  <Input id="cost_budget" type="number" step="0.5" value={form.cost_budget_usd} onChange={(event) => set('cost_budget_usd', Number(event.target.value))} />
                </Field>
                <Field label="Timeout (s)" htmlFor="timeout">
                  <Input id="timeout" type="number" step="10" value={form.timeout_seconds} onChange={(event) => set('timeout_seconds', Number(event.target.value))} />
                </Field>
              </div>

              <Field label="Guardrails" htmlFor="guardrails" hint="One per line. Applied on every invocation.">
                <Textarea
                  id="guardrails"
                  rows={4}
                  value={form.guardrails.join('\n')}
                  onChange={(event) => set('guardrails', event.target.value.split('\n').filter(Boolean))}
                />
              </Field>

              <label className="flex items-start gap-2.5 rounded border border-line bg-surface-muted px-4 py-3">
                <input
                  type="checkbox"
                  checked={form.requires_approval}
                  onChange={(event) => set('requires_approval', event.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-line-strong text-brand-500 focus:ring-brand-500"
                />
                <span>
                  <span className="block text-sm font-medium text-ink">Require human approval before every run</span>
                  <span className="block text-xs text-ink-secondary">
                    Recommended for agents that write to systems of record or act on regulated journeys.
                  </span>
                </span>
              </label>
            </CardBody>
          ) : null}
        </Card>
      </div>
    </div>
  );
}
