/** MCP tool layer and enterprise connectors (spec §9). */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronDown, Lock, Plug, ShieldAlert } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId } from '@/hooks';
import { AgentIcon } from '@/components/AgentIcon';
import {
  Badge, Card, CardBody, CardHeader, cn, EmptyState, LoadingBlock,
  PageHeader, statusTone,
} from '@/design-system/primitives';

export default function IntegrationsPage() {
  const projectId = useProjectId();
  const [expanded, setExpanded] = useState<string | null>(null);

  const { data: servers, isLoading } = useQuery({
    queryKey: ['mcp-servers', projectId],
    queryFn: () => api.mcpServers(projectId!),
    enabled: Boolean(projectId),
  });

  const { data: project } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => api.getProject(projectId!),
    enabled: Boolean(projectId),
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  return (
    <div>
      <PageHeader
        title="Integrations"
        description="Agents reach external systems only through the MCP tool layer, where allowlists, environment restrictions and approval gates are enforced."
      />

      <Card className="mb-5 border-info-border bg-info-bg/40">
        <CardBody className="flex gap-3 py-4">
          <Lock className="mt-0.5 h-4 w-4 shrink-0 text-info-text" />
          <div>
            <p className="text-sm font-semibold text-info-text">Connector mode</p>
            <p className="mt-0.5 text-sm text-ink">
              These connectors run in <strong>demo</strong> mode: they read and write the platform's own
              synthetic project data rather than contacting external systems. Switching a connector to a
              real Jira, Confluence or Git instance is a configuration change — agent and flow definitions
              stay exactly as they are.
            </p>
          </div>
        </CardBody>
      </Card>

      <div className="mb-6 space-y-3">
        {(servers ?? []).map((server) => (
          <Card key={server.key}>
            <button
              type="button"
              onClick={() => setExpanded(expanded === server.key ? null : server.key)}
              aria-expanded={expanded === server.key}
              className="flex w-full items-center gap-4 px-5 py-4 text-left transition-colors hover:bg-surface-muted"
            >
              <AgentIcon name={server.icon} className="h-9 w-9 shrink-0" tone="neutral" />
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-2">
                  <span className="text-md font-semibold text-ink">{server.name}</span>
                  <Badge tone={statusTone(server.status)} dot>{server.status}</Badge>
                  <Badge tone={server.connector_mode === 'demo' ? 'info' : 'success'}>{server.connector_mode}</Badge>
                  {!server.is_enabled ? <Badge tone="neutral">disabled</Badge> : null}
                </p>
                <p className="mt-0.5 text-sm text-ink-secondary">{server.description}</p>
                <p className="mt-1 text-xs text-ink-tertiary">
                  {server.tools.length} discoverable tool{server.tools.length === 1 ? '' : 's'}
                  {server.requires_approval_tools.length
                    ? ` · ${server.requires_approval_tools.length} approval-gated`
                    : ''}
                </p>
              </div>
              <ChevronDown className={cn('h-4 w-4 shrink-0 text-ink-tertiary transition-transform', expanded === server.key && 'rotate-180')} />
            </button>

            {expanded === server.key ? (
              <div className="border-t border-line">
                <ul className="divide-y divide-line-subtle">
                  {server.tools.map((tool) => (
                    <li key={tool.name} className="px-5 py-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <code className="font-mono text-sm font-medium text-ink">{tool.name}</code>
                        {tool.mutating ? <Badge tone="warning">mutating</Badge> : <Badge tone="neutral">read-only</Badge>}
                        {tool.requires_approval ? (
                          <Badge tone="danger">
                            <ShieldAlert className="h-3 w-3" /> requires approval
                          </Badge>
                        ) : null}
                        <Badge tone={tool.risk_level === 'high' ? 'danger' : tool.risk_level === 'medium' ? 'warning' : 'success'}>
                          {tool.risk_level} risk
                        </Badge>
                      </div>
                      <p className="mt-1 text-sm text-ink-secondary">{tool.description}</p>
                      {tool.parameters.length ? (
                        <p className="mt-1.5 flex flex-wrap gap-1.5">
                          {tool.parameters.map((parameter) => (
                            <span
                              key={parameter.name}
                              className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink-secondary"
                              title={parameter.description}
                            >
                              {parameter.name}
                              {parameter.required ? <span className="text-danger">*</span> : null}
                              <span className="ml-1 text-ink-tertiary">{parameter.type}</span>
                            </span>
                          ))}
                        </p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </Card>
        ))}
      </div>

      {project?.integrations?.length ? (
        <Card>
          <CardHeader title="Enterprise connectors" description="Configured systems of record" icon={<Plug className="h-4 w-4" />} />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {project.integrations.map((integration) => (
                <li key={integration.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-2">
                      <span className="text-sm font-medium text-ink">{integration.name}</span>
                      <Badge tone="neutral">{integration.kind}</Badge>
                    </p>
                    {integration.base_url ? (
                      <p className="truncate font-mono text-xs text-ink-tertiary">{integration.base_url}</p>
                    ) : null}
                  </div>
                  <Badge tone={integration.connector_mode === 'demo' ? 'info' : 'success'}>
                    {integration.connector_mode}
                  </Badge>
                  <Badge tone={statusTone(integration.status)}>{integration.status}</Badge>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : (
        <Card>
          <EmptyState icon={<Plug className="h-5 w-5" />} title="No connectors configured" />
        </Card>
      )}
    </div>
  );
}
