/** Knowledge Fabric (spec §8): sources, indexed documents, semantic search and vector health. */
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Database, FileText, Library, RefreshCw, Search, Sparkles } from 'lucide-react';
import { api } from '@/services/api';
import { useProjectId, formatNumber, formatPercent, formatRelativeTime } from '@/hooks';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Input,
  LoadingBlock, PageHeader, ProgressBar, Select, statusTone,
} from '@/design-system/primitives';

const COLLECTIONS = [
  { value: 'qe_knowledge', label: 'Documentation' },
  { value: 'qe_requirements', label: 'Requirements' },
  { value: 'qe_test_cases', label: 'Test cases' },
  { value: 'qe_defects', label: 'Defects' },
  { value: 'qe_execution_history', label: 'Execution history' },
  { value: 'qe_code_context', label: 'Code context' },
];

export default function KnowledgePage() {
  const projectId = useProjectId();
  const queryClient = useQueryClient();

  const [term, setTerm] = useState('');
  const [collection, setCollection] = useState('qe_knowledge');
  const [submitted, setSubmitted] = useState('');
  const [documentId, setDocumentId] = useState<string | null>(null);

  const { data: overview, isLoading } = useQuery({
    queryKey: ['knowledge-overview', projectId],
    queryFn: () => api.knowledgeOverview(projectId!),
    enabled: Boolean(projectId),
  });

  const { data: sources } = useQuery({
    queryKey: ['knowledge-sources', projectId],
    queryFn: () => api.knowledgeSources(projectId!),
    enabled: Boolean(projectId),
  });

  const { data: documents } = useQuery({
    queryKey: ['knowledge-documents', projectId],
    queryFn: () => api.knowledgeDocuments({ project_id: projectId!, limit: 100 }),
    enabled: Boolean(projectId),
  });

  const { data: hits, isFetching: searching } = useQuery({
    queryKey: ['knowledge-search', projectId, submitted, collection],
    queryFn: () => api.knowledgeSearch(projectId!, { query: submitted, collection, limit: 8 }),
    enabled: Boolean(projectId) && submitted.trim().length > 2,
  });

  const { data: document } = useQuery({
    queryKey: ['knowledge-document', documentId],
    queryFn: () => api.knowledgeDocument(documentId!),
    enabled: Boolean(documentId),
  });

  const sync = useMutation({
    mutationFn: () => api.knowledgeSync(projectId!),
    onSuccess: () => {
      // Indexing runs in the background; refresh shortly after it starts.
      setTimeout(() => void queryClient.invalidateQueries({ queryKey: ['knowledge-overview', projectId] }), 4000);
    },
  });

  if (isLoading) return <LoadingBlock rows={8} />;

  return (
    <div>
      <PageHeader
        title="Knowledge Fabric"
        description="The shared intelligence layer every agent reasons over: requirements, documentation, code, tests, defects and execution history."
        actions={
          <Button variant="secondary" icon={<RefreshCw className="h-3.5 w-3.5" />} loading={sync.isPending} onClick={() => sync.mutate()}>
            Re-index
          </Button>
        }
      />

      {sync.isSuccess ? (
        <div role="status" className="mb-4 rounded-lg border border-info-border bg-info-bg px-4 py-2.5 text-sm text-info-text">
          Re-indexing started in the background. Counts update as documents are embedded.
        </div>
      ) : null}

      {overview ? (
        <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <Stat label="Sources" value={overview.source_count} />
          <Stat label="Documents" value={overview.document_count} />
          <Stat label="Chunks" value={formatNumber(overview.chunk_count)} isText />
          <Stat label="Vectors" value={formatNumber(overview.vector_store.total_vectors)} isText />
          <Card>
            <CardBody className="p-4">
              <p className="text-xs font-medium text-ink-secondary">Index coverage</p>
              <p className="tabular mt-1 text-2xl font-semibold text-ink">{formatPercent(overview.index_coverage, 0)}</p>
              <ProgressBar
                value={overview.index_coverage}
                tone={overview.index_coverage > 0.95 ? 'success' : 'warning'}
                className="mt-2"
                label="Index coverage"
              />
            </CardBody>
          </Card>
        </div>
      ) : null}

      <Card className="mb-5">
        <CardHeader
          title="Semantic search"
          description="Retrieval runs through the same pipeline agents use, scoped to this project"
          icon={<Sparkles className="h-4 w-4" />}
        />
        <CardBody>
          <form
            className="flex flex-wrap gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              setSubmitted(term);
            }}
          >
            <div className="relative min-w-[240px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" aria-hidden />
              <Input
                value={term}
                onChange={(event) => setTerm(event.target.value)}
                placeholder="e.g. what is the daily payment limit?"
                aria-label="Search the knowledge fabric"
                className="pl-9"
              />
            </div>
            <Select aria-label="Collection" className="w-48" value={collection} onChange={(event) => setCollection(event.target.value)}>
              {COLLECTIONS.map((item) => (
                <option key={item.value} value={item.value}>{item.label}</option>
              ))}
            </Select>
            <Button type="submit" variant="primary" loading={searching}>Search</Button>
          </form>

          {hits?.length ? (
            <ul className="mt-4 space-y-2">
              {hits.map((hit) => (
                <li key={hit.id} className="rounded border border-line bg-surface-muted p-3">
                  <p className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium text-ink">
                      {String(hit.metadata.title ?? hit.metadata.external_id ?? 'Knowledge item')}
                    </span>
                    <Badge tone="neutral">{String(hit.metadata.source_type ?? '')}</Badge>
                    {hit.metadata.module ? <Badge tone="neutral">{String(hit.metadata.module)}</Badge> : null}
                    <span
                      className={cn(
                        'tabular ml-auto text-xs font-semibold',
                        hit.score > 0.7 ? 'text-success-text' : hit.score > 0.5 ? 'text-warning-text' : 'text-ink-tertiary',
                      )}
                    >
                      {formatPercent(hit.score, 0)} match
                    </span>
                  </p>
                  <p className="mt-1.5 whitespace-pre-wrap text-xs leading-relaxed text-ink-secondary">
                    {hit.content.slice(0, 320)}
                    {hit.content.length > 320 ? '…' : ''}
                  </p>
                </li>
              ))}
            </ul>
          ) : submitted && !searching ? (
            <p className="mt-4 text-sm text-ink-secondary">No results for “{submitted}” in this collection.</p>
          ) : null}
        </CardBody>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader title="Sources" description="Where knowledge comes from and its sync state" />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {(sources ?? []).map((source) => (
                <li key={source.id} className="flex items-center gap-3 px-5 py-3">
                  <Database className="h-4 w-4 shrink-0 text-ink-tertiary" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-ink">{source.name}</p>
                    <p className="text-xs text-ink-tertiary">
                      {source.document_count} documents · {source.collection_name} ·{' '}
                      {formatRelativeTime(source.last_synced_at)}
                    </p>
                  </div>
                  <Badge tone={source.connector_mode === 'demo' ? 'info' : 'neutral'}>{source.connector_mode}</Badge>
                  <Badge tone={statusTone(source.sync_status)}>{source.sync_status}</Badge>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Vector collections" description="Chroma collection health" />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {(overview?.vector_store.collections ?? []).map((item) => (
                <li key={item.name} className="flex items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-mono text-xs font-medium text-ink">{item.name}</p>
                    <p className="truncate text-xs text-ink-tertiary">{item.description}</p>
                  </div>
                  <span className="tabular shrink-0 text-sm font-medium text-ink-secondary">
                    {formatNumber(item.vector_count)}
                  </span>
                  <Badge tone={statusTone(item.status)}>{item.status}</Badge>
                </li>
              ))}
            </ul>
            {overview?.vector_store ? (
              <p className="border-t border-line px-5 py-3 text-xs text-ink-tertiary">
                {overview.vector_store.provider} · {overview.vector_store.mode} mode
                {overview.vector_store.persist_directory ? ` · ${overview.vector_store.persist_directory}` : ''}
              </p>
            ) : null}
          </CardBody>
        </Card>
      </div>

      <Card className="mt-5">
        <CardHeader title="Indexed documents" description={`${documents?.total ?? 0} documents in the fabric`} />
        <CardBody className="p-0">
          {documents?.items.length ? (
            <ul className="divide-y divide-line-subtle">
              {documents.items.map((doc) => (
                <li key={doc.id}>
                  <button
                    type="button"
                    onClick={() => setDocumentId(documentId === doc.id ? null : doc.id)}
                    aria-expanded={documentId === doc.id}
                    className="flex w-full items-center gap-3 px-5 py-3 text-left transition-colors hover:bg-surface-muted"
                  >
                    <FileText className="h-4 w-4 shrink-0 text-ink-tertiary" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium text-ink">{doc.title}</span>
                      <span className="block text-xs text-ink-tertiary">
                        {doc.source_type} · {doc.module} · {doc.chunk_count} chunks · v{doc.version}
                      </span>
                    </span>
                    <Badge tone={statusTone(doc.index_status)}>{doc.index_status}</Badge>
                  </button>

                  {documentId === doc.id && document ? (
                    <div className="border-t border-line-subtle bg-surface-muted px-5 py-4">
                      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                        Content ({document.chunks.length} chunks indexed)
                      </p>
                      <pre className="max-h-72 overflow-y-auto whitespace-pre-wrap rounded border border-line bg-surface px-3 py-2 text-xs leading-relaxed text-ink-secondary">
                        {document.content}
                      </pre>
                    </div>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState icon={<Library className="h-5 w-5" />} title="No documents indexed" description="Sync a knowledge source to populate the fabric." />
          )}
        </CardBody>
      </Card>
    </div>
  );
}

function Stat({ label, value, isText }: { label: string; value: number | string; isText?: boolean }) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p className={cn('tabular mt-1 font-semibold text-ink', isText ? 'text-xl' : 'text-2xl')}>{value}</p>
      </CardBody>
    </Card>
  );
}
