/**
 * Connecting the systems a customer owns to their own project.
 *
 * The screen is built around one fact: a credential goes in and never comes
 * back out. So the form never pre-fills a secret, the edit form says plainly
 * that leaving a field blank keeps the stored value, and the only evidence a
 * credential exists is that it is marked as stored and carries a fingerprint
 * that changes when it is rotated.
 *
 * The connection test reports what it actually proved. A reachable host is not
 * a working credential, and showing one as the other would leave people
 * believing a password had been checked when it has never been used.
 */
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle, CheckCircle2, Database, Loader2, Lock, Plug, Trash2,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId, formatRelativeTime } from '@/hooks';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Field, Input,
  LoadingBlock, PageHeader, Select, humanize,
} from '@/design-system/primitives';
import type { DataSource, DataSourceKind, DataSourceTestResult } from '@/types';

/** Plain-language labels; the server owns the list of kinds itself. */
const KIND_LABELS: Record<string, string> = {
  postgres: 'PostgreSQL',
  mysql: 'MySQL',
  sqlserver: 'SQL Server',
  oracle: 'Oracle',
  mongodb: 'MongoDB',
  rest_api: 'REST API',
  graphql: 'GraphQL',
  s3: 'Amazon S3',
  azure_blob: 'Azure Blob Storage',
  gcs: 'Google Cloud Storage',
  elasticsearch: 'Elasticsearch',
  snowflake: 'Snowflake',
  jira: 'Jira',
  confluence: 'Confluence',
  git: 'Git repository',
  file_upload: 'Uploaded files',
  custom: 'Something else',
};

const STATUS_TONE = {
  connected: 'success',
  unverified: 'warning',
  error: 'danger',
  disabled: 'neutral',
} as const;

function kindLabel(kind: string): string {
  return KIND_LABELS[kind] ?? humanize(kind);
}

function fieldLabel(name: string): string {
  return humanize(name);
}

function ConnectForm({
  kinds,
  projectId,
  onDone,
}: {
  kinds: DataSourceKind[];
  projectId: string;
  onDone: () => void;
}) {
  const [kind, setKind] = useState('postgres');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [values, setValues] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const selected = useMemo(() => kinds.find((item) => item.kind === kind), [kinds, kind]);
  // Everything the chosen kind asks for: its required settings first, then the
  // fields it treats as secret. Which is which comes from the server, so the
  // form cannot disagree with what actually gets encrypted.
  const requiredFields = selected?.required_fields ?? [];
  const optionalFields = selected?.optional_fields ?? [];
  const secretFields = selected?.credential_fields ?? [];

  const connect = useMutation({
    mutationFn: () =>
      api.connectDataSource(projectId, {
        name,
        kind,
        description: description || undefined,
        connection: Object.fromEntries(
          Object.entries(values).filter(([, value]) => value !== ''),
        ),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['data-sources', projectId] });
      setName('');
      setDescription('');
      setValues({});
      setError(null);
      onDone();
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : String(err)),
  });

  return (
    <Card>
      <CardHeader title="Connect a data source"
        description="Your system, your credentials, this project only." />
      <CardBody className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Name" htmlFor="ds-name" hint="How this source appears to your agents.">
            <Input
              id="ds-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Order warehouse"
            />
          </Field>
          <Field label="Kind" htmlFor="ds-kind">
            <Select
              id="ds-kind"
              value={kind}
              onChange={(event) => {
                setKind(event.target.value);
                setValues({});
              }}
            >
              {kinds.map((item) => (
                <option key={item.kind} value={item.kind}>
                  {kindLabel(item.kind)}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <Field label="Description" htmlFor="ds-description" hint="Optional. What this system holds, for whoever reads it next.">
          <Input id="ds-description" value={description} onChange={(event) => setDescription(event.target.value)} />
        </Field>

        {requiredFields.length + optionalFields.length > 0 && (
          <div className="grid gap-4 sm:grid-cols-2">
            {requiredFields.map((field) => (
              <Field key={field} label={fieldLabel(field)} htmlFor={`ds-${field}`} required>
                <Input
                  id={`ds-${field}`}
                  value={values[field] ?? ''}
                  onChange={(event) => setValues((prev) => ({ ...prev, [field]: event.target.value }))}
                />
              </Field>
            ))}
            {/* Optional settings a kind accepts -- a port, a username, a schema.
                Without these the form could only ask for what is mandatory. */}
            {optionalFields.map((field) => (
              <Field key={field} label={fieldLabel(field)} htmlFor={`ds-${field}`}>
                <Input
                  id={`ds-${field}`}
                  value={values[field] ?? ''}
                  onChange={(event) => setValues((prev) => ({ ...prev, [field]: event.target.value }))}
                />
              </Field>
            ))}
          </div>
        )}

        {secretFields.length > 0 && (
          <div className="rounded-lg border border-border bg-surface-muted/40 p-4">
            <p className="mb-3 flex items-center gap-2 text-sm font-medium text-text">
              <Lock className="h-4 w-4 text-text-muted" aria-hidden />
              Credentials
            </p>
            <p className="mb-3 text-xs text-text-muted">
              Encrypted before they are stored, and never shown again — not on this screen, not in
              the API, not in the audit trail.
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              {secretFields.map((field) => (
                <Field key={field} label={fieldLabel(field)} htmlFor={`ds-${field}`}>
                  <Input
                    id={`ds-${field}`}
                    type="password"
                    autoComplete="new-password"
                    value={values[field] ?? ''}
                    onChange={(event) =>
                      setValues((prev) => ({ ...prev, [field]: event.target.value }))
                    }
                  />
                </Field>
              ))}
            </div>
          </div>
        )}

        {error && (
          <p className="flex items-start gap-2 text-sm text-danger-text" role="alert">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            {error}
          </p>
        )}

        <div className="flex justify-end">
          <Button onClick={() => connect.mutate()} disabled={!name || connect.isPending}>
            {connect.isPending ? 'Connecting…' : 'Connect'}
          </Button>
        </div>
      </CardBody>
    </Card>
  );
}

function TestResult({ result }: { result: DataSourceTestResult }) {
  return (
    <div
      className={cn(
        'rounded-lg border p-3 text-sm',
        result.ok ? 'border-success-border bg-success-bg/40' : 'border-warning-border bg-warning-bg/40',
      )}
      role="status"
    >
      <p className="flex items-center gap-2 font-medium">
        {result.ok ? (
          <CheckCircle2 className="h-4 w-4 text-success-text" aria-hidden />
        ) : (
          <AlertTriangle className="h-4 w-4 text-warning-text" aria-hidden />
        )}
        {result.detail}
      </p>
      {result.proves && (
        // Said explicitly: a reachable host is not a checked credential.
        <p className="mt-1 pl-6 text-xs text-text-muted">{result.proves}</p>
      )}
    </div>
  );
}

function SourceCard({ source, projectId }: { source: DataSource; projectId: string }) {
  const queryClient = useQueryClient();
  const [result, setResult] = useState<DataSourceTestResult | null>(null);
  const [rotating, setRotating] = useState(false);
  const [newSecrets, setNewSecrets] = useState<Record<string, string>>({});

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ['data-sources', projectId] });

  const test = useMutation({
    mutationFn: () => api.testDataSource(projectId, source.id),
    onSuccess: (data) => {
      setResult(data);
      invalidate();
    },
  });

  const rotate = useMutation({
    mutationFn: () =>
      api.updateDataSource(projectId, source.id, {
        connection: Object.fromEntries(
          Object.entries(newSecrets).filter(([, value]) => value !== ''),
        ),
      }),
    onSuccess: () => {
      setRotating(false);
      setNewSecrets({});
      invalidate();
    },
  });

  const disconnect = useMutation({
    mutationFn: () => api.disconnectDataSource(projectId, source.id),
    onSuccess: invalidate,
  });

  const settings = Object.entries(source.config ?? {});

  return (
    <Card>
      <CardHeader
        title={source.name}
        description={source.description ?? kindLabel(source.kind)}
        actions={
          <div className="flex items-center gap-2">
            <Badge tone={STATUS_TONE[source.status] ?? 'neutral'}>{humanize(source.status)}</Badge>
            {source.allow_writes ? (
              <Badge tone="warning">Writes allowed</Badge>
            ) : (
              <Badge tone="neutral">Read-only</Badge>
            )}
          </div>
        }
      />
      <CardBody className="space-y-4">
        <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
          <div className="flex justify-between gap-4 sm:block">
            <dt className="text-text-muted">Kind</dt>
            <dd className="font-medium">{kindLabel(source.kind)}</dd>
          </div>
          {settings.map(([key, value]) => (
            <div key={key} className="flex justify-between gap-4 sm:block">
              <dt className="text-text-muted">{fieldLabel(key)}</dt>
              <dd className="truncate font-mono text-xs">{String(value)}</dd>
            </div>
          ))}
        </dl>

        <div className="rounded-lg border border-border bg-surface-muted/40 p-3 text-sm">
          <p className="flex items-center gap-2 font-medium">
            <Lock className="h-4 w-4 text-text-muted" aria-hidden />
            {source.has_credentials ? 'Credential stored, encrypted' : 'No credential stored'}
          </p>
          {source.has_credentials && (
            <p className="mt-1 pl-6 text-xs text-text-muted">
              Fingerprint <span className="font-mono">{source.credential_fingerprint}</span>
              {source.credential_updated_at && (
                <> · set {formatRelativeTime(source.credential_updated_at)}</>
              )}
              {source.credential_updated_by && <> by {source.credential_updated_by}</>}
              . It cannot be read back — rotate it to replace it.
            </p>
          )}
        </div>

        {source.last_error && !result && (
          <p className="text-sm text-danger-text">{source.last_error}</p>
        )}
        {result && <TestResult result={result} />}

        {rotating && source.credential_fields.length > 0 && (
          <div className="space-y-3 rounded-lg border border-border p-3">
            <p className="text-xs text-text-muted">
              Enter the new values. Anything left blank keeps what is stored.
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              {source.credential_fields.map((field) => (
                <Field key={field} label={fieldLabel(field)} htmlFor={`${source.id}-${field}`}>
                  <Input
                    id={`${source.id}-${field}`}
                    type="password"
                    autoComplete="new-password"
                    value={newSecrets[field] ?? ''}
                    onChange={(event) =>
                      setNewSecrets((prev) => ({ ...prev, [field]: event.target.value }))
                    }
                  />
                </Field>
              ))}
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setRotating(false)}>
                Cancel
              </Button>
              <Button onClick={() => rotate.mutate()} disabled={rotate.isPending}>
                {rotate.isPending ? 'Saving…' : 'Replace credential'}
              </Button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-text-muted">
            {source.last_tested_at
              ? `Last tested ${formatRelativeTime(source.last_tested_at)}`
              : 'Never tested'}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => test.mutate()} disabled={test.isPending}>
              {test.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <Plug className="h-4 w-4" aria-hidden />
              )}
              Test connection
            </Button>
            {source.credential_fields.length > 0 && !rotating && (
              <Button variant="secondary" onClick={() => setRotating(true)}>
                Rotate credential
              </Button>
            )}
            <Button
              variant="ghost"
              onClick={() => {
                if (
                  window.confirm(
                    `Disconnect "${source.name}"? The stored credential is destroyed and agents lose access to it.`,
                  )
                ) {
                  disconnect.mutate();
                }
              }}
              disabled={disconnect.isPending}
            >
              <Trash2 className="h-4 w-4" aria-hidden />
              Disconnect
            </Button>
          </div>
        </div>
      </CardBody>
    </Card>
  );
}

export default function DataSourcesPage() {
  const projectId = useProjectId();
  const [connecting, setConnecting] = useState(false);

  const kinds = useQuery({
    queryKey: ['data-source-kinds'],
    queryFn: () => api.dataSourceKinds(),
    staleTime: 60 * 60 * 1000,
  });

  const sources = useQuery({
    queryKey: ['data-sources', projectId],
    queryFn: () => api.dataSources(projectId!),
    enabled: Boolean(projectId),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Data sources"
        description="Systems you own, connected to this project. Agents and flows read them with your credentials, and no other project can reach them."
        actions={
          !connecting && (
            <Button onClick={() => setConnecting(true)}>Connect a data source</Button>
          )
        }
      />

      {connecting && kinds.data && (
        <ConnectForm kinds={kinds.data} projectId={projectId!} onDone={() => setConnecting(false)} />
      )}

      {sources.isLoading && <LoadingBlock rows={3} />}

      {sources.data && sources.data.length === 0 && !connecting && (
        <EmptyState
          icon={<Database className="h-5 w-5" aria-hidden />}
          title="No data sources connected"
          description="Connect your database, API or object store and this project's agents can read it — with credentials that stay encrypted and stay yours."
          action={<Button onClick={() => setConnecting(true)}>Connect a data source</Button>}
        />
      )}

      <div className="grid gap-4">
        {sources.data?.map((source) => (
          <SourceCard key={source.id} source={source} projectId={projectId!} />
        ))}
      </div>
    </div>
  );
}
