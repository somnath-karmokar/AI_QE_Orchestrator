/** Execution detail with live progress, failure evidence and AI follow-up actions. */
import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Activity, Ban, ChevronDown, FileWarning, Image, Microscope, RefreshCw, Terminal,
} from 'lucide-react';
import { api } from '@/services/api';
import { formatDuration, formatPercent, useEventStream } from '@/hooks';
import { useProjectId } from '@/hooks';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, LoadingBlock,
  PageHeader, ProgressBar, Select, statusTone,
} from '@/design-system/primitives';
import type { ExecutionTestRecord, FailureCluster } from '@/types';

const RESULT_TONE: Record<string, 'success' | 'danger' | 'warning' | 'neutral'> = {
  passed: 'success', failed: 'danger', flaky: 'warning', healed: 'success', skipped: 'neutral', blocked: 'danger',
};

export default function ExecutionDetailPage() {
  const { executionId } = useParams<{ executionId: string }>();
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [filter, setFilter] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);

  const { data: execution, isLoading } = useQuery({
    queryKey: ['execution', executionId],
    queryFn: () => api.getExecution(executionId!),
    enabled: Boolean(executionId),
    refetchInterval: (query) =>
      query.state.data && ['queued', 'running'].includes(query.state.data.status) ? 3000 : false,
  });

  const isActive = execution ? ['queued', 'running'].includes(execution.status) : false;

  const { connected } = useEventStream(
    isActive && executionId ? `/runs/executions/${executionId}/ws` : null,
    {
      terminalTypes: ['execution_completed'],
      onEvent: () => void queryClient.invalidateQueries({ queryKey: ['execution', executionId] }),
    },
  );

  const { data: artifacts } = useQuery({
    queryKey: ['execution-artifacts', executionId],
    queryFn: () => api.executionArtifacts(executionId!),
    enabled: Boolean(executionId) && !isActive,
  });

  // Grouped by root cause: a redesign that broke forty tests is one problem.
  const { data: triage } = useQuery({
    queryKey: ['execution-triage', executionId],
    queryFn: () => api.executionTriage(executionId!),
    enabled: Boolean(executionId) && !isActive && Boolean(execution?.failed),
  });

  const cancel = useMutation({
    mutationFn: () => api.cancelExecution(executionId!),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['execution', executionId] }),
  });

  const retry = useMutation({
    mutationFn: () => api.retryFailed(executionId!),
    onSuccess: (next) => navigate(`/executions/${next.id}`),
  });

  const analyze = useMutation({
    mutationFn: () =>
      api.analyzeDefect({ project_id: projectId, execution_id: executionId, synchronous: true }),
    onSuccess: (run) => navigate(`/runs/${run.id}`),
  });

  const tests = useMemo(() => {
    const rows = execution?.tests ?? [];
    if (!filter) return rows;
    return rows.filter((test) => test.result === filter);
  }, [execution, filter]);

  const artifactsByTest = useMemo(() => {
    const grouped = new Map<string, typeof artifacts>();
    for (const artifact of artifacts ?? []) {
      const testId = (artifact as unknown as { execution_test_id?: string }).execution_test_id;
      if (!testId) continue;
      const list = grouped.get(testId) ?? [];
      list.push(artifact);
      grouped.set(testId, list as typeof artifacts);
    }
    return grouped;
  }, [artifacts]);

  if (isLoading) return <LoadingBlock rows={8} />;
  if (!execution) return <EmptyState title="Execution not found" />;

  const completed = execution.passed + execution.failed + execution.skipped + execution.flaky;
  const progress = execution.total_tests ? completed / execution.total_tests : 0;

  return (
    <div>
      <PageHeader
        title={execution.name}
        description={`${execution.suite_type} suite · ${execution.browser} · ${execution.mode} mode`}
        breadcrumb={
          <Link to="/executions" className="text-sm text-ink-secondary hover:text-brand-600">
            ← Execution Center
          </Link>
        }
        actions={
          <>
            <Badge tone={statusTone(execution.status)} dot>
              {execution.status}
            </Badge>
            {isActive && connected ? (
              <Badge tone="info">
                <Activity className="h-3 w-3 animate-pulse" /> Live
              </Badge>
            ) : null}
            {isActive ? (
              <Button variant="danger" icon={<Ban className="h-3.5 w-3.5" />} loading={cancel.isPending} onClick={() => cancel.mutate()}>
                Stop
              </Button>
            ) : null}
            {execution.failed > 0 ? (
              <>
                <Button variant="secondary" icon={<RefreshCw className="h-3.5 w-3.5" />} loading={retry.isPending} onClick={() => retry.mutate()}>
                  Retry failures
                </Button>
                <Button variant="primary" icon={<Microscope className="h-3.5 w-3.5" />} loading={analyze.isPending} onClick={() => analyze.mutate()}>
                  Run RCA
                </Button>
              </>
            ) : null}
          </>
        }
      />

      {isActive ? (
        <Card className="mb-5">
          <CardBody className="py-4">
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="font-medium text-ink">
                Running {completed} of {execution.total_tests} tests
              </span>
              <span className="tabular text-ink-secondary">{formatPercent(progress, 0)}</span>
            </div>
            <ProgressBar value={progress} label="Execution progress" />
          </CardBody>
        </Card>
      ) : null}

      <div className="mb-5 grid gap-4 sm:grid-cols-3 xl:grid-cols-6">
        <Stat label="Total" value={execution.total_tests} />
        <Stat label="Passed" value={execution.passed} tone="success" />
        <Stat label="Failed" value={execution.failed} tone="danger" />
        <Stat label="Flaky" value={execution.flaky} tone="warning" />
        <Stat label="Healed" value={execution.healed} tone="success" />
        <Stat label="Duration" value={formatDuration(execution.duration_ms)} isText />
      </div>

      {triage && triage.failures > 0 ? (
        <Card className="mb-5">
          <CardHeader
            title="Failure causes"
            description={
              triage.investigations_saved > 0
                ? `${triage.failures} failures trace to ${triage.distinct_causes} distinct causes — ${triage.investigations_saved} fewer investigations`
                : `${triage.failures} failure${triage.failures === 1 ? '' : 's'}, each with its own cause`
            }
          />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {triage.clusters.map((cluster: FailureCluster) => (
                <li key={cluster.signature} className="px-5 py-3.5">
                  <p className="flex flex-wrap items-center gap-2">
                    <Badge tone={cluster.classification.healable ? 'warning' : 'danger'}>
                      {cluster.classification.label}
                    </Badge>
                    <span className="text-xs font-medium text-ink-secondary">
                      {cluster.size} test{cluster.size === 1 ? '' : 's'}
                    </span>
                    <span className="text-xs text-ink-tertiary">{cluster.modules.join(', ')}</span>
                    {cluster.classification.healable ? (
                      <Badge tone="brand">can heal {cluster.classification.change_type}</Badge>
                    ) : null}
                    {cluster.classification.needs_review ? (
                      <Badge tone="neutral">needs a person</Badge>
                    ) : null}
                  </p>
                  <p className="mt-1.5 font-mono text-xs text-ink-secondary">
                    {cluster.representative_message}
                  </p>
                  <p className="mt-1 text-xs text-ink-tertiary">{cluster.classification.guidance}</p>
                  {cluster.test_names.length > 1 ? (
                    <p className="mt-1 text-xs text-ink-tertiary">
                      {cluster.test_names[0]} and {cluster.test_names.length - 1} other
                      {cluster.test_names.length === 2 ? '' : 's'}
                    </p>
                  ) : null}
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : null}

      <Card>
        <CardHeader
          title="Test results"
          description={`${tests.length} shown`}
          actions={
            <Select aria-label="Filter results" className="w-40" value={filter} onChange={(event) => setFilter(event.target.value)}>
              <option value="">All results</option>
              <option value="failed">Failed</option>
              <option value="flaky">Flaky</option>
              <option value="passed">Passed</option>
              <option value="skipped">Skipped</option>
            </Select>
          }
        />
        <CardBody className="p-0">
          {tests.length ? (
            <ul className="divide-y divide-line-subtle">
              {tests.map((test) => (
                <TestRow
                  key={test.id}
                  test={test}
                  expanded={expanded === test.id}
                  onToggle={() => setExpanded(expanded === test.id ? null : test.id)}
                  artifactCount={artifactsByTest.get(test.id)?.length ?? 0}
                />
              ))}
            </ul>
          ) : (
            <EmptyState title="No matching tests" description="Adjust the filter to see other results." />
          )}
        </CardBody>
      </Card>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
  isText,
}: {
  label: string;
  value: number | string;
  tone?: 'success' | 'danger' | 'warning';
  isText?: boolean;
}) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p
          className={cn(
            'tabular mt-1 font-semibold',
            isText ? 'text-lg' : 'text-2xl',
            tone === 'success' ? 'text-success-text' : tone === 'danger' ? 'text-danger-text' : tone === 'warning' ? 'text-warning-text' : 'text-ink',
          )}
        >
          {value}
        </p>
      </CardBody>
    </Card>
  );
}

function TestRow({
  test,
  expanded,
  onToggle,
  artifactCount,
}: {
  test: ExecutionTestRecord;
  expanded: boolean;
  onToggle: () => void;
  artifactCount: number;
}) {
  const hasDetail = Boolean(test.failure_message || test.stack_trace || test.console_logs?.length);

  return (
    <li>
      <button
        type="button"
        onClick={hasDetail ? onToggle : undefined}
        aria-expanded={hasDetail ? expanded : undefined}
        className={cn(
          'flex w-full items-center gap-3 px-5 py-3 text-left transition-colors',
          hasDetail && 'hover:bg-surface-muted',
          !hasDetail && 'cursor-default',
        )}
      >
        <Badge tone={RESULT_TONE[test.result] ?? 'neutral'} className="shrink-0">
          {test.result}
        </Badge>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm text-ink">{test.name}</span>
          <span className="mt-0.5 flex flex-wrap items-center gap-2 text-2xs text-ink-tertiary">
            <span>{test.module}</span>
            <span>· {formatDuration(test.duration_ms)}</span>
            {test.retry_count > 0 ? <span>· {test.retry_count} retry</span> : null}
            {test.healed ? <span className="text-success-text">· self-healed</span> : null}
            {test.failure_category ? <span>· {test.failure_category.replace(/_/g, ' ')}</span> : null}
            {artifactCount > 0 ? <span>· {artifactCount} artifacts</span> : null}
          </span>
        </span>
        {hasDetail ? (
          <ChevronDown className={cn('h-4 w-4 shrink-0 text-ink-tertiary transition-transform', expanded && 'rotate-180')} />
        ) : null}
      </button>

      {expanded && hasDetail ? (
        <div className="space-y-3 border-t border-line-subtle bg-surface-muted px-5 py-4">
          {test.failure_message ? (
            <section>
              <h4 className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                <FileWarning className="h-3 w-3" /> Failure
              </h4>
              <pre className="overflow-x-auto whitespace-pre-wrap rounded border border-danger-border bg-danger-bg px-3 py-2 font-mono text-xs text-danger-text">
                {test.failure_message}
              </pre>
            </section>
          ) : null}

          {test.stack_trace ? (
            <section>
              <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Stack trace</h4>
              <pre className="overflow-x-auto rounded border border-line bg-surface px-3 py-2 font-mono text-xs text-ink-secondary">
                {test.stack_trace}
              </pre>
            </section>
          ) : null}

          {test.console_logs?.length ? (
            <section>
              <h4 className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                <Terminal className="h-3 w-3" /> Console
              </h4>
              <ul className="space-y-1 rounded border border-line bg-surface px-3 py-2">
                {test.console_logs.map((log, index) => (
                  <li key={index} className="font-mono text-xs">
                    <span className={cn(log.level === 'error' ? 'text-danger-text' : 'text-warning-text')}>
                      [{log.level}]
                    </span>{' '}
                    <span className="text-ink-secondary">{log.message}</span>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          {test.network_logs?.length ? (
            <section>
              <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">Network</h4>
              <ul className="space-y-1 rounded border border-line bg-surface px-3 py-2">
                {test.network_logs.map((entry, index) => (
                  <li key={index} className="flex items-center gap-2 font-mono text-xs">
                    <span className={cn(entry.status >= 400 ? 'text-danger-text' : 'text-success-text')}>
                      {entry.status}
                    </span>
                    <span className="flex-1 truncate text-ink-secondary">{entry.url}</span>
                    <span className="text-ink-tertiary">{entry.duration_ms}ms</span>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          {artifactCount > 0 ? (
            <p className="flex items-center gap-1.5 text-xs text-ink-tertiary">
              <Image className="h-3 w-3" aria-hidden />
              {artifactCount} artifact{artifactCount === 1 ? '' : 's'} captured (screenshot, trace)
            </p>
          ) : null}
        </div>
      ) : null}
    </li>
  );
}
