/**
 * Voice input and output via the browser's Web Speech API.
 *
 * Deliberately client-side: speech never leaves the browser, there is no extra
 * provider to configure, no per-minute cost, and it works with the platform's
 * offline demo mode. Support is feature-detected — the UI hides voice controls
 * rather than offering a button that does nothing.
 */
import { useCallback, useEffect, useRef, useState } from 'react';

/* -------------------------------------------------------------------------- */
/* Web Speech API types (not in the standard DOM lib)                         */
/* -------------------------------------------------------------------------- */

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}
interface SpeechRecognitionResult {
  readonly length: number;
  isFinal: boolean;
  [index: number]: SpeechRecognitionAlternative;
}
interface SpeechRecognitionResultList {
  readonly length: number;
  [index: number]: SpeechRecognitionResult;
}
interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message: string;
}
interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
}
type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

function recognitionConstructor(): SpeechRecognitionConstructor | null {
  if (typeof window === 'undefined') return null;
  return window.SpeechRecognition ?? window.webkitSpeechRecognition ?? null;
}

export const speechRecognitionSupported = () => recognitionConstructor() !== null;
export const speechSynthesisSupported = () =>
  typeof window !== 'undefined' && 'speechSynthesis' in window;

/* -------------------------------------------------------------------------- */
/* Speech to text                                                             */
/* -------------------------------------------------------------------------- */

export interface UseSpeechInput {
  supported: boolean;
  listening: boolean;
  transcript: string;
  interim: string;
  error: string | null;
  start: () => void;
  stop: () => void;
  reset: () => void;
}

/**
 * Dictation for the copilot input.
 *
 * `onFinal` fires once the speaker pauses, which is the natural moment to
 * submit — the caller decides whether to send immediately or let the user edit.
 */
export function useSpeechInput(options: { lang?: string; onFinal?: (text: string) => void } = {}): UseSpeechInput {
  const { lang = 'en-US', onFinal } = options;
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interim, setInterim] = useState('');
  const [error, setError] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const onFinalRef = useRef(onFinal);
  onFinalRef.current = onFinal;

  const supported = speechRecognitionSupported();

  useEffect(() => {
    const Constructor = recognitionConstructor();
    if (!Constructor) return;

    const recognition = new Constructor();
    recognition.lang = lang;
    // Single utterance: the user speaks, pauses, and we submit.
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setListening(true);
      setError(null);
    };

    recognition.onresult = (event) => {
      let finalText = '';
      let interimText = '';
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const result = event.results[index];
        const text = result[0]?.transcript ?? '';
        if (result.isFinal) finalText += text;
        else interimText += text;
      }
      if (interimText) setInterim(interimText);
      if (finalText) {
        const cleaned = finalText.trim();
        setTranscript(cleaned);
        setInterim('');
        onFinalRef.current?.(cleaned);
      }
    };

    recognition.onerror = (event) => {
      setListening(false);
      setInterim('');
      // 'aborted' and 'no-speech' are normal outcomes, not failures to report.
      if (event.error === 'aborted' || event.error === 'no-speech') return;
      setError(
        event.error === 'not-allowed'
          ? 'Microphone access was denied. Enable it in your browser settings to use voice.'
          : `Speech recognition error: ${event.error}`,
      );
    };

    recognition.onend = () => {
      setListening(false);
      setInterim('');
    };

    recognitionRef.current = recognition;
    return () => {
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;
      recognition.onstart = null;
      try {
        recognition.abort();
      } catch {
        /* already stopped */
      }
      recognitionRef.current = null;
    };
  }, [lang]);

  const start = useCallback(() => {
    const recognition = recognitionRef.current;
    if (!recognition || listening) return;
    setTranscript('');
    setInterim('');
    setError(null);
    try {
      recognition.start();
    } catch {
      // start() throws if called while already running; the state resyncs on end.
    }
  }, [listening]);

  const stop = useCallback(() => {
    try {
      recognitionRef.current?.stop();
    } catch {
      /* not running */
    }
  }, []);

  const reset = useCallback(() => {
    setTranscript('');
    setInterim('');
    setError(null);
  }, []);

  return { supported, listening, transcript, interim, error, start, stop, reset };
}

/* -------------------------------------------------------------------------- */
/* Text to speech                                                             */
/* -------------------------------------------------------------------------- */

export interface UseSpeechOutput {
  supported: boolean;
  speaking: boolean;
  enabled: boolean;
  setEnabled: (enabled: boolean) => void;
  speak: (text: string) => void;
  cancel: () => void;
}

const VOICE_PREFERENCE_KEY = 'aiqe.voice.enabled';

/**
 * Strips visual formatting so the reply reads naturally aloud.
 *
 * Bullets, identifiers and currency render well on screen but sound wrong when
 * spoken verbatim, so they are converted rather than read literally.
 */
export function toSpeakable(text: string): string {
  return text
    .replace(/^[•▪-]\s*/gm, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/`(.+?)`/g, '$1')
    .replace(/<€(\d+(?:\.\d+)?)/g, (_match, amount) => `under ${amount} euros`)
    .replace(/€(\d+(?:\.\d+)?)/g, (_match, amount) => `${amount} euros`)
    .replace(/(\d+(?:\.\d+)?)%/g, '$1 percent')
    // Read "PAY-201" as "P A Y 201" so it is intelligible.
    .replace(/\b([A-Z]{2,6})-(\d+)\b/g, (_match, prefix: string, number: string) =>
      `${prefix.split('').join(' ')} ${number}`,
    )
    .replace(/\n+/g, '. ')
    .replace(/\.\s*\./g, '.')
    .trim();
}

export function useSpeechOutput(): UseSpeechOutput {
  const supported = speechSynthesisSupported();
  const [speaking, setSpeaking] = useState(false);
  const [enabled, setEnabledState] = useState(() => {
    try {
      return localStorage.getItem(VOICE_PREFERENCE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const setEnabled = useCallback((next: boolean) => {
    setEnabledState(next);
    try {
      localStorage.setItem(VOICE_PREFERENCE_KEY, String(next));
    } catch {
      /* storage unavailable; preference is session-only */
    }
    if (!next && speechSynthesisSupported()) window.speechSynthesis.cancel();
  }, []);

  const cancel = useCallback(() => {
    if (!speechSynthesisSupported()) return;
    window.speechSynthesis.cancel();
    setSpeaking(false);
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (!speechSynthesisSupported() || !text.trim()) return;
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(toSpeakable(text));
      utterance.rate = 1.02;
      utterance.pitch = 1;
      utterance.volume = 1;

      // Prefer a natural-sounding English voice when the platform offers one.
      const voices = window.speechSynthesis.getVoices();
      const preferred =
        voices.find((voice) => /Google UK English Female|Samantha|Microsoft Aria/i.test(voice.name)) ??
        voices.find((voice) => voice.lang.startsWith('en') && !voice.localService) ??
        voices.find((voice) => voice.lang.startsWith('en'));
      if (preferred) utterance.voice = preferred;

      utterance.onstart = () => setSpeaking(true);
      utterance.onend = () => setSpeaking(false);
      utterance.onerror = () => setSpeaking(false);

      window.speechSynthesis.speak(utterance);
    },
    [],
  );

  // Voices load asynchronously in Chrome; touching the list primes it.
  useEffect(() => {
    if (!speechSynthesisSupported()) return;
    const prime = () => window.speechSynthesis.getVoices();
    prime();
    window.speechSynthesis.addEventListener('voiceschanged', prime);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', prime);
      window.speechSynthesis.cancel();
    };
  }, []);

  return { supported, speaking, enabled, setEnabled, speak, cancel };
}
