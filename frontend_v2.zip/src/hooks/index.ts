/** Shared data-fetching and utility hooks. */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api, streamUrl } from '@/services/api';
import { useWorkspace } from '@/store';
import type { StreamEvent } from '@/types';

/** The currently selected project id; throws-free, returns null when unset. */
export function useProjectId(): string | null {
  return useWorkspace((state) => state.projectId);
}

export function useSystemInfo() {
  return useQuery({
    queryKey: ['system-info'],
    queryFn: api.systemInfo,
    staleTime: 5 * 60 * 1000,
  });
}

export function useDashboard(windowDays = 30) {
  const projectId = useProjectId();
  return useQuery({
    queryKey: ['dashboard', projectId, windowDays],
    queryFn: () => api.dashboard(projectId!, windowDays),
    enabled: Boolean(projectId),
  });
}

/** Debounces a fast-changing value (search boxes, filters). */
export function useDebounced<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

/**
 * Subscribes to a live event stream over WebSocket.
 *
 * Reconnects with backoff while the stream is still expected to be active, and
 * stops cleanly once a terminal event arrives so a finished run does not keep
 * a socket open.
 */
export function useEventStream(
  path: string | null,
  options: { onEvent?: (event: StreamEvent) => void; terminalTypes?: string[] } = {},
) {
  const { onEvent, terminalTypes = [] } = options;
  const [events, setEvents] = useState<StreamEvent[]>([]);
  const [connected, setConnected] = useState(false);
  const onEventRef = useRef(onEvent);
  const terminalRef = useRef(terminalTypes);

  onEventRef.current = onEvent;
  terminalRef.current = terminalTypes;

  useEffect(() => {
    if (!path) return;

    let socket: WebSocket | null = null;
    let retryTimer: ReturnType<typeof setTimeout> | undefined;
    let attempt = 0;
    let closedByTerminal = false;
    let disposed = false;

    const connect = () => {
      if (disposed) return;
      socket = new WebSocket(streamUrl(path));

      socket.onopen = () => {
        attempt = 0;
        setConnected(true);
      };

      socket.onmessage = (message) => {
        try {
          const event = JSON.parse(message.data) as StreamEvent;
          if (event.type === 'heartbeat') return;
          setEvents((current) => [...current, event]);
          onEventRef.current?.(event);
          if (terminalRef.current.includes(event.type)) {
            closedByTerminal = true;
            socket?.close();
          }
        } catch {
          /* ignore malformed frames */
        }
      };

      socket.onclose = () => {
        setConnected(false);
        if (disposed || closedByTerminal) return;
        // Exponential backoff, capped, so a dead backend does not spin.
        attempt += 1;
        if (attempt > 6) return;
        retryTimer = setTimeout(connect, Math.min(1000 * 2 ** attempt, 15000));
      };

      socket.onerror = () => socket?.close();
    };

    connect();

    return () => {
      disposed = true;
      if (retryTimer) clearTimeout(retryTimer);
      socket?.close();
    };
  }, [path]);

  return { events, connected };
}

/** Formats a duration in milliseconds for display. */
export function formatDuration(ms: number | null | undefined): string {
  if (!ms || ms < 0) return '—';
  if (ms < 1000) return `${ms}ms`;
  const seconds = ms / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const minutes = Math.floor(seconds / 60);
  const remainder = Math.round(seconds % 60);
  if (minutes < 60) return `${minutes}m ${remainder}s`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ${minutes % 60}m`;
}

export function formatPercent(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  return `${(value * 100).toFixed(digits)}%`;
}

export function formatCurrency(value: number | null | undefined, digits = 2): string {
  if (value === null || value === undefined) return '—';
  if (value > 0 && value < 0.01) return '<€0.01';
  return `€${value.toFixed(digits)}`;
}

export function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined) return '—';
  return value.toLocaleString();
}

export function formatRelativeTime(iso?: string | null): string {
  if (!iso) return '—';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '—';
  const diffSeconds = Math.round((Date.now() - then) / 1000);
  if (diffSeconds < 60) return 'just now';
  if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)}m ago`;
  if (diffSeconds < 86400) return `${Math.floor(diffSeconds / 3600)}h ago`;
  const days = Math.floor(diffSeconds / 86400);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}

export function formatDateTime(iso?: string | null): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/** Stable colour assignment for chart series keyed by name. */
export function useSeriesColors(keys: string[]): Record<string, string> {
  return useMemo(() => {
    const palette = ['#145DA0', '#238636', '#B7791F', '#C53030', '#6FA5DE', '#0B2E59', '#5F6B7A', '#2563EB'];
    return Object.fromEntries(keys.map((key, index) => [key, palette[index % palette.length]]));
  }, [keys]);
}
