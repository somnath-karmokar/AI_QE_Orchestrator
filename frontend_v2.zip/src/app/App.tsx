/** Route table and session bootstrap. */
import { Suspense, lazy, useEffect, useState } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { api, getToken } from '@/services/api';
import { useSession } from '@/store';
import { AppShell } from '@/components/AppShell';
import { LoadingBlock } from '@/design-system/primitives';
import { LoginPage } from '@/pages/LoginPage';

// Route-level code splitting keeps the initial bundle small.
const ApiAccessPage = lazy(() => import('@/pages/ApiAccessPage'));
const ApiPortalPage = lazy(() => import('@/pages/ApiPortalPage'));
const DataSourcesPage = lazy(() => import('@/pages/DataSourcesPage'));
const DashboardPage = lazy(() => import('@/pages/DashboardPage'));
const ProjectsPage = lazy(() => import('@/pages/ProjectsPage'));
const MarketplacePage = lazy(() => import('@/pages/MarketplacePage'));
const AgentDetailPage = lazy(() => import('@/pages/AgentDetailPage'));
const AgentBuilderPage = lazy(() => import('@/pages/AgentBuilderPage'));
const CartPage = lazy(() => import('@/pages/CartPage'));
const FlowStudioPage = lazy(() => import('@/pages/flow-studio/FlowStudioPage'));
const NewFlowPage = lazy(() => import('@/pages/flow-studio/NewFlowPage'));
const FlowWorkspacePage = lazy(() => import('@/pages/flow-studio/FlowWorkspacePage'));
const FlowBuilderPage = lazy(() => import('@/pages/FlowBuilderPage'));
const MyAgentsPage = lazy(() => import('@/pages/MyAgentsPage'));
const RunsPage = lazy(() => import('@/pages/RunsPage'));
const RunDetailPage = lazy(() => import('@/pages/RunDetailPage'));
const TestPlanningPage = lazy(() => import('@/pages/testing/TestPlanningPage'));
const TestDesignPage = lazy(() => import('@/pages/testing/TestDesignPage'));
const TestDataPage = lazy(() => import('@/pages/testing/TestDataPage'));
const AutomationPage = lazy(() => import('@/pages/testing/AutomationPage'));
const ExecutionsPage = lazy(() => import('@/pages/ExecutionsPage'));
const ExecutionDetailPage = lazy(() => import('@/pages/ExecutionDetailPage'));
const DefectsPage = lazy(() => import('@/pages/quality/DefectsPage'));
const HealingPage = lazy(() => import('@/pages/quality/HealingPage'));
const RcaPage = lazy(() => import('@/pages/quality/RcaPage'));
const RegressionPage = lazy(() => import('@/pages/quality/RegressionPage'));
const TraceabilityPage = lazy(() => import('@/pages/quality/TraceabilityPage'));
const KnowledgePage = lazy(() => import('@/pages/KnowledgePage'));
const GovernancePage = lazy(() => import('@/pages/GovernancePage'));
const IntegrationsPage = lazy(() => import('@/pages/IntegrationsPage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));

function RouteFallback() {
  return (
    <div className="mx-auto max-w-4xl">
      <LoadingBlock rows={6} />
    </div>
  );
}

export function App() {
  const { isAuthenticated, signIn } = useSession();
  const [bootstrapping, setBootstrapping] = useState(true);

  // Restore the session from a stored token so a refresh does not sign the user out.
  useEffect(() => {
    const token = getToken();
    if (!token) {
      setBootstrapping(false);
      return;
    }
    api
      .me()
      .then((user) => signIn(user, token))
      .catch(() => {
        /* expired or invalid token: fall through to the sign-in screen */
      })
      .finally(() => setBootstrapping(false));
  }, [signIn]);

  if (bootstrapping) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-surface-muted">
        <div className="w-72">
          <LoadingBlock rows={3} />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Routes>
        {/* The portal authenticates with an API key, not a session, so it is
            reachable by someone who has no account on this platform. */}
        <Route path="/portal" element={<Suspense fallback={<RouteFallback />}><ApiPortalPage /></Suspense>} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/" replace />} />
      {/* Outside the shell: it is the API user's view, not an operator's. */}
      <Route path="/portal" element={<Suspense fallback={<RouteFallback />}><ApiPortalPage /></Suspense>} />
      <Route element={<AppShell />}>
        <Route
          path="/"
          element={
            <Suspense fallback={<RouteFallback />}>
              <DashboardPage />
            </Suspense>
          }
        />
        <Route path="/projects" element={<Suspense fallback={<RouteFallback />}><ProjectsPage /></Suspense>} />
        <Route path="/marketplace" element={<Suspense fallback={<RouteFallback />}><MarketplacePage /></Suspense>} />
        <Route path="/marketplace/:agentId" element={<Suspense fallback={<RouteFallback />}><AgentDetailPage /></Suspense>} />
        <Route path="/agents/new" element={<Suspense fallback={<RouteFallback />}><AgentBuilderPage /></Suspense>} />
        <Route path="/agents/:agentId/edit" element={<Suspense fallback={<RouteFallback />}><AgentBuilderPage /></Suspense>} />
        <Route path="/cart" element={<Suspense fallback={<RouteFallback />}><CartPage /></Suspense>} />
        <Route path="/flows" element={<Suspense fallback={<RouteFallback />}><FlowStudioPage /></Suspense>} />
        <Route path="/flows/new" element={<Suspense fallback={<RouteFallback />}><NewFlowPage /></Suspense>} />
        <Route path="/flows/:flowId" element={<Suspense fallback={<RouteFallback />}><FlowWorkspacePage /></Suspense>} />
        <Route path="/flows/:flowId/designer" element={<Suspense fallback={<RouteFallback />}><FlowBuilderPage /></Suspense>} />
        <Route path="/flows/:flowId/:tab" element={<Suspense fallback={<RouteFallback />}><FlowWorkspacePage /></Suspense>} />
        <Route path="/my-agents" element={<Suspense fallback={<RouteFallback />}><MyAgentsPage /></Suspense>} />
        <Route path="/runs" element={<Suspense fallback={<RouteFallback />}><RunsPage /></Suspense>} />
        <Route path="/runs/:runId" element={<Suspense fallback={<RouteFallback />}><RunDetailPage /></Suspense>} />
        <Route path="/testing/planning" element={<Suspense fallback={<RouteFallback />}><TestPlanningPage /></Suspense>} />
        <Route path="/testing/design" element={<Suspense fallback={<RouteFallback />}><TestDesignPage /></Suspense>} />
        <Route path="/testing/data" element={<Suspense fallback={<RouteFallback />}><TestDataPage /></Suspense>} />
        <Route path="/testing/automation" element={<Suspense fallback={<RouteFallback />}><AutomationPage /></Suspense>} />
        <Route path="/executions" element={<Suspense fallback={<RouteFallback />}><ExecutionsPage /></Suspense>} />
        <Route path="/executions/:executionId" element={<Suspense fallback={<RouteFallback />}><ExecutionDetailPage /></Suspense>} />
        <Route path="/quality/defects" element={<Suspense fallback={<RouteFallback />}><DefectsPage /></Suspense>} />
        <Route path="/quality/healing" element={<Suspense fallback={<RouteFallback />}><HealingPage /></Suspense>} />
        <Route path="/quality/rca" element={<Suspense fallback={<RouteFallback />}><RcaPage /></Suspense>} />
        <Route path="/quality/regression" element={<Suspense fallback={<RouteFallback />}><RegressionPage /></Suspense>} />
        <Route path="/quality/traceability" element={<Suspense fallback={<RouteFallback />}><TraceabilityPage /></Suspense>} />
        <Route path="/knowledge" element={<Suspense fallback={<RouteFallback />}><KnowledgePage /></Suspense>} />
        <Route path="/governance" element={<Suspense fallback={<RouteFallback />}><GovernancePage /></Suspense>} />
        <Route path="/integrations" element={<Suspense fallback={<RouteFallback />}><IntegrationsPage /></Suspense>} />
        <Route path="/data-sources" element={<Suspense fallback={<RouteFallback />}><DataSourcesPage /></Suspense>} />
        <Route path="/api-access" element={<Suspense fallback={<RouteFallback />}><ApiAccessPage /></Suspense>} />
        <Route path="/settings" element={<Suspense fallback={<RouteFallback />}><SettingsPage /></Suspense>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
