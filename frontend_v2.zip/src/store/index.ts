/** Global client state: session, selected project/environment, agent cart badge. */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Environment, ProjectSummary, User } from '@/types';
import { setToken } from '@/services/api';

interface SessionState {
  user: User | null;
  isAuthenticated: boolean;
  signIn: (user: User, token: string) => void;
  signOut: () => void;
  can: (permission: string) => boolean;
}

export const useSession = create<SessionState>()((set, get) => ({
  user: null,
  isAuthenticated: false,
  signIn: (user, token) => {
    setToken(token);
    set({ user, isAuthenticated: true });
  },
  signOut: () => {
    setToken(null);
    set({ user: null, isAuthenticated: false });
  },
  can: (permission) => {
    const { user } = get();
    if (!user) return false;
    return user.permissions.includes('*') || user.permissions.includes(permission);
  },
}));

interface WorkspaceState {
  projectId: string | null;
  environmentId: string | null;
  project: ProjectSummary | null;
  environments: Environment[];
  sidebarCollapsed: boolean;
  setProject: (project: ProjectSummary | null) => void;
  setEnvironments: (environments: Environment[]) => void;
  setEnvironmentId: (id: string | null) => void;
  toggleSidebar: () => void;
}

export const useWorkspace = create<WorkspaceState>()(
  persist(
    (set) => ({
      projectId: null,
      environmentId: null,
      project: null,
      environments: [],
      sidebarCollapsed: false,
      setProject: (project) =>
        set((state) => {
          const projectId = project?.id ?? null;
          // Re-hydrating the persisted project after a reload is not a switch: clearing
          // here would wipe environments the project query has already delivered.
          if (projectId === state.projectId) return { project };
          // Switching project invalidates the environment selection.
          return { project, projectId, environmentId: null, environments: [] };
        }),
      setEnvironments: (environments) =>
        set((state) => ({
          environments,
          environmentId:
            state.environmentId && environments.some((item) => item.id === state.environmentId)
              ? state.environmentId
              : (environments.find((item) => item.key === 'sit') ?? environments[0])?.id ?? null,
        })),
      setEnvironmentId: (environmentId) => set({ environmentId }),
      toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
    }),
    {
      name: 'aiqe.workspace',
      // Only durable preferences are persisted; server data is refetched.
      partialize: (state) => ({
        projectId: state.projectId,
        environmentId: state.environmentId,
        sidebarCollapsed: state.sidebarCollapsed,
      }),
    },
  ),
);

interface CartState {
  count: number;
  setCount: (count: number) => void;
}

export const useCartBadge = create<CartState>()((set) => ({
  count: 0,
  setCount: (count) => set({ count }),
}));
