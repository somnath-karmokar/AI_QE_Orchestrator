/**
 * Agent collaboration for one run: the flow graph with hand-offs travelling
 * between agents, the conversation they had through the orchestrator, and the
 * shared context they built together. Follows a live run as it happens, and
 * replays a finished one message by message.
 */
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  ArrowRight,
  Bot,
  Database,
  FastForward,
  GitBranch,
  Handshake,
  Pause,
  Play,
  Radio,
  RotateCcw,
  UserCheck,
  Users,
  Workflow,
} from 'lucide-react';
import { api } from '@/services/api';
import { formatDuration, formatPercent } from '@/hooks';
import { AgentIcon } from '@/components/AgentIcon';
import { Badge, Button, Card, cn, EmptyState, ErrorState, LoadingBlock } from '@/design-system/primitives';
import { FlowGraphView, type GraphEdgeInput, type GraphNodeInput } from '@/features/flow-graph/FlowGraphView';
import { dwellMs, frameAt, handoffPairs } from './replay';
import type {
  CollaborationMessage,
  CollaborationParticipant,
  RunCollaboration,
  SharedContextEntry,
} from '@/types';

/** Identity colours for agents: a ring around the icon, always shown with the agent's name. */
const AGENT_RINGS = ['#145DA0', '#0F766E', '#6D28D9', '#B45309', '#BE185D', '#4338CA', '#15803D', '#0369A1'];

const ROLE_LABELS: Record<string, string> = {
  qe_lead: 'QE Lead',
  business_user: 'Business / UAT',
  qe_engineer: 'QE Engineer',
  admin: 'Platform Admin',
};

const KIND_VERB: Record<CollaborationMessage['kind'], string> = {
  kickoff: 'started the run',
  acknowledge: 'picked up the work',
  handoff: 'handed over',
  decision: 'made a decision',
  approval_request: 'asked for approval',
  approval_decision: 'decided',
  retry: 'retried',
  failure: 'reported a problem',
  complete: 'wrapped up',
};

const KIND_BUBBLE: Record<CollaborationMessage['kind'], string> = {
  kickoff: 'border-navy-100 bg-navy-50',
  acknowledge: 'border-line bg-surface',
  handoff: 'border-brand-200 bg-brand-50/60',
  decision: 'border-line-strong bg-surface-muted',
  approval_request: 'border-warning-border bg-warning-bg/70',
  approval_decision: 'border-success-border bg-success-bg/70',
  retry: 'border-warning-border bg-surface',
  failure: 'border-danger-border bg-danger-bg/70',
  complete: 'border-navy-100 bg-navy-50',
};

export function AgentCollaboration({ runId, active }: { runId: string; active: boolean }) {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['run-collaboration', runId],
    queryFn: () => api.runCollaboration(runId),
    refetchInterval: active ? 1500 : false,
  });

  if (isLoading) return <LoadingBlock rows={10} className="rounded-lg border border-line bg-surface" />;
  if (error || !data) return <ErrorState message={(error as Error)?.message} onRetry={() => void refetch()} />;
  return <CollaborationView data={data} active={active} />;
}

function CollaborationView({ data, active }: { data: RunCollaboration; active: boolean }) {
  const messages = data.conversation;
  const last = messages.length - 1;
  const [cursor, setCursor] = useState<number | null>(null); // null follows the latest message
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [focus, setFocus] = useState<string | null>(null);
  const feedRef = useRef<HTMLOListElement>(null);
  const position = cursor === null ? last : Math.min(cursor, last);

  const participants = useMemo(
    () => Object.fromEntries(data.participants.map((participant) => [participant.key, participant])),
    [data.participants],
  );

  // Advance the replay one message at a time.
  useEffect(() => {
    if (!playing) return undefined;
    if (position >= last) {
      setPlaying(false);
      setCursor(null);
      return undefined;
    }
    const timer = setTimeout(() => setCursor(position + 1), dwellMs(messages[position]?.kind ?? 'kickoff', speed));
    return () => clearTimeout(timer);
  }, [playing, position, last, speed, messages]);

  // Keep the newest revealed message in view.
  useEffect(() => {
    const feed = feedRef.current;
    if (feed) feed.scrollTo({ top: feed.scrollHeight, behavior: 'smooth' });
  }, [position, messages.length]);

  const frame = useMemo(() => frameAt(data, cursor === null ? last : position), [data, cursor, position, last]);
  const current = messages[position];

  const related = useMemo(() => {
    if (!focus) return null;
    const keys = new Set<string>([focus]);
    for (const message of messages) {
      if (message.from === focus) message.to.forEach((key) => keys.add(key));
      if (message.to.includes(focus)) keys.add(message.from);
    }
    return keys;
  }, [focus, messages]);

  const graphNodes: GraphNodeInput[] = data.graph.nodes.map((node) => {
    const state = frame.nodeStates[node.node_key];
    const done = state === 'succeeded' && frame.revealed.has(node.node_key);
    return {
      node_key: node.node_key,
      node_type: node.node_type,
      label: node.node_type === 'start' ? 'Start' : node.node_type === 'end' ? node.label : node.label,
      position_x: node.position_x,
      position_y: node.position_y,
      icon: node.agent_icon,
      subtitle:
        node.node_type === 'agent'
          ? node.agent_name
          : node.node_type === 'approval'
            ? `Approval · ${ROLE_LABELS[node.approval_role ?? 'qe_lead'] ?? 'QE Lead'}`
            : undefined,
      state,
      decision: node.node_type === 'condition' && frame.revealed.has(node.node_key) ? node.decision : undefined,
      metrics:
        done && node.node_type === 'agent'
          ? [formatDuration(node.duration_ms), node.confidence != null ? `${Math.round(node.confidence * 100)}%` : ''].filter(Boolean)
          : undefined,
      dimmed: related ? !related.has(node.node_key) && node.node_type !== 'start' && node.node_type !== 'end' : false,
    };
  });

  const graphEdges: GraphEdgeInput[] = data.graph.edges.map((edge) => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
    branch_label: edge.branch_label,
    state: frame.edgeStates[edge.id],
    pulse: frame.pulses[edge.id] ?? null,
    pulseKey: `${edge.id}-${current?.id ?? 'x'}`,
  }));

  const revealedMessages = messages.slice(0, position + 1);
  const revealedContext = revealContext(data.context, revealedMessages);
  const pairs = handoffPairs({ ...data, conversation: revealedMessages });
  const replaying = cursor !== null;

  const startReplay = () => {
    setFocus(null);
    setCursor(0);
    setPlaying(true);
  };

  return (
    <div className="space-y-5">
      <Card className="overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-line px-5 py-4">
          <div className="min-w-0">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-ink">
              <Handshake className="h-5 w-5 text-brand-500" aria-hidden /> How the agents worked together
            </h2>
            <p className="mt-0.5 max-w-2xl text-sm text-ink-secondary">
              Each agent reads the run inputs and the results earlier agents published to the shared context, then hands its own
              result to the next step. Decisions read those results; people approve at gates.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <StatChip icon={<Bot className="h-3.5 w-3.5" />} label="agents" value={data.stats.agents} />
              <StatChip icon={<ArrowRight className="h-3.5 w-3.5" />} label="hand-offs" value={data.stats.handoffs} />
              <StatChip icon={<GitBranch className="h-3.5 w-3.5" />} label="decisions" value={data.stats.decisions} />
              <StatChip icon={<UserCheck className="h-3.5 w-3.5" />} label="human approvals" value={data.stats.human_decisions} />
              <StatChip icon={<Database className="h-3.5 w-3.5" />} label="shared facts" value={data.stats.shared_facts} />
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            {active && !replaying ? (
              <Badge tone="info">
                <Radio className="h-3 w-3 animate-pulse" aria-hidden /> Live: following the run
              </Badge>
            ) : null}
            <div className="flex flex-wrap items-center gap-2">
              {playing ? (
                <Button size="sm" variant="secondary" icon={<Pause className="h-3.5 w-3.5" />} onClick={() => setPlaying(false)}>
                  Pause
                </Button>
              ) : replaying ? (
                <Button size="sm" variant="primary" icon={<Play className="h-3.5 w-3.5" />} onClick={() => setPlaying(true)}>
                  Resume
                </Button>
              ) : (
                <Button
                  size="sm"
                  variant="primary"
                  icon={<RotateCcw className="h-3.5 w-3.5" />}
                  onClick={startReplay}
                  disabled={messages.length < 2}
                >
                  Replay collaboration
                </Button>
              )}
              {replaying ? (
                <Button size="sm" variant="ghost" onClick={() => { setPlaying(false); setCursor(null); }}>
                  Show all
                </Button>
              ) : null}
              <div role="group" aria-label="Replay speed" className="inline-flex rounded border border-line bg-surface-muted p-0.5">
                {[1, 2, 4].map((value) => (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={speed === value}
                    onClick={() => setSpeed(value)}
                    className={cn(
                      'h-6 rounded px-2 text-2xs font-medium',
                      speed === value ? 'bg-surface text-ink shadow-card' : 'text-ink-secondary hover:text-ink',
                    )}
                  >
                    {value === 1 ? '1×' : <span className="inline-flex items-center gap-0.5">{value}× <FastForward className="h-2.5 w-2.5" aria-hidden /></span>}
                  </button>
                ))}
              </div>
            </div>
            <label className="flex items-center gap-2 text-2xs text-ink-secondary">
              <span className="tabular">
                Message {position + 1} of {messages.length}
              </span>
              <input
                type="range"
                min={0}
                max={Math.max(0, last)}
                value={position}
                onChange={(event) => {
                  setPlaying(false);
                  const value = Number(event.target.value);
                  setCursor(value >= last ? null : value);
                }}
                className="w-44 accent-brand-500"
                aria-label="Step through the conversation"
              />
            </label>
          </div>
        </div>

        {/* Participants */}
        <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-muted px-5 py-2.5">
          <span className="mr-1 flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
            <Users className="h-3.5 w-3.5" aria-hidden /> Participants
          </span>
          {data.participants.map((participant) => {
            const speaking = current && (current.from === participant.key || current.to.includes(participant.key));
            return (
              <button
                key={participant.key}
                type="button"
                onClick={() => setFocus(focus === participant.key ? null : participant.key)}
                aria-pressed={focus === participant.key}
                className={cn(
                  'flex items-center gap-1.5 rounded-full border bg-surface py-0.5 pl-0.5 pr-2.5 text-xs transition-all',
                  focus === participant.key ? 'border-brand-500 ring-2 ring-brand-100' : 'border-line hover:border-line-strong',
                  speaking && current?.from === participant.key && 'shadow-raised',
                )}
                title={participant.subtitle}
              >
                <Avatar participant={participant} size="sm" speaking={Boolean(speaking && current?.from === participant.key)} />
                <span className="max-w-[160px] truncate text-ink">{participant.name}</span>
              </button>
            );
          })}
          {focus ? (
            <button type="button" onClick={() => setFocus(null)} className="text-2xs font-medium text-brand-600 hover:text-brand-700">
              Clear focus
            </button>
          ) : null}
        </div>

        {/* Graph + conversation */}
        <div className="grid xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
          <div className="border-b border-line p-4 xl:border-b-0 xl:border-r">
            <FlowGraphView
              nodes={graphNodes}
              edges={graphEdges}
              height={600}
              selected={focus}
              onSelect={setFocus}
              focusNodeKey={(replaying || active) && current?.node_key ? current.node_key : null}
              label={`Flow graph for run ${data.run.run_number}, showing each step's state and the hand-offs between agents`}
            />
            {current ? (
              <div className="mt-3 flex items-start gap-3 rounded-lg border border-line bg-surface px-3 py-2.5" aria-live="polite">
                <Avatar participant={participants[current.from]} size="md" speaking />
                <p className="min-w-0 text-sm text-ink">
                  <span className="font-semibold">{participants[current.from]?.name}</span>{' '}
                  <span className="text-ink-secondary">{KIND_VERB[current.kind]}</span>
                  {current.to.length ? (
                    <span className="text-ink-secondary">
                      {' '}
                      <ArrowRight className="inline h-3.5 w-3.5 align-[-2px]" aria-label="to" />{' '}
                      {current.to.map((key) => participants[key]?.name).filter(Boolean).join(', ')}
                    </span>
                  ) : null}
                  <span className="mt-0.5 block line-clamp-2 text-ink-secondary">{current.text}</span>
                </p>
              </div>
            ) : null}
          </div>

          <div className="flex min-h-0 flex-col">
            <div className="flex items-center justify-between px-5 pb-2 pt-4">
              <h3 className="text-md font-semibold text-ink">Agent conversation</h3>
              <span className="text-2xs text-ink-tertiary">Through the orchestrator's shared context</span>
            </div>
            <ol ref={feedRef} className="h-[640px] space-y-3 overflow-y-auto px-5 pb-5" aria-label="Agent conversation">
              {revealedMessages.map((message) => (
                <MessageItem
                  key={message.id}
                  message={message}
                  participants={participants}
                  isCurrent={message.index === position && (replaying || active)}
                  dimmed={Boolean(focus) && message.from !== focus && !message.to.includes(focus!)}
                />
              ))}
              {messages.length === 0 ? <EmptyState title="Waiting for the first agent" /> : null}
            </ol>
          </div>
        </div>
      </Card>

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <Card>
          <div className="flex items-center justify-between border-b border-line px-5 py-3">
            <h3 className="flex items-center gap-2 text-md font-semibold text-ink">
              <Database className="h-4 w-4 text-ink-secondary" aria-hidden /> Shared context
            </h3>
            <span className="text-2xs text-ink-tertiary">What was published, by whom, and who used it</span>
          </div>
          <ul className="divide-y divide-line-subtle">
            {revealedContext.length ? (
              revealedContext.map((entry, index) => (
                <ContextRow
                  key={entry.key}
                  entry={entry}
                  participants={participants}
                  isNew={index === revealedContext.length - 1 && (replaying || active)}
                />
              ))
            ) : (
              <li className="px-5 py-6 text-sm text-ink-secondary">Nothing published yet.</li>
            )}
          </ul>
        </Card>

        <Card>
          <div className="flex items-center justify-between border-b border-line px-5 py-3">
            <h3 className="flex items-center gap-2 text-md font-semibold text-ink">
              <Handshake className="h-4 w-4 text-ink-secondary" aria-hidden /> Who worked with whom
            </h3>
          </div>
          <ul className="divide-y divide-line-subtle">
            {pairs.length ? (
              pairs.map((pair) => (
                <li key={`${pair.from}-${pair.to}`} className="flex items-start gap-3 px-5 py-2.5">
                  <div className="flex shrink-0 items-center gap-1 pt-0.5">
                    <Avatar participant={participants[pair.from]} size="sm" />
                    <ArrowRight className="h-3.5 w-3.5 text-ink-tertiary" aria-hidden />
                    <Avatar participant={participants[pair.to]} size="sm" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm text-ink">
                      <span className="font-medium">{participants[pair.from]?.name}</span>
                      <span className="text-ink-secondary"> → </span>
                      <span className="font-medium">{participants[pair.to]?.name}</span>
                    </p>
                    <p className="line-clamp-1 text-xs text-ink-secondary">{pair.last}</p>
                  </div>
                </li>
              ))
            ) : (
              <li className="px-5 py-6 text-sm text-ink-secondary">No hand-offs yet.</li>
            )}
          </ul>
        </Card>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */

function revealContext(context: SharedContextEntry[], revealed: CollaborationMessage[]): SharedContextEntry[] {
  const kickedOff = revealed.some((message) => message.kind === 'kickoff');
  const published = new Set(
    revealed
      .filter((message) => message.kind === 'handoff' || message.kind === 'decision')
      .map((message) => message.from),
  );
  const approvals = new Set(
    revealed.filter((message) => message.kind === 'approval_decision').map((message) => `${message.from}|${message.node_key}`),
  );
  return context.filter((entry) => {
    if (entry.kind === 'input') return kickedOff;
    if (entry.kind === 'approval') return approvals.has(`${entry.written_by}|${entry.key.split(':')[1]}`);
    return published.has(entry.written_by);
  });
}

function StatChip({ icon, label, value }: { icon: ReactNode; label: string; value: number }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface-muted px-2.5 py-1 text-xs text-ink-secondary">
      <span className="text-ink-tertiary" aria-hidden>
        {icon}
      </span>
      <span className="font-semibold text-ink tabular">{value}</span> {label}
    </span>
  );
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase();
}

export function Avatar({
  participant,
  size = 'md',
  speaking,
}: {
  participant?: CollaborationParticipant;
  size?: 'sm' | 'md';
  speaking?: boolean;
}) {
  const box = size === 'sm' ? 'h-6 w-6' : 'h-9 w-9';
  if (!participant) return <span className={cn(box, 'rounded-full bg-surface-sunken')} aria-hidden />;
  const ring = participant.color_index !== null ? AGENT_RINGS[participant.color_index % AGENT_RINGS.length] : undefined;
  const pulse = speaking ? 'animate-pulse' : '';

  if (participant.kind === 'agent') {
    return (
      <span
        className={cn('relative inline-flex shrink-0 self-start rounded-lg', pulse)}
        style={{ boxShadow: ring ? `0 0 0 2px ${ring}` : undefined }}
      >
        <AgentIcon name={participant.icon} className={box} />
      </span>
    );
  }
  if (participant.kind === 'human') {
    return (
      <span
        className={cn(box, 'inline-flex shrink-0 self-start items-center justify-center rounded-full bg-warning-bg font-semibold text-warning-text', size === 'sm' ? 'text-[9px]' : 'text-xs', pulse)}
        aria-hidden
      >
        {initials(participant.name)}
      </span>
    );
  }
  const Icon = participant.kind === 'orchestrator' ? Workflow : participant.kind === 'gate' ? UserCheck : GitBranch;
  return (
    <span
      className={cn(
        box,
        'inline-flex shrink-0 self-start items-center justify-center rounded-lg border',
        participant.kind === 'orchestrator'
          ? 'border-navy-800 bg-navy-700 text-white'
          : participant.kind === 'gate'
            ? 'border-warning-border bg-warning-bg text-warning-text'
            : 'border-line bg-surface-muted text-ink-secondary',
        pulse,
      )}
      aria-hidden
    >
      <Icon className={size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'} />
    </span>
  );
}

function MessageItem({
  message,
  participants,
  isCurrent,
  dimmed,
}: {
  message: CollaborationMessage;
  participants: Record<string, CollaborationParticipant>;
  isCurrent: boolean;
  dimmed: boolean;
}) {
  const sender = participants[message.from];
  const time = new Date(message.at);
  const highlights = message.data.highlights ?? [];
  const reads = message.data.reads ?? [];
  return (
    <li className={cn('flex items-start gap-3 transition-opacity', isCurrent && 'animate-slide-up', dimmed && 'opacity-40')}>
      <Avatar participant={sender} size="md" speaking={isCurrent} />
      <div className="min-w-0 flex-1">
        <p className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs">
          <span className="font-semibold text-ink">{sender?.name ?? message.from}</span>
          <span className="text-ink-tertiary">{KIND_VERB[message.kind]}</span>
          {message.to.length ? (
            <>
              <ArrowRight className="h-3 w-3 text-ink-tertiary" aria-label="to" />
              {message.to.map((key) => (
                <span key={key} className="rounded bg-surface-sunken px-1.5 py-px text-2xs font-medium text-ink-secondary">
                  {participants[key]?.name ?? key}
                </span>
              ))}
            </>
          ) : null}
          <time className="ml-auto text-2xs text-ink-tertiary tabular" dateTime={message.at}>
            {Number.isNaN(time.getTime()) ? '' : time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </time>
        </p>
        <div
          className={cn(
            'mt-1 rounded-lg rounded-tl-sm border px-3 py-2 text-sm leading-relaxed text-ink',
            KIND_BUBBLE[message.kind],
            isCurrent && 'ring-2 ring-brand-200',
          )}
        >
          <p>{renderCode(message.text)}</p>
          {reads.length && message.kind === 'decision' ? (
            <ul className="mt-1.5 space-y-0.5">
              {reads.map((read) => (
                <li key={read.path} className="flex flex-wrap items-center gap-1 text-2xs text-ink-secondary">
                  <Database className="h-3 w-3" aria-hidden /> read
                  <code className="rounded bg-surface px-1 font-mono">{read.path}</code>
                  {read.value !== undefined ? <span>= {read.value}</span> : null}
                  <span>from {participants[read.from]?.name}</span>
                </li>
              ))}
            </ul>
          ) : null}
          {highlights.length || message.data.confidence != null || message.data.tools?.length ? (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {message.data.confidence != null ? (
                <span className="rounded-full border border-line bg-surface px-2 py-0.5 text-2xs font-medium text-ink">
                  {formatPercent(message.data.confidence, 0)} confident
                </span>
              ) : null}
              {highlights.map((item) => (
                <span key={item.label} className="rounded-full border border-line bg-surface px-2 py-0.5 text-2xs text-ink-secondary">
                  {item.label} <span className="font-semibold text-ink tabular">{item.value}</span>
                </span>
              ))}
              {message.data.tools?.map((tool) => (
                <span key={tool} className="rounded-full border border-line bg-surface px-2 py-0.5 font-mono text-2xs text-ink-secondary">
                  {tool}
                </span>
              ))}
              {message.data.context_key ? (
                <span className="rounded-full border border-brand-100 bg-surface px-2 py-0.5 text-2xs text-brand-700">
                  published <code className="font-mono">{message.data.context_key}</code>
                </span>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </li>
  );
}

/** Shows `backticked` expressions as code. */
function renderCode(text: string): ReactNode {
  const parts = text.split(/(`[^`]+`)/g);
  return parts.map((part, index) =>
    part.startsWith('`') && part.endsWith('`') ? (
      <code key={index} className="rounded bg-surface px-1 font-mono text-xs">
        {part.slice(1, -1)}
      </code>
    ) : (
      <span key={index}>{part}</span>
    ),
  );
}

function ContextRow({
  entry,
  participants,
  isNew,
}: {
  entry: SharedContextEntry;
  participants: Record<string, CollaborationParticipant>;
  isNew: boolean;
}) {
  const writer = participants[entry.written_by];
  const kindLabel = { input: 'Run input', agent_result: 'Agent result', decision: 'Decision', approval: 'Approval' }[entry.kind];
  return (
    <li className={cn('grid gap-2 px-5 py-2.5 sm:grid-cols-[minmax(0,1fr)_auto]', isNew && 'animate-slide-up bg-brand-50/40')}>
      <div className="min-w-0">
        <p className="flex flex-wrap items-center gap-2">
          <code className="font-mono text-xs font-semibold text-ink">{entry.key}</code>
          <Badge tone={entry.kind === 'agent_result' ? 'brand' : entry.kind === 'approval' ? 'warning' : 'neutral'}>{kindLabel}</Badge>
        </p>
        <p className="mt-0.5 line-clamp-1 text-xs text-ink-secondary">{entry.preview}</p>
        {entry.fields?.length ? (
          <p className="mt-0.5 text-2xs text-ink-tertiary">fields: {entry.fields.join(', ')}</p>
        ) : null}
      </div>
      <div className="flex items-center gap-3 text-2xs text-ink-tertiary">
        <span className="flex items-center gap-1" title={`Written by ${writer?.name ?? entry.written_by}`}>
          <Avatar participant={writer} size="sm" />
          <span className="hidden max-w-[110px] truncate sm:inline">{writer?.name}</span>
        </span>
        {entry.used_by.length ? (
          <span className="flex items-center gap-1">
            <ArrowRight className="h-3 w-3" aria-label="used by" />
            {entry.used_by.slice(0, 3).map((key) => (
              <span key={key} title={`Used by ${participants[key]?.name ?? key}`}>
                <Avatar participant={participants[key]} size="sm" />
              </span>
            ))}
          </span>
        ) : null}
      </div>
    </li>
  );
}
