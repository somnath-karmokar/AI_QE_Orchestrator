/**
 * What the collaboration graph looks like after a given message.
 *
 * Replaying a run reveals its conversation one message at a time; each message
 * says which node it changed and which hand-off edges it travelled, so the graph
 * at any point is simply the fold of the messages so far. Past the last message
 * the recorded final state is used, which also carries the paths not taken.
 */
import type { CollaborationEdge, CollaborationNodeState, RunCollaboration } from '@/types';

export interface ReplayFrame {
  nodeStates: Record<string, CollaborationNodeState>;
  edgeStates: Record<string, CollaborationEdge['state']>;
  /** Edges a hand-off packet should travel right now. */
  pulses: Record<string, 'once' | 'loop'>;
  /** Nodes whose outcome (e.g. a decision) has been revealed. */
  revealed: Set<string>;
  complete: boolean;
}

export function frameAt(collaboration: RunCollaboration, cursor: number): ReplayFrame {
  const { graph, conversation } = collaboration;
  const last = conversation.length - 1;

  if (cursor >= last) {
    const pulses: ReplayFrame['pulses'] = {};
    for (const edge of graph.edges) if (edge.state === 'active') pulses[edge.id] = 'loop';
    for (const id of conversation[last]?.edges ?? []) pulses[id] ??= 'once';
    return {
      nodeStates: Object.fromEntries(graph.nodes.map((node) => [node.node_key, node.state])),
      edgeStates: Object.fromEntries(graph.edges.map((edge) => [edge.id, edge.state])),
      pulses,
      revealed: new Set(graph.nodes.map((node) => node.node_key)),
      complete: true,
    };
  }

  const nodeStates: ReplayFrame['nodeStates'] = Object.fromEntries(
    graph.nodes.map((node) => [node.node_key, 'pending' as CollaborationNodeState]),
  );
  const edgeStates: ReplayFrame['edgeStates'] = Object.fromEntries(graph.edges.map((edge) => [edge.id, 'pending' as const]));
  const revealed = new Set<string>();

  for (const message of conversation.slice(0, Math.max(0, cursor + 1))) {
    if (message.node_key && message.node_state) {
      nodeStates[message.node_key] = message.node_state;
      revealed.add(message.node_key);
    }
    for (const id of message.edges) edgeStates[id] = 'traversed';
    if (message.kind === 'decision' && message.node_key) {
      for (const edge of graph.edges) {
        if (edge.source === message.node_key && !message.edges.includes(edge.id)) edgeStates[edge.id] = 'not_taken';
      }
    }
  }

  const pulses: ReplayFrame['pulses'] = {};
  const current = cursor >= 0 ? conversation[cursor] : undefined;
  for (const id of current?.edges ?? []) {
    pulses[id] = 'once';
    edgeStates[id] = 'active';
  }
  return { nodeStates, edgeStates, pulses, revealed, complete: false };
}

/** How long to dwell on a message before revealing the next, scaled by speed. */
export function dwellMs(kind: string, speed: number): number {
  const base = kind === 'handoff' || kind === 'decision' || kind === 'approval_decision' ? 1700 : 1100;
  return Math.round(base / Math.max(0.25, speed));
}

/** Handoffs grouped by sender and receiver, for the "who worked with whom" list. */
export function handoffPairs(collaboration: RunCollaboration): { from: string; to: string; count: number; last: string }[] {
  const pairs = new Map<string, { from: string; to: string; count: number; last: string }>();
  for (const message of collaboration.conversation) {
    if (message.kind !== 'handoff' && message.kind !== 'decision' && message.kind !== 'approval_decision') continue;
    for (const to of message.to) {
      if (to === message.from) continue;
      const key = `${message.from}->${to}`;
      const entry = pairs.get(key) ?? { from: message.from, to, count: 0, last: '' };
      entry.count += 1;
      entry.last = message.text;
      pairs.set(key, entry);
    }
  }
  return [...pairs.values()];
}
