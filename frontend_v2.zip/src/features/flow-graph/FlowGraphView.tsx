/**
 * Read-only picture of an agent flow.
 *
 * Used wherever a flow is shown rather than edited: a flow's workspace, a drafted
 * flow in the creation wizard, and a run's collaboration view, where nodes carry
 * their live state and edges carry the hand-offs between agents -- a data packet
 * travels along an edge when one step passes its result to the next.
 */
import { memo, useEffect, useMemo, useRef, useState } from 'react';
import ReactFlow, {
  Background,
  BaseEdge,
  Controls,
  EdgeLabelRenderer,
  getBezierPath,
  getRectOfNodes,
  getSmoothStepPath,
  Handle,
  Position,
  ReactFlowProvider,
  useNodesState,
  useReactFlow,
  type Edge,
  type EdgeProps,
  type NodeProps,
} from 'reactflow';
import 'reactflow/dist/style.css';
import {
  Check,
  CheckCircle2,
  Clock,
  Flag,
  GitBranch,
  Loader2,
  Minus,
  UserCheck,
  X,
} from 'lucide-react';
import { AgentIcon } from '@/components/AgentIcon';
import { cn } from '@/design-system/primitives';

export type GraphNodeState =
  | 'static'
  | 'pending'
  | 'running'
  | 'succeeded'
  | 'failed'
  | 'awaiting_approval'
  | 'not_reached'
  | 'skipped'
  | 'cancelled';

export type GraphEdgeState = 'static' | 'pending' | 'active' | 'traversed' | 'not_taken';

export interface GraphNodeInput {
  node_key: string;
  node_type: string;
  label: string;
  position_x: number;
  position_y: number;
  subtitle?: string | null;
  icon?: string | null;
  state?: GraphNodeState;
  metrics?: string[];
  decision?: boolean | null;
  dimmed?: boolean;
}

export interface GraphEdgeInput {
  id: string;
  source: string;
  target: string;
  branch_label?: string | null;
  state?: GraphEdgeState;
  /** Play a hand-off packet along this edge. `loop` keeps it flowing while a step runs. */
  pulse?: 'once' | 'loop' | null;
  pulseKey?: string | number;
}

const STATE_META: Record<GraphNodeState, { label: string; ring: string; chip: string; icon: typeof Check | null }> = {
  static: { label: '', ring: 'border-line-strong', chip: '', icon: null },
  pending: { label: 'Waiting', ring: 'border-line-strong', chip: 'bg-surface-sunken text-ink-tertiary', icon: Clock },
  running: { label: 'Working', ring: 'border-brand-500 ring-4 ring-brand-100', chip: 'bg-brand-50 text-brand-700', icon: Loader2 },
  succeeded: { label: 'Done', ring: 'border-success-border', chip: 'bg-success-bg text-success-text', icon: Check },
  failed: { label: 'Failed', ring: 'border-danger', chip: 'bg-danger-bg text-danger-text', icon: X },
  awaiting_approval: { label: 'Needs approval', ring: 'border-warning ring-4 ring-warning-bg', chip: 'bg-warning-bg text-warning-text', icon: UserCheck },
  not_reached: { label: 'Not needed', ring: 'border-dashed border-line-strong', chip: 'bg-surface-sunken text-ink-tertiary', icon: Minus },
  skipped: { label: 'Skipped', ring: 'border-dashed border-line-strong', chip: 'bg-surface-sunken text-ink-tertiary', icon: Minus },
  cancelled: { label: 'Cancelled', ring: 'border-line-strong', chip: 'bg-surface-sunken text-ink-tertiary', icon: X },
};

const SUBTITLE: Record<string, string> = {
  condition: 'Decision',
  approval: 'Human approval',
  tool: 'Tool call',
  parallel: 'Parallel split',
  join: 'Join',
};

/* -------------------------------------------------------------------------- */
/* Node                                                                       */
/* -------------------------------------------------------------------------- */

const GraphNode = memo(function GraphNode({ data, selected }: NodeProps<GraphNodeInput>) {
  const state = data.state ?? 'static';
  const meta = STATE_META[state];
  const StateIcon = meta.icon;
  const terminal = data.node_type === 'start' || data.node_type === 'end';

  if (terminal) {
    return (
      <div
        className={cn(
          'flex h-9 items-center gap-2 rounded-full border-2 bg-surface px-4 text-xs font-semibold text-ink shadow-card transition-all',
          state === 'succeeded' ? 'border-success-border text-success-text' : state === 'failed' ? 'border-danger text-danger-text' : 'border-line-strong',
          (state === 'not_reached' || data.dimmed) && 'opacity-50',
          selected && 'ring-2 ring-brand-500 ring-offset-2',
        )}
      >
        {data.node_type === 'end' ? <Handle type="target" position={Position.Top} className="!opacity-0" /> : null}
        {data.node_type === 'start' ? <Flag className="h-3.5 w-3.5" aria-hidden /> : <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />}
        {data.label}
        {data.node_type === 'start' ? <Handle type="source" position={Position.Bottom} className="!opacity-0" /> : null}
      </div>
    );
  }

  return (
    <div
      className={cn(
        'w-[232px] rounded-xl border-2 bg-surface shadow-card transition-all duration-300',
        meta.ring,
        (state === 'not_reached' || state === 'skipped' || data.dimmed) && 'opacity-50',
        selected && 'shadow-raised outline outline-2 outline-offset-2 outline-brand-500',
      )}
    >
      <Handle type="target" position={Position.Top} className="!opacity-0" />
      <div className="flex items-start gap-2.5 p-3">
        {data.node_type === 'agent' ? (
          <AgentIcon name={data.icon} className={cn('h-9 w-9 shrink-0', state === 'running' && 'animate-pulse')} />
        ) : (
          <span
            className={cn(
              'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border',
              data.node_type === 'approval' ? 'border-warning-border bg-warning-bg text-warning-text' : 'border-line bg-surface-muted text-ink-secondary',
            )}
            aria-hidden
          >
            {data.node_type === 'approval' ? <UserCheck className="h-4 w-4" /> : <GitBranch className="h-4 w-4" />}
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-ink" title={data.label}>
            {data.label}
          </p>
          <p className="truncate text-2xs text-ink-secondary">{data.subtitle ?? SUBTITLE[data.node_type] ?? 'Agent'}</p>
        </div>
      </div>
      {state !== 'static' || data.metrics?.length || data.decision !== undefined ? (
        <div className="flex flex-wrap items-center gap-1 border-t border-line-subtle px-3 py-1.5">
          {state !== 'static' ? (
            <span className={cn('inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-2xs font-medium', meta.chip)}>
              {StateIcon ? <StateIcon className={cn('h-3 w-3', state === 'running' && 'animate-spin')} aria-hidden /> : null}
              {meta.label}
            </span>
          ) : null}
          {data.decision !== undefined && data.decision !== null ? (
            <span className="rounded bg-surface-sunken px-1.5 py-0.5 text-2xs font-medium text-ink">
              {data.decision ? 'Yes' : 'No'}
            </span>
          ) : null}
          {data.metrics?.map((metric) => (
            <span key={metric} className="text-2xs text-ink-tertiary tabular">
              {metric}
            </span>
          ))}
        </div>
      ) : null}
      <Handle type="source" position={Position.Bottom} className="!opacity-0" />
    </div>
  );
});

/* -------------------------------------------------------------------------- */
/* Edge                                                                       */
/* -------------------------------------------------------------------------- */

const EDGE_STYLE: Record<GraphEdgeState, { stroke: string; width: number; dash?: string; opacity?: number }> = {
  static: { stroke: '#8B95A3', width: 1.5 },
  pending: { stroke: '#BCC9D7', width: 1.5 },
  active: { stroke: '#145DA0', width: 2.5, dash: '6 6' },
  traversed: { stroke: '#145DA0', width: 2 },
  not_taken: { stroke: '#BCC9D7', width: 1.5, dash: '4 5', opacity: 0.8 },
};

const READABLE_ZOOM = 0.72;

function HandoffEdge({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, data }: EdgeProps<GraphEdgeInput>) {
  // A path that rejoins a node on the same row (e.g. a review merging back) reads
  // better as right-angled steps than as an S-curve through both cards.
  const rejoins = targetY < sourceY + 40;
  const [path, labelX, labelY] = rejoins
    ? getSmoothStepPath({ sourceX, sourceY, sourcePosition, targetX, targetY, targetPosition, borderRadius: 14, offset: 22 })
    : getBezierPath({ sourceX, sourceY, sourcePosition, targetX, targetY, targetPosition });
  const state = data?.state ?? 'static';
  const style = EDGE_STYLE[state];
  const branch = data?.branch_label ? (data.branch_label.toLowerCase() === 'true' ? 'Yes' : data.branch_label.toLowerCase() === 'false' ? 'No' : data.branch_label) : null;

  return (
    <>
      <g className={state === 'active' ? 'edge-flowing' : undefined}>
        <BaseEdge
          id={id}
          path={path}
          style={{
            stroke: style.stroke,
            strokeWidth: style.width,
            strokeDasharray: style.dash,
            opacity: style.opacity,
          }}
          markerEnd={`url(#arrow-${state})`}
        />
      </g>
      {data?.pulse ? (
        <g key={String(data.pulseKey ?? 'pulse')}>
          <circle r={9} fill="#145DA0" opacity={0.18}>
            <animateMotion dur="1.2s" repeatCount={data.pulse === 'loop' ? 'indefinite' : '1'} path={path} fill="freeze" />
          </circle>
          <circle r={5} fill="#145DA0" stroke="#FFFFFF" strokeWidth={2}>
            <animateMotion dur="1.2s" repeatCount={data.pulse === 'loop' ? 'indefinite' : '1'} path={path} fill="freeze" />
          </circle>
        </g>
      ) : null}
      {branch ? (
        <EdgeLabelRenderer>
          <span
            style={{ transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)` }}
            className={cn(
              'nodrag nopan pointer-events-none absolute rounded-full border px-2 py-0.5 text-2xs font-semibold',
              state === 'not_taken' ? 'border-line bg-surface text-ink-tertiary' : 'border-brand-200 bg-brand-50 text-brand-700',
            )}
          >
            {branch}
          </span>
        </EdgeLabelRenderer>
      ) : null}
    </>
  );
}

const nodeTypes = { graphNode: GraphNode };
const edgeTypes = { handoff: HandoffEdge };

function ArrowMarkers() {
  return (
    <svg className="absolute h-0 w-0" aria-hidden>
      <defs>
        {(Object.keys(EDGE_STYLE) as GraphEdgeState[]).map((state) => (
          <marker
            key={state}
            id={`arrow-${state}`}
            viewBox="0 0 10 10"
            refX="8"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" fill={EDGE_STYLE[state].stroke} />
          </marker>
        ))}
      </defs>
    </svg>
  );
}

/* -------------------------------------------------------------------------- */

interface FlowGraphViewProps {
  nodes: GraphNodeInput[];
  edges: GraphEdgeInput[];
  height?: number;
  selected?: string | null;
  onSelect?: (nodeKey: string | null) => void;
  label: string;
  className?: string;
  /** Keep the camera on this node (e.g. the agent speaking); null shows the whole flow. */
  focusNodeKey?: string | null;
}

export function FlowGraphView(props: FlowGraphViewProps) {
  return (
    <ReactFlowProvider>
      <GraphCanvas {...props} />
    </ReactFlowProvider>
  );
}

function GraphCanvas({ nodes, edges, height = 520, selected, onSelect, label, className, focusNodeKey }: FlowGraphViewProps) {
  const flow = useReactFlow();
  const [flowNodes, setFlowNodes, onNodesChange] = useNodesState<GraphNodeInput>([]);

  // React Flow drops a node's measured size when the node object is replaced, and an
  // unmeasured node is hidden. Live views refresh every second or two, so carry the
  // measured size over and change only what the data changed.
  const nodesKey = JSON.stringify(nodes);
  useEffect(() => {
    setFlowNodes((current) =>
      nodes.map((node) => {
        const terminal = node.node_type === 'start' || node.node_type === 'end';
        const previous = current.find((item) => item.id === node.node_key);
        return {
          ...(previous ?? {}),
          id: node.node_key,
          type: 'graphNode',
          // Terminal pills are narrower than cards; nudge them to sit on the column's centre.
          position: { x: node.position_x + (terminal ? 66 : 0), y: node.position_y },
          data: node,
          selected: selected === node.node_key,
          draggable: false,
          connectable: false,
        };
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodesKey, selected, setFlowNodes]);

  const edgesKey = JSON.stringify(edges);
  const flowEdges: Edge<GraphEdgeInput>[] = useMemo(
    () => edges.map((edge) => ({ id: edge.id, source: edge.source, target: edge.target, type: 'handoff', data: edge })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [edgesKey],
  );

  // Follow the conversation: glide to the node that is acting now. Otherwise show the
  // flow at a readable size from the top; a tall flow is explored by dragging.
  const containerRef = useRef<HTMLDivElement>(null);
  const [taller, setTaller] = useState(false);
  const measured = flowNodes.length > 0 && flowNodes.every((node) => node.width);
  useEffect(() => {
    if (!measured) return;
    const target = focusNodeKey ? flow.getNode(focusNodeKey) : undefined;
    if (target) {
      flow.setCenter(
        target.position.x + (target.width ?? 232) / 2,
        target.position.y + (target.height ?? 90) / 2 + 60,
        { zoom: 0.85, duration: 700 },
      );
      return;
    }
    const box = containerRef.current;
    if (!box) return;
    const bounds = getRectOfNodes(flow.getNodes());
    const fit = Math.min(box.clientWidth / (bounds.width + 96), box.clientHeight / (bounds.height + 96));
    const zoom = Math.min(1, Math.max(fit, READABLE_ZOOM));
    const fitsVertically = bounds.height * zoom + 96 <= box.clientHeight;
    setTaller(!fitsVertically);
    flow.setViewport(
      {
        x: (box.clientWidth - bounds.width * zoom) / 2 - bounds.x * zoom,
        y: fitsVertically ? (box.clientHeight - bounds.height * zoom) / 2 - bounds.y * zoom : 32 - bounds.y * zoom,
        zoom,
      },
      { duration: 400 },
    );
  }, [focusNodeKey, measured, flow]);

  return (
    <div
      ref={containerRef}
      className={cn('relative overflow-hidden rounded-lg border border-line bg-surface-muted', className)}
      style={{ height }}
      role="img"
      aria-label={label}
    >
      {taller && !focusNodeKey ? (
        <span className="pointer-events-none absolute left-3 top-3 z-10 rounded-full border border-line bg-surface/90 px-2.5 py-1 text-2xs text-ink-secondary shadow-card">
          Drag to see the whole flow
        </span>
      ) : null}
      <ArrowMarkers />
      <ReactFlow
        nodes={flowNodes}
        edges={flowEdges}
        onNodesChange={onNodesChange}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        minZoom={0.25}
        maxZoom={1.4}
        nodesDraggable={false}
        nodesConnectable={false}
        edgesFocusable={false}
        zoomOnScroll={false}
        panOnScroll={false}
        preventScrolling={false}
        onNodeClick={(_, node) => onSelect?.(selected === node.id ? null : node.id)}
        onPaneClick={() => onSelect?.(null)}
        proOptions={{ hideAttribution: true }}
      >
        <Background gap={20} size={1} color="#D9E1EA" />
        <Controls showInteractive={false} position="bottom-right" />
      </ReactFlow>
    </div>
  );
}
