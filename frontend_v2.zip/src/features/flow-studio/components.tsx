/** Building blocks shared by the Flow Studio home, the creation wizard and flow workspaces. */
import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import {
  Accessibility,
  Bot,
  CalendarClock,
  ChevronRight,
  Gauge,
  GitBranch,
  Hand,
  Microscope,
  Play,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  UserCheck,
  Users,
  Webhook,
  Workflow,
  X,
  type LucideIcon,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useWorkspace } from '@/store';
import { Badge, Button, cn, Field, Input, Select } from '@/design-system/primitives';
import {
  ROLE_LABELS,
  RUN_ROLES,
  WEEKDAYS,
  describeSchedule,
  fromInputValue,
  initials,
  personName,
  toInputValue,
} from './format';
import type { FlowGovernanceSettings, FlowSchedule } from '@/types';

/* -------------------------------------------------------------------------- */
/* Icons                                                                      */
/* -------------------------------------------------------------------------- */

const TEMPLATE_ICONS: Record<string, LucideIcon> = {
  Sparkles,
  Microscope,
  TrendingDown,
  Gauge,
  Users,
  Accessibility,
  ShieldCheck,
  Workflow,
};

export function TemplateGlyph({ icon, className }: { icon: string; className?: string }) {
  const Icon = TEMPLATE_ICONS[icon] ?? Workflow;
  return (
    <span
      className={cn(
        'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-brand-100 bg-brand-50 text-brand-600',
        className,
      )}
      aria-hidden
    >
      <Icon className="h-5 w-5" />
    </span>
  );
}

const STEP_ICONS: Record<string, LucideIcon> = {
  agent: Bot,
  approval: UserCheck,
  condition: GitBranch,
};

export function StepIcon({ type, className }: { type: string; className?: string }) {
  const Icon = STEP_ICONS[type] ?? Workflow;
  return <Icon className={cn('h-3.5 w-3.5', className)} aria-hidden />;
}

/** A compact, readable chain of a flow's steps. */
export function StepChain({
  steps,
  max = 6,
  className,
}: {
  steps: { label: string; node_type: string; requires_approval?: boolean; agent_name?: string | null }[];
  max?: number;
  className?: string;
}) {
  const shown = steps.slice(0, max);
  const hidden = steps.length - shown.length;
  return (
    <ol className={cn('flex flex-wrap items-center gap-1', className)} aria-label="Steps">
      {shown.map((step, index) => (
        <li key={`${step.label}-${index}`} className="flex items-center gap-1">
          <span
            className={cn(
              'inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-2xs font-medium',
              step.node_type === 'approval' || step.requires_approval
                ? 'border-warning-border bg-warning-bg text-warning-text'
                : step.node_type === 'condition'
                  ? 'border-line bg-surface-sunken text-ink-secondary'
                  : 'border-brand-100 bg-brand-50 text-brand-700',
            )}
            title={step.agent_name ?? step.label}
          >
            <StepIcon type={step.requires_approval ? 'approval' : step.node_type} className="h-3 w-3" />
            <span className="max-w-[140px] truncate">{step.label}</span>
          </span>
          {index < shown.length - 1 ? <ChevronRight className="h-3 w-3 text-ink-tertiary" aria-hidden /> : null}
        </li>
      ))}
      {hidden > 0 ? <li className="text-2xs text-ink-tertiary">+{hidden} more</li> : null}
    </ol>
  );
}

/* -------------------------------------------------------------------------- */
/* People, triggers, status                                                   */
/* -------------------------------------------------------------------------- */

export function OwnerChip({ email, className }: { email?: string | null; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 text-xs text-ink-secondary', className)}>
      <span
        className="flex h-5 w-5 items-center justify-center rounded-full bg-navy-100 text-[10px] font-semibold text-navy-700"
        aria-hidden
      >
        {initials(email)}
      </span>
      <span className="truncate">{personName(email)}</span>
    </span>
  );
}

export function TriggerBadges({
  schedule,
  scheduleDescription,
  apiEnabled,
  className,
}: {
  schedule?: FlowSchedule | null;
  scheduleDescription?: string;
  apiEnabled?: boolean;
  className?: string;
}) {
  return (
    <span className={cn('inline-flex flex-wrap items-center gap-1.5', className)}>
      <Badge tone="neutral">
        <Hand className="h-3 w-3" aria-hidden /> Manual
      </Badge>
      {schedule?.enabled ? (
        <Badge tone="brand">
          <CalendarClock className="h-3 w-3" aria-hidden /> {scheduleDescription ?? describeSchedule(schedule)}
        </Badge>
      ) : null}
      {apiEnabled ? (
        <Badge tone="info">
          <Webhook className="h-3 w-3" aria-hidden /> API
        </Badge>
      ) : null}
    </span>
  );
}

/** A ring showing a 0–1 score with the number in the middle. */
export function ScoreRing({
  score,
  size = 64,
  label,
  tone = 'brand',
}: {
  score: number;
  size?: number;
  label: string;
  tone?: 'brand' | 'warning' | 'danger';
}) {
  const stroke = 6;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const color = { brand: '#145DA0', warning: '#B7791F', danger: '#C53030' }[tone];
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label={label}>
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#EFF3F8" strokeWidth={stroke} />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={`${circumference * Math.max(0, Math.min(1, score))} ${circumference}`}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <text
        x="50%"
        y="50%"
        dominantBaseline="central"
        textAnchor="middle"
        className="fill-ink text-sm font-semibold"
        style={{ fontVariantNumeric: 'tabular-nums' }}
      >
        {Math.round(score * 100)}%
      </text>
    </svg>
  );
}

/* -------------------------------------------------------------------------- */
/* Form controls                                                              */
/* -------------------------------------------------------------------------- */

export function Toggle({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4">
      <div className="min-w-0">
        <label htmlFor={id} className="text-sm font-medium text-ink">
          {label}
        </label>
        {description ? <p className="mt-0.5 text-xs text-ink-secondary">{description}</p> : null}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors disabled:opacity-50',
          checked ? 'bg-brand-500' : 'bg-line-strong',
        )}
      >
        <span
          className={cn(
            'inline-block h-4 w-4 rounded-full bg-white shadow transition-transform',
            checked ? 'translate-x-[18px]' : 'translate-x-0.5',
          )}
        />
      </button>
    </div>
  );
}

export function ScheduleFields({ value, onChange }: { value: FlowSchedule; onChange: (value: FlowSchedule) => void }) {
  const id = useId();
  const schedule: FlowSchedule = { frequency: 'daily', time: '07:00', weekday: 0, ...value };
  return (
    <div className="space-y-4">
      <Toggle
        checked={Boolean(value.enabled)}
        onChange={(enabled) => onChange({ ...schedule, enabled })}
        label="Run on a schedule"
        description="The flow starts itself, with the same validation, budget and approvals as a manual run."
      />
      {value.enabled ? (
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Frequency" htmlFor={`${id}-frequency`}>
            <Select
              id={`${id}-frequency`}
              value={schedule.frequency}
              onChange={(event) => onChange({ ...schedule, frequency: event.target.value as FlowSchedule['frequency'] })}
            >
              <option value="hourly">Hourly</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
            </Select>
          </Field>
          {schedule.frequency === 'weekly' ? (
            <Field label="Day" htmlFor={`${id}-weekday`}>
              <Select
                id={`${id}-weekday`}
                value={schedule.weekday}
                onChange={(event) => onChange({ ...schedule, weekday: Number(event.target.value) })}
              >
                {WEEKDAYS.map((day, index) => (
                  <option key={day} value={index}>
                    {day}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          <Field label={schedule.frequency === 'hourly' ? 'Minute past the hour' : 'Time (UTC)'} htmlFor={`${id}-time`}>
            <Input
              id={`${id}-time`}
              type="time"
              value={schedule.time}
              onChange={(event) => onChange({ ...schedule, time: event.target.value || '07:00' })}
            />
          </Field>
          <p className="text-xs text-ink-secondary sm:col-span-3">
            <CalendarClock className="mr-1 inline h-3.5 w-3.5 align-[-2px]" aria-hidden />
            {describeSchedule({ ...schedule, enabled: true })}
          </p>
        </div>
      ) : null}
    </div>
  );
}

export function GovernanceFields({
  value,
  onChange,
}: {
  value: FlowGovernanceSettings;
  onChange: (value: FlowGovernanceSettings) => void;
}) {
  const id = useId();
  const toggleRole = (role: string) => {
    const roles = value.run_roles.includes(role)
      ? value.run_roles.filter((item) => item !== role)
      : [...value.run_roles, role];
    onChange({ ...value, run_roles: roles });
  };
  return (
    <div className="space-y-5">
      <fieldset>
        <legend className="text-sm font-medium text-ink">Who can run this flow</legend>
        <p className="mt-0.5 text-xs text-ink-secondary">
          Leave all unticked to allow anyone with run permission. Admins can always run it.
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          {RUN_ROLES.map((role) => {
            const checked = value.run_roles.includes(role);
            return (
              <label
                key={role}
                className={cn(
                  'inline-flex cursor-pointer items-center gap-2 rounded border px-3 py-1.5 text-sm transition-colors',
                  checked ? 'border-brand-300 bg-brand-50 text-brand-700' : 'border-line-strong text-ink-secondary hover:bg-surface-muted',
                )}
              >
                <input
                  type="checkbox"
                  className="h-3.5 w-3.5 accent-brand-500"
                  checked={checked}
                  onChange={() => toggleRole(role)}
                />
                {ROLE_LABELS[role]}
              </label>
            );
          })}
        </div>
      </fieldset>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          label={`Budget alert at ${value.budget_alert_percent}% of the per-run budget`}
          htmlFor={`${id}-alert`}
          hint="The owner is notified and the event is audited when a run crosses it."
        >
          <input
            id={`${id}-alert`}
            type="range"
            min={50}
            max={100}
            step={5}
            value={value.budget_alert_percent}
            onChange={(event) => onChange({ ...value, budget_alert_percent: Number(event.target.value) })}
            className="w-full accent-brand-500"
          />
        </Field>
        <Field label="Reliability target (SLO)" htmlFor={`${id}-slo`} hint="Success rate the flow is expected to hold.">
          <Select
            id={`${id}-slo`}
            value={value.slo_success_rate}
            onChange={(event) => onChange({ ...value, slo_success_rate: Number(event.target.value) })}
          >
            {[0.8, 0.85, 0.9, 0.95, 0.99].map((target) => (
              <option key={target} value={target}>
                {Math.round(target * 100)}% of runs succeed
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <Toggle
        checked={value.notify_on_failure}
        onChange={(notify_on_failure) => onChange({ ...value, notify_on_failure })}
        label="Notify on failure"
        description="Raise a notification for the owner whenever a run fails."
      />
    </div>
  );
}

export const DEFAULT_GOVERNANCE: FlowGovernanceSettings = {
  run_roles: [],
  budget_alert_percent: 80,
  notify_on_failure: true,
  slo_success_rate: 0.9,
};

/* -------------------------------------------------------------------------- */
/* Dialog and the run dialog                                                  */
/* -------------------------------------------------------------------------- */

export function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 'max-w-lg',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  width?: string;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const focusable = panelRef.current?.querySelector<HTMLElement>('input, select, textarea, button');
    focusable?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      previous?.focus();
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/40 animate-fade-in" onClick={onClose} aria-hidden />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className={cn('relative w-full rounded-xl border border-line bg-surface shadow-popover animate-slide-up', width)}
      >
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
          <div>
            <h2 id={titleId} className="text-lg font-semibold text-ink">
              {title}
            </h2>
            {description ? <p className="mt-0.5 text-sm text-ink-secondary">{description}</p> : null}
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded p-1 text-ink-tertiary hover:bg-surface-sunken">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="max-h-[65vh] overflow-y-auto px-5 py-4">{children}</div>
        {footer ? <div className="flex justify-end gap-2 border-t border-line px-5 py-3">{footer}</div> : null}
      </div>
    </div>
  );
}

export function RunFlowDialog({
  open,
  onClose,
  flowId,
  flowName,
  variables,
}: {
  open: boolean;
  onClose: () => void;
  flowId: string;
  flowName: string;
  variables: Record<string, unknown>;
}) {
  const navigate = useNavigate();
  const environments = useWorkspace((state) => state.environments);
  const selectedEnvironment = useWorkspace((state) => state.environmentId);
  const [values, setValues] = useState<Record<string, string>>({});
  const [environmentId, setEnvironmentId] = useState<string>('');
  const id = useId();

  // Reset the form each time the dialog opens, not on every parent render.
  const variablesKey = JSON.stringify(variables);
  useEffect(() => {
    if (!open) return;
    setValues(Object.fromEntries(Object.entries(variables).map(([key, value]) => [key, toInputValue(value)])));
    setEnvironmentId(selectedEnvironment ?? '');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, variablesKey]);

  const run = useMutation({
    mutationFn: () =>
      api.runFlow(flowId, {
        inputs: Object.fromEntries(
          Object.entries(values).map(([key, text]) => [key, fromInputValue(text, variables[key])]),
        ),
        environment_id: environmentId || undefined,
      }),
    onSuccess: (started) => navigate(`/runs/${started.id}`),
  });

  const error = run.error instanceof ApiError ? run.error.message : run.error ? 'The run could not start.' : null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={`Run ${flowName}`}
      description="Check the inputs, then start. You'll follow the run live."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" icon={<Play className="h-3.5 w-3.5" />} loading={run.isPending} onClick={() => run.mutate()}>
            Start run
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {Object.keys(variables).length === 0 ? (
          <p className="text-sm text-ink-secondary">This flow needs no inputs.</p>
        ) : (
          Object.keys(variables).map((key) => (
            <Field key={key} label={key.replace(/_/g, ' ')} htmlFor={`${id}-${key}`}>
              <Input
                id={`${id}-${key}`}
                value={values[key] ?? ''}
                onChange={(event) => setValues((current) => ({ ...current, [key]: event.target.value }))}
              />
            </Field>
          ))
        )}
        {environments.length ? (
          <Field label="Environment" htmlFor={`${id}-environment`}>
            <Select id={`${id}-environment`} value={environmentId} onChange={(event) => setEnvironmentId(event.target.value)}>
              {environments.map((environment) => (
                <option key={environment.id} value={environment.id}>
                  {environment.name}
                </option>
              ))}
            </Select>
          </Field>
        ) : null}
        {error ? (
          <p role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2 text-sm text-danger-text">
            {error}
          </p>
        ) : null}
      </div>
    </Dialog>
  );
}
