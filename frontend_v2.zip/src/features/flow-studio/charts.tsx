/**
 * Flow Studio charts and metric tiles.
 *
 * Conventions: thin marks (bars at most 24px, 4px rounded data ends, 2px lines),
 * hairline horizontal gridlines only, one y-axis, a legend whenever there is
 * more than one series, hover tooltips on every chart, and a table view of the
 * same numbers for anyone who cannot or would rather not read the chart.
 */
import { useId, useState, type ReactNode } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowDownRight, ArrowUpRight, BarChart3, Minus, Table2 } from 'lucide-react';
import { Card, cn } from '@/design-system/primitives';
import { CHART_INK, OUTCOME_COLORS, shortDate, type Direction } from './format';
import type { FlowDailyPoint } from '@/types';

/* -------------------------------------------------------------------------- */
/* Sparkline                                                                  */
/* -------------------------------------------------------------------------- */

export function Sparkline({
  values,
  label,
  color = '#145DA0',
  width = 96,
  height = 28,
  className,
}: {
  values: number[];
  label: string;
  color?: string;
  width?: number;
  height?: number;
  className?: string;
}) {
  if (values.length < 2) return null;
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const span = max - min || 1;
  const step = width / (values.length - 1);
  const points = values.map((value, index) => [index * step, height - 3 - ((value - min) / span) * (height - 6)]);
  const path = points.map(([x, y], index) => `${index ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const [lastX, lastY] = points[points.length - 1];
  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      role="img"
      aria-label={label}
      className={cn('overflow-visible', className)}
    >
      <path d={path} fill="none" stroke={color} strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={lastX} cy={lastY} r={3} fill={color} stroke="#FFFFFF" strokeWidth={1.5} />
    </svg>
  );
}

/* -------------------------------------------------------------------------- */
/* Metric tile                                                                */
/* -------------------------------------------------------------------------- */

const DIRECTION_STYLE: Record<Direction, string> = {
  better: 'text-success-text bg-success-bg',
  worse: 'text-danger-text bg-danger-bg',
  flat: 'text-ink-secondary bg-surface-sunken',
};

export function MetricTile({
  label,
  value,
  icon,
  hint,
  delta,
  spark,
  sparkLabel,
  className,
}: {
  label: string;
  value: ReactNode;
  icon?: ReactNode;
  hint?: ReactNode;
  delta?: { text: string; direction: Direction; srLabel?: string };
  spark?: number[];
  sparkLabel?: string;
  className?: string;
}) {
  const DeltaIcon = delta?.direction === 'better' ? ArrowUpRight : delta?.direction === 'worse' ? ArrowDownRight : Minus;
  return (
    <Card className={cn('flex flex-col justify-between gap-3 p-4', className)}>
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-ink-tertiary">
          {icon ? <span className="text-ink-secondary">{icon}</span> : null}
          {label}
        </p>
        {delta ? (
          <span
            className={cn('inline-flex items-center gap-0.5 rounded px-1.5 py-0.5 text-2xs font-medium', DIRECTION_STYLE[delta.direction])}
            title={delta.srLabel}
          >
            <DeltaIcon className="h-3 w-3" aria-hidden />
            {delta.text}
            {delta.srLabel ? <span className="sr-only"> {delta.srLabel}</span> : null}
          </span>
        ) : null}
      </div>
      <div className="flex items-end justify-between gap-3">
        <p className="text-[28px] font-semibold leading-none tracking-[-0.02em] text-ink tabular">{value}</p>
        {spark && spark.length > 1 ? (
          <Sparkline values={spark} label={sparkLabel ?? `${label} trend`} className="shrink-0" />
        ) : null}
      </div>
      {hint ? <p className="text-xs text-ink-secondary">{hint}</p> : null}
    </Card>
  );
}

/* -------------------------------------------------------------------------- */
/* Chart card with a table view                                               */
/* -------------------------------------------------------------------------- */

export interface LegendItem {
  label: string;
  color: string;
}

export function ChartCard({
  title,
  description,
  legend,
  table,
  actions,
  children,
  className,
}: {
  title: string;
  description?: string;
  legend?: LegendItem[];
  table: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const [view, setView] = useState<'chart' | 'table'>('chart');
  const headingId = useId();
  return (
    <Card className={cn('flex flex-col', className)} aria-labelledby={headingId}>
      <div className="flex flex-wrap items-start justify-between gap-3 px-5 pt-4">
        <div className="min-w-0">
          <h3 id={headingId} className="text-md font-semibold text-ink">
            {title}
          </h3>
          {description ? <p className="mt-0.5 text-sm text-ink-secondary">{description}</p> : null}
        </div>
        <div className="flex items-center gap-2 print:hidden">
          {actions}
          <div role="group" aria-label={`${title} view`} className="inline-flex rounded border border-line bg-surface-muted p-0.5">
            {(['chart', 'table'] as const).map((option) => (
              <button
                key={option}
                type="button"
                aria-pressed={view === option}
                onClick={() => setView(option)}
                className={cn(
                  'inline-flex h-6 items-center gap-1 rounded px-2 text-2xs font-medium transition-colors',
                  view === option ? 'bg-surface text-ink shadow-card' : 'text-ink-secondary hover:text-ink',
                )}
              >
                {option === 'chart' ? <BarChart3 className="h-3 w-3" aria-hidden /> : <Table2 className="h-3 w-3" aria-hidden />}
                {option === 'chart' ? 'Chart' : 'Table'}
              </button>
            ))}
          </div>
        </div>
      </div>
      {legend && legend.length > 1 && view === 'chart' ? (
        <ul className="flex flex-wrap gap-x-4 gap-y-1 px-5 pt-3" aria-label="Legend">
          {legend.map((item) => (
            <li key={item.label} className="flex items-center gap-1.5 text-xs text-ink-secondary">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: item.color }} aria-hidden />
              {item.label}
            </li>
          ))}
        </ul>
      ) : null}
      <div className="flex-1 px-3 pb-4 pt-2">{view === 'chart' ? children : <div className="px-2">{table}</div>}</div>
    </Card>
  );
}

/** Compact table used as the accessible twin of a chart. */
export function MiniTable<T>({
  columns,
  rows,
  caption,
  maxHeight = 260,
}: {
  columns: { header: string; render: (row: T) => ReactNode; numeric?: boolean }[];
  rows: T[];
  caption: string;
  maxHeight?: number;
}) {
  return (
    <div className="overflow-auto rounded border border-line" style={{ maxHeight }}>
      <table className="w-full text-xs">
        <caption className="sr-only">{caption}</caption>
        <thead className="sticky top-0 bg-surface-muted">
          <tr>
            {columns.map((column) => (
              <th
                key={column.header}
                scope="col"
                className={cn('border-b border-line px-3 py-2 font-medium text-ink-secondary', column.numeric ? 'text-right' : 'text-left')}
              >
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index} className="border-b border-line-subtle last:border-0">
              {columns.map((column) => (
                <td key={column.header} className={cn('px-3 py-1.5 text-ink', column.numeric && 'text-right tabular')}>
                  {column.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Tooltip                                                                    */
/* -------------------------------------------------------------------------- */

interface TooltipPayloadItem {
  name?: string;
  value?: number | string;
  color?: string;
  dataKey?: string | number;
  payload?: Record<string, unknown>;
}

export function ChartTooltip({
  active,
  payload,
  label,
  format,
  labelFormat = (value) => shortDate(String(value)),
}: {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string | number;
  format?: (value: number, key: string) => string;
  labelFormat?: (value: string | number) => string;
}) {
  if (!active || !payload?.length) return null;
  const items = [...payload].reverse();
  return (
    <div className="min-w-[150px] rounded-md border border-line bg-surface px-3 py-2 shadow-popover">
      <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
        {label !== undefined ? labelFormat(label) : ''}
      </p>
      <ul className="space-y-0.5">
        {items.map((item) => (
          <li key={String(item.dataKey)} className="flex items-center justify-between gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-ink-secondary">
              <span className="h-2 w-2 rounded-sm" style={{ backgroundColor: item.color }} aria-hidden />
              {item.name}
            </span>
            <span className="font-medium text-ink tabular">
              {format ? format(Number(item.value), String(item.dataKey)) : item.value}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Run outcomes per day                                                       */
/* -------------------------------------------------------------------------- */

export const OUTCOME_LEGEND: LegendItem[] = [
  { label: 'Succeeded', color: OUTCOME_COLORS.succeeded },
  { label: 'Needs attention', color: OUTCOME_COLORS.attention },
  { label: 'Failed', color: OUTCOME_COLORS.failed },
];

export function OutcomeColumns({ daily, height = 220 }: { daily: FlowDailyPoint[]; height?: number }) {
  const barSize = Math.max(4, Math.min(24, Math.floor(640 / Math.max(daily.length, 1)) - 6));
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={daily} margin={{ top: 8, right: 8, bottom: 0, left: -18 }} barCategoryGap={2}>
        <CartesianGrid vertical={false} stroke={CHART_INK.grid} />
        <XAxis
          dataKey="date"
          tickFormatter={(value: string) => shortDate(value)}
          tick={{ fill: CHART_INK.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          minTickGap={24}
        />
        <YAxis allowDecimals={false} tick={{ fill: CHART_INK.axis, fontSize: 11 }} axisLine={false} tickLine={false} />
        <RechartsTooltip
          cursor={{ fill: 'rgba(20, 93, 160, 0.06)' }}
          content={<ChartTooltip format={(value) => `${value} run${value === 1 ? '' : 's'}`} />}
        />
        <Bar dataKey="succeeded" name="Succeeded" stackId="runs" fill={OUTCOME_COLORS.succeeded} stroke="#FFFFFF" strokeWidth={1} barSize={barSize} />
        <Bar dataKey="attention" name="Needs attention" stackId="runs" fill={OUTCOME_COLORS.attention} stroke="#FFFFFF" strokeWidth={1} barSize={barSize} />
        <Bar
          dataKey="failed"
          name="Failed"
          stackId="runs"
          fill={OUTCOME_COLORS.failed}
          stroke="#FFFFFF"
          strokeWidth={1}
          barSize={barSize}
          radius={[4, 4, 0, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function OutcomeTable({ daily }: { daily: FlowDailyPoint[] }) {
  return (
    <MiniTable
      caption="Runs per day by outcome"
      rows={[...daily].reverse().filter((day) => day.runs > 0)}
      columns={[
        { header: 'Day', render: (day) => shortDate(day.date) },
        { header: 'Runs', render: (day) => day.runs, numeric: true },
        { header: 'Succeeded', render: (day) => day.succeeded, numeric: true },
        { header: 'Needs attention', render: (day) => day.attention, numeric: true },
        { header: 'Failed', render: (day) => day.failed, numeric: true },
      ]}
    />
  );
}

/* -------------------------------------------------------------------------- */
/* Single-series trend                                                        */
/* -------------------------------------------------------------------------- */

export function TrendLine<T extends { date: string }>({
  data,
  dataKey,
  name,
  color = '#145DA0',
  format,
  height = 200,
  domain,
}: {
  data: T[];
  dataKey: keyof T & string;
  name: string;
  color?: string;
  format: (value: number) => string;
  height?: number;
  domain?: [number | 'auto', number | 'auto'];
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -6 }}>
        <CartesianGrid vertical={false} stroke={CHART_INK.grid} />
        <XAxis
          dataKey="date"
          tickFormatter={(value: string) => shortDate(value)}
          tick={{ fill: CHART_INK.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          minTickGap={24}
        />
        <YAxis
          tickFormatter={(value: number) => format(value)}
          tick={{ fill: CHART_INK.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          width={56}
          domain={domain}
        />
        <RechartsTooltip
          cursor={{ stroke: CHART_INK.axis, strokeDasharray: '3 3' }}
          content={<ChartTooltip format={(value) => format(value)} />}
        />
        <Line
          type="monotone"
          dataKey={dataKey}
          name={name}
          stroke={color}
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 4, stroke: '#FFFFFF', strokeWidth: 2 }}
          connectNulls
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

/* -------------------------------------------------------------------------- */
/* Share-of-total bar                                                         */
/* -------------------------------------------------------------------------- */

export function ShareBar({
  segments,
  format,
  label,
}: {
  segments: { label: string; value: number; color: string; note?: string }[];
  format: (value: number) => string;
  label: string;
}) {
  const total = segments.reduce((sum, segment) => sum + segment.value, 0) || 1;
  return (
    <div>
      <div className="flex h-3 w-full gap-[2px] overflow-hidden rounded" role="img" aria-label={label}>
        {segments
          .filter((segment) => segment.value > 0)
          .map((segment) => (
            <div
              key={segment.label}
              className="h-full first:rounded-l last:rounded-r"
              style={{ width: `${(segment.value / total) * 100}%`, backgroundColor: segment.color }}
              title={`${segment.label}: ${format(segment.value)}`}
            />
          ))}
      </div>
      <ul className="mt-3 grid gap-2 sm:grid-cols-3">
        {segments.map((segment) => (
          <li key={segment.label} className="flex items-start gap-2">
            <span className="mt-1 h-2.5 w-2.5 shrink-0 rounded-sm" style={{ backgroundColor: segment.color }} aria-hidden />
            <div className="min-w-0">
              <p className="text-xs text-ink-secondary">{segment.label}</p>
              <p className="text-sm font-semibold text-ink tabular">
                {format(segment.value)}{' '}
                <span className="text-xs font-normal text-ink-tertiary">{Math.round((segment.value / total) * 100)}%</span>
              </p>
              {segment.note ? <p className="text-2xs text-ink-tertiary">{segment.note}</p> : null}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Horizontal bars (ranked)                                                   */
/* -------------------------------------------------------------------------- */

export function RankedBars({
  rows,
  format,
  color = '#145DA0',
  label,
}: {
  rows: { label: string; value: number; secondary?: string }[];
  format: (value: number) => string;
  color?: string;
  label: string;
}) {
  const max = Math.max(...rows.map((row) => row.value), 0) || 1;
  return (
    <ul className="space-y-2.5" aria-label={label}>
      {rows.map((row) => (
        <li key={row.label}>
          <div className="mb-1 flex items-baseline justify-between gap-3 text-xs">
            <span className="truncate text-ink">{row.label}</span>
            <span className="shrink-0 font-medium text-ink tabular">
              {format(row.value)}
              {row.secondary ? <span className="ml-1.5 font-normal text-ink-tertiary">{row.secondary}</span> : null}
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-surface-sunken">
            <div
              className="h-2 rounded-full"
              style={{ width: `${Math.max(2, (row.value / max) * 100)}%`, backgroundColor: color }}
              title={`${row.label}: ${format(row.value)}`}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}
