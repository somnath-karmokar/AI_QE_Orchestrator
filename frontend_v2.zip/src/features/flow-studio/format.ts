/** Pure helpers shared by Flow Studio pages. No React here, so they are easy to test. */
import type { FlowSchedule } from '@/types';

export const WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export const ROLE_LABELS: Record<string, string> = {
  admin: 'Platform Admin',
  qe_lead: 'QE Lead',
  qe_engineer: 'QE Engineer',
  business_user: 'Business / UAT',
  viewer: 'Viewer',
};

export const RUN_ROLES = ['qe_lead', 'qe_engineer', 'business_user'] as const;

export const TRIGGER_LABELS: Record<string, string> = {
  manual: 'Manual',
  schedule: 'Schedule',
  api: 'API',
  copilot: 'Copilot',
};

/**
 * Run-outcome colours. Validated as a set (light surface): blue / amber / red keep
 * apart for colour-vision deficiencies, where green next to red does not. Amber is
 * below 3:1 on white, so every chart that uses it also offers a table view.
 */
export const OUTCOME_COLORS = {
  succeeded: '#145DA0',
  attention: '#E8A200',
  failed: '#D03B3B',
} as const;

/** Categorical order for multi-series charts: assigned in this order, never cycled. */
export const SERIES_COLORS = ['#145DA0', '#EB6834', '#1BAF7A'] as const;

export const CHART_INK = { axis: '#8B95A3', grid: '#E8EEF4', text: '#5F6B7A' } as const;

/** Mirrors the server's plain-English schedule description. */
export function describeSchedule(schedule?: FlowSchedule | null): string {
  if (!schedule?.enabled) return 'Not scheduled';
  const time = schedule.time ?? '07:00';
  if (schedule.frequency === 'hourly') return `Every hour at :${time.split(':')[1] ?? '00'}`;
  if (schedule.frequency === 'weekly') return `Every ${WEEKDAYS[schedule.weekday ?? 0]} at ${time} UTC`;
  return `Daily at ${time} UTC`;
}

/** "priya.raman@example.com" -> "Priya Raman". */
export function personName(email?: string | null): string {
  if (!email) return 'Unassigned';
  if (!email.includes('@')) return email;
  return email
    .split('@')[0]
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join(' ');
}

export function initials(email?: string | null): string {
  const name = personName(email);
  if (name === 'Unassigned') return '?';
  return name
    .split(' ')
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase();
}

export type Direction = 'better' | 'worse' | 'flat';

/** Whether a change is good news. `higherIsBetter` is false for cost and duration. */
export function deltaDirection(delta: number | null | undefined, higherIsBetter = true, tolerance = 0): Direction {
  if (delta === null || delta === undefined || Math.abs(delta) <= tolerance) return 'flat';
  return delta > 0 === higherIsBetter ? 'better' : 'worse';
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * "2026-09-12" -> "12 Sep". Dates from the API are UTC calendar days, so this
 * reads the parts directly rather than going through a Date and a time zone.
 */
export function shortDate(isoDate: string): string {
  const [year, month, day] = isoDate.slice(0, 10).split('-').map(Number);
  if (!year || !month || !day || month > 12) return isoDate;
  return `${day} ${MONTHS[month - 1]}`;
}

/** A signed percentage-point change, e.g. +7.9 pts. */
export function formatPoints(delta: number | null | undefined): string {
  if (delta === null || delta === undefined) return '—';
  const points = delta * 100;
  const sign = points > 0 ? '+' : points < 0 ? '−' : '±';
  return `${sign}${Math.abs(points).toFixed(1)} pts`;
}

/** Turns flow variables into editable strings and back, keeping numbers as numbers. */
export function toInputValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

export function fromInputValue(text: string, original: unknown): unknown {
  if (typeof original === 'number') {
    const parsed = Number(text);
    return text.trim() === '' || Number.isNaN(parsed) ? original : parsed;
  }
  if (typeof original === 'boolean') return text === 'true';
  if (original !== null && typeof original === 'object') {
    try {
      return JSON.parse(text);
    } catch {
      return original;
    }
  }
  return text;
}

export function humanizeEvent(eventType: string): string {
  return eventType.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
}
