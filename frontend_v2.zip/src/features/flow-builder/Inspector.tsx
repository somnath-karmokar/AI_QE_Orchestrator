/** Editable settings for the selected node or connection. */
import { useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowRight, Plus, Trash2, X } from 'lucide-react';
import { api } from '@/services/api';
import { AgentIcon } from '@/components/AgentIcon';
import {
  Button, Card, CardBody, CardHeader, Field, Input, Select, Textarea,
} from '@/design-system/primitives';
import type { AgentSummary, McpServer } from '@/types';
import { NODE_STYLE } from './FlowNodeCard';
import { parseMappingValue, type DraftEdge, type DraftNode } from './graph';

export const APPROVAL_ROLES: [string, string][] = [
  ['qe_lead', 'QE Lead'],
  ['admin', 'Platform administrator'],
  ['qe_engineer', 'QE Engineer'],
  ['business_user', 'Business / UAT user'],
];

const ON_FAILURE: [string, string][] = [
  ['fail_flow', 'Stop the flow'],
  ['continue', 'Continue with the next step'],
  ['skip_branch', 'Skip the rest of this path'],
];

export interface ModelOption {
  value: string;
  label: string;
}

function numberOrNull(raw: string): number | null {
  if (raw.trim() === '') return null;
  const value = Number(raw);
  return Number.isFinite(value) ? value : null;
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-3 border-t border-line pt-4 first:border-t-0 first:pt-0">
      <p className="text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">{title}</p>
      {children}
    </section>
  );
}

/* -------------------------------------------------------------------------- */

export function NodeInspector({
  node,
  agents,
  agentsById,
  models,
  mcpServers,
  conditionNames,
  outgoing,
  labelFor,
  onChange,
  onEdgeChange,
  onDelete,
}: {
  node: DraftNode;
  agents: AgentSummary[];
  agentsById: Map<string, AgentSummary>;
  models: ModelOption[];
  mcpServers: McpServer[];
  conditionNames: string[];
  outgoing: DraftEdge[];
  labelFor: (key: string) => string;
  onChange: (patch: Partial<DraftNode>) => void;
  onEdgeChange: (id: string, patch: Partial<DraftEdge>) => void;
  onDelete: () => void;
}) {
  const agent = node.agent_id ? agentsById.get(node.agent_id) : undefined;
  const style = NODE_STYLE[node.node_type] ?? NODE_STYLE.agent;
  const Icon = style.icon;
  const id = (field: string) => `node-${node.node_key}-${field}`;

  return (
    <Card>
      <CardHeader
        title={node.label || style.label}
        description={`${style.label} · key ${node.node_key}`}
        icon={
          agent ? (
            <AgentIcon name={agent.icon} className="h-7 w-7" />
          ) : (
            <span className={`flex h-7 w-7 items-center justify-center rounded border ${style.tone}`}>
              <Icon className="h-3.5 w-3.5" />
            </span>
          )
        }
        actions={
          node.node_type !== 'start' ? (
            <Button variant="ghost" size="sm" icon={<Trash2 className="h-3.5 w-3.5" />} onClick={onDelete} aria-label="Remove step">
              Remove
            </Button>
          ) : null
        }
      />
      <CardBody className="space-y-4">
        <Field label="Label" htmlFor={id('label')}>
          <Input id={id('label')} value={node.label} onChange={(event) => onChange({ label: event.target.value })} />
        </Field>

        {node.node_type === 'agent' ? (
          <AgentSettings node={node} agent={agent} agents={agents} models={models} onChange={onChange} idFor={id} />
        ) : null}

        {node.node_type === 'condition' ? (
          <ConditionSettings
            node={node}
            conditionNames={conditionNames}
            outgoing={outgoing}
            labelFor={labelFor}
            onChange={onChange}
            onEdgeChange={onEdgeChange}
            idFor={id}
          />
        ) : null}

        {node.node_type === 'approval' ? <ApprovalSettings node={node} onChange={onChange} idFor={id} /> : null}

        {node.node_type === 'tool' ? (
          <ToolSettings node={node} mcpServers={mcpServers} onChange={onChange} idFor={id} />
        ) : null}

        {['start', 'end', 'parallel', 'join'].includes(node.node_type) ? (
          <p className="text-xs text-ink-secondary">
            {
              {
                start: 'Where the run begins. Run inputs are available to every step as variables.',
                end: 'Marks a path as complete.',
                parallel: 'Every outgoing path is followed.',
                join: 'Waits until every incoming path has finished before continuing.',
              }[node.node_type]
            }
          </p>
        ) : null}
      </CardBody>
    </Card>
  );
}

/* -------------------------------------------------------------------------- */

function AgentSettings({
  node,
  agent,
  agents,
  models,
  onChange,
  idFor,
}: {
  node: DraftNode;
  agent?: AgentSummary;
  agents: AgentSummary[];
  models: ModelOption[];
  onChange: (patch: Partial<DraftNode>) => void;
  idFor: (field: string) => string;
}) {
  const { data: versions } = useQuery({
    queryKey: ['agent-versions', node.agent_id],
    queryFn: () => api.agentVersions(node.agent_id!),
    enabled: Boolean(node.agent_id),
  });

  const modelValue = node.llm_config?.provider && node.llm_config?.model
    ? `${String(node.llm_config.provider)}:${String(node.llm_config.model)}`
    : '';
  const attempts = Number(node.retry_policy?.max_attempts ?? 1);
  const backoff = Number(node.retry_policy?.backoff_seconds ?? 1);

  return (
    <>
      <Field label="Agent" htmlFor={idFor('agent')}>
        <Select
          id={idFor('agent')}
          value={node.agent_id ?? ''}
          onChange={(event) => {
            const next = agents.find((item) => item.id === event.target.value);
            onChange({
              agent_id: next?.id ?? null,
              agent_version: null,
              label: next && (!node.label || node.label === agent?.name) ? next.name : node.label,
            });
          }}
        >
          <option value="">Select an agent</option>
          {[...agents].sort((a, b) => a.name.localeCompare(b.name)).map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
        </Select>
      </Field>
      {agent ? (
        <p className="-mt-2 flex items-center justify-between gap-2 text-xs text-ink-secondary">
          <span>
            {agent.category} · {agent.risk_level} risk
          </span>
          <Link to={`/marketplace/${agent.id}`} className="text-brand-600 hover:text-brand-700">
            View agent <ArrowRight className="inline h-3 w-3" />
          </Link>
        </p>
      ) : null}

      <div className="grid grid-cols-2 gap-3">
        <Field label="Version" htmlFor={idFor('version')} hint="Pin to keep runs repeatable">
          <Select
            id={idFor('version')}
            value={node.agent_version ?? ''}
            onChange={(event) => onChange({ agent_version: event.target.value || null })}
          >
            <option value="">Latest</option>
            {(versions ?? []).map((version) => (
              <option key={version.id} value={version.version}>
                v{version.version}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Model" htmlFor={idFor('model')} hint="Overrides routing">
          <Select
            id={idFor('model')}
            value={modelValue}
            onChange={(event) => {
              const [provider, ...rest] = event.target.value.split(':');
              onChange({ llm_config: event.target.value ? { provider, model: rest.join(':') } : {} });
            }}
          >
            <option value="">Platform routing</option>
            {models.map((model) => (
              <option key={model.value} value={model.value}>
                {model.label}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <Section title="Inputs">
        <MappingEditor
          key={node.node_key}
          value={node.input_mapping}
          onChange={(input_mapping) => onChange({ input_mapping })}
          hint="Run inputs reach every agent automatically. Map a value here to override it, e.g. requirement_key = $requirement_key."
        />
      </Section>

      <Section title="Reliability">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Attempts" htmlFor={idFor('attempts')}>
            <Input
              id={idFor('attempts')}
              type="number"
              min={1}
              max={5}
              value={attempts}
              onChange={(event) =>
                onChange({ retry_policy: { ...node.retry_policy, max_attempts: Math.min(5, Math.max(1, Number(event.target.value) || 1)) } })
              }
            />
          </Field>
          <Field label="Backoff (s)" htmlFor={idFor('backoff')}>
            <Input
              id={idFor('backoff')}
              type="number"
              min={0}
              step={0.5}
              value={backoff}
              disabled={attempts <= 1}
              onChange={(event) =>
                onChange({ retry_policy: { ...node.retry_policy, backoff_seconds: Math.max(0, Number(event.target.value) || 0) } })
              }
            />
          </Field>
          <Field label="Timeout (s)" htmlFor={idFor('timeout')}>
            <Input
              id={idFor('timeout')}
              type="number"
              min={1}
              placeholder="Agent default"
              value={node.timeout_seconds ?? ''}
              onChange={(event) => onChange({ timeout_seconds: numberOrNull(event.target.value) })}
            />
          </Field>
          <Field label="Cost limit (€)" htmlFor={idFor('cost')}>
            <Input
              id={idFor('cost')}
              type="number"
              min={0}
              step={0.01}
              placeholder="Agent budget"
              value={node.cost_limit_usd ?? ''}
              onChange={(event) => onChange({ cost_limit_usd: numberOrNull(event.target.value) })}
            />
          </Field>
        </div>
        <Field label="If this step fails" htmlFor={idFor('failure')}>
          <Select id={idFor('failure')} value={node.on_failure} onChange={(event) => onChange({ on_failure: event.target.value })}>
            {ON_FAILURE.map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </Select>
        </Field>
      </Section>

      <Section title="Governance">
        <label className="flex items-start gap-2.5 text-sm text-ink">
          <input
            type="checkbox"
            className="mt-0.5 h-4 w-4 rounded border-line-strong accent-brand-600"
            checked={node.requires_approval}
            onChange={(event) =>
              onChange({
                requires_approval: event.target.checked,
                approval_role: event.target.checked ? node.approval_role ?? 'qe_lead' : node.approval_role,
              })
            }
          />
          <span>
            Require human approval before this step runs
            <span className="block text-xs text-ink-secondary">
              High-risk agents also pause when a governance policy requires it.
            </span>
          </span>
        </label>
        {node.requires_approval ? (
          <Field label="Approver role" htmlFor={idFor('role')}>
            <RoleSelect id={idFor('role')} value={node.approval_role} onChange={(approval_role) => onChange({ approval_role })} />
          </Field>
        ) : null}
      </Section>
    </>
  );
}

/* -------------------------------------------------------------------------- */

function ConditionSettings({
  node,
  conditionNames,
  outgoing,
  labelFor,
  onChange,
  onEdgeChange,
  idFor,
}: {
  node: DraftNode;
  conditionNames: string[];
  outgoing: DraftEdge[];
  labelFor: (key: string) => string;
  onChange: (patch: Partial<DraftNode>) => void;
  onEdgeChange: (id: string, patch: Partial<DraftEdge>) => void;
  idFor: (field: string) => string;
}) {
  const expression = node.condition_expression ?? '';
  return (
    <>
      <Field
        label="Expression"
        htmlFor={idFor('expression')}
        hint="Compare run variables and earlier results, e.g. user_story_completeness.outputs.completeness_score >= 80"
      >
        <Textarea
          id={idFor('expression')}
          rows={3}
          spellCheck={false}
          className="font-mono text-xs"
          value={expression}
          onChange={(event) => onChange({ condition_expression: event.target.value || null })}
        />
      </Field>
      {conditionNames.length ? (
        <div className="-mt-2 flex flex-wrap gap-1">
          {conditionNames.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => onChange({ condition_expression: `${expression}${expression && !expression.endsWith(' ') ? ' ' : ''}${name}` })}
              className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono text-2xs text-ink-secondary hover:border-brand-300 hover:text-brand-700"
            >
              {name}
            </button>
          ))}
        </div>
      ) : null}

      <Section title="Paths">
        {outgoing.length ? (
          <ul className="space-y-2">
            {outgoing.map((edge) => (
              <li key={edge.id} className="flex items-center gap-2">
                <Select
                  aria-label={`Branch to ${labelFor(edge.target_node_key)}`}
                  value={edge.branch_label ?? ''}
                  onChange={(event) => onEdgeChange(edge.id, { branch_label: event.target.value || null })}
                  className="h-8 w-24 text-xs"
                >
                  <option value="true">If true</option>
                  <option value="false">If false</option>
                  <option value="">Always</option>
                </Select>
                <ArrowRight className="h-3.5 w-3.5 shrink-0 text-ink-tertiary" />
                <span className="truncate text-sm text-ink">{labelFor(edge.target_node_key)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-xs text-ink-secondary">
            Drag from this node&apos;s bottom handle to a step. The first path is taken when the expression is true, the second when it is false.
          </p>
        )}
      </Section>
    </>
  );
}

/* -------------------------------------------------------------------------- */

function ApprovalSettings({
  node,
  onChange,
  idFor,
}: {
  node: DraftNode;
  onChange: (patch: Partial<DraftNode>) => void;
  idFor: (field: string) => string;
}) {
  return (
    <>
      <Field label="Approver role" htmlFor={idFor('role')}>
        <RoleSelect id={idFor('role')} value={node.approval_role} onChange={(approval_role) => onChange({ approval_role })} />
      </Field>
      <Field label="Reason shown to the approver" htmlFor={idFor('reason')}>
        <Textarea
          id={idFor('reason')}
          rows={3}
          value={String(node.config?.reason ?? '')}
          onChange={(event) => onChange({ config: { ...node.config, reason: event.target.value } })}
        />
      </Field>
      <Field label="Risk level" htmlFor={idFor('risk')}>
        <Select
          id={idFor('risk')}
          value={String(node.config?.risk_level ?? 'medium')}
          onChange={(event) => onChange({ config: { ...node.config, risk_level: event.target.value } })}
        >
          {['low', 'medium', 'high', 'critical'].map((level) => (
            <option key={level} value={level}>
              {level}
            </option>
          ))}
        </Select>
      </Field>
      <p className="text-xs text-ink-secondary">
        The run pauses here until someone with this role approves it in Governance. A rejection stops the flow.
      </p>
    </>
  );
}

/* -------------------------------------------------------------------------- */

function ToolSettings({
  node,
  mcpServers,
  onChange,
  idFor,
}: {
  node: DraftNode;
  mcpServers: McpServer[];
  onChange: (patch: Partial<DraftNode>) => void;
  idFor: (field: string) => string;
}) {
  const serverKey = String(node.config?.server ?? '');
  const server = mcpServers.find((item) => item.key === serverKey);
  const tool = server?.tools.find((item) => item.name === node.config?.tool);

  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Server" htmlFor={idFor('server')}>
          <Select
            id={idFor('server')}
            value={serverKey}
            onChange={(event) => onChange({ config: { ...node.config, server: event.target.value, tool: '' } })}
          >
            <option value="">Select</option>
            {mcpServers.map((item) => (
              <option key={item.key} value={item.key}>
                {item.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Tool" htmlFor={idFor('tool')}>
          <Select
            id={idFor('tool')}
            value={String(node.config?.tool ?? '')}
            disabled={!server}
            onChange={(event) => onChange({ config: { ...node.config, tool: event.target.value } })}
          >
            <option value="">Select</option>
            {(server?.tools ?? []).map((item) => (
              <option key={item.name} value={item.name}>
                {item.name}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      {tool ? <p className="-mt-2 text-xs text-ink-secondary">{tool.description}</p> : null}
      <Section title="Arguments">
        <MappingEditor
          key={`${node.node_key}-${String(node.config?.tool ?? '')}`}
          value={node.input_mapping}
          suggestions={tool?.parameters.map((parameter) => parameter.name)}
          onChange={(input_mapping) => onChange({ input_mapping })}
          hint="Use $variable to pass a run value, e.g. $module."
        />
      </Section>
      <Field label="If this step fails" htmlFor={idFor('failure')}>
        <Select id={idFor('failure')} value={node.on_failure} onChange={(event) => onChange({ on_failure: event.target.value })}>
          {ON_FAILURE.map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>
      </Field>
    </>
  );
}

/* -------------------------------------------------------------------------- */

function RoleSelect({ id, value, onChange }: { id: string; value?: string | null; onChange: (role: string) => void }) {
  return (
    <Select id={id} value={value ?? 'qe_lead'} onChange={(event) => onChange(event.target.value)}>
      {APPROVAL_ROLES.map(([role, label]) => (
        <option key={role} value={role}>
          {label}
        </option>
      ))}
    </Select>
  );
}

/** Key/value rows for input mappings and tool arguments. */
function MappingEditor({
  value,
  onChange,
  hint,
  suggestions,
}: {
  value: Record<string, unknown>;
  onChange: (next: Record<string, unknown>) => void;
  hint: string;
  suggestions?: string[];
}) {
  // Rows are local so a half-typed key doesn't vanish; the parent sees complete rows only.
  // An empty editor starts with the tool's parameter names, when there are any.
  const [rows, setRows] = useState<[string, string][]>(() => {
    const existing = Object.entries(value ?? {}).map(
      ([key, item]): [string, string] => [key, typeof item === 'string' ? item : JSON.stringify(item)],
    );
    return existing.length ? existing : (suggestions ?? []).map((name): [string, string] => [name, '']);
  });

  function commit(next: [string, string][]) {
    setRows(next);
    onChange(
      Object.fromEntries(
        next.filter(([key, item]) => key.trim() && item.trim() !== '').map(([key, item]) => [key.trim(), parseMappingValue(item)]),
      ),
    );
  }

  return (
    <div className="space-y-2">
      {rows.map(([key, item], index) => (
        <div key={index} className="flex items-center gap-1.5">
          <Input
            aria-label="Name"
            placeholder="name"
            value={key}
            className="h-8 font-mono text-xs"
            onChange={(event) => commit(rows.map((row, at) => (at === index ? [event.target.value, row[1]] : row)))}
          />
          <Input
            aria-label="Value"
            placeholder="$variable or value"
            value={item}
            className="h-8 font-mono text-xs"
            onChange={(event) => commit(rows.map((row, at) => (at === index ? [row[0], event.target.value] : row)))}
          />
          <button
            type="button"
            aria-label="Remove row"
            onClick={() => commit(rows.filter((_, at) => at !== index))}
            className="rounded p-1 text-ink-tertiary hover:bg-surface-sunken hover:text-ink"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
      <Button variant="ghost" size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setRows([...rows, ['', '']])}>
        Add mapping
      </Button>
      <p className="text-xs text-ink-secondary">{hint}</p>
    </div>
  );
}

/* -------------------------------------------------------------------------- */

export function EdgeInspector({
  edge,
  fromCondition,
  labelFor,
  onChange,
  onDelete,
}: {
  edge: DraftEdge;
  fromCondition: boolean;
  labelFor: (key: string) => string;
  onChange: (patch: Partial<DraftEdge>) => void;
  onDelete: () => void;
}) {
  return (
    <Card>
      <CardHeader
        title="Connection"
        description={`${labelFor(edge.source_node_key)} → ${labelFor(edge.target_node_key)}`}
        actions={
          <Button variant="ghost" size="sm" icon={<Trash2 className="h-3.5 w-3.5" />} onClick={onDelete}>
            Remove
          </Button>
        }
      />
      <CardBody className="space-y-4">
        {fromCondition ? (
          <Field label="Taken when the condition is" htmlFor={`edge-${edge.id}-branch`}>
            <Select
              id={`edge-${edge.id}-branch`}
              value={edge.branch_label ?? ''}
              onChange={(event) => onChange({ branch_label: event.target.value || null })}
            >
              <option value="true">True</option>
              <option value="false">False</option>
              <option value="">Always</option>
            </Select>
          </Field>
        ) : (
          <Field
            label="Only follow this path when"
            htmlFor={`edge-${edge.id}-condition`}
            hint="Optional. Leave empty to always continue."
          >
            <Input
              id={`edge-${edge.id}-condition`}
              className="font-mono text-xs"
              placeholder="e.g. test_data_generator.outputs.record_count > 0"
              value={edge.condition_expression ?? ''}
              onChange={(event) => onChange({ condition_expression: event.target.value || null })}
            />
          </Field>
        )}
      </CardBody>
    </Card>
  );
}
