/** Building blocks and agents that can be dragged onto the canvas or clicked to insert. */
import { useMemo, useState, type DragEvent } from 'react';
import { Search } from 'lucide-react';
import { AgentIcon } from '@/components/AgentIcon';
import { Card, CardBody, CardHeader, Input } from '@/design-system/primitives';
import type { AgentSummary } from '@/types';
import { BLOCK_LABELS, type BlockType } from './graph';
import { NODE_STYLE } from './FlowNodeCard';

/** MIME type carrying the palette item through a drag. */
export const PALETTE_MIME = 'application/x-aiqe-flow-node';

export interface PaletteItem {
  type: 'agent' | BlockType;
  agentId?: string;
}

const BLOCKS: { type: BlockType; hint: string }[] = [
  { type: 'condition', hint: 'Branch on a result' },
  { type: 'approval', hint: 'Pause for a person' },
  { type: 'tool', hint: 'Call an MCP tool' },
  { type: 'parallel', hint: 'Fan out paths' },
  { type: 'join', hint: 'Wait for paths' },
  { type: 'end', hint: 'Finish the flow' },
];

export function NodePalette({
  agents,
  onAdd,
}: {
  agents: AgentSummary[];
  onAdd: (item: PaletteItem) => void;
}) {
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const text = query.trim().toLowerCase();
    return agents
      .filter((agent) => !text || `${agent.name} ${agent.category} ${agent.key}`.toLowerCase().includes(text))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [agents, query]);

  function startDrag(event: DragEvent, item: PaletteItem) {
    event.dataTransfer.setData(PALETTE_MIME, JSON.stringify(item));
    event.dataTransfer.effectAllowed = 'move';
  }

  return (
    <Card className="flex min-h-0 flex-col">
      <CardHeader title="Add to flow" description="Drag onto the canvas, or click to insert after the selected step" />
      <CardBody className="min-h-0 flex-1 space-y-4 overflow-y-auto p-3">
        <section>
          <p className="px-1 pb-1.5 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">Building blocks</p>
          <ul className="grid grid-cols-2 gap-1.5">
            {BLOCKS.map(({ type, hint }) => {
              const style = NODE_STYLE[type];
              const Icon = style.icon;
              return (
                <li key={type}>
                  <button
                    type="button"
                    draggable
                    onDragStart={(event) => startDrag(event, { type })}
                    onClick={() => onAdd({ type })}
                    title={hint}
                    className="flex w-full cursor-grab items-center gap-2 rounded border border-line bg-surface px-2 py-1.5 text-left text-xs font-medium text-ink transition-colors hover:border-brand-300 hover:bg-brand-50 active:cursor-grabbing"
                  >
                    <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border ${style.tone}`}>
                      <Icon className="h-3 w-3" />
                    </span>
                    <span className="truncate">{BLOCK_LABELS[type]}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        <section>
          <p className="px-1 pb-1.5 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
            Agents ({agents.length})
          </p>
          <div className="relative mb-2">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-tertiary" />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Find an agent"
              aria-label="Find an agent"
              className="h-8 pl-8 text-xs"
            />
          </div>
          <ul className="space-y-1">
            {visible.map((agent) => (
              <li key={agent.id}>
                <button
                  type="button"
                  draggable
                  onDragStart={(event) => startDrag(event, { type: 'agent', agentId: agent.id })}
                  onClick={() => onAdd({ type: 'agent', agentId: agent.id })}
                  className="flex w-full cursor-grab items-center gap-2 rounded px-2 py-1.5 text-left transition-colors hover:bg-brand-50 active:cursor-grabbing"
                >
                  <AgentIcon name={agent.icon} className="h-6 w-6 shrink-0" />
                  <span className="min-w-0">
                    <span className="block truncate text-xs font-medium text-ink">{agent.name}</span>
                    <span className="block truncate text-2xs text-ink-tertiary">
                      {agent.category}
                      {agent.is_builtin ? '' : ' · custom'}
                    </span>
                  </span>
                </button>
              </li>
            ))}
            {!visible.length ? <li className="px-2 py-3 text-xs text-ink-tertiary">No agents match.</li> : null}
          </ul>
        </section>
      </CardBody>
    </Card>
  );
}
