/**
 * Editable flow graph for the Flow Builder.
 *
 * Pure functions over a draft of nodes and edges, kept apart from React so the
 * editing rules (insertion, branching, deletion) are easy to test. The server
 * always receives the complete graph on save.
 */
import type { AgentSummary, FlowDetail, FlowNode } from '@/types';

export type DraftNode = Omit<FlowNode, 'id'>;

export interface DraftEdge {
  id: string;
  source_node_key: string;
  target_node_key: string;
  branch_label: string | null;
  condition_expression: string | null;
}

export interface FlowDraft {
  nodes: DraftNode[];
  edges: DraftEdge[];
}

export type BlockType = 'condition' | 'approval' | 'tool' | 'parallel' | 'join' | 'end';

export const BLOCK_LABELS: Record<BlockType, string> = {
  condition: 'Condition',
  approval: 'Human approval',
  tool: 'Tool call',
  parallel: 'Parallel split',
  join: 'Join',
  end: 'End',
};

/** Vertical distance between steps placed by the builder. */
export const ROW_HEIGHT = 150;

let edgeSequence = 0;
function edgeId(): string {
  edgeSequence += 1;
  return `edge-${Date.now().toString(36)}-${edgeSequence}`;
}

export function draftFromFlow(flow: FlowDetail): FlowDraft {
  return {
    nodes: flow.nodes.map((node) => ({
      node_key: node.node_key,
      node_type: node.node_type,
      label: node.label,
      agent_id: node.agent_id ?? null,
      agent_version: node.agent_version ?? null,
      position_x: node.position_x,
      position_y: node.position_y,
      sequence: node.sequence,
      config: node.config ?? {},
      input_mapping: node.input_mapping ?? {},
      output_mapping: node.output_mapping ?? {},
      condition_expression: node.condition_expression ?? null,
      llm_config: node.llm_config ?? {},
      retry_policy: node.retry_policy ?? {},
      timeout_seconds: node.timeout_seconds ?? null,
      on_failure: node.on_failure,
      requires_approval: node.requires_approval,
      approval_role: node.approval_role ?? null,
      cost_limit_usd: node.cost_limit_usd ?? null,
    })),
    edges: flow.edges.map((edge) => ({
      id: edge.id,
      source_node_key: edge.source_node_key,
      target_node_key: edge.target_node_key,
      branch_label: edge.branch_label ?? null,
      condition_expression: edge.condition_expression ?? null,
    })),
  };
}

/** The PATCH body. Sequence follows the canvas top to bottom so run steps read in order. */
export function toPayload(draft: FlowDraft) {
  const ordered = [...draft.nodes].sort((a, b) => a.position_y - b.position_y || a.position_x - b.position_x);
  return {
    nodes: ordered.map((node, index) => ({ ...node, sequence: index })),
    edges: draft.edges.map(({ source_node_key, target_node_key, branch_label, condition_expression }) => ({
      source_node_key,
      target_node_key,
      branch_label,
      condition_expression,
    })),
  };
}

/** A readable, unique node key. Keys double as variable names in conditions, so no hyphens. */
export function uniqueNodeKey(base: string, existing: Iterable<string>): string {
  const taken = new Set(existing);
  const slug =
    base
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 40) || 'step';
  if (!taken.has(slug)) return slug;
  for (let suffix = 2; ; suffix += 1) {
    const candidate = `${slug}_${suffix}`;
    if (!taken.has(candidate)) return candidate;
  }
}

export function createNode(
  draft: FlowDraft,
  type: 'agent' | BlockType,
  position: { x: number; y: number },
  agent?: AgentSummary,
): DraftNode {
  const label = type === 'agent' && agent ? agent.name : BLOCK_LABELS[type as BlockType];
  return {
    node_key: uniqueNodeKey(type === 'agent' && agent ? agent.key : label, draft.nodes.map((node) => node.node_key)),
    node_type: type,
    label,
    agent_id: agent?.id ?? null,
    agent_version: null,
    position_x: Math.round(position.x),
    position_y: Math.round(position.y),
    sequence: draft.nodes.length,
    config: type === 'approval' ? { risk_level: 'medium' } : {},
    input_mapping: {},
    output_mapping: {},
    condition_expression: null,
    llm_config: {},
    retry_policy: {},
    timeout_seconds: null,
    on_failure: 'fail_flow',
    requires_approval: type === 'agent' ? Boolean(agent?.requires_approval) : false,
    approval_role: type === 'approval' || agent?.requires_approval ? 'qe_lead' : null,
    cost_limit_usd: null,
  };
}

function isCondition(draft: FlowDraft, key: string): boolean {
  return draft.nodes.some((node) => node.node_key === key && node.node_type === 'condition');
}

/** A condition's first path is its true branch and its second the false branch. */
function nextBranchLabel(draft: FlowDraft, sourceKey: string): string | null {
  if (!isCondition(draft, sourceKey)) return null;
  const used = new Set(draft.edges.filter((edge) => edge.source_node_key === sourceKey).map((edge) => edge.branch_label));
  if (!used.has('true')) return 'true';
  if (!used.has('false')) return 'false';
  return null;
}

export function connect(draft: FlowDraft, sourceKey: string, targetKey: string): FlowDraft {
  const duplicate = draft.edges.some(
    (edge) => edge.source_node_key === sourceKey && edge.target_node_key === targetKey,
  );
  if (sourceKey === targetKey || duplicate) return draft;
  return {
    ...draft,
    edges: [
      ...draft.edges,
      {
        id: edgeId(),
        source_node_key: sourceKey,
        target_node_key: targetKey,
        branch_label: nextBranchLabel(draft, sourceKey),
        condition_expression: null,
      },
    ],
  };
}

/**
 * The step a click-to-add attaches after: the selected node, or else whatever
 * leads into the flow's end, so clicking agents in turn builds a sequence.
 */
export function insertionPoint(draft: FlowDraft, selectedKey: string | null): string | null {
  if (selectedKey && draft.nodes.some((node) => node.node_key === selectedKey && node.node_type !== 'end')) {
    return selectedKey;
  }
  const end = draft.nodes.find((node) => node.node_type === 'end');
  if (!end) return null;
  const incoming = draft.edges.filter((edge) => edge.target_node_key === end.node_key);
  return incoming.length === 1 ? incoming[0].source_node_key : null;
}

/**
 * Add a node after `afterKey`, splicing it into a single outgoing path and
 * shifting the steps below down to make room.
 */
export function insertAfter(draft: FlowDraft, node: DraftNode, afterKey: string | null): FlowDraft {
  const anchor = afterKey ? draft.nodes.find((item) => item.node_key === afterKey) : undefined;
  if (!anchor) return { ...draft, nodes: [...draft.nodes, node] };

  const placed: DraftNode = { ...node, position_x: anchor.position_x, position_y: anchor.position_y + ROW_HEIGHT };
  const nodes = [
    ...draft.nodes.map((item) =>
      item.position_y > anchor.position_y ? { ...item, position_y: item.position_y + ROW_HEIGHT } : item,
    ),
    placed,
  ];

  const outgoing = draft.edges.filter((edge) => edge.source_node_key === anchor.node_key);
  if (outgoing.length === 1 && placed.node_type !== 'end') {
    const [next] = outgoing;
    return {
      nodes,
      edges: [
        ...draft.edges.filter((edge) => edge.id !== next.id),
        { ...next, id: edgeId(), target_node_key: placed.node_key },
        {
          id: edgeId(),
          source_node_key: placed.node_key,
          target_node_key: next.target_node_key,
          branch_label: placed.node_type === 'condition' ? 'true' : null,
          condition_expression: null,
        },
      ],
    };
  }
  return connect({ nodes, edges: draft.edges }, anchor.node_key, placed.node_key);
}

/**
 * Remove nodes and their edges. A removed step with one path in and one path
 * out is bridged, so deleting from the middle of a sequence keeps it connected.
 */
export function removeNodes(draft: FlowDraft, keys: string[]): FlowDraft {
  let current = draft;
  for (const key of keys) {
    const incoming = current.edges.filter((edge) => edge.target_node_key === key);
    const outgoing = current.edges.filter((edge) => edge.source_node_key === key);
    let edges = current.edges.filter((edge) => edge.source_node_key !== key && edge.target_node_key !== key);
    if (incoming.length === 1 && outgoing.length === 1) {
      const bridge = { ...incoming[0], id: edgeId(), target_node_key: outgoing[0].target_node_key };
      const exists = edges.some(
        (edge) => edge.source_node_key === bridge.source_node_key && edge.target_node_key === bridge.target_node_key,
      );
      if (!exists && bridge.source_node_key !== bridge.target_node_key) edges = [...edges, bridge];
    }
    current = { nodes: current.nodes.filter((node) => node.node_key !== key), edges };
  }
  return current;
}

export function removeEdges(draft: FlowDraft, ids: string[]): FlowDraft {
  const doomed = new Set(ids);
  return { ...draft, edges: draft.edges.filter((edge) => !doomed.has(edge.id)) };
}

export function updateNode(draft: FlowDraft, key: string, patch: Partial<DraftNode>): FlowDraft {
  return {
    ...draft,
    nodes: draft.nodes.map((node) => (node.node_key === key ? { ...node, ...patch } : node)),
  };
}

export function updateEdge(draft: FlowDraft, id: string, patch: Partial<DraftEdge>): FlowDraft {
  return { ...draft, edges: draft.edges.map((edge) => (edge.id === id ? { ...edge, ...patch } : edge)) };
}

/**
 * Names a condition can read: flow variables plus each agent step's result,
 * addressable by node key or agent key with hyphens as underscores.
 */
export function conditionVariables(
  draft: FlowDraft,
  variables: Record<string, unknown>,
  agentsById: Map<string, AgentSummary>,
): string[] {
  const names = new Set(Object.keys(variables).filter((name) => !name.startsWith('_')));
  for (const node of draft.nodes) {
    if (node.node_type !== 'agent') continue;
    const agent = node.agent_id ? agentsById.get(node.agent_id) : undefined;
    names.add(`${(agent?.key ?? node.node_key).replace(/-/g, '_')}.outputs`);
  }
  return [...names];
}

/** Parse a mapping value typed by a user: numbers and booleans stay typed, `$refs` stay strings. */
export function parseMappingValue(raw: string): unknown {
  const text = raw.trim();
  if (text === 'true') return true;
  if (text === 'false') return false;
  if (text !== '' && /^-?\d+(\.\d+)?$/.test(text)) return Number(text);
  return raw;
}
