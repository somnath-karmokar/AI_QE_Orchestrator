/** Canvas card for one flow node. */
import { Handle, Position, type NodeProps } from 'reactflow';
import {
  CheckCircle2, CircleDot, Flag, GitBranch, GitMerge, ShieldCheck, Sparkles, Split, Wrench,
} from 'lucide-react';
import { AgentIcon } from '@/components/AgentIcon';
import { cn } from '@/design-system/primitives';
import type { AgentSummary } from '@/types';
import type { DraftNode } from './graph';

export const NODE_STYLE: Record<string, { icon: typeof CircleDot; tone: string; label: string }> = {
  start: { icon: Flag, tone: 'border-success-border bg-success-bg text-success-text', label: 'Start' },
  end: { icon: CheckCircle2, tone: 'border-line-strong bg-surface-sunken text-ink-secondary', label: 'End' },
  agent: { icon: Sparkles, tone: 'border-brand-200 bg-surface text-brand-700', label: 'Agent' },
  condition: { icon: Split, tone: 'border-warning-border bg-warning-bg text-warning-text', label: 'Condition' },
  approval: { icon: ShieldCheck, tone: 'border-info-border bg-info-bg text-info-text', label: 'Human approval' },
  tool: { icon: Wrench, tone: 'border-line-strong bg-surface text-ink', label: 'Tool call' },
  parallel: { icon: GitBranch, tone: 'border-line-strong bg-surface text-ink', label: 'Parallel split' },
  join: { icon: GitMerge, tone: 'border-line-strong bg-surface text-ink', label: 'Join' },
  loop: { icon: CircleDot, tone: 'border-line-strong bg-surface text-ink', label: 'Loop' },
};

export interface FlowNodeData {
  node: DraftNode;
  agent?: AgentSummary;
}

export function FlowNodeCard({ data, selected }: NodeProps<FlowNodeData>) {
  const { node, agent } = data;
  const style = NODE_STYLE[node.node_type] ?? NODE_STYLE.agent;
  const Icon = style.icon;
  const isTerminal = node.node_type === 'start' || node.node_type === 'end';
  const attempts = Number(node.retry_policy?.max_attempts ?? 1);
  const toolName = node.node_type === 'tool' && node.config?.tool ? `${String(node.config.server)}.${String(node.config.tool)}` : null;

  const chips = [
    node.requires_approval && node.node_type === 'agent' ? 'Approval' : null,
    agent?.risk_level && agent.risk_level !== 'low' ? `${agent.risk_level} risk` : null,
    attempts > 1 ? `${attempts} attempts` : null,
    node.timeout_seconds ? `${node.timeout_seconds}s timeout` : null,
    node.cost_limit_usd ? `≤ €${node.cost_limit_usd}` : null,
    node.on_failure !== 'fail_flow' && !isTerminal ? node.on_failure.replace(/_/g, ' ') : null,
    node.llm_config?.model ? String(node.llm_config.model) : null,
    node.agent_version ? `v${node.agent_version}` : null,
  ].filter((chip): chip is string => Boolean(chip));

  return (
    <div
      className={cn(
        'w-60 rounded-lg border-2 shadow-card transition-shadow hover:shadow-raised',
        style.tone,
        selected && 'ring-2 ring-brand-500 ring-offset-2',
      )}
    >
      {node.node_type !== 'start' ? <Handle type="target" position={Position.Top} className="!h-2.5 !w-2.5" /> : null}

      <div className="flex items-start gap-2.5 p-3">
        {node.node_type === 'agent' && agent ? (
          <AgentIcon name={agent.icon} className="h-8 w-8 shrink-0" />
        ) : (
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded border border-current/20 bg-white/60">
            <Icon className="h-4 w-4" />
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{node.label}</p>
          <p className="truncate text-2xs opacity-75">
            {node.node_type === 'agent' && !node.agent_id ? 'Agent not selected' : toolName ?? style.label}
          </p>
        </div>
      </div>

      {node.node_type === 'condition' || chips.length ? (
        <div className="flex flex-wrap gap-1 border-t border-current/15 px-3 py-1.5">
          {node.node_type === 'condition' ? (
            <span className="max-w-full truncate rounded bg-white/70 px-1.5 py-0.5 font-mono text-2xs">
              {node.condition_expression || 'no expression yet'}
            </span>
          ) : null}
          {chips.map((chip) => (
            <span key={chip} className="rounded bg-white/70 px-1.5 py-0.5 text-2xs font-medium">
              {chip}
            </span>
          ))}
        </div>
      ) : null}

      {node.node_type !== 'end' ? <Handle type="source" position={Position.Bottom} className="!h-2.5 !w-2.5" /> : null}
    </div>
  );
}
