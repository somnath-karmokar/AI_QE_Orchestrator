/** Application shell: collapsible enterprise sidebar, header, project context. */
import { Fragment, useEffect, useMemo, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Activity,
  Bell, Bot, ChevronDown, ChevronRight, CircleHelp, Database, FileSearch,
  FlaskConical, GitBranch, KeyRound, LayoutDashboard, Library, LogOut, Menu, Network, PanelLeftClose,
  PanelLeftOpen, PlayCircle, Search, Settings, Shield, ShoppingCart, Sparkles, Store,
  TrendingUp, Workflow, Wrench,
} from 'lucide-react';
import { api } from '@/services/api';
import { useCartBadge, useSession, useWorkspace } from '@/store';
import { useSystemInfo } from '@/hooks';
import { Badge, Button, cn, Select, Tooltip } from '@/design-system/primitives';
import { GlobalSearch } from '@/components/GlobalSearch';
import { Copilot } from '@/components/Copilot';

interface NavItem {
  label: string;
  to?: string;
  icon: typeof LayoutDashboard;
  permission?: string;
  badge?: 'cart';
  children?: { label: string; to: string; permission?: string }[];
}

const NAVIGATION: { section?: string; items: NavItem[] }[] = [
  {
    items: [
      { label: 'Home', to: '/', icon: LayoutDashboard },
      { label: 'Projects', to: '/projects', icon: Database, permission: 'project:read' },
    ],
  },
  {
    section: 'Agents',
    items: [
      { label: 'Agent Marketplace', to: '/marketplace', icon: Store, permission: 'agent:read' },
      { label: 'Agent Cart', to: '/cart', icon: ShoppingCart, permission: 'agent:read', badge: 'cart' },
      { label: 'Flow Studio', to: '/flows', icon: Workflow, permission: 'flow:read' },
      { label: 'My Agents', to: '/my-agents', icon: Bot, permission: 'agent:read' },
      { label: 'Runs', to: '/runs', icon: Activity, permission: 'run:read' },
    ],
  },
  {
    section: 'Test Engineering',
    items: [
      {
        label: 'Test Engineering',
        icon: FlaskConical,
        permission: 'test:read',
        children: [
          { label: 'Test Planning', to: '/testing/planning' },
          { label: 'Test Design', to: '/testing/design' },
          { label: 'Test Data', to: '/testing/data' },
          { label: 'Automation', to: '/testing/automation' },
        ],
      },
      { label: 'Execution', to: '/executions', icon: PlayCircle, permission: 'execution:read' },
    ],
  },
  {
    section: 'Quality Intelligence',
    items: [
      { label: 'Defects', to: '/quality/defects', icon: FileSearch, permission: 'defect:read' },
      { label: 'Healing', to: '/quality/healing', icon: Wrench, permission: 'execution:read' },
      { label: 'Root Cause', to: '/quality/rca', icon: Sparkles, permission: 'defect:read' },
      { label: 'Regression', to: '/quality/regression', icon: TrendingUp, permission: 'test:read' },
      { label: 'Traceability', to: '/quality/traceability', icon: Network, permission: 'test:read' },
    ],
  },
  {
    section: 'Platform',
    items: [
      { label: 'Knowledge Fabric', to: '/knowledge', icon: Library, permission: 'knowledge:read' },
      { label: 'Governance', to: '/governance', icon: Shield, permission: 'governance:read' },
      { label: 'Integrations', to: '/integrations', icon: GitBranch, permission: 'project:read' },
      { label: 'Data Sources', to: '/data-sources', icon: Database, permission: 'project:read' },
      { label: 'API Access', to: '/api-access', icon: KeyRound, permission: 'project:read' },
      { label: 'Settings', to: '/settings', icon: Settings },
    ],
  },
];

export function AppShell() {
  const { user, signOut, can } = useSession();
  const { projectId, project, setProject, environments, setEnvironments, environmentId, setEnvironmentId, sidebarCollapsed, toggleSidebar } =
    useWorkspace();
  const cartCount = useCartBadge((state) => state.count);
  const setCartCount = useCartBadge((state) => state.setCount);
  const navigate = useNavigate();
  const location = useLocation();
  const { data: systemInfo } = useSystemInfo();

  const [searchOpen, setSearchOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const { data: projects } = useQuery({ queryKey: ['projects'], queryFn: api.listProjects });
  const { data: projectDetail } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => api.getProject(projectId!),
    enabled: Boolean(projectId),
  });
  const { data: cart } = useQuery({
    queryKey: ['cart', projectId],
    queryFn: () => api.getCart(projectId!),
    enabled: Boolean(projectId) && can('agent:read'),
  });
  const { data: approvals } = useQuery({
    queryKey: ['approvals', projectId, 'pending'],
    queryFn: () => api.listApprovals({ project_id: projectId!, status: 'pending', limit: 20 }),
    enabled: Boolean(projectId) && can('governance:read'),
    refetchInterval: 30000,
  });

  // Default to the first project so the app is never in a contextless state.
  useEffect(() => {
    if (!projectId && projects?.items.length) setProject(projects.items[0]);
    else if (projectId && projects?.items.length && !project) {
      const match = projects.items.find((item) => item.id === projectId);
      if (match) setProject(match);
      else setProject(projects.items[0]);
    }
  }, [projects, projectId, project, setProject]);

  useEffect(() => {
    if (projectDetail?.environments) setEnvironments(projectDetail.environments);
  }, [projectDetail, setEnvironments]);

  useEffect(() => {
    if (cart) setCartCount(cart.length);
  }, [cart, setCartCount]);

  useEffect(() => setMobileNavOpen(false), [location.pathname]);

  // Cmd/Ctrl+K opens global search, a convention users expect.
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen(true);
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'j') {
        event.preventDefault();
        setCopilotOpen((open) => !open);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const pendingApprovals = approvals?.total ?? 0;

  return (
    <div className="flex min-h-screen bg-surface-muted">
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>

      <Sidebar
        collapsed={sidebarCollapsed}
        mobileOpen={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        cartCount={cartCount}
        can={can}
      />

      <div className={cn('flex min-w-0 flex-1 flex-col transition-[margin] duration-200 print:ml-0', sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64')}>
        <header className="sticky top-0 z-30 border-b border-line bg-surface/95 backdrop-blur print:hidden">
          <div className="flex h-14 items-center gap-3 px-4 lg:px-6">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileNavOpen(true)}
              aria-label="Open navigation"
            >
              <Menu className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="hidden lg:inline-flex"
              onClick={toggleSidebar}
              aria-label={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              {sidebarCollapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
            </Button>

            {/* Project and environment context applies to every screen. */}
            <div className="flex min-w-0 items-center gap-2">
              <Select
                aria-label="Select project"
                className="h-8 w-48 text-sm sm:w-64"
                value={projectId ?? ''}
                onChange={(event) => {
                  const next = projects?.items.find((item) => item.id === event.target.value);
                  if (next) setProject(next);
                }}
              >
                {projects?.items.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.key} · {item.name}
                  </option>
                ))}
              </Select>
              <Select
                aria-label="Select environment"
                className="hidden h-8 w-40 text-sm sm:block"
                value={environmentId ?? ''}
                onChange={(event) => setEnvironmentId(event.target.value || null)}
                disabled={!environments.length}
              >
                {/* Environments load with the project; say so rather than
                    rendering an empty control. */}
                {environments.length ? (
                  environments.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))
                ) : (
                  <option value="">Loading environments…</option>
                )}
              </Select>
            </div>

            <div className="flex-1" />

            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="hidden items-center gap-2 rounded border border-line-strong bg-surface-muted px-3 py-1.5
                         text-sm text-ink-tertiary transition-colors hover:border-ink-tertiary hover:text-ink-secondary md:flex"
            >
              <Search className="h-3.5 w-3.5" />
              <span>Search</span>
              <kbd className="ml-4 rounded border border-line bg-surface px-1.5 py-0.5 font-mono text-2xs text-ink-tertiary">
                ⌘K
              </kbd>
            </button>

            <button
              type="button"
              onClick={() => setCopilotOpen(true)}
              className="inline-flex h-8 items-center gap-1.5 rounded border border-brand-200 bg-brand-50 px-2.5
                         text-xs font-medium text-brand-700 transition-colors hover:bg-brand-100"
              aria-label="Open the QE Copilot"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Ask Copilot</span>
              <kbd className="ml-1 hidden rounded border border-brand-200 bg-surface px-1 font-mono text-[10px] lg:inline">
                ⌘J
              </kbd>
            </button>

            {systemInfo?.demo_mode ? (
              <Tooltip label="Synthetic data; no external systems are contacted">
                <Badge tone="info" dot>
                  Demo Mode
                </Badge>
              </Tooltip>
            ) : null}

            <Tooltip label={`${pendingApprovals} pending approval${pendingApprovals === 1 ? '' : 's'}`}>
              <button
                type="button"
                onClick={() => navigate('/governance?tab=approvals')}
                className="relative rounded p-2 text-ink-secondary transition-colors hover:bg-surface-sunken hover:text-ink"
                aria-label={`Notifications, ${pendingApprovals} pending approvals`}
              >
                <Bell className="h-4 w-4" />
                {pendingApprovals > 0 ? (
                  <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-semibold text-white">
                    {pendingApprovals > 9 ? '9+' : pendingApprovals}
                  </span>
                ) : null}
              </button>
            </Tooltip>

            <Tooltip label="Documentation">
              <a
                href="/api/docs"
                target="_blank"
                rel="noreferrer"
                className="rounded p-2 text-ink-secondary transition-colors hover:bg-surface-sunken hover:text-ink"
                aria-label="API documentation"
              >
                <CircleHelp className="h-4 w-4" />
              </a>
            </Tooltip>

            <div className="relative">
              <button
                type="button"
                onClick={() => setUserMenuOpen((open) => !open)}
                className="flex items-center gap-2 rounded px-1.5 py-1 transition-colors hover:bg-surface-sunken"
                aria-haspopup="menu"
                aria-expanded={userMenuOpen}
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-navy-700 text-2xs font-semibold text-ink-inverse">
                  {user?.avatar_initials ?? user?.full_name?.slice(0, 2).toUpperCase()}
                </span>
                <ChevronDown className="hidden h-3 w-3 text-ink-tertiary sm:block" />
              </button>
              {userMenuOpen ? (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} aria-hidden />
                  <div
                    role="menu"
                    className="absolute right-0 z-50 mt-2 w-60 animate-slide-up rounded-lg border border-line bg-surface p-1 shadow-popover"
                  >
                    <div className="border-b border-line px-3 py-2.5">
                      <p className="truncate text-sm font-semibold text-ink">{user?.full_name}</p>
                      <p className="truncate text-xs text-ink-secondary">{user?.email}</p>
                      <Badge tone="brand" className="mt-1.5">
                        {user?.job_title ?? user?.role_key}
                      </Badge>
                    </div>
                    <button
                      role="menuitem"
                      onClick={() => {
                        setUserMenuOpen(false);
                        navigate('/settings');
                      }}
                      className="flex w-full items-center gap-2 rounded px-3 py-2 text-left text-sm text-ink-secondary hover:bg-surface-muted hover:text-ink"
                    >
                      <Settings className="h-3.5 w-3.5" /> Settings
                    </button>
                    <button
                      role="menuitem"
                      onClick={() => {
                        signOut();
                        navigate('/login');
                      }}
                      className="flex w-full items-center gap-2 rounded px-3 py-2 text-left text-sm text-danger-text hover:bg-danger-bg"
                    >
                      <LogOut className="h-3.5 w-3.5" /> Sign out
                    </button>
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </header>

        <main id="main-content" className="flex-1 px-4 py-6 lg:px-8 lg:py-8 print:p-0">
          <Outlet />
        </main>
      </div>

      <GlobalSearch open={searchOpen} onClose={() => setSearchOpen(false)} />
      <Copilot open={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}

function Sidebar({
  collapsed,
  mobileOpen,
  onCloseMobile,
  cartCount,
  can,
}: {
  collapsed: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  cartCount: number;
  can: (permission: string) => boolean;
}) {
  const location = useLocation();
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  // Keep a group open when the current route lives inside it.
  const activeGroups = useMemo(() => {
    const result: Record<string, boolean> = {};
    for (const group of NAVIGATION) {
      for (const item of group.items) {
        if (item.children?.some((child) => location.pathname.startsWith(child.to))) {
          result[item.label] = true;
        }
      }
    }
    return result;
  }, [location.pathname]);

  return (
    <>
      {mobileOpen ? (
        <div className="fixed inset-0 z-40 bg-navy-900/40 lg:hidden" onClick={onCloseMobile} aria-hidden />
      ) : null}

      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex flex-col border-r border-navy-800 bg-navy-700 transition-all duration-200 print:hidden',
          collapsed ? 'w-16' : 'w-64',
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
        )}
        aria-label="Main navigation"
      >
        <div className={cn('flex h-14 shrink-0 items-center border-b border-navy-800', collapsed ? 'justify-center px-2' : 'gap-2.5 px-4')}>
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded bg-brand-500">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          {!collapsed ? (
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-white">AI QE Orchestrator</p>
              <p className="truncate text-2xs text-navy-200">Continuous quality</p>
            </div>
          ) : null}
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto px-2 py-4">
          {NAVIGATION.map((group, groupIndex) => {
            const visible = group.items.filter((item) => !item.permission || can(item.permission));
            if (!visible.length) return null;
            return (
              <div key={group.section ?? groupIndex}>
                {group.section && !collapsed ? (
                  <p className="mb-1.5 px-3 text-2xs font-semibold uppercase tracking-wider text-navy-300">
                    {group.section}
                  </p>
                ) : null}
                <ul className="space-y-0.5">
                  {visible.map((item) => {
                    const Icon = item.icon;
                    if (item.children) {
                      const isOpen = expanded[item.label] ?? activeGroups[item.label] ?? false;
                      if (collapsed) {
                        return (
                          <li key={item.label}>
                            <Tooltip label={item.label}>
                              <NavLink
                                to={item.children[0].to}
                                className={({ isActive }) =>
                                  cn(
                                    'flex h-9 w-full items-center justify-center rounded text-navy-100 transition-colors hover:bg-navy-600',
                                    isActive && 'bg-navy-600 text-white',
                                  )
                                }
                              >
                                <Icon className="h-4 w-4" />
                              </NavLink>
                            </Tooltip>
                          </li>
                        );
                      }
                      return (
                        <li key={item.label}>
                          <button
                            type="button"
                            onClick={() => setExpanded((state) => ({ ...state, [item.label]: !isOpen }))}
                            aria-expanded={isOpen}
                            className="flex w-full items-center gap-2.5 rounded px-3 py-2 text-sm text-navy-100 transition-colors hover:bg-navy-600 hover:text-white"
                          >
                            <Icon className="h-4 w-4 shrink-0" />
                            <span className="flex-1 text-left">{item.label}</span>
                            <ChevronRight className={cn('h-3 w-3 transition-transform', isOpen && 'rotate-90')} />
                          </button>
                          {isOpen ? (
                            <ul className="ml-4 mt-0.5 space-y-0.5 border-l border-navy-600 pl-3">
                              {item.children.map((child) => (
                                <li key={child.to}>
                                  <NavLink
                                    to={child.to}
                                    className={({ isActive }) =>
                                      cn(
                                        'block rounded px-3 py-1.5 text-sm text-navy-200 transition-colors hover:bg-navy-600 hover:text-white',
                                        isActive && 'bg-navy-600 font-medium text-white',
                                      )
                                    }
                                  >
                                    {child.label}
                                  </NavLink>
                                </li>
                              ))}
                            </ul>
                          ) : null}
                        </li>
                      );
                    }

                    const link = (
                      <NavLink
                        to={item.to!}
                        end={item.to === '/'}
                        className={({ isActive }) =>
                          cn(
                            'flex items-center rounded text-sm text-navy-100 transition-colors hover:bg-navy-600 hover:text-white',
                            collapsed ? 'h-9 justify-center' : 'gap-2.5 px-3 py-2',
                            isActive && 'bg-navy-600 font-medium text-white',
                          )
                        }
                      >
                        <Icon className="h-4 w-4 shrink-0" />
                        {!collapsed ? <span className="flex-1">{item.label}</span> : null}
                        {!collapsed && item.badge === 'cart' && cartCount > 0 ? (
                          <span className="rounded-full bg-brand-500 px-1.5 py-0.5 text-2xs font-semibold text-white">
                            {cartCount}
                          </span>
                        ) : null}
                      </NavLink>
                    );

                    return (
                      <li key={item.to}>
                        {collapsed ? <Tooltip label={item.label}>{link}</Tooltip> : link}
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </nav>

        {!collapsed ? (
          <div className="shrink-0 border-t border-navy-800 px-4 py-3">
            <p className="text-2xs text-navy-300">Intelligent agents.</p>
            <p className="text-2xs text-navy-300">Governed orchestration.</p>
          </div>
        ) : null}
      </aside>
    </>
  );
}

export { Fragment };
