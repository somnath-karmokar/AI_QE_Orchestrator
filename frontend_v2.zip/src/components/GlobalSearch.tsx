/** Command palette: semantic search across the Knowledge Fabric plus quick navigation. */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Bot, FileSearch, Library, Loader2, PlayCircle, Search, Workflow, X } from 'lucide-react';
import { api } from '@/services/api';
import { useDebounced, useProjectId } from '@/hooks';
import { Badge, cn } from '@/design-system/primitives';

const QUICK_LINKS = [
  { label: 'Agent Marketplace', to: '/marketplace', icon: Bot },
  { label: 'Flow Studio', to: '/flows', icon: Workflow },
  { label: 'Execution Center', to: '/executions', icon: PlayCircle },
  { label: 'Defects', to: '/quality/defects', icon: FileSearch },
  { label: 'Knowledge Fabric', to: '/knowledge', icon: Library },
];

export function GlobalSearch({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [term, setTerm] = useState('');
  const debounced = useDebounced(term, 350);
  const projectId = useProjectId();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setTerm('');
      // Autofocus after the dialog paints, so the caret lands in the field.
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [open]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && open) onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  const { data: hits, isFetching } = useQuery({
    queryKey: ['global-search', projectId, debounced],
    queryFn: () => api.knowledgeSearch(projectId!, { query: debounced, limit: 6 }),
    enabled: open && Boolean(projectId) && debounced.trim().length > 2,
  });

  const links = useMemo(
    () =>
      QUICK_LINKS.filter((link) =>
        term.trim() ? link.label.toLowerCase().includes(term.trim().toLowerCase()) : true,
      ),
    [term],
  );

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center bg-navy-900/30 px-4 pt-[10vh]"
      role="dialog"
      aria-modal="true"
      aria-label="Global search"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl animate-slide-up overflow-hidden rounded-lg border border-line bg-surface shadow-popover"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-line px-4">
          <Search className="h-4 w-4 shrink-0 text-ink-tertiary" aria-hidden />
          <input
            ref={inputRef}
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            placeholder="Search knowledge, or jump to a screen…"
            aria-label="Search"
            className="h-12 flex-1 border-0 bg-transparent text-md text-ink outline-none placeholder:text-ink-tertiary"
          />
          {isFetching ? <Loader2 className="h-4 w-4 animate-spin text-ink-tertiary" aria-hidden /> : null}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close search"
            className="rounded p-1 text-ink-tertiary hover:bg-surface-sunken hover:text-ink"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[55vh] overflow-y-auto p-2">
          {links.length ? (
            <section aria-label="Navigation">
              <p className="px-2 py-1.5 text-2xs font-semibold uppercase tracking-wider text-ink-tertiary">
                Navigate
              </p>
              {links.map((link) => {
                const Icon = link.icon;
                return (
                  <button
                    key={link.to}
                    onClick={() => {
                      navigate(link.to);
                      onClose();
                    }}
                    className="flex w-full items-center gap-2.5 rounded px-2 py-2 text-left text-sm text-ink-secondary hover:bg-surface-muted hover:text-ink"
                  >
                    <Icon className="h-3.5 w-3.5 text-ink-tertiary" />
                    {link.label}
                  </button>
                );
              })}
            </section>
          ) : null}

          {hits?.length ? (
            <section aria-label="Knowledge results" className="mt-2">
              <p className="px-2 py-1.5 text-2xs font-semibold uppercase tracking-wider text-ink-tertiary">
                Knowledge Fabric
              </p>
              {hits.map((hit) => (
                <button
                  key={hit.id}
                  onClick={() => {
                    const documentId = hit.metadata.document_id as string | undefined;
                    navigate(documentId ? `/knowledge?document=${documentId}` : '/knowledge');
                    onClose();
                  }}
                  className="flex w-full flex-col gap-1 rounded px-2 py-2 text-left hover:bg-surface-muted"
                >
                  <span className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium text-ink">
                      {(hit.metadata.title as string) ?? 'Knowledge item'}
                    </span>
                    <Badge tone="neutral" className="shrink-0">
                      {String(hit.metadata.source_type ?? 'document')}
                    </Badge>
                    <span className={cn('shrink-0 font-mono text-2xs', hit.score > 0.7 ? 'text-success-text' : 'text-ink-tertiary')}>
                      {(hit.score * 100).toFixed(0)}%
                    </span>
                  </span>
                  <span className="line-clamp-2 text-xs text-ink-secondary">{hit.content.slice(0, 180)}</span>
                </button>
              ))}
            </section>
          ) : null}

          {debounced.trim().length > 2 && !isFetching && !hits?.length ? (
            <p className="px-3 py-8 text-center text-sm text-ink-secondary">
              No knowledge matches “{debounced}”.
            </p>
          ) : null}
        </div>

        <div className="flex items-center justify-between border-t border-line bg-surface-muted px-4 py-2 text-2xs text-ink-tertiary">
          <span>Semantic search over the project's indexed knowledge</span>
          <span>
            <kbd className="rounded border border-line bg-surface px-1 py-0.5 font-mono">Esc</kbd> to close
          </span>
        </div>
      </div>
    </div>
  );
}
