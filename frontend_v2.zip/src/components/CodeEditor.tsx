/**
 * Monaco code viewer.
 *
 * `@monaco-editor/react` fetches Monaco from a CDN by default, which leaves the
 * editor stuck on "Loading…" on an offline or locked-down network. Monaco is
 * bundled with the app instead, with only the grammars the platform generates.
 */
import Editor, { loader, type EditorProps } from '@monaco-editor/react';
import * as monaco from 'monaco-editor/esm/vs/editor/editor.api';
import 'monaco-editor/esm/vs/basic-languages/python/python.contribution';
import 'monaco-editor/esm/vs/basic-languages/javascript/javascript.contribution';
import EditorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker';

self.MonacoEnvironment = { getWorker: () => new EditorWorker() };
loader.config({ monaco });

export function CodeEditor(props: EditorProps) {
  return <Editor {...props} />;
}
