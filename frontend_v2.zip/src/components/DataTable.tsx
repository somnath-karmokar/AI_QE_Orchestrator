/** Accessible, reusable data table with loading, empty and error states. */
import type { ReactNode } from 'react';
import { cn, EmptyState, LoadingBlock } from '@/design-system/primitives';

export interface Column<T> {
  key: string;
  header: string;
  /** Renders the cell. Keep it pure -- it runs on every render. */
  render: (row: T) => ReactNode;
  className?: string;
  headerClassName?: string;
  numeric?: boolean;
}

export function DataTable<T>({
  columns,
  rows,
  keyOf,
  loading,
  emptyTitle = 'Nothing to show',
  emptyDescription,
  emptyIcon,
  emptyAction,
  onRowClick,
  caption,
  minWidth = 720,
}: {
  columns: Column<T>[];
  rows: T[];
  keyOf: (row: T) => string;
  loading?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  emptyIcon?: ReactNode;
  emptyAction?: ReactNode;
  onRowClick?: (row: T) => void;
  caption?: string;
  minWidth?: number;
}) {
  if (loading) return <LoadingBlock rows={6} />;

  if (!rows.length) {
    return (
      <EmptyState
        icon={emptyIcon}
        title={emptyTitle}
        description={emptyDescription}
        action={emptyAction}
      />
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" style={{ minWidth }}>
        {caption ? <caption className="sr-only">{caption}</caption> : null}
        <thead>
          <tr className="border-b border-line bg-surface-muted text-left">
            {columns.map((column) => (
              <th
                key={column.key}
                scope="col"
                className={cn(
                  'px-5 py-2.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary',
                  column.numeric && 'text-right',
                  column.headerClassName,
                )}
              >
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={keyOf(row)}
              className={cn('data-grid-row', onRowClick && 'cursor-pointer')}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              // Rows that act as links must be reachable by keyboard.
              tabIndex={onRowClick ? 0 : undefined}
              onKeyDown={
                onRowClick
                  ? (event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        onRowClick(row);
                      }
                    }
                  : undefined
              }
            >
              {columns.map((column) => (
                <td
                  key={column.key}
                  className={cn('px-5 py-3 align-middle', column.numeric && 'tabular text-right', column.className)}
                >
                  {column.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
