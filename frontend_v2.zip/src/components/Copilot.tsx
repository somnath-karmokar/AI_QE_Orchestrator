/**
 * Conversational copilot panel.
 *
 * A single natural-language surface over the whole platform. The user states
 * what they want; the planner resolves intent, picks the right specialist
 * agent(s) and runs them through the same governed path the Flow Builder uses.
 *
 * The panel deliberately shows *how* the request was routed — intent,
 * confidence, which agents were considered and why one won — so the system
 * stays inspectable rather than feeling like a black box.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ArrowRight, Bot, ChevronDown, Loader2, Mic, MicOff, Plus, Send, Sparkles,
  ThumbsDown, ThumbsUp, Volume2, VolumeX, X,
} from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { formatCurrency } from '@/hooks';
import { useSpeechInput, useSpeechOutput } from '@/hooks/useVoice';
import { useWorkspace } from '@/store';
import { AgentIcon } from '@/components/AgentIcon';
import { Badge, Button, cn, Tooltip } from '@/design-system/primitives';
import type { CopilotFact, CopilotMessage } from '@/types';

const PLAN_LABEL: Record<string, string> = {
  run_agent: 'Agent run',
  run_flow: 'Workflow run',
  answer: 'Answered from knowledge',
  clarify: 'Needs detail',
  navigate: 'Navigation',
  refused: 'Blocked',
};

/** Flow questions are answered from recorded runs, not from the knowledge base. */
function planLabel(message: CopilotMessage): string {
  if (message.plan_kind === 'answer' && message.intent?.startsWith('flow_')) return 'Answered from flow records';
  return PLAN_LABEL[message.plan_kind ?? ''] ?? message.plan_kind ?? '';
}

const PLAN_TONE: Record<string, 'brand' | 'success' | 'warning' | 'danger' | 'info' | 'neutral'> = {
  run_agent: 'brand',
  run_flow: 'brand',
  answer: 'info',
  clarify: 'warning',
  navigate: 'neutral',
  refused: 'danger',
};

export function Copilot({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { projectId, environmentId } = useWorkspace();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [conversationId, setConversationId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<CopilotMessage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [expandedPlan, setExpandedPlan] = useState<string | null>(null);
  const [pendingVoice, setPendingVoice] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const speech = useSpeechOutput();

  const { data: capabilities } = useQuery({
    queryKey: ['copilot-capabilities', projectId],
    queryFn: () => api.copilotCapabilities(projectId!),
    enabled: Boolean(projectId) && open,
  });

  const send = useMutation({
    mutationFn: (payload: { message: string; isVoice: boolean }) =>
      api.copilotMessage({
        project_id: projectId!,
        message: payload.message,
        conversation_id: conversationId ?? undefined,
        environment_id: environmentId ?? undefined,
        is_voice: payload.isVoice,
      }),
    onSuccess: (response, variables) => {
      setConversationId(response.conversation_id);
      setMessages((current) => [...current, response.message]);
      setError(null);

      // Speak the reply when voice output is on, or when the turn was spoken.
      if (speech.enabled || variables.isVoice) speech.speak(response.message.content);

      // Anything that ran touches platform state the rest of the UI shows.
      void queryClient.invalidateQueries({ queryKey: ['runs'] });
      void queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      void queryClient.invalidateQueries({ queryKey: ['approvals', projectId, 'pending'] });
    },
    onError: (caught) =>
      setError(caught instanceof ApiError ? caught.message : 'The copilot could not respond.'),
  });

  const submit = (text: string, isVoice = false) => {
    const trimmed = text.trim();
    if (!trimmed || send.isPending) return;
    setMessages((current) => [
      ...current,
      { id: `local-${Date.now()}`, role: 'user', content: trimmed, sequence: current.length, is_voice: isVoice } as CopilotMessage,
    ]);
    setDraft('');
    send.mutate({ message: trimmed, isVoice });
  };

  // Dictation: a finished utterance submits straight away, which is what makes
  // hands-free use actually hands-free.
  const dictation = useSpeechInput({
    onFinal: (text) => {
      setPendingVoice(false);
      submit(text, true);
    },
  });

  useEffect(() => {
    if (open) requestAnimationFrame(() => inputRef.current?.focus());
    else speech.cancel();
  }, [open, speech]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, send.isPending]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && open) onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  const startNew = () => {
    setConversationId(null);
    setMessages([]);
    setError(null);
    speech.cancel();
    inputRef.current?.focus();
  };

  const toggleMic = () => {
    if (dictation.listening) {
      dictation.stop();
      setPendingVoice(false);
    } else {
      setPendingVoice(true);
      dictation.start();
    }
  };

  const starters = capabilities?.starters ?? [];

  if (!open) return null;

  return (
    <>
      <div className="fixed inset-0 z-40 bg-navy-900/20" onClick={onClose} aria-hidden />
      <aside
        className="fixed right-0 top-0 z-50 flex h-full w-full flex-col border-l border-line bg-surface shadow-popover sm:w-[520px]"
        role="dialog"
        aria-modal="true"
        aria-label="QE Copilot"
      >
        {/* ---- header ---- */}
        <header className="flex shrink-0 items-center gap-3 border-b border-line px-4 py-3">
          <div className="flex h-8 w-8 items-center justify-center rounded bg-brand-500">
            <Sparkles className="h-4 w-4 text-white" aria-hidden />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-sm font-semibold text-ink">QE Copilot</h2>
            <p className="truncate text-2xs text-ink-tertiary">
              Ask in plain language — the right agents are selected for you
            </p>
          </div>

          {speech.supported ? (
            <Tooltip label={speech.enabled ? 'Turn off spoken replies' : 'Speak replies aloud'}>
              <button
                type="button"
                onClick={() => speech.setEnabled(!speech.enabled)}
                aria-pressed={speech.enabled}
                aria-label={speech.enabled ? 'Turn off spoken replies' : 'Speak replies aloud'}
                className={cn(
                  'rounded p-2 transition-colors',
                  speech.enabled ? 'bg-brand-50 text-brand-600' : 'text-ink-tertiary hover:bg-surface-sunken hover:text-ink',
                )}
              >
                {speech.enabled ? <Volume2 className={cn('h-4 w-4', speech.speaking && 'animate-pulse')} /> : <VolumeX className="h-4 w-4" />}
              </button>
            </Tooltip>
          ) : null}

          <Tooltip label="New conversation">
            <button
              type="button"
              onClick={startNew}
              aria-label="Start a new conversation"
              className="rounded p-2 text-ink-tertiary transition-colors hover:bg-surface-sunken hover:text-ink"
            >
              <Plus className="h-4 w-4" />
            </button>
          </Tooltip>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close copilot"
            className="rounded p-2 text-ink-tertiary transition-colors hover:bg-surface-sunken hover:text-ink"
          >
            <X className="h-4 w-4" />
          </button>
        </header>

        {/* ---- transcript ---- */}
        <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
          {!messages.length ? (
            <div className="pt-2">
              <div className="mb-5 rounded-lg border border-brand-100 bg-brand-50 p-4">
                <p className="text-sm font-semibold text-brand-800">What would you like to do?</p>
                <p className="mt-1 text-xs leading-relaxed text-ink-secondary">
                  Describe the outcome you want. The copilot works out which of the{' '}
                  {capabilities?.intents.length ?? 14} capabilities applies, picks the right specialist
                  agent, and runs it under the same governance as everything else.
                </p>
              </div>

              <p className="mb-2 text-2xs font-semibold uppercase tracking-wider text-ink-tertiary">
                Try one of these
              </p>
              <div className="space-y-1.5">
                {starters.map((starter) => (
                  <button
                    key={starter.prompt}
                    type="button"
                    onClick={() => submit(starter.prompt)}
                    className="group flex w-full items-center gap-2.5 rounded border border-line bg-surface px-3 py-2.5
                               text-left transition-colors hover:border-brand-200 hover:bg-brand-50"
                  >
                    <span className="min-w-0 flex-1">
                      <span className="block text-2xs font-medium uppercase tracking-wide text-ink-tertiary">
                        {starter.label}
                      </span>
                      <span className="block truncate text-sm text-ink">{starter.prompt}</span>
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 shrink-0 text-ink-tertiary transition-colors group-hover:text-brand-600" />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((message) =>
              message.role === 'user' ? (
                <UserBubble key={message.id} message={message} />
              ) : (
                <AssistantBubble
                  key={message.id}
                  message={message}
                  expanded={expandedPlan === message.id}
                  onToggle={() => setExpandedPlan(expandedPlan === message.id ? null : message.id)}
                  onNavigate={(route) => {
                    navigate(route);
                    onClose();
                  }}
                  onSuggestion={(text) => submit(text)}
                  onSpeak={() => speech.speak(message.content)}
                  speakSupported={speech.supported}
                />
              ),
            )
          )}

          {send.isPending ? (
            <div className="flex items-center gap-2.5 rounded-lg border border-line bg-surface-muted px-3.5 py-3">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-brand-500" aria-hidden />
              <span className="text-sm text-ink-secondary">
                Working out which agent to use, then running it…
              </span>
            </div>
          ) : null}

          {error ? (
            <div role="alert" className="rounded-lg border border-danger-border bg-danger-bg px-3.5 py-2.5">
              <p className="text-sm text-danger-text">{error}</p>
            </div>
          ) : null}

          {dictation.error ? (
            <div role="alert" className="rounded-lg border border-warning-border bg-warning-bg px-3.5 py-2.5">
              <p className="text-sm text-warning-text">{dictation.error}</p>
            </div>
          ) : null}
        </div>

        {/* ---- composer ---- */}
        <div className="shrink-0 border-t border-line p-3">
          {dictation.listening ? (
            <div className="mb-2 flex items-center gap-2.5 rounded border border-brand-200 bg-brand-50 px-3 py-2">
              <span className="relative flex h-2.5 w-2.5 shrink-0" aria-hidden>
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-brand-500" />
              </span>
              <span className="min-w-0 flex-1 truncate text-sm text-brand-800">
                {dictation.interim || 'Listening…'}
              </span>
              <button
                type="button"
                onClick={toggleMic}
                className="shrink-0 text-xs font-medium text-brand-700 hover:text-brand-800"
              >
                Stop
              </button>
            </div>
          ) : null}

          <form
            className="flex items-end gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              submit(draft);
            }}
          >
            <textarea
              ref={inputRef}
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                // Enter sends; Shift+Enter adds a newline.
                if (event.key === 'Enter' && !event.shiftKey) {
                  event.preventDefault();
                  submit(draft);
                }
              }}
              rows={1}
              placeholder={pendingVoice ? 'Listening…' : 'Ask anything, or describe what you want done…'}
              aria-label="Message the copilot"
              disabled={send.isPending}
              className="max-h-32 min-h-[38px] flex-1 resize-y rounded border border-line-strong bg-surface px-3 py-2
                         text-base text-ink placeholder:text-ink-tertiary transition-colors
                         hover:border-ink-tertiary focus:border-brand-500 disabled:bg-surface-sunken"
            />

            {dictation.supported ? (
              <Tooltip label={dictation.listening ? 'Stop listening' : 'Speak your request'}>
                <button
                  type="button"
                  onClick={toggleMic}
                  disabled={send.isPending}
                  aria-pressed={dictation.listening}
                  aria-label={dictation.listening ? 'Stop listening' : 'Speak your request'}
                  className={cn(
                    'flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded border transition-colors',
                    dictation.listening
                      ? 'border-brand-500 bg-brand-500 text-white'
                      : 'border-line-strong bg-surface text-ink-secondary hover:bg-surface-muted',
                  )}
                >
                  {dictation.listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </button>
              </Tooltip>
            ) : null}

            <Button
              type="submit"
              variant="primary"
              className="h-[38px] w-[38px] shrink-0 p-0"
              disabled={!draft.trim() || send.isPending}
              aria-label="Send message"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>

          <p className="mt-1.5 text-center text-2xs text-ink-tertiary">
            {dictation.supported
              ? 'Every action runs under the same governance, budgets and audit as the rest of the platform.'
              : 'Voice input needs a Chromium-based browser. Typing works everywhere.'}
          </p>
        </div>
      </aside>
    </>
  );
}

/* -------------------------------------------------------------------------- */

function UserBubble({ message }: { message: CopilotMessage }) {
  return (
    <div className="flex justify-end">
      <div className="max-w-[85%] rounded-lg rounded-br-sm bg-navy-700 px-3.5 py-2.5">
        <p className="whitespace-pre-wrap text-sm text-white">{message.content}</p>
        {message.is_voice ? (
          <p className="mt-1 flex items-center justify-end gap-1 text-2xs text-navy-200">
            <Mic className="h-2.5 w-2.5" aria-hidden /> spoken
          </p>
        ) : null}
      </div>
    </div>
  );
}

function AssistantBubble({
  message,
  expanded,
  onToggle,
  onNavigate,
  onSuggestion,
  onSpeak,
  speakSupported,
}: {
  message: CopilotMessage;
  expanded: boolean;
  onToggle: () => void;
  onNavigate: (route: string) => void;
  onSuggestion: (text: string) => void;
  onSpeak: () => void;
  speakSupported: boolean;
}) {
  const selected = message.selected_agents ?? [];
  const considered = message.considered_agents ?? [];
  const entities = message.extracted_entities ?? {};

  // The run already has its own button; a navigation entry pointing at the same
  // run would render a duplicate control.
  const navigationRoute = useMemo(() => {
    const route = message.navigation?.route as string | undefined;
    if (!route) return null;
    if (message.run_id && route === `/runs/${message.run_id}`) return null;
    return route;
  }, [message.navigation, message.run_id]);

  // Figures an answer was built from are shown as chips; the rest are citations.
  const facts = useMemo(
    () =>
      (message.evidence ?? [])
        .map((item) => item as CopilotFact)
        .filter((item) => item.type === 'metric' && item.label && item.value),
    [message.evidence],
  );

  // Several retrieved chunks commonly come from one document; show each source once.
  const sources = useMemo(() => {
    const seen = new Set<string>();
    const names: string[] = [];
    for (const item of message.evidence ?? []) {
      const record = item as Record<string, unknown>;
      if (record.type === 'metric') continue;
      const name = String(record.title ?? record.detail ?? '').trim();
      if (!name || seen.has(name)) continue;
      seen.add(name);
      names.push(name);
    }
    return names;
  }, [message.evidence]);

  const entityChips = useMemo(
    () =>
      Object.entries(entities)
        .filter(([key]) => !key.endsWith('_id') && key !== 'unresolved')
        .map(([key, value]) => `${key.replace(/_/g, ' ')}: ${Array.isArray(value) ? value.join(', ') : String(value)}`),
    [entities],
  );

  return (
    <div className="space-y-2">
      <div className="flex gap-2.5">
        <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded bg-brand-50 text-brand-600">
          <Sparkles className="h-3.5 w-3.5" aria-hidden />
        </div>

        <div className="min-w-0 flex-1">
          {/* How the request was routed */}
          {message.plan_kind ? (
            <div className="mb-1.5 flex flex-wrap items-center gap-1.5">
              <Badge tone={PLAN_TONE[message.plan_kind] ?? 'neutral'}>
                {planLabel(message)}
              </Badge>
              {selected.map((agent) => (
                <Badge key={agent.agent_key} tone="neutral">
                  <AgentIcon name="Bot" className="h-3 w-3 border-0 bg-transparent p-0" />
                  {agent.name}
                </Badge>
              ))}
              {message.intent_confidence !== null && message.intent_confidence !== undefined ? (
                <span className="tabular text-2xs text-ink-tertiary">
                  {(message.intent_confidence * 100).toFixed(0)}% confidence
                </span>
              ) : null}
            </div>
          ) : null}

          <div className="rounded-lg rounded-tl-sm border border-line bg-surface-muted px-3.5 py-2.5">
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-ink">{message.content}</p>
          </div>

          {/* Actions */}
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            {navigationRoute ? (
              <button
                type="button"
                onClick={() => onNavigate(navigationRoute)}
                className="inline-flex items-center gap-1 rounded border border-line-strong bg-surface px-2 py-1
                           text-2xs font-medium text-ink transition-colors hover:bg-surface-muted"
              >
                Open {String(message.navigation?.label ?? 'view')}
                <ArrowRight className="h-3 w-3" />
              </button>
            ) : null}
            {message.run_id ? (
              <button
                type="button"
                onClick={() => onNavigate(`/runs/${message.run_id}`)}
                className="inline-flex items-center gap-1 rounded border border-line-strong bg-surface px-2 py-1
                           text-2xs font-medium text-ink transition-colors hover:bg-surface-muted"
              >
                View run
                <ArrowRight className="h-3 w-3" />
              </button>
            ) : null}
            {speakSupported ? (
              <button
                type="button"
                onClick={onSpeak}
                aria-label="Read this reply aloud"
                className="inline-flex items-center gap-1 rounded border border-line-strong bg-surface px-2 py-1
                           text-2xs font-medium text-ink-secondary transition-colors hover:bg-surface-muted"
              >
                <Volume2 className="h-3 w-3" /> Read aloud
              </button>
            ) : null}
            {(message.reasoning_summary || considered.length) ? (
              <button
                type="button"
                onClick={onToggle}
                aria-expanded={expanded}
                className="inline-flex items-center gap-1 rounded px-1.5 py-1 text-2xs font-medium
                           text-ink-tertiary transition-colors hover:text-ink"
              >
                How this was routed
                <ChevronDown className={cn('h-3 w-3 transition-transform', expanded && 'rotate-180')} />
              </button>
            ) : null}
            {message.cost_usd ? (
              <span className="tabular text-2xs text-ink-tertiary">{formatCurrency(message.cost_usd, 4)}</span>
            ) : null}
          </div>

          {/* Routing transparency */}
          {expanded ? (
            <div className="mt-2 space-y-2.5 rounded border border-line bg-surface p-3">
              {message.reasoning_summary ? (
                <div>
                  <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                    Reasoning
                  </p>
                  <p className="text-xs leading-relaxed text-ink-secondary">{message.reasoning_summary}</p>
                </div>
              ) : null}

              {entityChips.length ? (
                <div>
                  <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                    Understood from your message
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {entityChips.map((chip) => (
                      <span key={chip} className="rounded border border-line bg-surface-muted px-1.5 py-0.5 text-2xs text-ink-secondary">
                        {chip}
                      </span>
                    ))}
                  </div>
                </div>
              ) : null}

              {considered.length ? (
                <div>
                  <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                    Agents considered
                  </p>
                  <ul className="space-y-1">
                    {considered.slice(0, 5).map((agent) => {
                      const isSelected = selected.some((item) => item.agent_key === agent.agent_key);
                      return (
                        <li key={agent.agent_key} className="flex items-center gap-2 text-2xs">
                          <span
                            className={cn(
                              'tabular w-8 shrink-0 text-right font-medium',
                              isSelected ? 'text-success-text' : 'text-ink-tertiary',
                            )}
                          >
                            {(agent.score * 100).toFixed(0)}%
                          </span>
                          <span className={cn('min-w-0 flex-1 truncate', isSelected ? 'font-medium text-ink' : 'text-ink-secondary')}>
                            {agent.name}
                          </span>
                          {isSelected ? <Badge tone="success">selected</Badge> : null}
                        </li>
                      );
                    })}
                  </ul>
                  <p className="mt-1.5 text-2xs text-ink-tertiary">
                    Score combines semantic match against each agent's capability description with the
                    classified intent.
                  </p>
                </div>
              ) : null}

              {sources.length ? (
                <div>
                  <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                    Grounded in
                  </p>
                  <ul className="space-y-0.5">
                    {sources.slice(0, 4).map((name) => (
                      <li key={name} className="truncate text-2xs text-ink-secondary">
                        {name}
                      </li>
                    ))}
                  </ul>
                  {message.evidence && message.evidence.length > sources.length ? (
                    <p className="mt-0.5 text-2xs text-ink-tertiary">
                      {message.evidence.length} passages across {sources.length} source
                      {sources.length === 1 ? '' : 's'}
                    </p>
                  ) : null}
                </div>
              ) : null}
            </div>
          ) : null}

          {/* Figures behind the answer */}
          {facts.length ? (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {facts.map((fact) => (
                <span
                  key={`${fact.label}-${fact.value}`}
                  title={fact.detail ?? undefined}
                  className="inline-flex items-center gap-1 rounded-full border border-line bg-surface-muted px-2 py-0.5 text-2xs text-ink-secondary"
                >
                  {fact.label}
                  <span className="tabular font-semibold text-ink">{fact.value}</span>
                </span>
              ))}
            </div>
          ) : null}

          {/* Was this answer useful? */}
          {message.id && !message.id.startsWith('local-') && message.plan_kind ? (
            <Feedback message={message} />
          ) : null}

          {/* Follow-ups */}
          {message.suggestions?.length ? (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {message.suggestions.slice(0, 3).map((suggestion) => (
                <button
                  key={String(suggestion)}
                  type="button"
                  onClick={() => onSuggestion(String(suggestion))}
                  className="rounded-full border border-brand-100 bg-brand-50 px-2.5 py-1 text-2xs
                             font-medium text-brand-700 transition-colors hover:bg-brand-100"
                >
                  {String(suggestion)}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

/**
 * Rating an answer is what turns the transcript into an evaluation set: a thumbs
 * down with a note names a question the copilot should have answered better.
 */
function Feedback({ message }: { message: CopilotMessage }) {
  const [rating, setRating] = useState<'up' | 'down' | null>(message.feedback ?? null);
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState('');

  const send = useMutation({
    mutationFn: (payload: { rating: 'up' | 'down'; note?: string }) =>
      api.copilotFeedback(message.id, payload.rating, payload.note),
    onSuccess: (updated) => setRating(updated.feedback ?? null),
  });

  const choose = (value: 'up' | 'down') => {
    setRating(value);
    setNoteOpen(value === 'down');
    send.mutate({ rating: value });
  };

  return (
    <div className="mt-2">
      <div className="flex items-center gap-1.5">
        <span className="text-2xs text-ink-tertiary">Was this useful?</span>
        {(['up', 'down'] as const).map((value) => (
          <button
            key={value}
            type="button"
            aria-label={value === 'up' ? 'Helpful answer' : 'Unhelpful answer'}
            aria-pressed={rating === value}
            onClick={() => choose(value)}
            className={cn(
              'rounded border p-1 transition-colors',
              rating === value
                ? value === 'up'
                  ? 'border-success-border bg-success-bg text-success-text'
                  : 'border-danger-border bg-danger-bg text-danger-text'
                : 'border-line text-ink-tertiary hover:bg-surface-muted hover:text-ink',
            )}
          >
            {value === 'up' ? <ThumbsUp className="h-3 w-3" /> : <ThumbsDown className="h-3 w-3" />}
          </button>
        ))}
        {rating && !noteOpen ? <span className="text-2xs text-ink-tertiary">Thanks — recorded.</span> : null}
      </div>
      {noteOpen ? (
        <form
          className="mt-1.5 flex gap-1.5"
          onSubmit={(event) => {
            event.preventDefault();
            send.mutate({ rating: 'down', note: note.trim() || undefined });
            setNoteOpen(false);
          }}
        >
          <input
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="What did you expect instead?"
            aria-label="What did you expect instead?"
            className="h-7 flex-1 rounded border border-line-strong bg-surface px-2 text-2xs text-ink placeholder:text-ink-tertiary"
          />
          <Button type="submit" size="sm" variant="secondary" className="h-7 px-2 text-2xs">
            Send
          </Button>
        </form>
      ) : null}
    </div>
  );
}

export { Bot };
