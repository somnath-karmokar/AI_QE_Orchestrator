/**
 * "How does another system call this?" for one agent or one flow.
 *
 * Collapsed by default: it answers a question most visitors to these pages are
 * not asking, and an endpoint, a scope and a cURL snippet unfurled on every
 * agent would bury what the page is actually about. The choice is remembered,
 * because the people who do want it want it every time.
 *
 * Everything shown is computed server-side from the real authorisation rules,
 * including which keys can already call this, so the panel cannot promise
 * access the API would refuse. It never shows a token -- only a key's name and
 * the hint the rest of the UI shows.
 */
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  ChevronDown, CircleAlert, ExternalLink, KeyRound, Plug, Terminal,
} from 'lucide-react';
import { api } from '@/services/api';
import {
  Badge, Card, CardBody, cn, CopyButton, LoadingBlock,
} from '@/design-system/primitives';

const STORAGE_KEY = 'aiqe.api-access.expanded';

function useRememberedToggle(): [boolean, (next: boolean) => void] {
  const [open, setOpen] = useState(false);

  // Read once on mount rather than during render: storage can throw in a
  // private window, and a render must not depend on that.
  useEffect(() => {
    try {
      setOpen(window.localStorage.getItem(STORAGE_KEY) === 'true');
    } catch {
      /* no stored preference is a fine answer */
    }
  }, []);

  return [
    open,
    (next: boolean) => {
      setOpen(next);
      try {
        window.localStorage.setItem(STORAGE_KEY, String(next));
      } catch {
        /* the panel still works without remembering */
      }
    },
  ];
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:gap-3">
      <span className="w-28 shrink-0 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
        {label}
      </span>
      <div className="flex min-w-0 flex-1 items-center gap-2">{children}</div>
    </div>
  );
}

function Snippet({ text, label }: { text: string; label: string }) {
  return (
    <div className="relative">
      <pre className="overflow-x-auto rounded-lg border border-line bg-surface-sunken px-3.5 py-3 pr-20 font-mono text-2xs leading-relaxed text-ink">
        {text}
      </pre>
      <div className="absolute right-2 top-2">
        <CopyButton text={text} label={label} />
      </div>
    </div>
  );
}

export function ApiAccessCard({
  resource,
  id,
  projectId,
}: {
  resource: 'agent' | 'flow';
  id: string;
  projectId?: string;
}) {
  const [open, setOpen] = useRememberedToggle();

  const { data, isLoading, error } = useQuery({
    queryKey: ['api-access', resource, id, projectId],
    queryFn: () =>
      resource === 'agent' ? api.agentApiAccess(id, projectId!) : api.flowApiAccess(id),
    // Nothing is fetched until the panel is opened: this page is about the
    // agent, not about its endpoint.
    enabled: open && (resource === 'flow' || Boolean(projectId)),
  });

  const panelId = `api-access-${resource}-${id}`;

  return (
    <Card>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        aria-controls={panelId}
        className={cn(
          'flex w-full items-center gap-3 px-5 py-4 text-left transition-colors hover:bg-surface-muted',
          'focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brand-500',
        )}
      >
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-brand-100 bg-brand-50 text-brand-700">
          <Plug className="h-4 w-4" aria-hidden />
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <span className="text-md font-semibold text-ink">API endpoint</span>
            {data ? (
              <Badge tone={data.available ? 'success' : 'warning'} dot>
                {data.available
                  ? `${data.keys.length} key${data.keys.length === 1 ? '' : 's'} can call this`
                  : 'No key can call this yet'}
              </Badge>
            ) : null}
          </span>
          <span className="mt-0.5 block text-sm text-ink-secondary">
            How another platform invokes this {resource} over HTTP or MCP.
          </span>
        </span>
        <span className="flex shrink-0 items-center gap-2 text-sm font-medium text-ink-secondary">
          {open ? 'Hide' : 'Show'}
          <ChevronDown className={cn('h-4 w-4 transition-transform', open && 'rotate-180')} aria-hidden />
        </span>
      </button>

      {open ? (
        <div id={panelId} className="border-t border-line">
          {isLoading ? (
            <CardBody>
              <LoadingBlock rows={4} />
            </CardBody>
          ) : error || !data ? (
            <CardBody>
              <p className="text-sm text-danger-text">The endpoint details could not be loaded.</p>
            </CardBody>
          ) : (
            <CardBody className="space-y-5">
              {data.unavailable_reason ? (
                <p className="flex gap-2 rounded-lg border border-warning-border bg-warning-bg px-3.5 py-2.5 text-sm text-warning-text">
                  <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
                  {data.unavailable_reason}
                </p>
              ) : null}

              <div className="space-y-2.5">
                <Row label="Endpoint">
                  <Badge tone="brand">{data.endpoint.method}</Badge>
                  <code className="min-w-0 flex-1 truncate font-mono text-xs text-ink" title={data.endpoint.url}>
                    {data.endpoint.path}
                  </code>
                  <CopyButton text={data.endpoint.url} label="Copy the endpoint URL" />
                </Row>
                <Row label="Auth">
                  <code className="font-mono text-xs text-ink">{data.authentication.header}</code>
                  <span className="text-xs text-ink-tertiary">requires scope</span>
                  <Badge tone="neutral">{data.authentication.scope_required}</Badge>
                </Row>
                <Row label="MCP tool">
                  <code className="min-w-0 flex-1 truncate font-mono text-xs text-ink">{data.mcp.tool}</code>
                  <CopyButton text={data.mcp.tool} label="Copy the MCP tool name" />
                </Row>
              </div>

              <div>
                <p className="mb-2 flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                  <Terminal className="h-3.5 w-3.5" aria-hidden /> Example request
                </p>
                <Snippet text={data.example.curl} label="Copy the example request" />
                <p className="mt-2 text-xs text-ink-secondary">{data.polling.note}</p>
              </div>

              <div>
                <p className="mb-2 flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                  <KeyRound className="h-3.5 w-3.5" aria-hidden /> Keys that can call this
                </p>
                {data.keys.length ? (
                  <ul className="flex flex-wrap gap-2">
                    {data.keys.map((key) => (
                      <li
                        key={`${key.name}-${key.token_hint}`}
                        className="inline-flex items-center gap-2 rounded-full border border-line bg-surface-muted px-3 py-1"
                      >
                        <span className="text-xs font-medium text-ink">{key.name}</span>
                        <code className="font-mono text-2xs text-ink-tertiary">…{key.token_hint}</code>
                        <Badge tone={key.grant === 'project-wide' ? 'info' : 'neutral'}>{key.grant}</Badge>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-ink-secondary">
                    None yet. An operator issues one with{' '}
                    <code className="font-mono text-xs">POST /api/v1/integration-clients</code>.
                  </p>
                )}
              </div>

              <a
                href="/api/integration-docs"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-brand-600 hover:text-brand-700"
              >
                Browse the full integration API <ExternalLink className="h-3.5 w-3.5" aria-hidden />
              </a>
            </CardBody>
          )}
        </div>
      ) : null}
    </Card>
  );
}
