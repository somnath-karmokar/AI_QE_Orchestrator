/**
 * A premium, RAG-coloured view of a weighted risk assessment (band, veto
 * rule, 15 scored dimensions, selected tests) -- the shape the Impact
 * Analyzer Agent's `outputs` returns. Detected structurally, from `outputs`
 * carrying `band` + `base_score` + `dimensions`, not from the agent's key, so
 * any future agent returning the same shape gets the same treatment for
 * free instead of needing its own bespoke view.
 */
import { Gauge, Minus, ShieldAlert, ShieldCheck, TrendingDown, TrendingUp } from 'lucide-react';
import { Badge, Card, CardBody, CardHeader, ProgressBar, cn } from '@/design-system/primitives';

interface DimensionScore {
  key: string;
  label: string;
  weight: number;
  score: number;
  weighted: number;
}

interface SelectedTestRow {
  path: string;
  priority: string;
  journey?: string;
  reason: string;
}

interface RiskOutputs {
  change_id?: string;
  change_title?: string;
  band: string;
  band_before_veto: string;
  base_score: number;
  max_score: number;
  veto_triggered: string[];
  modifier: number;
  modifier_reading: string;
  coverage_commitment?: string;
  dimensions: DimensionScore[];
  selected_tests: SelectedTestRow[];
  test_counts_by_priority?: Record<string, number>;
}

export function isRiskOutputs(value: unknown): value is RiskOutputs {
  if (!value || typeof value !== 'object') return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.band === 'string' &&
    typeof v.base_score === 'number' &&
    typeof v.max_score === 'number' &&
    Array.isArray(v.dimensions)
  );
}

type Severity = 'critical' | 'high' | 'medium' | 'low';

function severityOf(band: string): Severity {
  const key = band.split(' /')[0].trim().toLowerCase();
  return key === 'critical' || key === 'high' || key === 'medium' || key === 'low' ? key : 'medium';
}

const BAND_STYLE: Record<Severity, { badge: string; bar: 'danger' | 'warning' | 'success'; icon: typeof ShieldAlert }> = {
  critical: { badge: 'border-transparent bg-danger text-white', bar: 'danger', icon: ShieldAlert },
  high: { badge: 'bg-danger-bg text-danger-text border-danger-border', bar: 'danger', icon: ShieldAlert },
  medium: { badge: 'bg-warning-bg text-warning-text border-warning-border', bar: 'warning', icon: ShieldAlert },
  low: { badge: 'bg-success-bg text-success-text border-success-border', bar: 'success', icon: ShieldCheck },
};

const PRIORITY_TONE: Record<string, 'danger' | 'warning' | 'neutral'> = { P1: 'danger', P2: 'warning', P3: 'neutral' };

function scoreTone(score: number): 'success' | 'warning' | 'danger' {
  if (score >= 4) return 'danger';
  if (score === 3) return 'warning';
  return 'success';
}

export function RiskScoreCard({ outputs }: { outputs: RiskOutputs }) {
  const severity = severityOf(outputs.band);
  const style = BAND_STYLE[severity];
  const BandIcon = style.icon;
  const vetoed = outputs.veto_triggered.length > 0;
  const testEntries = Object.entries(outputs.test_counts_by_priority ?? {}).sort(([a], [b]) => a.localeCompare(b));

  return (
    <Card className="border-line-strong shadow-raised">
      <CardHeader
        title={outputs.change_title ? `${outputs.change_id ?? ''} — ${outputs.change_title}` : 'Risk assessment'}
        description="Wickes 15-dimension weighted risk model"
        icon={<Gauge className="h-4 w-4" />}
      />
      <CardBody className="space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">Risk band</p>
            <span
              className={cn(
                'mt-1.5 inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-semibold',
                style.badge,
              )}
            >
              <BandIcon className="h-4 w-4" /> {outputs.band}
            </span>
          </div>
          <div className="text-right">
            <p className="text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">Weighted score</p>
            <p className="tabular mt-1 text-3xl font-semibold text-ink">
              {outputs.base_score}
              <span className="text-lg font-normal text-ink-tertiary">/{outputs.max_score}</span>
            </p>
          </div>
        </div>

        <ProgressBar value={outputs.base_score / outputs.max_score} tone={style.bar} className="h-2" label="Weighted score" />

        {vetoed ? (
          <div className="flex items-start gap-2.5 rounded border border-danger-border bg-danger-bg px-3.5 py-3">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-danger-text" aria-hidden />
            <p className="text-sm text-danger-text">
              <span className="font-semibold">Veto rule triggered</span> on {outputs.veto_triggered.join(', ')} (scored
              5) —{' '}
              {outputs.band === outputs.band_before_veto
                ? `already at the top band (${outputs.band}) on its base score, so the veto confirms it rather than raising it.`
                : `escalated from ${outputs.band_before_veto} to ${outputs.band}.`}
            </p>
          </div>
        ) : null}

        <div className="flex flex-wrap items-center gap-2 text-sm">
          <span className="font-medium text-ink">Confidence / control modifier</span>
          <span
            className={cn(
              'tabular inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-xs font-semibold',
              outputs.modifier > 0
                ? 'bg-danger-bg text-danger-text'
                : outputs.modifier < 0
                  ? 'bg-success-bg text-success-text'
                  : 'bg-surface-sunken text-ink-secondary',
            )}
          >
            {outputs.modifier > 0 ? (
              <TrendingUp className="h-3 w-3" aria-hidden />
            ) : outputs.modifier < 0 ? (
              <TrendingDown className="h-3 w-3" aria-hidden />
            ) : (
              <Minus className="h-3 w-3" aria-hidden />
            )}
            {outputs.modifier > 0 ? `+${outputs.modifier}` : outputs.modifier}
          </span>
          <span className="text-ink-tertiary">({outputs.modifier_reading})</span>
        </div>

        {outputs.coverage_commitment ? (
          <p className="text-sm text-ink-secondary">
            <span className="font-medium text-ink">Coverage commitment: </span>
            {outputs.coverage_commitment}
          </p>
        ) : null}

        <div>
          <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
            {outputs.dimensions.length} weighted dimensions
          </p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {outputs.dimensions.map((dimension) => (
              <DimensionChip key={dimension.key} dimension={dimension} />
            ))}
          </div>
        </div>

        {outputs.selected_tests.length ? (
          <div>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <p className="text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">
                {outputs.selected_tests.length} test(s) selected from the test-pack repo
              </p>
              <div className="flex flex-wrap gap-1.5">
                {testEntries.map(([priority, count]) => (
                  <Badge key={priority} tone={PRIORITY_TONE[priority] ?? 'neutral'}>
                    {priority}: {count}
                  </Badge>
                ))}
              </div>
            </div>
            {/* Scrollable on screen so a long list stays compact; the cap is a
                container height, not a slice, so a downloaded/printed copy
                shows every selected test, not just the visible ones. */}
            <ul className="max-h-72 divide-y divide-line-subtle overflow-y-auto rounded border border-line print:max-h-none print:overflow-visible">
              {outputs.selected_tests.map((test, index) => (
                <li key={index} className="flex items-start gap-2.5 px-3 py-2">
                  <Badge tone={PRIORITY_TONE[test.priority] ?? 'neutral'} className="mt-0.5 shrink-0">
                    {test.priority}
                  </Badge>
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs text-ink">{test.path}</p>
                    <p className="mt-0.5 text-xs text-ink-secondary">{test.reason}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </CardBody>
    </Card>
  );
}

function DimensionChip({ dimension }: { dimension: DimensionScore }) {
  const tone = scoreTone(dimension.score);
  const toneText = { success: 'text-success-text', warning: 'text-warning-text', danger: 'text-danger-text' }[tone];
  const toneDot = { success: 'bg-success', warning: 'bg-warning', danger: 'bg-danger' }[tone];
  const toneBorder = { success: 'border-line', warning: 'border-warning-border', danger: 'border-danger-border' }[tone];

  return (
    <div className={cn('rounded border bg-surface px-3 py-2', toneBorder)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-medium leading-snug text-ink">{dimension.label}</p>
        <span className={cn('tabular shrink-0 text-xs font-semibold', toneText)}>{dimension.score}/5</span>
      </div>
      <div className="mt-1.5 flex gap-0.5" aria-hidden>
        {[1, 2, 3, 4, 5].map((n) => (
          <span key={n} className={cn('h-1.5 flex-1 rounded-full', n <= dimension.score ? toneDot : 'bg-surface-sunken')} />
        ))}
      </div>
      <p className="mt-1 text-2xs text-ink-tertiary">
        weight ×{dimension.weight} = {dimension.weighted}
        {dimension.score === 5 ? <span className={cn('ml-1 font-medium', toneText)}>· veto-eligible</span> : null}
      </p>
    </div>
  );
}
