"""Copilot answer feedback: was the reply useful?

Revision ID: c7b3e55d1a92
Revises: f1a83c6d40e2
Create Date: 2026-09-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import UTCDateTime

revision = "c7b3e55d1a92"
down_revision = "f1a83c6d40e2"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("conversation_messages") as batch:
        batch.add_column(sa.Column("feedback", sa.String(length=12), nullable=True))
        batch.add_column(sa.Column("feedback_note", sa.Text(), nullable=True))
        batch.add_column(sa.Column("feedback_by", sa.String(length=160), nullable=True))
        batch.add_column(sa.Column("feedback_at", UTCDateTime(), nullable=True))
    op.create_index(
        "ix_conversation_messages_feedback", "conversation_messages", ["feedback"], unique=False
    )


def downgrade() -> None:
    op.drop_index("ix_conversation_messages_feedback", table_name="conversation_messages")
    with op.batch_alter_table("conversation_messages") as batch:
        batch.drop_column("feedback_at")
        batch.drop_column("feedback_by")
        batch.drop_column("feedback_note")
        batch.drop_column("feedback")
