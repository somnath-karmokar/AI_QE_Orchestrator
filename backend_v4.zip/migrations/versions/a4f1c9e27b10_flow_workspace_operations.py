"""flow workspace: owner, schedule, API trigger and governance settings

Revision ID: a4f1c9e27b10
Revises: d03ba7e2cca7
Create Date: 2026-09-17 10:00:00.000000
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

# Portable custom column types referenced by the schema.
import app.models.base


revision = 'a4f1c9e27b10'
down_revision = 'd03ba7e2cca7'
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table('agent_flows') as batch:
        batch.add_column(sa.Column('owner', sa.String(length=160), nullable=True))
        batch.add_column(sa.Column('schedule', app.models.base.JSONType(), nullable=True))
        batch.add_column(sa.Column('next_run_at', app.models.base.UTCDateTime(), nullable=True))
        batch.add_column(sa.Column('webhook_token_hash', sa.String(length=128), nullable=True))
        batch.add_column(sa.Column('webhook_token_hint', sa.String(length=12), nullable=True))
        batch.add_column(sa.Column('governance', app.models.base.JSONType(), nullable=True))
        batch.create_index('ix_agent_flows_next_run_at', ['next_run_at'], unique=False)


def downgrade() -> None:
    with op.batch_alter_table('agent_flows') as batch:
        batch.drop_index('ix_agent_flows_next_run_at')
        batch.drop_column('governance')
        batch.drop_column('webhook_token_hint')
        batch.drop_column('webhook_token_hash')
        batch.drop_column('next_run_at')
        batch.drop_column('schedule')
        batch.drop_column('owner')
