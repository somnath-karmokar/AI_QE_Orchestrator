"""Failure evidence: what the browser actually saw when a test failed.

Healing previously reasoned over heuristics because there was nothing else. This
table holds the page as it really was -- DOM, accessibility tree, console and
network -- so a proposed locator can be checked against reality.

Revision ID: e5c81a3f7b62
Revises: b2d7419fc305
Create Date: 2026-09-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID, JSONType, UTCDateTime

revision = "e5c81a3f7b62"
down_revision = "b2d7419fc305"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "failure_evidence",
        sa.Column("id", GUID(), primary_key=True, nullable=False),
        sa.Column("project_id", GUID(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("execution_id", GUID(), sa.ForeignKey("executions.id", ondelete="CASCADE"), nullable=False),
        sa.Column(
            "execution_test_id",
            GUID(),
            sa.ForeignKey("execution_tests.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("page_url", sa.String(length=600), nullable=True),
        sa.Column("page_title", sa.String(length=300), nullable=True),
        sa.Column("failed_locator", sa.String(length=600), nullable=True),
        sa.Column("failed_locator_name", sa.String(length=200), nullable=True),
        sa.Column("failed_locator_strategy", sa.String(length=40), nullable=True),
        sa.Column("dom_html", sa.Text(), nullable=True),
        sa.Column("accessibility_tree", JSONType(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("console_logs", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("network_logs", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("screenshot_path", sa.String(length=600), nullable=True),
        sa.Column("trace_path", sa.String(length=600), nullable=True),
        sa.Column("capture_mode", sa.String(length=20), nullable=False, server_default="simulated"),
        sa.Column("captured_at", UTCDateTime(), nullable=True),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
    )
    op.create_index("ix_failure_evidence_project_id", "failure_evidence", ["project_id"])
    op.create_index("ix_failure_evidence_execution_id", "failure_evidence", ["execution_id"])
    op.create_index(
        "ix_failure_evidence_execution_test_id", "failure_evidence", ["execution_test_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_failure_evidence_execution_test_id", table_name="failure_evidence")
    op.drop_index("ix_failure_evidence_execution_id", table_name="failure_evidence")
    op.drop_index("ix_failure_evidence_project_id", table_name="failure_evidence")
    op.drop_table("failure_evidence")
