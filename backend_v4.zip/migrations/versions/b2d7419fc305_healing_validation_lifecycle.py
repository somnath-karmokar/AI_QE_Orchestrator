"""Healing validation lifecycle: prove a heal before applying it.

Adds the change type the policy matrix is applied to, the per-signal confidence
breakdown, the temporary patch, and the re-run validation result. Before this,
`result_after` was written on approval without a re-run; from here it is written
only by the validation service.

Revision ID: b2d7419fc305
Revises: c7b3e55d1a92
Create Date: 2026-09-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID, JSONType, UTCDateTime

revision = "b2d7419fc305"
down_revision = "c7b3e55d1a92"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("healing_records") as batch:
        batch.add_column(
            sa.Column("change_type", sa.String(length=40), nullable=False, server_default="locator")
        )
        # NOT NULL with a server default, matching the models. A nullable column
        # here would let a migrated database hold NULLs the ORM says cannot exist.
        batch.add_column(
            sa.Column(
                "confidence_breakdown", JSONType(), nullable=False, server_default=sa.text("'[]'")
            )
        )
        batch.add_column(
            sa.Column("patch", JSONType(), nullable=False, server_default=sa.text("'{}'"))
        )
        batch.add_column(
            sa.Column(
                "validation_status", sa.String(length=30), nullable=False, server_default="not_started"
            )
        )
        batch.add_column(sa.Column("validation_mode", sa.String(length=20), nullable=True))
        batch.add_column(
            sa.Column(
                "validation_evidence", JSONType(), nullable=False, server_default=sa.text("'[]'")
            )
        )
        batch.add_column(sa.Column("validation_execution_id", GUID(), nullable=True))
        batch.add_column(sa.Column("attempt_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("rolled_back_at", UTCDateTime(), nullable=True))
        batch.add_column(sa.Column("approval_request_id", GUID(), nullable=True))

    op.create_index("ix_healing_records_change_type", "healing_records", ["change_type"], unique=False)
    op.create_index(
        "ix_healing_records_validation_status", "healing_records", ["validation_status"], unique=False
    )

    # A new JSON column is NULL on existing rows, and the model defaults only
    # apply to inserts. Backfill so every row is readable, not just new ones.
    for column, empty in (
        ("confidence_breakdown", "'[]'"),
        ("validation_evidence", "'[]'"),
        ("patch", "'{}'"),
    ):
        op.execute(f"UPDATE healing_records SET {column} = {empty} WHERE {column} IS NULL")

    # `a4f1c9e27b10` added these as nullable although the models declare them
    # NOT NULL, so a migrated database could hold NULLs the ORM says cannot
    # exist. Same class of fault as the JSON columns above; fixed forward.
    op.execute("UPDATE agent_flows SET schedule = '{}' WHERE schedule IS NULL")
    op.execute("UPDATE agent_flows SET governance = '{}' WHERE governance IS NULL")
    with op.batch_alter_table("agent_flows") as batch:
        batch.alter_column(
            "schedule", existing_type=JSONType(), nullable=False, server_default=sa.text("'{}'")
        )
        batch.alter_column(
            "governance", existing_type=JSONType(), nullable=False, server_default=sa.text("'{}'")
        )

    # Existing rows were marked "applied" with result_after="passed" by an
    # endpoint that never re-ran anything. Keep the history, but stop it claiming
    # a validation: the outcome is unknown, not successful.
    op.execute(
        """
        UPDATE healing_records
           SET validation_status = 'inconclusive',
               result_after = NULL,
               validated_at = NULL
         WHERE status = 'applied'
        """
    )


def downgrade() -> None:
    with op.batch_alter_table("agent_flows") as batch:
        batch.alter_column("governance", existing_type=JSONType(), nullable=True)
        batch.alter_column("schedule", existing_type=JSONType(), nullable=True)

    op.drop_index("ix_healing_records_validation_status", table_name="healing_records")
    op.drop_index("ix_healing_records_change_type", table_name="healing_records")
    with op.batch_alter_table("healing_records") as batch:
        batch.drop_column("approval_request_id")
        batch.drop_column("rolled_back_at")
        batch.drop_column("attempt_count")
        batch.drop_column("validation_execution_id")
        batch.drop_column("validation_evidence")
        batch.drop_column("validation_mode")
        batch.drop_column("validation_status")
        batch.drop_column("patch")
        batch.drop_column("confidence_breakdown")
        batch.drop_column("change_type")
