"""Project-wide grants for an integration key.

Until now a key named every flow and agent it could invoke, so exposing a whole
project meant listing it -- and relisting it whenever something was published.
These two flags let an operator grant the project instead, deliberately: both
default to false, so no existing key widens.

Revision ID: a4d92f1c8b57
Revises: f7a21b9d4e30
Create Date: 2026-09-21
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "a4d92f1c8b57"
down_revision = "f7a21b9d4e30"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # A server default as well as the Python default: rows written by anything
    # that bypasses the ORM must not leave these NULL, which reads as "unknown"
    # on an authorisation check.
    with op.batch_alter_table("integration_clients") as batch:
        batch.add_column(
            sa.Column("grants_all_flows", sa.Boolean(), nullable=False, server_default=sa.text("0"))
        )
        batch.add_column(
            sa.Column("grants_all_agents", sa.Boolean(), nullable=False, server_default=sa.text("0"))
        )


def downgrade() -> None:
    with op.batch_alter_table("integration_clients") as batch:
        batch.drop_column("grants_all_agents")
        batch.drop_column("grants_all_flows")
