"""Tenant-owned data sources, with their credentials encrypted at rest.

A customer connecting their own Postgres, S3 bucket or REST API hands this
platform a credential to their systems. Nothing else in the schema holds a
secret value, so this table introduces the first: `secret_bundle` is ciphertext
written by `app.core.crypto`, never plaintext.

Unlike `mcp_servers`, `project_id` is NOT NULL here. A shared connector belongs
to the platform; a data source belongs to one customer, and one that belonged to
nobody would be one everybody could use.

Revision ID: d3f6a91c07b4
Revises: c8f1d2b45a06
Create Date: 2026-09-22
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID, UTCDateTime

revision = "d3f6a91c07b4"
down_revision = "c8f1d2b45a06"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "data_sources",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column(
            "project_id",
            GUID(),
            sa.ForeignKey("projects.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("key", sa.String(length=60), nullable=False),
        sa.Column("name", sa.String(length=240), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("kind", sa.String(length=40), nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False, server_default="unverified"),
        sa.Column("is_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("config", sa.JSON(), nullable=False, server_default="{}"),
        # Ciphertext. Text rather than a fixed width: the bundle grows with the
        # number of credential fields a kind takes.
        sa.Column("secret_bundle", sa.Text(), nullable=True),
        sa.Column("secret_fingerprint", sa.String(length=32), nullable=True),
        sa.Column("secret_updated_at", UTCDateTime(), nullable=True),
        sa.Column("secret_updated_by", sa.String(length=160), nullable=True),
        sa.Column("allow_writes", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("last_tested_at", UTCDateTime(), nullable=True),
        sa.Column("last_test_ok", sa.Boolean(), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("created_by", sa.String(length=160), nullable=True),
        sa.Column("is_deleted", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("deleted_at", UTCDateTime(), nullable=True),
        sa.Column("deleted_by", sa.String(length=160), nullable=True),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("updated_by", sa.String(length=160), nullable=True),
        sa.UniqueConstraint("project_id", "key", name="uq_data_sources_project_key"),
    )
    op.create_index("ix_data_sources_project_id", "data_sources", ["project_id"])
    op.create_index("ix_data_sources_key", "data_sources", ["key"])
    op.create_index("ix_data_sources_kind", "data_sources", ["kind"])


def downgrade() -> None:
    op.drop_index("ix_data_sources_kind", table_name="data_sources")
    op.drop_index("ix_data_sources_key", table_name="data_sources")
    op.drop_index("ix_data_sources_project_id", table_name="data_sources")
    op.drop_table("data_sources")
