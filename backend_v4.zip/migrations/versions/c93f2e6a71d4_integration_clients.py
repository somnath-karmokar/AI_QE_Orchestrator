"""Integration clients: credentials for other platforms calling in.

A flow's own token starts exactly one flow. This is the broader credential --
explicit scopes, an explicit list of what may be invoked, and an identity the
audit trail can name.

Revision ID: c93f2e6a71d4
Revises: e5c81a3f7b62
Create Date: 2026-09-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID, JSONType, UTCDateTime

revision = "c93f2e6a71d4"
down_revision = "e5c81a3f7b62"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "integration_clients",
        sa.Column("id", GUID(), primary_key=True, nullable=False),
        sa.Column("project_id", GUID(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(length=160), nullable=False),
        sa.Column("description", sa.String(length=500), nullable=True),
        sa.Column("platform", sa.String(length=80), nullable=True),
        sa.Column("token_hash", sa.String(length=128), nullable=False),
        sa.Column("token_hint", sa.String(length=12), nullable=False),
        sa.Column("scopes", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("allowed_flow_ids", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("allowed_agent_keys", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("1")),
        sa.Column("expires_at", UTCDateTime(), nullable=True),
        sa.Column("rate_limit_per_minute", sa.Integer(), nullable=False, server_default="60"),
        sa.Column("callback_url", sa.String(length=600), nullable=True),
        sa.Column("last_used_at", UTCDateTime(), nullable=True),
        sa.Column("call_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("is_deleted", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("deleted_at", UTCDateTime(), nullable=True),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
    )
    op.create_index("ix_integration_clients_project_id", "integration_clients", ["project_id"])
    # Authentication looks a token up by its hash on every call.
    op.create_index("ix_integration_clients_token_hash", "integration_clients", ["token_hash"])
    op.create_index("ix_integration_clients_is_deleted", "integration_clients", ["is_deleted"])

    # An external caller's idempotency key. Its own column rather than a corner
    # of `variables`, which the flow engine overwrites while a run is in flight.
    with op.batch_alter_table("agent_runs") as batch:
        batch.add_column(sa.Column("idempotency_key", sa.String(length=120), nullable=True))
    op.create_index("ix_agent_runs_idempotency_key", "agent_runs", ["idempotency_key"])


def downgrade() -> None:
    op.drop_index("ix_agent_runs_idempotency_key", table_name="agent_runs")
    with op.batch_alter_table("agent_runs") as batch:
        batch.drop_column("idempotency_key")

    op.drop_index("ix_integration_clients_is_deleted", table_name="integration_clients")
    op.drop_index("ix_integration_clients_token_hash", table_name="integration_clients")
    op.drop_index("ix_integration_clients_project_id", table_name="integration_clients")
    op.drop_table("integration_clients")
