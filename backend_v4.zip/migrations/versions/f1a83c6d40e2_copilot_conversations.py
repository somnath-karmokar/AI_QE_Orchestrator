"""Copilot conversations and their messages.

These tables exist in the models (and in demo databases, which are built with
`create_all`) but were missing from the migration baseline, so a database built
purely from migrations had no copilot history. This adds them.

Revision ID: f1a83c6d40e2
Revises: a4f1c9e27b10
Create Date: 2026-09-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

import app.models.base

revision = "f1a83c6d40e2"
down_revision = "a4f1c9e27b10"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "conversations",
        sa.Column("project_id", app.models.base.GUID(length=36), nullable=False),
        sa.Column("user_id", app.models.base.GUID(length=36), nullable=True),
        sa.Column("title", sa.String(length=240), nullable=False),
        sa.Column("environment_id", app.models.base.GUID(length=36), nullable=True),
        sa.Column("message_count", sa.Integer(), nullable=False),
        sa.Column("total_tokens", sa.Integer(), nullable=False),
        sa.Column("total_cost_usd", sa.Float(), nullable=False),
        sa.Column("last_message_at", app.models.base.UTCDateTime(), nullable=True),
        sa.Column("context", app.models.base.JSONType(), nullable=False),
        sa.Column("is_deleted", sa.Boolean(), nullable=False),
        sa.Column("deleted_at", app.models.base.UTCDateTime(), nullable=True),
        sa.Column("id", app.models.base.GUID(length=36), nullable=False),
        sa.Column("created_at", app.models.base.UTCDateTime(), nullable=False),
        sa.Column("updated_at", app.models.base.UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
        sa.ForeignKeyConstraint(["environment_id"], ["environments.id"]),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    with op.batch_alter_table("conversations", schema=None) as batch:
        batch.create_index(batch.f("ix_conversations_is_deleted"), ["is_deleted"], unique=False)
        batch.create_index(batch.f("ix_conversations_project_id"), ["project_id"], unique=False)
        batch.create_index(batch.f("ix_conversations_user_id"), ["user_id"], unique=False)

    op.create_table(
        "conversation_messages",
        sa.Column("conversation_id", app.models.base.GUID(length=36), nullable=False),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column("role", sa.String(length=20), nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("plan_kind", sa.String(length=24), nullable=True),
        sa.Column("intent", sa.String(length=80), nullable=True),
        sa.Column("intent_confidence", sa.Float(), nullable=True),
        sa.Column("considered_agents", app.models.base.JSONType(), nullable=False),
        sa.Column("selected_agents", app.models.base.JSONType(), nullable=False),
        sa.Column("extracted_entities", app.models.base.JSONType(), nullable=False),
        sa.Column("reasoning_summary", sa.Text(), nullable=True),
        sa.Column("run_id", app.models.base.GUID(length=36), nullable=True),
        sa.Column("evidence", app.models.base.JSONType(), nullable=False),
        sa.Column("artifacts", app.models.base.JSONType(), nullable=False),
        sa.Column("suggestions", app.models.base.JSONType(), nullable=False),
        sa.Column("navigation", app.models.base.JSONType(), nullable=False),
        sa.Column("provider", sa.String(length=40), nullable=True),
        sa.Column("model", sa.String(length=80), nullable=True),
        sa.Column("total_tokens", sa.Integer(), nullable=False),
        sa.Column("cost_usd", sa.Float(), nullable=False),
        sa.Column("duration_ms", sa.Integer(), nullable=False),
        sa.Column("policy_decision", app.models.base.JSONType(), nullable=False),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("is_voice", sa.Boolean(), nullable=False),
        sa.Column("id", app.models.base.GUID(length=36), nullable=False),
        sa.Column("created_at", app.models.base.UTCDateTime(), nullable=False),
        sa.Column("updated_at", app.models.base.UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
        sa.ForeignKeyConstraint(["conversation_id"], ["conversations.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["run_id"], ["agent_runs.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    with op.batch_alter_table("conversation_messages", schema=None) as batch:
        batch.create_index(batch.f("ix_conversation_messages_conversation_id"), ["conversation_id"], unique=False)
        batch.create_index(batch.f("ix_conversation_messages_run_id"), ["run_id"], unique=False)


def downgrade() -> None:
    with op.batch_alter_table("conversation_messages", schema=None) as batch:
        batch.drop_index(batch.f("ix_conversation_messages_run_id"))
        batch.drop_index(batch.f("ix_conversation_messages_conversation_id"))
    op.drop_table("conversation_messages")
    with op.batch_alter_table("conversations", schema=None) as batch:
        batch.drop_index(batch.f("ix_conversations_user_id"))
        batch.drop_index(batch.f("ix_conversations_project_id"))
        batch.drop_index(batch.f("ix_conversations_is_deleted"))
    op.drop_table("conversations")
