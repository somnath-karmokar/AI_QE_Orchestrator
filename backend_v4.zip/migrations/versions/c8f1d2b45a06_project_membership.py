"""Project membership: who may see a project's data.

Until now a project was an organising concept, not a boundary. Any authenticated
user could list every project, open any of them, and read any run by id -- so a
second customer's work was one identifier away. This table makes membership the
tenant boundary.

The upgrade backfills every existing user into every existing project, because
the alternative is locking people out of a platform that has been single-tenant
until this moment. New projects get only their creator.

Revision ID: c8f1d2b45a06
Revises: b7e4c1a90d83
Create Date: 2026-09-22
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID, UTCDateTime

revision = "c8f1d2b45a06"
down_revision = "b7e4c1a90d83"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "project_members",
        sa.Column("id", GUID(), primary_key=True, nullable=False),
        sa.Column("project_id", GUID(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", GUID(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("access", sa.String(length=20), nullable=False, server_default="member"),
        sa.Column("added_by", sa.String(length=160), nullable=True),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
        sa.UniqueConstraint("project_id", "user_id", name="uq_project_members_project_user"),
    )
    op.create_index("ix_project_members_project_id", "project_members", ["project_id"])
    op.create_index("ix_project_members_user_id", "project_members", ["user_id"])

    # Everyone keeps the access they had, so switching this on is not an outage.
    # Narrowing it afterwards is a deliberate act by an operator.
    op.execute(
        """
        INSERT INTO project_members (id, project_id, user_id, access, added_by, created_at, updated_at)
        SELECT lower(hex(randomblob(16))), p.id, u.id, 'member', 'migration',
               CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
        FROM projects p CROSS JOIN users u
        """
    )


def downgrade() -> None:
    op.drop_index("ix_project_members_user_id", table_name="project_members")
    op.drop_index("ix_project_members_project_id", table_name="project_members")
    op.drop_table("project_members")
