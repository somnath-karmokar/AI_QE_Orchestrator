"""Business flows: the journeys a customer takes, and what each step depends on.

Modules say where a test lives. A journey says what a repair touches — which is
the question that matters after healing something, and before choosing a
regression suite.

Revision ID: f7a21b9d4e30
Revises: d41b8c05e7a9
Create Date: 2026-09-20
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID, JSONType, UTCDateTime

revision = "f7a21b9d4e30"
down_revision = "d41b8c05e7a9"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "business_flows",
        sa.Column("id", GUID(), primary_key=True, nullable=False),
        sa.Column("project_id", GUID(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("key", sa.String(length=80), nullable=False),
        sa.Column("name", sa.String(length=240), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("criticality", sa.String(length=20), nullable=False, server_default="high"),
        sa.Column("owner", sa.String(length=120), nullable=True),
        sa.Column("modules", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("is_deleted", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("deleted_at", UTCDateTime(), nullable=True),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
    )
    op.create_index("ix_business_flows_project_id", "business_flows", ["project_id"])
    op.create_index("ix_business_flows_key", "business_flows", ["key"])
    op.create_index("ix_business_flows_is_deleted", "business_flows", ["is_deleted"])

    op.create_table(
        "business_flow_steps",
        sa.Column("id", GUID(), primary_key=True, nullable=False),
        sa.Column(
            "business_flow_id",
            GUID(),
            sa.ForeignKey("business_flows.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("position", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("key", sa.String(length=80), nullable=False),
        sa.Column("name", sa.String(length=240), nullable=False),
        sa.Column("module", sa.String(length=120), nullable=True),
        sa.Column("ui_components", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("api_endpoints", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("data_entities", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("assertions", JSONType(), nullable=False, server_default=sa.text("'[]'")),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
    )
    op.create_index(
        "ix_business_flow_steps_business_flow_id", "business_flow_steps", ["business_flow_id"]
    )

    op.create_table(
        "test_dependencies",
        sa.Column("id", GUID(), primary_key=True, nullable=False),
        sa.Column("project_id", GUID(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column(
            "test_case_id", GUID(), sa.ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False
        ),
        sa.Column(
            "business_flow_step_id",
            GUID(),
            sa.ForeignKey("business_flow_steps.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("relationship_type", sa.String(length=24), nullable=False, server_default="covers"),
        sa.Column("created_at", UTCDateTime(), nullable=False),
        sa.Column("updated_at", UTCDateTime(), nullable=False),
        sa.Column("created_by", sa.String(length=120), nullable=True),
        sa.Column("updated_by", sa.String(length=120), nullable=True),
        sa.UniqueConstraint("test_case_id", "business_flow_step_id", name="uq_test_dependency"),
    )
    op.create_index("ix_test_dependencies_project_id", "test_dependencies", ["project_id"])
    op.create_index("ix_test_dependencies_test_case_id", "test_dependencies", ["test_case_id"])
    op.create_index(
        "ix_test_dependencies_business_flow_step_id", "test_dependencies", ["business_flow_step_id"]
    )


def downgrade() -> None:
    op.drop_table("test_dependencies")
    op.drop_index("ix_business_flow_steps_business_flow_id", table_name="business_flow_steps")
    op.drop_table("business_flow_steps")
    op.drop_index("ix_business_flows_is_deleted", table_name="business_flows")
    op.drop_index("ix_business_flows_key", table_name="business_flows")
    op.drop_index("ix_business_flows_project_id", table_name="business_flows")
    op.drop_table("business_flows")
