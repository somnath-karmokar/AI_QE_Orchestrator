"""Own an integration-started run by the key's id, not its name.

A run recorded its caller only as `integration:{name}`, and that string decided
who could read the run back. A name is a label, not an identity: two keys in one
project may share one, and then each would see the other's runs -- which matters
now that a key's holder has a dashboard listing them.

The column is nullable, and reads fall back to the old name match, so runs
started before this migration stay visible to the key that started them.

Revision ID: b7e4c1a90d83
Revises: a4d92f1c8b57
Create Date: 2026-09-21
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.models.base import GUID

revision = "b7e4c1a90d83"
down_revision = "a4d92f1c8b57"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("agent_runs") as batch:
        batch.add_column(sa.Column("integration_client_id", GUID(), nullable=True))
    op.create_index(
        "ix_agent_runs_integration_client_id", "agent_runs", ["integration_client_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_agent_runs_integration_client_id", table_name="agent_runs")
    with op.batch_alter_table("agent_runs") as batch:
        batch.drop_column("integration_client_id")
