"""How long a late element actually took to appear.

Distinguishing "the element is missing" from "the element was late" is what makes
a timing repair possible: the proposed wait is derived from this measurement
rather than from a round number.

Revision ID: d41b8c05e7a9
Revises: c93f2e6a71d4
Create Date: 2026-09-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "d41b8c05e7a9"
down_revision = "c93f2e6a71d4"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("failure_evidence") as batch:
        batch.add_column(sa.Column("observed_wait_ms", sa.Integer(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("failure_evidence") as batch:
        batch.drop_column("observed_wait_ms")
