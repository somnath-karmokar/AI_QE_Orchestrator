"""Does the Bedrock provider translate correctly? Stubbed client, real code path."""
import os
os.environ["BEDROCK_REGION"] = "eu-west-2"
os.environ["BEDROCK_CHAT_MODEL"] = "anthropic.claude-sonnet-4-5-v1:0"
os.environ["BEDROCK_EMBEDDING_MODEL"] = "amazon.titan-embed-text-v2:0"

from app.ai.providers.base import ChatMessage, ModelSelection
from app.ai.providers.bedrock_provider import BedrockProvider
from app.ai.providers.registry import bedrock_catalog

captured = {}
class StubClient:
    def converse(self, **kw):
        captured.update(kw)
        return {"output": {"message": {"content": [{"text": '```json\n{"verdict": "ok"}\n```'}]}},
                "usage": {"inputTokens": 120, "outputTokens": 30}, "stopReason": "end_turn"}

p = BedrockProvider()
BedrockProvider._client_cache = StubClient()
sel = ModelSelection(provider="bedrock", model="anthropic.claude-sonnet-4-5-v1:0",
                     deployment=None, capability="generation", max_tokens=1000)
msgs = [ChatMessage(role="system", content="You are precise."),
        ChatMessage(role="user", content="First question."),
        ChatMessage(role="user", content="Second, same turn."),
        ChatMessage(role="assistant", content="Reply."),
        ChatMessage(role="user", content="Follow up.")]
r = p.chat(msgs, sel, response_schema={"type": "object"})

print("system out of band :", captured["system"])
print("turns alternate    :", [t["role"] for t in captured["messages"]])
print("merged same-role   :", len(captured["messages"][0]["content"]) == 2)
print("inference config   :", captured["inferenceConfig"])
print("fenced json parsed :", r.structured)
print("tokens             :", r.usage.prompt_tokens, "/", r.usage.completion_tokens)
print("finish             :", r.finish_reason)
print("catalogue          :", [(e['model_key'], e['tier'], e['capabilities'][0]) for e in bedrock_catalog()])
