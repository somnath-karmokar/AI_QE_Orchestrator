"""Business flows, and what a change reaches.

A module says where a test was filed. It cannot say that repairing the
Add-to-Cart control puts the checkout total at risk, because those live in
different folders and are the same journey.

These tests pin two things: that the graph answers that question, and that when
no journey covers something the platform says so instead of guessing.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.healing.impact import assess, locate_step, select_for_change
from app.models.testing import BusinessFlow, BusinessFlowStep, TestCase, TestDependency


@pytest.fixture
def journey(db, project_id: str):
    """A three-step journey with a test covering each step."""
    flow = BusinessFlow(
        project_id=project_id,
        key="probe-journey",
        name="Probe journey",
        criticality="critical",
        owner="qe.lead@example.com",
        modules=["Basket", "Checkout"],
    )
    db.add(flow)
    db.flush()

    # Names deliberately distinct from the seeded demo journeys, so this
    # exercises its own graph rather than colliding with theirs.
    steps = []
    for position, (key, name, module, component, assertion) in enumerate(
        [
            ("probe-add-to-cart", "Add to cart", "ProbeBasket", "probe-add-to-cart-btn",
             "The basket count increases by one."),
            ("probe-review-basket", "Review the basket", "ProbeBasket", "probe-basket-total",
             "The basket total equals the sum of its lines."),
            ("probe-checkout", "Check out", "ProbeCheckout", "probe-checkout-submit",
             "The amount charged equals the basket total."),
        ]
    ):
        step = BusinessFlowStep(
            business_flow_id=flow.id,
            position=position,
            key=key,
            name=name,
            module=module,
            ui_components=[component],
            api_endpoints=[f"/api/{key}"],
            assertions=[assertion],
        )
        db.add(step)
        steps.append(step)
    db.flush()

    # Its own test cases, so the seeded project's dependencies do not answer
    # for them.
    cases = []
    for index, step in enumerate(steps):
        case = TestCase(
            project_id=project_id,
            key=f"PROBE-{index}",
            title=f"Probe test {index}",
            module=step.module,
            priority="high",
            is_automated=True,
        )
        db.add(case)
        cases.append(case)
    db.flush()

    for case, step in zip(cases, steps, strict=True):
        db.add(
            TestDependency(
                project_id=project_id,
                test_case_id=case.id,
                business_flow_step_id=step.id,
                relationship_type="covers",
            )
        )
    db.flush()
    return {"flow": flow, "steps": steps, "cases": cases}


# ---------------------------------------------------------------------------
# Locating
# ---------------------------------------------------------------------------


def test_a_test_is_located_in_its_journey(db, project_id: str, journey) -> None:
    step = locate_step(db, project_id=project_id, test_case_id=journey["cases"][0].id)
    assert step is not None
    assert step.key == "probe-add-to-cart"


def test_a_component_is_located_in_its_step(db, project_id: str, journey) -> None:
    """A drifted locator names a component, not a test."""
    step = locate_step(db, project_id=project_id, component="probe-checkout-submit")
    assert step is not None
    assert step.key == "probe-checkout"


def test_something_no_journey_covers_is_not_located(db, project_id: str, journey) -> None:
    assert locate_step(db, project_id=project_id, component="unrelated-widget") is None


# ---------------------------------------------------------------------------
# What a repair reaches
# ---------------------------------------------------------------------------


def test_a_repair_names_what_must_still_be_checked(db, project_id: str, journey) -> None:
    """The point: passing the repaired test proves the test. It does not prove
    the journey."""
    impact = assess(db, project_id=project_id, test_case_id=journey["cases"][0].id)

    assert impact.found
    assert impact.business_flow["name"] == "Probe journey"
    assert [step["key"] for step in impact.downstream_steps] == ["probe-review-basket", "probe-checkout"]
    # The tests covering later steps are what would notice a bad repair.
    assert {item["test_case_id"] for item in impact.validation_tests} >= {
        journey["cases"][1].id,
        journey["cases"][2].id,
    }


def test_downstream_business_assertions_are_surfaced(db, project_id: str, journey) -> None:
    """These are outcomes healing may never touch, and exactly what a repair is
    validated against."""
    impact = assess(db, project_id=project_id, test_case_id=journey["cases"][0].id)
    assert "The amount charged equals the basket total." in impact.business_assertions


def test_a_repair_late_in_a_journey_reaches_less(db, project_id: str, journey) -> None:
    early = assess(db, project_id=project_id, test_case_id=journey["cases"][0].id)
    late = assess(db, project_id=project_id, test_case_id=journey["cases"][2].id)

    assert len(late.downstream_steps) < len(early.downstream_steps)
    assert late.risk_score < early.risk_score


def test_criticality_raises_the_risk_of_the_same_change(db, project_id: str, journey) -> None:
    before = assess(db, project_id=project_id, test_case_id=journey["cases"][0].id).risk_score
    journey["flow"].criticality = "low"
    db.flush()
    after = assess(db, project_id=project_id, test_case_id=journey["cases"][0].id).risk_score
    assert after < before


def test_a_test_in_no_journey_reports_nothing_rather_than_guessing(
    db, project_id: str
) -> None:
    """Without a journey the platform does not know what else this touches, and
    saying so is better than implying coverage it does not have."""
    orphan = db.execute(
        select(TestCase).where(TestCase.project_id == project_id).limit(1)
    ).scalars().first()
    impact = assess(db, project_id=project_id, test_case_id=orphan.id)
    if not impact.found:
        assert impact.validation_tests == []
        assert impact.business_assertions == []
        assert impact.risk_score == 0.0


# ---------------------------------------------------------------------------
# Choosing a suite from a change
# ---------------------------------------------------------------------------


def test_a_changed_component_selects_its_step_and_everything_after(
    db, project_id: str, journey
) -> None:
    result = select_for_change(
        db, project_id=project_id, changed_components=["probe-add-to-cart-btn"]
    )
    assert result["steps_changed"] == 1
    # The change is at the first step, so the whole journey is at risk.
    assert result["steps_at_risk"] == 3
    assert "Probe journey" in result["journeys"]


def test_every_selection_says_why(db, project_id: str, journey) -> None:
    """A suite nobody can argue with is a suite nobody can trust."""
    result = select_for_change(
        db, project_id=project_id, changed_components=["probe-add-to-cart-btn"]
    )
    assert result["selected"]
    for item in result["selected"]:
        assert item["selected_because"]
    reasons = {item["selected_because"] for item in result["selected"]}
    assert any("changed UI component" in reason for reason in reasons)
    assert any("downstream of" in reason for reason in reasons)


def test_a_changed_endpoint_selects_too(db, project_id: str, journey) -> None:
    result = select_for_change(
        db, project_id=project_id, changed_endpoints=["/api/probe-checkout"]
    )
    assert result["steps_changed"] == 1
    assert any("API endpoint" in item["selected_because"] for item in result["selected"])


def test_a_change_no_journey_covers_selects_nothing_and_says_so(
    db, project_id: str, journey
) -> None:
    result = select_for_change(
        db, project_id=project_id, changed_components=["something-nobody-modelled"]
    )
    assert result["selected"] == []
    assert "No business flow covers" in result["reason"]


def test_selection_is_reported_as_journey_based(db, project_id: str, journey) -> None:
    result = select_for_change(db, project_id=project_id, changed_components=["probe-basket-total"])
    assert result["selected_by"] == "business_flow"


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------


def test_the_journeys_are_readable(client, auth_headers, project_id: str) -> None:
    response = client.get(
        "/api/v1/business-flows", headers=auth_headers, params={"project_id": project_id}
    )
    assert response.status_code == 200, response.text
    flows = response.json()
    assert flows, "the demo project should have seeded journeys"
    payment = next(flow for flow in flows if flow["key"] == "payment-journey")
    assert payment["criticality"] == "critical"
    assert [step["key"] for step in payment["steps"]][:2] == ["sign-in", "choose-beneficiary"]
    # Business assertions travel with the step, so a reader can see what may
    # never be healed.
    assert any(step["assertions"] for step in payment["steps"])


def test_impact_is_queryable_by_component(client, auth_headers, project_id: str) -> None:
    response = client.get(
        "/api/v1/impact",
        headers=auth_headers,
        params={"project_id": project_id, "component": "checkout-submit-btn"},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["business_flow"]["key"] == "payment-journey"
    assert body["step"]["key"] == "confirm-payment"


def test_selection_is_available_to_a_pipeline(client, auth_headers, project_id: str) -> None:
    response = client.post(
        "/api/v1/impact/select",
        headers=auth_headers,
        params={"project_id": project_id},
        json={"changed_components": ["pay-now"]},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["selected_by"] == "business_flow"
    assert "Make a payment" in body["journeys"]
