"""The healing strategy ladder, and timing repair.

Two things are being pinned here.

The ladder must be **walked**, in order, stopping at the first rung that
answers — and it must record what it tried. "Healed at `test_id`, rung 2 of 9,
after `known_healing` found nothing" is checkable; "the AI suggested this" is not.

Timing repair must be kept apart from locator repair. An element that is late
and an element that is gone look identical to a test, and they need opposite
fixes: waiting longer, or looking somewhere else. Confusing them means either
rewriting a locator that was always correct, or waiting forever for something
that will never arrive.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import select

from app.healing.config import HealingConfig
from app.healing.dom import candidates_by_strategy, parse_page
from app.healing.policy import ChangeType
from app.healing.strategies import RUNG_STRATEGIES, StrategyLadder, propose_wait
from app.models.testing import HealingRecord

DEMO_APP = Path(__file__).resolve().parents[1] / "app" / "demo_app" / "static"
V1 = (DEMO_APP / "v1" / "checkout.html").read_text(encoding="utf-8")
V2 = (DEMO_APP / "v2" / "checkout.html").read_text(encoding="utf-8")

ORIGINAL = 'page.get_by_test_id("checkout-submit-btn")'


def fingerprint(test_id: str) -> dict:
    elements, labels = parse_page(V1)
    element = next(item for item in elements if item.test_id == test_id)
    return element.fingerprint(labels)


# ---------------------------------------------------------------------------
# Candidates per strategy
# ---------------------------------------------------------------------------


def test_candidates_can_be_asked_for_by_strategy() -> None:
    finger = fingerprint("checkout-submit-btn")
    by_role = candidates_by_strategy(V2, finger, strategies=("role",))
    assert by_role
    assert {item["strategy"] for item in by_role} == {"role"}
    assert 'get_by_role("button", name="Pay now")' in by_role[0]["locator"]


def test_asking_for_a_strategy_the_page_cannot_offer_returns_nothing() -> None:
    """Not an error, and not a substitute from another rung."""
    finger = fingerprint("checkout-submit-btn")
    assert candidates_by_strategy(V2, finger, strategies=("placeholder",)) == []


def test_every_dom_rung_maps_to_real_strategies() -> None:
    from app.healing.dom import locator_expressions  # noqa: PLC0415

    elements, labels = parse_page(V2)
    produced = {
        strategy
        for element in elements
        for strategy, _, _ in locator_expressions(element, labels)
    }
    for rung, strategies in RUNG_STRATEGIES.items():
        assert set(strategies) & produced, f"rung {rung} maps to strategies nothing emits"


# ---------------------------------------------------------------------------
# Walking the ladder
# ---------------------------------------------------------------------------


def test_the_ladder_stops_at_the_first_rung_that_answers(db, project_id: str) -> None:
    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint=fingerprint("checkout-submit-btn"),
        dom_html=V2,
    )
    assert result.found
    assert result.resolved_by == "test_id"
    # It tried the cheaper rung first and moved on when it had nothing.
    assert "known_healing" in result.rungs_tried
    assert result.rungs_tried.index("known_healing") < result.rungs_tried.index("test_id")
    # Rungs after the one that answered were never reached.
    assert "text_content" not in result.rungs_tried


def test_a_previous_successful_heal_wins_over_searching_the_page(db, project_id: str) -> None:
    """The cheapest rung is also the best evidence: a replacement that already
    survived a re-run beats any amount of DOM similarity."""
    db.add(
        HealingRecord(
            project_id=project_id,
            status="applied",
            validation_status="passed",
            failure_class="locator_drift",
            change_type=ChangeType.LOCATOR,
            original_locator=ORIGINAL,
            proposed_locator='page.get_by_test_id("pay-now")',
            locator_strategy="test_id",
            reason="Healed previously and it held.",
            confidence=0.96,
        )
    )
    db.flush()

    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint=fingerprint("checkout-submit-btn"),
        dom_html=V2,
    )
    assert result.resolved_by == "known_healing"
    assert result.rungs_tried == ["known_healing"]
    assert 'get_by_test_id("pay-now")' in result.candidates[0]["locator"]


def test_a_remembered_heal_is_dropped_when_it_is_no_longer_on_the_page(
    db, project_id: str
) -> None:
    """A repair that worked before says nothing about a page that has changed
    again. Offering a locator we can see is absent would waste a re-run."""
    db.add(
        HealingRecord(
            project_id=project_id,
            status="applied",
            validation_status="passed",
            failure_class="locator_drift",
            change_type=ChangeType.LOCATOR,
            original_locator=ORIGINAL,
            # Was right once; this element does not exist in v2.
            proposed_locator='page.get_by_test_id("checkout-submit")',
            locator_strategy="test_id",
            reason="Healed against an older version of the page.",
            confidence=0.96,
        )
    )
    db.flush()

    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint=fingerprint("checkout-submit-btn"),
        dom_html=V2,
    )
    assert result.resolved_by == "test_id", "the stale memory should not have answered"
    assert "checkout-submit\"" not in result.candidates[0]["locator"]
    assert 'get_by_test_id("pay-now")' in result.candidates[0]["locator"]


def test_a_heal_that_did_not_hold_is_not_reused(db, project_id: str) -> None:
    """Only heals that passed their re-run count as precedent."""
    db.add(
        HealingRecord(
            project_id=project_id,
            status="rolled_back",
            validation_status="failed",
            failure_class="locator_drift",
            change_type=ChangeType.LOCATOR,
            original_locator=ORIGINAL,
            proposed_locator='page.get_by_test_id("cancel-checkout")',
            locator_strategy="test_id",
            reason="Tried before; the re-run failed.",
            confidence=0.9,
        )
    )
    db.flush()

    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint=fingerprint("checkout-submit-btn"),
        dom_html=V2,
    )
    assert result.resolved_by != "known_healing"
    assert "cancel-checkout" not in result.candidates[0]["locator"]


def test_without_a_captured_page_the_dom_rungs_are_skipped_not_failed(db, project_id: str) -> None:
    """Skipped and tried-and-empty are different facts, and the record says which."""
    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint=fingerprint("checkout-submit-btn"),
        dom_html=None,
    )
    assert not result.found
    assert "test_id" in result.rungs_skipped
    assert "test_id" not in result.rungs_tried


def test_unimplemented_rungs_are_reported_as_skipped(db, project_id: str) -> None:
    """`visual` and `llm_assisted` are not wired up. Saying so is honest; quietly
    omitting them from the record would not be."""
    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator="page.get_by_test_id('nothing-like-this')",
        fingerprint={"tag": "button", "role": "button", "name": "Nowhere", "test_id": "nope"},
        dom_html=V2,
    )
    assert not result.found
    assert "visual" in result.rungs_skipped
    assert "llm_assisted" in result.rungs_skipped


def test_the_ladder_explains_itself(db, project_id: str) -> None:
    config = HealingConfig()
    result = StrategyLadder(db, config=config).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint=fingerprint("checkout-submit-btn"),
        dom_html=V2,
    )
    detail = result.evidence(config.strategy_ladder)["detail"]
    assert "rung 2 of 9" in detail
    assert "known_healing" in detail


def test_an_exhausted_ladder_says_so(db, project_id: str) -> None:
    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator=ORIGINAL,
        fingerprint={"tag": "button", "role": "button", "name": "Download invoice", "test_id": "inv"},
        dom_html=V2,
    )
    assert not result.found
    assert "No strategy produced a candidate" in result.evidence(HealingConfig().strategy_ladder)["detail"]


# ---------------------------------------------------------------------------
# Timing repair
# ---------------------------------------------------------------------------


def test_a_wait_is_proposed_from_what_was_measured() -> None:
    proposal = propose_wait(observed_wait_ms=2400, current_timeout_ms=500)
    assert proposal is not None
    assert proposal["change_type"] == ChangeType.TIMING
    assert proposal["observed_wait_ms"] == 2400
    # Headroom over the observed time, because a page slow once is slower later.
    assert proposal["wait_ms"] == 6000
    assert "2400ms" in proposal["rationale"]


def test_a_proposed_wait_never_exceeds_the_configured_ceiling() -> None:
    """A repair must not turn a fast suite into a slow one."""
    config = HealingConfig(max_wait_ms=5_000)
    proposal = propose_wait(observed_wait_ms=4_000, current_timeout_ms=500, config=config)
    assert proposal["wait_ms"] == 5_000


def test_no_wait_is_proposed_when_the_element_never_appeared() -> None:
    """Nothing was measured, so there is nothing to base a wait on. That is a
    locator problem, and the ladder should handle it instead."""
    assert propose_wait(observed_wait_ms=None, current_timeout_ms=500) is None
    assert propose_wait(observed_wait_ms=0, current_timeout_ms=500) is None


def test_no_wait_is_proposed_when_the_test_already_waits_long_enough() -> None:
    """The element arrived inside the existing budget, so waiting is not the fix."""
    assert propose_wait(observed_wait_ms=200, current_timeout_ms=10_000) is None


def test_an_element_that_needs_nearly_the_whole_budget_scores_lower() -> None:
    """Papering over a performance problem should not look like a confident fix."""
    config = HealingConfig(max_wait_ms=10_000)
    quick = propose_wait(observed_wait_ms=800, current_timeout_ms=200, config=config)
    slow = propose_wait(observed_wait_ms=9_000, current_timeout_ms=200, config=config)
    assert quick["confidence"] > slow["confidence"]
    assert slow["confidence"] >= 0.55


def test_timing_confidence_is_not_diluted_by_locator_signals() -> None:
    """A timing repair chooses no locator, so accessibility strength and DOM
    similarity say nothing about it. Feeding them in at a default quietly
    lowered the score for no defensible reason."""
    config = HealingConfig()
    proposal = propose_wait(observed_wait_ms=2_400, current_timeout_ms=500, config=config)

    measured = {"strategy_robustness": proposal["confidence"], **proposal["signals"]}
    assert "accessibility_match" not in measured
    assert "dom_similarity" not in measured
    assert config.score(measured) > 0.8


# ---------------------------------------------------------------------------
# Applying a timing repair
# ---------------------------------------------------------------------------


def test_a_timing_patch_keeps_the_locator_and_carries_a_wait(db, project_id: str) -> None:
    from app.healing.validation import build_patch  # noqa: PLC0415

    record = HealingRecord(
        project_id=project_id,
        status="approved",
        failure_class="timing",
        change_type=ChangeType.TIMING,
        original_locator='page.get_by_test_id("loyalty-points")',
        proposed_locator="wait for the element to be attached, up to 6000ms",
        locator_strategy="explicit_wait",
        reason="It appeared after 2400ms.",
        confidence=0.88,
        policy_decision={"wait_ms": 6000},
    )
    db.add(record)
    db.flush()

    patch = build_patch(record)
    assert patch["change_type"] == "timing"
    assert patch["wait_ms"] == 6000
    # The locator was never wrong, so the patch keeps pointing at it.
    assert patch["locator"] == 'page.get_by_test_id("loyalty-points")'


def test_applying_a_timing_heal_does_not_overwrite_the_locator(db, project_id: str) -> None:
    """The bug this guards: writing the wait description into the locator field
    would destroy a locator that was correct all along."""
    from app.healing.validation import HealingValidationService  # noqa: PLC0415

    record = HealingRecord(
        project_id=project_id,
        status="approved",
        failure_class="timing",
        change_type=ChangeType.TIMING,
        original_locator='page.get_by_test_id("loyalty-points")',
        proposed_locator="wait for the element to be attached, up to 6000ms",
        locator_strategy="explicit_wait",
        reason="It appeared after 2400ms.",
        confidence=0.88,
        policy_decision={"wait_ms": 6000},
    )
    entry = {"name": "loyalty", "strategy": "test_id",
             "locator": 'page.get_by_test_id("loyalty-points")'}

    updated = HealingValidationService._apply_to_locator(record, entry)  # noqa: SLF001

    assert updated["locator"] == 'page.get_by_test_id("loyalty-points")'
    assert updated["strategy"] == "test_id"
    assert updated["wait_ms"] == 6000


def test_applying_a_locator_heal_still_replaces_the_locator(db, project_id: str) -> None:
    from app.healing.validation import HealingValidationService  # noqa: PLC0415

    record = HealingRecord(
        project_id=project_id,
        status="approved",
        failure_class="locator_drift",
        change_type=ChangeType.LOCATOR,
        original_locator=ORIGINAL,
        proposed_locator='page.get_by_test_id("pay-now")',
        locator_strategy="test_id",
        reason="Renamed in the redesign.",
        confidence=0.94,
    )
    entry = {"name": "submit", "strategy": "test_id", "locator": ORIGINAL}

    updated = HealingValidationService._apply_to_locator(record, entry)  # noqa: SLF001
    assert updated["locator"] == 'page.get_by_test_id("pay-now")'


def test_timing_is_a_permitted_change_type() -> None:
    """It goes through the same gate as every other repair."""
    from app.healing.policy import evaluate_change  # noqa: PLC0415

    gate = evaluate_change(change_type=ChangeType.TIMING, confidence=0.9)
    assert gate.allowed is True
    assert gate.requires_approval is False

    # And it is still not a licence to change what the test asserts.
    assert evaluate_change(change_type=ChangeType.ASSERTION, confidence=0.99).allowed is False


@pytest.mark.parametrize("rung", ["known_healing", "test_id", "accessibility_role", "label"])
def test_the_configured_ladder_contains_the_rungs_that_are_implemented(rung: str) -> None:
    assert rung in HealingConfig().strategy_ladder
