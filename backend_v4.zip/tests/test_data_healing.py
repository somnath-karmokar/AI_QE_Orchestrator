"""Repairing a test whose data ran out.

The failure this addresses is common and badly served: the account was closed
overnight, the voucher was redeemed, the record was cleaned up. The test is
correct and so is the application.

What must not happen is a substitution that quietly changes what was tested — a
gold-tier test rerun on a standard-tier account is a different test, and a green
result from it means nothing.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.healing.data import (
    extract_reference,
    find_substitute,
    propose_substitution,
)
from app.healing.policy import ChangeType, evaluate_change
from app.models.testing import TestDataSet


@pytest.fixture
def dataset(db, project_id: str) -> TestDataSet:
    """A pool with one exhausted record and several candidates."""
    row = TestDataSet(
        project_id=project_id,
        name="Loyalty accounts",
        module="Payments",
        data_type="synthetic",
        records=[
            # The one the test used, now closed.
            {"account_ref": "LOY-2210", "tier": "gold", "currency": "GBP",
             "limit": 5000, "account_status": "CLOSED"},
            # Same characteristics, available -- the honest substitute.
            {"account_ref": "LOY-4471", "tier": "gold", "currency": "GBP",
             "limit": 5000, "account_status": "ACTIVE"},
            # Different tier: not the same test.
            {"account_ref": "LOY-9000", "tier": "standard", "currency": "GBP",
             "limit": 5000, "account_status": "ACTIVE"},
            # Right characteristics, but itself unusable.
            {"account_ref": "LOY-7777", "tier": "gold", "currency": "GBP",
             "limit": 5000, "account_status": "EXPIRED"},
        ],
        record_count=4,
    )
    db.add(row)
    db.flush()
    return row


# ---------------------------------------------------------------------------
# Reading the failure
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("message", "expected"),
    [
        ("Precondition failed: the loyalty account LOY-2210 is closed", "LOY-2210"),
        ("No such record for ACCO-1042", "ACCO-1042"),
        ("Card 4111111111111111 was declined: expired", "4111111111111111"),
        ("Voucher SUMMER_2026 has already been redeemed", "SUMMER_2026"),
    ],
)
def test_the_failing_record_is_read_from_the_message(message: str, expected: str) -> None:
    assert extract_reference(message) == expected


def test_a_message_naming_no_record_yields_nothing() -> None:
    """Without knowing which record ran out there is nothing to substitute, and
    saying so is better than guessing at one."""
    assert extract_reference("Precondition failed") is None
    assert extract_reference(None) is None


# ---------------------------------------------------------------------------
# Finding an honest substitute
# ---------------------------------------------------------------------------


def test_an_equivalent_available_record_is_found(db, project_id: str, dataset) -> None:
    substitute = find_substitute(
        db, project_id=project_id, module="Payments", failed_reference="LOY-2210"
    )
    assert substitute is not None
    assert substitute["to_reference"] == "LOY-4471"
    assert substitute["matched_on"] == ["currency", "limit", "tier"]


def test_a_record_with_different_characteristics_is_not_substituted(
    db, project_id: str, dataset
) -> None:
    """The heart of it: a standard-tier account is not a gold-tier account, and
    passing on one says nothing about the other."""
    substitute = find_substitute(
        db, project_id=project_id, module="Payments", failed_reference="LOY-2210"
    )
    assert substitute["to_reference"] != "LOY-9000"


def test_an_unusable_record_is_not_offered_as_a_substitute(
    db, project_id: str, dataset
) -> None:
    substitute = find_substitute(
        db, project_id=project_id, module="Payments", failed_reference="LOY-2210"
    )
    assert substitute["to_reference"] != "LOY-7777"


def test_no_substitute_is_invented_when_none_is_equivalent(db, project_id: str) -> None:
    db.add(
        TestDataSet(
            project_id=project_id,
            name="Single account",
            module="Payments",
            records=[
                {"account_ref": "SOLO-1", "tier": "platinum", "account_status": "CLOSED"}
            ],
            record_count=1,
        )
    )
    db.flush()
    assert (
        find_substitute(db, project_id=project_id, module="Payments", failed_reference="SOLO-1")
        is None
    )


def test_an_unknown_record_yields_no_substitute(db, project_id: str, dataset) -> None:
    """If we cannot find what failed, we cannot say what would be equivalent."""
    assert (
        find_substitute(
            db, project_id=project_id, module="Payments", failed_reference="NOT-A-RECORD"
        )
        is None
    )


def test_identity_is_recognised_in_realistic_schemas(db, project_id: str) -> None:
    """Real fixtures use `user_id` and `account_status`, not `id` and `status`."""
    db.add(
        TestDataSet(
            project_id=project_id,
            name="Realistic",
            module="Login",
            records=[
                {"user_id": "ZUSER-1000", "tier": "gold", "account_status": "LOCKED"},
                {"user_id": "ZUSER-1001", "tier": "gold", "account_status": "ACTIVE"},
            ],
            record_count=2,
        )
    )
    db.flush()
    substitute = find_substitute(
        db, project_id=project_id, module="Login", failed_reference="ZUSER-1000"
    )
    assert substitute["to_reference"] == "ZUSER-1001"


# ---------------------------------------------------------------------------
# The proposal
# ---------------------------------------------------------------------------


def test_a_substitution_is_proposed_as_a_test_data_change(db, project_id: str, dataset) -> None:
    proposal = propose_substitution(
        db,
        project_id=project_id,
        module="Payments",
        failure_message="Precondition failed: the loyalty account LOY-2210 is closed",
    )
    assert proposal is not None
    assert proposal["change_type"] == ChangeType.TEST_DATA
    assert proposal["from"] == "LOY-2210"
    assert proposal["to"] == "LOY-4471"
    assert "tier" in proposal["rationale"]
    assert "a person approves this" in proposal["rationale"]


def test_matching_on_more_characteristics_raises_confidence(
    db, project_id: str, dataset
) -> None:
    db.add(
        TestDataSet(
            project_id=project_id,
            name="Thin",
            module="Payments",
            records=[
                {"ref": "THIN-1", "account_status": "CLOSED"},
                {"ref": "THIN-2", "account_status": "ACTIVE"},
            ],
            record_count=2,
        )
    )
    db.flush()

    thin = propose_substitution(
        db, project_id=project_id, module="Payments",
        failure_message="Record THIN-1 is closed",
    )
    rich = propose_substitution(
        db, project_id=project_id, module="Payments",
        failure_message="Record LOY-2210 is closed",
    )
    assert thin is not None and rich is not None
    # Matching on nothing but shape is a weaker claim to equivalence.
    assert rich["confidence"] > thin["confidence"]


def test_a_data_substitution_always_needs_a_person(db, project_id: str, dataset) -> None:
    """However confident, and whatever the deployment's threshold."""
    proposal = propose_substitution(
        db, project_id=project_id, module="Payments",
        failure_message="Account LOY-2210 is closed",
    )
    gate = evaluate_change(change_type=ChangeType.TEST_DATA, confidence=0.99)
    assert gate.allowed is True
    assert gate.requires_approval is True
    assert proposal["confidence"] < 1.0


# ---------------------------------------------------------------------------
# Applying it
# ---------------------------------------------------------------------------


def test_the_patch_carries_the_substitute_and_not_a_locator(db, project_id: str, dataset) -> None:
    from app.healing.validation import build_patch  # noqa: PLC0415
    from app.models.testing import HealingRecord  # noqa: PLC0415

    record = HealingRecord(
        project_id=project_id,
        status="approved",
        failure_class="test_data",
        change_type=ChangeType.TEST_DATA,
        original_locator="LOY-2210",
        proposed_locator="LOY-4471",
        locator_strategy="equivalent_record",
        reason="Equivalent gold-tier account.",
        confidence=0.9,
        policy_decision={"dataset_id": dataset.id, "substitute_reference": "LOY-4471"},
    )
    db.add(record)
    db.flush()

    patch = build_patch(record)
    assert patch["change_type"] == "test_data"
    assert patch["substitute_reference"] == "LOY-4471"
    assert patch["dataset_id"] == dataset.id
    assert "wait_ms" not in patch


def test_an_applied_substitution_retires_the_exhausted_record(
    db, project_id: str, dataset
) -> None:
    """Otherwise the same failure returns tomorrow and the heal looks unreliable
    when nothing had actually changed."""
    from app.healing.validation import HealingValidationService, ValidationOutcome  # noqa: PLC0415
    from app.models.testing import HealingRecord  # noqa: PLC0415

    record = HealingRecord(
        project_id=project_id,
        status="validating",
        failure_class="test_data",
        change_type=ChangeType.TEST_DATA,
        original_locator="LOY-2210",
        proposed_locator="LOY-4471",
        locator_strategy="equivalent_record",
        reason="Equivalent gold-tier account.",
        confidence=0.9,
        policy_decision={"dataset_id": dataset.id, "substitute_reference": "LOY-4471"},
    )
    db.add(record)
    db.flush()

    service = HealingValidationService(db)
    service._persist(  # noqa: SLF001
        record, ValidationOutcome(status="passed", mode="simulated", result="passed")
    )
    db.refresh(dataset)

    retired = next(
        item for item in dataset.records if item.get("account_ref") == "LOY-2210"
    )
    assert retired["status"] == "exhausted"
    # The substitute is untouched and still available.
    substitute = next(
        item for item in dataset.records if item.get("account_ref") == "LOY-4471"
    )
    assert substitute["account_status"] == "ACTIVE"


def test_a_data_heal_leaves_the_test_script_alone(db, project_id: str, dataset) -> None:
    """Nothing about the test was wrong, so nothing about it changes."""
    from app.healing.validation import HealingValidationService, ValidationOutcome  # noqa: PLC0415
    from app.models.testing import HealingRecord, TestScript  # noqa: PLC0415

    script = db.execute(
        select(TestScript).where(TestScript.project_id == project_id)
    ).scalars().first()
    assert script is not None
    version_before = script.version
    locators_before = list(script.locators or [])

    record = HealingRecord(
        project_id=project_id,
        test_script_id=script.id,
        status="validating",
        failure_class="test_data",
        change_type=ChangeType.TEST_DATA,
        original_locator="LOY-2210",
        proposed_locator="LOY-4471",
        locator_strategy="equivalent_record",
        reason="Equivalent gold-tier account.",
        confidence=0.9,
        policy_decision={"dataset_id": dataset.id, "substitute_reference": "LOY-4471"},
    )
    db.add(record)
    db.flush()

    HealingValidationService(db)._persist(  # noqa: SLF001
        record, ValidationOutcome(status="passed", mode="simulated", result="passed")
    )
    db.refresh(script)

    assert script.version == version_before
    assert script.locators == locators_before
    assert record.status == "applied"
