"""Real evidence, and healing that reasons over it.

These tests run against the two versions of the demo checkout page shipped in
`app/demo_app`. That markup is the real thing a browser serves, so the drift
between v1 and v2 is real drift -- a renamed `data-testid` with the accessible
role and name left intact -- and healing has to cope with it for real.

No browser is needed here: the pages are parsed from disk, which keeps the suite
fast and deterministic. The browser itself is exercised separately.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app.execution.browser import PageCapture, evidence_files, parse_locator
from app.healing.dom import (
    candidates_from_dom,
    locator_expressions,
    normalise_fingerprint,
    parse_page,
)

DEMO_APP = Path(__file__).resolve().parents[1] / "app" / "demo_app" / "static"
V1 = (DEMO_APP / "v1" / "checkout.html").read_text(encoding="utf-8")
V2 = (DEMO_APP / "v2" / "checkout.html").read_text(encoding="utf-8")


def fingerprint_from_v1(test_id: str) -> dict:
    """What an element looked like while the original locator still resolved."""
    elements, labels = parse_page(V1)
    element = next(item for item in elements if item.test_id == test_id)
    return element.fingerprint(labels)


# ---------------------------------------------------------------------------
# Locator expressions are re-issued, never evaluated
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("expression", "expected"),
    [
        ('page.get_by_test_id("pay-now")', ("get_by_test_id", ["pay-now"], {})),
        ('page.get_by_role("button", name="Pay now")', ("get_by_role", ["button"], {"name": "Pay now"})),
        ('page.get_by_label("Promo code")', ("get_by_label", ["Promo code"], {})),
        ('page.locator("#field-promo")', ("locator", ["#field-promo"], {})),
        ('page.get_by_text("Continue", exact=False)', ("get_by_text", ["Continue"], {"exact": False})),
    ],
)
def test_supported_locators_are_parsed(expression: str, expected: tuple) -> None:
    assert parse_locator(expression) == expected


@pytest.mark.parametrize(
    "expression",
    [
        'page.evaluate("fetch(\'/steal\')")',            # not a locator at all
        'page.goto("http://elsewhere.example")',         # navigation, not resolution
        '__import__("os").system("echo hi")',            # not even a page call
        "",
    ],
)
def test_expressions_that_are_not_locators_are_refused(expression: str) -> None:
    """Stored expressions are re-issued through the API, never executed, so
    anything the runner cannot re-issue is reported rather than run."""
    assert parse_locator(expression) is None


# ---------------------------------------------------------------------------
# Reading a captured page
# ---------------------------------------------------------------------------


def test_implicit_roles_and_accessible_names_are_read() -> None:
    elements, labels = parse_page(V2)
    button = next(item for item in elements if item.test_id == "pay-now")
    assert button.role == "button"          # implicit, never spelled out in the markup
    assert button.accessible_name(labels) == "Pay now"

    promo = next(item for item in elements if item.test_id == "discount-code")
    assert promo.role == "textbox"
    assert promo.accessible_name(labels) == "Promo code"   # from its <label for>


def test_locator_expressions_follow_the_ladder() -> None:
    elements, labels = parse_page(V2)
    button = next(item for item in elements if item.test_id == "pay-now")
    strategies = [strategy for strategy, _, _ in locator_expressions(button, labels)]
    assert strategies[0] == "test_id"
    assert "role" in strategies
    assert strategies.index("test_id") < strategies.index("role")


def test_fingerprint_keeps_the_implicit_role_and_name() -> None:
    """The bug this guards: a raw capture reports role=null for a <button> and
    carries no accessible name, which left matching comparing test-id spellings
    and picking the wrong control."""
    raw = {
        "tag": "button",
        "role": None,
        "test_id": "checkout-submit-btn",
        "text": "Pay now",
        "aria_label": None,
        "label": None,
        "classes": ["btn-primary"],
    }
    fingerprint = normalise_fingerprint(raw)
    assert fingerprint["role"] == "button"
    assert fingerprint["name"] == "Pay now"


def test_fingerprint_reads_an_inputs_label_as_its_name() -> None:
    fingerprint = normalise_fingerprint(
        {"tag": "input", "type": "text", "label": "Promo code", "text": ""}
    )
    assert fingerprint["role"] == "textbox"
    assert fingerprint["name"] == "Promo code"


# ---------------------------------------------------------------------------
# Healing the real drift between v1 and v2
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("original_test_id", "expected_test_id"),
    [
        ("checkout-submit-btn", "pay-now"),
        ("promo-code", "discount-code"),
        ("cancel-order", "cancel-checkout"),
        ("card-number", "card-number-input"),
    ],
)
def test_renamed_test_ids_heal_to_the_right_element(
    original_test_id: str, expected_test_id: str
) -> None:
    """The accessible role and name survived the redesign, so the right element
    is findable even though every test id changed."""
    candidates = candidates_from_dom(V2, fingerprint_from_v1(original_test_id), limit=4)
    assert candidates, f"no candidate found for {original_test_id}"
    assert expected_test_id in candidates[0]["locator"], (
        f"expected {expected_test_id}, got {candidates[0]['locator']}"
    )


def test_the_winner_is_separated_from_the_runner_up() -> None:
    """A correct answer that ties with a wrong one is not much use: the gate
    would send it to a human anyway."""
    candidates = candidates_from_dom(V2, fingerprint_from_v1("checkout-submit-btn"), limit=4)
    assert len(candidates) >= 2
    assert candidates[0]["confidence"] > candidates[1]["confidence"]


def test_candidates_carry_the_signals_behind_their_score() -> None:
    best = candidates_from_dom(V2, fingerprint_from_v1("promo-code"), limit=1)[0]
    assert best["signals"]["text_similarity"] == pytest.approx(1.0)
    assert best["signals"]["accessibility_match"] == pytest.approx(1.0)
    assert "captured when the test failed" in best["rationale"]


def test_an_element_that_is_gone_produces_no_candidate() -> None:
    """Healing has to be able to say "it is not there" rather than invent one."""
    absent = {"tag": "button", "role": "button", "name": "Download invoice PDF", "test_id": "invoice-pdf"}
    assert candidates_from_dom(V2, absent) == []


def test_nothing_is_proposed_from_an_empty_page() -> None:
    assert candidates_from_dom("", fingerprint_from_v1("checkout-submit-btn")) == []


def test_a_locator_that_still_works_is_not_drift() -> None:
    """Sanity check on the demo data itself: the role-based locator survives the
    redesign, which is the whole reason the ladder prefers it."""
    elements, labels = parse_page(V2)
    button = next(item for item in elements if item.test_id == "pay-now")
    assert button.accessible_name(labels) == "Pay now"

    elements_v1, labels_v1 = parse_page(V1)
    original = next(item for item in elements_v1 if item.test_id == "checkout-submit-btn")
    assert original.accessible_name(labels_v1) == "Pay now"


# ---------------------------------------------------------------------------
# Artefacts are real files, and say so
# ---------------------------------------------------------------------------


def test_only_files_that_exist_are_recorded(tmp_path: Path) -> None:
    capture = PageCapture(url="http://example.test/checkout")
    (tmp_path / "shot-screenshot.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"0" * 64)
    (tmp_path / "shot-dom.html").write_text("<html></html>", encoding="utf-8")
    # No accessibility or trace file was written.

    rows = evidence_files(capture, tmp_path, "shot")
    kinds = {row["artifact_type"] for row in rows}
    assert kinds == {"screenshot", "dom_snapshot"}
    for row in rows:
        assert row["size_bytes"] > 0
        # The claim that mattered: this one is genuinely on disk.
        assert row["metadata"]["materialized"] is True


def test_no_artifacts_are_claimed_when_nothing_was_written(tmp_path: Path) -> None:
    assert evidence_files(PageCapture(), tmp_path, "shot") == []


# ---------------------------------------------------------------------------
# Retention
# ---------------------------------------------------------------------------


def test_retention_removes_the_files_as_well_as_the_rows(db, project_id: str, tmp_path: Path) -> None:
    """A row pointing at a file nobody kept is worse than no row."""
    from datetime import UTC, datetime, timedelta  # noqa: PLC0415

    from sqlalchemy import select  # noqa: PLC0415

    from app.execution.retention import sweep_expired_evidence  # noqa: PLC0415
    from app.models.testing import Execution, ExecutionArtifact  # noqa: PLC0415

    execution = db.execute(
        select(Execution).where(Execution.project_id == project_id)
    ).scalars().first()
    assert execution is not None

    # Inside the project's own storage directory, which is where evidence
    # actually lives -- the sweep refuses to unlink anything outside it.
    from app.core.storage import execution_dir  # noqa: PLC0415

    stale_file = execution_dir(project_id, execution.id) / "old-trace.zip"
    stale_file.write_bytes(b"0" * 128)
    old = datetime.now(UTC) - timedelta(days=400)

    artifact = ExecutionArtifact(
        execution_id=execution.id,
        artifact_type="trace",
        name="old-trace.zip",
        storage_path=str(stale_file),
        content_type="application/zip",
        size_bytes=128,
        artifact_metadata={"materialized": True},
    )
    db.add(artifact)
    db.flush()
    artifact.created_at = old
    db.flush()

    summary = sweep_expired_evidence(db)

    assert summary["artifacts"] >= 1
    assert not stale_file.exists(), "the file should have been deleted, not just the row"
    assert db.get(ExecutionArtifact, artifact.id) is None


def test_retention_will_not_delete_a_file_outside_tenant_storage(db, tmp_path: Path, project_id) -> None:  # noqa: ANN001
    """The sweep unlinks whatever path a row holds, so the path has to be bounded.

    A stored path that points somewhere else -- through a bug, a bad import or a
    tampered row -- must leave that file alone. Otherwise the retention job is
    an arbitrary-file-delete waiting for a wrong value.
    """
    from datetime import UTC, datetime, timedelta  # noqa: PLC0415

    from sqlalchemy import select  # noqa: PLC0415

    from app.execution.retention import sweep_expired_evidence  # noqa: PLC0415
    from app.models.testing import Execution, ExecutionArtifact  # noqa: PLC0415

    execution = db.execute(
        select(Execution).where(Execution.project_id == project_id)
    ).scalars().first()

    innocent = tmp_path / "somebody-elses-file.txt"
    innocent.write_text("not ours to delete", encoding="utf-8")

    artifact = ExecutionArtifact(
        execution_id=execution.id,
        artifact_type="trace",
        name="escaped.zip",
        storage_path=str(innocent),
        content_type="application/zip",
        size_bytes=18,
        artifact_metadata={"materialized": True},
    )
    db.add(artifact)
    db.flush()
    artifact.created_at = datetime.now(UTC) - timedelta(days=400)
    db.flush()

    sweep_expired_evidence(db)

    assert innocent.exists(), "a path outside tenant storage must not be deleted"
    # The row is still cleaned up: the point is to stop the unlink, not to keep
    # a stale record forever.
    assert db.get(ExecutionArtifact, artifact.id) is None


def test_retention_of_zero_days_keeps_everything(db, tmp_path: Path, monkeypatch) -> None:
    from app.core.config import settings as live_settings  # noqa: PLC0415
    from app.execution.retention import sweep_expired_evidence  # noqa: PLC0415

    monkeypatch.setattr(live_settings, "artifact_retention_days", 0)
    assert sweep_expired_evidence(db) == {"artifacts": 0, "evidence": 0, "files": 0, "bytes": 0}
