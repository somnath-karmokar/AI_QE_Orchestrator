"""Connecting a tenant's own systems, and keeping their credentials.

The thing these tests exist to prevent is a credential leaving the platform by a
route nobody thought about: a list response, a detail response, an audit entry,
an error message, a log line, or another tenant's request. So most of what is
asserted here is a negative -- the password is *not* in the response -- checked
against the whole serialised body rather than against the field somebody
remembered to redact.
"""

from __future__ import annotations

import uuid

import pytest

from app.core import crypto
from app.models.datasource import DataSource, secret_fields_for
from app.models.project import Project

PASSWORD = "pl4intext-should-never-appear"


@pytest.fixture
def headers(client) -> dict[str, str]:  # noqa: ANN001
    response = client.post(
        "/api/v1/auth/login",
        json={"email": "alex.morgan@example.com", "password": "Demo!2024"},
    )
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


@pytest.fixture
def connected(client, headers, project_id) -> dict:  # noqa: ANN001
    # The seeded database is shared across the module and writes through the
    # client are committed, so each test connects a differently named source.
    response = client.post(
        "/api/v1/data-sources",
        headers=headers,
        params={"project_id": project_id},
        json={
            "name": f"Customer warehouse {uuid.uuid4().hex[:8]}",
            "kind": "postgres",
            "connection": {
                "host": "warehouse.customer.example",
                "port": 5432,
                "database": "orders",
                "username": "qe_reader",
                "password": PASSWORD,
            },
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


# ---------------------------------------------------------------------------
# The credential never comes back
# ---------------------------------------------------------------------------


def test_creating_a_source_does_not_echo_the_password(connected) -> None:  # noqa: ANN001
    assert PASSWORD not in str(connected)
    assert connected["has_credentials"] is True
    assert connected["credential_fields"] == ["password"]


def test_the_password_is_not_in_the_listing_or_the_detail(client, headers, project_id, connected) -> None:  # noqa: ANN001
    listing = client.get("/api/v1/data-sources", headers=headers, params={"project_id": project_id})
    assert listing.status_code == 200, listing.text
    assert PASSWORD not in listing.text

    detail = client.get(
        f"/api/v1/data-sources/{connected['id']}", headers=headers, params={"project_id": project_id}
    )
    assert detail.status_code == 200, detail.text
    assert PASSWORD not in detail.text


def test_the_non_secret_details_are_still_visible(connected) -> None:  # noqa: ANN001
    """Redaction has to stop at the credential, or the screen becomes useless."""
    assert connected["config"]["host"] == "warehouse.customer.example"
    assert connected["config"]["database"] == "orders"
    assert connected["config"]["username"] == "qe_reader"
    assert "password" not in connected["config"]


def test_the_password_is_not_stored_in_the_clear(db, connected) -> None:  # noqa: ANN001
    """Read the row itself: the API could be clean while the column is not."""
    row = db.get(DataSource, connected["id"])
    assert PASSWORD not in str(row.config)
    assert row.secret_bundle is not None
    assert PASSWORD not in row.secret_bundle
    assert crypto.is_encrypted(row.secret_bundle)
    # And it really is the password, not something lost in transit.
    assert crypto.decrypt_mapping(row.secret_bundle)["password"] == PASSWORD


def test_the_audit_entry_does_not_carry_the_credential(client, headers, project_id, connected) -> None:  # noqa: ANN001
    """The audit trail is read by more people than the data source screen."""
    trail = client.get(
        "/api/v1/audit", headers=headers, params={"project_id": project_id, "action": "data_source.connect"}
    )
    assert trail.status_code == 200, trail.text
    assert PASSWORD not in trail.text
    assert any(row["entity_id"] == connected["id"] for row in trail.json()["items"])


def test_a_secret_bundle_does_not_print_its_contents() -> None:
    """Most leaks are an object stringified into a log line."""
    bundle = crypto.SecretBundle({"password": PASSWORD, "token": "abc"})
    assert PASSWORD not in repr(bundle)
    assert PASSWORD not in str(bundle)
    assert PASSWORD not in str(bundle.redacted())
    assert bundle.get("password") == PASSWORD  # still usable by the adapter


# ---------------------------------------------------------------------------
# Editing
# ---------------------------------------------------------------------------


def test_an_edit_without_a_password_keeps_the_stored_one(client, headers, project_id, connected, db) -> None:  # noqa: ANN001
    """The form cannot show the password, so a blank field means "unchanged"."""
    response = client.patch(
        f"/api/v1/data-sources/{connected['id']}",
        headers=headers,
        params={"project_id": project_id},
        json={"connection": {"host": "warehouse-2.customer.example"}},
    )
    assert response.status_code == 200, response.text
    assert response.json()["config"]["host"] == "warehouse-2.customer.example"
    # Unrelated fields survive the merge, and so does the credential.
    assert response.json()["config"]["database"] == "orders"

    db.expire_all()
    row = db.get(DataSource, connected["id"])
    assert crypto.decrypt_mapping(row.secret_bundle)["password"] == PASSWORD


def test_changing_the_password_changes_the_fingerprint(client, headers, project_id, connected) -> None:  # noqa: ANN001
    """A screen has to be able to say "this was rotated" without showing it."""
    before = connected["credential_fingerprint"]
    response = client.patch(
        f"/api/v1/data-sources/{connected['id']}",
        headers=headers,
        params={"project_id": project_id},
        json={"connection": {"password": "a-different-password"}},
    )
    assert response.status_code == 200, response.text
    assert response.json()["credential_fingerprint"] != before
    assert "a-different-password" not in response.text


def test_changing_the_connection_marks_it_unverified(client, headers, project_id, connected) -> None:  # noqa: ANN001
    """A passed test does not carry over to a connection that changed."""
    response = client.patch(
        f"/api/v1/data-sources/{connected['id']}",
        headers=headers,
        params={"project_id": project_id},
        json={"connection": {"host": "somewhere.else.example"}},
    )
    assert response.json()["status"] == "unverified"
    assert response.json()["last_test_ok"] is None


def test_disconnecting_destroys_the_credential(client, headers, project_id, connected, db) -> None:  # noqa: ANN001
    """Disconnecting means the platform no longer holds a key to their systems."""
    response = client.delete(
        f"/api/v1/data-sources/{connected['id']}",
        headers=headers,
        params={"project_id": project_id},
    )
    assert response.status_code == 200, response.text

    db.expire_all()
    row = db.get(DataSource, connected["id"])
    assert row.secret_bundle is None
    assert row.secret_fingerprint is None
    assert row.is_deleted is True


# ---------------------------------------------------------------------------
# Validation and tenancy
# ---------------------------------------------------------------------------


def test_a_secret_submitted_in_the_wrong_half_is_still_encrypted(client, headers, project_id, db) -> None:  # noqa: ANN001
    """Which fields are secret is decided by the kind, not by the caller.

    A client that put the token in with the ordinary settings would otherwise
    have it stored in the clear and rendered straight back onto a screen.
    """
    response = client.post(
        "/api/v1/data-sources",
        headers=headers,
        params={"project_id": project_id},
        json={
            "name": f"Their REST API {uuid.uuid4().hex[:8]}",
            "kind": "rest_api",
            "connection": {"base_url": "https://api.customer.example", "api_key": "sk-secret-value"},
        },
    )
    assert response.status_code == 201, response.text
    assert "sk-secret-value" not in response.text

    row = db.get(DataSource, response.json()["id"])
    assert "sk-secret-value" not in str(row.config)
    assert crypto.decrypt_mapping(row.secret_bundle)["api_key"] == "sk-secret-value"


def test_an_unknown_kind_is_refused(client, headers, project_id) -> None:  # noqa: ANN001
    response = client.post(
        "/api/v1/data-sources",
        headers=headers,
        params={"project_id": project_id},
        json={"name": f"Mystery {uuid.uuid4().hex[:8]}", "kind": "telepathy", "connection": {}},
    )
    assert response.status_code == 422, response.text


def test_a_kind_missing_its_required_fields_is_refused(client, headers, project_id) -> None:  # noqa: ANN001
    response = client.post(
        "/api/v1/data-sources",
        headers=headers,
        params={"project_id": project_id},
        json={"name": f"Nameless database {uuid.uuid4().hex[:8]}", "kind": "postgres", "connection": {"host": "db.example"}},
    )
    assert response.status_code == 422, response.text
    assert "database" in response.text


def test_an_unknown_kind_falls_back_to_encrypting_the_widest_set() -> None:
    """Failing towards encrypting too much is the recoverable direction."""
    assert set(secret_fields_for("something-new")) == set(secret_fields_for("custom"))


def test_another_tenant_cannot_see_or_load_the_data_source(client, db, connected, project_id) -> None:  # noqa: ANN001
    """The whole point: one customer's connection details are not another's."""
    other = Project(key=f"DSO{uuid.uuid4().hex[:5].upper()}", name="Another customer", business_domain="Banking")
    db.add(other)
    db.commit()

    outsider = client.post(
        "/api/v1/auth/login", json={"email": "tom.becker@example.com", "password": "Demo!2024"}
    )
    tom = {"Authorization": f"Bearer {outsider.json()['access_token']}"}

    # Tom is a member of the demo project, so he may list its sources -- but he
    # cannot reach them through a project he does not belong to, and naming
    # that project at all is refused.
    refused = client.get("/api/v1/data-sources", headers=tom, params={"project_id": other.id})
    assert refused.status_code == 404, refused.text

    # And an id from one project cannot be read through another project.
    crossed = client.get(
        f"/api/v1/data-sources/{connected['id']}", headers=tom, params={"project_id": other.id}
    )
    assert crossed.status_code == 404, crossed.text


def test_a_source_id_cannot_be_read_through_a_project_you_do_belong_to(client, db, headers, project_id) -> None:  # noqa: ANN001
    """Naming a project you *are* in, with a source id from one you are not.

    This is the case the query-parameter check cannot catch: membership of the
    named project is genuine, so the dependency is satisfied and only the
    service's own `project_id` filter stands between the caller and another
    tenant's connection details. Without that filter this test reads out a
    database host, a username and the fact that a credential is stored.
    """
    other = Project(key=f"DSX{uuid.uuid4().hex[:5].upper()}", name="Another customer")
    db.add(other)
    db.commit()

    from app.services import data_sources  # noqa: PLC0415

    theirs = data_sources.create(
        db,
        project_id=other.id,
        name=f"Their warehouse {uuid.uuid4().hex[:6]}",
        kind="postgres",
        connection={"host": "secret-host.customer.example", "database": "theirs", "password": PASSWORD},
        actor="them@other-tenant.example",
    )
    db.commit()

    response = client.get(
        f"/api/v1/data-sources/{theirs.id}",
        headers=headers,           # alex, a genuine member of the demo project
        params={"project_id": project_id},  # a project he really does belong to
    )
    assert response.status_code == 404, response.text
    assert "secret-host.customer.example" not in response.text
