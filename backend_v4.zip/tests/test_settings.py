"""Loading configuration from an environment file.

The first thing the README tells anyone to do is copy `.env.example` to `.env`.
For a while that produced an application that could not start: the example
shipped comma-separated lists and blank placeholders, and the settings loader
rejected both. Nothing tested it, because the test suite runs without a `.env`
and so never parsed one.

These tests hold that a verbatim copy of the example file loads, and that each
format it uses keeps working.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app.core.config import REPO_ROOT, Settings

EXAMPLE = REPO_ROOT / ".env.example"


def _load(tmp_path: Path, body: str) -> Settings:
    """Settings built from one env file, ignoring the real `.env`."""
    env_file = tmp_path / ".env"
    env_file.write_text(body, encoding="utf-8")
    return Settings(_env_file=env_file)


# ---------------------------------------------------------------------------
# The file people actually copy
# ---------------------------------------------------------------------------


def test_the_shipped_example_file_loads_verbatim() -> None:
    """The regression itself. A user who follows the README's first step must
    get a working configuration, not a SettingsError at import."""
    assert EXAMPLE.exists()
    Settings(_env_file=EXAMPLE)  # must not raise


def test_the_example_selects_local_mode() -> None:
    """A fresh clone must run with nothing installed, so the example must not
    opt into production."""
    assert Settings(_env_file=EXAMPLE).app_mode == "local"


# ---------------------------------------------------------------------------
# List settings: two formats, both supported
# ---------------------------------------------------------------------------


def test_a_comma_separated_list_is_accepted(tmp_path: Path) -> None:
    """The format `.env.example` ships. pydantic-settings JSON-decodes list
    fields before validators run, so this raised until the fields were marked
    `NoDecode`."""
    loaded = _load(tmp_path, "CORS_ORIGINS=https://a.example.com, https://b.example.com\n")
    assert loaded.cors_origins == ["https://a.example.com", "https://b.example.com"]


def test_a_json_array_is_still_accepted(tmp_path: Path) -> None:
    """The format that worked before, which a deployment may already use. Once
    the raw string reaches the validator it has to be parsed, not passed on."""
    loaded = _load(tmp_path, 'CORS_ORIGINS=["https://a.example.com","https://b.example.com"]\n')
    assert loaded.cors_origins == ["https://a.example.com", "https://b.example.com"]


def test_a_single_value_is_a_list_of_one(tmp_path: Path) -> None:
    assert _load(tmp_path, "CORS_ORIGINS=https://only.example.com\n").cors_origins == [
        "https://only.example.com"
    ]


def test_the_risk_levels_list_takes_the_same_formats(tmp_path: Path) -> None:
    """It shares the validator, so it shared the bug."""
    assert _load(tmp_path, "APPROVAL_REQUIRED_RISK_LEVELS=high,critical\n").approval_required_risk_levels == [
        "high",
        "critical",
    ]
    assert _load(tmp_path, 'APPROVAL_REQUIRED_RISK_LEVELS=["medium"]\n').approval_required_risk_levels == [
        "medium"
    ]


def test_malformed_json_is_an_error_not_a_silent_default(tmp_path: Path) -> None:
    """A typo in a security-relevant list must not quietly fall back to
    something else."""
    with pytest.raises(ValueError):
        _load(tmp_path, 'CORS_ORIGINS=["https://a.example.com"\n')


# ---------------------------------------------------------------------------
# Blank placeholders
# ---------------------------------------------------------------------------


def test_a_blank_line_means_not_set(tmp_path: Path) -> None:
    """`KEY=` in the example is a placeholder. An integer setting cannot parse
    an empty string, so CHROMA_PORT alone stopped the app from starting."""
    loaded = _load(tmp_path, "CHROMA_PORT=\nCHROMA_HOST=\nBEDROCK_REGION=\n")

    assert loaded.chroma_port is None
    assert loaded.chroma_host is None
    # None, not "": the two behave differently under an `is None` check.
    assert loaded.bedrock_region is None


def test_a_blank_setting_takes_its_default_rather_than_emptying_it(tmp_path: Path) -> None:
    """The trade-off, stated: a blank line no longer blanks out a setting that
    has a default. For a template full of placeholders that is the intent."""
    loaded = _load(tmp_path, "CORS_ORIGINS=\n")
    assert loaded.cors_origins == Settings(_env_file=None).cors_origins


def test_a_real_value_still_overrides(tmp_path: Path) -> None:
    loaded = _load(tmp_path, "CHROMA_PORT=8001\nCHROMA_HOST=chroma.internal\n")
    assert loaded.chroma_port == 8001
    assert loaded.chroma_host == "chroma.internal"


# ---------------------------------------------------------------------------
# What the example promises
# ---------------------------------------------------------------------------


def test_every_key_in_the_example_names_a_real_setting() -> None:
    """`extra="ignore"` means a misspelt key is silently dropped: the operator
    believes they configured something and nothing happened. Catch it here,
    where it is the example's own typo rather than someone's deployment."""
    known = {name.lower() for name in Settings.model_fields}
    unknown: list[str] = []

    for line in EXAMPLE.read_text(encoding="utf-8").splitlines():
        stripped = line.strip().lstrip("#").strip()
        if "=" not in stripped or " " in stripped.split("=", 1)[0]:
            continue  # prose, not an assignment
        key = stripped.split("=", 1)[0]
        # VITE_* is read by the frontend dev server (frontend/vite.config.ts),
        # not by these settings; it shares the file on purpose.
        if key.startswith("VITE_"):
            continue
        if key.isupper() and key.lower() not in known:
            unknown.append(key)

    assert not unknown, f".env.example names settings that do not exist: {sorted(set(unknown))}"
