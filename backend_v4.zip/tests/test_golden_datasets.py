"""Every golden dataset case, executed the way a consumer would execute it.

A golden dataset is only worth publishing while it is true. This file runs every
curated reference case and every schema-derived edge case through the
integration API -- the same endpoints, the same key-based authentication, the
same envelope a calling platform receives -- and evaluates it with the same
`evaluate` function whose semantics the dataset publishes. A case that stops
holding fails the build instead of quietly misleading whoever relies on it.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.agents.registry import BUILTIN_AGENT_CLASSES
from app.core.worker import job_queue
from app.models.flow import AgentFlow
from app.services.golden_datasets import AGENT_CASES, EXPECTATION_SEMANTICS, FLOW_CASES, evaluate
from app.services.integration_clients import issue_client

API = "/api/v1/integration"
REFERENCE_FLOWS = sorted(FLOW_CASES)


@pytest.fixture
def key(db, project_id: str) -> str:
    """A key that reaches everything in the reference project."""
    _record, token = issue_client(
        db,
        project_id=project_id,
        name="golden-dataset-runner",
        actor="alex.morgan@example.com",
        scopes=["catalog:read", "flows:run", "agents:run", "runs:read", "runs:logs"],
        grants_all_flows=True,
        grants_all_agents=True,
        rate_limit_per_minute=10_000,
    )
    db.commit()
    return token


@pytest.fixture(scope="module")
def reference_project(seeded):  # noqa: ANN001, ANN201, ARG001
    """The reference project as it really is: seeded, with its knowledge indexed.

    The suite skips indexing to stay fast, but retrieval cases are meaningless
    without it. Indexed into a store of this module's own, and the shared store
    put back afterwards, so no other test sees a different vector store.
    """
    from app.seed.runner import index_project_knowledge  # noqa: PLC0415
    from app.vectorstore import factory  # noqa: PLC0415
    from app.vectorstore.memory import InMemoryVectorStore  # noqa: PLC0415

    shared = factory._store  # noqa: SLF001 - deliberate test seam, as in conftest
    factory._store = InMemoryVectorStore()  # noqa: SLF001
    try:
        index_project_knowledge()
        yield
    finally:
        factory._store = shared  # noqa: SLF001


@pytest.fixture
def flows_by_key(db, project_id: str) -> dict[str, AgentFlow]:
    return {
        flow.key: flow
        for flow in db.execute(
            select(AgentFlow).where(AgentFlow.project_id == project_id, AgentFlow.is_deleted.is_(False))
        ).scalars()
    }


def _finished(client, token: str, run_id: str) -> dict:  # noqa: ANN001
    job_queue.wait_for_idle(timeout=60)
    response = client.get(f"{API}/runs/{run_id}", headers={"X-API-Key": token})
    assert response.status_code == 200, response.text
    return response.json()


def _refusal(response) -> dict:  # noqa: ANN001
    assert response.status_code == 422, f"{response.status_code}: {response.text}"
    return response.json()["error"]["details"]


def _check_edge(response, expect: dict) -> None:  # noqa: ANN001
    details = _refusal(response)
    fields = {item["field"]: item for item in details.get("invalid_inputs", [])}
    assert expect["invalid_field"] in fields, f"refusal did not name {expect['invalid_field']}: {details}"
    if "did_you_mean" in expect:
        assert fields[expect["invalid_field"]].get("did_you_mean") == expect["did_you_mean"], details


# ---------------------------------------------------------------------------
# Coverage: nothing is left without a dataset
# ---------------------------------------------------------------------------


def test_every_builtin_agent_has_a_curated_reference_case() -> None:
    missing = [cls.key for cls in BUILTIN_AGENT_CLASSES if cls.key not in AGENT_CASES]
    assert not missing, f"no reference case for {missing}"


def test_every_case_uses_only_published_expectations() -> None:
    """An expectation the dataset does not define would be unreadable to a consumer."""
    for cases in list(AGENT_CASES.values()) + list(FLOW_CASES.values()):
        for case in cases:
            unknown = set(case["expect"]) - set(EXPECTATION_SEMANTICS)
            assert not unknown, f"{case['id']} uses undefined expectations {unknown}"


def test_case_ids_are_unique() -> None:
    ids = [case["id"] for cases in list(AGENT_CASES.values()) + list(FLOW_CASES.values()) for case in cases]
    assert len(ids) == len(set(ids))


# ---------------------------------------------------------------------------
# Reference cases, through the API
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("agent_key", "case"),
    [(key, case) for key, cases in sorted(AGENT_CASES.items()) for case in cases],
    ids=lambda value: value["id"] if isinstance(value, dict) else value,
)
def test_agent_reference_case_holds(client, key: str, reference_project, agent_key: str, case: dict) -> None:  # noqa: ANN001
    started = client.post(
        f"{API}/agents/{agent_key}/runs", headers={"X-API-Key": key}, json={"inputs": case["inputs"]}
    )
    assert started.status_code in (200, 202), started.text
    envelope = _finished(client, key, started.json()["run_id"])

    outcome = evaluate(case, envelope, agent_key=agent_key)
    assert outcome["passed"], f"{case['id']}: {outcome['failures']}"


@pytest.mark.parametrize("flow_key", REFERENCE_FLOWS)
def test_flow_reference_case_holds(client, key: str, reference_project, flows_by_key: dict, flow_key: str) -> None:  # noqa: ANN001
    flow = flows_by_key.get(flow_key)
    assert flow is not None, f"reference flow {flow_key} is not seeded"
    for case in FLOW_CASES[flow_key]:
        started = client.post(
            f"{API}/flows/{flow.id}/runs", headers={"X-API-Key": key}, json={"inputs": case["inputs"]}
        )
        assert started.status_code in (200, 202), started.text
        envelope = _finished(client, key, started.json()["run_id"])
        outcome = evaluate(case, envelope)
        assert outcome["passed"], f"{case['id']}: {outcome['failures']}"


# ---------------------------------------------------------------------------
# Edge cases, through the API, for every agent and every reference flow
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("agent_key", sorted(cls.key for cls in BUILTIN_AGENT_CLASSES))
def test_agent_edge_cases_are_refused_as_published(client, key: str, agent_key: str) -> None:  # noqa: ANN001
    dataset = client.get(f"{API}/agents/{agent_key}/golden-dataset", headers={"X-API-Key": key})
    assert dataset.status_code == 200, dataset.text
    edges = dataset.json()["edge_cases"]
    assert edges, "every agent has at least one edge case"
    for case in edges:
        response = client.post(
            f"{API}/agents/{agent_key}/runs", headers={"X-API-Key": key}, json={"inputs": case["inputs"]}
        )
        _check_edge(response, case["expect"])


@pytest.mark.parametrize("flow_key", REFERENCE_FLOWS)
def test_flow_edge_cases_are_refused_as_published(client, key: str, flows_by_key: dict, flow_key: str) -> None:  # noqa: ANN001
    flow = flows_by_key[flow_key]
    dataset = client.get(f"{API}/flows/{flow.id}/golden-dataset", headers={"X-API-Key": key}).json()
    for case in dataset["edge_cases"]:
        response = client.post(
            f"{API}/flows/{flow.id}/runs", headers={"X-API-Key": key}, json={"inputs": case["inputs"]}
        )
        _check_edge(response, case["expect"])


# ---------------------------------------------------------------------------
# The evaluator fails when it should
# ---------------------------------------------------------------------------


def test_the_evaluator_reports_each_unmet_expectation() -> None:
    """If `evaluate` passed everything, every test above would pass vacuously."""
    case = {
        "id": "X",
        "expect": {
            "disposition_in": ["succeeded"],
            "status_in": ["success"],
            "outputs_have": ["plan"],
            "summary_mentions": ["Payments"],
            "min_findings": 2,
            "approvals_at_least": 1,
        },
    }
    envelope = {
        "disposition": "failed",
        "guardrails": {"awaiting_approval": []},
        "outputs": {"a": {"status": "failed", "summary": "nothing", "outputs": {}, "findings": []}},
    }
    outcome = evaluate(case, envelope, agent_key="a")
    assert outcome["passed"] is False
    assert len(outcome["failures"]) == 6


def test_the_evaluator_passes_a_matching_run() -> None:
    case = {"id": "Y", "expect": {"disposition_in": ["succeeded"], "agents_produced": ["a", "b"]}}
    envelope = {"disposition": "succeeded", "outputs": {"a": {}, "b": {}}}
    assert evaluate(case, envelope)["passed"] is True


# ---------------------------------------------------------------------------
# Who may read a dataset
# ---------------------------------------------------------------------------


def test_a_dataset_is_served_only_for_what_the_catalog_lists(client, db, project_id: str) -> None:  # noqa: ANN001
    _record, narrow = issue_client(
        db,
        project_id=project_id,
        name="narrow-golden-reader",
        actor="alex.morgan@example.com",
        scopes=["catalog:read"],
        allowed_agent_keys=["test-planning"],
    )
    db.commit()
    headers = {"X-API-Key": narrow}

    assert client.get(f"{API}/agents/test-planning/golden-dataset", headers=headers).status_code == 200
    # Not granted and not existing are the same answer.
    assert client.get(f"{API}/agents/coverage-planning/golden-dataset", headers=headers).status_code == 404
    assert client.get(f"{API}/agents/no-such-agent/golden-dataset", headers=headers).status_code == 404


def test_a_dataset_needs_catalog_read(client, db, project_id: str) -> None:  # noqa: ANN001
    _record, token = issue_client(
        db, project_id=project_id, name="no-catalog", actor="alex.morgan@example.com",
        scopes=["agents:run"], grants_all_agents=True,
    )
    db.commit()
    response = client.get(f"{API}/agents/test-planning/golden-dataset", headers={"X-API-Key": token})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["required_scope"] == "catalog:read"
