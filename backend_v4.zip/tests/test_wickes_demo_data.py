"""The Wickes demo data itself: the git repo builder and the change board CSV.

Two things could silently break the client demo without breaking any other
test: the hand-authored CSV drifting from the worked example it is supposed to
reproduce, and the demo losing its variety (every change request happening to
land in the same band would make a dull demo and hide the veto rule). Both are
pinned here so a later edit to `scripts/build_wickes_demo_data.py` that breaks
either fails the build instead of failing on stage.
"""

from __future__ import annotations

import csv
import importlib.util
import sys
from pathlib import Path

import pytest

from app.services.wickes_risk_model import (
    BAND_ORDER,
    DIMENSIONS,
    apple_pay_worked_example_scores,
    assess,
)
from app.services.wickes_test_pack import scan_repo, select_impacted

SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"


def _load_builder():  # noqa: ANN202
    """Import scripts/build_wickes_demo_data.py by path -- it is a demo/ops
    script, not a package, so it is not on the normal import path."""
    spec = importlib.util.spec_from_file_location(
        "build_wickes_demo_data", SCRIPTS_DIR / "build_wickes_demo_data.py"
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def builder():  # noqa: ANN201
    return _load_builder()


@pytest.fixture(scope="module")
def demo_repo(tmp_path_factory, builder) -> Path:  # noqa: ANN001
    root = tmp_path_factory.mktemp("wickes-test-pack")
    builder.write_test_pack(root)
    builder.git_init_and_commit(root)
    return root


@pytest.fixture(scope="module")
def demo_csv(tmp_path_factory, builder) -> Path:  # noqa: ANN001
    path = tmp_path_factory.mktemp("wickes-csv") / "change_requests.csv"
    builder.write_csv(path)
    return path


def _rows(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


# ---------------------------------------------------------------------------
# The test pack repo
# ---------------------------------------------------------------------------


def test_the_builder_produces_a_real_git_repository(demo_repo: Path) -> None:
    assert (demo_repo / ".git").is_dir()


def test_every_generated_test_file_is_discoverable_by_the_scanner(demo_repo: Path, builder) -> None:  # noqa: ANN001
    expected = sum(len(files) for files in builder.TEST_PACK.values())
    found = scan_repo(demo_repo)
    assert len(found) == expected > 0


def test_re_running_the_builder_does_not_duplicate_or_break_the_repo(demo_repo: Path, builder) -> None:  # noqa: ANN001
    before = len(scan_repo(demo_repo))
    builder.write_test_pack(demo_repo)
    builder.git_init_and_commit(demo_repo)  # must not re-`init` an existing repo
    after = len(scan_repo(demo_repo))
    assert before == after
    assert (demo_repo / ".git").is_dir()


# ---------------------------------------------------------------------------
# The change board CSV
# ---------------------------------------------------------------------------


def test_the_csv_has_every_column_assess_and_select_impacted_need(demo_csv: Path, builder) -> None:  # noqa: ANN001
    rows = _rows(demo_csv)
    assert len(rows) == len(builder.CHANGE_REQUESTS) > 0
    required = {"issue_key", "summary", "description", "journey", "tags",
                "probability", "impact", "confidence", "control"}
    required |= {key for key, *_ in DIMENSIONS}
    for row in rows:
        assert required <= set(row), row["issue_key"]


def test_every_dimension_score_in_the_csv_is_in_range(demo_csv: Path) -> None:
    for row in _rows(demo_csv):
        for key, *_ in DIMENSIONS:
            value = int(row[key])
            assert 1 <= value <= 5, f"{row['issue_key']}.{key} = {value}"


def test_every_row_scores_without_error(demo_csv: Path) -> None:
    for row in _rows(demo_csv):
        result = assess(
            change_id=row["issue_key"], change_title=row["summary"],
            scores={key: int(row[key]) for key, *_ in DIMENSIONS},
            probability=int(row["probability"]), impact=int(row["impact"]),
            confidence=int(row["confidence"]), control=int(row["control"]),
        )
        assert result.band in BAND_ORDER


def test_cr_1001_reproduces_the_worked_example_through_the_csv_itself(demo_csv: Path) -> None:
    """Not just the hardcoded fixture (test_wickes_risk_model.py already holds
    that) -- the actual row a demo operator will read off the CSV on stage."""
    row = next(r for r in _rows(demo_csv) if r["issue_key"] == "CR-1001")
    scores = {key: int(row[key]) for key, *_ in DIMENSIONS}
    assert scores == apple_pay_worked_example_scores()

    result = assess(
        change_id=row["issue_key"], change_title=row["summary"], scores=scores,
        probability=int(row["probability"]), impact=int(row["impact"]),
        confidence=int(row["confidence"]), control=int(row["control"]),
    )
    assert (result.base_score, result.band) == (124, "Critical / P1")
    assert set(result.veto_triggered) == {"business_criticality", "security_data_privacy"}


def test_the_demo_shows_every_band_not_just_critical(demo_csv: Path) -> None:
    """The whole point of six change requests is to walk the client through
    the full range. If an edit to the CSV collapsed them all into one band,
    this is what would catch it."""
    bands = set()
    for row in _rows(demo_csv):
        result = assess(
            change_id=row["issue_key"], change_title=row["summary"],
            scores={key: int(row[key]) for key, *_ in DIMENSIONS},
            probability=int(row["probability"]), impact=int(row["impact"]),
            confidence=int(row["confidence"]), control=int(row["control"]),
        )
        bands.add(result.band)
    assert bands == set(BAND_ORDER), f"missing band(s): {set(BAND_ORDER) - bands}"


def test_the_demo_includes_at_least_one_non_flagship_veto(demo_csv: Path) -> None:
    """CR-1001 is expected to trip the veto -- that is the worked example. A
    second, independent veto (on a change that would not otherwise be
    Critical) is what proves the rule generalises rather than being special-
    cased for the one change it was copied from."""
    vetoed = []
    for row in _rows(demo_csv):
        result = assess(
            change_id=row["issue_key"], change_title=row["summary"],
            scores={key: int(row[key]) for key, *_ in DIMENSIONS},
            probability=int(row["probability"]), impact=int(row["impact"]),
            confidence=int(row["confidence"]), control=int(row["control"]),
        )
        if result.veto_triggered:
            vetoed.append(row["issue_key"])
    assert len(vetoed) >= 2, f"only vetoed: {vetoed}"
    assert "CR-1001" in vetoed


# ---------------------------------------------------------------------------
# End to end: CSV row -> score -> selection, the way the runner script does it
# ---------------------------------------------------------------------------


def test_every_change_request_selects_at_least_one_test_from_its_own_journey(demo_csv: Path, demo_repo: Path) -> None:
    files = scan_repo(demo_repo)
    for row in _rows(demo_csv):
        tags = tuple(t.strip() for t in row["tags"].split(",") if t.strip())
        selected = select_impacted(files, journey=row["journey"], change_tags=tags)
        assert selected, f"{row['issue_key']} selected no tests at all"
        assert any(s.test.journey == row["journey"] for s in selected), row["issue_key"]


def test_cr_1001_selection_covers_every_item_on_the_worked_examples_checklist(demo_csv: Path, demo_repo: Path) -> None:
    """Slide 3's 'Coverage Applied' list, checked against what SELECT actually
    returns for the same change: E2E order-to-finance, cross-system
    reconciliation, a negative/failure path, PCI security, accessibility, and
    performance/peak load."""
    row = next(r for r in _rows(demo_csv) if r["issue_key"] == "CR-1001")
    files = scan_repo(demo_repo)
    tags = tuple(t.strip() for t in row["tags"].split(",") if t.strip())
    selected_tags = {t.lower() for s in select_impacted(files, journey=row["journey"], change_tags=tags) for t in s.test.tags}

    checklist = {
        "end-to-end order to finance": {"e2e", "finance"},
        "cross-system reconciliation": {"reconciliation"},
        "negative / failure path": {"decline", "duplicate", "3ds"},
        "PCI security (SAST/DAST)": {"pci", "sast", "dast"},
        "accessibility (WCAG)": {"wcag", "accessibility"},
        "performance / peak load": {"performance", "peak"},
    }
    missing = [name for name, needed in checklist.items() if not (needed & selected_tags)]
    assert not missing, f"worked-example checklist item(s) not covered by SELECT: {missing}"
