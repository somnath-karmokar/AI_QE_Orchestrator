"""Failure classification, signatures and clustering.

The messages here are the real thing -- Playwright, pytest, HTTP and database
errors as they actually arrive. Classification is only worth having if it copes
with those rather than with tidied-up examples.
"""

from __future__ import annotations

import pytest

from app.execution.failures import (
    CONFIDENT_SCORE,
    FAILURE_CATEGORIES,
    classify,
    classify_failure,
    cluster_failures,
    failure_signature,
    normalise_message,
    triage_summary,
)


class FakeTest:
    """Stands in for an ExecutionTest row."""

    def __init__(self, id: str, name: str, module: str, message: str, result: str = "failed") -> None:  # noqa: A002
        self.id = id
        self.name = name
        self.module = module
        self.failure_message = message
        self.stack_trace = None
        self.result = result


# ---------------------------------------------------------------------------
# The taxonomy itself
# ---------------------------------------------------------------------------


def test_the_taxonomy_has_twelve_categories() -> None:
    assert len(FAILURE_CATEGORIES) == 12


def test_every_category_declares_what_it_means_for_healing() -> None:
    for key, spec in FAILURE_CATEGORIES.items():
        assert spec["label"] and spec["owner"] and spec["guidance"], key
        # A healable category must name the change healing would make; a
        # non-healable one must not, or the policy matrix has nothing to bite on.
        if spec["healable"]:
            assert spec["change_type"], f"{key} is healable but names no change type"
        else:
            assert spec["change_type"] is None, f"{key} is not healable but names a change type"


def test_business_failures_are_never_healable() -> None:
    for key in ("assertion_mismatch", "application_defect", "test_logic"):
        assert FAILURE_CATEGORIES[key]["healable"] is False


# ---------------------------------------------------------------------------
# Classification, on real messages
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("message", "expected"),
    [
        # Playwright
        (
            'Locator resolved to 0 elements: page.get_by_test_id("checkout-submit-btn") '
            "- waiting for locator to be visible",
            "locator_drift",
        ),
        (
            "Error: strict mode violation: get_by_role('button') resolved to 3 elements",
            "locator_drift",
        ),
        (
            "Timeout 30000ms exceeded while waiting for element state 'visible' on #promo",
            "timing",
        ),
        (
            "Test timed out after 60000ms waiting for the confirmation panel",
            "timing",
        ),
        (
            "page.goto: net::ERR_TOO_MANY_REDIRECTS at /checkout",
            "navigation",
        ),
        (
            "Target page, context or browser has been closed",
            "browser_crash",
        ),
        # Data
        (
            "Precondition failed: no such record for account reference used by this test",
            "test_data",
        ),
        (
            "psycopg2.errors.UniqueViolation: duplicate key value violates unique constraint",
            "test_data",
        ),
        (
            "The loyalty account LOY-2210 is closed and cannot be used",
            "test_data",
        ),
        # Application and contract
        (
            "AssertionError: expected order total to be '1,180.00' but the page showed '1,240.00'",
            "assertion_mismatch",
        ),
        (
            "HTTP 500 Internal Server Error returned by POST /api/payments",
            "application_defect",
        ),
        (
            "Schema validation failed: missing required field 'settlementDate' in response",
            "api_contract",
        ),
        # Platform
        (
            "401 Unauthorized - the session token expired before the assertion ran",
            "authentication",
        ),
        (
            "net::ERR_CONNECTION_REFUSED at https://staging.example.test - the service did not accept",
            "environment",
        ),
        (
            "Error: socket hang up (ECONNRESET) while posting to the payments service",
            "network",
        ),
        # The test's own fault
        (
            "fixture 'logged_in_page' not found",
            "test_logic",
        ),
        (
            "AttributeError: 'CheckoutPage' object has no attribute 'submit_btn'",
            "test_logic",
        ),
    ],
)
def test_real_failure_messages_are_classified(message: str, expected: str) -> None:
    result = classify(message)
    assert result.category == expected, (
        f"{message[:60]!r} -> {result.category} "
        f"(confidence {result.confidence}, matched {result.matched})"
    )


def test_a_locator_failure_is_not_read_as_a_timing_one() -> None:
    """The message mentions waiting, but what went wrong is the locator.

    The old classifier got this right only by dictionary order.
    """
    result = classify(
        'Locator resolved to 0 elements: page.get_by_test_id("pay") - waiting for it to be visible'
    )
    assert result.category == "locator_drift"
    assert result.confidence >= CONFIDENT_SCORE


def test_the_word_data_alone_does_not_mean_a_data_failure() -> None:
    """`test_data` used to match any message containing "data"."""
    result = classify("TypeError: cannot read property 'data' of undefined")
    assert result.category != "test_data"


def test_the_word_navigation_alone_does_not_mean_a_navigation_failure() -> None:
    result = classify("Timeout 15000ms exceeded during navigation to the basket")
    assert result.category == "timing"


def test_an_empty_message_is_unknown_and_says_so() -> None:
    result = classify("")
    assert result.category == "unknown"
    assert result.needs_review is True
    assert result.healable is False


def test_an_unrecognisable_message_is_not_forced_into_a_category() -> None:
    result = classify("something went sideways")
    assert result.category == "unknown"
    assert result.needs_review is True


def test_an_ambiguous_message_is_flagged_for_review() -> None:
    """Supporting two readings equally is a reason to ask, not to pick."""
    result = classify(
        "AssertionError: expected the order confirmation, but HTTP 500 Internal Server Error"
    )
    assert result.category in {"assertion_mismatch", "application_defect"}
    assert result.needs_review is True
    assert result.runner_up is not None


def test_classification_reports_what_it_matched() -> None:
    result = classify("Timeout 30000ms exceeded while waiting for element state 'visible'")
    assert result.matched, "a classification should be able to show its evidence"
    assert 0.0 < result.confidence <= 1.0


def test_healable_categories_carry_their_change_type() -> None:
    assert classify("Locator resolved to 0 elements: #pay").change_type == "locator"
    assert classify("Timeout 30000ms exceeded while waiting").change_type == "timing"
    # An assertion mismatch is healable by nobody.
    assert classify("AssertionError: expected 5 but got 6").change_type is None


# ---------------------------------------------------------------------------
# Signatures
# ---------------------------------------------------------------------------


def test_the_same_fault_signs_the_same_whatever_the_run() -> None:
    first = (
        "Timeout 30000ms exceeded while waiting for locator at "
        "https://staging.example.test/checkout?session=6f1c2a9e-1111-4b2c-9d3e-0a1b2c3d4e5f"
    )
    second = (
        "Timeout 45000ms exceeded while waiting for locator at "
        "https://staging.example.test/checkout?session=aaaaaaaa-2222-4b2c-9d3e-ffffffffffff"
    )
    assert failure_signature(first) == failure_signature(second)


def test_different_faults_sign_differently() -> None:
    assert failure_signature("Locator resolved to 0 elements: #pay") != failure_signature(
        "Timeout 30000ms exceeded while waiting"
    )


def test_normalisation_removes_what_changes_between_runs() -> None:
    normalised = normalise_message(
        "Order 1,240.00 failed at 2026-09-18T04:14:43 on /var/app/tests/checkout_spec.py line 42"
    )
    assert "1,240.00" not in normalised
    assert "2026-09-18" not in normalised
    assert "line 42" not in normalised
    assert "line <n>" in normalised


def test_a_signature_names_its_category() -> None:
    signature = failure_signature("Locator resolved to 0 elements: #pay")
    assert signature.startswith("LOCATOR_DRIFT")


def test_an_empty_message_has_a_signature_too() -> None:
    assert failure_signature("") == "EMPTY"


# ---------------------------------------------------------------------------
# Clustering and triage
# ---------------------------------------------------------------------------


def _drifted(index: int) -> FakeTest:
    return FakeTest(
        f"t{index}",
        f"Checkout test {index}",
        "Payments",
        f'Locator resolved to 0 elements: page.get_by_test_id("pay-now") on attempt {index}',
    )


def test_one_cause_across_many_tests_is_one_cluster() -> None:
    """The point of the whole module: a redesign breaks fifty tests one way."""
    clusters = cluster_failures([_drifted(index) for index in range(50)])
    assert len(clusters) == 1
    assert clusters[0].size == 50
    assert clusters[0].classification.category == "locator_drift"


def test_distinct_causes_stay_distinct() -> None:
    tests = [
        *[_drifted(index) for index in range(4)],
        FakeTest("x1", "Slow history", "History", "Timeout 30000ms exceeded while waiting for rows"),
        FakeTest("x2", "Slow history 2", "History", "Timeout 45000ms exceeded while waiting for rows"),
        FakeTest("y1", "Payment total", "Payments", "AssertionError: expected 1,180.00 but got 1,240.00"),
    ]
    clusters = cluster_failures(tests)
    assert len(clusters) == 3
    assert [cluster.size for cluster in clusters] == [4, 2, 1]
    assert {cluster.classification.category for cluster in clusters} == {
        "locator_drift",
        "timing",
        "assertion_mismatch",
    }


def test_passing_tests_are_not_clustered() -> None:
    tests = [_drifted(1), FakeTest("p1", "Fine", "Payments", "", result="passed")]
    clusters = cluster_failures(tests)
    assert sum(cluster.size for cluster in clusters) == 1


def test_flaky_tests_are_clustered_too() -> None:
    tests = [FakeTest("f1", "Flaky", "Login", "Timeout 30000ms exceeded", result="flaky")]
    assert cluster_failures(tests)[0].size == 1


def test_a_cluster_records_every_test_and_module_it_touched() -> None:
    tests = [
        FakeTest("a", "One", "Payments", 'Locator resolved to 0 elements: page.get_by_test_id("pay")'),
        FakeTest("b", "Two", "Basket", 'Locator resolved to 0 elements: page.get_by_test_id("pay")'),
    ]
    cluster = cluster_failures(tests)[0]
    assert set(cluster.test_ids) == {"a", "b"}
    assert cluster.modules == ["Basket", "Payments"]


def test_triage_reports_how_much_work_clustering_removed() -> None:
    tests = [
        *[_drifted(index) for index in range(40)],
        FakeTest("x1", "Slow", "History", "Timeout 30000ms exceeded while waiting for rows"),
    ]
    summary = triage_summary(cluster_failures(tests))

    assert summary["failures"] == 41
    assert summary["distinct_causes"] == 2
    # 41 failures need 2 investigations, not 41 -- which is 39 model calls saved.
    assert summary["investigations_saved"] == 39
    assert summary["by_category"] == {"locator_drift": 40, "timing": 1}
    assert summary["healable_failures"] == 41


def test_triage_counts_causes_that_need_a_person() -> None:
    tests = [FakeTest("u1", "Odd", "Payments", "something went sideways")]
    summary = triage_summary(cluster_failures(tests))
    assert summary["needs_review_causes"] == 1
    assert summary["healable_causes"] == 0


def test_triage_of_a_clean_run_is_empty() -> None:
    summary = triage_summary(cluster_failures([]))
    assert summary["failures"] == 0
    assert summary["distinct_causes"] == 0
    assert summary["largest_cluster"] is None


# ---------------------------------------------------------------------------
# The older interface still works
# ---------------------------------------------------------------------------


def test_the_original_two_value_interface_still_works() -> None:
    key, spec = classify_failure('Locator resolved to 0 elements: page.get_by_test_id("pay")')
    assert key == "locator_drift"
    assert spec["healable"] is True
    assert spec["label"] == "Locator drift"


def test_the_original_interface_still_returns_unknown_for_noise() -> None:
    key, spec = classify_failure("something went sideways")
    assert key == "unknown"
    assert spec["healable"] is False


# ---------------------------------------------------------------------------
# The agent triages causes, not failures
# ---------------------------------------------------------------------------


def test_analysis_retrieves_once_per_cause_not_once_per_failure(db, project_id: str) -> None:
    """The cost claim, tested.

    Forty tests broken by one redesign should cost one retrieval, not forty.
    """
    from app.agents.base import AgentContext  # noqa: PLC0415
    from app.agents.implementations.automation import AutomationFailureAnalysisAgent  # noqa: PLC0415
    from app.execution.service import ExecutionService  # noqa: PLC0415
    from app.models.project import Project  # noqa: PLC0415

    project = db.get(Project, project_id)
    execution = ExecutionService(db).create(
        project_id=project_id, name="Triage cost test", suite_type="regression"
    )
    tests = list(execution.tests)
    assert len(tests) >= 5, "the demo project should have enough automated tests"

    # One redesign, many broken tests -- plus one unrelated timeout.
    for index, test in enumerate(tests):
        test.result = "failed"
        test.failure_message = (
            'Locator resolved to 0 elements: page.get_by_test_id("pay-now") '
            f"on attempt {index}"
            if index < len(tests) - 1
            else "Timeout 30000ms exceeded while waiting for the history rows"
        )
    db.flush()

    calls: list[str] = []
    agent = AutomationFailureAnalysisAgent()
    ctx = AgentContext(session=db, project=project, variables={"execution_id": execution.id})

    class CountingKnowledge:
        def retrieve(self, query, **kwargs):  # noqa: ANN001, ANN202, ARG002
            calls.append(query)
            return []

    ctx._knowledge = CountingKnowledge()  # noqa: SLF001 - deliberate test seam

    context = agent.gather_context(ctx, {"execution_id": execution.id})
    payload = agent.draft(ctx, {"execution_id": execution.id}, context)

    # Two causes, so two retrievals -- however many tests broke.
    assert len(calls) == 2, f"expected one retrieval per cause, got {len(calls)}"
    assert payload["outputs"]["distinct_causes"] == 2
    assert payload["outputs"]["analysed"] == len(tests)
    assert payload["outputs"]["investigations_saved"] == len(tests) - 2


def test_a_stored_category_matches_what_triage_computes(db, project_id: str) -> None:
    """A test row saying "application defect" while the cause panel says
    "assertion mismatch" is the kind of inconsistency a client spots
    immediately. Both read from the same classifier, so they cannot diverge."""
    from app.execution.service import ExecutionService  # noqa: PLC0415

    service = ExecutionService(db)
    execution = service.create(
        project_id=project_id, name="Category consistency", suite_type="regression"
    )
    service.run(execution.id)
    db.refresh(execution)

    failed = [test for test in execution.tests if test.result == "failed"]
    for test in failed:
        assert test.failure_category == classify(test.failure_message).category, (
            f"stored {test.failure_category!r} but the message classifies as "
            f"{classify(test.failure_message).category!r}: {test.failure_message!r}"
        )

    for cluster in cluster_failures(list(execution.tests)):
        for test in execution.tests:
            if test.id in cluster.test_ids and test.result == "failed":
                assert test.failure_category == cluster.classification.category


def test_every_simulated_failure_is_classifiable(db, project_id: str) -> None:
    """The simulator must not produce messages the taxonomy cannot read."""
    from app.execution.service import _FAILURE_TEMPLATES  # noqa: PLC0415

    for category_key, _signature, template in _FAILURE_TEMPLATES:
        message = template.format(
            element="Submit action", url="https://app.example.test", module="payments"
        )
        result = classify(message)
        assert result.category == category_key, (
            f"template labelled {category_key!r} classifies as {result.category!r}: {message!r}"
        )
        assert not result.needs_review, f"{category_key} template is ambiguous: {message!r}"


def test_triage_endpoint_groups_a_runs_failures(client, auth_headers, db, project_id: str) -> None:
    from app.execution.service import ExecutionService  # noqa: PLC0415

    execution = ExecutionService(db).create(
        project_id=project_id, name="Triage endpoint test", suite_type="regression"
    )
    for index, test in enumerate(execution.tests):
        test.result = "failed"
        test.failure_message = (
            'Locator resolved to 0 elements: page.get_by_test_id("pay-now")'
            if index % 2 == 0
            else "Timeout 30000ms exceeded while waiting for rows"
        )
    db.commit()

    response = client.get(f"/api/v1/executions/{execution.id}/triage", headers=auth_headers)
    assert response.status_code == 200, response.text
    body = response.json()

    assert body["distinct_causes"] == 2
    assert body["failures"] == len(list(execution.tests))
    assert set(body["by_category"]) == {"locator_drift", "timing"}
    assert body["clusters"][0]["size"] >= body["clusters"][-1]["size"]
    assert body["largest_cluster"]["classification"]["healable"] is True
