"""A project is a tenant boundary, and these tests are what say so.

Before project membership existed, any authenticated user could list every
project, read any run by id and search any project's knowledge -- the roles said
what somebody could *do*, and nothing said which projects they could do it *in*.
A live probe against the demo server confirmed all three.

What is pinned here is the rule rather than one endpoint's spelling of it: a
caller who is not a member is told the thing was not found, never that it exists
but is somebody else's, because the second answer confirms another customer's
project and its id. The platform administrator role holds `project:access_all`
and still reaches everything, which is deliberate and is asserted too -- if that
ever stops being wanted, this is the test that should change.
"""

from __future__ import annotations

import uuid

import pytest

from app.models.identity import ProjectMember
from app.models.project import Project
from app.models.run import AgentRun
from app.models.testing import Requirement


def _login(client, email: str) -> dict[str, str]:  # noqa: ANN001
    response = client.post(
        "/api/v1/auth/login", json={"email": email, "password": "Demo!2024"}
    )
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


@pytest.fixture
def outsider(client) -> dict[str, str]:  # noqa: ANN001
    """An ordinary user, deliberately not an administrator."""
    return _login(client, "tom.becker@example.com")


@pytest.fixture
def other_tenant(db) -> Project:  # noqa: ANN001
    """A project with no members at all: nobody but an admin may touch it."""
    project = Project(
        key=f"OTHER{uuid.uuid4().hex[:4].upper()}",
        name="Another customer",
        description="Belongs to a different tenant.",
        business_domain="Banking",
    )
    db.add(project)
    db.commit()
    return project


@pytest.fixture
def foreign_run(db, other_tenant) -> AgentRun:  # noqa: ANN001
    run = AgentRun(
        project_id=other_tenant.id,
        title="Their run",
        correlation_id=str(uuid.uuid4()),
        status="succeeded",
        run_number=1,
        trigger="manual",
        triggered_by="someone@other-tenant.example",
        inputs={"card_number": "4111111111111111"},
        outputs={"summary": "Their confidential result."},
    )
    db.add(run)
    db.commit()
    return run


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------


def test_a_project_you_are_not_in_is_absent_from_the_listing(client, outsider, other_tenant) -> None:  # noqa: ANN001
    response = client.get("/api/v1/projects", headers=outsider, params={"limit": 200})
    assert response.status_code == 200, response.text
    assert other_tenant.id not in [row["id"] for row in response.json()["items"]]


def test_reading_another_tenants_project_says_not_found(client, outsider, other_tenant) -> None:  # noqa: ANN001
    """404 and not 403 on purpose: a 403 would confirm the project exists."""
    response = client.get(f"/api/v1/projects/{other_tenant.id}", headers=outsider)
    assert response.status_code == 404, response.text
    assert other_tenant.name not in response.text


def test_reading_another_tenants_run_says_not_found(client, outsider, foreign_run) -> None:  # noqa: ANN001
    response = client.get(f"/api/v1/runs/{foreign_run.id}", headers=outsider)
    assert response.status_code == 404, response.text
    # The refusal must not carry the very data it is refusing.
    assert "4111111111111111" not in response.text
    assert "confidential" not in response.text.lower()


def test_another_tenants_run_is_absent_from_the_run_listing(client, outsider, foreign_run) -> None:  # noqa: ANN001
    response = client.get("/api/v1/runs", headers=outsider, params={"limit": 200})
    assert response.status_code == 200, response.text
    assert foreign_run.id not in [row["id"] for row in response.json()["items"]]


def test_a_run_event_log_needs_membership(client, outsider, foreign_run) -> None:  # noqa: ANN001
    response = client.get(f"/api/v1/runs/{foreign_run.id}/messages", headers=outsider)
    assert response.status_code == 404, response.text


def test_naming_another_tenants_project_in_a_query_is_refused(client, outsider, other_tenant) -> None:  # noqa: ANN001
    """The `?project_id=` parameter is as untrusted as an id in the path."""
    for path in (
        "/api/v1/requirements",
        "/api/v1/test-cases",
        "/api/v1/test-scripts",
        "/api/v1/knowledge/documents",
        "/api/v1/executions",
    ):
        response = client.get(path, headers=outsider, params={"project_id": other_tenant.id})
        assert response.status_code == 404, f"{path} -> {response.status_code} {response.text}"


def test_a_requirement_in_another_tenants_project_is_not_readable(client, db, outsider, other_tenant) -> None:  # noqa: ANN001
    requirement = Requirement(
        project_id=other_tenant.id,
        external_key="OTHER-1",
        title="Their requirement",
        description="Confidential.",
        module="payments",
    )
    db.add(requirement)
    db.commit()

    response = client.get(f"/api/v1/requirements/{requirement.id}", headers=outsider)
    assert response.status_code == 404, response.text


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------


def test_a_project_id_in_a_request_body_is_checked_too(client, outsider, other_tenant) -> None:  # noqa: ANN001
    """Creating *into* another tenant is as much a breach as reading out of it."""
    response = client.post(
        "/api/v1/flows",
        headers=outsider,
        json={"project_id": other_tenant.id, "name": "Intrusion"},
    )
    assert response.status_code == 404, response.text


def test_a_shared_builtin_cannot_drop_a_run_into_another_tenant(client, outsider, other_tenant) -> None:  # noqa: ANN001
    """Built-in agents are shared; where their runs are written is not."""
    catalog = client.get("/api/v1/agents", headers=outsider, params={"limit": 200})
    assert catalog.status_code == 200, catalog.text
    builtin = next(row for row in catalog.json()["items"] if row["is_builtin"])

    response = client.post(
        f"/api/v1/agents/{builtin['id']}/test",
        headers=outsider,
        json={"project_id": other_tenant.id, "inputs": {}},
    )
    assert response.status_code == 404, response.text


def test_another_tenants_run_cannot_be_cancelled_or_deleted(client, outsider, foreign_run) -> None:  # noqa: ANN001
    assert client.post(f"/api/v1/runs/{foreign_run.id}/cancel", headers=outsider).status_code == 404
    assert client.delete(f"/api/v1/runs/{foreign_run.id}", headers=outsider).status_code == 404


# ---------------------------------------------------------------------------
# Membership, and the administrator exception
# ---------------------------------------------------------------------------


def test_membership_is_what_grants_access(client, db, outsider, other_tenant) -> None:  # noqa: ANN001
    """The same request, refused and then allowed, with only membership changed.

    This is the test that proves the boundary is membership rather than some
    incidental property of the seeded data.
    """
    before = client.get(f"/api/v1/projects/{other_tenant.id}", headers=outsider)
    assert before.status_code == 404, before.text

    tom = client.get("/api/v1/auth/me", headers=outsider).json()
    db.add(ProjectMember(project_id=other_tenant.id, user_id=tom["id"], access="member"))
    db.commit()

    after = client.get(f"/api/v1/projects/{other_tenant.id}", headers=outsider)
    assert after.status_code == 200, after.text
    assert after.json()["name"] == other_tenant.name


def test_creating_a_project_makes_the_creator_its_owner(client, auth_headers, db) -> None:  # noqa: ANN001
    """Otherwise the first thing anyone did after creating a project would 404."""
    response = client.post(
        "/api/v1/projects",
        headers=auth_headers,
        json={
            "key": f"NEW{uuid.uuid4().hex[:5].upper()}",
            "name": "Freshly created",
            "business_domain": "Retail",
        },
    )
    assert response.status_code == 201, response.text
    project_id = response.json()["id"]

    membership = (
        db.query(ProjectMember).filter(ProjectMember.project_id == project_id).one()
    )
    assert membership.access == "owner"
    assert client.get(f"/api/v1/projects/{project_id}", headers=auth_headers).status_code == 200


def test_a_platform_administrator_still_reaches_every_project(client, auth_headers, other_tenant) -> None:  # noqa: ANN001
    """Somebody has to be able to run the platform.

    The seeded `admin` role holds `*`, which includes `project:access_all`. This
    is the test to change if an operator should stop seeing tenant data.
    """
    response = client.get(f"/api/v1/projects/{other_tenant.id}", headers=auth_headers)
    assert response.status_code == 200, response.text
