"""Flow execution: approval on agent steps, per-execution budgets and flow versioning."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

import pytest
from sqlalchemy import func, select

from app.models.agent import Agent
from app.models.flow import AgentFlow, AgentFlowEdge, AgentFlowNode
from app.models.governance import ApprovalRequest
from app.models.llm import LLMUsage
from app.models.project import Project
from app.models.run import AgentRun, AgentRunStep
from app.orchestration.factory import build_engine
from app.services.run_service import RunService


pytestmark = pytest.mark.usefixtures("orchestration_engine")


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


def _agent(db, key: str) -> Agent:  # noqa: ANN001
    return db.execute(select(Agent).where(Agent.key == key)).scalar_one()


def _readiness_flow(db, project: Project, cost_budget_usd: float = 5.0, **check_node: Any) -> AgentFlow:  # noqa: ANN001
    """start -> User Story Completeness (configurable) -> end."""
    flow = AgentFlow(
        project_id=project.id,
        key=f"test-{uuid.uuid4().hex[:10]}",
        name="Readiness check",
        status="published",
        variables={"requirement_key": "PAY-201"},
        cost_budget_usd=cost_budget_usd,
    )
    db.add(flow)
    db.flush()
    db.add_all(
        [
            AgentFlowNode(flow_id=flow.id, node_key="start", node_type="start", label="Start", sequence=0),
            AgentFlowNode(
                flow_id=flow.id,
                node_key="check",
                node_type="agent",
                label="Check readiness",
                agent_id=_agent(db, "user-story-completeness").id,
                input_mapping={"requirement_key": "$requirement_key"},
                sequence=1,
                **check_node,
            ),
            AgentFlowNode(flow_id=flow.id, node_key="end", node_type="end", label="Done", sequence=2),
            AgentFlowEdge(flow_id=flow.id, source_node_key="start", target_node_key="check"),
            AgentFlowEdge(flow_id=flow.id, source_node_key="check", target_node_key="end"),
        ]
    )
    db.flush()
    db.refresh(flow)
    return flow


def _run_flow(db, flow: AgentFlow) -> AgentRun:  # noqa: ANN001
    run = RunService(db).start_flow_run(flow_id=flow.id, project_id=flow.project_id, triggered_by="tester@example.com")
    return build_engine(db).execute_run(run.id)


def _decide(db, run: AgentRun, status: str) -> None:  # noqa: ANN001
    approval = db.execute(
        select(ApprovalRequest).where(ApprovalRequest.run_id == run.id, ApprovalRequest.status == "pending")
    ).scalar_one()
    approval.status = status
    approval.decided_by = "priya.raman@example.com"
    approval.decided_at = datetime.now(UTC)
    db.flush()


def _resume(db, run: AgentRun) -> AgentRun:  # noqa: ANN001
    # What RunService.resume does, minus handing the run to a background thread.
    run.status = "queued"
    db.flush()
    return build_engine(db).execute_run(run.id)


def _count(db, model, **filters: Any) -> int:  # noqa: ANN001
    statement = select(func.count()).select_from(model)
    for field, value in filters.items():
        statement = statement.where(getattr(model, field) == value)
    return int(db.execute(statement).scalar_one())


class TestAgentStepApproval:
    def test_a_node_that_requires_approval_pauses_before_the_agent_runs(self, db, project) -> None:  # noqa: ANN001
        run = _run_flow(db, _readiness_flow(db, project, requires_approval=True, approval_role="qe_lead"))

        assert run.status == "awaiting_approval"
        (step,) = db.execute(select(AgentRunStep).where(AgentRunStep.run_id == run.id)).scalars().all()
        assert step.status == "awaiting_approval"
        assert not step.output
        approval = db.execute(select(ApprovalRequest).where(ApprovalRequest.run_id == run.id)).scalar_one()
        assert approval.required_role == "qe_lead"

    def test_an_approved_step_runs_once_and_the_flow_finishes(self, db, project) -> None:  # noqa: ANN001
        run = _run_flow(db, _readiness_flow(db, project, requires_approval=True))
        _decide(db, run, "approved")
        run = _resume(db, run)

        assert run.status == "succeeded"
        steps = db.execute(select(AgentRunStep).where(AgentRunStep.run_id == run.id)).scalars().all()
        assert [(step.node_key, step.status) for step in steps] == [("check", "succeeded")]
        assert _count(db, ApprovalRequest, run_id=run.id) == 1

    def test_a_rejected_step_stops_the_flow(self, db, project) -> None:  # noqa: ANN001
        run = _run_flow(db, _readiness_flow(db, project, requires_approval=True))
        _decide(db, run, "rejected")
        run = _resume(db, run)

        assert run.status == "failed"
        step = db.execute(select(AgentRunStep).where(AgentRunStep.run_id == run.id)).scalar_one()
        assert step.status == "failed"
        assert "Rejected by priya.raman@example.com" in (step.error or "")

    def test_policy_approval_is_not_requested_again_after_approval(self, db, project) -> None:  # noqa: ANN001
        # A high-risk agent: governance, not the flow, demands the approval.
        service = RunService(db)
        run = service.start_agent_run(
            agent_id=_agent(db, "jira-defect-assistant").id,
            project_id=project.id,
            inputs={"title": "Payment total rounds incorrectly", "module": "Payments"},
            triggered_by="tester@example.com",
        )
        run = build_engine(db).execute_run(run.id)
        assert run.status == "awaiting_approval"

        _decide(db, run, "approved")
        run = _resume(db, run)

        assert run.status == "succeeded"
        assert _count(db, ApprovalRequest, run_id=run.id) == 1
        assert _count(db, AgentRunStep, run_id=run.id) == 1


class TestResume:
    def test_resuming_after_an_approval_gate_follows_the_branch_taken_before_the_pause(self, db, project) -> None:  # noqa: ANN001
        # start -> check -> gate(condition) -true-> approve(approval) -> scenarios -> end
        flow = _readiness_flow(db, project)
        db.query(AgentFlowEdge).filter(AgentFlowEdge.flow_id == flow.id).delete()
        db.add_all(
            [
                AgentFlowNode(
                    flow_id=flow.id, node_key="gate", node_type="condition", label="Story ready?", sequence=2,
                    condition_expression="user_story_completeness.outputs.completeness_score >= 0",
                ),
                AgentFlowNode(
                    flow_id=flow.id, node_key="approve", node_type="approval", label="Approve", sequence=3,
                    approval_role="qe_lead",
                ),
                AgentFlowNode(
                    flow_id=flow.id, node_key="scenarios", node_type="agent", label="Scenarios", sequence=4,
                    agent_id=_agent(db, "test-scenario-generator").id,
                    input_mapping={"requirement_key": "$requirement_key"},
                ),
                AgentFlowEdge(flow_id=flow.id, source_node_key="start", target_node_key="check"),
                AgentFlowEdge(flow_id=flow.id, source_node_key="check", target_node_key="gate"),
                AgentFlowEdge(flow_id=flow.id, source_node_key="gate", target_node_key="approve", branch_label="true"),
                AgentFlowEdge(flow_id=flow.id, source_node_key="approve", target_node_key="scenarios"),
                AgentFlowEdge(flow_id=flow.id, source_node_key="scenarios", target_node_key="end"),
            ]
        )
        db.flush()
        db.refresh(flow)

        run = _run_flow(db, flow)
        assert run.status == "awaiting_approval"
        _decide(db, run, "approved")
        run = _resume(db, run)

        steps = {
            step.node_key: step.status
            for step in db.execute(select(AgentRunStep).where(AgentRunStep.run_id == run.id)).scalars()
        }
        assert steps == {"check": "succeeded", "gate": "succeeded", "approve": "succeeded", "scenarios": "succeeded"}
        assert run.status == "succeeded"
        assert (run.completed_step_count, run.step_count) == (2, 2)


class TestBudgets:
    def test_a_node_cost_limit_stops_an_expensive_step(self, db, project) -> None:  # noqa: ANN001
        run = _run_flow(db, _readiness_flow(db, project, cost_limit_usd=0.000001))

        assert run.status == "failed"
        step = db.execute(select(AgentRunStep).where(AgentRunStep.run_id == run.id)).scalar_one()
        assert "budget" in (step.error or "").lower()

    def test_the_flow_budget_applies_per_run_not_to_everything_ever_spent(self, db, project) -> None:  # noqa: ANN001
        flow = _readiness_flow(db, project, cost_budget_usd=1.0)
        # Earlier runs of this flow have spent far more than one run's budget.
        db.add(
            LLMUsage(
                project_id=project.id,
                flow_id=flow.id,
                provider="mock",
                model="qe-demo-standard",
                estimated_cost_usd=25.0,
            )
        )
        db.flush()

        assert _run_flow(db, flow).status == "succeeded"


class TestFlowVersioning:
    @staticmethod
    def _create_published_flow(client, auth_headers, project_id) -> dict:  # noqa: ANN001
        agents = client.get("/api/v1/agents", params={"limit": 200}, headers=auth_headers).json()["items"]
        agent_id = next(agent["id"] for agent in agents if agent["key"] == "user-story-completeness")
        nodes = [
            {"node_key": "start", "node_type": "start", "label": "Start", "position_x": 0, "position_y": 0},
            {"node_key": "check", "node_type": "agent", "label": "Check", "agent_id": agent_id, "position_x": 0, "position_y": 150},
        ]
        edges = [{"source_node_key": "start", "target_node_key": "check"}]
        created = client.post(
            "/api/v1/flows",
            json={"project_id": project_id, "name": f"Versioning {uuid.uuid4().hex[:8]}", "nodes": nodes, "edges": edges},
            headers=auth_headers,
        )
        assert created.status_code == 201, created.text
        published = client.post(f"/api/v1/flows/{created.json()['id']}/publish", headers=auth_headers)
        assert published.status_code == 200, published.text
        return published.json()

    @staticmethod
    def _nodes(flow: dict) -> list[dict]:
        return [{key: value for key, value in node.items() if key != "id"} for node in flow["nodes"]]

    @staticmethod
    def _edges(flow: dict) -> list[dict]:
        return [{key: value for key, value in edge.items() if key != "id"} for edge in flow["edges"]]

    def test_moving_nodes_keeps_the_published_version(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow = self._create_published_flow(client, auth_headers, project_id)
        nodes = self._nodes(flow)
        nodes[1]["position_x"] = 400

        response = client.patch(
            f"/api/v1/flows/{flow['id']}", json={"nodes": nodes, "edges": self._edges(flow)}, headers=auth_headers
        )
        assert response.status_code == 200, response.text
        assert response.json()["status"] == "published"

    def test_changing_a_step_returns_the_flow_to_draft(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        flow = self._create_published_flow(client, auth_headers, project_id)
        nodes = self._nodes(flow)
        nodes[1]["requires_approval"] = True

        response = client.patch(
            f"/api/v1/flows/{flow['id']}", json={"nodes": nodes, "edges": self._edges(flow)}, headers=auth_headers
        )
        assert response.status_code == 200, response.text
        assert response.json()["status"] == "draft"
