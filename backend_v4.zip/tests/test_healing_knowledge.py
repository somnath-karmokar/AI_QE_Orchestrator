"""What healing remembers, and how it is allowed to use it.

Memory is the difference between a platform that heals the same drift forty
times and one that heals it once. But memory is also where a self-healing system
most easily starts lying to itself: an index is a snapshot, and a repair that has
since been rolled back must never be recommended because an old embedding still
says it worked.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.healing.knowledge import (
    INDEXABLE_STATUSES,
    backfill,
    index_healing_outcome,
    similar_successful_heals,
)
from app.healing.policy import ChangeType
from app.healing.strategies import StrategyLadder
from app.models.testing import HealingRecord


def make_record(
    project_id: str,
    *,
    status: str = "applied",
    validation_status: str = "passed",
    original: str = 'page.get_by_test_id("checkout-submit-btn")',
    proposed: str = 'page.get_by_test_id("pay-now")',
    failure_class: str = "locator_drift",
    change_type: str = ChangeType.LOCATOR,
) -> HealingRecord:
    return HealingRecord(
        project_id=project_id,
        status=status,
        validation_status=validation_status,
        failure_class=failure_class,
        change_type=change_type,
        original_locator=original,
        proposed_locator=proposed,
        locator_strategy="test_id",
        reason="The test id was renamed in the redesign.",
        confidence=0.94,
    )


# ---------------------------------------------------------------------------
# Indexing
# ---------------------------------------------------------------------------


def test_a_decided_heal_is_indexed(db, project_id: str) -> None:
    record = make_record(project_id)
    db.add(record)
    db.flush()
    assert index_healing_outcome(db, record) is True


def test_a_failed_heal_is_indexed_too(db, project_id: str) -> None:
    """Knowing a repair was tried and did not hold is worth as much as knowing
    one worked -- it stops the platform proposing it again."""
    record = make_record(project_id, status="rolled_back", validation_status="failed")
    db.add(record)
    db.flush()
    assert index_healing_outcome(db, record) is True


def test_an_undecided_proposal_teaches_nothing(db, project_id: str) -> None:
    record = make_record(project_id, status="proposed", validation_status="not_started")
    db.add(record)
    db.flush()
    assert index_healing_outcome(db, record) is False


def test_every_indexable_status_is_a_decision() -> None:
    assert "proposed" not in INDEXABLE_STATUSES
    assert "validating" not in INDEXABLE_STATUSES
    assert "applied" in INDEXABLE_STATUSES


def test_indexing_never_breaks_the_heal(db, project_id: str, monkeypatch) -> None:
    """Failing to learn from a repair must not undo the repair."""
    from app.healing import knowledge as knowledge_module

    class Broken:
        def __init__(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
            raise RuntimeError("vector store unavailable")

    monkeypatch.setattr(knowledge_module, "KnowledgeService", Broken)

    record = make_record(project_id)
    db.add(record)
    db.flush()
    assert index_healing_outcome(db, record) is False  # reported, not raised


# ---------------------------------------------------------------------------
# Recall
# ---------------------------------------------------------------------------


def test_a_similar_failure_finds_a_repair_that_held(db, project_id: str) -> None:
    """The point of the whole module: an exact string match is rare, and a
    redesign renames forty test ids that are all the same problem."""
    record = make_record(project_id)
    db.add(record)
    db.flush()
    index_healing_outcome(db, record)

    hits = similar_successful_heals(
        db,
        project_id=project_id,
        failure_message='Locator resolved to 0 elements: page.get_by_test_id("checkout-submit-btn")',
        original_locator='page.get_by_test_id("checkout-submit-btn")',
        min_score=0.0,
    )
    assert any(hit["healing_record_id"] == record.id for hit in hits)


def test_a_rolled_back_repair_is_never_recommended(db, project_id: str) -> None:
    """The failure mode this guards: the index says it worked, the record says
    it was rolled back. The record wins."""
    record = make_record(project_id)
    db.add(record)
    db.flush()
    index_healing_outcome(db, record)

    # It later turned out not to hold.
    record.status = "rolled_back"
    record.validation_status = "failed"
    db.flush()

    hits = similar_successful_heals(
        db,
        project_id=project_id,
        failure_message="Locator resolved to 0 elements",
        original_locator='page.get_by_test_id("checkout-submit-btn")',
        min_score=0.0,
    )
    assert all(hit["healing_record_id"] != record.id for hit in hits)


def test_recall_of_nothing_is_empty_not_an_error(db, project_id: str) -> None:
    assert (
        similar_successful_heals(
            db, project_id=project_id, failure_message="", original_locator=""
        )
        == []
    )


def test_recall_failure_does_not_break_healing(db, project_id: str, monkeypatch) -> None:
    from app.healing import knowledge as knowledge_module

    class Broken:
        def __init__(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
            raise RuntimeError("vector store unavailable")

    monkeypatch.setattr(knowledge_module, "KnowledgeService", Broken)
    assert (
        similar_successful_heals(
            db, project_id=project_id, failure_message="anything", original_locator="x"
        )
        == []
    )


# ---------------------------------------------------------------------------
# Using it in the ladder
# ---------------------------------------------------------------------------


def test_the_ladder_recalls_a_similar_repair_not_just_an_exact_one(
    db, project_id: str
) -> None:
    """A different broken locator, the same underlying redesign."""
    from pathlib import Path  # noqa: PLC0415

    demo = Path(__file__).resolve().parents[1] / "app" / "demo_app" / "static"
    v2 = (demo / "v2" / "checkout.html").read_text(encoding="utf-8")

    remembered = make_record(
        project_id,
        original='page.get_by_test_id("promo-code")',
        proposed='page.get_by_test_id("discount-code")',
    )
    db.add(remembered)
    db.flush()
    index_healing_outcome(db, remembered)

    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        # Not the locator that was healed before -- a different one.
        original_locator='page.get_by_test_id("some-other-field")',
        fingerprint={"tag": "input", "role": "textbox", "name": "Promo code",
                     "test_id": "some-other-field"},
        dom_html=v2,
        failure_message=(
            'Locator resolved to 0 elements: page.get_by_test_id("promo-code") '
            "after the design system migration"
        ),
    )
    assert result.found
    # Either memory answered, or the DOM did -- both are legitimate. What must
    # not happen is proposing something absent from the page.
    assert "discount-code" in result.candidates[0]["locator"] or result.resolved_by != "known_healing"


def test_a_recalled_repair_is_still_checked_against_the_page(db, project_id: str) -> None:
    """Memory does not override evidence: a remembered locator that is not on
    this page is dropped, however well the failure matched."""
    from pathlib import Path  # noqa: PLC0415

    demo = Path(__file__).resolve().parents[1] / "app" / "demo_app" / "static"
    v2 = (demo / "v2" / "checkout.html").read_text(encoding="utf-8")

    remembered = make_record(
        project_id, proposed='page.get_by_test_id("long-since-removed")'
    )
    db.add(remembered)
    db.flush()
    index_healing_outcome(db, remembered)

    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator='page.get_by_test_id("checkout-submit-btn")',
        fingerprint={"tag": "button", "role": "button", "name": "Pay now",
                     "test_id": "checkout-submit-btn"},
        dom_html=v2,
        failure_message="Locator resolved to 0 elements",
    )
    assert all("long-since-removed" not in item["locator"] for item in result.candidates)


def test_a_recalled_repair_scores_below_an_exact_one(db, project_id: str) -> None:
    """A repair for a failure that merely *resembles* this one is a weaker
    claim, and the confidence says so."""
    from pathlib import Path  # noqa: PLC0415

    demo = Path(__file__).resolve().parents[1] / "app" / "demo_app" / "static"
    v2 = (demo / "v2" / "checkout.html").read_text(encoding="utf-8")

    exact = make_record(project_id)
    db.add(exact)
    db.flush()

    result = StrategyLadder(db).propose_locator(
        project_id=project_id,
        original_locator='page.get_by_test_id("checkout-submit-btn")',
        fingerprint={"tag": "button", "role": "button", "name": "Pay now",
                     "test_id": "checkout-submit-btn"},
        dom_html=v2,
        failure_message="Locator resolved to 0 elements",
    )
    assert result.resolved_by == "known_healing"
    assert result.candidates[0]["confidence"] == pytest.approx(0.95)


# ---------------------------------------------------------------------------
# Backfill
# ---------------------------------------------------------------------------


def test_backfill_indexes_existing_history(db, project_id: str) -> None:
    """So memory does not start empty on a platform that has been healing for
    months before this shipped."""
    for index in range(3):
        db.add(make_record(project_id, proposed=f'page.get_by_test_id("target-{index}")'))
    db.flush()

    indexed = backfill(db, project_id)
    decided = len(
        db.execute(
            select(HealingRecord).where(
                HealingRecord.project_id == project_id,
                HealingRecord.status.in_(sorted(INDEXABLE_STATUSES)),
            )
        ).scalars().all()
    )
    assert indexed == decided
    assert indexed >= 3
