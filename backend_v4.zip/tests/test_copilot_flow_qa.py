"""Copilot flow Q&A: a golden set of questions and what a good answer must contain.

This is the copilot's evaluation suite. Each case fixes the routing (which intent,
which flow) and asserts the facts the answer has to carry, so a change to the
planner, the wording or the underlying services cannot quietly make answers wrong.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.copilot.flow_resolver import resolve
from app.copilot.service import CopilotService
from app.models.conversation import Conversation
from app.models.flow import AgentFlow
from app.models.project import Project
from app.models.run import AgentRun


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


@pytest.fixture
def copilot(db) -> CopilotService:  # noqa: ANN001
    return CopilotService(db)


@pytest.fixture
def conversation(db, copilot, project) -> Conversation:  # noqa: ANN001
    return copilot.get_or_create_conversation(conversation_id=None, project_id=project.id, user_id=None)


def ask(copilot: CopilotService, conversation: Conversation, project: Project, question: str):  # noqa: ANN201
    return copilot.handle_message(
        conversation=conversation, message=question, project=project, actor="tester@example.com"
    )


def metrics(reply) -> dict[str, str]:  # noqa: ANN001
    return {item["label"]: item["value"] for item in (reply.evidence or []) if item.get("type") == "metric"}


class TestFlowResolution:
    @pytest.mark.parametrize(
        ("question", "expected_key"),
        [
            ("What does the Requirement to Automated Test flow do?", "requirement-to-automated-test"),
            ("how is the failed test to rca and defect flow doing", "failure-to-rca-defect"),
            ("Is the release readiness flow under control?", "release-readiness"),
            ("How often does the accessibility compliance sweep run?", "accessibility-compliance"),
        ],
    )
    def test_a_flow_named_loosely_is_resolved(self, db, project, question: str, expected_key: str) -> None:  # noqa: ANN001
        reference = resolve(db, question, project)
        assert reference.flow is not None and reference.flow.key == expected_key

    def test_an_ambiguous_question_offers_choices_instead_of_guessing(self, db, project) -> None:  # noqa: ANN001
        reference = resolve(db, "how is the payment flow doing?", project)
        assert reference.flow is None
        assert reference.candidates

    def test_a_run_number_resolves_to_that_run(self, db, project) -> None:  # noqa: ANN001
        run = db.execute(
            select(AgentRun).where(AgentRun.project_id == project.id, AgentRun.flow_id.is_not(None)).limit(1)
        ).scalar_one()
        reference = resolve(db, f"what happened in run #{run.run_number}?", project)
        assert reference.run is not None and reference.run.id == run.id
        assert reference.flow is not None and reference.flow.id == run.flow_id


class TestFlowAnswers:
    def test_it_explains_what_a_flow_does(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        reply = ask(copilot, conversation, project, "What does the Requirement to Automated Test flow do?")

        assert reply.plan_kind == "answer" and reply.intent == "flow_explain"
        assert reply.extracted_entities["flow_key"] == "requirement-to-automated-test"
        assert "User Story Completeness" in reply.content
        assert "approval" in reply.content.lower()
        assert metrics(reply)["Agents"] == "6"
        assert reply.navigation["route"].startswith("/flows/")

    def test_it_reports_a_flows_health_with_real_figures(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        flow = db.execute(select(AgentFlow).where(AgentFlow.key == "failure-to-rca-defect")).scalar_one()
        reply = ask(copilot, conversation, project, "How is the Failed Test to RCA and Defect flow doing?")

        assert reply.intent == "flow_health"
        figures = metrics(reply)
        assert {"Runs", "Success rate", "Typical run", "Cost per run"} <= set(figures)
        assert figures["Runs"].isdigit() and int(figures["Runs"]) > 0
        assert flow.name in reply.content
        assert reply.navigation["route"] == f"/flows/{flow.id}"

    def test_it_reviews_a_run_and_names_the_step_that_failed(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        failed = db.execute(
            select(AgentRun)
            .where(AgentRun.project_id == project.id, AgentRun.status == "failed", AgentRun.flow_id.is_not(None))
            .order_by(AgentRun.created_at.desc())
            .limit(1)
        ).scalar_one()
        reply = ask(copilot, conversation, project, f"Why did run #{failed.run_number} fail?")

        assert reply.intent == "flow_run_review"
        assert f"#{failed.run_number}" in reply.content
        assert "stopped at" in reply.content
        assert reply.navigation["route"] == f"/runs/{failed.id}"

    def test_it_lists_the_scheduled_flows(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        reply = ask(copilot, conversation, project, "Which flows are scheduled?")

        assert reply.intent == "flow_inventory"
        assert "Payment Regression Intelligence" in reply.content
        assert "Daily at 02:00 UTC" in reply.content
        assert reply.navigation["route"] == "/flows"

    def test_it_reports_governance_posture(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        reply = ask(copilot, conversation, project, "Is the Release Readiness Assessment flow under control?")

        assert reply.intent == "flow_governance"
        assert "governance checks" in reply.content
        assert reply.navigation["route"].endswith("/governance")

    def test_a_follow_up_stays_on_the_same_flow(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        ask(copilot, conversation, project, "How is the UAT Preparation Pack flow doing?")
        reply = ask(copilot, conversation, project, "Who owns it?")

        assert reply.extracted_entities["flow_name"] == "UAT Preparation Pack"
        assert "Sara" in reply.content or "sara" in reply.content

    def test_an_unknown_flow_is_admitted_not_invented(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        reply = ask(copilot, conversation, project, "How is the 'Nightly Payments Sweep' flow doing?")

        assert reply.plan_kind == "clarify"
        assert "could not find" in reply.content
        assert "Nightly Payments Sweep" in reply.content
        assert len(reply.suggestions) >= 2

    def test_knowledge_questions_are_not_captured_by_flow_routing(self, db, copilot, conversation, project) -> None:  # noqa: ANN001
        """A business question must still go to retrieval, not to a flow answer.

        The suite seeds without indexing documents, so the reply here is the honest
        "nothing indexed" message; what matters is that it was routed to knowledge.
        """
        reply = ask(copilot, conversation, project, "What is the daily payment limit?")

        assert reply.intent == "knowledge_question"
        assert reply.extracted_entities.get("flow_id") is None
        assert "10,000" in reply.content or "could not find anything" in reply.content


class TestAnswerFeedback:
    def test_an_answer_can_be_rated_and_the_rating_is_audited(self, client, auth_headers, project_id) -> None:  # noqa: ANN001
        turn = client.post(
            "/api/v1/copilot/message",
            json={"project_id": project_id, "message": "Which flows need attention?"},
            headers=auth_headers,
        )
        assert turn.status_code == 200, turn.text
        message_id = turn.json()["message"]["id"]

        rated = client.post(
            f"/api/v1/copilot/messages/{message_id}/feedback",
            json={"rating": "down", "note": "I wanted the failing step, not the list."},
            headers=auth_headers,
        )
        assert rated.status_code == 200, rated.text
        assert rated.json()["feedback"] == "down"

        audit = client.get("/api/v1/audit", params={"limit": 20}, headers=auth_headers).json()["items"]
        assert any(entry["action"] == "copilot.feedback" for entry in audit)
