"""Running on the caller's data, not on defaults that look like it.

The failure these prevent is quiet, and quiet failures are the expensive ones. A
calling platform sends `changed_moduls` instead of `changed_modules`; nothing
matches, the flow runs on its declared default, and the caller receives a green
result about the wrong requirement with no way to tell.

An error is a far better outcome than a wrong answer.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.models.flow import AgentFlow
from app.services.input_validation import describe_effective, validate_inputs
from app.services.integration_clients import issue_client

BASE = "/api/v1/integration"

SCHEMA = {
    "type": "object",
    "properties": {
        "requirement_key": {"type": "string"},
        "completeness_threshold": {"type": "integer"},
        "changed_modules": {"type": "array", "items": {"type": "string"}},
        "depth": {"type": "string", "enum": ["quick", "full"]},
    },
    "required": ["requirement_key"],
    "additionalProperties": False,
}
DEFAULTS = {"requirement_key": "PAY-201", "completeness_threshold": 80}


# ---------------------------------------------------------------------------
# The quiet failure
# ---------------------------------------------------------------------------


def test_a_mistyped_input_is_refused_not_ignored() -> None:
    """The whole point. Ignoring it means running on the default and reporting
    success about something the caller never asked for."""
    outcome = validate_inputs(SCHEMA, {"changed_moduls": ["Payments"]}, defaults=DEFAULTS)

    assert not outcome.ok
    error = outcome.errors[0]
    assert error.field == "changed_moduls"
    assert "no effect" in error.message
    assert error.suggestion == "changed_modules"


def test_a_key_too_different_to_guess_is_still_refused() -> None:
    outcome = validate_inputs(SCHEMA, {"totally_unrelated": 1}, defaults=DEFAULTS)
    assert not outcome.ok
    assert outcome.errors[0].suggestion is None


def test_correct_inputs_are_accepted() -> None:
    outcome = validate_inputs(
        SCHEMA,
        {"requirement_key": "PAY-999", "changed_modules": ["Payments"]},
        defaults=DEFAULTS,
    )
    assert outcome.ok


# ---------------------------------------------------------------------------
# Types and constraints
# ---------------------------------------------------------------------------


def test_a_wrong_type_is_reported_with_what_was_sent() -> None:
    outcome = validate_inputs(SCHEMA, {"completeness_threshold": "eighty"}, defaults=DEFAULTS)

    assert not outcome.ok
    message = outcome.errors[0].message
    assert "should be integer" in message
    assert "string was sent" in message


def test_a_boolean_is_not_accepted_as_a_number() -> None:
    """True is an int in Python. JSON Schema does not agree, and a flow that
    compares a threshold would behave very strangely."""
    outcome = validate_inputs(SCHEMA, {"completeness_threshold": True}, defaults=DEFAULTS)
    assert not outcome.ok


def test_array_item_types_are_checked() -> None:
    outcome = validate_inputs(SCHEMA, {"changed_modules": ["Payments", 7]}, defaults=DEFAULTS)
    assert not outcome.ok
    assert outcome.errors[0].field == "changed_modules[1]"


def test_an_enum_offers_the_nearest_valid_choice() -> None:
    outcome = validate_inputs(SCHEMA, {"depth": "quik"}, defaults=DEFAULTS)
    assert not outcome.ok
    assert outcome.errors[0].suggestion == "quick"


def test_a_required_field_with_no_default_is_demanded() -> None:
    outcome = validate_inputs(SCHEMA, {}, defaults={})
    assert not outcome.ok
    assert outcome.errors[0].field == "requirement_key"


def test_a_required_field_covered_by_a_default_is_fine() -> None:
    """The flow supplies it, so the caller need not."""
    assert validate_inputs(SCHEMA, {}, defaults=DEFAULTS).ok


def test_every_problem_is_reported_not_just_the_first() -> None:
    """A caller fixing one field at a time across four round trips is a bad
    integration experience."""
    outcome = validate_inputs(
        SCHEMA,
        {"changed_moduls": [], "completeness_threshold": "eighty", "depth": "quik"},
        defaults=DEFAULTS,
    )
    assert len(outcome.errors) == 3


# ---------------------------------------------------------------------------
# What will actually be used
# ---------------------------------------------------------------------------


def test_the_effective_inputs_show_where_each_value_came_from() -> None:
    outcome = validate_inputs(SCHEMA, {"requirement_key": "PAY-999"}, defaults=DEFAULTS)
    applied = describe_effective(outcome.effective, {"requirement_key": "PAY-999"})

    assert applied["requirement_key"] == {"value": "PAY-999", "source": "caller"}
    assert applied["completeness_threshold"] == {"value": 80, "source": "flow_default"}


def test_internal_variables_are_not_echoed_back() -> None:
    applied = describe_effective({"_run_id": "x", "module": "Payments"}, {})
    assert "_run_id" not in applied
    assert "module" in applied


# ---------------------------------------------------------------------------
# Over the wire
# ---------------------------------------------------------------------------


@pytest.fixture
def runnable(db, project_id: str):
    """A published flow with variables, and a key that may run it."""
    flow = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.is_deleted.is_(False),
            AgentFlow.status == "published",
        )
    ).scalars().first()
    assert flow is not None and flow.variables, "need a published flow with variables"

    _record, token = issue_client(
        db,
        project_id=project_id,
        name="validating-caller",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()
    return flow, token


def test_a_typo_is_rejected_over_rest_with_a_suggestion(client, runnable) -> None:
    flow, token = runnable
    known = sorted(flow.variables)[0]
    typo = known[:-1] + "x"

    response = client.post(
        f"{BASE}/flows/{flow.id}/runs",
        headers={"X-API-Key": token},
        json={"inputs": {typo: "anything"}},
    )
    assert response.status_code == 422, response.text
    details = response.json()["error"]["details"]
    assert details["invalid_inputs"][0]["field"] == typo
    assert details["invalid_inputs"][0]["did_you_mean"] == known
    # And it says what the flow does accept, so the fix is obvious.
    assert known in details["accepts"]


def test_an_accepted_run_reports_exactly_what_it_will_use(client, runnable) -> None:
    """So "run it with my data" is verifiable rather than taken on trust."""
    flow, token = runnable
    known = sorted(flow.variables)[0]
    sent = flow.variables[known]

    response = client.post(
        f"{BASE}/flows/{flow.id}/runs",
        headers={"X-API-Key": token},
        json={"inputs": {known: sent}},
    )
    assert response.status_code == 202, response.text
    applied = response.json()["inputs_applied"]

    assert applied[known]["source"] == "caller"
    for name, entry in applied.items():
        if name != known:
            assert entry["source"] == "flow_default"


def test_the_published_schema_matches_what_is_enforced(client, runnable) -> None:
    """The contract said `additionalProperties: true` while unknown keys were
    being rejected. A contract that does not describe the behaviour is worse
    than none."""
    flow, token = runnable
    catalog = client.get(f"{BASE}/catalog", headers={"X-API-Key": token}).json()
    entry = next(item for item in catalog["flows"] if item["id"] == flow.id)

    assert entry["input_schema"]["additionalProperties"] is False


def test_the_same_rejection_happens_over_mcp(client, runnable) -> None:
    """An agent that mistypes an argument must be told, exactly as a pipeline
    would be. Two doors, one behaviour."""
    from app.services.mcp_tools import tool_name

    flow, token = runnable
    known = sorted(flow.variables)[0]
    typo = known[:-1] + "x"

    response = client.post(
        "/api/v1/mcp",
        headers={"X-API-Key": token},
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": tool_name("run_flow", flow.key), "arguments": {typo: "x"}},
        },
    )
    result = response.json()["result"]
    assert result["isError"] is True
    assert "do not match" in result["content"][0]["text"]
