"""The MCP server that lets an agent read a customer's own connected systems.

This is the one tool whose arguments a model composes from untrusted content, so
what matters is what an argument *cannot* do: it cannot name another tenant's
project, it cannot steer the request off the source's own host, and it cannot
turn a read-only connection into a write.
"""

from __future__ import annotations

import uuid

import pytest

from app.core.errors import ToolExecutionError
from app.mcp.servers.tenant_data import TenantDataAdapter
from app.models.project import Project
from app.services import data_sources


@pytest.fixture
def other_project(db) -> Project:  # noqa: ANN001
    project = Project(key=f"TDT{uuid.uuid4().hex[:5].upper()}", name="Another customer")
    db.add(project)
    db.commit()
    return project


@pytest.fixture
def api_source(db, project_id):  # noqa: ANN001, ANN201
    source = data_sources.create(
        db,
        project_id=project_id,
        name=f"Their API {uuid.uuid4().hex[:6]}",
        kind="rest_api",
        connection={"base_url": "https://api.customer.example", "api_key": "sk-not-real"},
        actor="test",
    )
    db.commit()
    return source


def adapter_for(db, project_id: str) -> TenantDataAdapter:  # noqa: ANN001
    return TenantDataAdapter({"session": db, "project_id": project_id})


def test_it_lists_only_this_projects_sources(db, project_id, other_project, api_source) -> None:  # noqa: ANN001
    theirs = data_sources.create(
        db,
        project_id=other_project.id,
        name="Their warehouse",
        kind="postgres",
        connection={"host": "their-db.example", "database": "theirs", "password": "nope"},
        actor="them",
    )
    db.commit()

    listed = adapter_for(db, project_id).tool_list_sources()
    keys = [row["key"] for row in listed]

    assert api_source.key in keys
    assert theirs.key not in keys


def test_the_listing_carries_no_credential_material(db, project_id, api_source) -> None:  # noqa: ANN001
    listed = adapter_for(db, project_id).tool_list_sources()
    assert "sk-not-real" not in str(listed)
    assert all("secret" not in key and "credential" not in key for row in listed for key in row)


def test_an_agent_cannot_name_another_tenants_source(db, project_id, other_project) -> None:  # noqa: ANN001
    """The project comes from the run, so a key from elsewhere simply is not there."""
    theirs = data_sources.create(
        db,
        project_id=other_project.id,
        name="Their warehouse",
        kind="rest_api",
        connection={"base_url": "https://their-api.example", "api_key": "theirs"},
        actor="them",
    )
    db.commit()

    with pytest.raises(ToolExecutionError) as refused:
        adapter_for(db, project_id).tool_fetch(source=theirs.key, path="/orders")

    assert "no connected data source" in str(refused.value)


def test_a_path_cannot_steer_the_request_off_the_sources_host(db, project_id, api_source) -> None:  # noqa: ANN001
    """`path` is composed by a model, and a model reads untrusted content."""
    adapter = adapter_for(db, project_id)

    # An absolute URL is refused outright: it names a host of its own.
    for escape in ("https://evil.example/steal", "http://169.254.169.254/latest/meta-data/"):
        with pytest.raises(ToolExecutionError) as refused:
            adapter.tool_fetch(source=api_source.key, path=escape)
        assert "outside the data source" in str(refused.value), escape

    # A protocol-relative URL is flattened onto the source's own host instead of
    # being refused, so it never reaches the named host either. Asserted through
    # the failure it *does* produce: resolving the source's host, not evil's.
    with pytest.raises(ToolExecutionError) as refused:
        adapter.tool_fetch(source=api_source.key, path="//evil.example/steal")
    assert "evil.example" not in str(refused.value)
    assert "api.customer.example" in str(refused.value)


def test_a_read_only_source_refuses_a_write(db, project_id, api_source) -> None:  # noqa: ANN001
    with pytest.raises(ToolExecutionError) as refused:
        adapter_for(db, project_id).tool_fetch(
            source=api_source.key, path="/orders", method="POST"
        )

    assert "read-only" in str(refused.value)


def test_a_kind_it_cannot_call_says_so_rather_than_inventing(db, project_id) -> None:  # noqa: ANN001
    """The one stand-in that would be indistinguishable from a real breach."""
    warehouse = data_sources.create(
        db,
        project_id=project_id,
        name=f"Warehouse {uuid.uuid4().hex[:6]}",
        kind="postgres",
        connection={"host": "db.customer.example", "database": "orders", "password": "x"},
        actor="test",
    )
    db.commit()

    with pytest.raises(ToolExecutionError) as refused:
        adapter_for(db, project_id).tool_fetch(source=warehouse.key, path="/orders")

    message = str(refused.value)
    assert "not implemented" in message
    assert "nothing was fetched" in message


def test_a_disabled_source_is_refused(db, project_id, api_source) -> None:  # noqa: ANN001
    api_source.is_enabled = False
    db.commit()

    with pytest.raises(ToolExecutionError) as refused:
        adapter_for(db, project_id).tool_fetch(source=api_source.key, path="/orders")

    assert "disabled" in str(refused.value)


def test_without_a_project_in_context_nothing_resolves(db) -> None:  # noqa: ANN001
    """A missing project must fail, never fall back to "all projects"."""
    with pytest.raises(ToolExecutionError):
        TenantDataAdapter({"session": db}).tool_list_sources()
