"""Suite execution as the live Execution Center sees it."""

from __future__ import annotations

from sqlalchemy import select

from app.core.database import SessionLocal
from app.execution import service as execution_service
from app.execution.service import ExecutionService
from app.models.project import Project
from app.models.testing import Execution


def test_progress_is_visible_to_other_sessions_while_the_suite_runs(db, monkeypatch) -> None:  # noqa: ANN001
    project = db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()
    execution = ExecutionService(db).create(project_id=project.id, module="Payments", triggered_by="tester@example.com")
    db.commit()

    seen: list[tuple[int, int]] = []

    def observe(topic, event_type, payload):  # noqa: ANN001, ARG001
        # Read the way the web app does: from a separate session, after each test.
        if event_type != "test_completed":
            return
        with SessionLocal() as reader:
            row = reader.get(Execution, payload["execution_id"])
            seen.append((payload["completed"], row.passed + row.failed + row.flaky))

    monkeypatch.setattr(execution_service.event_bus, "publish", observe)
    monkeypatch.setattr(execution_service.time, "sleep", lambda _seconds: None)

    ExecutionService(db).run(execution.id)

    assert seen, "no tests ran"
    assert all(completed == counted for completed, counted in seen), seen
