"""Governed self-healing.

These tests exist to keep three promises honest:

  1. A heal is never recorded as successful without a re-run that produced it.
  2. A change the policy matrix forbids cannot be approved by anyone.
  3. Every healing decision leaves an audit trail.

The first is the one that was previously broken: approving a proposal wrote
`result_after = "passed"` and bumped the script version without running anything.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app.core.errors import ValidationError
from app.healing.config import HealingConfig
from app.healing.policy import ChangeType, change_type_for, evaluate_change
from app.healing.service import HealingService
from app.healing.validation import HealingValidationService, build_patch
from app.models.governance import ApprovalRequest, AuditLog
from app.models.testing import Execution, ExecutionTest, HealingRecord, TestScript


# ---------------------------------------------------------------------------
# Policy matrix
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "change_type",
    [ChangeType.ASSERTION, ChangeType.BUSINESS_RULE, ChangeType.TEST_LOGIC],
)
def test_business_logic_is_never_healable(change_type: str) -> None:
    """No confidence, however high, unlocks an assertion change."""
    gate = evaluate_change(change_type=change_type, confidence=1.0)
    assert gate.allowed is False
    assert gate.decision == "blocked"
    assert any("never change" in reason for reason in gate.reasons)


def test_unknown_change_type_is_forbidden_by_default() -> None:
    """A change type nobody has classified is refused, not waved through."""
    gate = evaluate_change(change_type="something_new", confidence=0.99)
    assert gate.allowed is False


def test_high_confidence_locator_change_may_auto_apply() -> None:
    gate = evaluate_change(change_type=ChangeType.LOCATOR, confidence=0.94)
    assert gate.allowed is True
    assert gate.requires_approval is False
    assert gate.decision == "auto_apply"


def test_low_confidence_falls_below_the_proposal_floor() -> None:
    gate = evaluate_change(change_type=ChangeType.LOCATOR, confidence=0.20)
    assert gate.allowed is False
    assert any("floor" in reason for reason in gate.reasons)


def test_confidence_between_thresholds_requires_a_human() -> None:
    gate = evaluate_change(change_type=ChangeType.LOCATOR, confidence=0.70)
    assert gate.allowed is True
    assert gate.requires_approval is True
    assert gate.decision == "human_review"


def test_ambiguous_candidates_require_a_human_despite_high_confidence() -> None:
    """Two candidates that score alike mean we do not know which element it is."""
    gate = evaluate_change(
        change_type=ChangeType.LOCATOR, confidence=0.95, runner_up_confidence=0.93
    )
    assert gate.requires_approval is True
    assert any("ambiguous" in reason for reason in gate.reasons)


def test_test_data_changes_always_need_an_approver() -> None:
    """Even at full confidence: substituting data changes what was tested."""
    gate = evaluate_change(change_type=ChangeType.TEST_DATA, confidence=0.99)
    assert gate.allowed is True
    assert gate.requires_approval is True


def test_disabled_healing_blocks_everything() -> None:
    config = HealingConfig(enabled=False)
    gate = evaluate_change(change_type=ChangeType.LOCATOR, confidence=0.99, config=config)
    assert gate.allowed is False


def test_failure_classes_map_only_to_healable_change_types() -> None:
    assert change_type_for("locator_drift") == ChangeType.LOCATOR
    assert change_type_for("timing") == ChangeType.TIMING
    # An application defect is a real bug; healing has no business touching it.
    assert change_type_for("application_defect") is None
    assert change_type_for("environment") is None


# ---------------------------------------------------------------------------
# Confidence scoring
# ---------------------------------------------------------------------------


def test_confidence_is_weighted_and_normalised_over_measured_signals() -> None:
    config = HealingConfig()
    both = config.score({"strategy_robustness": 1.0, "accessibility_match": 0.0})
    # 0.30 and 0.15 of the weight, normalised over the two that were measured.
    assert both == pytest.approx(0.30 / 0.45, abs=0.001)
    # An unmeasured signal neither helps nor harms.
    only_one = config.score({"strategy_robustness": 1.0})
    assert only_one == pytest.approx(1.0)


def test_confidence_breakdown_explains_the_number() -> None:
    config = HealingConfig()
    rows = config.breakdown({"strategy_robustness": 0.9, "accessibility_match": 0.5})
    assert [row["signal"] for row in rows] == ["strategy_robustness", "accessibility_match"]
    assert sum(float(row["weight"]) for row in rows) == pytest.approx(1.0)
    assert sum(float(row["contribution"]) for row in rows) == pytest.approx(
        config.score({"strategy_robustness": 0.9, "accessibility_match": 0.5}), abs=0.001
    )


def test_unknown_signals_are_ignored_rather_than_trusted() -> None:
    config = HealingConfig()
    assert config.score({"vibes": 1.0}) == 0.0


# ---------------------------------------------------------------------------
# The validation lifecycle
# ---------------------------------------------------------------------------


def _proposal(db, project_id: str) -> HealingRecord:
    """A fresh proposal against a real failing test from the seeded demo data."""
    test = db.execute(
        select(ExecutionTest).where(ExecutionTest.failure_signature == "LOCATOR_NOT_FOUND")
    ).scalars().first()
    assert test is not None, "the demo data should contain locator failures"

    record = HealingRecord(
        project_id=project_id,
        test_script_id=test.test_script_id,
        execution_test_id=test.id,
        status="proposed",
        failure_class="locator_drift",
        change_type=ChangeType.LOCATOR,
        original_locator='page.get_by_test_id("payment-submit-btn")',
        proposed_locator='page.get_by_role("button", name="Continue")',
        locator_strategy="role",
        reason="Accessible role and name survive DOM restructuring.",
        confidence=0.93,
        result_before="failed",
    )
    db.add(record)
    db.flush()
    return record


def test_approving_does_not_claim_a_validation_it_did_not_run(db, project_id: str) -> None:
    """The regression this whole phase exists to prevent."""
    record = _proposal(db, project_id)
    HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")
    db.refresh(record)

    # Whatever the re-run concluded, the record must not be in a state where it
    # claims success without evidence.
    assert record.validation_status in {"passed", "failed", "inconclusive"}
    if record.result_after == "passed":
        assert record.validation_evidence, "a pass must carry the re-run that produced it"
        assert record.validated_at is not None
        assert any(item.get("type") == "rerun" for item in record.validation_evidence)
    else:
        assert record.validated_at is None


def test_approval_creates_a_real_rerun_carrying_the_patch(db, project_id: str) -> None:
    """The re-run is an actual execution, and the patch travels in its config
    rather than being written to the script."""
    record = _proposal(db, project_id)
    HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")
    db.refresh(record)

    assert record.attempt_count == 1
    assert record.validation_execution_id, "approval must produce a re-run execution"

    execution = db.get(Execution, record.validation_execution_id)
    assert execution is not None
    assert execution.trigger == "healing_validation"
    assert execution.config["healing_patch"]["to"] == record.proposed_locator
    assert execution.config["healing_patch"]["from"] == record.original_locator
    # One test, the one that failed -- not the whole suite.
    assert execution.total_tests == 1


def test_a_passing_rerun_versions_the_script(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    script = db.get(TestScript, record.test_script_id)
    version_before = script.version

    HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")
    db.refresh(record)
    db.refresh(script)

    if record.status == "applied":
        assert script.version == version_before + 1
        assert record.script_version_after == script.version
        assert record.result_after == "passed"
    else:
        # The heal did not survive its re-run, so the script is untouched.
        assert script.version == version_before
        assert record.status in {"rolled_back", "validation_failed"}
        assert record.script_version_after is None


def test_a_failed_rerun_leaves_the_script_alone(db, project_id: str, monkeypatch) -> None:
    """Force the re-run to fail and confirm nothing is persisted."""
    from app.healing import validation as validation_module

    record = _proposal(db, project_id)
    script = db.get(TestScript, record.test_script_id)
    version_before = script.version
    locators_before = list(script.locators or [])

    def failing_rerun(self, rec):  # noqa: ANN001, ANN202, ARG001
        return validation_module.ValidationOutcome(
            status="failed",
            mode="simulated",
            execution_id=None,
            result="failed",
            evidence=[{"type": "rerun", "detail": "Still failed with the patch applied."}],
        )

    monkeypatch.setattr(validation_module.HealingValidationService, "_rerun", failing_rerun)

    HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")
    db.refresh(record)
    db.refresh(script)

    assert record.status == "rolled_back"
    assert record.result_after == "failed"
    assert record.validated_at is None
    assert record.rolled_back_at is not None
    assert script.version == version_before
    assert script.locators == locators_before


def test_the_patch_is_never_written_to_the_script_before_validation(db, project_id: str) -> None:
    """A patch is configuration handed to a run, not an edit to the script."""
    record = _proposal(db, project_id)
    patch = build_patch(record)
    script = db.get(TestScript, record.test_script_id)

    assert patch["from"] == record.original_locator
    assert patch["to"] == record.proposed_locator
    # Building a patch changes nothing.
    assert record.proposed_locator not in (script.code or "")


def test_a_forbidden_change_cannot_be_approved_by_a_human(db, project_id: str) -> None:
    """The last line of defence: the approve button itself refuses."""
    record = _proposal(db, project_id)
    record.change_type = ChangeType.ASSERTION
    db.flush()

    with pytest.raises(ValidationError):
        HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")

    db.refresh(record)
    assert record.status == "blocked"
    assert record.result_after is None


def test_rejecting_records_the_decision_without_touching_the_script(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    script = db.get(TestScript, record.test_script_id)
    version_before = script.version

    HealingService(db).decide(record.id, decision="reject", actor="qe.lead@example.com")
    db.refresh(record)
    db.refresh(script)

    assert record.status == "rejected"
    assert record.approver == "qe.lead@example.com"
    assert record.result_after is None
    assert script.version == version_before


def test_a_decided_record_cannot_be_decided_again(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    HealingService(db).decide(record.id, decision="reject", actor="qe.lead@example.com")
    with pytest.raises(ValidationError):
        HealingService(db).decide(record.id, decision="approve", actor="someone.else@example.com")


def test_a_flaky_rerun_proves_nothing_and_applies_nothing(db, project_id: str, monkeypatch) -> None:
    """Passing only on a retry is not evidence the change worked."""
    from app.healing import validation as validation_module

    record = _proposal(db, project_id)
    script = db.get(TestScript, record.test_script_id)
    version_before = script.version

    def flaky_rerun(self, rec):  # noqa: ANN001, ANN202, ARG001
        outcome = validation_module.ValidationOutcome(
            status="inconclusive", mode="simulated", result="flaky", evidence=[]
        )
        return outcome

    monkeypatch.setattr(validation_module.HealingValidationService, "_rerun", flaky_rerun)
    HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")
    db.refresh(record)
    db.refresh(script)

    assert record.status == "validation_failed"
    assert record.result_after is None
    assert record.validated_at is None
    assert script.version == version_before


def test_attempts_are_capped(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    record.status = "approved"
    record.attempt_count = 99
    db.flush()

    HealingValidationService(db).validate(record, actor="system")
    db.refresh(record)
    assert record.status == "validation_failed"
    assert any(
        item.get("type") == "attempts_exhausted" for item in (record.validation_evidence or [])
    )


# ---------------------------------------------------------------------------
# Governance
# ---------------------------------------------------------------------------


def test_a_proposal_needing_review_joins_the_shared_approval_queue(db, project_id: str) -> None:
    """Healing approvals belong in the same queue as every other risky action."""
    record = _proposal(db, project_id)
    approval = HealingService(db).request_approval(record, requested_by="self-healing-automation")

    assert approval.subject_type == "healing_record"
    assert approval.subject_ref == record.id
    assert approval.status == "pending"
    assert record.approval_request_id == approval.id
    # The reviewer can see what they are approving and what happens next.
    assert approval.proposed_action["to"] == record.proposed_locator
    assert "re-run" in approval.proposed_action["validation"]


def test_deciding_resolves_the_linked_approval_request(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    service = HealingService(db)
    approval = service.request_approval(record)

    service.decide(record.id, decision="reject", actor="qe.lead@example.com")
    db.refresh(approval)

    assert approval.status == "rejected"
    assert approval.decided_by == "qe.lead@example.com"
    assert approval.decided_at is not None


def test_every_healing_decision_is_audited(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")

    entries = list(
        db.execute(
            select(AuditLog)
            .where(AuditLog.entity_type == "healing_record", AuditLog.entity_id == record.id)
            .order_by(AuditLog.created_at)
        )
        .scalars()
        .all()
    )
    actions = [entry.action for entry in entries]
    assert "healing.approved" in actions
    # The validation outcome is audited separately from the human decision.
    assert any(action.startswith("healing.validat") for action in actions)

    approved = next(entry for entry in entries if entry.action == "healing.approved")
    assert approved.actor == "qe.lead@example.com"
    assert approved.input_summary["from"] == record.original_locator
    assert approved.input_summary["to"] == record.proposed_locator


def test_blocked_approval_is_audited_as_denied(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    record.change_type = ChangeType.BUSINESS_RULE
    db.flush()

    with pytest.raises(ValidationError):
        HealingService(db).decide(record.id, decision="approve", actor="qe.lead@example.com")

    entry = db.execute(
        select(AuditLog).where(
            AuditLog.entity_id == record.id, AuditLog.action == "healing.blocked"
        )
    ).scalars().first()
    assert entry is not None
    assert entry.outcome == "denied"


# ---------------------------------------------------------------------------
# API surface
# ---------------------------------------------------------------------------


def test_healing_api_exposes_the_validation_state(client, auth_headers, project_id: str) -> None:
    response = client.get(
        "/api/v1/healing", headers=auth_headers, params={"project_id": project_id, "limit": 5}
    )
    assert response.status_code == 200, response.text
    items = response.json()["items"]
    assert items, "the demo project should contain healing records"

    for item in items:
        assert "validation_status" in item
        assert "change_type" in item
        # An applied record must carry the evidence for its claim.
        if item["result_after"] == "passed":
            assert item["validation_status"] == "passed"
            assert item["validation_evidence"]


def test_decide_endpoint_runs_the_validation(client, auth_headers, db, project_id: str) -> None:
    record = _proposal(db, project_id)
    db.commit()

    response = client.post(
        f"/api/v1/healing/{record.id}/decide",
        headers=auth_headers,
        params={"decision": "approve"},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["attempt_count"] == 1
    assert body["validation_status"] in {"passed", "failed", "inconclusive"}
    if body["result_after"] == "passed":
        assert body["validation_evidence"]


def test_decide_endpoint_refuses_a_forbidden_change(client, auth_headers, db, project_id: str) -> None:
    record = _proposal(db, project_id)
    record.change_type = ChangeType.ASSERTION
    db.commit()

    response = client.post(
        f"/api/v1/healing/{record.id}/decide",
        headers=auth_headers,
        params={"decision": "approve"},
    )
    assert response.status_code == 422, response.text
    assert "cannot be approved" in response.text


def test_records_predating_the_migration_are_readable() -> None:
    """A JSON column added to a live database by hand can be NULL on older rows.

    The migration backfills and enforces NOT NULL, but a database patched outside
    it should still read rather than 500 -- which is exactly what the demo
    database did before this was handled.
    """
    from app.schemas.entities import HealingRecordOut  # noqa: PLC0415

    record = HealingRecordOut.model_validate(
        {
            "id": "abc",
            "status": "proposed",
            "failure_class": "locator_drift",
            "original_locator": "#old",
            "proposed_locator": "#new",
            "locator_strategy": "role",
            "reason": "because",
            "confidence": 0.9,
            "candidates": None,
            "evidence": None,
            "confidence_breakdown": None,
            "validation_evidence": None,
            "patch": None,
            "policy_decision": None,
        }
    )
    assert record.confidence_breakdown == []
    assert record.validation_evidence == []
    assert record.candidates == []
    assert record.patch == {}
    assert record.policy_decision == {}


def test_seeded_history_contains_a_heal_that_failed_validation(db) -> None:
    """Demo data must show validation as a real gate, not a formality."""
    rolled_back = db.execute(
        select(HealingRecord).where(HealingRecord.status == "rolled_back")
    ).scalars().first()
    assert rolled_back is not None
    assert rolled_back.script_version_after is None


def test_no_seeded_record_claims_a_pass_without_evidence(db) -> None:
    records = list(db.execute(select(HealingRecord)).scalars().all())
    assert records
    for record in records:
        if record.result_after == "passed":
            assert record.validation_evidence, f"{record.id} claims a pass with no re-run"
            assert record.validated_at is not None


def test_pending_healing_approvals_are_visible_to_governance(db, project_id: str) -> None:
    record = _proposal(db, project_id)
    HealingService(db).request_approval(record)

    pending = list(
        db.execute(
            select(ApprovalRequest).where(
                ApprovalRequest.subject_type == "healing_record",
                ApprovalRequest.status == "pending",
            )
        )
        .scalars()
        .all()
    )
    assert any(item.subject_ref == record.id for item in pending)
