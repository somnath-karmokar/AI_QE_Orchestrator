"""Agent collaboration: the graph state, conversation and shared context of a run."""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import select

from app.models.agent import Agent
from app.models.flow import AgentFlow, AgentFlowEdge, AgentFlowNode
from app.models.project import Project
from app.models.run import AgentRun, AgentRunStep
from app.orchestration.factory import build_engine
from app.services.run_collaboration import run_collaboration
from app.services.run_service import RunService


pytestmark = pytest.mark.usefixtures("orchestration_engine")


@pytest.fixture
def project(db) -> Project:  # noqa: ANN001
    return db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()


def _agent(db, key: str) -> Agent:  # noqa: ANN001
    return db.execute(select(Agent).where(Agent.key == key)).scalar_one()


def _gated_flow(db, project: Project, threshold: int) -> AgentFlow:  # noqa: ANN001
    """start -> completeness -> decision -> (yes) scenarios -> end, (no) end."""
    flow = AgentFlow(
        project_id=project.id,
        key=f"collab-{uuid.uuid4().hex[:8]}",
        name="Collaboration check",
        status="published",
        variables={"requirement_key": "PAY-201", "completeness_threshold": threshold},
    )
    db.add(flow)
    db.flush()
    db.add_all(
        [
            AgentFlowNode(flow_id=flow.id, node_key="start", node_type="start", label="Start", position_y=0),
            AgentFlowNode(
                flow_id=flow.id,
                node_key="completeness",
                node_type="agent",
                label="Check readiness",
                agent_id=_agent(db, "user-story-completeness").id,
                input_mapping={"requirement_key": "$requirement_key", "threshold": "$completeness_threshold"},
                position_y=150,
            ),
            AgentFlowNode(
                flow_id=flow.id,
                node_key="ready",
                node_type="condition",
                label="Ready?",
                condition_expression="user_story_completeness.outputs.completeness_score >= completeness_threshold",
                position_y=300,
            ),
            AgentFlowNode(
                flow_id=flow.id,
                node_key="scenarios",
                node_type="agent",
                label="Generate scenarios",
                agent_id=_agent(db, "test-scenario-generator").id,
                input_mapping={"requirement_key": "$requirement_key"},
                position_y=450,
            ),
            AgentFlowNode(flow_id=flow.id, node_key="end", node_type="end", label="Done", position_y=600),
            AgentFlowNode(flow_id=flow.id, node_key="stop", node_type="end", label="Not ready", position_x=340, position_y=450),
            AgentFlowEdge(flow_id=flow.id, source_node_key="start", target_node_key="completeness"),
            AgentFlowEdge(flow_id=flow.id, source_node_key="completeness", target_node_key="ready"),
            AgentFlowEdge(flow_id=flow.id, source_node_key="ready", target_node_key="scenarios", branch_label="true"),
            AgentFlowEdge(flow_id=flow.id, source_node_key="ready", target_node_key="stop", branch_label="false"),
            AgentFlowEdge(flow_id=flow.id, source_node_key="scenarios", target_node_key="end"),
        ]
    )
    db.flush()
    db.refresh(flow)
    return flow


def _run(db, flow: AgentFlow) -> AgentRun:  # noqa: ANN001
    run = RunService(db).start_flow_run(
        flow_id=flow.id, project_id=flow.project_id, inputs=dict(flow.variables), triggered_by="priya.raman@example.com"
    )
    return build_engine(db).execute_run(run.id)


class TestLiveRunCollaboration:
    def test_agents_hand_over_through_the_shared_context(self, db, project) -> None:  # noqa: ANN001
        run = _run(db, _gated_flow(db, project, threshold=0))
        assert run.status == "succeeded"

        view = run_collaboration(db, run)
        kinds = [message["kind"] for message in view["conversation"]]
        assert kinds[0] == "kickoff" and kinds[-1] == "complete"
        assert kinds.count("handoff") == 2 and "decision" in kinds

        first_handoff = next(message for message in view["conversation"] if message["kind"] == "handoff")
        assert first_handoff["from"] == "completeness" and first_handoff["to"] == ["ready"]
        assert first_handoff["edges"] == ["completeness->ready"]

        decision = next(message for message in view["conversation"] if message["kind"] == "decision")
        assert decision["to"] == ["scenarios"]
        assert decision["data"]["reads"][0]["from"] == "completeness"
        assert "completeness_score" in decision["data"]["reads"][0]["path"]

        pickup = next(
            message for message in view["conversation"] if message["kind"] == "acknowledge" and message["from"] == "scenarios"
        )
        assert "Check readiness" in pickup["text"] and "PAY-201" in pickup["text"]

        context = {entry["key"]: entry for entry in view["context"]}
        assert context["user_story_completeness"]["written_by"] == "completeness"
        assert "ready" in context["user_story_completeness"]["used_by"]
        assert context["requirement_key"]["kind"] == "input"
        assert view["stats"]["agents"] == 2 and view["stats"]["handoffs"] == 2

    def test_the_path_not_taken_is_marked_on_the_graph(self, db, project) -> None:  # noqa: ANN001
        run = _run(db, _gated_flow(db, project, threshold=101))
        view = run_collaboration(db, run)

        edges = {edge["id"]: edge for edge in view["graph"]["edges"]}
        nodes = {node["node_key"]: node for node in view["graph"]["nodes"]}
        assert edges["ready->stop"]["state"] == "traversed"
        assert edges["ready->scenarios"]["state"] == "not_taken"
        assert nodes["scenarios"]["state"] == "not_reached"
        assert nodes["completeness"]["state"] == "succeeded"
        assert edges["completeness->ready"]["handoff"]["summary"]


class TestSeededRunCollaboration:
    def test_seeded_decisions_agree_with_the_numbers_agents_reported(self, client, auth_headers, db) -> None:  # noqa: ANN001
        flow = db.execute(select(AgentFlow).where(AgentFlow.key == "requirement-to-automated-test")).scalar_one()
        runs = list(db.execute(select(AgentRun).where(AgentRun.flow_id == flow.id)).scalars())
        checked = 0
        for run in runs:
            gate = db.execute(
                select(AgentRunStep).where(AgentRunStep.run_id == run.id, AgentRunStep.node_key == "gate")
            ).scalar_one_or_none()
            if gate is None:
                continue
            response = client.get(f"/api/v1/runs/{run.id}/collaboration", headers=auth_headers)
            assert response.status_code == 200, response.text
            decision = next(message for message in response.json()["conversation"] if message["kind"] == "decision")
            score = float(decision["data"]["reads"][0]["value"])
            assert (score >= 80) == decision["data"]["result"]
            checked += 1
            if checked >= 5:
                break
        assert checked
