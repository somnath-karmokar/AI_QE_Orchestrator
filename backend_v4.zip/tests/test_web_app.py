"""The API serves the built web app on its own port, so a demo is one process."""

from __future__ import annotations


def test_client_side_routes_fall_back_to_the_app(client) -> None:  # noqa: ANN001
    for path in ("/", "/marketplace", "/runs/some-run-id"):
        response = client.get(path)
        assert response.status_code == 200, path
        assert response.headers["content-type"].startswith("text/html")
        assert '<div id=root>' in response.text
        assert response.headers["cache-control"] == "no-cache"


def test_scripts_are_served_as_javascript(client) -> None:  # noqa: ANN001
    # With nosniff, a text/plain script (the Windows registry default) is refused.
    response = client.get("/assets/app.js")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/javascript")


def test_unknown_api_paths_stay_json_errors(client) -> None:  # noqa: ANN001
    response = client.get("/api/v1/does-not-exist")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "http_error"


def test_files_outside_the_build_are_not_served(client) -> None:  # noqa: ANN001
    response = client.get("/..%2Fchroma")
    assert response.status_code == 200
    assert '<div id=root>' in response.text


def test_microphone_is_allowed_for_voice_input(client) -> None:  # noqa: ANN001
    response = client.get("/health")
    assert "microphone=(self)" in response.headers["permissions-policy"]
