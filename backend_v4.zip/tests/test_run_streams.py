"""The live run stream over WebSocket.

This endpoint had no automated coverage. That mattered when the `websockets`
library, which uvicorn uses to serve it, moved two major versions (14 to 16) as a
side effect of adding LangGraph.

What these tests hold is the endpoint's own behaviour: it authenticates before it
accepts, forwards events, and closes when the run reaches a terminal state. They run
in-process, so they do not exercise uvicorn or the `websockets` library itself; that
transport was verified against a running server.
"""

from __future__ import annotations

import uuid

import pytest
from starlette.websockets import WebSocketDisconnect

from app.core.events import event_bus, run_topic
from app.models.run import AgentRun


def _token(auth_headers: dict[str, str]) -> str:
    return auth_headers["Authorization"].split(" ", 1)[1]


@pytest.fixture
def run_id(db, project_id) -> str:  # noqa: ANN001
    """A real run to stream.

    The socket now checks that the run exists and belongs to a project the
    caller is a member of, so a made-up id is refused rather than streamed --
    which is the point of `test_a_socket_for_another_tenants_run_is_refused`.
    """
    run = AgentRun(
        project_id=project_id,
        title="Streamed run",
        correlation_id=str(uuid.uuid4()),
        status="running",
        run_number=9_001,
        trigger="manual",
        triggered_by="alex.morgan@example.com",
    )
    db.add(run)
    db.commit()
    return run.id


def test_a_socket_without_a_token_is_refused_before_it_is_accepted(client) -> None:  # noqa: ANN001
    with pytest.raises(WebSocketDisconnect) as refused:
        with client.websocket_connect(f"/api/v1/runs/{uuid.uuid4()}/ws"):
            pass

    assert refused.value.code == 4401


def test_a_socket_with_a_bad_token_is_refused(client) -> None:  # noqa: ANN001
    with pytest.raises(WebSocketDisconnect) as refused:
        with client.websocket_connect(f"/api/v1/runs/{uuid.uuid4()}/ws?token=not-a-real-token"):
            pass

    assert refused.value.code == 4401


def test_the_stream_forwards_events_and_ends_when_the_run_does(client, auth_headers, run_id) -> None:  # noqa: ANN001
    with client.websocket_connect(f"/api/v1/runs/{run_id}/ws?token={_token(auth_headers)}") as socket:
        event_bus.publish(run_topic(run_id), "step_started", {"run_id": run_id, "node_key": "a"})
        event_bus.publish(run_topic(run_id), "run_completed", {"run_id": run_id})

        first = socket.receive_json()
        last = socket.receive_json()

    assert first["type"] == "step_started" and first["payload"]["node_key"] == "a"
    assert last["type"] == "run_completed"


def test_a_paused_run_also_ends_the_stream(client, auth_headers, run_id) -> None:  # noqa: ANN001
    """Waiting for an approval is a stopping point for the stream, not an error."""
    with client.websocket_connect(f"/api/v1/runs/{run_id}/ws?token={_token(auth_headers)}") as socket:
        event_bus.publish(run_topic(run_id), "run_paused", {"run_id": run_id})
        assert socket.receive_json()["type"] == "run_paused"


def test_a_socket_for_a_run_that_does_not_exist_is_refused(client, auth_headers) -> None:  # noqa: ANN001
    """A valid token is not a licence to subscribe to an arbitrary topic."""
    with pytest.raises(WebSocketDisconnect) as refused:
        with client.websocket_connect(
            f"/api/v1/runs/{uuid.uuid4()}/ws?token={_token(auth_headers)}"
        ):
            pass

    assert refused.value.code == 4401


def test_a_socket_for_another_tenants_run_is_refused(client, db, run_id) -> None:  # noqa: ANN001
    """The stream carries a run's prompts and outputs as they happen.

    Subscribing needs membership of the run's project, not merely `run:read` --
    otherwise a run id, which appears in any shared link or log line, would be
    enough to watch another customer's run live.
    """
    from app.models.project import Project  # noqa: PLC0415

    outsider = client.post(
        "/api/v1/auth/login",
        json={"email": "tom.becker@example.com", "password": "Demo!2024"},
    )
    assert outsider.status_code == 200, outsider.text
    token = outsider.json()["access_token"]

    # Move the run into a project with no members at all.
    private = Project(key="PRIVATE1", name="Another customer", business_domain="Banking")
    db.add(private)
    db.flush()
    db.get(AgentRun, run_id).project_id = private.id
    db.commit()

    with pytest.raises(WebSocketDisconnect) as refused:
        with client.websocket_connect(f"/api/v1/runs/{run_id}/ws?token={token}"):
            pass

    assert refused.value.code == 4401
