"""Onboarding an API user, and the self-service view they get.

An API key is an identity on this platform held by someone with no account on
it. These cover the three things that makes necessary: issuing the key as a
named identity, letting the holder verify it without starting work, and showing
them their own provisioned capabilities and runs -- their own, and nobody
else's, which is the part worth testing hardest.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import select

from app.models.flow import AgentFlow
from app.models.governance import AuditLog
from app.services.integration_clients import issue_client

BASE = "/api/v1/integration"


@pytest.fixture
def published_flow(db, project_id: str) -> AgentFlow:
    row = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.is_deleted.is_(False),
            AgentFlow.status == "published",
        )
    ).scalars().first()
    assert row is not None
    return row


def _key(db, project_id: str, **kwargs):  # noqa: ANN001, ANN003, ANN202
    kwargs.setdefault("scopes", ["catalog:read", "flows:run", "agents:run", "runs:read"])
    record, token = issue_client(db, project_id=project_id, actor="alex.morgan@example.com", **kwargs)
    db.commit()
    return record, token


@pytest.fixture(autouse=True)
def _no_background_execution(monkeypatch):  # noqa: ANN001, ANN202
    """Create runs without executing them.

    These tests are about who owns a run and who may read it, not about what the
    run does. Letting each one dispatch a real worker thread makes them slow and
    flaky: the threads open their own sessions against the same SQLite file and
    collide with the test's own writes ("database is locked").
    """
    from app.services import run_service

    monkeypatch.setattr(run_service.job_queue, "submit", lambda name, *args, **kwargs: None)


def headers(token: str) -> dict[str, str]:
    return {"X-API-Key": token}


# ---------------------------------------------------------------------------
# Onboarding
# ---------------------------------------------------------------------------


def test_two_keys_sharing_a_name_still_cannot_see_each_others_runs(
    client, db, project_id: str, published_flow  # noqa: ANN001
) -> None:
    """Ownership is the key's id, not its name.

    A run used to record its caller only as `integration:{name}`, and that
    string decided who could read it back. Nothing stops an operator issuing two
    keys called "jenkins", and then each would have seen the other's work -- on
    the dashboard this feature adds, most visibly. Enforcing unique names was
    the cheaper fix and the wrong one: a label is not an identity.
    """
    _record, first = _key(db, project_id, name="jenkins", grants_all_flows=True)
    _record, second = _key(db, project_id, name="jenkins", grants_all_flows=True)

    started = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(first), json={"inputs": {}}
    ).json()

    listing = client.get(f"{BASE}/runs", headers=headers(second)).json()

    assert started["run_id"] not in {run["run_id"] for run in listing["items"]}
    assert client.get(f"{BASE}/runs/{started['run_id']}", headers=headers(second)).status_code == 404
    # ...and the key that did start it still sees it.
    assert client.get(f"{BASE}/runs/{started['run_id']}", headers=headers(first)).status_code == 200


def test_a_run_records_the_key_that_started_it(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    from app.models.run import AgentRun

    record, token = _key(db, project_id, name="claims-its-work", grants_all_flows=True)
    started = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}}
    ).json()

    db.expire_all()
    run = db.get(AgentRun, started["run_id"])
    assert run.integration_client_id == record.id
    # The readable label stays, for the audit trail and the run list in the UI.
    assert run.triggered_by == "integration:claims-its-work"


def test_a_run_from_before_the_id_existed_is_still_visible(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """The fallback. Runs started before runs recorded the key's id have NULL
    there, and must not vanish from their key's dashboard."""
    from app.models.run import AgentRun

    _record, token = _key(db, project_id, name="legacy-caller", grants_all_flows=True)
    started = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}}
    ).json()

    db.expire_all()
    db.get(AgentRun, started["run_id"]).integration_client_id = None  # as an old row would be
    db.commit()

    listing = client.get(f"{BASE}/runs", headers=headers(token)).json()
    assert started["run_id"] in {run["run_id"] for run in listing["items"]}


def test_onboarding_is_audited(client, db, project_id: str, auth_headers) -> None:  # noqa: ANN001
    """Issuing a credential to an outside system is what an audit trail is for."""
    response = client.post(
        "/api/v1/integration-clients",
        headers=auth_headers,
        json={
            "project_id": project_id,
            "name": "audited-partner",
            "scopes": ["catalog:read", "flows:run"],
            "grants_all_flows": True,
        },
    )
    assert response.status_code == 201

    entry = db.execute(
        select(AuditLog)
        .where(AuditLog.entity_id == response.json()["id"])
        .order_by(AuditLog.created_at.desc())
    ).scalars().first()
    assert entry is not None
    assert entry.actor == "alex.morgan@example.com"


def test_onboarding_needs_permission(client, db, project_id: str) -> None:  # noqa: ANN001
    """Keys are issued by an operator, never self-served."""
    assert client.post(
        "/api/v1/integration-clients", json={"project_id": project_id, "name": "self-served"}
    ).status_code in {401, 403}


# ---------------------------------------------------------------------------
# /me -- verifying a key without starting work
# ---------------------------------------------------------------------------


def test_me_authenticates_and_describes_the_key(client, db, project_id: str) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="introspect", grants_all_flows=True)

    body = client.get(f"{BASE}/me", headers=headers(token)).json()

    assert body["authenticated"] is True
    assert body["client"]["name"] == "introspect"
    assert body["validity"]["expired"] is False
    assert body["provisioned"]["all_flows_in_project"] is True
    assert body["provisioned"]["flows"] > 0


def test_me_explains_each_scope_it_granted(client, db, project_id: str) -> None:  # noqa: ANN001
    """So a caller can explain a 403 to itself without reading the docs."""
    _record, token = _key(db, project_id, name="explainer", scopes=["catalog:read", "flows:run"])

    scopes = client.get(f"{BASE}/me", headers=headers(token)).json()["scopes"]

    assert scopes["granted"] == ["catalog:read", "flows:run"]
    assert "flow" in scopes["meaning"]["flows:run"].lower()


def test_me_starts_no_work(client, db, project_id: str) -> None:  # noqa: ANN001
    """The reason the endpoint exists: checking a key must not have a side
    effect. Before it, the only way to prove a key was live was to invoke
    something real."""
    _record, token = _key(db, project_id, name="harmless", grants_all_flows=True)
    before = client.get(f"{BASE}/runs", headers=headers(token)).json()["total"]

    client.get(f"{BASE}/me", headers=headers(token))

    assert client.get(f"{BASE}/runs", headers=headers(token)).json()["total"] == before


def test_me_refuses_a_key_that_is_no_longer_usable(client, db, project_id: str) -> None:  # noqa: ANN001
    record, token = _key(db, project_id, name="lapsed-introspect")
    record.expires_at = datetime.now(UTC) - timedelta(days=1)
    db.commit()

    assert client.get(f"{BASE}/me", headers=headers(token)).status_code == 401


def test_me_needs_no_scope_beyond_being_a_key(client, db, project_id: str) -> None:  # noqa: ANN001
    """Any key must be able to ask what it is, whatever it was granted."""
    _record, token = _key(db, project_id, name="minimal", scopes=["catalog:read"])

    assert client.get(f"{BASE}/me", headers=headers(token)).status_code == 200


def test_me_never_returns_a_token(client, db, project_id: str) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="no-echo", grants_all_flows=True)

    body = client.get(f"{BASE}/me", headers=headers(token)).text

    assert token not in body
    assert "token_hash" not in body


# ---------------------------------------------------------------------------
# /runs -- the dashboard list, and its isolation
# ---------------------------------------------------------------------------


def test_a_key_sees_the_runs_it_started(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="runner", grants_all_flows=True)
    started = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}}
    )
    assert started.status_code == 202, started.text

    listing = client.get(f"{BASE}/runs", headers=headers(token)).json()

    assert listing["total"] >= 1
    assert started.json()["run_id"] in {run["run_id"] for run in listing["items"]}


def test_a_key_never_sees_another_keys_runs(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """The isolation the whole dashboard rests on."""
    _record, mine = _key(db, project_id, name="mine", grants_all_flows=True)
    _record, theirs = _key(db, project_id, name="theirs", grants_all_flows=True)

    started = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(mine), json={"inputs": {}}
    ).json()

    listing = client.get(f"{BASE}/runs", headers=headers(theirs)).json()

    assert started["run_id"] not in {run["run_id"] for run in listing["items"]}


def test_a_key_never_sees_a_run_a_person_started(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """A key's dashboard shows its own work, not the project's."""
    from app.services.run_service import RunService

    human = RunService(db).start_flow_run(
        flow_id=published_flow.id, project_id=project_id, triggered_by="priya.raman@example.com"
    )
    db.commit()
    _record, token = _key(db, project_id, name="not-a-person", grants_all_flows=True)

    listing = client.get(f"{BASE}/runs", headers=headers(token)).json()

    assert human.id not in {run["run_id"] for run in listing["items"]}


def test_the_run_list_needs_the_read_scope(client, db, project_id: str) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="no-read", scopes=["catalog:read", "flows:run"])

    assert client.get(f"{BASE}/runs", headers=headers(token)).status_code == 403


def test_the_run_list_omits_outputs(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """A page of twenty runs should not carry twenty result payloads."""
    _record, token = _key(db, project_id, name="lean-list", grants_all_flows=True)
    client.post(f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}})

    items = client.get(f"{BASE}/runs", headers=headers(token)).json()["items"]

    assert items and "outputs" not in items[0]
    assert "disposition" in items[0] and "is_terminal" in items[0]


def test_the_list_and_the_detail_agree_about_ownership(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """Everything the list shows must be readable, and nothing else must be."""
    _record, mine = _key(db, project_id, name="owner", grants_all_flows=True)
    _record, theirs = _key(db, project_id, name="stranger", grants_all_flows=True)
    started = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(mine), json={"inputs": {}}
    ).json()

    for run in client.get(f"{BASE}/runs", headers=headers(mine)).json()["items"]:
        assert client.get(f"{BASE}/runs/{run['run_id']}", headers=headers(mine)).status_code == 200

    assert client.get(f"{BASE}/runs/{started['run_id']}", headers=headers(theirs)).status_code == 404


def test_the_list_is_paginated(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="pager", grants_all_flows=True)
    for _ in range(3):
        client.post(f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}})

    page = client.get(f"{BASE}/runs", headers=headers(token), params={"limit": 2}).json()

    assert len(page["items"]) == 2
    assert page["total"] >= 3
    assert page["limit"] == 2


def test_activity_counts_what_this_key_has_started(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="counter", grants_all_flows=True)
    before = client.get(f"{BASE}/me", headers=headers(token)).json()["activity"]["runs_total"]

    client.post(f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}})
    after = client.get(f"{BASE}/me", headers=headers(token)).json()["activity"]

    assert after["runs_total"] == before + 1
    assert sum(after["runs_by_disposition"].values()) == after["runs_total"]


# ---------------------------------------------------------------------------
# The seeded API user
# ---------------------------------------------------------------------------


def test_the_demo_seeds_one_working_api_user(client) -> None:  # noqa: ANN001
    """Every other part of the demo is explorable the moment it is seeded. The
    integration surface was not: a key is shown once and only hashed, so a fresh
    install had nothing to sign into the portal with."""
    from app.seed.api_clients import DEMO_API_KEY

    body = client.get(f"{BASE}/me", headers=headers(DEMO_API_KEY)).json()

    assert body["client"]["name"] == "acme-partner-platform"
    assert body["provisioned"]["flows"] > 0
    assert body["provisioned"]["agents"] > 0


def test_seeding_the_demo_api_user_twice_is_harmless(db, project_id: str) -> None:  # noqa: ANN001
    """The seed runs again on every reset."""
    from app.models.project import Project
    from app.seed.api_clients import seed_demo_api_client

    project = db.get(Project, project_id)
    first = seed_demo_api_client(db, project)
    second = seed_demo_api_client(db, project)

    assert first.id == second.id
