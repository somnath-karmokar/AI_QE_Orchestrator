"""The migrations must build the same schema the models declare.

Demo and test databases are created with `create_all`, so a table missing from
the migrations stays invisible until someone deploys from migrations alone.
This test walks the migration chain on a throwaway database and compares.
"""

from __future__ import annotations

import os
import subprocess
import sys
import sqlite3
from pathlib import Path

import pytest

import app.models  # noqa: F401 - registers every model on the metadata
from app.models.base import Base

BACKEND = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def migrated_database(tmp_path_factory) -> Path:  # noqa: ANN001
    """Walk the whole migration chain once; both checks read the same database."""
    database = tmp_path_factory.mktemp("migrations") / "migrated.db"
    result = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=BACKEND,
        env={**os.environ, "DATABASE_URL": f"sqlite:///{database.as_posix()}", "LOG_LEVEL": "WARNING"},
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr[-2000:]
    return database


def test_migrations_build_every_table_the_models_declare(migrated_database: Path) -> None:
    with sqlite3.connect(migrated_database) as connection:
        migrated = {
            row[0] for row in connection.execute("select name from sqlite_master where type='table'")
        } - {"alembic_version", "sqlite_sequence"}

    missing = sorted(set(Base.metadata.tables) - migrated)
    assert not missing, f"tables declared by the models but never created by a migration: {missing}"


def test_migrated_columns_match_the_models(migrated_database: Path) -> None:
    """Every table, column by column."""
    missing: dict[str, list[str]] = {}
    with sqlite3.connect(migrated_database) as connection:
        for table, declared_table in Base.metadata.tables.items():
            columns = {row[1] for row in connection.execute(f"pragma table_info({table})")}
            absent = sorted(set(declared_table.columns.keys()) - columns)
            if absent:
                missing[table] = absent
    assert not missing, f"columns declared by the models but never migrated: {missing}"


def test_migrated_columns_match_model_nullability(migrated_database: Path) -> None:
    """A column the models say is NOT NULL must be NOT NULL after a migration too.

    Without this, a migrated database can hold NULLs the ORM believes impossible,
    and the first read of an older row fails in production rather than in a test.
    """
    divergent: list[str] = []
    with sqlite3.connect(migrated_database) as connection:
        for table, declared_table in Base.metadata.tables.items():
            actual = {
                row[1]: bool(row[3])  # row[3] = "notnull"
                for row in connection.execute(f"pragma table_info({table})")
            }
            for name, column in declared_table.columns.items():
                if name not in actual or column.primary_key:
                    continue
                if column.nullable == actual[name]:
                    divergent.append(
                        f"{table}.{name}: model nullable={column.nullable}, "
                        f"migration notnull={actual[name]}"
                    )
    assert not divergent, "migration and model disagree on nullability:\n" + "\n".join(divergent)
