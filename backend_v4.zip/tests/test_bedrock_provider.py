"""AWS Bedrock as a configurable provider.

No agent imports a vendor SDK, so adding a provider must be configuration
rather than code. These tests hold that line, and pin the three translations
Bedrock actually needs: the system prompt goes out of band, turns must
alternate, and there is no universal JSON mode to rely on.
"""

from __future__ import annotations

import json

import pytest

from app.ai.providers.base import ChatMessage, ModelSelection
from app.ai.providers.bedrock_provider import BedrockProvider, _parse_json, _text_of
from app.ai.providers.registry import _PROVIDER_CLASSES, bedrock_catalog, get_provider

FENCED = "```json\n{\"verdict\": \"ok\", \"score\": 3}\n```"
PLAIN = "{\"verdict\": \"ok\"}"


@pytest.fixture
def bedrock(monkeypatch):
    """A provider wired to a stub, so the real code path runs without AWS."""
    from app.core.config import settings

    monkeypatch.setattr(settings, "bedrock_region", "eu-west-2")
    monkeypatch.setattr(settings, "bedrock_chat_model", "anthropic.claude-sonnet-4-5-v1:0")
    monkeypatch.setattr(settings, "bedrock_reasoning_model", None)
    monkeypatch.setattr(settings, "bedrock_embedding_model", "amazon.titan-embed-text-v2:0")

    captured: dict = {}

    class Stub:
        reply = PLAIN
        usage = {"inputTokens": 120, "outputTokens": 30}

        def converse(self, **kwargs):  # noqa: ANN003, ANN201
            captured.update(kwargs)
            return {
                "output": {"message": {"content": [{"text": self.reply}]}},
                "usage": self.usage,
                "stopReason": "end_turn",
            }

        def invoke_model(self, modelId, body):  # noqa: ANN001, ANN201, N803
            captured["embed_model"] = modelId
            captured.setdefault("embed_bodies", []).append(json.loads(body))

            class Body:
                @staticmethod
                def read():
                    return json.dumps({"embedding": [0.1, 0.2, 0.3]})

            return {"body": Body()}

    stub = Stub()
    provider = BedrockProvider()
    BedrockProvider._client_cache = stub  # noqa: SLF001 - deliberate test seam
    yield provider, stub, captured
    BedrockProvider._client_cache = None


def selection(**overrides) -> ModelSelection:  # noqa: ANN003
    base = {
        "provider": "bedrock",
        "model": "anthropic.claude-sonnet-4-5-v1:0",
        "deployment": None,
        "capability": "generation",
        "temperature": 0.1,
        "max_tokens": 1000,
    }
    return ModelSelection(**{**base, **overrides})


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def test_bedrock_is_a_selectable_provider() -> None:
    assert "bedrock" in _PROVIDER_CLASSES


def test_an_unconfigured_bedrock_falls_back_to_mock(monkeypatch) -> None:
    """The platform must boot without AWS rather than fail at import."""
    from app.core.config import settings

    monkeypatch.setattr(settings, "bedrock_region", None)
    assert get_provider("bedrock").key == "mock"


def test_health_reports_configuration_without_secrets(monkeypatch) -> None:
    from app.core.config import settings

    monkeypatch.setattr(settings, "bedrock_region", "eu-west-2")
    report = BedrockProvider().health_check()

    assert report["region"] == "eu-west-2"
    # Credentials come from the AWS chain, so there is nothing here to leak.
    serialised = json.dumps(report).lower()
    for forbidden in ("secret", "aws_access_key", "session_token", "password"):
        assert forbidden not in serialised


# ---------------------------------------------------------------------------
# Request translation
# ---------------------------------------------------------------------------


def test_the_system_prompt_is_sent_out_of_band(bedrock) -> None:
    """Bedrock takes the system prompt separately, not as a message."""
    provider, _stub, captured = bedrock
    provider.chat(
        [
            ChatMessage(role="system", content="You are precise."),
            ChatMessage(role="user", content="Hello."),
        ],
        selection(),
    )
    assert captured["system"] == [{"text": "You are precise."}]
    assert all(turn["role"] != "system" for turn in captured["messages"])


def test_consecutive_same_role_messages_are_merged(bedrock) -> None:
    """Bedrock rejects a conversation that does not alternate. The caller should
    not have to know that."""
    provider, _stub, captured = bedrock
    provider.chat(
        [
            ChatMessage(role="user", content="First."),
            ChatMessage(role="user", content="Second."),
            ChatMessage(role="assistant", content="Reply."),
            ChatMessage(role="user", content="Third."),
        ],
        selection(),
    )
    assert [turn["role"] for turn in captured["messages"]] == ["user", "assistant", "user"]
    assert len(captured["messages"][0]["content"]) == 2


def test_an_empty_conversation_still_produces_a_valid_request(bedrock) -> None:
    provider, _stub, captured = bedrock
    provider.chat([ChatMessage(role="system", content="Only a system prompt.")], selection())
    assert captured["messages"] == [{"role": "user", "content": [{"text": ""}]}]


def test_inference_settings_are_passed_through(bedrock) -> None:
    provider, _stub, captured = bedrock
    provider.chat(
        [ChatMessage(role="user", content="Hi.")], selection(temperature=0.7, max_tokens=4096)
    )
    assert captured["inferenceConfig"] == {"temperature": 0.7, "maxTokens": 4096}


def test_a_pinned_inference_profile_wins_over_the_model_key(bedrock) -> None:
    """`deployment` carries a Bedrock id or inference-profile ARN, exactly as it
    carries a deployment name for Azure."""
    provider, _stub, captured = bedrock
    provider.chat(
        [ChatMessage(role="user", content="Hi.")],
        selection(deployment="arn:aws:bedrock:eu-west-2:123:inference-profile/eu-claude"),
    )
    assert captured["modelId"].startswith("arn:aws:bedrock:")


def test_json_is_requested_in_the_system_prompt(bedrock) -> None:
    """There is no universal JSON mode across Bedrock families, so the portable
    instruction is the prompt -- and the agent's parser still validates it."""
    provider, _stub, captured = bedrock
    provider.chat(
        [ChatMessage(role="user", content="Hi.")], selection(), response_schema={"type": "object"}
    )
    assert any("valid JSON object" in item["text"] for item in captured["system"])


# ---------------------------------------------------------------------------
# Response translation
# ---------------------------------------------------------------------------


def test_the_uniform_response_shape_is_produced(bedrock) -> None:
    provider, _stub, _captured = bedrock
    response = provider.chat([ChatMessage(role="user", content="Hi.")], selection())

    assert response.content == PLAIN
    assert response.usage.prompt_tokens == 120
    assert response.usage.completion_tokens == 30
    assert response.finish_reason == "end_turn"
    assert response.selection.provider == "bedrock"


def test_a_fenced_json_reply_is_recovered(bedrock) -> None:
    """Models without a JSON mode often wrap the object in markdown."""
    provider, stub, _captured = bedrock
    stub.reply = FENCED
    response = provider.chat(
        [ChatMessage(role="user", content="Hi.")], selection(), response_schema={"type": "object"}
    )
    assert response.structured == {"verdict": "ok", "score": 3}


def test_a_reply_that_is_not_json_is_reported_not_invented(bedrock) -> None:
    """Returning None lets the agent's own validation report it, the same way
    every other provider fails."""
    provider, stub, _captured = bedrock
    stub.reply = "I am afraid I cannot do that."
    response = provider.chat(
        [ChatMessage(role="user", content="Hi.")], selection(), response_schema={"type": "object"}
    )
    assert response.structured is None
    assert response.content == "I am afraid I cannot do that."


def test_multiple_text_blocks_are_joined() -> None:
    joined = _text_of({"output": {"message": {"content": [{"text": "one "}, {"text": "two"}]}}})
    assert joined == "one two"


def test_a_non_object_json_reply_is_wrapped() -> None:
    assert _parse_json("[1, 2]", provider="bedrock", model="m") == {"result": [1, 2]}


# ---------------------------------------------------------------------------
# Embeddings
# ---------------------------------------------------------------------------


def test_titan_embeds_one_text_per_call(bedrock) -> None:
    provider, _stub, captured = bedrock
    result = provider.embed(["alpha", "beta"], selection(capability="embedding"))

    assert len(result.vectors) == 2
    assert captured["embed_model"] == "amazon.titan-embed-text-v2:0"
    assert [body["inputText"] for body in captured["embed_bodies"]] == ["alpha", "beta"]


def test_cohere_embeds_the_batch_in_one_call(bedrock, monkeypatch) -> None:
    """Titan and Cohere differ in request shape, so both are handled explicitly
    rather than guessed at."""
    from app.core.config import settings

    monkeypatch.setattr(settings, "bedrock_embedding_model", "cohere.embed-english-v3")
    provider, _stub, captured = bedrock

    class CohereStub:
        @staticmethod
        def invoke_model(modelId, body):  # noqa: ANN001, ANN205, N803
            captured["embed_model"] = modelId
            captured["cohere_body"] = json.loads(body)

            class Body:
                @staticmethod
                def read():
                    return json.dumps({"embeddings": [[0.1], [0.2]]})

            return {"body": Body()}

    BedrockProvider._client_cache = CohereStub()  # noqa: SLF001
    result = provider.embed(["alpha", "beta"], selection(capability="embedding"))

    assert len(result.vectors) == 2
    assert captured["cohere_body"]["texts"] == ["alpha", "beta"]


# ---------------------------------------------------------------------------
# Catalogue
# ---------------------------------------------------------------------------


def test_only_configured_bedrock_models_are_advertised(bedrock) -> None:
    """An unconfigured slot must not advertise a model the platform cannot call."""
    keys = {entry["model_key"] for entry in bedrock_catalog()}
    assert "anthropic.claude-sonnet-4-5-v1:0" in keys
    assert "amazon.titan-embed-text-v2:0" in keys
    # The reasoning slot was left unset in the fixture.
    assert len(keys) == 2


def test_bedrock_pricing_is_left_to_the_deployment(bedrock) -> None:
    """Rates vary by model, region and commitment. A wrong number in a cost
    report is worse than an absent one."""
    for entry in bedrock_catalog():
        assert entry["input_cost_per_1k"] == 0.0
        assert "not shipped as a guess" in entry["pricing_note"]


def test_an_unconfigured_deployment_advertises_no_bedrock_models(monkeypatch) -> None:
    from app.core.config import settings

    for slot in ("bedrock_chat_model", "bedrock_reasoning_model", "bedrock_embedding_model"):
        monkeypatch.setattr(settings, slot, None)
    assert bedrock_catalog() == []
