"""An agent cannot be pointed at another tenant's data by an identifier.

Agents take identifiers as inputs -- a defect, an execution, a failing test, a
data set -- and since the integration API those inputs come from other
platforms. They were loaded with `session.get(Model, id)`, which ignores the
project, so an agent running in one project would analyse, and in two places
write to, another project's rows for anyone holding a UUID.

Every test here builds a second tenant whose rows carry a marker string, runs an
agent in the demo project with that tenant's identifiers, and asserts the marker
never comes back and nothing of theirs changed.
"""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import select

from app.agents.base import AgentContext
from app.agents.registry import AGENT_CLASS_BY_KEY
from app.models.defect import Defect
from app.models.project import Project
from app.models.testing import Execution, Requirement
from app.models.testing import ExecutionTest as ExecutionTestRow
from app.models.testing import TestCase as CaseRow
from app.models.testing import TestDataSet as DataSetRow

MARKER = "THEIR-PRIVATE-MARKER"


@pytest.fixture
def ours(db) -> AgentContext:  # noqa: ANN001
    project = db.execute(select(Project).where(Project.key == "ABCR")).scalar_one()
    return AgentContext(session=db, project=project, actor="test", approval_granted=True)


@pytest.fixture
def theirs(db) -> dict:  # noqa: ANN001
    """Another tenant, with one of everything an agent can be pointed at."""
    tag = uuid.uuid4().hex[:6].upper()
    project = Project(key=f"THR{tag}", name=f"Another customer {tag}")
    db.add(project)
    db.flush()

    execution = Execution(project_id=project.id, name=f"{MARKER} run", status="completed", failed=1)
    db.add(execution)
    db.flush()
    failed = ExecutionTestRow(
        execution_id=execution.id,
        name=f"{MARKER} test",
        result="failed",
        failure_message=f"TimeoutError: locator '#{MARKER}' not found",
    )
    db.add(failed)
    defect = Defect(project_id=project.id, external_key=f"THR-{tag}", title=f"{MARKER} defect", module="Payments")
    data_set = DataSetRow(project_id=project.id, name=f"{MARKER} data", module="Payments", sql_scripts=[])
    requirement = Requirement(project_id=project.id, external_key=f"THRQ-{tag}", title=f"{MARKER} story", module="Payments")
    case = CaseRow(project_id=project.id, key=f"THRC-{tag}", title=f"{MARKER} case", module="Payments", is_automated=False)
    db.add_all([defect, data_set, requirement, case])
    db.commit()
    return {
        "project": project,
        "execution": execution,
        "failed_test": failed,
        "defect": defect,
        "data_set": data_set,
        "requirement": requirement,
        "case": case,
    }


def _run(ctx: AgentContext, key: str, inputs: dict):  # noqa: ANN202
    return AGENT_CLASS_BY_KEY[key]().execute(ctx, inputs)


def _leaked(result) -> bool:  # noqa: ANN001
    return MARKER in str(result.to_dict())


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------


def test_defect_rca_cannot_analyse_another_tenants_defect(ours, theirs) -> None:  # noqa: ANN001
    result = _run(ours, "automated-defect-rca", {"defect_id": theirs["defect"].id})
    assert not _leaked(result)
    assert result.status in ("failed", "partial")


def test_defect_rca_accepts_a_defect_key_from_its_own_project(ours, db) -> None:  # noqa: ANN001
    """What a calling platform knows is DEF-0003, not our primary key."""
    defect = db.execute(
        select(Defect).where(Defect.project_id == ours.project_id, Defect.external_key.is_not(None))
    ).scalars().first()
    result = _run(ours, "automated-defect-rca", {"defect_id": defect.external_key})
    assert result.status != "failed", result.summary


def test_failure_analysis_cannot_read_another_tenants_failure(ours, theirs) -> None:  # noqa: ANN001
    by_test = _run(ours, "automation-failure-analysis", {"execution_test_id": theirs["failed_test"].id})
    by_execution = _run(ours, "automation-failure-analysis", {"execution_id": theirs["execution"].id})
    assert not _leaked(by_test)
    assert not _leaked(by_execution)


def test_rca_cannot_read_another_tenants_failure(ours, theirs) -> None:  # noqa: ANN001
    result = _run(ours, "automated-rca", {"execution_test_id": theirs["failed_test"].id})
    assert not _leaked(result)


def test_self_healing_with_no_inputs_stays_in_its_own_project(db, theirs) -> None:  # noqa: ANN001
    """With nothing named, it used to pick failed tests from every project.

    Run from a project with no failures of its own, so the only failures it
    could possibly find belong to someone else -- which is what made the old
    query's leak visible at all: in a project with its own failures, those came
    first and hid it.
    """
    empty = Project(key=f"EMP{uuid.uuid4().hex[:5].upper()}", name="A project with no failures")
    db.add(empty)
    db.commit()
    ctx = AgentContext(session=db, project=empty, actor="test", approval_granted=True)

    agent = AGENT_CLASS_BY_KEY["self-healing-automation"]()
    context = agent.gather_context(ctx, {})

    assert context["candidates"] == [], "it found failures in a project that has none"


def test_script_generation_cannot_be_pointed_at_another_tenants_cases(ours, theirs, db) -> None:  # noqa: ANN001
    result = _run(ours, "auto-script-generator", {"test_case_ids": [theirs["case"].id]})
    assert not _leaked(result)
    db.refresh(theirs["case"])
    assert theirs["case"].is_automated is False


def test_execution_triage_cannot_be_pointed_at_another_tenants_execution(ours, theirs) -> None:  # noqa: ANN001
    result = _run(ours, "automated-test-execution", {"execution_id": theirs["execution"].id})
    assert not _leaked(result)


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------


def test_db_script_generation_cannot_write_into_another_tenants_data_set(ours, theirs, db) -> None:  # noqa: ANN001
    """The one path that wrote: persist stored scripts on whatever data set it was given."""
    result = _run(ours, "db-script-generator", {"table": "payments", "data_set_id": theirs["data_set"].id})
    db.refresh(theirs["data_set"])
    assert theirs["data_set"].sql_scripts == []
    assert not _leaked(result)


def test_a_model_naming_another_tenants_row_cannot_make_an_agent_write_to_it(ours, theirs, db, monkeypatch) -> None:  # noqa: ANN001
    """Under a real provider the payload is the model's answer, and a model can
    be talked into naming any id. Identity in a payload is a claim, honoured
    only inside the run's own project."""
    from app.ai.providers.mock import MockLLMProvider  # noqa: PLC0415

    original = MockLLMProvider.chat
    target = theirs["requirement"]
    before = (target.completeness_score, target.status)

    def injected(self, messages, selection, **kwargs):  # noqa: ANN001, ANN202
        kwargs["deterministic_draft"] = {
            "status": "success",
            "confidence": 0.9,
            "summary": "done",
            "outputs": {
                "requirement_id": target.id,
                "completeness_score": 1,
                "passed": False,
                "gap_count": 9,
            },
        }
        return original(self, messages, selection, **kwargs)

    monkeypatch.setattr(MockLLMProvider, "chat", injected)
    _run(ours, "user-story-completeness", {"requirement_key": "PAY-201"})

    db.refresh(target)
    assert (target.completeness_score, target.status) == before
