"""A write is committed before the client is told it succeeded.

FastAPI runs a yield-dependency's teardown *after* the response has been sent,
unless the dependency asks for `scope="function"`. `get_db` commits in that
teardown, so with the default a client was told "201 Created" before the row
existed. Two consequences, both observed on a live server after a framework
upgrade:

* a key issued in one request was refused by the very next one -- 20 of 20
  freshly issued keys, valid 34-158 ms later;
* a commit that *failed* failed after the client had already been sent a
  success, so the write was lost and nobody was told.

The suite could not see it. `TestClient` waits for the whole request, teardown
included, before handing back the response, so every sequential test observed
a committed write. These tests drive the app at the ASGI level instead and
record the order things actually happen in.

(No `from __future__ import annotations` here on purpose: FastAPI resolves a
string annotation against module globals, and these routes are built inside
functions from a dependency passed in.)
"""

import asyncio
from typing import Annotated

import pytest
from fastapi import Depends, FastAPI
from sqlalchemy.orm import Session

from app.api.deps import DbSession
from app.core.database import get_db


def _app(session_dependency) -> FastAPI:  # noqa: ANN001
    app = FastAPI()

    @app.post("/write")
    def write(session: Annotated[Session, session_dependency]) -> dict:  # noqa: ARG001
        return {"ok": True}

    return app


def _timeline(
    app: FastAPI,
    monkeypatch: pytest.MonkeyPatch,
    *,
    commit_fails: bool = False,
) -> list[str]:
    """Call `POST /write` and return what happened, in the order it happened.

    One list is appended to by both sides -- the commit and the moment the
    response starts -- so their relative order is what is asserted, not their
    timing.
    """
    timeline: list[str] = []
    real_commit = Session.commit

    def commit_spy(self: Session) -> None:
        timeline.append("commit")
        if commit_fails:
            raise RuntimeError("database is locked")
        real_commit(self)

    monkeypatch.setattr(Session, "commit", commit_spy)

    scope = {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": "1.1",
        "method": "POST",
        "scheme": "http",
        "path": "/write",
        "raw_path": b"/write",
        "root_path": "",
        "query_string": b"",
        "headers": [],
        "server": ("testserver", 80),
        "client": ("testclient", 5000),
    }

    async def receive() -> dict:
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(message: dict) -> None:
        if message["type"] == "http.response.start":
            timeline.append(f"response_started:{message['status']}")

    async def run() -> None:
        try:
            await app(scope, receive, send)
        except Exception:  # noqa: BLE001 - a server error is re-raised after its 500 is sent
            pass

    asyncio.run(run())
    return timeline


# ---------------------------------------------------------------------------
# The guarantee
# ---------------------------------------------------------------------------


def test_the_write_is_committed_before_the_response_starts(monkeypatch: pytest.MonkeyPatch) -> None:
    """The guarantee, against the real `DbSession` alias every route imports."""
    app = FastAPI()

    @app.post("/write")
    def write(session: DbSession) -> dict:  # noqa: ARG001
        return {"ok": True}

    assert _timeline(app, monkeypatch) == ["commit", "response_started:200"]


def test_a_commit_that_fails_is_reported_to_the_caller(monkeypatch: pytest.MonkeyPatch) -> None:
    """The quieter half. With the default, a failed commit happened after the
    client had already been sent a success, so the write was lost and the
    caller was told it had worked."""
    app = FastAPI()

    @app.post("/write")
    def write(session: DbSession) -> dict:  # noqa: ARG001
        return {"ok": True}

    assert _timeline(app, monkeypatch, commit_fails=True) == ["commit", "response_started:500"]


# ---------------------------------------------------------------------------
# The canary
# ---------------------------------------------------------------------------


def test_the_harness_can_tell_the_two_behaviours_apart(monkeypatch: pytest.MonkeyPatch) -> None:
    """Without this, the tests above could pass because the harness sees
    nothing. With FastAPI's default scope the order is the reverse: the client
    is answered first and the commit lands afterwards.

    If this fails after a FastAPI upgrade, the framework's default changed
    again. Re-read `DbSession` in app/api/deps.py before deleting the test."""
    timeline = _timeline(_app(Depends(get_db)), monkeypatch)

    assert timeline == ["response_started:200", "commit"], (
        "the default scope no longer commits after the response; the premise of "
        "the function-scope override has changed"
    )


def test_the_default_would_report_success_for_a_commit_that_failed(monkeypatch: pytest.MonkeyPatch) -> None:
    """The failure the override prevents, shown rather than described: under the
    default the caller is sent a 200 and the failed commit happens afterwards."""
    timeline = _timeline(_app(Depends(get_db)), monkeypatch, commit_fails=True)

    assert timeline == ["response_started:200", "commit"]
