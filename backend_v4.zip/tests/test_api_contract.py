"""Details of the API's output that the web app depends on."""

from __future__ import annotations

from datetime import datetime

from app.execution.codegen import generate_playwright_script


def test_timestamps_carry_a_utc_offset(client, auth_headers, project_id) -> None:  # noqa: ANN001
    # Without an offset the browser reads a UTC time as local time, skewing every "x ago".
    response = client.get("/api/v1/defects", params={"project_id": project_id, "limit": 5}, headers=auth_headers)
    assert response.status_code == 200, response.text
    created = response.json()["items"][0]["created_at"]
    assert datetime.fromisoformat(created.replace("Z", "+00:00")).utcoffset() is not None, created


def test_generated_test_names_do_not_repeat_the_test_prefix() -> None:
    script = generate_playwright_script(
        test_case_key="TC-1",
        title="Test a payment above 1,000, the customer confirms",
        module="Payments",
        steps=[{"action": "Submit the payment", "expected": "Confirmation is shown"}],
    )
    assert "def test_payment_above_1_000_the_customer_confirms(" in script.code
    assert "test_test_" not in script.code
