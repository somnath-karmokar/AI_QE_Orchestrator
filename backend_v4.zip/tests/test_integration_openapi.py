"""The OpenAPI document an integrator actually generates a client from.

Two things are being held here. The document must describe the **contract** and
not the platform's 118 internal routes, because a client generated from the full
spec would carry a hundred methods nobody may call. And it must stay in step
with the routes that really exist — a spec that drifts is worse than none, since
it is trusted by a code generator rather than read by a person.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import select

from app.models.flow import AgentFlow
from app.services.integration_clients import issue_client
from app.services.integration_openapi import build_integration_openapi

SPEC = "/api/v1/integration/openapi.json"


@pytest.fixture
def granted(db, project_id: str):
    """A key granted a published flow, so the personalised document has content."""
    flow = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.is_deleted.is_(False),
            AgentFlow.status == "published",
        )
    ).scalars().first()
    assert flow is not None

    record, token = issue_client(
        db,
        project_id=project_id,
        name="sdk-generator",
        actor="alex.morgan@example.com",
        allowed_flow_ids=[flow.id],
    )
    db.commit()
    return flow, record, token


# ---------------------------------------------------------------------------
# The document itself
# ---------------------------------------------------------------------------


def test_it_is_a_valid_openapi_document() -> None:
    spec = build_integration_openapi()
    assert spec["openapi"].startswith("3.1")
    assert spec["info"]["title"]
    assert spec["paths"]
    assert spec["components"]["schemas"]


def test_it_describes_the_contract_not_the_whole_platform(client) -> None:
    """The platform has well over a hundred routes; this must not."""
    full = client.get("/api/openapi.json").json()
    scoped = client.get(SPEC).json()

    assert len(full["paths"]) > 100
    # A fraction of the platform, stated as a fraction: the contract grew when
    # run logs, the audit feed and model cards joined it, and a fixed count
    # would only have been bumped rather than re-asked each time.
    assert len(scoped["paths"]) < len(full["paths"]) // 4
    # And nothing internal leaked in.
    for path in scoped["paths"]:
        assert "/integration" in path or path.endswith("/mcp")


def test_authentication_is_declared_so_generated_clients_send_the_key(client) -> None:
    spec = client.get(SPEC).json()
    scheme = spec["components"]["securitySchemes"]["ApiKeyAuth"]

    assert scheme["type"] == "apiKey"
    assert scheme["in"] == "header"
    assert scheme["name"] == "X-API-Key"
    assert spec["security"] == [{"ApiKeyAuth": []}]


def test_responses_are_typed_rather_than_bare_dictionaries(client) -> None:
    """The routes return plain dicts, so FastAPI infers nothing. Without these
    written out, a generated client would be untyped and useless."""
    spec = client.get(SPEC).json()
    start = spec["paths"]["/api/v1/integration/flows/{flow_id}/runs"]["post"]
    schema = start["responses"]["202"]["content"]["application/json"]["schema"]

    assert schema["$ref"].endswith("/Run")
    run = spec["components"]["schemas"]["Run"]
    assert "disposition" in run["properties"]
    assert "is_terminal" in run["properties"]


def test_the_disposition_enum_is_the_real_one(client) -> None:
    """A generated client switches on this, so it must match what the platform
    actually returns."""
    from app.services.integration import DISPOSITIONS

    spec = client.get(SPEC).json()
    declared = set(spec["components"]["schemas"]["Run"]["properties"]["disposition"]["enum"])
    assert declared == set(DISPOSITIONS.values())


def test_the_document_warns_about_the_thing_integrators_get_wrong(client) -> None:
    spec = client.get(SPEC).json()
    description = spec["info"]["description"]

    assert "waiting_for_approval" in description
    assert "not a failure" in description
    # And that inputs are rejected rather than ignored.
    assert "rejected rather than" in description


def test_validation_failures_are_documented_with_their_shape(client) -> None:
    """422 is the response an integrator will hit first and most often."""
    spec = client.get(SPEC).json()
    invalid = spec["components"]["schemas"]["InvalidInputs"]

    assert "did_you_mean" in invalid["properties"]["invalid_inputs"]["items"]["properties"]
    assert "accepts" in invalid["properties"]


# ---------------------------------------------------------------------------
# Staying in step with the real routes
# ---------------------------------------------------------------------------


def _served_paths(client) -> set[str]:  # noqa: ANN001
    """Every path the server actually serves.

    Read from the server's own OpenAPI document rather than by walking
    `app.routes`. FastAPI stopped flattening `include_router` into that list --
    an included router is now one wrapper object holding an unprefixed router,
    so the flat read returned eleven paths instead of a hundred and twenty-two.
    The guards below would then have passed by seeing nothing. The generated
    document carries the prefixes already applied, and does not change shape
    between versions.
    """
    return set(client.get("/api/openapi.json").json()["paths"])


def test_every_documented_path_exists_on_the_server(client) -> None:
    """A hand-written spec earns its accuracy only if drift is caught."""
    real = _served_paths(client)
    assert len(real) > 100, "too few routes found for this to be checking anything"

    documented = set(client.get(SPEC).json()["paths"])
    missing = documented - real
    assert not missing, f"documented but not routed: {sorted(missing)}"


def test_every_contractual_route_is_documented(client) -> None:
    """The other direction: a contractual route nobody documented is invisible
    to an integrator."""
    routed = {
        path for path in _served_paths(client) if path.startswith("/api/v1/integration/")
    }
    # Discovery of the document itself is not part of the contract it describes.
    routed.discard("/api/v1/integration/openapi.json")

    documented = set(client.get(SPEC).json()["paths"])
    assert not routed - documented, f"routed but undocumented: {sorted(routed - documented)}"


# ---------------------------------------------------------------------------
# Personalisation
# ---------------------------------------------------------------------------


def test_without_a_key_it_says_nothing_about_any_project(client, granted) -> None:
    flow, _record, _token = granted
    body = client.get(SPEC).text

    assert flow.name not in body
    assert flow.id not in body
    assert "Your flows" not in body


def test_with_a_key_each_granted_flow_becomes_its_own_operation(client, granted) -> None:
    """The version worth generating a client from: a typed call per flow rather
    than one generic call taking an untyped dictionary."""
    flow, _record, token = granted
    spec = client.get(SPEC, headers={"X-API-Key": token}).json()

    path = f"/api/v1/integration/flows/{flow.id}/runs"
    assert path in spec["paths"]

    operation = spec["paths"][path]["post"]
    assert operation["tags"] == ["Your flows"]
    assert operation["summary"] == flow.name
    # Its real variables, typed, not `additionalProperties: true`.
    schema = operation["requestBody"]["content"]["application/json"]["schema"]
    properties = schema["properties"]["inputs"]["properties"]
    assert set(properties) == set(flow.variables)
    assert schema["properties"]["inputs"]["additionalProperties"] is False


def test_an_ungranted_flow_never_appears(client, db, project_id: str, granted) -> None:
    flow, _record, token = granted
    other = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.id != flow.id,
            AgentFlow.is_deleted.is_(False),
        )
    ).scalars().first()
    assert other is not None

    body = client.get(SPEC, headers={"X-API-Key": token}).text
    assert other.id not in body


def test_a_bad_key_falls_back_to_the_public_contract(client) -> None:
    """This document reveals nothing worth protecting, so a wrong key gets the
    contract rather than a 401 that an SDK generator cannot interpret."""
    response = client.get(SPEC, headers={"X-API-Key": "qei_not-a-real-key"})
    assert response.status_code == 200
    assert "Your flows" not in response.text


def test_only_tags_with_operations_are_declared(client, granted) -> None:
    """An empty tag group in Swagger UI reads as a key that is not working."""
    _flow, _record, token = granted

    public = {tag["name"] for tag in client.get(SPEC).json()["tags"]}
    assert "Your flows" not in public

    personal = {tag["name"] for tag in client.get(SPEC, headers={"X-API-Key": token}).json()["tags"]}
    assert "Your flows" in personal


# ---------------------------------------------------------------------------
# The browsable page
# ---------------------------------------------------------------------------


def test_the_swagger_page_is_served(client) -> None:
    response = client.get("/api/integration-docs")
    assert response.status_code == 200
    assert "swagger" in response.text.lower()
    assert SPEC in response.text


def test_the_swagger_page_tells_a_reader_to_authorise(client) -> None:
    """Otherwise they see the public contract and wonder where their flows are."""
    body = client.get("/api/integration-docs").text
    assert "Authorize" in body
    assert "X-API-Key" in body


# ---------------------------------------------------------------------------
# A key that may no longer be used
# ---------------------------------------------------------------------------


def test_an_expired_key_falls_back_to_the_public_contract(client, db, granted) -> None:  # noqa: ANN001
    """The bug this closes: expiry was enforced on every endpoint that runs
    something, and not here. An expired key kept a window onto the project's
    flows, their ids and their input schemas -- most of what expiry is for."""
    flow, record, token = granted
    record.expires_at = datetime.now(UTC) - timedelta(days=30)
    db.commit()

    # Refused where it runs anything...
    assert client.post(
        f"/api/v1/integration/flows/{flow.id}/runs",
        headers={"X-API-Key": token},
        json={"inputs": {}},
    ).status_code == 401

    # ...and tells it nothing here either.
    body = client.get(SPEC, headers={"X-API-Key": token}).text
    assert flow.name not in body
    assert flow.id not in body
    assert "Your flows" not in body


def test_a_revoked_key_falls_back_to_the_public_contract(client, db, granted) -> None:  # noqa: ANN001
    flow, record, token = granted
    record.is_active = False
    db.commit()

    body = client.get(SPEC, headers={"X-API-Key": token}).text
    assert flow.id not in body


@pytest.mark.parametrize(
    ("label", "disable"),
    [
        ("revoked", lambda record: setattr(record, "is_active", False)),
        ("deleted", lambda record: setattr(record, "is_deleted", True)),
        (
            "expired",
            lambda record: setattr(
                record, "expires_at", datetime.now(UTC) - timedelta(days=1)
            ),
        ),
    ],
)
def test_both_paths_decide_validity_the_same_way(client, db, granted, label: str, disable) -> None:  # noqa: ANN001
    """The structural half. The two paths drifted because each had its own copy
    of the rule; they share one now (`IntegrationClient.is_usable`), and this
    fails if they fork again.

    Asserted by behaviour rather than by reading the source, so moving the rule
    -- as it has already moved once -- does not break the test that guards it.
    Each of the three ways a key stops being usable must close both doors.
    """
    _flow, record, token = granted
    assert "Your flows" in client.get(SPEC, headers={"X-API-Key": token}).text
    assert client.get("/api/v1/integration/manifest", headers={"X-API-Key": token}).status_code == 200

    disable(record)
    db.commit()

    # The authenticating path refuses outright...
    assert client.get(
        "/api/v1/integration/manifest", headers={"X-API-Key": token}
    ).status_code == 401, label
    # ...and the optional-auth document falls back to the public contract.
    assert "Your flows" not in client.get(SPEC, headers={"X-API-Key": token}).text, label


def test_fetching_the_document_is_not_charged_to_the_key(client, db, granted) -> None:  # noqa: ANN001
    """It meters work the key asks the platform to do. A code generator
    fetching discovery docs should not consume a run budget the manifest
    describes in terms of runs."""
    _flow, record, token = granted
    before = record.call_count

    for _ in range(3):
        assert client.get(SPEC, headers={"X-API-Key": token}).status_code == 200

    db.refresh(record)
    assert record.call_count == before
