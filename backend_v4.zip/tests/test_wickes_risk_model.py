"""The Wickes 15-dimension risk model, held to the client's own worked example.

`requirement_docs_2/.../slide 3` scores one change by hand -- Apple Pay checkout
auth -- and gets 124/140, Critical/P1, veto triggered on Business Criticality
and Security, modifier +2. That is the one number in this whole spec nobody can
argue with: it is *their* arithmetic. Everything here is checked against it
first, and only then extended to boundaries and edge cases the deck doesn't
spell out but the formula has to handle anyway.
"""

from __future__ import annotations

import pytest

from app.services.wickes_risk_model import (
    DIMENSION_KEYS,
    MAX_SCORE,
    MIN_SCORE,
    TOTAL_WEIGHT,
    apple_pay_worked_example_scores,
    apply_veto,
    assess,
    band_for,
    modifier_reading,
    net_modifier,
    score_apple_pay_worked_example,
    suggest_scores,
    veto_narrative,
)


def test_fifteen_dimensions_weight_to_the_decks_own_range() -> None:
    """Sum of weights x max score per dimension must land on the deck's stated
    ceiling of 140, since that number appears on three separate slides."""
    assert len(DIMENSION_KEYS) == 15
    assert TOTAL_WEIGHT == 28
    assert MAX_SCORE == 140
    assert MIN_SCORE == 28


def test_the_apple_pay_worked_example_reproduces_the_decks_own_numbers() -> None:
    """The one fact in this whole model that is not open to interpretation."""
    result = score_apple_pay_worked_example()

    assert result.base_score == 124
    assert result.band_before_veto == "Critical / P1"  # 124 is already in-band
    assert result.band == "Critical / P1"
    assert set(result.veto_triggered) == {"business_criticality", "security_data_privacy"}
    assert result.modifier == 2
    assert result.modifier_reading == "risk elevated"
    assert "100% automated E2E" in result.coverage_commitment


def test_every_dimension_weighted_value_matches_the_slide_table() -> None:
    """Row-by-row against slide 3's own "Weighted" column, not just the total --
    a total can be right for the wrong reasons."""
    expected_weighted = {
        "business_criticality": 15, "customer_journey_impact": 15,
        "systems_affected": 10, "integration_complexity": 10,
        "technical_complexity": 8, "third_party_dependency": 10,
        "peak_trading_exposure": 8, "security_data_privacy": 10,
        "regulatory_impact": 10, "data_change": 6, "legacy_tech_debt": 8,
        "environment_readiness": 4, "historical_defect_rate": 4,
        "rollback_recoverability": 3, "deployment_scope": 3,
    }
    result = score_apple_pay_worked_example()
    actual = {d.key: d.weighted for d in result.dimensions}
    assert actual == expected_weighted
    assert sum(expected_weighted.values()) == 124


# ---------------------------------------------------------------------------
# Band boundaries -- exact values from slide 1's table, both edges of each band
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("score", "band"),
    [
        (28, "Low"), (41, "Low"),
        (42, "Medium / P3"), (65, "Medium / P3"),
        (66, "High / P2"), (95, "High / P2"),
        (96, "Critical / P1"), (140, "Critical / P1"),
    ],
)
def test_band_boundaries_match_the_slide_table(score: int, band: str) -> None:
    assert band_for(score) == band


def test_a_score_below_the_lowest_band_still_bands_as_low() -> None:
    """The deck's own table starts at 24, four points below our reachable
    minimum of 28. A hand-entered score in that gap must still resolve to a
    real band rather than falling through the table."""
    assert band_for(24) == "Low"


# ---------------------------------------------------------------------------
# Veto rule
# ---------------------------------------------------------------------------


def test_veto_escalates_exactly_one_band() -> None:
    """A Medium-scoring change with Security=5 becomes High, not Critical --
    'auto-escalates to the next higher band', singular, per slide 1."""
    scores = {key: 2 for key in DIMENSION_KEYS}
    scores["security_data_privacy"] = 5
    escalated, hit = apply_veto(scores, "Medium / P3")
    assert escalated == "High / P2"
    assert hit == ["security_data_privacy"]


def test_veto_at_the_top_band_has_nowhere_to_escalate_to() -> None:
    scores = {key: 2 for key in DIMENSION_KEYS}
    scores["business_criticality"] = 5
    band, triggered = apply_veto(scores, "Critical / P1")
    assert band == "Critical / P1"
    assert triggered == ["business_criticality"]


def test_no_veto_dimension_at_5_leaves_the_band_unchanged() -> None:
    scores = {key: 2 for key in DIMENSION_KEYS}
    scores["technical_complexity"] = 5  # not a veto dimension
    band, triggered = apply_veto(scores, "Medium / P3")
    assert band == "Medium / P3"
    assert triggered == []


def test_multiple_veto_dimensions_still_escalate_only_one_band() -> None:
    """Two veto hits do not compound -- 'the next higher band', not two up."""
    scores = {key: 2 for key in DIMENSION_KEYS}
    scores["business_criticality"] = 5
    scores["peak_trading_exposure"] = 5
    band, triggered = apply_veto(scores, "Low")
    assert band == "Medium / P3"
    assert set(triggered) == {"business_criticality", "peak_trading_exposure"}


# ---------------------------------------------------------------------------
# Veto narration -- must not claim a move that did not happen
# ---------------------------------------------------------------------------


def test_a_veto_at_the_already_top_band_does_not_claim_to_have_escalated() -> None:
    """The worked example's own case: 124 is already Critical/P1 before the
    veto rule is even applied. 'Escalated to Critical/P1' would be false --
    nothing moved."""
    result = score_apple_pay_worked_example()
    assert result.band == result.band_before_veto == "Critical / P1"

    narrative = veto_narrative(result)
    assert "escalated" not in narrative.lower()
    assert "already at the top band" in narrative


def test_a_veto_that_genuinely_moves_the_band_says_escalated() -> None:
    scores = {key: 2 for key in DIMENSION_KEYS}
    scores["security_data_privacy"] = 5
    result = assess(
        change_id="x", change_title="x", scores=scores,
        probability=1, impact=1, confidence=1, control=1,
    )
    assert result.band_before_veto != result.band

    narrative = veto_narrative(result)
    assert "escalated from" in narrative
    assert result.band_before_veto in narrative
    assert result.band in narrative


def test_no_veto_reads_as_the_band_standing() -> None:
    result = assess(
        change_id="x", change_title="x",
        scores={key: 2 for key in DIMENSION_KEYS},
        probability=1, impact=1, confidence=1, control=1,
    )
    assert not result.veto_triggered
    assert "band stands" in veto_narrative(result)


# ---------------------------------------------------------------------------
# The modifier
# ---------------------------------------------------------------------------


def test_modifier_is_additive_not_multiplied_into_the_band() -> None:
    """Multiplying the base score by the modifier would push 124 to 248 --
    the deck never shows a number like that, and the worked example bands on
    124 alone with the modifier reported beside it."""
    assert net_modifier(probability=4, impact=5, confidence=4, control=3) == 2

    result = assess(
        change_id="CR-X", change_title="x",
        scores={key: 3 for key in DIMENSION_KEYS},
        probability=5, impact=5, confidence=1, control=1,  # modifier = +8
    )
    assert result.base_score == 3 * TOTAL_WEIGHT
    assert result.modifier == 8


@pytest.mark.parametrize(
    ("modifier", "reading"),
    [(1, "risk elevated"), (0, "risk neutral"), (-1, "risk contained")],
)
def test_modifier_reading_is_directional(modifier: int, reading: str) -> None:
    # Constructed so probability - impact + confidence + control nets to `modifier`.
    p, i, c, ctl = 3, 3, 3, 3
    net = p + i - c - ctl
    assert net == 0
    assert modifier_reading(modifier) == reading


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def test_a_missing_dimension_is_refused_not_defaulted() -> None:
    incomplete = apple_pay_worked_example_scores()
    del incomplete["deployment_scope"]
    with pytest.raises(ValueError, match="deployment_scope"):
        assess(
            change_id="x", change_title="x", scores=incomplete,
            probability=1, impact=1, confidence=1, control=1,
        )


def test_an_out_of_range_score_is_refused() -> None:
    bad = apple_pay_worked_example_scores()
    bad["data_change"] = 6
    with pytest.raises(ValueError, match="data_change"):
        assess(
            change_id="x", change_title="x", scores=bad,
            probability=1, impact=1, confidence=1, control=1,
        )


# ---------------------------------------------------------------------------
# The heuristic scorer -- derives dimension scores from a change's own text
# ---------------------------------------------------------------------------


def test_apple_pay_change_text_derives_the_vetoing_dimensions_high() -> None:
    text = (
        "Update the Hybris checkout Apple Pay 3D Secure authorisation flow ahead "
        "of Christmas peak trading. Handles card payment data (PCI-DSS)."
    )
    scores, rationale = suggest_scores(text)

    assert scores["business_criticality"] == 5
    assert scores["security_data_privacy"] == 5
    assert scores["peak_trading_exposure"] == 5
    assert scores["third_party_dependency"] == 5  # "apple pay"
    assert "apple pay" in rationale["third_party_dependency"].lower()


def test_every_dimension_gets_a_score_and_a_reason_even_with_no_signal() -> None:
    scores, rationale = suggest_scores("Update the footer copyright year.")
    assert set(scores) == set(DIMENSION_KEYS)
    assert all(1 <= v <= 5 for v in scores.values())
    assert all(rationale[key] for key in DIMENSION_KEYS)
    # No risk language at all -- everything should read as low, not guessed high.
    assert all(v <= 3 for v in scores.values())


def test_suggested_scores_are_still_a_valid_input_to_assess() -> None:
    scores, rationale = suggest_scores("Trivial copy change on the FAQ page.")
    result = assess(
        change_id="CR-1", change_title="FAQ copy fix", scores=scores,
        rationale=rationale, probability=1, impact=1, confidence=5, control=5,
    )
    assert result.band == "Low"
