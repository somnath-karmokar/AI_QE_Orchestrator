"""Project-wide grants, and the API-access panel the web app shows.

Two related things. A key can now be granted a whole project rather than a list
that has to be maintained every time something is published -- which is what
makes "every agent and flow is reachable by a third party" true in practice.
And each agent and flow can show an operator its own endpoint, with the answer
to "who can already call this?" computed from the real authorisation rules,
so the panel cannot advertise access the API would refuse.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import select

from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.services.integration import granted_agents, granted_flows, resolve_agent, resolve_flow
from app.services.integration_clients import issue_client

BASE = "/api/v1/integration"
BUILTIN = "user-story-completeness"


@pytest.fixture
def published_flow(db, project_id: str) -> AgentFlow:
    row = db.execute(
        select(AgentFlow).where(
            AgentFlow.project_id == project_id,
            AgentFlow.is_deleted.is_(False),
            AgentFlow.status == "published",
        )
    ).scalars().first()
    assert row is not None
    return row


@pytest.fixture
def draft_flow(db, project_id: str, published_flow: AgentFlow) -> AgentFlow:
    """A draft, so the published-only rule has something to exclude."""
    draft = AgentFlow(
        project_id=project_id,
        key=f"draft-{published_flow.key}",
        name="Not ready yet",
        status="draft",
        variables={},
    )
    db.add(draft)
    db.commit()
    return draft


def _key(db, project_id: str, **kwargs) -> tuple:  # noqa: ANN003
    kwargs.setdefault("scopes", ["catalog:read", "flows:run", "agents:run", "runs:read"])
    record, token = issue_client(db, project_id=project_id, actor="alex.morgan@example.com", **kwargs)
    db.commit()
    return record, token


@pytest.fixture(autouse=True)
def _no_background_execution(monkeypatch):  # noqa: ANN001, ANN202
    """Create runs without executing them.

    These tests are about who owns a run and who may read it, not about what the
    run does. Letting each one dispatch a real worker thread makes them slow and
    flaky: the threads open their own sessions against the same SQLite file and
    collide with the test's own writes ("database is locked").
    """
    from app.services import run_service

    monkeypatch.setattr(run_service.job_queue, "submit", lambda name, *args, **kwargs: None)


def headers(token: str) -> dict[str, str]:
    return {"X-API-Key": token}


# ---------------------------------------------------------------------------
# A project-wide grant
# ---------------------------------------------------------------------------


def test_a_project_wide_key_reaches_every_published_flow(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """Without naming one. The point: a third party gets the whole project, and
    the list does not have to be maintained as flows are published."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True)

    catalog = client.get(f"{BASE}/catalog", headers=headers(token)).json()
    listed = {flow["id"] for flow in catalog["flows"]}

    assert len(listed) > 1
    assert published_flow.id in listed


def test_a_project_wide_key_reaches_every_agent(client, db, project_id: str) -> None:  # noqa: ANN001
    _record, token = _key(db, project_id, name="partner", grants_all_agents=True)

    catalog = client.get(f"{BASE}/catalog", headers=headers(token)).json()
    keys = {agent["key"] for agent in catalog["agents"]}

    assert len(keys) > 10, "the built-in catalogue should be reachable"
    assert BUILTIN in keys


def test_a_project_wide_key_can_call_something_it_never_named(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """The catalog listing it is not the same as the endpoint accepting it."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True, grants_all_agents=True)

    flow_run = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}}
    )
    agent_run = client.post(
        f"{BASE}/agents/{BUILTIN}/runs",
        headers=headers(token),
        json={"inputs": {"requirement_key": "PAY-201"}},
    )

    assert flow_run.status_code == 202, flow_run.text
    assert agent_run.status_code == 202, agent_run.text


def test_a_draft_flow_is_not_included_in_a_project_wide_grant(client, db, project_id: str, draft_flow) -> None:  # noqa: ANN001
    """Publishing is the act that says a flow is ready for someone else to run."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True)

    catalog = client.get(f"{BASE}/catalog", headers=headers(token)).json()
    assert draft_flow.id not in {flow["id"] for flow in catalog["flows"]}

    refused = client.post(f"{BASE}/flows/{draft_flow.id}/runs", headers=headers(token), json={"inputs": {}})
    assert refused.status_code == 404


def test_a_draft_named_explicitly_is_still_honoured(client, db, project_id: str, draft_flow) -> None:  # noqa: ANN001
    """An operator naming one flow is a deliberate act, whatever its status."""
    _record, token = _key(db, project_id, name="named", allowed_flow_ids=[draft_flow.id])

    catalog = client.get(f"{BASE}/catalog", headers=headers(token)).json()
    assert draft_flow.id in {flow["id"] for flow in catalog["flows"]}


def test_a_project_wide_grant_stops_at_the_project_boundary(client, db, project_id: str) -> None:  # noqa: ANN001
    """"All" means all of *this* project, never another one."""
    other = db.execute(
        select(AgentFlow).where(AgentFlow.project_id != project_id, AgentFlow.is_deleted.is_(False))
    ).scalars().first()
    if other is None:
        pytest.skip("the demo data has only one project")

    _record, token = _key(db, project_id, name="partner", grants_all_flows=True)

    assert client.post(
        f"{BASE}/flows/{other.id}/runs", headers=headers(token), json={"inputs": {}}
    ).status_code == 404


def test_the_flags_are_off_unless_asked_for(db, project_id: str) -> None:  # noqa: ANN001
    """A key must never widen by accident."""
    record, _token = _key(db, project_id, name="narrow")

    assert record.grants_all_flows is False
    assert record.grants_all_agents is False
    assert granted_flows(db, record) == []
    assert granted_agents(db, record) == []


def test_a_project_wide_grant_still_needs_the_scope(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """Reach and permission are separate: the grant says *which*, the scope says
    *whether*."""
    _record, token = _key(
        db, project_id, name="reader", scopes=["catalog:read"], grants_all_flows=True
    )

    assert client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json={"inputs": {}}
    ).status_code == 403


def test_the_manifest_counts_what_a_wide_key_can_actually_call(client, db, project_id: str) -> None:  # noqa: ANN001
    """It used to report the length of the grant list, which is zero for a
    project-wide key -- advertising nothing to call."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True, grants_all_agents=True)

    limits = client.get(f"{BASE}/manifest", headers=headers(token)).json()["limits"]

    assert limits["flows_available"] > 0
    assert limits["agents_available"] > 0


def test_a_wide_key_gets_a_typed_operation_per_capability(client, db, project_id: str) -> None:  # noqa: ANN001
    """The generated OpenAPI document must widen with the grant too."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True, grants_all_agents=True)

    spec = client.get(f"{BASE}/openapi.json", headers=headers(token)).json()
    operations = [path for path in spec["paths"] if "/runs" in path]

    assert len(operations) > 10
    assert any(BUILTIN in path for path in operations)


def test_mcp_offers_the_same_widened_set(client, db, project_id: str) -> None:  # noqa: ANN001
    """An agent platform must see exactly what a pipeline sees."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True, grants_all_agents=True)

    response = client.post(
        "/api/v1/mcp", headers=headers(token), json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"}
    )
    tools = response.json()["result"]["tools"]

    assert len([t for t in tools if t["_meta"].get("kind") == "agent"]) > 10
    assert len([t for t in tools if t["_meta"].get("kind") == "flow"]) > 1


def test_an_expired_wide_key_is_still_refused(client, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """Widening what a key reaches must not change when it stops working."""
    record, token = _key(db, project_id, name="partner", grants_all_flows=True)
    record.expires_at = datetime.now(UTC) - timedelta(days=1)
    db.commit()

    assert client.get(f"{BASE}/catalog", headers=headers(token)).status_code == 401


# ---------------------------------------------------------------------------
# The API-access panel
# ---------------------------------------------------------------------------


def test_a_flow_reports_its_endpoint(client, auth_headers, published_flow) -> None:  # noqa: ANN001
    body = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).json()

    assert body["endpoint"]["method"] == "POST"
    assert body["endpoint"]["path"] == f"/api/v1/integration/flows/{published_flow.id}/runs"
    assert body["endpoint"]["url"].endswith(body["endpoint"]["path"])
    assert body["authentication"]["scope_required"] == "flows:run"
    assert body["authentication"]["header"] == "X-API-Key"


def test_an_agent_reports_its_endpoint_and_mcp_tool(client, auth_headers, db, project_id: str) -> None:  # noqa: ANN001
    agent = db.execute(select(Agent).where(Agent.handler_key == BUILTIN)).scalars().first()

    body = client.get(
        f"/api/v1/agents/{agent.id}/api-access", headers=auth_headers, params={"project_id": project_id}
    ).json()

    assert body["id"] == BUILTIN
    assert body["endpoint"]["path"] == f"/api/v1/integration/agents/{BUILTIN}/runs"
    assert body["authentication"]["scope_required"] == "agents:run"
    assert body["mcp"]["tool"] == "run_agent_user_story_completeness"


def test_the_example_is_a_body_that_would_be_accepted(client, auth_headers, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """A sample that the API would reject is worse than no sample. Take the one
    the panel shows and post it."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True)

    panel = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).json()
    response = client.post(
        f"{BASE}/flows/{published_flow.id}/runs", headers=headers(token), json=panel["example"]["body"]
    )

    assert response.status_code == 202, response.text


def test_the_curl_snippet_names_the_header_and_the_url(client, auth_headers, published_flow) -> None:  # noqa: ANN001
    snippet = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).json()["example"]["curl"]

    assert "X-API-Key" in snippet
    assert "X-Idempotency-Key" in snippet
    assert f"/integration/flows/{published_flow.id}/runs" in snippet


def test_it_lists_the_keys_that_can_call_it_and_how(client, auth_headers, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    _key(db, project_id, name="wide-open", grants_all_flows=True)
    _key(db, project_id, name="just-this-one", allowed_flow_ids=[published_flow.id])

    keys = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).json()["keys"]
    by_name = {entry["name"]: entry for entry in keys}

    assert by_name["wide-open"]["grant"] == "project-wide"
    assert by_name["just-this-one"]["grant"] == "named explicitly"


def test_it_never_shows_a_token(client, auth_headers, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """Only the hint the operator UI shows everywhere else."""
    _record, token = _key(db, project_id, name="partner", grants_all_flows=True)

    body = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).text

    assert token not in body
    assert "token_hash" not in body


def test_an_expired_key_is_not_listed_as_able_to_call(client, auth_headers, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """The panel's whole claim is that it reflects the real rules. An expired
    key is refused at the door, so listing it would promise access that does not
    exist -- which this did until `is_usable` became the shared rule."""
    record, _token = _key(db, project_id, name="lapsed", allowed_flow_ids=[published_flow.id])
    record.expires_at = datetime.now(UTC) - timedelta(days=1)
    db.commit()

    keys = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).json()["keys"]

    assert "lapsed" not in {entry["name"] for entry in keys}


def test_a_revoked_key_is_not_listed_either(client, auth_headers, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    record, _token = _key(db, project_id, name="revoked-key", allowed_flow_ids=[published_flow.id])
    record.is_active = False
    db.commit()

    keys = client.get(f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers).json()["keys"]

    assert "revoked-key" not in {entry["name"] for entry in keys}


def test_a_draft_flow_says_why_nobody_can_call_it(client, auth_headers, draft_flow) -> None:  # noqa: ANN001
    """An endpoint that would answer 404, shown without explanation, wastes an
    afternoon."""
    body = client.get(f"/api/v1/flows/{draft_flow.id}/api-access", headers=auth_headers).json()

    assert body["available"] is False
    assert "draft" in body["unavailable_reason"]
    assert "publish" in body["unavailable_reason"].lower()


def test_the_panel_agrees_with_the_authorisation_rules(client, auth_headers, db, project_id: str, published_flow) -> None:  # noqa: ANN001
    """The structural guarantee: a key appears in the panel exactly when the rule
    the endpoint uses would let it through -- checked in both directions, over a
    wide key, a named key and an expired one.

    Names are made unique per run because other tests in this module leave keys
    behind in the same project, and two keys sharing a name would make this
    comparison meaningless rather than wrong.
    """
    import uuid

    marker = uuid.uuid4().hex[:8]
    wide, _ = _key(db, project_id, name=f"wide-{marker}", grants_all_flows=True)
    named, _ = _key(db, project_id, name=f"named-{marker}", allowed_flow_ids=[published_flow.id])
    lapsed, _ = _key(db, project_id, name=f"lapsed-{marker}", allowed_flow_ids=[published_flow.id])
    lapsed.expires_at = datetime.now(UTC) - timedelta(days=1)
    db.commit()

    listed = {
        entry["name"]
        for entry in client.get(
            f"/api/v1/flows/{published_flow.id}/api-access", headers=auth_headers
        ).json()["keys"]
    }

    for record in (wide, named, lapsed):
        permitted = record.is_usable() and resolve_flow(db, record, published_flow.id) is not None
        assert (record.name in listed) == permitted, f"{record.name}: listed={record.name in listed}"

    # And the expected shape of that answer, so the test cannot pass by agreeing
    # that nothing is permitted.
    assert wide.name in listed and named.name in listed and lapsed.name not in listed


def test_the_panel_needs_a_session(client, published_flow) -> None:  # noqa: ANN001
    """It names the project's API keys, so it is not public."""
    assert client.get(f"/api/v1/flows/{published_flow.id}/api-access").status_code in {401, 403}


def test_an_unknown_flow_is_a_404(client, auth_headers) -> None:  # noqa: ANN001
    assert client.get("/api/v1/flows/not-a-flow/api-access", headers=auth_headers).status_code == 404


def test_resolve_agent_and_the_panel_agree_for_a_wide_key(db, project_id: str) -> None:  # noqa: ANN001
    """`resolve_agent` is what the endpoint calls; a project-wide grant must let
    it through for an agent the key never named."""
    record, _token = _key(db, project_id, name="partner", grants_all_agents=True)

    assert record.allowed_agent_keys == []
    assert resolve_agent(db, record, BUILTIN) is not None
