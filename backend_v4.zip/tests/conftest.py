"""Test fixtures.

Every test runs against a throwaway SQLite database and an in-memory vector
store, so the suite is fast, isolated and needs no external services.
"""

from __future__ import annotations

import os
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

# Configure the environment before app modules read settings at import time.
_TEST_DIR = Path(tempfile.mkdtemp(prefix="aiqe-tests-"))

# A stand-in web app build, so serving tests never depend on a real frontend build.
WEB_APP_DIR = _TEST_DIR / "web"
(WEB_APP_DIR / "assets").mkdir(parents=True)
(WEB_APP_DIR / "index.html").write_text("<!doctype html><div id=root></div>", encoding="utf-8")
(WEB_APP_DIR / "assets" / "app.js").write_text("console.log('app');", encoding="utf-8")

os.environ.update(
    {
        "DATABASE_URL": f"sqlite:///{(_TEST_DIR / 'test.db').as_posix()}",
        "CHROMA_PERSIST_DIRECTORY": str(_TEST_DIR / "chroma"),
        "EXECUTION_ARTIFACTS_DIR": str(_TEST_DIR / "artifacts"),
        "FRONTEND_DIST_DIR": str(WEB_APP_DIR),
        "DEMO_MODE": "true",
        "DEFAULT_LLM_PROVIDER": "mock",
        "AUTO_SEED_ON_STARTUP": "false",
        "SCHEDULER_ENABLED": "false",
        "JWT_SECRET": "test-secret-value-for-the-test-suite-only",
        "LOG_LEVEL": "WARNING",
    }
)

from sqlalchemy.orm import Session  # noqa: E402

from app.core.database import SessionLocal, engine  # noqa: E402
from app.models import Base  # noqa: E402
from app.vectorstore import factory as vector_factory  # noqa: E402
from app.vectorstore.memory import InMemoryVectorStore  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _use_in_memory_vector_store() -> Iterator[None]:
    """Swap Chroma for the in-memory store so tests never touch disk or a server."""
    store = InMemoryVectorStore()
    vector_factory._store = store  # noqa: SLF001 - deliberate test seam
    yield
    vector_factory.reset_vector_store()


@pytest.fixture(scope="session", autouse=True)
def _schema() -> Iterator[None]:
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def session() -> Iterator[Session]:
    """A session whose writes are rolled back after each test."""
    connection = engine.connect()
    transaction = connection.begin()
    db = Session(bind=connection)
    try:
        yield db
    finally:
        db.close()
        transaction.rollback()
        connection.close()


@pytest.fixture(scope="session")
def seeded() -> dict:
    """Seed the catalogue and demo project once for the whole session.

    Document indexing is skipped to keep the suite fast, but the agent
    catalogue *is* indexed: the copilot selects agents by semantic similarity,
    so without it the tests would exercise only the intent prior and quietly
    miss the behaviour that matters.
    """
    from sqlalchemy import select  # noqa: PLC0415

    from app.copilot.service import index_agent_catalog  # noqa: PLC0415
    from app.core.database import session_scope  # noqa: PLC0415
    from app.models.project import Project  # noqa: PLC0415
    from app.seed.runner import seed_all  # noqa: PLC0415

    summary = seed_all(reset=False, index_knowledge=False)

    with session_scope() as session:
        project = session.execute(select(Project).where(Project.key == "ABCR")).scalar_one_or_none()
        if project is not None:
            summary["indexed_agents"] = index_agent_catalog(session, project)

    return summary


@pytest.fixture(autouse=True)
def _drain_background_jobs() -> Iterator[None]:
    """Let any job a test started finish before the next test begins.

    Runs dispatch to a thread pool, and those threads open their own sessions
    against the same SQLite file. A job still writing while the next test sets
    up surfaces as "database is locked" in a test that did nothing wrong, which
    is a slow and confusing thing to debug.
    """
    yield
    from app.core.worker import job_queue  # noqa: PLC0415

    job_queue.wait_for_idle(timeout=30)


@pytest.fixture
def db(seeded) -> Iterator[Session]:  # noqa: ANN001, ARG001
    """A committed session over the seeded database."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.rollback()
        db.close()


@pytest.fixture
def client(seeded):  # noqa: ANN001, ANN201, ARG001
    """FastAPI test client against the seeded database."""
    from fastapi.testclient import TestClient  # noqa: PLC0415

    from app.main import app  # noqa: PLC0415

    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def auth_headers(client) -> dict[str, str]:  # noqa: ANN001
    response = client.post(
        "/api/v1/auth/login",
        json={"email": "alex.morgan@example.com", "password": "Demo!2024"},
    )
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


@pytest.fixture
def project_id(client, auth_headers) -> str:  # noqa: ANN001
    """The seeded demo project, named rather than taken by position.

    This used to return the first project in the listing, which was the demo
    project only because nothing else had ever created one. A test that creates
    a second project -- as the tenancy and data source tests must -- then
    silently changed which project every other test in the session ran against,
    and the failures landed in unrelated files.
    """
    response = client.get("/api/v1/projects", headers=auth_headers, params={"limit": 200})
    assert response.status_code == 200, response.text
    items = response.json()["items"]
    demo = next((row for row in items if row["key"] == "ABCR"), None)
    assert demo is not None, f"the seeded demo project is missing; saw {[r['key'] for r in items]}"
    return demo["id"]


@pytest.fixture(params=["native", "langgraph"])
def orchestration_engine(request, monkeypatch):  # noqa: ANN001, ANN201
    """Run a test once on each flow runtime.

    Use as `pytestmark = pytest.mark.usefixtures("orchestration_engine")`. The
    scenarios written against the original engine are the specification the
    LangGraph runtime is held to, so they run on both.
    """
    from app.core.config import settings  # noqa: PLC0415

    monkeypatch.setattr(settings, "orchestration_engine", request.param)
    return request.param
