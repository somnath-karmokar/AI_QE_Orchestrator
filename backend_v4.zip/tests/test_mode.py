"""Local mode and production mode.

The platform degrades gracefully when something is missing — a mock model, a
simulated browser, an invented Jira ticket — and logs a warning. That is right
for a demo and dangerous in production, where the failure mode is a customer
being shown simulated test results as though a browser had run them.

These tests hold the line that production refuses rather than degrades, and that
every refusal names what to set.
"""

from __future__ import annotations

import pytest

from app.core.config import settings
from app.core.mode import (
    Mode,
    ModeViolation,
    current_mode,
    enforce_production_readiness,
    forbid_stand_in,
    is_production,
    readiness,
)


@pytest.fixture
def production(monkeypatch):
    monkeypatch.setattr(settings, "app_mode", "production")
    return settings


@pytest.fixture
def ready_production(monkeypatch):
    """A deployment that has configured everything real."""
    monkeypatch.setattr(settings, "app_mode", "production")
    monkeypatch.setattr(settings, "demo_mode", False)
    monkeypatch.setattr(settings, "auto_seed_on_startup", False)
    monkeypatch.setattr(settings, "playwright_enabled", True)
    monkeypatch.setattr(settings, "jwt_secret", "a-genuinely-random-secret-value-for-tests")
    monkeypatch.setattr(settings, "default_llm_provider", "bedrock")
    monkeypatch.setattr(settings, "bedrock_region", "eu-west-2")
    return settings


# ---------------------------------------------------------------------------
# The switch
# ---------------------------------------------------------------------------


def test_local_is_the_default() -> None:
    """A fresh clone must run with nothing installed."""
    assert settings.app_mode == "local"
    assert current_mode() is Mode.LOCAL
    assert is_production() is False


def test_production_is_recognised(production) -> None:
    assert current_mode() is Mode.PRODUCTION
    assert is_production() is True


# ---------------------------------------------------------------------------
# What production refuses
# ---------------------------------------------------------------------------


def test_production_refuses_to_start_on_a_demo_install(db, production) -> None:
    """The whole point: a demo install must not quietly become production."""
    with pytest.raises(ModeViolation) as raised:
        enforce_production_readiness(db)

    message = str(raised.value)
    assert "would fall back to a stand-in" in message
    assert "APP_MODE=local" in message


def test_every_refusal_names_what_to_set(db, production) -> None:
    """A refusal an operator cannot act on is just an outage."""
    report = readiness(db)
    for check in report.blocking_failures:
        assert check.remedy, f"{check.component} fails without saying how to fix it"


@pytest.mark.parametrize(
    ("setting", "value", "component"),
    [
        ("default_llm_provider", "mock", "llm_provider"),
        ("playwright_enabled", False, "test_execution"),
        ("demo_mode", True, "demo_mode"),
        ("auto_seed_on_startup", True, "auto_seed"),
        ("jwt_secret", "change-me-in-production-please-use-a-long-random-value", "jwt_secret"),
    ],
)
def test_each_stand_in_blocks_production(
    db, ready_production, monkeypatch, setting: str, value, component: str
) -> None:
    monkeypatch.setattr(settings, setting, value)
    report = readiness(db)

    failed = {check.component for check in report.blocking_failures}
    assert component in failed


def test_a_selected_but_unconfigured_provider_is_caught(db, ready_production, monkeypatch) -> None:
    """Checking the setting alone would pass a deployment that then silently
    ran every call on the demo model."""
    monkeypatch.setattr(settings, "bedrock_region", None)
    report = readiness(db)

    llm = next(check for check in report.checks if check.component == "llm_provider")
    assert llm.ready is False
    assert "fall back to the mock model" in llm.detail


def test_simulated_execution_is_treated_as_a_stand_in(db, ready_production, monkeypatch) -> None:
    """A pass rate derived from a model of the application, shown next to real
    ones, is indistinguishable from evidence."""
    monkeypatch.setattr(settings, "playwright_enabled", False)
    report = readiness(db)

    execution = next(check for check in report.checks if check.component == "test_execution")
    assert execution.ready is False
    assert "simulated" in execution.detail


def test_demo_mcp_connectors_block_production(db, ready_production) -> None:
    """The seeded servers are on demo connectors, which invent tickets and commits."""
    report = readiness(db)
    mcp = next(check for check in report.checks if check.component == "mcp_connectors")

    assert mcp.ready is False
    assert "invented data" in mcp.detail
    # Each key named once, not once per configuration row.
    listed = mcp.detail.split(":")[-1]
    keys = [item.strip(" .") for item in listed.split(",")]
    assert len(keys) == len(set(keys))


# ---------------------------------------------------------------------------
# What production tolerates
# ---------------------------------------------------------------------------


def test_sqlite_is_a_warning_not_a_refusal(db, ready_production) -> None:
    """Wrong for production, but a deployment's own problem rather than a
    correctness one -- it does not make results untrue."""
    report = readiness(db)
    database = next(check for check in report.checks if check.component == "database")

    assert database.blocking is False
    assert database.component not in {item.component for item in report.blocking_failures}


def test_local_mode_never_refuses(db) -> None:
    """A developer with nothing installed must still be able to run it."""
    report = enforce_production_readiness(db)
    assert report.mode == "local"


# ---------------------------------------------------------------------------
# Runtime guards, for what startup cannot catch
# ---------------------------------------------------------------------------


def test_a_runtime_fallback_is_allowed_locally() -> None:
    forbid_stand_in("something", "detail", "remedy")  # must not raise


def test_a_runtime_fallback_is_refused_in_production(production) -> None:
    """Startup catches nearly everything; this catches a component that was
    reachable at boot and is not any more."""
    with pytest.raises(ModeViolation) as raised:
        forbid_stand_in("the vector store", "Chroma went away.", "Restore Chroma.")

    assert "vector store" in str(raised.value)
    assert "Restore Chroma." in str(raised.value)


def test_the_provider_registry_refuses_to_substitute_the_mock(production, monkeypatch) -> None:
    """The most dangerous fallback: a working-looking platform giving demo
    answers to real questions."""
    from app.ai.providers.registry import _INSTANCES, get_provider

    monkeypatch.setattr(settings, "default_llm_provider", "bedrock")
    monkeypatch.setattr(settings, "bedrock_region", None)
    _INSTANCES.pop("bedrock", None)

    with pytest.raises(ModeViolation):
        get_provider("bedrock")


def test_the_provider_registry_still_substitutes_locally(monkeypatch) -> None:
    from app.ai.providers.registry import _INSTANCES, get_provider

    monkeypatch.setattr(settings, "app_mode", "local")
    monkeypatch.setattr(settings, "bedrock_region", None)
    _INSTANCES.pop("bedrock", None)

    assert get_provider("bedrock").key == "mock"


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def test_readiness_is_served_and_names_no_secret(client) -> None:
    response = client.get("/api/v1/system/readiness")
    assert response.status_code == 200

    body = response.text.lower()
    for forbidden in ("password", "api_key", "secret_value", "token"):
        assert forbidden not in body


def test_readiness_reports_the_mode_and_each_component(client) -> None:
    body = client.get("/api/v1/system/readiness").json()

    assert body["mode"] == "local"
    components = {check["component"] for check in body["checks"]}
    assert {"llm_provider", "test_execution", "vector_store", "mcp_connectors"} <= components


def test_health_reports_which_mode_is_running(client) -> None:
    assert client.get("/health").json()["mode"] == "local"


def test_readiness_is_not_a_failure_in_local_mode(client) -> None:
    """Stand-ins are expected locally, so a probe must not report the platform
    as unhealthy for using them."""
    assert client.get("/api/v1/system/readiness").status_code == 200


# ---------------------------------------------------------------------------
# Browser-facing configuration
# ---------------------------------------------------------------------------


def test_a_wildcard_origin_with_credentials_blocks_production(db, ready_production, monkeypatch) -> None:  # noqa: ANN001
    """`CORS_ORIGINS=*` is the usual shortcut when something is blocked, and
    with credentials allowed Starlette echoes back whichever origin asked --
    so every site on the internet becomes a trusted origin."""
    monkeypatch.setattr(settings, "cors_origins", ["*"])
    report = readiness(db)

    cors = next(check for check in report.checks if check.component == "cors")
    assert cors.ready is False
    assert cors.blocking is True
    assert "CORS_ORIGINS" in (cors.remedy or "")


def test_plain_http_origins_block_production(db, ready_production, monkeypatch) -> None:  # noqa: ANN001
    monkeypatch.setattr(settings, "cors_origins", ["http://app.example.com"])
    report = readiness(db)

    cors = next(check for check in report.checks if check.component == "cors")
    assert cors.ready is False
    assert "not HTTPS" in cors.detail


def test_explicit_https_origins_are_accepted(db, ready_production, monkeypatch) -> None:  # noqa: ANN001
    monkeypatch.setattr(settings, "cors_origins", ["https://qe.example.com"])
    report = readiness(db)

    assert next(check for check in report.checks if check.component == "cors").ready is True


def test_the_local_defaults_are_not_a_production_gate_failure_locally(db) -> None:  # noqa: ANN001
    """The shipped default is http://localhost:5173, which must stay fine."""
    assert enforce_production_readiness(db).mode == "local"


def test_responses_carry_the_baseline_transport_headers(client) -> None:  # noqa: ANN001
    headers = client.get("/health").headers

    assert headers["X-Content-Type-Options"] == "nosniff"
    assert headers["X-Frame-Options"] == "DENY"
    assert headers["Referrer-Policy"] == "strict-origin-when-cross-origin"
    # The copilot's voice input needs this one, so it is scoped rather than off.
    assert "microphone=(self)" in headers["Permissions-Policy"]


def test_hsts_is_sent_only_in_production(client) -> None:
    """Sending it from a local http:// server pins the browser to https for
    localhost and breaks whatever the next developer runs on that port."""
    assert "Strict-Transport-Security" not in client.get("/health").headers


# ---------------------------------------------------------------------------
# The orchestration runtime
# ---------------------------------------------------------------------------

TRACING_FLAGS = ("LANGSMITH_TRACING", "LANGCHAIN_TRACING_V2", "LANGSMITH_TRACING_V2", "LANGCHAIN_TRACING")


@pytest.fixture
def no_tracing(monkeypatch) -> None:  # noqa: ANN001
    for name in TRACING_FLAGS:
        monkeypatch.delenv(name, raising=False)


def _check(report, component: str):  # noqa: ANN001, ANN202
    return next(check for check in report.checks if check.component == component)


def test_readiness_names_the_runtime_flows_run_on(db, no_tracing) -> None:  # noqa: ANN001, ARG001
    check = _check(readiness(db), "orchestration")

    assert check.ready is True and check.blocking is False
    assert "LangGraph" in check.detail


def test_langsmith_tracing_blocks_production(db, ready_production, monkeypatch, no_tracing) -> None:  # noqa: ANN001, ARG001
    """LangGraph can ship every run's state to LangSmith's cloud, and that state is
    inputs a caller supplied and what agents made of them. One environment
    variable is all it would take, so production refuses to start with it set."""
    monkeypatch.setenv("LANGSMITH_TRACING", "true")
    check = _check(readiness(db), "tracing")

    assert check.ready is False and check.blocking is True
    assert "LANGSMITH_TRACING" in (check.remedy or "")
    assert "tracing" in {failure.component for failure in readiness(db).blocking_failures}


@pytest.mark.parametrize("flag", TRACING_FLAGS)
def test_every_spelling_of_the_tracing_switch_is_caught(db, ready_production, monkeypatch, no_tracing, flag: str) -> None:  # noqa: ANN001, ARG001
    """The switch has been renamed over time; a deployment may use any of them."""
    monkeypatch.setenv(flag, "true")
    assert _check(readiness(db), "tracing").ready is False


def test_tracing_explicitly_off_is_fine(db, ready_production, monkeypatch, no_tracing) -> None:  # noqa: ANN001, ARG001
    monkeypatch.setenv("LANGSMITH_TRACING", "false")
    assert _check(readiness(db), "tracing").ready is True


def test_the_native_engine_has_nothing_to_trace(db, ready_production, monkeypatch, no_tracing) -> None:  # noqa: ANN001, ARG001
    """LangChain's tracing hooks only apply to LangChain runnables, which the
    native engine never creates."""
    monkeypatch.setattr(settings, "orchestration_engine", "native")
    monkeypatch.setenv("LANGSMITH_TRACING", "true")

    assert _check(readiness(db), "tracing").ready is True


def test_tracing_never_refuses_a_local_start(db, monkeypatch, no_tracing) -> None:  # noqa: ANN001, ARG001
    monkeypatch.setenv("LANGSMITH_TRACING", "true")
    assert enforce_production_readiness(db).mode == "local"
