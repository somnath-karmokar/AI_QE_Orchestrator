"""Selecting impacted tests from a real (temporary) git repo of test packs."""

from __future__ import annotations

from pathlib import Path

from app.services.wickes_test_pack import scan_repo, select_impacted


def _write(root: Path, relative: str, *, journey: str, priority: str, tags: str, defects: int | None = None) -> None:
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        '"""', "A synthetic test.", '"""',
        f"# journey: {journey}", f"# priority: {priority}", f"# tags: {tags}",
    ]
    if defects:
        lines.append(f"# defect_history: {defects} in last 90d")
    lines += ["", "def test_x():", "    assert True", ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def test_scan_reads_journey_priority_tags_and_defect_history(tmp_path: Path) -> None:
    _write(tmp_path, "checkout/test_pay.py", journey="checkout", priority="P1", tags="payment, pci", defects=3)
    files = scan_repo(tmp_path)
    assert len(files) == 1
    test = files[0]
    assert test.journey == "checkout"
    assert test.priority == "P1"
    assert test.tags == ("payment", "pci")
    assert test.recent_defects == 3


def test_a_file_without_the_header_is_skipped_not_guessed_at(tmp_path: Path) -> None:
    (tmp_path / "test_untagged.py").write_text("def test_x():\n    assert True\n", encoding="utf-8")
    assert scan_repo(tmp_path) == []


def test_only_test_underscore_files_are_scanned(tmp_path: Path) -> None:
    _write(tmp_path, "checkout/helpers.py", journey="checkout", priority="P1", tags="payment")
    assert scan_repo(tmp_path) == []


def test_a_p2_test_in_the_journey_with_no_tag_overlap_is_not_selected(tmp_path: Path) -> None:
    """The design this guards against: selecting a whole journey wholesale
    just because a test happens to live there. Only a shared tag, or the P1
    floor, earns a place -- a P2 with neither gets left out, which is what
    leaves 'rank' and 'de-duplicate' something real to do."""
    _write(tmp_path, "checkout/test_totals.py", journey="checkout-payment", priority="P2", tags="totals")
    files = scan_repo(tmp_path)
    selected = select_impacted(files, journey="checkout-payment", change_tags=("apple-pay",))
    assert selected == []


def test_a_test_relevant_by_tag_and_in_the_same_journey_names_both_reasons(tmp_path: Path) -> None:
    _write(tmp_path, "checkout/test_pay.py", journey="checkout-payment", priority="P2", tags="apple-pay")
    files = scan_repo(tmp_path)
    selected = select_impacted(files, journey="checkout-payment", change_tags=("apple-pay",))
    assert len(selected) == 1
    assert "tags overlap" in selected[0].reason
    assert "journey" in selected[0].reason


def test_tag_only_match_is_selected_across_journeys(tmp_path: Path) -> None:
    _write(tmp_path, "account/test_saved_cards.py", journey="account", priority="P2", tags="payment, pci")
    files = scan_repo(tmp_path)
    selected = select_impacted(files, journey="checkout-payment", change_tags=("payment", "pci"))
    assert len(selected) == 1
    assert "tags overlap" in selected[0].reason


def test_unrelated_tests_are_not_selected(tmp_path: Path) -> None:
    _write(tmp_path, "search/test_relevance.py", journey="search", priority="P2", tags="search, plp")
    files = scan_repo(tmp_path)
    selected = select_impacted(files, journey="checkout-payment", change_tags=("payment",))
    assert selected == []


def test_p1_floor_includes_every_p1_test_in_the_journey_even_without_tag_or_journey_overlap(tmp_path: Path) -> None:
    """The floor is what makes 'journey is impacted' true for P1 coverage
    specifically -- so it must reach a P1 test even when the CR names a
    *different* journey than the test file happens to sit in is not the case
    here; the case that matters is no tag relevance at all."""
    _write(tmp_path, "checkout/test_p1_unrelated_tags.py", journey="checkout-payment", priority="P1", tags="totally-unrelated")
    _write(tmp_path, "checkout/test_p2_unrelated_tags.py", journey="checkout-payment", priority="P2", tags="also-unrelated")
    files = scan_repo(tmp_path)
    selected = select_impacted(files, journey="checkout-payment", change_tags=("apple-pay",))

    assert any(s.test.path.name == "test_p1_unrelated_tags.py" for s in selected)
    p1 = next(s for s in selected if s.test.path.name == "test_p1_unrelated_tags.py")
    assert "floor" in p1.reason
    # The P2 with no overlap at all is correctly left out -- the floor is P1-only.
    assert not any(s.test.path.name == "test_p2_unrelated_tags.py" for s in selected)


def test_disabling_the_p1_floor_only_selects_on_relevance(tmp_path: Path) -> None:
    _write(tmp_path, "checkout/test_p1_unrelated_tags.py", journey="checkout-payment", priority="P1", tags="totally-unrelated")
    files = scan_repo(tmp_path)
    selected = select_impacted(
        files, journey="checkout-payment", change_tags=("apple-pay",), enforce_p1_floor=False,
    )
    assert selected == []


def test_selection_has_no_duplicates_when_journey_and_tags_both_match(tmp_path: Path) -> None:
    """A test that matches by journey AND by tag overlap must appear once, not twice."""
    _write(tmp_path, "checkout/test_both.py", journey="checkout-payment", priority="P1", tags="apple-pay")
    files = scan_repo(tmp_path)
    selected = select_impacted(files, journey="checkout-payment", change_tags=("apple-pay",))
    assert len(selected) == 1


def test_ranking_prefers_more_tags_then_journey_match_then_defect_history(tmp_path: Path) -> None:
    _write(tmp_path, "account/test_one_tag_cross_journey.py", journey="account", priority="P2", tags="apple-pay")
    _write(tmp_path, "checkout/test_one_tag_same_journey.py", journey="checkout-payment", priority="P2", tags="apple-pay")
    _write(tmp_path, "checkout/test_two_tags_same_journey.py", journey="checkout-payment", priority="P2", tags="apple-pay, pci")
    _write(
        tmp_path, "checkout/test_two_tags_same_journey_and_defects.py",
        journey="checkout-payment", priority="P2", tags="apple-pay, pci", defects=4,
    )
    files = scan_repo(tmp_path)
    selected = select_impacted(
        files, journey="checkout-payment", change_tags=("apple-pay", "pci"), enforce_p1_floor=False,
    )

    ranked = [s.test.path.name for s in selected]
    assert ranked == [
        "test_two_tags_same_journey_and_defects.py",  # two tags + in-journey + defect history: highest
        "test_two_tags_same_journey.py",               # two tags + in-journey
        "test_one_tag_same_journey.py",                 # one tag + in-journey: beats...
        "test_one_tag_cross_journey.py",                 # ...one tag with no journey bonus
    ]
