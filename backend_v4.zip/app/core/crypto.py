"""Encryption for the secrets tenants hand us.

When a customer connects their own database, Jira or object store, they give
this platform a credential that opens their systems, not ours. Those live in the
same table as everything else, so anything that can read the database -- a
backup, a support query, a stolen file, a SQL injection elsewhere in the app --
reads every tenant's credentials at once unless they are encrypted before they
get there.

This module is the only place that turns plaintext into stored ciphertext and
back. Callers hold `SecretBundle`, never a raw string from the database.

The scheme is Fernet: AES-128-CBC with an HMAC-SHA256 authentication tag, from
`cryptography`, which is the library that gets this right. Authentication is the
part that matters most here -- without it, ciphertext in a database somebody can
write to is ciphertext an attacker can tamper with.

**Key management.** The key comes from `SECRET_ENCRYPTION_KEY`, a
urlsafe-base64-encoded 32-byte value, generated with:

    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

Set it once and keep it; losing it means the stored secrets cannot be read and
every tenant has to reconnect their data sources. In `APP_MODE=production` a
missing key stops the platform from starting, because the alternative -- falling
back to something derived and predictable -- is how a credential store ends up
encrypted with a key that is in the source code.

Locally, and only when demo mode is on, the key is derived from `JWT_SECRET` so
the demo runs out of the box. That derived key is not a secret: `JWT_SECRET` has
a published default. Demo mode and production mode already refuse to be on at
the same time, so this cannot follow anyone into a real deployment.

**Rotation.** `SECRET_ENCRYPTION_KEY` may hold several keys separated by commas.
The first encrypts; all of them decrypt. So rotating is: put the new key first,
restart, and let `reencrypt` move rows over as they are next written.
"""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from typing import Any

from cryptography.fernet import Fernet, InvalidToken, MultiFernet

from app.core.config import settings
from app.core.errors import ConfigurationError
from app.core.logging import get_logger

logger = get_logger(__name__)

# Marks a stored value as ciphertext from this module, so a plaintext value left
# by an older row is recognisable rather than being fed to the decryptor.
PREFIX = "enc:v1:"


def _derived_demo_key() -> str:
    """A key derived from JWT_SECRET, for the demo only.

    Deliberately not a secret and deliberately not reachable from production:
    `_cipher` refuses to use it unless demo mode is on.
    """
    digest = hashlib.sha256(f"aiqe-secret-box::{settings.jwt_secret}".encode()).digest()
    return base64.urlsafe_b64encode(digest).decode()


def _configured_keys() -> list[str]:
    raw = (getattr(settings, "secret_encryption_key", "") or "").strip()
    return [key.strip() for key in raw.split(",") if key.strip()]


def _cipher() -> MultiFernet:
    keys = _configured_keys()
    if not keys:
        if settings.app_mode == "production" or not settings.demo_mode:
            raise ConfigurationError(
                "SECRET_ENCRYPTION_KEY is not set, so connected data source "
                "credentials cannot be encrypted. Generate one with: python -c "
                '"from cryptography.fernet import Fernet; '
                'print(Fernet.generate_key().decode())"'
            )
        keys = [_derived_demo_key()]

    try:
        return MultiFernet([Fernet(key.encode()) for key in keys])
    except (ValueError, TypeError) as error:
        raise ConfigurationError(
            "SECRET_ENCRYPTION_KEY is not a valid Fernet key (urlsafe base64, "
            f"32 bytes). Generate one with Fernet.generate_key(). ({error})"
        ) from None


def encrypt(plaintext: str) -> str:
    """Encrypt one string for storage."""
    return PREFIX + _cipher().encrypt(plaintext.encode()).decode()


def decrypt(stored: str) -> str:
    """Decrypt one stored string.

    Raises `ConfigurationError` on a value this key cannot read, which in
    practice means the key changed. That is worth an explicit error rather than
    a confusing downstream failure: the fix is to restore the old key or have
    the tenant reconnect.
    """
    if not is_encrypted(stored):
        raise ConfigurationError("This value is not encrypted; refusing to treat it as ciphertext.")
    try:
        return _cipher().decrypt(stored[len(PREFIX) :].encode()).decode()
    except InvalidToken:
        raise ConfigurationError(
            "A stored secret could not be decrypted with the configured "
            "SECRET_ENCRYPTION_KEY. If the key was rotated, list the previous "
            "key after the new one so existing rows stay readable."
        ) from None


def is_encrypted(value: object) -> bool:
    return isinstance(value, str) and value.startswith(PREFIX)


def encrypt_mapping(values: dict[str, Any]) -> str:
    """Encrypt a whole credential set as one blob.

    One blob rather than a column per field because which fields a data source
    needs varies by kind -- a DSN, or a user and password, or a token and a
    base URL -- and because a single ciphertext leaks nothing about how many
    fields there are or which ones are set.
    """
    return encrypt(json.dumps(values, separators=(",", ":"), sort_keys=True))


def decrypt_mapping(stored: str) -> dict[str, Any]:
    decoded = json.loads(decrypt(stored))
    if not isinstance(decoded, dict):
        raise ConfigurationError("A stored secret bundle did not decode to an object.")
    return decoded


@dataclass(frozen=True, slots=True)
class SecretBundle:
    """A decrypted credential set, with a `__repr__` that does not spill it.

    Every accident this guards against is the same one: a secret reaching a log
    line, an error message or an API response because something stringified the
    object holding it.
    """

    values: dict[str, Any]

    def get(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        return self.values.get(key, default)

    def __repr__(self) -> str:
        return f"SecretBundle({len(self.values)} value(s) redacted)"

    __str__ = __repr__

    def redacted(self) -> dict[str, str]:
        """What is safe to show: which fields are set, never what they hold."""
        return {key: "********" for key in sorted(self.values)}


def fingerprint(values: dict[str, Any]) -> str:
    """A short, stable digest so a screen can say "this is still the same key".

    Salted with the encryption key so the digest cannot be used to confirm a
    guessed credential by comparing hashes.
    """
    material = json.dumps(values, separators=(",", ":"), sort_keys=True)
    salt = (_configured_keys() or [_derived_demo_key()])[0]
    return hashlib.sha256(f"{salt}::{material}".encode()).hexdigest()[:12]
