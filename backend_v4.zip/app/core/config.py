"""Central application configuration.

Every deployment difference between the demo environment and a real enterprise
environment is expressed here as configuration -- never as branching inside
agents, flows or frontend code (see spec sections 21, 38, 39).
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Annotated, Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

BACKEND_ROOT = Path(__file__).resolve().parents[2]
REPO_ROOT = BACKEND_ROOT.parent

LLMProviderName = Literal["mock", "azure_openai", "openai", "bedrock"]


class Settings(BaseSettings):
    """Runtime settings loaded from environment / .env file."""

    model_config = SettingsConfigDict(
        env_file=(REPO_ROOT / ".env", BACKEND_ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
        # `KEY=` in .env.example means "not set". Without this it arrives as an
        # empty string: harmless for a string setting, but a SettingsError for
        # CHROMA_PORT, so a verbatim copy of the example file could not start.
        env_ignore_empty=True,
    )

    # ----- Application -------------------------------------------------------
    # The one switch that decides whether stand-ins are allowed.
    #   local      -- mocks permitted; missing credentials degrade with a warning
    #   production -- no stand-ins; a component that cannot run for real stops
    #                 the platform from starting. See app/core/mode.py.
    app_mode: Literal["local", "production"] = "local"
    app_env: Literal["development", "staging", "production", "test"] = "development"
    app_name: str = "AI QE Orchestrator"
    app_version: str = "1.0.0"
    api_prefix: str = "/api/v1"
    demo_mode: bool = True
    log_level: str = "INFO"
    log_json: bool = False

    # ----- Persistence -------------------------------------------------------
    # Defaults to a local SQLite file so the platform boots with zero external
    # services. docker-compose overrides this with the PostgreSQL DSN.
    database_url: str = Field(default=f"sqlite:///{(BACKEND_ROOT / 'data' / 'aiqe.db').as_posix()}")
    database_echo: bool = False
    redis_url: str | None = None

    # ----- Security ----------------------------------------------------------
    jwt_secret: str = "change-me-in-production-please-use-a-long-random-value"
    jwt_algorithm: str = "HS256"
    jwt_expiry_minutes: int = 60 * 12
    cors_origins: Annotated[list[str], NoDecode] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]
    rate_limit_per_minute: int = 600
    # Encrypts the credentials tenants give us for their own data sources.
    # Comma-separated to rotate: the first key encrypts, all of them decrypt.
    # Required in production; see app/core/crypto.py for how to generate one.
    secret_encryption_key: str = ""

    # ----- LLM providers -----------------------------------------------------
    default_llm_provider: LLMProviderName = "mock"
    llm_request_timeout_seconds: int = 60
    llm_max_retries: int = 2

    azure_openai_endpoint: str | None = None
    azure_openai_api_key: str | None = None
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_chat_deployment: str | None = None
    azure_openai_reasoning_deployment: str | None = None
    azure_openai_embedding_deployment: str | None = None

    openai_api_key: str | None = None
    openai_org_id: str | None = None
    openai_chat_model: str = "gpt-4o-mini"
    openai_reasoning_model: str = "gpt-4o"
    openai_embedding_model: str = "text-embedding-3-small"

    # AWS Bedrock. Deliberately no keys here: boto3 resolves credentials from
    # the standard AWS chain (environment, shared config, SSO, instance or task
    # role), so a deployment uses whatever its platform team already runs and no
    # AWS secret is ever stored in this application.
    bedrock_region: str | None = None
    bedrock_profile: str | None = None
    # For VPC endpoints or a gateway in front of Bedrock.
    bedrock_endpoint_url: str | None = None
    # Model ids are configuration because Bedrock ids are account- and
    # region-specific, and an inference profile ARN is valid here too.
    bedrock_chat_model: str | None = None
    bedrock_reasoning_model: str | None = None
    bedrock_embedding_model: str | None = None

    # ----- Vector store (Chroma is mandatory) --------------------------------
    chroma_host: str | None = None
    chroma_port: int | None = None
    chroma_tenant: str | None = None
    chroma_database: str | None = None
    chroma_persist_directory: str = str(BACKEND_ROOT / "data" / "chroma")
    embedding_dimensions: int = 384  # used by the deterministic demo embedder

    # ----- Execution ---------------------------------------------------------
    playwright_enabled: bool = False
    playwright_browser: Literal["chromium", "firefox", "webkit"] = "chromium"
    playwright_headless: bool = True
    playwright_timeout_ms: int = Field(default=8_000, ge=500, le=120_000)
    execution_artifacts_dir: str = str(BACKEND_ROOT / "data" / "artifacts")
    # Each project's own files live under their own directory here, so one
    # tenant's evidence is never interleaved with another's on disk and a whole
    # tenant can be exported or deleted as a unit. See app/core/storage.py.
    tenant_storage_dir: str = str(BACKEND_ROOT / "data" / "tenants")
    max_parallel_workers: int = 4

    # ----- Evidence ----------------------------------------------------------
    # What a real browser run captures when a test fails. Each costs disk, so a
    # deployment turns off what it does not review.
    capture_screenshot: bool = True
    capture_dom_snapshot: bool = True
    capture_accessibility_tree: bool = True
    capture_console_logs: bool = True
    capture_network_logs: bool = True
    capture_trace: bool = False
    # Evidence older than this is removed by the retention sweep. 0 keeps it all.
    artifact_retention_days: int = Field(default=30, ge=0, le=3650)

    # ----- Demo application under test ---------------------------------------
    # A small checkout served at /demo-app so healing can be demonstrated against
    # a real DOM. See app/demo_app/README.md.
    demo_app_enabled: bool = True
    demo_app_base_url: str = "http://127.0.0.1:8100/demo-app"
    # A pause between flow steps, in milliseconds. 0 in production; the demo
    # scripts set it so people can watch agents hand work to each other live.
    run_step_pause_ms: int = Field(default=0, ge=0, le=10_000)

    # Which runtime walks a stored flow. `langgraph` compiles it to a LangGraph
    # StateGraph; `native` is the original in-house worklist loop, kept as a
    # fallback and as the reference the LangGraph runtime is tested against.
    orchestration_engine: Literal["langgraph", "native"] = "langgraph"

    # ----- Self-healing ------------------------------------------------------
    # Healing is tuned here, never by editing an agent. `healing_change_policy`
    # and `healing_confidence_weights` merge over the defaults in
    # app/healing/config.py, so an override names only what it changes.
    healing_enabled: bool = True
    healing_auto_apply_threshold: float = Field(default=0.85, ge=0.0, le=1.0)
    healing_propose_threshold: float = Field(default=0.50, ge=0.0, le=1.0)
    healing_ambiguity_margin: float = Field(default=0.10, ge=0.0, le=1.0)
    # A heal is never recorded as successful without a re-run that proves it.
    # Turning this off is a deliberate, auditable downgrade.
    healing_require_validation: bool = True
    healing_validate_async: bool = False
    healing_max_attempts_per_test: int = Field(default=3, ge=1, le=20)
    healing_max_wait_ms: int = Field(default=15_000, ge=0, le=120_000)
    healing_max_retries: int = Field(default=2, ge=0, le=10)
    healing_confidence_weights: dict[str, float] = {}
    healing_change_policy: dict[str, str] = {}

    # ----- Governance / cost -------------------------------------------------
    default_project_cost_budget_usd: float = 50.0
    default_flow_cost_budget_usd: float = 5.0
    default_agent_token_budget: int = 40_000
    approval_required_risk_levels: Annotated[list[str], NoDecode] = ["high", "critical"]

    # ----- Flow triggers -----------------------------------------------------
    # Scheduled flows are started by an in-process scheduler; turn it off when
    # an external scheduler (or a second replica) owns scheduling.
    scheduler_enabled: bool = True
    scheduler_interval_seconds: int = 30

    # ----- Web app -----------------------------------------------------------
    # When the production build exists the API also serves the web app, so a
    # demo is one process on one URL. The Vite dev server is unaffected.
    serve_frontend: bool = True
    frontend_dist_dir: str = str(REPO_ROOT / "frontend" / "dist")

    # ----- Seeding -----------------------------------------------------------
    auto_seed_on_startup: bool = True
    seed_random_state: int = 20240917

    @field_validator("cors_origins", "approval_required_risk_levels", mode="before")
    @classmethod
    def _split_csv(cls, value: object) -> object:
        """Accept `A,B,C` or a JSON array for list-typed settings.

        These fields are marked `NoDecode`, so pydantic-settings hands over the
        raw string. Without that, it JSON-decodes a list field *before* any
        validator runs: a comma-separated value -- the format `.env.example`
        ships -- raised a SettingsError while the settings were being built,
        this validator never saw it, and the app could not start from a
        verbatim copy of its own example file.
        """
        if isinstance(value, str):
            stripped = value.strip()
            if stripped.startswith("["):
                return json.loads(stripped)
            return [item.strip() for item in stripped.split(",") if item.strip()]
        return value

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def chroma_server_mode(self) -> bool:
        return bool(self.chroma_host and self.chroma_port)

    def ensure_directories(self) -> None:
        """Create the local data directories the platform writes to."""
        for path in (
            Path(self.chroma_persist_directory),
            Path(self.execution_artifacts_dir),
            Path(self.tenant_storage_dir),
            BACKEND_ROOT / "data",
        ):
            path.mkdir(parents=True, exist_ok=True)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings()
    settings.ensure_directories()
    return settings


settings = get_settings()
