"""Background job execution (spec section 34 "Event-driven execution").

Long-running work -- flow runs, test executions, knowledge indexing -- is
dispatched here rather than blocking the HTTP request. The queue is an
abstraction: the in-process thread pool keeps the demo dependency-free, and a
Redis-backed queue can be substituted for a multi-node deployment without any
caller changes.
"""

from __future__ import annotations

import threading
import time
import traceback
import uuid
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from concurrent.futures import wait as concurrent_wait
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Protocol

from app.core.config import settings
from app.core.logging import get_logger, set_correlation_id

logger = get_logger(__name__)


@dataclass
class JobRecord:
    job_id: str
    name: str
    status: str = "queued"  # queued | running | succeeded | failed | cancelled
    submitted_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    finished_at: datetime | None = None
    error: str | None = None
    correlation_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "name": self.name,
            "status": self.status,
            "submitted_at": self.submitted_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "error": self.error,
            "correlation_id": self.correlation_id,
            "metadata": self.metadata,
        }


class JobQueue(Protocol):
    """Contract every queue backend must satisfy."""

    def submit(self, name: str, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> JobRecord: ...

    def get(self, job_id: str) -> JobRecord | None: ...

    def cancel(self, job_id: str) -> bool: ...

    def list_jobs(self, limit: int = 50) -> list[JobRecord]: ...

    def shutdown(self) -> None: ...


class ThreadPoolJobQueue:
    """Default in-process queue backed by a bounded thread pool.

    Cancellation is cooperative: a token is exposed through `is_cancelled` so
    long-running orchestration loops can stop at a step boundary and leave the
    run in a consistent state (spec section 29).
    """

    def __init__(self, max_workers: int | None = None) -> None:
        self._max_workers = max_workers or settings.max_parallel_workers
        self._executor = self._new_executor()
        self._jobs: dict[str, JobRecord] = {}
        self._futures: dict[str, Future] = {}
        self._cancelled: set[str] = set()
        self._dead_letter: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._is_shut_down = False

    def _new_executor(self) -> ThreadPoolExecutor:
        return ThreadPoolExecutor(max_workers=self._max_workers, thread_name_prefix="aiqe-worker")

    def submit(self, name: str, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> JobRecord:
        # Callers may pre-allocate the id so they can persist it before the job
        # starts, closing the race between dispatch and cancellation.
        job_id = kwargs.pop("job_id", None) or str(uuid.uuid4())
        correlation_id = kwargs.pop("correlation_id", None) or job_id
        metadata = kwargs.pop("job_metadata", {}) or {}
        record = JobRecord(job_id=job_id, name=name, correlation_id=correlation_id, metadata=metadata)

        with self._lock:
            self._jobs[job_id] = record

        def _runner() -> Any:
            set_correlation_id(correlation_id)
            with self._lock:
                if job_id in self._cancelled:
                    record.status = "cancelled"
                    record.finished_at = datetime.now(UTC)
                    return None
                record.status = "running"
                record.started_at = datetime.now(UTC)
            logger.info("job_started", job=name, job_id=job_id)
            try:
                result = fn(*args, **kwargs)
                with self._lock:
                    record.status = "cancelled" if job_id in self._cancelled else "succeeded"
                    record.finished_at = datetime.now(UTC)
                logger.info("job_finished", job=name, job_id=job_id, status=record.status)
                return result
            except Exception as exc:  # noqa: BLE001 - queue boundary must not raise
                with self._lock:
                    record.status = "failed"
                    record.error = str(exc)
                    record.finished_at = datetime.now(UTC)
                    self._dead_letter.append(
                        {
                            "job": record.to_dict(),
                            "traceback": traceback.format_exc(limit=12),
                        }
                    )
                logger.exception("job_failed", job=name, job_id=job_id, error=str(exc))
                return None
            finally:
                set_correlation_id(None)

        with self._lock:
            # An app started again in the same process (tests, reloads) gets a fresh pool.
            if self._is_shut_down:
                self._executor = self._new_executor()
                self._is_shut_down = False
            executor = self._executor
        self._futures[job_id] = executor.submit(_runner)
        return record

    def get(self, job_id: str) -> JobRecord | None:
        with self._lock:
            return self._jobs.get(job_id)

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            record = self._jobs.get(job_id)
            if record is None or record.status in {"succeeded", "failed", "cancelled"}:
                return False
            self._cancelled.add(job_id)
        future = self._futures.get(job_id)
        if future is not None:
            future.cancel()
        return True

    def is_cancelled(self, job_id: str) -> bool:
        with self._lock:
            return job_id in self._cancelled

    def list_jobs(self, limit: int = 50) -> list[JobRecord]:
        with self._lock:
            jobs = sorted(self._jobs.values(), key=lambda job: job.submitted_at, reverse=True)
        return jobs[:limit]

    def dead_letters(self, limit: int = 25) -> list[dict[str, Any]]:
        with self._lock:
            return self._dead_letter[-limit:]

    def wait_for_idle(self, timeout: float = 30.0) -> bool:
        """Block until nothing is running, or the timeout passes.

        Returns whether the queue actually drained. Used when something else
        needs the jobs' side effects to have landed -- a graceful shutdown, and
        the tests, where a job still writing to the database while the next test
        starts shows up as an unrelated failure somewhere else.
        """
        deadline = time.monotonic() + timeout
        while True:
            with self._lock:
                pending = [future for future in self._futures.values() if not future.done()]
            if not pending:
                return True
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            concurrent_wait(pending, timeout=remaining)

    def shutdown(self) -> None:
        with self._lock:
            self._is_shut_down = True
            executor = self._executor
        executor.shutdown(wait=False, cancel_futures=True)


job_queue = ThreadPoolJobQueue()


class CancellationToken:
    """Passed into orchestration loops so they can honour a cancel request."""

    def __init__(self, job_id: str | None = None) -> None:
        self.job_id = job_id
        self._flag = threading.Event()

    def cancel(self) -> None:
        self._flag.set()

    @property
    def is_cancelled(self) -> bool:
        if self._flag.is_set():
            return True
        if self.job_id and job_queue.is_cancelled(self.job_id):
            return True
        return False
