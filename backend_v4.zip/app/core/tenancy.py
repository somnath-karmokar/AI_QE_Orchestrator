"""Which projects a caller may touch.

A project is the tenant boundary: its requirements, runs, evidence, knowledge and
connected data sources belong to its members and to nobody else. Roles are
separate and still apply -- a role says what someone may *do* anywhere on the
platform, membership says which projects they may do it *in*, and both have to
allow an action for it to happen.

Everything that reads project-scoped data goes through `assert_project_access`
or `accessible_project_ids`, so there is one answer to "may this caller see
this?" rather than one per endpoint. Before these existed, any authenticated
user could list every project and read any run by id.

Platform administration is the one exception: a role holding
`project:access_all` reaches every project, so somebody can still run the
platform. The seeded `admin` role holds `*`, which includes it -- worth knowing,
because it means a platform administrator can read every tenant's data. Narrow
that role, or drop `project:access_all` from it, if an operator should not.
"""

from __future__ import annotations

from sqlalchemy import false, or_, select
from sqlalchemy.orm import Session

from app.core.errors import NotFoundError
from app.core.security import Principal

# Reaches every project. Held by the platform administrator role.
ACCESS_ALL = "project:access_all"


def reaches_every_project(principal: Principal) -> bool:
    return principal.has_permission(ACCESS_ALL)


def accessible_project_ids(session: Session, principal: Principal) -> set[str] | None:
    """The projects this caller may see, or None meaning "every project".

    None rather than a set of everything, so a caller that reaches all of them
    does not pay for a membership query on every request, and so a query can
    skip the filter entirely instead of building a huge `IN` clause.
    """
    if reaches_every_project(principal):
        return None

    from app.models.identity import ProjectMember  # noqa: PLC0415

    return set(
        session.execute(
            select(ProjectMember.project_id).where(ProjectMember.user_id == principal.user_id)
        )
        .scalars()
        .all()
    )


def may_access_project(session: Session, principal: Principal, project_id: str | None) -> bool:
    if project_id is None:
        return True  # not project-scoped data
    allowed = accessible_project_ids(session, principal)
    return allowed is None or project_id in allowed


def assert_project_access(session: Session, principal: Principal, project_id: str | None) -> None:
    """Refuse a caller who is not a member, saying only that it was not found.

    Deliberately a 404 and not a 403: telling somebody "this exists but is not
    yours" confirms another tenant's project or run exists, and its id. A caller
    outside the boundary should not be able to tell the two apart.
    """
    if may_access_project(session, principal, project_id):
        return
    raise NotFoundError("No such resource is available.")


def get_owned(  # noqa: ANN201
    session: Session,
    principal: Principal,
    model,  # noqa: ANN001
    object_id: str,
    *,
    label: str,
    soft_deleted_is_missing: bool = True,
):
    """Load one project-scoped row the caller is entitled to, or raise 404.

    Nearly every by-id endpoint was the same three lines -- fetch, 404 if
    missing, return -- and the tenant check is a fourth that is easy to leave
    out one route at a time. Routes call this instead, so forgetting it means
    not calling a function rather than omitting a line inside one.

    The row must carry `project_id`; a row whose `project_id` is None is shared
    platform data and is readable by anyone who got past the permission check.
    """
    row = session.get(model, object_id)
    missing = row is None or (
        soft_deleted_is_missing and getattr(row, "is_deleted", False)
    )
    if missing:
        raise NotFoundError(f"{label} '{object_id}' was not found.")
    assert_project_access(session, principal, getattr(row, "project_id", None))
    return row


def scope_to_accessible(  # noqa: ANN201
    statement,  # noqa: ANN001
    column,  # noqa: ANN001
    session: Session,
    principal: Principal,
    *,
    include_shared: bool = False,
):
    """Narrow a select to the projects this caller may see.

    `column` is the model's project column, e.g. `AgentRun.project_id`. Set
    `include_shared` where a NULL in that column means platform-wide data that
    belongs to no tenant -- a built-in agent, a default policy -- rather than an
    orphan. Leave it off otherwise: on a table whose rows always have an owner,
    matching NULL would only ever let an unowned row escape the filter.
    """
    allowed = accessible_project_ids(session, principal)
    if allowed is None:
        return statement
    if not allowed:
        # A caller who is a member of nothing sees only shared rows, rather than
        # everything, which is what an empty `IN ()` would risk.
        return statement.where(column.is_(None)) if include_shared else statement.where(false())
    if include_shared:
        return statement.where(or_(column.in_(allowed), column.is_(None)))
    return statement.where(column.in_(allowed))
