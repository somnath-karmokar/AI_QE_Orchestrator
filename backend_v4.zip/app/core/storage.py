"""Where each tenant's files live.

Evidence from a run -- screenshots, DOM snapshots, traces, network logs -- can
contain anything that was on the page: order numbers, names, account details.
All of it used to be written into one shared `data/artifacts` directory keyed
only by execution id. Nothing there said which tenant a file belonged to, so
separation depended entirely on every reader remembering to check, and a
mistake in one path handler exposed every customer at once.

Here each project gets its own directory tree:

    data/tenants/<project_id>/executions/<execution_id>/...
    data/tenants/<project_id>/uploads/...

That buys three things beyond tidiness. A path itself now says who owns the
file, so `owning_project` can answer "may this caller read this?" from the path
alone. A tenant's data can be exported or destroyed by removing one directory,
which is what a deletion request actually asks for. And a per-tenant directory
can be a separate mount, volume or bucket prefix when a customer requires their
data on their own storage.

Every path this module returns is verified to be inside the tenant's own root,
so a crafted id or filename cannot walk out of it with `..`.
"""

from __future__ import annotations

import re
from pathlib import Path

from app.core.config import settings
from app.core.errors import ValidationError

# Ids are UUIDs and names are slugs. Anything else is refused rather than
# sanitised: quietly rewriting a caller's path is how a traversal check gets
# bypassed by a value that survives the rewrite.
_SAFE_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")


def _segment(value: str, *, label: str) -> str:
    if not isinstance(value, str) or not _SAFE_SEGMENT.match(value) or ".." in value:
        raise ValidationError(f"'{label}' is not a usable storage path segment.")
    return value


def tenant_root(project_id: str) -> Path:
    """The directory that holds everything belonging to one project."""
    root = Path(settings.tenant_storage_dir).resolve() / _segment(project_id, label="project_id")
    root.mkdir(parents=True, exist_ok=True)
    return root


def execution_dir(project_id: str, execution_id: str) -> Path:
    """Where one execution's evidence is written."""
    path = tenant_root(project_id) / "executions" / _segment(execution_id, label="execution_id")
    path.mkdir(parents=True, exist_ok=True)
    return path


def artifact_path(project_id: str, execution_id: str, filename: str) -> Path:
    """One evidence file, guaranteed to sit inside its own tenant's directory."""
    return resolve_within(
        execution_dir(project_id, execution_id), _segment(filename, label="filename")
    )


def resolve_within(base: Path, *parts: str) -> Path:
    """Join and then *prove* the result is still under `base`.

    The check is on the resolved path rather than the input string, so it holds
    for `..`, for an absolute path, and for a symlink pointing outward -- the
    three ways a join escapes its directory.
    """
    base = base.resolve()
    candidate = base.joinpath(*parts)
    resolved = candidate.resolve() if candidate.exists() else Path(candidate.absolute())
    try:
        resolved.relative_to(base)
    except ValueError:
        raise ValidationError("That path is outside the tenant's storage directory.") from None
    return resolved


def owning_project(path: str | Path) -> str | None:
    """Which project a stored file belongs to, read from the path itself.

    Returns None for a path outside tenant storage -- an artifact written before
    this existed, for instance -- so a caller can tell "belongs to someone else"
    apart from "cannot tell", and refuse in both cases if it chooses to.
    """
    try:
        candidate = Path(path).resolve()
        relative = candidate.relative_to(Path(settings.tenant_storage_dir).resolve())
    except (ValueError, OSError):
        return None
    return relative.parts[0] if relative.parts else None


def tenant_relative_path(project_id: str, stored: str | None) -> str | None:
    """A stored path expressed relative to the tenant's own root, for display.

    Falls back to the bare filename for a path written before tenant storage
    existed, rather than handing out an absolute server path: what a caller
    needs is which file it is, not where this deployment keeps it.
    """
    if not stored:
        return stored
    candidate = Path(stored)
    try:
        return candidate.relative_to(tenant_root(project_id)).as_posix()
    except (ValueError, OSError):
        return candidate.name


def usage_bytes(project_id: str) -> int:
    """How much disk one tenant is using, for quotas and for the storage card."""
    root = tenant_root(project_id)
    return sum(item.stat().st_size for item in root.rglob("*") if item.is_file())


def purge_tenant(project_id: str) -> int:
    """Delete everything stored for one project. Returns the files removed.

    This is the operation a customer means by "delete our data", and it is only
    honest because the data was kept in one place to begin with.
    """
    import shutil  # noqa: PLC0415

    root = tenant_root(project_id)
    count = sum(1 for item in root.rglob("*") if item.is_file())
    shutil.rmtree(root, ignore_errors=True)
    return count
