"""Local mode and production mode.

The platform is designed to run with nothing installed: no AI credentials, no
Chroma, no browser, no Jira. Every component has a working stand-in, and when
something is missing it degrades to that stand-in and logs a warning. That is
exactly right for a demo and exactly wrong for production, where a warning in a
log nobody reads is how a customer ends up shown simulated test results as
though a browser had run them.

`APP_MODE` decides which of those two the deployment is:

* **local** — stand-ins allowed. Missing credentials degrade with a warning.
* **production** — stand-ins forbidden. A component that cannot run for real
  **stops the platform from starting**, with a message naming what to set.

The check is deliberately at startup rather than at first use. A platform that
boots and then fails on the first customer request has already accepted the
work; one that refuses to boot is a deployment failure somebody sees.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# The default JWT secret shipped for the demo. Running production on it would
# let anyone who has read the repository mint a valid session.
_DEMO_JWT_SECRET = "change-me-in-production-please-use-a-long-random-value"


class Mode(str, Enum):
    LOCAL = "local"
    PRODUCTION = "production"


def current_mode() -> Mode:
    return Mode.PRODUCTION if settings.app_mode == "production" else Mode.LOCAL


def is_production() -> bool:
    return current_mode() is Mode.PRODUCTION


class ModeViolation(RuntimeError):
    """Raised when production mode is asked to use a stand-in."""


@dataclass(slots=True)
class Check:
    """One component, and whether it can do the real thing."""

    component: str
    ready: bool
    detail: str
    # What to set to fix it. Never a secret value, only the name.
    remedy: str | None = None
    # False for components a deployment may legitimately not use.
    blocking: bool = True

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "component": self.component,
            "ready": self.ready,
            "detail": self.detail,
            "blocking": self.blocking,
        }
        if self.remedy and not self.ready:
            payload["remedy"] = self.remedy
        return payload


@dataclass(slots=True)
class Readiness:
    mode: str
    checks: list[Check] = field(default_factory=list)

    @property
    def blocking_failures(self) -> list[Check]:
        return [check for check in self.checks if check.blocking and not check.ready]

    @property
    def warnings(self) -> list[Check]:
        return [check for check in self.checks if not check.blocking and not check.ready]

    @property
    def ready(self) -> bool:
        return not self.blocking_failures

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "ready": self.ready,
            "checks": [check.to_dict() for check in self.checks],
            "blocking_failures": [check.component for check in self.blocking_failures],
            "warnings": [check.component for check in self.warnings],
        }


# ---------------------------------------------------------------------------
# The checks
# ---------------------------------------------------------------------------


def _check_llm() -> Check:
    """The provider must be a real one, and actually configured.

    `get_provider` falls back to mock when a provider is unconfigured, so
    checking the setting alone would pass a deployment that then quietly ran on
    the demo model.
    """
    from app.ai.providers.registry import _PROVIDER_CLASSES  # noqa: PLC0415

    provider_key = settings.default_llm_provider
    if provider_key == "mock":
        return Check(
            component="llm_provider",
            ready=False,
            detail="The deterministic mock provider is selected; no real model would be called.",
            remedy="Set DEFAULT_LLM_PROVIDER to bedrock, azure_openai or openai.",
        )

    provider_class = _PROVIDER_CLASSES.get(provider_key)
    if provider_class is None:
        return Check(
            component="llm_provider",
            ready=False,
            detail=f"'{provider_key}' is not a provider this platform implements.",
            remedy="Set DEFAULT_LLM_PROVIDER to bedrock, azure_openai or openai.",
        )

    instance = provider_class()
    if not instance.is_configured():
        health = instance.health_check()
        return Check(
            component="llm_provider",
            ready=False,
            detail=(
                f"{instance.display_name} is selected but not configured, so every call "
                f"would fall back to the mock model. {health.get('detail', '')}".strip()
            ),
            remedy=f"Configure {instance.display_name}; see docs/llm-providers.md.",
        )

    return Check(
        component="llm_provider",
        ready=True,
        detail=f"{instance.display_name} is configured.",
    )


def _check_vector_store() -> Check:
    """Chroma must be reachable, or retrieval silently stops persisting."""
    from app.vectorstore.chroma.store import ChromaVectorStore  # noqa: PLC0415

    try:
        store = ChromaVectorStore()
        store.bootstrap()
    except Exception as error:  # noqa: BLE001
        return Check(
            component="vector_store",
            ready=False,
            detail=(
                f"Chroma is not reachable, so retrieval would fall back to a non-persistent "
                f"in-memory store: {str(error)[:160]}"
            ),
            remedy="Set CHROMA_HOST and CHROMA_PORT, or make the persist directory writable.",
        )
    if settings.chroma_host:
        # The advisories open against chromadb's server API have no fixed
        # release. Embedded mode is not affected -- there is no server to
        # reach -- but a deployment that runs one must keep it off any network
        # this platform does not own.
        return Check(
            component="vector_store",
            ready=True,
            detail=(
                f"Chroma server at {settings.chroma_host} is reachable. It must not be "
                "reachable from anywhere else: open advisories against the Chroma server "
                "API have no fixed release. See docs/security.md."
            ),
            blocking=False,
        )
    return Check(component="vector_store", ready=True, detail="Chroma is reachable (embedded).")


def _check_execution() -> Check:
    """Simulated execution in production would report tests that never ran.

    This is the one most worth refusing. A pass rate derived from a model of the
    application, presented next to real ones, is indistinguishable from evidence.
    """
    if not settings.playwright_enabled:
        return Check(
            component="test_execution",
            ready=False,
            detail=(
                "Playwright is disabled, so executions would be simulated from test history "
                "and reported as results."
            ),
            remedy="Set PLAYWRIGHT_ENABLED=true and run 'playwright install'.",
        )
    return Check(component="test_execution", ready=True, detail="Real browser execution is enabled.")


def _check_demo_surfaces() -> list[Check]:
    """Demo-only conveniences that must not be reachable in production."""
    checks: list[Check] = []

    if settings.demo_mode:
        checks.append(
            Check(
                component="demo_mode",
                ready=False,
                detail=(
                    "Demo mode exposes the seeded sign-in accounts at /auth/demo-users."
                ),
                remedy="Set DEMO_MODE=false.",
            )
        )
    else:
        checks.append(Check(component="demo_mode", ready=True, detail="Demo mode is off."))

    if settings.auto_seed_on_startup:
        checks.append(
            Check(
                component="auto_seed",
                ready=False,
                detail="Startup would load the synthetic demo project into this database.",
                remedy="Set AUTO_SEED_ON_STARTUP=false.",
            )
        )
    else:
        checks.append(Check(component="auto_seed", ready=True, detail="Auto-seeding is off."))

    if settings.jwt_secret == _DEMO_JWT_SECRET:
        checks.append(
            Check(
                component="jwt_secret",
                ready=False,
                detail=(
                    "The shipped demo signing secret is in use; anyone who has read the "
                    "repository could mint a valid session."
                ),
                remedy="Set JWT_SECRET to a long random value.",
            )
        )
    else:
        checks.append(Check(component="jwt_secret", ready=True, detail="A custom signing secret is set."))

    # Without this, the credentials tenants give us for their own systems are
    # encrypted with a key derived from JWT_SECRET, whose default is published.
    # The failure is silent -- everything works -- which is why it is checked
    # here rather than left to be noticed.
    if not (settings.secret_encryption_key or "").strip():
        checks.append(
            Check(
                component="secret_encryption_key",
                ready=False,
                detail=(
                    "No encryption key is set, so connected data source credentials would "
                    "be encrypted with a key derived from JWT_SECRET rather than one of "
                    "your own."
                ),
                remedy=(
                    "Set SECRET_ENCRYPTION_KEY. Generate one with: python -c "
                    '"from cryptography.fernet import Fernet; '
                    'print(Fernet.generate_key().decode())"'
                ),
            )
        )
    else:
        checks.append(
            Check(
                component="secret_encryption_key",
                ready=True,
                detail="Tenant credentials are encrypted with a configured key.",
            )
        )

    return checks


def _check_mcp(session: Any = None) -> Check:  # noqa: ANN401
    """Enabled MCP servers must be live connectors, not demo adapters.

    Only *enabled* ones: a deployment that has not connected Jira is not
    misconfigured, it simply does not use Jira. One that has enabled Jira and
    left it on the demo adapter would be returning invented tickets.
    """
    if session is None:
        return Check(
            component="mcp_connectors",
            ready=True,
            detail="Not checked without a database session.",
            blocking=False,
        )

    from sqlalchemy import select  # noqa: PLC0415

    from app.models.project import MCPServer  # noqa: PLC0415

    try:
        rows = list(
            session.execute(select(MCPServer).where(MCPServer.is_enabled.is_(True))).scalars().all()
        )
    except Exception as error:  # noqa: BLE001 - before migrations, there is no table
        return Check(
            component="mcp_connectors",
            ready=False,
            detail=f"Could not read the MCP server configuration: {str(error)[:120]}",
            remedy="Run migrations before starting in production.",
            blocking=False,
        )
    # A server can have both a global and a project-scoped row; report the key
    # once rather than once per row.
    demo_servers = sorted({row.key for row in rows if (row.connector_mode or "demo") == "demo"})
    enabled_keys = {row.key for row in rows}

    if demo_servers:
        return Check(
            component="mcp_connectors",
            ready=False,
            detail=(
                "These enabled MCP servers are on the demo connector and would return "
                f"invented data: {', '.join(demo_servers)}."
            ),
            remedy="Set each server's connector mode to live, or disable the server.",
        )
    return Check(
        component="mcp_connectors",
        ready=True,
        detail=f"{len(enabled_keys)} enabled server(s), all on live connectors."
        if enabled_keys
        else "No MCP servers are enabled.",
    )


def _check_cors() -> Check:
    """A wildcard origin with credentials is a browser-trust hole.

    Starlette does not simply send `Access-Control-Allow-Origin: *` when
    credentials are allowed -- it echoes back whichever origin asked, with
    `Allow-Credentials: true`. So `CORS_ORIGINS=*`, the usual deployment
    shortcut when something is blocked, turns every site on the internet into
    a trusted origin for this API.
    """
    origins = list(settings.cors_origins or [])
    if "*" in origins:
        return Check(
            component="cors",
            ready=False,
            detail=(
                "CORS_ORIGINS is '*' while credentials are allowed, so any site a "
                "signed-in user visits could call this API as them."
            ),
            remedy="Set CORS_ORIGINS to the exact origins that serve the UI.",
        )

    insecure = [origin for origin in origins if origin.startswith("http://")]
    if insecure:
        return Check(
            component="cors",
            ready=False,
            detail=f"These allowed origins are not HTTPS: {', '.join(insecure)}.",
            remedy="Use https:// origins in production, or remove them.",
        )

    return Check(
        component="cors",
        ready=True,
        detail=f"{len(origins)} explicit origin(s) allowed." if origins else "No cross-origin access.",
    )


# Environment variables that switch on LangSmith tracing (current and legacy names).
_TRACING_FLAGS = ("LANGSMITH_TRACING", "LANGCHAIN_TRACING_V2", "LANGSMITH_TRACING_V2", "LANGCHAIN_TRACING")


def _check_orchestration() -> Check:
    """Which runtime executes flows. Informational: either is production-capable."""
    engine = settings.orchestration_engine
    if engine == "langgraph":
        try:
            from importlib.metadata import version  # noqa: PLC0415

            detail = f"Flows run on LangGraph {version('langgraph')}."
        except Exception:  # noqa: BLE001 - the package metadata is only for the message
            detail = "Flows run on LangGraph."
    else:
        detail = "Flows run on the native in-house engine."
    return Check(component="orchestration", ready=True, detail=detail, blocking=False)


def _check_tracing() -> Check:
    """LangGraph can ship every run's state to LangSmith's cloud.

    That state is this platform's run variables -- inputs a caller supplied and
    what agents produced from them. It must not leave the deployment by
    accident, and setting one environment variable is all it would take.
    """
    if settings.orchestration_engine != "langgraph":
        return Check(component="tracing", ready=True, detail="No LangChain tracing applies to the native engine.")

    enabled = [
        name for name in _TRACING_FLAGS if os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}
    ]
    if enabled:
        return Check(
            component="tracing",
            ready=False,
            detail=(
                f"LangSmith tracing is switched on ({', '.join(enabled)}), so each run's variables "
                "would be sent to LangSmith's servers."
            ),
            remedy="Unset " + ", ".join(enabled) + " (or set it to false).",
        )
    return Check(component="tracing", ready=True, detail="LangSmith tracing is off; no run data leaves the deployment.")


def _check_database() -> Check:
    """SQLite is right for a demo and wrong for a production deployment."""
    if settings.is_sqlite:
        return Check(
            component="database",
            ready=False,
            detail="SQLite is single-writer and file-local; it will not survive a real workload.",
            remedy="Set DATABASE_URL to a PostgreSQL DSN.",
            blocking=False,
        )
    return Check(component="database", ready=True, detail="A server database is configured.")


# ---------------------------------------------------------------------------


def readiness(session: Any = None) -> Readiness:  # noqa: ANN401
    """Every component, and whether it can do the real thing.

    Safe to call in either mode: in local mode this is a report, and in
    production it is what the startup gate reads.
    """
    report = Readiness(mode=current_mode().value)
    report.checks.append(_check_llm())
    report.checks.append(_check_vector_store())
    report.checks.append(_check_execution())
    report.checks.extend(_check_demo_surfaces())
    report.checks.append(_check_mcp(session))
    report.checks.append(_check_cors())
    report.checks.append(_check_orchestration())
    report.checks.append(_check_tracing())
    report.checks.append(_check_database())
    return report


def enforce_production_readiness(session: Any = None) -> Readiness:  # noqa: ANN401
    """In production, refuse to start rather than run on stand-ins.

    Local mode returns the same report and changes nothing, so the check is
    worth running either way -- a developer sees what production would object to
    before they deploy.
    """
    report = readiness(session)

    if not is_production():
        degraded = [check.component for check in report.checks if not check.ready]
        logger.info(
            "mode_local",
            using_stand_ins=degraded,
            note="Set APP_MODE=production to forbid these.",
        )
        return report

    for check in report.warnings:
        logger.warning("production_warning", component=check.component, detail=check.detail)

    failures = report.blocking_failures
    if failures:
        lines = "\n".join(
            f"  - {check.component}: {check.detail}"
            + (f"\n      Fix: {check.remedy}" if check.remedy else "")
            for check in failures
        )
        logger.error(
            "production_readiness_failed",
            components=[check.component for check in failures],
        )
        raise ModeViolation(
            "APP_MODE=production, but these components would fall back to a stand-in:\n"
            f"{lines}\n\n"
            "Production mode refuses to start rather than serve simulated results as real "
            "ones. Fix the above, or use APP_MODE=local."
        )

    logger.info("mode_production", note="All components verified; no stand-ins in use.")
    return report


def forbid_stand_in(component: str, detail: str, remedy: str) -> None:
    """Refuse a runtime fallback in production.

    Called from the few places that degrade on demand rather than at startup.
    Startup catches nearly everything; this catches the case where a component
    was reachable at boot and is not any more.
    """
    if not is_production():
        return
    raise ModeViolation(
        f"APP_MODE=production forbids falling back to a stand-in for {component}. "
        f"{detail} Fix: {remedy}"
    )
