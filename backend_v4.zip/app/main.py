"""FastAPI application entry point."""

from __future__ import annotations

import asyncio
import mimetypes
import time
import uuid
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.api.v1 import api_router
from app.core.config import settings
from app.core.errors import register_exception_handlers
from app.core.events import event_bus
from app.core.database import session_scope
from app.core.logging import configure_logging, get_logger, set_correlation_id
from app.core.mode import enforce_production_readiness, is_production, readiness
from app.core.worker import job_queue

configure_logging(settings.log_level, settings.log_json)
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ANN201
    # Worker threads publish run events; the bus needs the loop to hand them over.
    event_bus.bind_loop(asyncio.get_running_loop())
    logger.info(
        "startup",
        app=settings.app_name,
        version=settings.app_version,
        environment=settings.app_env,
        demo_mode=settings.demo_mode,
        provider=settings.default_llm_provider,
    )

    # In production this raises and the platform does not start. A deployment
    # failure somebody sees beats a warning in a log nobody reads, and beats
    # serving simulated results as though they were real.
    with session_scope() as session:
        enforce_production_readiness(session)

    if settings.auto_seed_on_startup:
        from app.seed.runner import create_schema, seed_all  # noqa: PLC0415

        create_schema()
        # Seeding embeds the whole corpus, so keep it off the event loop.
        await asyncio.to_thread(seed_all)

    try:
        from app.vectorstore.factory import get_vector_store  # noqa: PLC0415

        health = get_vector_store().health()
        logger.info("vector_store", provider=health.get("provider"), status=health.get("status"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("vector_store_unavailable", error=str(exc)[:200])

    scheduler = None
    if settings.scheduler_enabled:
        from app.services.flow_triggers import flow_scheduler  # noqa: PLC0415

        scheduler = flow_scheduler
        scheduler.start()

    yield

    logger.info("shutdown")
    if scheduler is not None:
        scheduler.stop()
    job_queue.shutdown()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Intelligent agents. Governed orchestration. Continuous quality.\n\n"
        "A reusable agentic QE operating platform: discover agents, compose them into governed "
        "workflows, execute quality engineering activities and learn from execution history."
    ),
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Correlation-ID"],
)


@app.middleware("http")
async def correlation_and_timing(request: Request, call_next):  # noqa: ANN001, ANN201
    """Attach a correlation id and record request duration (spec §31)."""
    correlation_id = request.headers.get("X-Correlation-ID") or str(uuid.uuid4())
    request.state.correlation_id = correlation_id
    set_correlation_id(correlation_id)

    started = time.perf_counter()
    try:
        response = await call_next(request)
    finally:
        set_correlation_id(None)

    duration_ms = int((time.perf_counter() - started) * 1000)
    response.headers["X-Correlation-ID"] = correlation_id
    response.headers["X-Response-Time-ms"] = str(duration_ms)

    if duration_ms > 3000:
        logger.warning("slow_request", path=request.url.path, duration_ms=duration_ms)
    return response


# Simple fixed-window rate limiter. A shared store (Redis) would replace this
# in a multi-node deployment; the hook and headers stay identical.
_rate_buckets: dict[str, deque[float]] = defaultdict(deque)


@app.middleware("http")
async def rate_limit(request: Request, call_next):  # noqa: ANN001, ANN201
    if request.url.path.startswith("/api") and request.method != "OPTIONS":
        client = request.client.host if request.client else "unknown"
        now = time.time()
        bucket = _rate_buckets[client]
        while bucket and now - bucket[0] > 60:
            bucket.popleft()
        if len(bucket) >= settings.rate_limit_per_minute:
            return JSONResponse(
                status_code=429,
                content={
                    "error": {
                        "code": "rate_limited",
                        "message": "Too many requests. Try again shortly.",
                        "details": {"limit_per_minute": settings.rate_limit_per_minute},
                    }
                },
            )
        bucket.append(now)
    return await call_next(request)


@app.middleware("http")
async def security_headers(request: Request, call_next):  # noqa: ANN001, ANN201
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    if is_production():
        # Only in production: sending HSTS from a local http:// dev server
        # would pin the browser to https for localhost and break the next
        # developer who ran anything else on that port.
        response.headers.setdefault(
            "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
        )
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    # The copilot's voice input needs the microphone on this origin, and only this one.
    response.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(self), camera=()")
    return response


register_exception_handlers(app)
app.include_router(api_router, prefix=settings.api_prefix)


@app.get("/health", tags=["System"], summary="Liveness probe")
def health() -> dict:
    return {
        "status": "ok",
        "version": settings.app_version,
        "mode": settings.app_mode,
        "demo_mode": settings.demo_mode,
        "orchestration": settings.orchestration_engine,
    }


@app.get("/api/v1/system/readiness", tags=["System"], summary="Is anything running on a stand-in?")
def system_readiness() -> JSONResponse:
    """Component-by-component: real, or a stand-in, and what to set.

    Unauthenticated because it names no secret and no project — only which
    components are real. In local mode it is the honest picture of what is
    simulated; run it before switching a deployment to production and it lists
    exactly what would stop the platform starting.

    Returns **503** when something blocking is not ready, so a container
    readiness probe can use it directly.
    """
    with session_scope() as session:
        report = readiness(session)
    payload = report.to_dict()
    # In local mode a stand-in is expected, so it is not a failure.
    healthy = report.ready or settings.app_mode != "production"
    return JSONResponse(status_code=200 if healthy else 503, content=payload)


@app.get("/api/integration-docs", include_in_schema=False)
def integration_docs() -> HTMLResponse:
    """Swagger UI for the integration surface alone.

    Separate from `/api/docs`, which documents all 118 routes including the ones
    the web app uses. An integrator needs to see the ten that are contractual,
    and nothing else -- a client generated from the full document would have a
    hundred methods they must not call.

    Use **Authorize** to set `X-API-Key`. Reload afterwards and the document
    also describes your own flows and agents, one operation each.
    """
    spec_url = f"{settings.api_prefix}/integration/openapi.json"
    return HTMLResponse(
        f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{settings.app_name} — Integration API</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css" />
  <style>
    body {{ margin: 0; background: #fafafa; }}
    .topbar {{ display: none; }}
    .qe-note {{
      font: 14px/1.5 -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      background: #eef4fb; border-bottom: 1px solid #cfe0f2; color: #1b2430;
      padding: 12px 20px;
    }}
    .qe-note code {{ background: #fff; padding: 1px 5px; border-radius: 4px; }}
  </style>
</head>
<body>
  <p class="qe-note">
    The integration contract only. Click <strong>Authorize</strong> and paste your
    <code>X-API-Key</code>, then reload &mdash; this page will also list
    <strong>your own flows and agents</strong>, each with its real input schema.
  </p>
  <div id="swagger"></div>
  <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    window.ui = SwaggerUIBundle({{
      url: "{spec_url}",
      dom_id: "#swagger",
      deepLinking: true,
      persistAuthorization: true,
      tryItOutEnabled: true,
      defaultModelsExpandDepth: 1,
      requestInterceptor: (request) => {{
        // Send the key when fetching the document too, so an authorised reload
        // shows this key's own capabilities rather than the public contract.
        const key = (window.ui && window.ui.authSelectors)
          ? window.ui.authSelectors.authorized().getIn(["ApiKeyAuth", "value"])
          : null;
        if (key) {{ request.headers["X-API-Key"] = key; }}
        return request;
      }},
    }});
  </script>
</body>
</html>"""
    )


@app.get(
    "/.well-known/qe-platform.json",
    tags=["System"],
    summary="Unauthenticated discovery document",
)
def discovery() -> dict:
    """How to integrate with this platform, for a caller that has no key yet.

    Deliberately says nothing about any project: no names, no counts, no
    capabilities. A caller learns which protocols this speaks and where to
    authenticate, and everything past that needs a credential. Publishing more
    would turn a convenience into a way of surveying an installation.
    """
    prefix = settings.api_prefix
    return {
        "platform": {"name": settings.app_name, "version": settings.app_version},
        "api_version": "v1",
        "protocols": {
            "rest": {
                "description": "For a pipeline: start work, poll it, read the result.",
                "base_path": f"{prefix}/integration",
                "manifest": f"{prefix}/integration/manifest",
                "catalog": f"{prefix}/integration/catalog",
            },
            "mcp": {
                "description": "For an agent platform: discover callable tools and invoke them.",
                "endpoint": f"{prefix}/mcp",
                "transport": "http-jsonrpc",
                "protocol_version": "2024-11-05",
            },
        },
        "authentication": {
            "scheme": "api_key",
            "header": "X-API-Key",
            # How to get one, since a caller reading this has no credential.
            "how_to_obtain": "Ask a platform operator to issue an integration key for your system.",
        },
        # The scoped document, not the platform's 118 internal routes.
        "openapi": f"{prefix}/integration/openapi.json",
        "swagger_ui": "/api/integration-docs",
        "documentation": {
            "start_here": "docs/integration/README.md",
            "guardrails": "docs/integration/guardrails.md",
            "mcp": "docs/integration/mcp.md",
        },
    }


_web_app_dir = Path(settings.frontend_dist_dir).resolve()

# The application under test for demonstrations. Serving it here means healing can
# be shown against a real browser and a real DOM with nothing else to install.
# See app/demo_app/README.md; it is not part of the product.
_demo_app_dir = Path(__file__).resolve().parent / "demo_app" / "static"
if settings.demo_app_enabled and _demo_app_dir.is_dir():
    app.mount("/demo-app", StaticFiles(directory=_demo_app_dir, html=True), name="demo-app")

if settings.serve_frontend and (_web_app_dir / "index.html").is_file():
    # Python reads MIME types from the Windows registry, which often maps .js to
    # text/plain; with nosniff the browser would then refuse to run the app.
    for mime_type, extension in (
        ("text/javascript", ".js"),
        ("text/javascript", ".mjs"),
        ("text/css", ".css"),
        ("font/woff2", ".woff2"),
        ("font/woff", ".woff"),
        ("image/svg+xml", ".svg"),
    ):
        mimetypes.add_type(mime_type, extension)

    # Registered last, so every API route above takes precedence.
    app.mount("/assets", StaticFiles(directory=_web_app_dir / "assets"), name="web-assets")

    @app.get("/{path:path}", include_in_schema=False)
    def web_app(path: str) -> FileResponse:
        """Serve the built web app; client-side routes fall back to index.html."""
        if path == "api" or path.startswith("api/"):
            raise StarletteHTTPException(status_code=404, detail="Not Found")
        candidate = (_web_app_dir / path).resolve()
        if path and candidate.is_file() and candidate.is_relative_to(_web_app_dir):
            return FileResponse(candidate)
        # index.html names the hashed bundles, so it must never be served stale.
        return FileResponse(_web_app_dir / "index.html", headers={"Cache-Control": "no-cache"})

else:

    @app.get("/", tags=["System"], summary="Service root")
    def root() -> dict:
        return {
            "name": settings.app_name,
            "tagline": "Intelligent agents. Governed orchestration. Continuous quality.",
            "version": settings.app_version,
            "docs": "/api/docs",
            "api": settings.api_prefix,
        }
