"""Defect intelligence entities (spec section 13)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, GUID, JSONType, SoftDeleteMixin, TimestampMixin, UUIDPrimaryKeyMixin, UTCDateTime

DEFECT_STATUSES = ("open", "triage", "in_progress", "resolved", "closed", "rejected", "duplicate")
SEVERITIES = ("blocker", "critical", "major", "minor", "trivial")


class Defect(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "defects"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    external_key: Mapped[str | None] = mapped_column(String(60), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(400), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(24), default="open", nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(20), default="major", nullable=False, index=True)
    priority: Mapped[str] = mapped_column(String(20), default="medium", nullable=False, index=True)
    environment_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("environments.id"), nullable=True)
    execution_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("executions.id"), nullable=True)
    execution_test_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("execution_tests.id"), nullable=True)
    requirement_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("requirements.id"), nullable=True)
    test_case_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("test_cases.id"), nullable=True)

    reported_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    assigned_to: Mapped[str | None] = mapped_column(String(120), nullable=True)
    source: Mapped[str] = mapped_column(String(40), default="automation", nullable=False)
    created_by_agent: Mapped[str | None] = mapped_column(String(80), nullable=True)
    is_ai_suggested: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ai_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    cluster_key: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    duplicate_of_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("defects.id"), nullable=True)
    duplicate_similarity: Mapped[float | None] = mapped_column(Float, nullable=True)
    failure_signature: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    steps_to_reproduce: Mapped[list] = mapped_column(JSONType, default=list)
    evidence: Mapped[list] = mapped_column(JSONType, default=list)
    labels: Mapped[list] = mapped_column(JSONType, default=list)
    resolved_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    resolution_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    jira_sync_state: Mapped[str] = mapped_column(String(24), default="not_synced", nullable=False)

    analyses: Mapped[list[DefectAnalysis]] = relationship(
        back_populates="defect", cascade="all, delete-orphan", lazy="selectin"
    )


class DefectAnalysis(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """AI triage output: severity/priority suggestions, clustering, duplicates."""

    __tablename__ = "defect_analysis"

    defect_id: Mapped[str] = mapped_column(GUID(), ForeignKey("defects.id", ondelete="CASCADE"), index=True)
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True)
    agent_key: Mapped[str] = mapped_column(String(80), nullable=False)
    analysis_type: Mapped[str] = mapped_column(String(40), default="triage", nullable=False)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    recommended_severity: Mapped[str | None] = mapped_column(String(20), nullable=True)
    recommended_priority: Mapped[str | None] = mapped_column(String(20), nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    findings: Mapped[list] = mapped_column(JSONType, default=list)
    recommendations: Mapped[list] = mapped_column(JSONType, default=list)
    similar_defects: Mapped[list] = mapped_column(JSONType, default=list)
    accepted: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    reviewed_by: Mapped[str | None] = mapped_column(String(120), nullable=True)

    defect: Mapped[Defect] = relationship(back_populates="analyses")


class DefectPrediction(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Forward-looking risk scores per module/requirement (spec section 13)."""

    __tablename__ = "defect_predictions"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True)
    target_type: Mapped[str] = mapped_column(String(40), default="module", nullable=False)
    target_ref: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False)
    probability: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    predicted_severity: Mapped[str] = mapped_column(String(20), default="major", nullable=False)
    risk_band: Mapped[str] = mapped_column(String(16), default="medium", nullable=False, index=True)
    drivers: Mapped[list] = mapped_column(JSONType, default=list)
    recommended_actions: Mapped[list] = mapped_column(JSONType, default=list)
    horizon_days: Mapped[int] = mapped_column(Integer, default=14, nullable=False)
    model_version: Mapped[str] = mapped_column(String(40), default="heuristic-v1", nullable=False)
    outcome_observed: Mapped[bool | None] = mapped_column(Boolean, nullable=True)


class RootCauseAnalysis(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """RCA records produced by the Automated RCA agent (spec section 13)."""

    __tablename__ = "root_cause_analysis"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    defect_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("defects.id"), nullable=True, index=True)
    execution_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("executions.id"), nullable=True)
    execution_test_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("execution_tests.id"), nullable=True)
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    probable_root_cause: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[str] = mapped_column(String(60), default="application", nullable=False, index=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    evidence: Mapped[list] = mapped_column(JSONType, default=list)
    contributing_factors: Mapped[list] = mapped_column(JSONType, default=list)
    affected_tests: Mapped[list] = mapped_column(JSONType, default=list)
    related_requirements: Mapped[list] = mapped_column(JSONType, default=list)
    related_code_changes: Mapped[list] = mapped_column(JSONType, default=list)
    historical_similarity: Mapped[list] = mapped_column(JSONType, default=list)
    recommended_action: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="proposed", nullable=False, index=True)
    reviewed_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    agent_key: Mapped[str | None] = mapped_column(String(80), nullable=True)
