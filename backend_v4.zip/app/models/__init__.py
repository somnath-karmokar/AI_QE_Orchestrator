"""SQLAlchemy models for the AI QE Orchestrator.

Importing this package registers every table on `Base.metadata`, which Alembic
autogeneration and the demo bootstrap both rely on.
"""

from app.models.agent import Agent, AgentPermission, AgentTool, AgentVersion
from app.models.base import Base, GUID, JSONType, new_uuid, utcnow
from app.models.conversation import Conversation, ConversationMessage
from app.models.datasource import DataSource
from app.models.defect import Defect, DefectAnalysis, DefectPrediction, RootCauseAnalysis
from app.models.flow import AgentCartItem, AgentFlow, AgentFlowEdge, AgentFlowNode, AgentFlowVersion
from app.models.governance import ApprovalRequest, AuditLog, GovernancePolicy, Notification
from app.models.identity import Permission, Role, User
from app.models.integration import IntegrationClient
from app.models.knowledge import (
    EmbeddingModel,
    KnowledgeChunk,
    KnowledgeCollection,
    KnowledgeDocument,
    KnowledgeSource,
    VectorStoreConfig,
)
from app.models.llm import LLMDeployment, LLMModel, LLMProvider, LLMRoutingPolicy, LLMUsage
from app.models.project import Environment, Integration, MCPServer, Project
from app.models.run import AgentMessage, AgentRun, AgentRunStep
from app.models.testing import (
    BusinessFlow,
    BusinessFlowStep,
    Execution,
    ExecutionArtifact,
    ExecutionTest,
    FailureEvidence,
    HealingRecord,
    RegressionAnalysis,
    Requirement,
    TestCase,
    TestDataSet,
    TestScenario,
    TestScript,
    TestDependency,
    TraceabilityLink,
)

__all__ = [
    "Base",
    "BusinessFlow",
    "BusinessFlowStep",
    "TestDependency",
    "FailureEvidence",
    "IntegrationClient",
    "GUID",
    "JSONType",
    "new_uuid",
    "utcnow",
    # identity
    "User",
    "Role",
    "Permission",
    # project
    "Project",
    "Environment",
    "Integration",
    "MCPServer",
    # tenant-owned data sources
    "DataSource",
    # agents
    "Agent",
    "AgentVersion",
    "AgentTool",
    "AgentPermission",
    # flows
    "AgentFlow",
    "AgentFlowVersion",
    "AgentFlowNode",
    "AgentFlowEdge",
    "AgentCartItem",
    # runs
    "AgentRun",
    "AgentRunStep",
    "AgentMessage",
    # testing
    "Requirement",
    "TestScenario",
    "TestCase",
    "TestScript",
    "TestDataSet",
    "Execution",
    "ExecutionTest",
    "ExecutionArtifact",
    "HealingRecord",
    "TraceabilityLink",
    "RegressionAnalysis",
    # defects
    "Defect",
    "DefectAnalysis",
    "DefectPrediction",
    "RootCauseAnalysis",
    # knowledge
    "KnowledgeSource",
    "KnowledgeDocument",
    "KnowledgeChunk",
    "KnowledgeCollection",
    "VectorStoreConfig",
    "EmbeddingModel",
    # llm
    "LLMProvider",
    "LLMModel",
    "LLMDeployment",
    "LLMRoutingPolicy",
    "LLMUsage",
    # conversations
    "Conversation",
    "ConversationMessage",
    # governance
    "GovernancePolicy",
    "ApprovalRequest",
    "AuditLog",
    "Notification",
]
