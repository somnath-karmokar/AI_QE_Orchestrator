"""Agent run state: runs, per-step records and the message/event trail."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, GUID, JSONType, TimestampMixin, UUIDPrimaryKeyMixin, UTCDateTime

RUN_STATUSES = (
    "queued",
    "running",
    "awaiting_approval",
    "succeeded",
    "failed",
    "cancelled",
    "partially_succeeded",
)
STEP_STATUSES = ("pending", "running", "succeeded", "failed", "skipped", "awaiting_approval", "cancelled")


class AgentRun(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_runs"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    flow_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_flows.id"), index=True, nullable=True)
    flow_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    agent_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agents.id"), nullable=True)
    environment_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("environments.id"), nullable=True)

    run_number: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    title: Mapped[str] = mapped_column(String(240), nullable=False)
    kind: Mapped[str] = mapped_column(String(24), default="flow", nullable=False)  # flow | agent | agent_test
    status: Mapped[str] = mapped_column(String(30), default="queued", nullable=False, index=True)
    trigger: Mapped[str] = mapped_column(String(40), default="manual", nullable=False)
    correlation_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    job_id: Mapped[str | None] = mapped_column(String(64), nullable=True)

    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    inputs: Mapped[dict] = mapped_column(JSONType, default=dict)
    outputs: Mapped[dict] = mapped_column(JSONType, default=dict)
    variables: Mapped[dict] = mapped_column(JSONType, default=dict)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    step_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completed_step_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    triggered_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    resume_token: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # Supplied by an external caller so a network retry re-reads this run rather
    # than starting a second one. It gets its own column because `variables` is
    # the flow's working blackboard and the engine overwrites it mid-run.
    idempotency_key: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    # Which API key started this run, when one did. `triggered_by` carries the
    # same thing as a readable label, but a label is not an identity: two keys
    # in a project may share a name, and ownership decides who can read a run
    # back. Nullable because a person starting a run in the web app has none.
    integration_client_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("integration_clients.id", ondelete="SET NULL"), nullable=True, index=True
    )

    steps: Mapped[list[AgentRunStep]] = relationship(
        back_populates="run",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="AgentRunStep.sequence",
    )


class AgentRunStep(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_run_steps"

    run_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agent_runs.id", ondelete="CASCADE"), index=True)
    node_key: Mapped[str] = mapped_column(String(80), nullable=False)
    node_type: Mapped[str] = mapped_column(String(24), default="agent", nullable=False)
    agent_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agents.id"), nullable=True)
    agent_key: Mapped[str | None] = mapped_column(String(80), nullable=True)
    agent_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    label: Mapped[str] = mapped_column(String(200), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="pending", nullable=False, index=True)

    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    inputs: Mapped[dict] = mapped_column(JSONType, default=dict)
    output: Mapped[dict] = mapped_column(JSONType, default=dict)
    # Concise, user-safe rationale -- never raw chain-of-thought (spec section 27).
    reasoning_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    evidence: Mapped[list] = mapped_column(JSONType, default=list)
    tool_calls: Mapped[list] = mapped_column(JSONType, default=list)
    artifacts: Mapped[list] = mapped_column(JSONType, default=list)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    policy_decision: Mapped[dict] = mapped_column(JSONType, default=dict)

    provider: Mapped[str | None] = mapped_column(String(40), nullable=True)
    model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    deployment: Mapped[str | None] = mapped_column(String(80), nullable=True)
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    run: Mapped[AgentRun] = relationship(back_populates="steps")


class AgentMessage(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Append-only trail of run events shown in the live run timeline."""

    __tablename__ = "agent_messages"

    run_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agent_runs.id", ondelete="CASCADE"), index=True)
    step_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_run_steps.id"), nullable=True)
    role: Mapped[str] = mapped_column(String(24), default="system", nullable=False)
    event_type: Mapped[str] = mapped_column(String(50), default="log", nullable=False, index=True)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
