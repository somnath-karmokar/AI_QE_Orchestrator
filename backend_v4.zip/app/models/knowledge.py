"""Knowledge Fabric persistence: sources, documents, chunks and collections.

Chunk rows keep the relational side of the Knowledge Fabric; their embeddings
live in Chroma and are joined back by `chunk_id` (spec section 8).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, GUID, JSONType, SoftDeleteMixin, TimestampMixin, UUIDPrimaryKeyMixin, UTCDateTime

SOURCE_TYPES = ("jira", "confluence", "git", "database", "test_case", "execution", "defect", "upload", "api_spec")
INDEX_STATUSES = ("pending", "indexing", "indexed", "failed", "stale")


class KnowledgeSource(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "knowledge_sources"
    __table_args__ = (UniqueConstraint("project_id", "key", name="uq_knowledge_source_key"),)

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    key: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    connector_mode: Mapped[str] = mapped_column(String(12), default="demo", nullable=False)
    location: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    sync_status: Mapped[str] = mapped_column(String(24), default="indexed", nullable=False, index=True)
    sync_schedule: Mapped[str] = mapped_column(String(40), default="manual", nullable=False)
    last_synced_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    document_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    chunk_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    collection_name: Mapped[str] = mapped_column(String(80), default="qe_knowledge", nullable=False)
    access_scope: Mapped[str] = mapped_column(String(40), default="project", nullable=False)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)

    documents: Mapped[list[KnowledgeDocument]] = relationship(
        back_populates="source", cascade="all, delete-orphan", lazy="selectin"
    )


class KnowledgeDocument(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "knowledge_documents"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    source_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("knowledge_sources.id", ondelete="CASCADE"), index=True, nullable=False
    )
    external_id: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(400), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    artifact_type: Mapped[str] = mapped_column(String(60), default="document", nullable=False)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False, index=True)
    environment: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    url: Mapped[str | None] = mapped_column(String(600), nullable=True)
    author: Mapped[str | None] = mapped_column(String(160), nullable=True)
    index_status: Mapped[str] = mapped_column(String(24), default="pending", nullable=False, index=True)
    indexed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    chunk_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    checksum: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tags: Mapped[list] = mapped_column(JSONType, default=list)
    access_scope: Mapped[str] = mapped_column(String(40), default="project", nullable=False)
    doc_metadata: Mapped[dict] = mapped_column(JSONType, default=dict)

    source: Mapped[KnowledgeSource] = relationship(back_populates="documents")
    chunks: Mapped[list[KnowledgeChunk]] = relationship(
        back_populates="document", cascade="all, delete-orphan", lazy="selectin"
    )


class KnowledgeChunk(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "knowledge_chunks"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    document_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("knowledge_documents.id", ondelete="CASCADE"), index=True, nullable=False
    )
    chunk_index: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    token_estimate: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    collection_name: Mapped[str] = mapped_column(String(80), default="qe_knowledge", nullable=False, index=True)
    vector_id: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    embedding_model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    chunk_metadata: Mapped[dict] = mapped_column(JSONType, default=dict)

    document: Mapped[KnowledgeDocument] = relationship(back_populates="chunks")


class KnowledgeCollection(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Registry of Chroma collections with health/status for the UI."""

    __tablename__ = "knowledge_collections"

    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(160), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    purpose: Mapped[str] = mapped_column(String(120), default="rag", nullable=False)
    vector_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    embedding_model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    dimensions: Mapped[int] = mapped_column(Integer, default=384, nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="healthy", nullable=False)
    last_indexed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)


class VectorStoreConfig(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "vector_store_configs"

    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    provider: Mapped[str] = mapped_column(String(40), default="chroma", nullable=False)
    mode: Mapped[str] = mapped_column(String(24), default="persistent", nullable=False)
    host: Mapped[str | None] = mapped_column(String(200), nullable=True)
    port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    tenant: Mapped[str | None] = mapped_column(String(120), nullable=True)
    database: Mapped[str | None] = mapped_column(String(120), nullable=True)
    persist_directory: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="connected", nullable=False)
    last_checked_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)


class EmbeddingModel(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "embedding_models"

    key: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    provider: Mapped[str] = mapped_column(String(40), default="mock", nullable=False)
    model_name: Mapped[str] = mapped_column(String(120), nullable=False)
    deployment_name: Mapped[str | None] = mapped_column(String(120), nullable=True)
    dimensions: Mapped[int] = mapped_column(Integer, default=384, nullable=False)
    cost_per_1k_tokens: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
