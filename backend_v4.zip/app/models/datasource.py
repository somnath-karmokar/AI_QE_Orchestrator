"""A data source a tenant connects, and the secrets that open it.

`Integration` and `MCPServer` describe what *this platform* ships a connector
for, configured per project. A `DataSource` is the other direction: a customer
pointing the platform at a system of their own -- their Postgres, their S3
bucket, their internal REST API -- and handing over a credential for it.

That difference is why this is its own table rather than another column on
`Integration`:

  * the credential is the customer's, and is encrypted at rest with
    `app.core.crypto`; nothing else in the schema holds a secret value;
  * it is always owned by exactly one project (`project_id` is not nullable
    here, unlike `MCPServer`, where NULL means a shared built-in) -- a data
    source that belonged to nobody would be a data source everybody could use;
  * agents and flows reference it by id, so what a run touched is answerable
    afterwards from the run record.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import (
    Base,
    DescribedMixin,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UTCDateTime,
    UUIDPrimaryKeyMixin,
)

# What kind of system is on the other end. The kind decides which fields the
# connection form asks for and which adapter reads it, nothing more.
DATA_SOURCE_KINDS = (
    "postgres",
    "mysql",
    "sqlserver",
    "oracle",
    "mongodb",
    "rest_api",
    "graphql",
    "s3",
    "azure_blob",
    "gcs",
    "elasticsearch",
    "snowflake",
    "jira",
    "confluence",
    "git",
    "file_upload",
    "custom",
)

DATA_SOURCE_STATUSES = ("unverified", "connected", "error", "disabled")

# Which fields of a kind's connection details are secret. Everything not listed
# is stored in the clear so it can be shown on screen and searched; everything
# listed goes into the encrypted bundle and is never returned by the API.
SECRET_FIELDS: dict[str, tuple[str, ...]] = {
    "postgres": ("password",),
    "mysql": ("password",),
    "sqlserver": ("password",),
    "oracle": ("password",),
    "mongodb": ("password", "connection_string"),
    "rest_api": ("api_key", "bearer_token", "password"),
    "graphql": ("api_key", "bearer_token"),
    "s3": ("access_key_id", "secret_access_key", "session_token"),
    "azure_blob": ("account_key", "sas_token", "connection_string"),
    "gcs": ("service_account_json",),
    "elasticsearch": ("password", "api_key"),
    "snowflake": ("password", "private_key"),
    "jira": ("api_token",),
    "confluence": ("api_token",),
    "git": ("access_token", "ssh_private_key"),
    "file_upload": (),
    "custom": ("api_key", "password", "token", "secret"),
}


def secret_fields_for(kind: str) -> tuple[str, ...]:
    """Which fields to encrypt for a kind.

    An unknown kind gets the widest set rather than none: failing towards
    encrypting too much is recoverable, failing towards storing a password in
    the clear is not.
    """
    return SECRET_FIELDS.get(kind, SECRET_FIELDS["custom"])


class DataSource(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin, DescribedMixin):
    __tablename__ = "data_sources"
    __table_args__ = (
        UniqueConstraint("project_id", "key", name="uq_data_sources_project_key"),
    )

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    key: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(24), default="unverified", nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    # Non-secret connection details: host, port, database, bucket, base URL.
    # Shown on screen, so nothing sensitive may be put here -- the service
    # splits an incoming payload by `secret_fields_for(kind)` rather than
    # trusting the caller to have split it.
    config: Mapped[dict] = mapped_column(JSONType, default=dict)

    # The encrypted credential bundle. Ciphertext from app.core.crypto, or None
    # when this source needs no credential.
    secret_bundle: Mapped[str | None] = mapped_column(Text, nullable=True)
    # A salted digest of the credential, so a screen can show that it changed
    # without ever showing it.
    secret_fingerprint: Mapped[str | None] = mapped_column(String(32), nullable=True)
    secret_updated_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    secret_updated_by: Mapped[str | None] = mapped_column(String(160), nullable=True)

    # Read-only by default: a data source is for *reading* a customer's systems,
    # and an agent that can write to a production database is a different
    # decision that somebody should have to make deliberately.
    allow_writes: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    last_tested_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    last_test_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_by: Mapped[str | None] = mapped_column(String(160), nullable=True)

    project: Mapped["Project"] = relationship()  # noqa: F821, UP037


from app.models.project import Project  # noqa: E402, F401 - resolves the relationship
