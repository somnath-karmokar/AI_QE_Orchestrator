"""Users, roles and permissions."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import (
    UTCDateTime,
    Base,
    DescribedMixin,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)


class Role(Base, UUIDPrimaryKeyMixin, TimestampMixin, DescribedMixin):
    __tablename__ = "roles"

    key: Mapped[str] = mapped_column(String(60), unique=True, nullable=False, index=True)
    is_system: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    permissions: Mapped[list[Permission]] = relationship(
        back_populates="role", cascade="all, delete-orphan", lazy="selectin"
    )
    users: Mapped[list[User]] = relationship(back_populates="role", lazy="selectin")


class Permission(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "permissions"
    __table_args__ = (UniqueConstraint("role_id", "key", name="uq_permission_role_key"),)

    role_id: Mapped[str] = mapped_column(GUID(), ForeignKey("roles.id", ondelete="CASCADE"), index=True)
    key: Mapped[str] = mapped_column(String(80), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    role: Mapped[Role] = relationship(back_populates="permissions")


class User(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    full_name: Mapped[str] = mapped_column(String(200), nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role_id: Mapped[str] = mapped_column(GUID(), ForeignKey("roles.id"), index=True)
    job_title: Mapped[str | None] = mapped_column(String(160), nullable=True)
    avatar_initials: Mapped[str | None] = mapped_column(String(4), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    last_login_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    preferences: Mapped[dict] = mapped_column(JSONType, default=dict)

    role: Mapped[Role] = relationship(back_populates="users", lazy="joined")

    @property
    def role_key(self) -> str:
        return self.role.key if self.role else "viewer"


class ProjectMember(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Who may see a project's data.

    A role says what a person may *do* anywhere on the platform; this says which
    projects they may do it *in*. Both apply: a QE lead still cannot decide an
    approval without `approval:decide`, and cannot see a project they are not a
    member of whatever their role.

    Membership is the tenant boundary. A project's requirements, runs, evidence,
    knowledge and connected data sources belong to its members and to nobody
    else.
    """

    __tablename__ = "project_members"
    __table_args__ = (
        # One row per person per project: two would make "what access do they
        # have" ambiguous rather than additive.
        UniqueConstraint("project_id", "user_id", name="uq_project_members_project_user"),
    )

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    user_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False
    )
    # "owner" may change membership; "member" works in the project; "viewer" reads.
    access: Mapped[str] = mapped_column(String(20), default="member", nullable=False)
    added_by: Mapped[str | None] = mapped_column(String(160), nullable=True)

    user: Mapped[User] = relationship(lazy="joined")
