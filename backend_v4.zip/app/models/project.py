"""Projects, environments, integrations and MCP server registrations.

`project_id` is the isolation boundary for every other entity in the platform
(spec section 19).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import (
    UTCDateTime,
    Base,
    DescribedMixin,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)

PROJECT_STATUSES = ("draft", "onboarding", "active", "paused", "archived")
INTEGRATION_KINDS = ("jira", "confluence", "git", "database", "cicd", "custom")
CONNECTOR_MODES = ("demo", "real")


class Project(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin, DescribedMixin):
    __tablename__ = "projects"

    key: Mapped[str] = mapped_column(String(40), unique=True, nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(24), default="active", nullable=False)
    business_domain: Mapped[str | None] = mapped_column(String(120), nullable=True)
    application_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    jira_project_key: Mapped[str | None] = mapped_column(String(40), nullable=True)
    confluence_space: Mapped[str | None] = mapped_column(String(80), nullable=True)
    git_repository: Mapped[str | None] = mapped_column(String(300), nullable=True)
    onboarding_step: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
    modules: Mapped[list] = mapped_column(JSONType, default=list)
    tags: Mapped[list] = mapped_column(JSONType, default=list)

    # Configuration hierarchy: project overrides global, agent overrides project.
    llm_config: Mapped[dict] = mapped_column(JSONType, default=dict)
    qe_policies: Mapped[dict] = mapped_column(JSONType, default=dict)
    execution_config: Mapped[dict] = mapped_column(JSONType, default=dict)
    cost_budget_usd: Mapped[float] = mapped_column(Float, default=50.0, nullable=False)

    environments: Mapped[list[Environment]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )
    integrations: Mapped[list[Integration]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )
    mcp_servers: Mapped[list[MCPServer]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )


class Environment(Base, UUIDPrimaryKeyMixin, TimestampMixin, DescribedMixin):
    __tablename__ = "environments"
    __table_args__ = (UniqueConstraint("project_id", "key", name="uq_environment_project_key"),)

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    key: Mapped[str] = mapped_column(String(40), nullable=False)
    base_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    api_base_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    database_alias: Mapped[str | None] = mapped_column(String(120), nullable=True)
    is_production_like: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    allows_write_actions: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    health_status: Mapped[str] = mapped_column(String(24), default="healthy", nullable=False)
    # Credential *references* only -- never raw secret values (spec section 30).
    secret_refs: Mapped[dict] = mapped_column(JSONType, default=dict)
    metadata_json: Mapped[dict] = mapped_column(JSONType, default=dict)

    project: Mapped[Project] = relationship(back_populates="environments")


class Integration(Base, UUIDPrimaryKeyMixin, TimestampMixin, DescribedMixin):
    __tablename__ = "integrations"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    kind: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    connector_mode: Mapped[str] = mapped_column(String(12), default="demo", nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="connected", nullable=False)
    base_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)
    secret_refs: Mapped[dict] = mapped_column(JSONType, default=dict)
    last_sync_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    project: Mapped[Project] = relationship(back_populates="integrations")


class MCPServer(Base, UUIDPrimaryKeyMixin, TimestampMixin, DescribedMixin):
    __tablename__ = "mcp_servers"

    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=True
    )
    key: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    transport: Mapped[str] = mapped_column(String(24), default="in_process", nullable=False)
    endpoint: Mapped[str | None] = mapped_column(String(500), nullable=True)
    connector_mode: Mapped[str] = mapped_column(String(12), default="demo", nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="online", nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    tools: Mapped[list] = mapped_column(JSONType, default=list)
    # Only tools on this allowlist may be invoked by agents (spec section 30).
    allowed_tools: Mapped[list] = mapped_column(JSONType, default=list)
    requires_approval_tools: Mapped[list] = mapped_column(JSONType, default=list)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)
    last_heartbeat_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    project: Mapped[Project | None] = relationship(back_populates="mcp_servers")
