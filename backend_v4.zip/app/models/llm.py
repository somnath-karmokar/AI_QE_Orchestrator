"""LLM provider registry, model/deployment catalogue, routing policies and usage.

Deployment names are stored separately from logical model identifiers because
Azure OpenAI deployment names do not equal model names (spec section 3).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, GUID, JSONType, TimestampMixin, UUIDPrimaryKeyMixin, UTCDateTime

CAPABILITIES = ("classification", "structured_extraction", "generation", "reasoning", "embedding")


class LLMProvider(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "llm_providers"

    key: Mapped[str] = mapped_column(String(40), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="not_configured", nullable=False)
    endpoint: Mapped[str | None] = mapped_column(String(500), nullable=True)
    api_version: Mapped[str | None] = mapped_column(String(40), nullable=True)
    # Reference to a secret, never the secret itself.
    credential_ref: Mapped[str | None] = mapped_column(String(120), nullable=True)
    has_credentials: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    last_checked_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)

    models: Mapped[list[LLMModel]] = relationship(
        back_populates="provider", cascade="all, delete-orphan", lazy="selectin"
    )


class LLMModel(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "llm_models"
    __table_args__ = (UniqueConstraint("provider_id", "model_key", name="uq_model_provider_key"),)

    provider_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("llm_providers.id", ondelete="CASCADE"), index=True, nullable=False
    )
    model_key: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(160), nullable=False)
    family: Mapped[str] = mapped_column(String(60), default="gpt", nullable=False)
    tier: Mapped[str] = mapped_column(String(24), default="standard", nullable=False)  # light|standard|premium
    capabilities: Mapped[list] = mapped_column(JSONType, default=list)
    context_window: Mapped[int] = mapped_column(Integer, default=128000, nullable=False)
    max_output_tokens: Mapped[int] = mapped_column(Integer, default=4096, nullable=False)
    input_cost_per_1k: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    output_cost_per_1k: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    supports_structured_output: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    supports_tools: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    provider: Mapped[LLMProvider] = relationship(back_populates="models")
    deployments: Mapped[list[LLMDeployment]] = relationship(
        back_populates="model", cascade="all, delete-orphan", lazy="selectin"
    )


class LLMDeployment(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Azure deployment mapping; `deployment_name` is null for direct OpenAI."""

    __tablename__ = "llm_deployments"

    model_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("llm_models.id", ondelete="CASCADE"), index=True, nullable=False
    )
    project_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("projects.id"), nullable=True, index=True)
    deployment_name: Mapped[str | None] = mapped_column(String(120), nullable=True)
    region: Mapped[str | None] = mapped_column(String(60), nullable=True)
    capability: Mapped[str] = mapped_column(String(40), default="generation", nullable=False, index=True)
    rate_limit_rpm: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rate_limit_tpm: Mapped[int | None] = mapped_column(Integer, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="available", nullable=False)

    model: Mapped[LLMModel] = relationship(back_populates="deployments")


class LLMRoutingPolicy(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Capability -> provider/model routing with fallback (spec sections 17 and 21)."""

    __tablename__ = "llm_routing_policies"

    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    capability: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    complexity: Mapped[str] = mapped_column(String(24), default="any", nullable=False)  # simple|standard|complex
    provider_key: Mapped[str] = mapped_column(String(40), nullable=False)
    model_key: Mapped[str] = mapped_column(String(80), nullable=False)
    fallback_provider_key: Mapped[str | None] = mapped_column(String(40), nullable=True)
    fallback_model_key: Mapped[str | None] = mapped_column(String(80), nullable=True)
    max_tokens: Mapped[int] = mapped_column(Integer, default=3000, nullable=False)
    temperature: Mapped[float] = mapped_column(Float, default=0.1, nullable=False)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class LLMUsage(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """One row per AI invocation: provider, model, deployment, tokens, latency, cost."""

    __tablename__ = "llm_usage"

    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True, index=True)
    step_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_run_steps.id"), nullable=True)
    agent_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agents.id"), nullable=True, index=True)
    agent_key: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    flow_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_flows.id"), nullable=True, index=True)

    provider: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    model: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    deployment: Mapped[str | None] = mapped_column(String(120), nullable=True)
    capability: Mapped[str] = mapped_column(String(40), default="generation", nullable=False, index=True)
    operation: Mapped[str] = mapped_column(String(40), default="chat", nullable=False)

    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    estimated_cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cache_hit: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    success: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    fallback_used: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    correlation_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
