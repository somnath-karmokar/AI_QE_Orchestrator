"""Agent definitions, versions, tool bindings and permissions.

Agents are metadata-driven records, not hard-coded classes: the marketplace,
flow builder and custom-agent builder all read and write these rows, so new
agents appear in the UI without a frontend change (spec sections 4 and 7).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import (
    UTCDateTime,
    Base,
    DescribedMixin,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)

AGENT_LIFECYCLE = ("draft", "test", "review", "published", "active", "deprecated")
RISK_LEVELS = ("low", "medium", "high", "critical")
COST_TIERS = ("low", "medium", "high")
AGENT_CATEGORIES = (
    "Requirements",
    "Planning",
    "Test Design",
    "Test Data",
    "Automation",
    "Execution",
    "Defect Intelligence",
    "RCA",
    "UAT",
    "Performance",
    "Accessibility",
    "Governance",
    "Reporting",
)


class Agent(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin, DescribedMixin):
    __tablename__ = "agents"

    key: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=True
    )
    category: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    icon: Mapped[str] = mapped_column(String(60), default="Bot", nullable=False)
    summary: Mapped[str | None] = mapped_column(String(400), nullable=True)
    lifecycle_state: Mapped[str] = mapped_column(String(24), default="active", nullable=False, index=True)
    version: Mapped[str] = mapped_column(String(20), default="1.0.0", nullable=False)
    risk_level: Mapped[str] = mapped_column(String(16), default="low", nullable=False, index=True)
    cost_tier: Mapped[str] = mapped_column(String(16), default="low", nullable=False, index=True)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_builtin: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    is_published: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)

    # Behaviour
    goal: Mapped[str | None] = mapped_column(Text, nullable=True)
    system_instructions: Mapped[str | None] = mapped_column(Text, nullable=True)
    handler_key: Mapped[str | None] = mapped_column(String(80), nullable=True)
    capability: Mapped[str] = mapped_column(String(40), default="generation", nullable=False)
    input_schema: Mapped[dict] = mapped_column(JSONType, default=dict)
    output_schema: Mapped[dict] = mapped_column(JSONType, default=dict)
    default_config: Mapped[dict] = mapped_column(JSONType, default=dict)

    # Model / execution policy (agent tier of the configuration hierarchy)
    llm_config: Mapped[dict] = mapped_column(JSONType, default=dict)
    temperature: Mapped[float] = mapped_column(Float, default=0.1, nullable=False)
    max_tokens: Mapped[int] = mapped_column(Integer, default=2500, nullable=False)
    token_budget: Mapped[int] = mapped_column(Integer, default=40000, nullable=False)
    cost_budget_usd: Mapped[float] = mapped_column(Float, default=2.0, nullable=False)
    retry_policy: Mapped[dict] = mapped_column(JSONType, default=dict)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=120, nullable=False)
    guardrails: Mapped[list] = mapped_column(JSONType, default=list)
    supported_tools: Mapped[list] = mapped_column(JSONType, default=list)
    mcp_servers: Mapped[list] = mapped_column(JSONType, default=list)
    tags: Mapped[list] = mapped_column(JSONType, default=list)

    # Marketplace statistics
    usage_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    success_rate: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    avg_duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    avg_cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    rating: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    cloned_from_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agents.id"), nullable=True)

    versions: Mapped[list[AgentVersion]] = relationship(
        back_populates="agent", cascade="all, delete-orphan", lazy="selectin"
    )
    tools: Mapped[list[AgentTool]] = relationship(
        back_populates="agent", cascade="all, delete-orphan", lazy="selectin"
    )
    permissions: Mapped[list[AgentPermission]] = relationship(
        back_populates="agent", cascade="all, delete-orphan", lazy="selectin"
    )


class AgentVersion(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_versions"
    __table_args__ = (UniqueConstraint("agent_id", "version", name="uq_agent_version"),)

    agent_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agents.id", ondelete="CASCADE"), index=True)
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    lifecycle_state: Mapped[str] = mapped_column(String(24), default="draft", nullable=False)
    change_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    snapshot: Mapped[dict] = mapped_column(JSONType, default=dict)
    prompt_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    published_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    published_by: Mapped[str | None] = mapped_column(String(120), nullable=True)

    agent: Mapped[Agent] = relationship(back_populates="versions")


class AgentTool(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_tools"

    agent_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agents.id", ondelete="CASCADE"), index=True)
    mcp_server_key: Mapped[str] = mapped_column(String(60), nullable=False)
    tool_name: Mapped[str] = mapped_column(String(80), nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)

    agent: Mapped[Agent] = relationship(back_populates="tools")


class AgentPermission(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_permissions"

    agent_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agents.id", ondelete="CASCADE"), index=True)
    scope: Mapped[str] = mapped_column(String(60), nullable=False)
    value: Mapped[str] = mapped_column(String(120), nullable=False)
    allowed: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    agent: Mapped[Agent] = relationship(back_populates="permissions")
