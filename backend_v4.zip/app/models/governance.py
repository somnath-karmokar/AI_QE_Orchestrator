"""Governance: policies, approval gates, audit trail and notifications (spec section 18)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, GUID, JSONType, TimestampMixin, UUIDPrimaryKeyMixin, UTCDateTime

POLICY_TYPES = (
    "tool_permission",
    "environment_restriction",
    "approval",
    "model_policy",
    "data_access",
    "cost_limit",
    "execution_limit",
    "pii_masking",
)
POLICY_EFFECTS = ("allow", "deny", "require_approval", "warn")
APPROVAL_STATUSES = ("pending", "approved", "rejected", "expired", "cancelled")


class GovernancePolicy(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "governance_policies"

    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    key: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    policy_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    effect: Mapped[str] = mapped_column(String(24), default="allow", nullable=False)
    scope: Mapped[str] = mapped_column(String(40), default="global", nullable=False)
    # Structured match conditions, e.g. {"risk_level": ["high"], "tool": ["create_defect"]}
    conditions: Mapped[dict] = mapped_column(JSONType, default=dict)
    parameters: Mapped[dict] = mapped_column(JSONType, default=dict)
    severity: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    priority: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
    enforcement_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_enforced_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)


class ApprovalRequest(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "approval_requests"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True, index=True)
    step_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_run_steps.id"), nullable=True)
    policy_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("governance_policies.id"), nullable=True)
    subject_type: Mapped[str] = mapped_column(String(40), default="flow_node", nullable=False)
    subject_ref: Mapped[str | None] = mapped_column(String(160), nullable=True)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    risk_level: Mapped[str] = mapped_column(String(16), default="medium", nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(24), default="pending", nullable=False, index=True)
    required_role: Mapped[str] = mapped_column(String(60), default="qe_lead", nullable=False)
    requested_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    decided_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    decision_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    context: Mapped[dict] = mapped_column(JSONType, default=dict)
    proposed_action: Mapped[dict] = mapped_column(JSONType, default=dict)


class AuditLog(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Who / what / when / why for every important action (spec section 18)."""

    __tablename__ = "audit_logs"

    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    actor: Mapped[str] = mapped_column(String(160), default="system", nullable=False, index=True)
    actor_type: Mapped[str] = mapped_column(String(24), default="user", nullable=False)  # user|agent|system
    action: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    entity_type: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    entity_label: Mapped[str | None] = mapped_column(String(300), nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    outcome: Mapped[str] = mapped_column(String(24), default="success", nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(20), default="info", nullable=False)
    input_summary: Mapped[dict] = mapped_column(JSONType, default=dict)
    output_summary: Mapped[dict] = mapped_column(JSONType, default=dict)
    tool_used: Mapped[str | None] = mapped_column(String(120), nullable=True)
    model_used: Mapped[str | None] = mapped_column(String(120), nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    policy_result: Mapped[dict] = mapped_column(JSONType, default=dict)
    run_id: Mapped[str | None] = mapped_column(GUID(), nullable=True, index=True)
    correlation_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    ip_address: Mapped[str | None] = mapped_column(String(60), nullable=True)


class Notification(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "notifications"

    project_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    user_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(240), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[str] = mapped_column(String(40), default="system", nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(20), default="info", nullable=False)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    link: Mapped[str | None] = mapped_column(String(400), nullable=True)
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)
