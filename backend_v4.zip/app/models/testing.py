"""Test engineering entities: requirements through executions and healing records."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import (
    UTCDateTime,
    Base,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)

REQUIREMENT_STATUSES = ("draft", "refinement", "ready", "in_development", "in_test", "done")
TEST_TYPES = ("functional", "regression", "smoke", "integration", "api", "performance", "accessibility", "uat")
TEST_PRIORITIES = ("critical", "high", "medium", "low")
EXECUTION_STATUSES = ("queued", "running", "passed", "failed", "aborted", "partial")
TEST_RESULTS = ("passed", "failed", "skipped", "blocked", "flaky", "healed")

# The healing lifecycle. A record only reaches `applied` by way of `validated`,
# which only a real re-run can produce.
HEALING_STATUSES = (
    "proposed",              # candidate found, waiting on a human
    "blocked",               # policy forbids this change; no human can approve it
    "approved",              # cleared to be tried, not yet proven
    "validating",            # temporary patch applied, re-run in flight
    "validated",             # the re-run passed
    "validation_failed",     # the re-run did not pass
    "applied",               # persisted to the test script, version bumped
    "rolled_back",           # patch discarded, script untouched
    "rejected",              # a human declined it
)
HEALING_VALIDATION_STATUSES = ("not_started", "running", "passed", "failed", "inconclusive")


class Requirement(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "requirements"
    __table_args__ = (UniqueConstraint("project_id", "external_key", name="uq_requirement_project_key"),)

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    external_key: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(400), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False, index=True)
    source: Mapped[str] = mapped_column(String(40), default="jira", nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="ready", nullable=False, index=True)
    priority: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
    story_points: Mapped[int | None] = mapped_column(Integer, nullable=True)
    epic: Mapped[str | None] = mapped_column(String(160), nullable=True)
    sprint: Mapped[str | None] = mapped_column(String(80), nullable=True)
    acceptance_criteria: Mapped[list] = mapped_column(JSONType, default=list)
    labels: Mapped[list] = mapped_column(JSONType, default=list)
    risk_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    change_frequency: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completeness_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    completeness_findings: Mapped[list] = mapped_column(JSONType, default=list)
    last_analyzed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    scenarios: Mapped[list[TestScenario]] = relationship(
        back_populates="requirement", cascade="all, delete-orphan", lazy="selectin"
    )


class TestScenario(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "test_scenarios"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    requirement_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("requirements.id", ondelete="CASCADE"), index=True, nullable=True
    )
    key: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(400), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    scenario_type: Mapped[str] = mapped_column(String(24), default="positive", nullable=False, index=True)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False)
    priority: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
    risk_level: Mapped[str] = mapped_column(String(16), default="medium", nullable=False)
    generated_by_agent: Mapped[str | None] = mapped_column(String(80), nullable=True)
    generated_by_run_id: Mapped[str | None] = mapped_column(GUID(), nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    tags: Mapped[list] = mapped_column(JSONType, default=list)

    requirement: Mapped[Requirement | None] = relationship(back_populates="scenarios")
    test_cases: Mapped[list[TestCase]] = relationship(
        back_populates="scenario", cascade="all, delete-orphan", lazy="selectin"
    )


class TestCase(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "test_cases"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    scenario_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("test_scenarios.id", ondelete="CASCADE"), index=True, nullable=True
    )
    requirement_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("requirements.id"), nullable=True)
    key: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(400), nullable=False)
    objective: Mapped[str | None] = mapped_column(Text, nullable=True)
    preconditions: Mapped[list] = mapped_column(JSONType, default=list)
    steps: Mapped[list] = mapped_column(JSONType, default=list)
    expected_result: Mapped[str | None] = mapped_column(Text, nullable=True)
    test_type: Mapped[str] = mapped_column(String(30), default="functional", nullable=False, index=True)
    priority: Mapped[str] = mapped_column(String(20), default="medium", nullable=False, index=True)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False, index=True)
    is_automated: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    automation_status: Mapped[str] = mapped_column(String(30), default="not_automated", nullable=False)
    duplicate_of_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("test_cases.id"), nullable=True)
    duplicate_similarity: Mapped[float | None] = mapped_column(Float, nullable=True)
    generated_by_agent: Mapped[str | None] = mapped_column(String(80), nullable=True)
    last_result: Mapped[str | None] = mapped_column(String(20), nullable=True)
    last_executed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    execution_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failure_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    flakiness_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    avg_duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    tags: Mapped[list] = mapped_column(JSONType, default=list)

    scenario: Mapped[TestScenario | None] = relationship(back_populates="test_cases")
    scripts: Mapped[list[TestScript]] = relationship(
        back_populates="test_case", cascade="all, delete-orphan", lazy="selectin"
    )


class TestScript(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "test_scripts"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    test_case_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("test_cases.id", ondelete="CASCADE"), index=True, nullable=True
    )
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    framework: Mapped[str] = mapped_column(String(40), default="playwright-python", nullable=False)
    language: Mapped[str] = mapped_column(String(30), default="python", nullable=False)
    file_path: Mapped[str] = mapped_column(String(400), nullable=False)
    code: Mapped[str] = mapped_column(Text, nullable=False)
    page_objects: Mapped[list] = mapped_column(JSONType, default=list)
    locators: Mapped[list] = mapped_column(JSONType, default=list)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="active", nullable=False)
    generated_by_agent: Mapped[str | None] = mapped_column(String(80), nullable=True)
    generated_by_run_id: Mapped[str | None] = mapped_column(GUID(), nullable=True)
    healing_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    quality_notes: Mapped[list] = mapped_column(JSONType, default=list)

    test_case: Mapped[TestCase | None] = relationship(back_populates="scripts")


class TestDataSet(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "test_data_sets"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False)
    data_type: Mapped[str] = mapped_column(String(40), default="synthetic", nullable=False)
    environment_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("environments.id"), nullable=True)
    schema_definition: Mapped[dict] = mapped_column(JSONType, default=dict)
    records: Mapped[list] = mapped_column(JSONType, default=list)
    record_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    contains_pii: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    masking_applied: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    sql_scripts: Mapped[list] = mapped_column(JSONType, default=list)
    generated_by_agent: Mapped[str | None] = mapped_column(String(80), nullable=True)
    refresh_policy: Mapped[str] = mapped_column(String(40), default="on_demand", nullable=False)
    tags: Mapped[list] = mapped_column(JSONType, default=list)


class Execution(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "executions"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    environment_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("environments.id"), nullable=True)
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    execution_number: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    suite_type: Mapped[str] = mapped_column(String(40), default="regression", nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(24), default="queued", nullable=False, index=True)
    browser: Mapped[str] = mapped_column(String(24), default="chromium", nullable=False)
    headless: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    parallelism: Mapped[int] = mapped_column(Integer, default=2, nullable=False)
    trigger: Mapped[str] = mapped_column(String(40), default="manual", nullable=False)
    mode: Mapped[str] = mapped_column(String(20), default="simulated", nullable=False)  # simulated | playwright

    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    total_tests: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    passed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    skipped: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    flaky: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    healed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    pass_rate: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    failure_categories: Mapped[dict] = mapped_column(JSONType, default=dict)
    ai_findings: Mapped[list] = mapped_column(JSONType, default=list)
    defects_created: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)
    triggered_by: Mapped[str | None] = mapped_column(String(120), nullable=True)

    tests: Mapped[list[ExecutionTest]] = relationship(
        back_populates="execution", cascade="all, delete-orphan", lazy="selectin"
    )


class ExecutionTest(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "execution_tests"

    execution_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("executions.id", ondelete="CASCADE"), index=True, nullable=False
    )
    test_case_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("test_cases.id"), nullable=True)
    test_script_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("test_scripts.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(400), nullable=False)
    module: Mapped[str] = mapped_column(String(120), default="General", nullable=False, index=True)
    result: Mapped[str] = mapped_column(String(20), default="passed", nullable=False, index=True)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    retry_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failure_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    failure_category: Mapped[str | None] = mapped_column(String(60), nullable=True, index=True)
    failure_signature: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    stack_trace: Mapped[str | None] = mapped_column(Text, nullable=True)
    console_logs: Mapped[list] = mapped_column(JSONType, default=list)
    network_logs: Mapped[list] = mapped_column(JSONType, default=list)
    dom_snapshot_ref: Mapped[str | None] = mapped_column(String(400), nullable=True)
    healed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    execution: Mapped[Execution] = relationship(back_populates="tests")
    artifacts: Mapped[list[ExecutionArtifact]] = relationship(
        back_populates="execution_test", cascade="all, delete-orphan", lazy="selectin"
    )


class ExecutionArtifact(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "execution_artifacts"

    execution_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("executions.id", ondelete="CASCADE"), index=True, nullable=False
    )
    execution_test_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("execution_tests.id", ondelete="CASCADE"), nullable=True
    )
    artifact_type: Mapped[str] = mapped_column(String(30), nullable=False)  # screenshot|video|trace|log|report
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    storage_path: Mapped[str] = mapped_column(String(600), nullable=False)
    content_type: Mapped[str] = mapped_column(String(80), default="application/octet-stream", nullable=False)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    artifact_metadata: Mapped[dict] = mapped_column(JSONType, default=dict)

    execution_test: Mapped[ExecutionTest | None] = relationship(back_populates="artifacts")


class HealingRecord(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Auditable self-healing proposals and outcomes (spec section 11)."""

    __tablename__ = "healing_records"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    test_script_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("test_scripts.id"), nullable=True)
    execution_test_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("execution_tests.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="proposed", nullable=False, index=True)
    failure_class: Mapped[str] = mapped_column(String(60), default="locator_drift", nullable=False)
    # What kind of change this heal makes (app.healing.policy.ChangeType). The
    # change-policy matrix is applied to this, not to the failure class.
    change_type: Mapped[str] = mapped_column(String(40), default="locator", nullable=False, index=True)
    original_locator: Mapped[str] = mapped_column(String(600), nullable=False)
    proposed_locator: Mapped[str] = mapped_column(String(600), nullable=False)
    locator_strategy: Mapped[str] = mapped_column(String(40), default="role", nullable=False)
    candidates: Mapped[list] = mapped_column(JSONType, default=list)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    evidence: Mapped[list] = mapped_column(JSONType, default=list)
    # Per-signal contributions behind `confidence`, so a reviewer can see why the
    # number is what it is rather than being asked to trust it.
    confidence_breakdown: Mapped[list] = mapped_column(JSONType, default=list)
    policy_decision: Mapped[dict] = mapped_column(JSONType, default=dict)
    # The reversible change, held here while it is proven. It is applied to the
    # test script only after a re-run validates it.
    patch: Mapped[dict] = mapped_column(JSONType, default=dict)
    result_before: Mapped[str | None] = mapped_column(String(20), nullable=True)
    # `result_after` and `validated_at` are written by the validation service and
    # by nothing else: they mean "a re-run produced this", never "we expect this".
    result_after: Mapped[str | None] = mapped_column(String(20), nullable=True)
    validated_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    validation_status: Mapped[str] = mapped_column(
        String(30), default="not_started", nullable=False, index=True
    )
    validation_mode: Mapped[str | None] = mapped_column(String(20), nullable=True)
    validation_evidence: Mapped[list] = mapped_column(JSONType, default=list)
    validation_execution_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("executions.id"), nullable=True
    )
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rolled_back_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    approval_request_id: Mapped[str | None] = mapped_column(
        GUID(), ForeignKey("approval_requests.id"), nullable=True
    )
    approver: Mapped[str | None] = mapped_column(String(120), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    script_version_before: Mapped[int | None] = mapped_column(Integer, nullable=True)
    script_version_after: Mapped[int | None] = mapped_column(Integer, nullable=True)


class FailureEvidence(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """What was actually observed when a test failed.

    Healing reasons over this rather than over guesses: the DOM as it really was,
    the accessibility tree, what the console and network said, and the locator
    that could not be resolved. One row per failed test per run.
    """

    __tablename__ = "failure_evidence"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    execution_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("executions.id", ondelete="CASCADE"), index=True, nullable=False
    )
    execution_test_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("execution_tests.id", ondelete="CASCADE"), index=True, nullable=False
    )
    # Where the browser was when this was captured.
    page_url: Mapped[str | None] = mapped_column(String(600), nullable=True)
    page_title: Mapped[str | None] = mapped_column(String(300), nullable=True)
    # The locator that failed, and what it was meant to find.
    failed_locator: Mapped[str | None] = mapped_column(String(600), nullable=True)
    failed_locator_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    failed_locator_strategy: Mapped[str | None] = mapped_column(String(40), nullable=True)
    # Set when the element was not missing, only late: how long it actually took
    # to appear. A timing repair is derived from this measurement, so a proposed
    # wait is evidence-based rather than a round number.
    observed_wait_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # Captured artefacts. `dom_html` holds the page as it was; the rest are paths.
    dom_html: Mapped[str | None] = mapped_column(Text, nullable=True)
    accessibility_tree: Mapped[dict] = mapped_column(JSONType, default=dict)
    console_logs: Mapped[list] = mapped_column(JSONType, default=list)
    network_logs: Mapped[list] = mapped_column(JSONType, default=list)
    screenshot_path: Mapped[str | None] = mapped_column(String(600), nullable=True)
    trace_path: Mapped[str | None] = mapped_column(String(600), nullable=True)
    # Honest about provenance: "playwright" means a browser produced this.
    capture_mode: Mapped[str] = mapped_column(String(20), default="simulated", nullable=False)
    captured_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    execution_test: Mapped[ExecutionTest] = relationship()


class BusinessFlow(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    """A journey a customer actually takes: Login → Search → Cart → Checkout → Pay.

    Modules answer "where does this test live". A business flow answers the
    question that matters after a repair: *what else does this touch*. A heal to
    the Add-to-Cart control is only proved by the basket still totalling
    correctly at checkout, and nothing in a module tree says those are related.
    """

    __tablename__ = "business_flows"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    key: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    # What it costs the business when this journey breaks.
    criticality: Mapped[str] = mapped_column(String(20), default="high", nullable=False)
    owner: Mapped[str | None] = mapped_column(String(120), nullable=True)
    modules: Mapped[list] = mapped_column(JSONType, default=list)

    steps: Mapped[list[BusinessFlowStep]] = relationship(
        back_populates="business_flow",
        cascade="all, delete-orphan",
        order_by="BusinessFlowStep.position",
    )


class BusinessFlowStep(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """One step of a journey, and what it depends on.

    The dependencies are what make change impact answerable: a locator that
    drifted belongs to a step, the step belongs to a journey, and the journey
    names every test that would notice.
    """

    __tablename__ = "business_flow_steps"

    business_flow_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("business_flows.id", ondelete="CASCADE"), index=True, nullable=False
    )
    position: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    key: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    module: Mapped[str | None] = mapped_column(String(120), nullable=True)
    # What this step touches. Deliberately plain lists: a component name, an API
    # path, a table, a data set reference.
    ui_components: Mapped[list] = mapped_column(JSONType, default=list)
    api_endpoints: Mapped[list] = mapped_column(JSONType, default=list)
    data_entities: Mapped[list] = mapped_column(JSONType, default=list)
    # What must still be true after this step. Never healed -- these are the
    # business outcomes a repair is validated against.
    assertions: Mapped[list] = mapped_column(JSONType, default=list)

    business_flow: Mapped[BusinessFlow] = relationship(back_populates="steps")


class TestDependency(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Which test exercises which step of which journey."""

    __tablename__ = "test_dependencies"
    __table_args__ = (
        UniqueConstraint("test_case_id", "business_flow_step_id", name="uq_test_dependency"),
    )

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    test_case_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("test_cases.id", ondelete="CASCADE"), index=True, nullable=False
    )
    business_flow_step_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("business_flow_steps.id", ondelete="CASCADE"), index=True, nullable=False
    )
    # "covers" the step, or merely "traverses" it on the way to something else.
    # A repair is validated by what covers it; a regression sweep includes both.
    relationship_type: Mapped[str] = mapped_column(String(24), default="covers", nullable=False)


class TraceabilityLink(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Typed edges of the requirement-to-defect traceability graph (spec section 14)."""

    __tablename__ = "traceability_links"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    source_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    source_id: Mapped[str] = mapped_column(GUID(), nullable=False, index=True)
    target_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    target_id: Mapped[str] = mapped_column(GUID(), nullable=False, index=True)
    link_type: Mapped[str] = mapped_column(String(40), default="covers", nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
    created_by_agent: Mapped[str | None] = mapped_column(String(80), nullable=True)


class RegressionAnalysis(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Output of the regression optimisation agent (spec section 15)."""

    __tablename__ = "regression_analyses"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(240), nullable=False)
    changed_modules: Mapped[list] = mapped_column(JSONType, default=list)
    changed_requirements: Mapped[list] = mapped_column(JSONType, default=list)
    selected_tests: Mapped[list] = mapped_column(JSONType, default=list)
    skipped_tests: Mapped[list] = mapped_column(JSONType, default=list)
    risk_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    baseline_duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    optimized_duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    reduction_percent: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    rationale: Mapped[str | None] = mapped_column(Text, nullable=True)
