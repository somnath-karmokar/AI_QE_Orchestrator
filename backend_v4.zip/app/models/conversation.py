"""Copilot conversations.

The conversational surface is a first-class, audited part of the platform: what
a user asked, how intent was resolved, which agents were selected and why, and
what those agents produced.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, GUID, JSONType, SoftDeleteMixin, TimestampMixin, UUIDPrimaryKeyMixin, UTCDateTime

MESSAGE_ROLES = ("user", "assistant", "system")
# How the planner decided to respond to a turn.
PLAN_KINDS = ("answer", "run_agent", "run_flow", "clarify", "navigate", "refused")


class Conversation(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "conversations"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    user_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(240), default="New conversation", nullable=False)
    environment_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("environments.id"), nullable=True)

    message_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    last_message_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    # Carried between turns so follow-ups like "now automate it" resolve.
    context: Mapped[dict] = mapped_column(JSONType, default=dict)

    messages: Mapped[list[ConversationMessage]] = relationship(
        back_populates="conversation",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="ConversationMessage.sequence",
    )


class ConversationMessage(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "conversation_messages"

    conversation_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("conversations.id", ondelete="CASCADE"), index=True, nullable=False
    )
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)

    # ----- how intent was resolved (assistant turns) -----
    plan_kind: Mapped[str | None] = mapped_column(String(24), nullable=True)
    intent: Mapped[str | None] = mapped_column(String(80), nullable=True)
    intent_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    # Agents the planner considered, each with its match score and rationale.
    considered_agents: Mapped[list] = mapped_column(JSONType, default=list)
    selected_agents: Mapped[list] = mapped_column(JSONType, default=list)
    extracted_entities: Mapped[dict] = mapped_column(JSONType, default=dict)
    reasoning_summary: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ----- what happened -----
    run_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agent_runs.id"), nullable=True, index=True)
    evidence: Mapped[list] = mapped_column(JSONType, default=list)
    artifacts: Mapped[list] = mapped_column(JSONType, default=list)
    suggestions: Mapped[list] = mapped_column(JSONType, default=list)
    navigation: Mapped[dict] = mapped_column(JSONType, default=dict)

    # ----- telemetry -----
    provider: Mapped[str | None] = mapped_column(String(40), nullable=True)
    model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    policy_decision: Mapped[dict] = mapped_column(JSONType, default=dict)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    # True when the turn arrived by voice, so the UI can speak the reply back.
    is_voice: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # ----- was the answer any good? -----
    # Readers rate an answer, which is what turns a transcript into an evaluation
    # set: the weak answers are the ones with a thumbs down and a reason.
    feedback: Mapped[str | None] = mapped_column(String(12), nullable=True, index=True)  # up | down
    feedback_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    feedback_by: Mapped[str | None] = mapped_column(String(160), nullable=True)
    feedback_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    conversation: Mapped[Conversation] = relationship(back_populates="messages")
