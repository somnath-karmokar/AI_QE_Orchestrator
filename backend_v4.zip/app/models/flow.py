"""Agent flows: versioned graphs of agent, condition, approval and tool nodes."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import (
    UTCDateTime,
    Base,
    DescribedMixin,
    GUID,
    JSONType,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)

NODE_TYPES = ("start", "agent", "condition", "approval", "parallel", "join", "tool", "loop", "end")
FLOW_STATUSES = ("draft", "validated", "published", "archived")


class AgentFlow(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin, DescribedMixin):
    __tablename__ = "agent_flows"

    project_id: Mapped[str] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True, nullable=False
    )
    key: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(24), default="draft", nullable=False, index=True)
    category: Mapped[str] = mapped_column(String(60), default="Test Engineering", nullable=False)
    version: Mapped[str] = mapped_column(String(20), default="1.0.0", nullable=False)
    is_template: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    trigger_type: Mapped[str] = mapped_column(String(40), default="manual", nullable=False)
    variables: Mapped[dict] = mapped_column(JSONType, default=dict)
    default_environment_id: Mapped[str | None] = mapped_column(GUID(), nullable=True)
    llm_config: Mapped[dict] = mapped_column(JSONType, default=dict)
    cost_budget_usd: Mapped[float] = mapped_column(Float, default=5.0, nullable=False)
    token_budget: Mapped[int] = mapped_column(Integer, default=120000, nullable=False)
    validation_result: Mapped[dict] = mapped_column(JSONType, default=dict)
    last_run_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    run_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    tags: Mapped[list] = mapped_column(JSONType, default=list)

    # ----- Operating the flow on its own -----------------------------------
    # Every flow is a self-contained unit: an accountable owner, its own triggers
    # (manual, schedule, API) and its own governance settings.
    owner: Mapped[str | None] = mapped_column(String(160), nullable=True)
    # {"enabled": bool, "frequency": "hourly|daily|weekly", "time": "HH:MM", "weekday": 0-6}, UTC.
    schedule: Mapped[dict] = mapped_column(JSONType, default=dict)
    next_run_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True, index=True)
    # Only a keyed hash is stored; the token itself is shown once when generated.
    webhook_token_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    webhook_token_hint: Mapped[str | None] = mapped_column(String(12), nullable=True)
    # {"run_roles": [...], "budget_alert_percent": 80, "notify_on_failure": bool}
    governance: Mapped[dict] = mapped_column(JSONType, default=dict)

    nodes: Mapped[list[AgentFlowNode]] = relationship(
        back_populates="flow", cascade="all, delete-orphan", lazy="selectin"
    )
    edges: Mapped[list[AgentFlowEdge]] = relationship(
        back_populates="flow", cascade="all, delete-orphan", lazy="selectin"
    )
    versions: Mapped[list[AgentFlowVersion]] = relationship(
        back_populates="flow", cascade="all, delete-orphan", lazy="selectin"
    )

    @property
    def schedule_description(self) -> str:
        from app.orchestration.schedule import describe_schedule  # noqa: PLC0415 - avoids an import cycle

        return describe_schedule(self.schedule)

    @property
    def api_trigger_enabled(self) -> bool:
        return bool(self.webhook_token_hash)


class AgentFlowVersion(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_flow_versions"
    __table_args__ = (UniqueConstraint("flow_id", "version", name="uq_flow_version"),)

    flow_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agent_flows.id", ondelete="CASCADE"), index=True)
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    change_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    graph_snapshot: Mapped[dict] = mapped_column(JSONType, default=dict)
    published_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)

    flow: Mapped[AgentFlow] = relationship(back_populates="versions")


class AgentFlowNode(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_flow_nodes"
    __table_args__ = (UniqueConstraint("flow_id", "node_key", name="uq_flow_node_key"),)

    flow_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agent_flows.id", ondelete="CASCADE"), index=True)
    node_key: Mapped[str] = mapped_column(String(80), nullable=False)
    node_type: Mapped[str] = mapped_column(String(24), nullable=False)
    label: Mapped[str] = mapped_column(String(160), nullable=False)
    agent_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("agents.id"), nullable=True)
    agent_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    position_x: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    position_y: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    config: Mapped[dict] = mapped_column(JSONType, default=dict)
    input_mapping: Mapped[dict] = mapped_column(JSONType, default=dict)
    output_mapping: Mapped[dict] = mapped_column(JSONType, default=dict)
    condition_expression: Mapped[str | None] = mapped_column(Text, nullable=True)
    llm_config: Mapped[dict] = mapped_column(JSONType, default=dict)  # most-specific override tier
    retry_policy: Mapped[dict] = mapped_column(JSONType, default=dict)
    timeout_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    on_failure: Mapped[str] = mapped_column(String(24), default="fail_flow", nullable=False)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    approval_role: Mapped[str | None] = mapped_column(String(60), nullable=True)
    cost_limit_usd: Mapped[float | None] = mapped_column(Float, nullable=True)

    flow: Mapped[AgentFlow] = relationship(back_populates="nodes")


class AgentFlowEdge(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "agent_flow_edges"

    flow_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agent_flows.id", ondelete="CASCADE"), index=True)
    source_node_key: Mapped[str] = mapped_column(String(80), nullable=False)
    target_node_key: Mapped[str] = mapped_column(String(80), nullable=False)
    branch_label: Mapped[str | None] = mapped_column(String(40), nullable=True)  # "true" / "false" / custom
    condition_expression: Mapped[str | None] = mapped_column(Text, nullable=True)
    config: Mapped[dict] = mapped_column(JSONType, default=dict)

    flow: Mapped[AgentFlow] = relationship(back_populates="edges")


class AgentCartItem(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Selected agents staged before they become a flow (spec section 6)."""

    __tablename__ = "agent_cart_items"
    __table_args__ = (UniqueConstraint("user_id", "project_id", "agent_id", name="uq_cart_entry"),)

    user_id: Mapped[str] = mapped_column(GUID(), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[str] = mapped_column(GUID(), ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    agent_id: Mapped[str] = mapped_column(GUID(), ForeignKey("agents.id", ondelete="CASCADE"), index=True)
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    config_overrides: Mapped[dict] = mapped_column(JSONType, default=dict)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
