"""Run tests in a real browser and capture what actually happened.

This is the runner behind `PLAYWRIGHT_ENABLED=true`. It drives Playwright
directly rather than shelling out to pytest, because the platform needs the page
*while it is still open* -- the DOM, the accessibility tree, the console and the
network -- and a finished pytest process cannot give it that.

What it verifies is locator resolution: for each locator a script declares, can
the browser still find that element on the page? That is precisely the failure
self-healing exists to repair, and it fails for real when the markup drifts.

Everything captured here is written to disk and recorded as evidence, so a heal
proposed later reasons over the page as it really was.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# Locators are stored as Playwright Python expressions, e.g.
#   page.get_by_test_id("pay-now")
#   page.get_by_role("button", name="Pay now")
# Rather than eval them, parse the call and re-issue it through the API, so a
# malformed or hostile string can never execute.
_CALL = re.compile(r"""page\.(?P<method>get_by_\w+|locator)\((?P<args>.*)\)\s*$""", re.DOTALL)
_ARG = re.compile(r"""^\s*(?:(?P<kw>\w+)\s*=\s*)?(?P<value>"[^"]*"|'[^']*'|True|False|\d+)\s*$""")

SUPPORTED_METHODS = {
    "get_by_test_id",
    "get_by_role",
    "get_by_label",
    "get_by_text",
    "get_by_placeholder",
    "get_by_title",
    "get_by_alt_text",
    "locator",
}


# Read an element's identity from the live page. Captured while a locator still
# resolves, so that when it later stops resolving there is something real to
# match against rather than a guess about what the element used to be.
_FINGERPRINT_JS = """
(element) => {
  const attr = (name) => element.getAttribute(name) || null;
  const label = element.id
    ? (document.querySelector(`label[for="${CSS.escape(element.id)}"]`)?.innerText || null)
    : null;
  return {
    tag: element.tagName.toLowerCase(),
    role: attr('role'),
    test_id: attr('data-testid') || attr('data-test-id') || attr('data-test'),
    id: element.id || null,
    type: attr('type'),
    classes: Array.from(element.classList),
    text: (element.innerText || '').trim().slice(0, 120),
    aria_label: attr('aria-label'),
    placeholder: attr('placeholder'),
    label: label ? label.trim() : null,
  };
}
"""


@dataclass(slots=True)
class LocatorCheck:
    name: str
    expression: str
    strategy: str
    resolved: bool
    match_count: int = 0
    error: str | None = None
    # What the element looked like, captured only when the locator resolved.
    fingerprint: dict[str, Any] | None = None
    # Set when the element was not there at first but arrived if we waited. This
    # is the difference between a locator that is wrong and a test that is
    # impatient, and the two need opposite repairs.
    appeared_after_ms: int | None = None

    @property
    def is_timing(self) -> bool:
        return not self.resolved and self.appeared_after_ms is not None


@dataclass(slots=True)
class PageCapture:
    """One page's worth of evidence."""

    url: str = ""
    title: str = ""
    dom_html: str = ""
    accessibility_tree: dict[str, Any] = field(default_factory=dict)
    console_logs: list[dict[str, Any]] = field(default_factory=list)
    network_logs: list[dict[str, Any]] = field(default_factory=list)
    screenshot_path: str | None = None
    trace_path: str | None = None
    checks: list[LocatorCheck] = field(default_factory=list)

    @property
    def failures(self) -> list[LocatorCheck]:
        return [check for check in self.checks if not check.resolved]


def parse_locator(expression: str) -> tuple[str, list[Any], dict[str, Any]] | None:
    """Turn a stored locator expression into (method, args, kwargs), or None.

    Returning None is a real answer -- an expression this runner cannot re-issue
    is reported as unsupported rather than guessed at.
    """
    match = _CALL.match((expression or "").strip())
    if not match:
        return None
    method = match.group("method")
    if method not in SUPPORTED_METHODS:
        return None

    args: list[Any] = []
    kwargs: dict[str, Any] = {}
    for raw in _split_args(match.group("args")):
        piece = _ARG.match(raw)
        if not piece:
            return None
        value: Any = piece.group("value")
        if value in {"True", "False"}:
            value = value == "True"
        elif value.isdigit():
            value = int(value)
        else:
            value = value[1:-1]
        if piece.group("kw"):
            kwargs[piece.group("kw")] = value
        else:
            args.append(value)
    return method, args, kwargs


def _split_args(text: str) -> list[str]:
    """Split on commas that are not inside quotes."""
    parts: list[str] = []
    depth = 0
    quote: str | None = None
    current: list[str] = []
    for char in text:
        if quote:
            if char == quote:
                quote = None
            current.append(char)
            continue
        if char in "\"'":
            quote = char
            current.append(char)
        elif char in "([{":
            depth += 1
            current.append(char)
        elif char in ")]}":
            depth -= 1
            current.append(char)
        elif char == "," and depth == 0:
            parts.append("".join(current))
            current = []
        else:
            current.append(char)
    if "".join(current).strip():
        parts.append("".join(current))
    return parts


class BrowserRunner:
    """Opens a browser once and checks each test's locators against a live page."""

    def __init__(self, artifacts_dir: Path) -> None:
        self.artifacts_dir = artifacts_dir
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

    def check_locators(
        self,
        *,
        url: str,
        locators: list[dict[str, Any]],
        label: str,
        capture_evidence: bool = True,
        wait_ms: int | None = None,
    ) -> PageCapture:
        """Open `url`, try every locator, and capture the page if any failed.

        `wait_ms` raises the patience for this run only. That is how a timing
        repair is validated: the same test, the same locator, waiting the amount
        the repair proposes.
        """
        from playwright.sync_api import sync_playwright  # noqa: PLC0415 - optional dependency

        capture = PageCapture(url=url)
        slug = re.sub(r"[^a-z0-9]+", "-", label.lower())[:48].strip("-") or "test"

        with sync_playwright() as driver:
            browser = getattr(driver, settings.playwright_browser).launch(
                headless=settings.playwright_headless
            )
            context = browser.new_context()
            if settings.capture_trace:
                context.tracing.start(screenshots=True, snapshots=True)

            page = context.new_page()
            # Deliberately not `set_default_timeout`: that would also govern
            # screenshots and snapshots, so a test tuned to be impatient with an
            # element would fail to capture the evidence explaining why.
            # Locator patience is applied per check instead.

            if settings.capture_console_logs:
                page.on(
                    "console",
                    lambda message: capture.console_logs.append(
                        {"level": message.type, "message": message.text[:400]}
                    ),
                )
            if settings.capture_network_logs:
                page.on(
                    "response",
                    lambda response: capture.network_logs.append(
                        {"url": response.url[:300], "status": response.status}
                    ),
                )

            try:
                # Page load and locator patience are different concerns. A test
                # tuned to give an element half a second should still be allowed
                # to open the page.
                page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=max(settings.playwright_timeout_ms, 15_000),
                )
                capture.title = page.title()
                capture.url = page.url

                for locator in locators:
                    capture.checks.append(self._check_one(page, locator, wait_ms=wait_ms))

                if capture.failures and capture_evidence:
                    self._capture_page(page, capture, slug)
            except Exception as error:  # noqa: BLE001 - reported, never raised at the caller
                capture.checks.append(
                    LocatorCheck(
                        name="page",
                        expression=url,
                        strategy="navigation",
                        resolved=False,
                        error=f"{type(error).__name__}: {error}"[:400],
                    )
                )
            finally:
                if settings.capture_trace:
                    trace_path = self.artifacts_dir / f"{slug}-trace.zip"
                    context.tracing.stop(path=str(trace_path))
                    capture.trace_path = str(trace_path)
                context.close()
                browser.close()

        return capture

    # ------------------------------------------------------------------
    @staticmethod
    def _check_one(
        page: Any,  # noqa: ANN401
        locator: dict[str, Any],
        *,
        wait_ms: int | None = None,
    ) -> LocatorCheck:
        expression = str(locator.get("locator", ""))
        name = str(locator.get("name") or locator.get("description") or "element")
        strategy = str(locator.get("strategy", "unknown"))

        parsed = parse_locator(expression)
        if parsed is None:
            return LocatorCheck(
                name=name,
                expression=expression,
                strategy=strategy,
                resolved=False,
                error="This locator expression is not one the runner can re-issue.",
            )

        method, args, kwargs = parsed
        try:
            found = getattr(page, method)(*args, **kwargs)
            count = found.count()
        except Exception as error:  # noqa: BLE001
            return LocatorCheck(
                name=name,
                expression=expression,
                strategy=strategy,
                resolved=False,
                error=f"{type(error).__name__}: {error}"[:300],
            )

        fingerprint: dict[str, Any] | None = None
        if count == 1:
            # Remember this element while we can still point at it.
            from app.healing.dom import normalise_fingerprint  # noqa: PLC0415 - avoids a cycle

            try:
                fingerprint = normalise_fingerprint(found.evaluate(_FINGERPRINT_JS))
            except Exception:  # noqa: BLE001 - evidence, not a reason to fail a test
                fingerprint = None

        appeared_after: int | None = None
        if count == 0:
            # `count()` is instantaneous, so on its own it cannot tell a missing
            # element from one that has not rendered yet. Wait twice: first for
            # as long as the test itself allows, then for as long as healing
            # would be willing to. Where the element turns up decides which of
            # two opposite repairs is the right one.
            # A timing patch raises the patience for this run only.
            patience = wait_ms or settings.playwright_timeout_ms
            appeared_after = BrowserRunner._time_until_present(found, patience)
            if appeared_after is not None:
                # It arrived inside the test's own budget after all.
                return LocatorCheck(
                    name=name,
                    expression=expression,
                    strategy=strategy,
                    resolved=True,
                    match_count=1,
                    fingerprint=BrowserRunner._fingerprint_of(found),
                )

            from app.healing.config import healing_config  # noqa: PLC0415

            budget = healing_config().max_wait_ms
            if budget > patience:
                extra = BrowserRunner._time_until_present(found, budget - patience)
                if extra is not None:
                    appeared_after = patience + extra

        return LocatorCheck(
            name=name,
            expression=expression,
            strategy=strategy,
            resolved=count > 0,
            match_count=count,
            error=(
                None
                if count
                else (
                    f"Locator resolved to 0 elements within {settings.playwright_timeout_ms}ms; "
                    f"the element appeared after {appeared_after}ms."
                    if appeared_after is not None
                    else "Locator resolved to 0 elements."
                )
            ),
            fingerprint=fingerprint,
            appeared_after_ms=appeared_after,
        )

    @staticmethod
    def _time_until_present(locator: Any, timeout_ms: int) -> int | None:  # noqa: ANN401
        """How long the element took to appear, or None within this budget.

        The measurement is what makes a timing heal defensible: the proposed
        wait is derived from an element that really did arrive, not from a guess
        that waiting might help.
        """
        started = time.perf_counter()
        try:
            locator.first.wait_for(state="attached", timeout=max(1, timeout_ms))
        except Exception:  # noqa: BLE001 - not appearing is the expected answer
            return None
        return int((time.perf_counter() - started) * 1000)

    @staticmethod
    def _fingerprint_of(locator: Any) -> dict[str, Any] | None:  # noqa: ANN401
        from app.healing.dom import normalise_fingerprint  # noqa: PLC0415

        try:
            return normalise_fingerprint(locator.first.evaluate(_FINGERPRINT_JS))
        except Exception:  # noqa: BLE001 - evidence, not a reason to fail a test
            return None

    def _capture_page(self, page: Any, capture: PageCapture, slug: str) -> None:  # noqa: ANN401
        """Write the evidence a heal will need, while the page is still open."""
        if settings.capture_dom_snapshot:
            capture.dom_html = page.content()
            (self.artifacts_dir / f"{slug}-dom.html").write_text(capture.dom_html, encoding="utf-8")

        if settings.capture_screenshot:
            path = self.artifacts_dir / f"{slug}-screenshot.png"
            page.screenshot(path=str(path), full_page=True)
            capture.screenshot_path = str(path)

        if settings.capture_accessibility_tree:
            try:
                tree = page.accessibility.snapshot() or {}
            except Exception:  # noqa: BLE001 - absence of a tree is not a test failure
                tree = {}
            capture.accessibility_tree = tree
            if tree:
                (self.artifacts_dir / f"{slug}-accessibility.json").write_text(
                    json.dumps(tree, indent=2), encoding="utf-8"
                )

        logger.info(
            "evidence_captured",
            url=capture.url,
            failures=len(capture.failures),
            dom_bytes=len(capture.dom_html),
        )


def evidence_files(capture: PageCapture, artifacts_dir: Path, slug: str) -> list[dict[str, Any]]:
    """The artefacts this capture actually wrote, with their real sizes."""
    rows: list[dict[str, Any]] = []
    for artifact_type, filename, content_type in (
        ("screenshot", f"{slug}-screenshot.png", "image/png"),
        ("dom_snapshot", f"{slug}-dom.html", "text/html"),
        ("accessibility_tree", f"{slug}-accessibility.json", "application/json"),
        ("trace", f"{slug}-trace.zip", "application/zip"),
    ):
        path = artifacts_dir / filename
        if not path.is_file():
            continue
        rows.append(
            {
                "artifact_type": artifact_type,
                "name": filename,
                "storage_path": str(path),
                "content_type": content_type,
                "size_bytes": path.stat().st_size,
                "metadata": {
                    "captured_at": datetime.now(UTC).isoformat(),
                    "url": capture.url,
                    # It is on disk, and this says so truthfully.
                    "materialized": True,
                },
            }
        )
    return rows
