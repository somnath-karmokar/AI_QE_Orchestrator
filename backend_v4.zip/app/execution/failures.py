"""Failure taxonomy, signatures and clustering.

Three jobs, all deterministic:

  * **Classify** a failure into one of twelve categories, from the vocabulary of
    the message itself. Scored, not first-match-wins, and it reports how sure it
    is -- so an uncertain case can be sent to a model instead of guessed at.
  * **Signature** a failure: strip out everything incidental (ids, numbers,
    URLs, timings) so two reports of the same root cause read as the same string.
  * **Cluster** a run's failures by signature, so two hundred failures become the
    handful of distinct problems they actually are.

The last one is what keeps this affordable. Triaging failures one at a time
means one model call per failure; triaging clusters means one per *cause*, and a
big regression run is mostly the same few causes repeated.
"""

from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

# Categories are ordered by how specific their evidence is, which only matters
# for presentation -- selection is by score, never by position.
#
# `change_type` names what healing would have to alter (app.healing.policy).
# A category with no change type is not something healing may touch: it is a
# defect, an environment problem, or a test that needs a person.
FAILURE_CATEGORIES: dict[str, dict[str, Any]] = {
    "locator_drift": {
        "label": "Locator drift",
        "owner": "automation",
        "healable": True,
        "change_type": "locator",
        "guidance": "The UI moved or renamed the element; propose a more resilient locator.",
        "strong": (
            r"resolved to 0 elements",
            r"no element (?:matches|found)",
            r"unable to (?:find|locate) element",
            r"element is not attached to the dom",
            r"strict mode violation",
            r"selector .* (?:did not|didn't) match",
            r"nosuchelement",
        ),
        "weak": ("locator", "selector", "css", "xpath", "get_by_"),
    },
    "timing": {
        "label": "Timing / synchronisation",
        "owner": "automation",
        "healable": True,
        "change_type": "timing",
        "guidance": "Wait for the state the test depends on rather than a fixed delay.",
        "strong": (
            r"timeout \d+ms exceeded",
            r"timed out (?:after|waiting)",
            r"waiting for (?:element|locator|selector) .* to be",
            r"exceeded while waiting",
            r"still (?:not visible|hidden|disabled) after",
            r"race condition",
        ),
        "weak": ("timeout", "timed out", "not visible", "not stable", "flake"),
    },
    "navigation": {
        "label": "Navigation",
        "owner": "automation",
        "healable": True,
        "change_type": "navigation",
        "guidance": "The journey changed shape; the test is on the wrong page for this step.",
        "strong": (
            r"expected (?:url|page) .* but (?:was|got)",
            r"navigation (?:failed|timeout|interrupted)",
            r"err_too_many_redirects",
            r"page (?:did not|didn't) (?:load|navigate)",
            r"redirected to .* unexpectedly",
        ),
        "weak": ("redirect", "wrong page", "navigated"),
    },
    "test_data": {
        "label": "Test data",
        "owner": "qe",
        "healable": True,
        "change_type": "test_data",
        "guidance": "The record this test depends on is missing, expired or already used.",
        "strong": (
            r"no such record",
            r"(?:record|account|customer|order) (?:not found|does not exist|has expired)",
            r"data precondition failed",
            r"duplicate key",
            r"violates (?:unique|foreign key) constraint",
            r"fixture .* (?:unavailable|exhausted)",
            # An identifier usually sits between the noun and its state:
            # "the loyalty account LOY-2210 is closed".
            r"(?:account|card|customer|order|token)\b[^.]{0,30}?\b(?:is |was |has been )?"
            r"(?:closed|expired|locked|inactive|already used)",
        ),
        "weak": ("test data", "seed data", "precondition"),
    },
    "api_contract": {
        "label": "API contract change",
        "owner": "development",
        "healable": True,
        "change_type": "api_contract",
        "guidance": "The API this test calls changed shape; confirm the change was intended.",
        "strong": (
            r"(?:unexpected|unknown) (?:field|property|key)",
            r"(?:missing|required) (?:field|property) .* in response",
            r"schema validation failed",
            r"(?:response|payload) (?:does not match|did not match) .*schema",
            r"http 40[09]\b.*(?:contract|schema|version)",
            r"deserializ\w+ (?:error|failed)",
        ),
        "weak": ("schema", "contract", "payload shape"),
    },
    "assertion_mismatch": {
        "label": "Assertion mismatch",
        "owner": "qe",
        "healable": False,
        "change_type": None,
        "guidance": (
            "Expected and actual differ. Decide whether the application is wrong or the "
            "expectation is out of date -- healing may not decide this."
        ),
        "strong": (
            r"assertionerror",
            # An expectation about the url or the page is a navigation problem,
            # not a disagreement about a value, so leave those to `navigation`.
            r"expected (?!url\b|page\b)\S.* (?:but|to be|to equal|to have)",
            r"assert .* ==",
            r"to have text .* received",
            r"values? (?:do not|don't) match",
        ),
        "weak": ("mismatch", "expected", "assertion"),
    },
    "application_defect": {
        "label": "Application defect",
        "owner": "development",
        "healable": False,
        "change_type": None,
        "guidance": "The application returned an error; raise a defect.",
        "strong": (
            r"\b50[0-9]\b.*(?:internal server|server error)",
            r"internal server error",
            r"unhandled (?:exception|error) in",
            r"stack ?trace.*at (?:com|org|app)\.",
            r"nullpointerexception|typeerror: cannot read",
        ),
        "weak": ("server error", "exception thrown"),
    },
    "authentication": {
        "label": "Authentication / session",
        "owner": "platform",
        "healable": False,
        "change_type": None,
        "guidance": "The session could not be established or did not survive; check credentials and token life.",
        "strong": (
            r"\b401\b|unauthori[sz]ed",
            r"\b403\b|forbidden",
            r"(?:session|token) (?:expired|invalid|rejected)",
            r"login (?:failed|unsuccessful)",
            r"mfa|two[- ]factor",
        ),
        "weak": ("credentials", "sign in failed", "permission denied"),
    },
    "environment": {
        "label": "Environment",
        "owner": "platform",
        "healable": False,
        "change_type": None,
        "guidance": "The environment was not healthy; verify service health before re-running.",
        "strong": (
            r"err_connection_refused|econnrefused",
            r"\b50[23]\b|service unavailable|bad gateway",
            r"could not resolve host|enotfound|dns",
            r"(?:database|service) (?:is )?(?:down|unavailable)",
            r"out of (?:memory|disk)",
        ),
        "weak": ("unreachable", "connection", "deploy in progress"),
    },
    "network": {
        "label": "Network",
        "owner": "platform",
        "healable": False,
        "change_type": None,
        "guidance": "A request did not complete; distinguish a flaky link from a broken service.",
        "strong": (
            r"econnreset|socket hang up",
            r"net::err_(?:network|internet|name_not)",
            r"request (?:aborted|timed out) after",
            r"tls|ssl (?:handshake )?(?:error|failure)",
            r"proxy (?:error|refused)",
        ),
        "weak": ("network", "packet", "latency"),
    },
    "browser_crash": {
        "label": "Browser crashed",
        "owner": "platform",
        "healable": False,
        "change_type": None,
        "guidance": "The browser or page died mid-test; the result says nothing about the application.",
        "strong": (
            r"target (?:page|closed|crashed)",
            r"browser (?:has been )?(?:closed|disconnected|crashed)",
            r"page crashed",
            r"session (?:deleted|not created)",
            r"renderer process",
        ),
        "weak": ("crash", "disconnected"),
    },
    "test_logic": {
        "label": "Test logic error",
        "owner": "automation",
        "healable": False,
        "change_type": None,
        "guidance": "The test itself is wrong -- a person must fix it; healing may not rewrite test logic.",
        "strong": (
            r"syntaxerror|indentationerror|importerror|modulenotfounderror",
            r"fixture '.*' not found",
            r"takes \d+ positional arguments? but \d+",
            r"attributeerror: .* has no attribute",
            r"name '.*' is not defined",
        ),
        "weak": ("traceback (most recent call last)",),
    },
}

UNKNOWN = {
    "label": "Unclassified",
    "owner": "qe",
    "healable": False,
    "change_type": None,
    "guidance": "Not enough signal in the failure message; read the trace and the screenshot.",
}

# A strong signal is worth much more than a weak one: weak markers are single
# words that appear in plenty of unrelated messages.
STRONG_WEIGHT = 1.0
WEAK_WEIGHT = 0.18

# Below this, the deterministic classifier says so instead of guessing. Those
# cases are what an LLM is actually useful for.
CONFIDENT_SCORE = 0.55
# Two categories this close together means the message supports both readings.
DECISIVE_MARGIN = 0.15


@dataclass(slots=True)
class Classification:
    category: str
    label: str
    owner: str
    healable: bool
    change_type: str | None
    guidance: str
    confidence: float
    matched: list[str] = field(default_factory=list)
    runner_up: str | None = None
    # True when the message does not decide it. Ask a model, or ask a person.
    needs_review: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category,
            "label": self.label,
            "owner": self.owner,
            "healable": self.healable,
            "change_type": self.change_type,
            "guidance": self.guidance,
            "confidence": self.confidence,
            "matched": self.matched,
            "runner_up": self.runner_up,
            "needs_review": self.needs_review,
        }


def _score(text: str, spec: dict[str, Any]) -> tuple[float, list[str]]:
    score = 0.0
    matched: list[str] = []
    for pattern in spec.get("strong", ()):
        if re.search(pattern, text):
            score += STRONG_WEIGHT
            matched.append(pattern)
    for marker in spec.get("weak", ()):
        if marker in text:
            score += WEAK_WEIGHT
            matched.append(marker)
    return score, matched


def classify(message: str | None, *, stack_trace: str | None = None) -> Classification:
    """Classify a failure from its own text, and say how sure that is."""
    text = " ".join(f"{message or ''} {stack_trace or ''}".lower().split())
    if not text.strip():
        return Classification(
            category="unknown", confidence=0.0, needs_review=True, **_unknown_fields()
        )

    scores: list[tuple[float, str, list[str]]] = []
    for key, spec in FAILURE_CATEGORIES.items():
        score, matched = _score(text, spec)
        if score > 0:
            scores.append((score, key, matched))

    if not scores:
        return Classification(
            category="unknown", confidence=0.0, needs_review=True, **_unknown_fields()
        )

    scores.sort(key=lambda row: row[0], reverse=True)
    top_score, category, matched = scores[0]
    runner_up = scores[1][1] if len(scores) > 1 else None
    runner_up_score = scores[1][0] if len(scores) > 1 else 0.0

    total = sum(row[0] for row in scores)
    confidence = round(top_score / total, 4) if total else 0.0
    margin = round((top_score - runner_up_score) / total, 4) if total else 0.0

    spec = FAILURE_CATEGORIES[category]
    return Classification(
        category=category,
        label=spec["label"],
        owner=spec["owner"],
        healable=spec["healable"],
        change_type=spec["change_type"],
        guidance=spec["guidance"],
        confidence=confidence,
        matched=matched[:6],
        runner_up=runner_up,
        needs_review=confidence < CONFIDENT_SCORE or margin < DECISIVE_MARGIN,
    )


def _unknown_fields() -> dict[str, Any]:
    return {
        "label": UNKNOWN["label"],
        "owner": UNKNOWN["owner"],
        "healable": UNKNOWN["healable"],
        "change_type": UNKNOWN["change_type"],
        "guidance": UNKNOWN["guidance"],
        "matched": [],
    }


# ---------------------------------------------------------------------------
# Signatures
# ---------------------------------------------------------------------------

# Everything incidental to *what went wrong*: two runs of the same fault differ
# only in these, so they are removed before signing.
_NOISE: tuple[tuple[str, str], ...] = (
    (r"https?://[^\s\"')]+", "<url>"),
    (r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", "<uuid>"),
    (r"\b[0-9a-f]{16,}\b", "<hash>"),
    (r"\b\d+\s*ms\b", "<duration>"),
    (r"\b\d{1,3}(?:[.,]\d{3})+(?:[.,]\d+)?\b", "<amount>"),
    (r"\b\d{4}-\d{2}-\d{2}[t ]?[\d:.]*\b", "<timestamp>"),
    (r"\bline \d+\b", "line <n>"),
    (r"\b\d+\b", "<n>"),
    (r"0x[0-9a-f]+", "<addr>"),
    (r"[\\/][^\s\"']*[\\/][^\s\"']*", "<path>"),
)


def normalise_message(message: str | None) -> str:
    """The stable part of a failure message: what is wrong, not which run."""
    text = (message or "").strip().lower()
    for pattern, replacement in _NOISE:
        text = re.sub(pattern, replacement, text)
    return " ".join(text.split())[:300]


def failure_signature(message: str | None, *, category: str | None = None) -> str:
    """A short, stable key for "this exact problem".

    Two failures with the same signature have the same cause and deserve one
    investigation between them, not one each.
    """
    normalised = normalise_message(message)
    if not normalised:
        return "EMPTY"
    prefix = (category or classify(message).category).upper()[:18]
    digest = hashlib.sha1(normalised.encode("utf-8")).hexdigest()[:8]  # noqa: S324 - a key, not a secret
    return f"{prefix}-{digest}"


# ---------------------------------------------------------------------------
# Clustering
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class FailureCluster:
    """One distinct problem, and every test it broke."""

    signature: str
    classification: Classification
    representative_message: str
    test_ids: list[str] = field(default_factory=list)
    test_names: list[str] = field(default_factory=list)
    modules: list[str] = field(default_factory=list)

    @property
    def size(self) -> int:
        return len(self.test_ids)

    def to_dict(self) -> dict[str, Any]:
        return {
            "signature": self.signature,
            "size": self.size,
            "classification": self.classification.to_dict(),
            "representative_message": self.representative_message,
            "test_ids": self.test_ids,
            "test_names": self.test_names[:10],
            "modules": self.modules,
        }


def cluster_failures(tests: list[Any]) -> list[FailureCluster]:
    """Group failed tests by root cause, largest cluster first.

    `tests` are ExecutionTest rows (anything with `failure_message`, `name`,
    `module` and `id` will do).
    """
    grouped: dict[str, list[Any]] = defaultdict(list)
    classifications: dict[str, Classification] = {}

    for test in tests:
        if getattr(test, "result", None) not in {"failed", "flaky"}:
            continue
        message = getattr(test, "failure_message", None)
        classification = classify(message, stack_trace=getattr(test, "stack_trace", None))
        signature = failure_signature(message, category=classification.category)
        grouped[signature].append(test)
        classifications.setdefault(signature, classification)

    clusters = [
        FailureCluster(
            signature=signature,
            classification=classifications[signature],
            representative_message=(getattr(members[0], "failure_message", "") or "")[:400],
            test_ids=[member.id for member in members],
            test_names=[getattr(member, "name", "") or "" for member in members],
            modules=sorted({getattr(member, "module", None) or "unknown" for member in members}),
        )
        for signature, members in grouped.items()
    ]
    clusters.sort(key=lambda cluster: (cluster.size, cluster.classification.confidence), reverse=True)
    return clusters


def triage_summary(clusters: list[FailureCluster]) -> dict[str, Any]:
    """What a run's failures amount to, and how much work triage actually is."""
    failures = sum(cluster.size for cluster in clusters)
    by_category: dict[str, int] = defaultdict(int)
    for cluster in clusters:
        by_category[cluster.classification.category] += cluster.size

    uncertain = [cluster for cluster in clusters if cluster.classification.needs_review]
    healable = [cluster for cluster in clusters if cluster.classification.healable]
    return {
        "failures": failures,
        "distinct_causes": len(clusters),
        # The reason clustering exists: this is how many investigations, and how
        # many model calls, the run actually needs.
        "investigations_saved": max(0, failures - len(clusters)),
        "by_category": dict(by_category),
        "healable_causes": len(healable),
        "healable_failures": sum(cluster.size for cluster in healable),
        "needs_review_causes": len(uncertain),
        "largest_cluster": clusters[0].to_dict() if clusters else None,
    }


# ---------------------------------------------------------------------------
# Compatibility with the original two-value interface
# ---------------------------------------------------------------------------


def classify_failure(message: str | None) -> tuple[str, dict[str, Any]]:
    """The older `(key, spec)` shape, kept so existing callers still work."""
    result = classify(message)
    if result.category == "unknown":
        return "unknown", dict(UNKNOWN)
    return result.category, FAILURE_CATEGORIES[result.category]
