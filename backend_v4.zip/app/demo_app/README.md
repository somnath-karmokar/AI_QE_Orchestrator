# Demo application under test

A deliberately small retail checkout, served by the platform itself, so self-healing
can be demonstrated against a **real browser and real DOM** rather than described.

Two versions of the same page:

| Route | Meaning |
|---|---|
| `/demo-app/v1/checkout` | The markup the tests were written against |
| `/demo-app/v2/checkout` | The same page after a front-end redesign |

What changed in v2 is what actually changes in real projects:

| | v1 | v2 |
|---|---|---|
| Submit control | `data-testid="checkout-submit-btn"` | `data-testid="pay-now"` |
| Its markup | `<button class="btn-primary">` | `<button class="ui-Button ui-Button--cta">` |
| Its accessible name | "Pay now" | "Pay now" (unchanged) |
| Promo field | `data-testid="promo-code"` | `data-testid="discount-code"` |
| Its label | "Promo code" | "Promo code" (unchanged) |

So a test pinned to `data-testid` breaks, while the accessible role, name and label survive —
which is exactly why the healing strategy ladder prefers them. The heal is not a lucky guess;
it is the platform choosing the locator that was always the more durable one.

Nothing here is part of the product. It exists so a demonstration can be honest.
