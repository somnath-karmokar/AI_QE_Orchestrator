"""Document chunking for the Knowledge Fabric.

Chunks respect structural boundaries (headings, bullet lists, acceptance
criteria) before falling back to sentence packing, so a retrieved chunk reads as
a coherent unit rather than a sentence fragment.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any

DEFAULT_CHUNK_TOKENS = 320
DEFAULT_OVERLAP_TOKENS = 48
_CHARS_PER_TOKEN = 4

_HEADING = re.compile(r"^(#{1,6}\s+.+|[A-Z][A-Za-z0-9 /&-]{3,60}:)\s*$")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")


@dataclass(slots=True)
class Chunk:
    index: int
    content: str
    token_estimate: int
    heading: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


def estimate_tokens(text: str) -> int:
    return max(1, len(text) // _CHARS_PER_TOKEN)


def checksum(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _split_sections(text: str) -> list[tuple[str | None, str]]:
    """Split on headings, keeping each heading with the body that follows it."""
    sections: list[tuple[str | None, str]] = []
    current_heading: str | None = None
    buffer: list[str] = []

    for line in text.splitlines():
        if _HEADING.match(line.strip()) and line.strip():
            if buffer:
                sections.append((current_heading, "\n".join(buffer).strip()))
                buffer = []
            current_heading = line.strip().lstrip("#").strip().rstrip(":")
        else:
            buffer.append(line)

    if buffer:
        sections.append((current_heading, "\n".join(buffer).strip()))
    return [(heading, body) for heading, body in sections if body]


def _pack_sentences(body: str, max_tokens: int, overlap_tokens: int) -> list[str]:
    """Greedily pack sentences up to the budget, carrying an overlap tail."""
    sentences = [sentence.strip() for sentence in _SENTENCE_SPLIT.split(body) if sentence.strip()]
    if not sentences:
        return []

    packed: list[str] = []
    current: list[str] = []
    current_tokens = 0

    for sentence in sentences:
        sentence_tokens = estimate_tokens(sentence)
        if current and current_tokens + sentence_tokens > max_tokens:
            packed.append(" ".join(current))
            # Carry the tail forward so a fact split across a boundary is still
            # retrievable from either chunk.
            overlap: list[str] = []
            overlap_budget = overlap_tokens
            for previous in reversed(current):
                previous_tokens = estimate_tokens(previous)
                if previous_tokens > overlap_budget:
                    break
                overlap.insert(0, previous)
                overlap_budget -= previous_tokens
            current = overlap
            current_tokens = sum(estimate_tokens(item) for item in current)
        current.append(sentence)
        current_tokens += sentence_tokens

    if current:
        packed.append(" ".join(current))
    return packed


def chunk_document(
    content: str,
    *,
    title: str | None = None,
    max_tokens: int = DEFAULT_CHUNK_TOKENS,
    overlap_tokens: int = DEFAULT_OVERLAP_TOKENS,
) -> list[Chunk]:
    """Split a document into retrieval-sized chunks with structural context."""
    text = (content or "").strip()
    if not text:
        return []

    chunks: list[Chunk] = []
    index = 0

    for heading, body in _split_sections(text) or [(None, text)]:
        if estimate_tokens(body) <= max_tokens:
            pieces = [body]
        else:
            pieces = _pack_sentences(body, max_tokens, overlap_tokens) or [body]

        for piece in pieces:
            # Prefixing title/heading keeps each chunk self-describing, which
            # measurably improves retrieval on short queries.
            prefix_parts = [part for part in (title, heading) if part]
            prefixed = f"{' > '.join(prefix_parts)}\n{piece}" if prefix_parts else piece
            chunks.append(
                Chunk(
                    index=index,
                    content=prefixed.strip(),
                    token_estimate=estimate_tokens(prefixed),
                    heading=heading,
                )
            )
            index += 1

    return chunks
