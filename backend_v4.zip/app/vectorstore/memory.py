"""In-memory vector store used only as a degraded fallback.

Chroma is the mandated store. This exists so that a machine without the
`chromadb` package still boots and demonstrates retrieval rather than failing
outright -- it reports `status: "degraded"` so the Settings screen shows the
platform is not running on its real vector database. It is never selected when
Chroma is importable.
"""

from __future__ import annotations

import math
from datetime import UTC, datetime
from typing import Any

from app.core.logging import get_logger
from app.vectorstore.base import (
    ALL_COLLECTIONS,
    COLLECTION_DESCRIPTIONS,
    SearchResult,
    VectorRecord,
    VectorStore,
    sanitize_metadata,
)

logger = get_logger(__name__)


def cosine_similarity(left: list[float], right: list[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=False))
    norm_left = math.sqrt(sum(a * a for a in left))
    norm_right = math.sqrt(sum(b * b for b in right))
    if norm_left == 0 or norm_right == 0:
        return 0.0
    return dot / (norm_left * norm_right)


def _matches(metadata: dict[str, Any], where: dict[str, Any] | None) -> bool:
    """Evaluate the subset of Chroma's `where` grammar the platform emits."""
    if not where:
        return True
    if "$and" in where:
        return all(_matches(metadata, clause) for clause in where["$and"])
    if "$or" in where:
        return any(_matches(metadata, clause) for clause in where["$or"])
    for key, condition in where.items():
        value = metadata.get(key)
        if isinstance(condition, dict):
            for operator, operand in condition.items():
                if operator == "$eq" and value != operand:
                    return False
                if operator == "$ne" and value == operand:
                    return False
                if operator == "$in" and value not in operand:
                    return False
                if operator == "$nin" and value in operand:
                    return False
                if operator == "$gt" and not (value is not None and value > operand):
                    return False
                if operator == "$gte" and not (value is not None and value >= operand):
                    return False
                if operator == "$lt" and not (value is not None and value < operand):
                    return False
                if operator == "$lte" and not (value is not None and value <= operand):
                    return False
        elif value != condition:
            return False
    return True


class InMemoryVectorStore(VectorStore):
    provider = "memory"

    def __init__(self) -> None:
        self._data: dict[str, dict[str, VectorRecord]] = {}

    def ensure_collection(self, name: str, *, metadata: dict[str, Any] | None = None) -> None:
        self._data.setdefault(name, {})

    def upsert(self, collection: str, records: list[VectorRecord]) -> int:
        self.ensure_collection(collection)
        for record in records:
            self._data[collection][record.id] = VectorRecord(
                id=record.id,
                content=record.content,
                metadata=sanitize_metadata(record.metadata),
                embedding=record.embedding,
            )
        return len(records)

    def query(
        self,
        collection: str,
        query_embedding: list[float],
        *,
        limit: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        self.ensure_collection(collection)
        scored: list[SearchResult] = []
        for record in self._data[collection].values():
            if not _matches(record.metadata, where):
                continue
            similarity = cosine_similarity(query_embedding, record.embedding or [])
            scored.append(
                SearchResult(
                    id=record.id,
                    content=record.content,
                    metadata=record.metadata,
                    score=max(0.0, similarity),
                    distance=1.0 - similarity,
                )
            )
        scored.sort(key=lambda result: result.score, reverse=True)
        return scored[:limit]

    def delete_by_source(self, collection: str, *, project_id: str, source_id: str) -> int:
        self.ensure_collection(collection)
        doomed = [
            record_id
            for record_id, record in self._data[collection].items()
            if record.metadata.get("project_id") == project_id
            and record.metadata.get("source_id") == source_id
        ]
        for record_id in doomed:
            del self._data[collection][record_id]
        return len(doomed)

    def delete_by_document(self, collection: str, *, document_id: str) -> int:
        self.ensure_collection(collection)
        doomed = [
            record_id
            for record_id, record in self._data[collection].items()
            if record.metadata.get("document_id") == document_id
        ]
        for record_id in doomed:
            del self._data[collection][record_id]
        return len(doomed)

    def count(self, collection: str, *, where: dict[str, Any] | None = None) -> int:
        self.ensure_collection(collection)
        if where is None:
            return len(self._data[collection])
        return sum(1 for record in self._data[collection].values() if _matches(record.metadata, where))

    def reset_collection(self, name: str) -> None:
        self._data[name] = {}

    def list_collections(self) -> list[dict[str, Any]]:
        for name in ALL_COLLECTIONS:
            self.ensure_collection(name)
        return [
            {
                "name": name,
                "description": COLLECTION_DESCRIPTIONS.get(name, ""),
                "vector_count": len(records),
                "status": "degraded",
            }
            for name, records in self._data.items()
        ]

    def health(self) -> dict[str, Any]:
        collections = self.list_collections()
        return {
            "provider": self.provider,
            "status": "degraded",
            "mode": "in_memory",
            "detail": "Chroma is unavailable; retrieval is running on a non-persistent fallback store.",
            "checked_at": datetime.now(UTC).isoformat(),
            "collections": collections,
            "total_vectors": sum(item["vector_count"] for item in collections),
        }
