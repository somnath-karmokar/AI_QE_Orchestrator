"""Vector store selection: Chroma when available, degraded fallback otherwise."""

from __future__ import annotations

import threading

from app.core.logging import get_logger
from app.vectorstore.base import VectorStore
from app.core.mode import forbid_stand_in
from app.vectorstore.chroma.store import ChromaVectorStore
from app.vectorstore.memory import InMemoryVectorStore

logger = get_logger(__name__)

_store: VectorStore | None = None
_lock = threading.Lock()


def get_vector_store() -> VectorStore:
    """Return the process-wide vector store singleton."""
    global _store
    if _store is not None:
        return _store
    with _lock:
        if _store is not None:
            return _store
        store: VectorStore = ChromaVectorStore()
        try:
            store.bootstrap()  # type: ignore[attr-defined]
            logger.info("vector_store_ready", provider="chroma")
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "chroma_unavailable_using_fallback",
                error=str(exc)[:220],
                impact="Retrieval is non-persistent until Chroma is reachable.",
            )
            forbid_stand_in(
                "the vector store",
                "Chroma is unreachable, so retrieval would silently stop persisting.",
                "Set CHROMA_HOST and CHROMA_PORT, or set APP_MODE=local.",
            )
            store = InMemoryVectorStore()
        _store = store
        return _store


def reset_vector_store() -> None:
    """Drop the cached instance (used by tests and by configuration changes)."""
    global _store
    with _lock:
        _store = None
