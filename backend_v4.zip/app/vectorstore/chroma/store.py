"""Chroma vector store implementation (mandatory backing store, spec section 8).

Runs in two modes, chosen purely by configuration:

  * persistent -- local on-disk client (`CHROMA_PERSIST_DIRECTORY`), used for
    local development and demonstrations;
  * server     -- HTTP client against a Chroma deployment (`CHROMA_HOST` /
    `CHROMA_PORT` / `CHROMA_TENANT` / `CHROMA_DATABASE`).

Embeddings are supplied by the platform's embedding pipeline, never by Chroma's
built-in embedding functions, so the configured Azure OpenAI / OpenAI embedding
model is always the one in use.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any, TypeVar

from app.core.config import settings
from app.core.errors import ProviderError
from app.core.logging import get_logger
from app.vectorstore.base import (
    ALL_COLLECTIONS,
    COLLECTION_DESCRIPTIONS,
    SearchResult,
    VectorRecord,
    VectorStore,
    sanitize_metadata,
)

logger = get_logger(__name__)

T = TypeVar("T")


class ChromaVectorStore(VectorStore):
    """Thin, well-behaved wrapper over the Chroma client."""

    provider = "chroma"

    def __init__(self) -> None:
        self._client: Any = None
        self._collections: dict[str, Any] = {}
        self._mode = "server" if settings.chroma_server_mode else "persistent"

    # ----- client ------------------------------------------------------------
    @property
    def client(self) -> Any:
        if self._client is None:
            self._client = self._create_client()
        return self._client

    def _create_client(self) -> Any:
        try:
            import chromadb  # noqa: PLC0415
            from chromadb.config import Settings as ChromaSettings  # noqa: PLC0415
        except ImportError as exc:  # pragma: no cover
            raise ProviderError(
                "The 'chromadb' package is required for the Knowledge Fabric. "
                "Install backend requirements to enable vector retrieval.",
                details={"missing_dependency": "chromadb"},
            ) from exc

        common = ChromaSettings(anonymized_telemetry=False, allow_reset=True)
        if settings.chroma_server_mode:
            logger.info("chroma_connect", mode="server", host=settings.chroma_host, port=settings.chroma_port)
            kwargs: dict[str, Any] = {
                "host": settings.chroma_host,
                "port": int(settings.chroma_port or 8000),
                "settings": common,
            }
            if settings.chroma_tenant:
                kwargs["tenant"] = settings.chroma_tenant
            if settings.chroma_database:
                kwargs["database"] = settings.chroma_database
            return chromadb.HttpClient(**kwargs)

        logger.info("chroma_connect", mode="persistent", path=settings.chroma_persist_directory)
        return chromadb.PersistentClient(path=settings.chroma_persist_directory, settings=common)

    # ----- collections -------------------------------------------------------
    def ensure_collection(self, name: str, *, metadata: dict[str, Any] | None = None) -> None:
        if name in self._collections:
            return
        collection_metadata = {
            "description": COLLECTION_DESCRIPTIONS.get(name, "AI QE Orchestrator collection"),
            "created_at": datetime.now(UTC).isoformat(),
            # Cosine matches the normalised embeddings the pipeline produces.
            "hnsw:space": "cosine",
            **(metadata or {}),
        }
        self._collections[name] = self.client.get_or_create_collection(
            name=name, metadata=collection_metadata
        )

    def _collection(self, name: str) -> Any:
        self.ensure_collection(name)
        return self._collections[name]

    def _invalidate(self, name: str | None = None) -> None:
        """Drop cached collection handles so the next access re-resolves them."""
        if name is None:
            self._collections.clear()
        else:
            self._collections.pop(name, None)

    def _with_collection(self, name: str, operation: Callable[[Any], T]) -> T:
        """Run an operation against a collection, re-resolving a stale handle once.

        A cached handle goes stale whenever the collection is dropped and
        recreated elsewhere -- most commonly a demo reset run from another
        process. Retrying once with a fresh handle turns a hard failure into a
        transparent recovery.
        """
        try:
            return operation(self._collection(name))
        except Exception as exc:  # noqa: BLE001
            logger.debug("chroma_handle_refresh", collection=name, error=str(exc)[:160])
            self._invalidate(name)
            return operation(self._collection(name))

    def bootstrap(self) -> None:
        """Create every specified collection up front so the UI has real status."""
        for name in ALL_COLLECTIONS:
            try:
                self.ensure_collection(name)
            except Exception as exc:  # noqa: BLE001
                logger.warning("chroma_collection_bootstrap_failed", collection=name, error=str(exc)[:200])

    # ----- writes ------------------------------------------------------------
    def upsert(self, collection: str, records: list[VectorRecord]) -> int:
        if not records:
            return 0
        self._with_collection(
            collection,
            lambda handle: handle.upsert(
                ids=[record.id for record in records],
                documents=[record.content for record in records],
                embeddings=[record.embedding for record in records],
                metadatas=[sanitize_metadata(record.metadata) for record in records],
            ),
        )
        logger.debug("chroma_upsert", collection=collection, count=len(records))
        return len(records)

    def delete_by_source(self, collection: str, *, project_id: str, source_id: str) -> int:
        where = {"$and": [{"project_id": {"$eq": project_id}}, {"source_id": {"$eq": source_id}}]}
        before = self.count(collection, where=where)
        self._with_collection(collection, lambda handle: handle.delete(where=where))
        return before

    def delete_by_document(self, collection: str, *, document_id: str) -> int:
        where = {"document_id": {"$eq": document_id}}
        before = self.count(collection, where=where)
        self._with_collection(collection, lambda handle: handle.delete(where=where))
        return before

    def reset_collection(self, name: str) -> None:
        self._invalidate(name)
        try:
            self.client.delete_collection(name)
        except Exception as exc:  # noqa: BLE001 - absent collection is fine
            logger.debug("chroma_delete_collection_skipped", collection=name, error=str(exc)[:120])
        self._collections.pop(name, None)
        self.ensure_collection(name)

    # ----- reads -------------------------------------------------------------
    def query(
        self,
        collection: str,
        query_embedding: list[float],
        *,
        limit: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        try:
            raw = self._with_collection(
                collection,
                lambda handle: handle.query(
                    query_embeddings=[query_embedding],
                    n_results=max(1, limit),
                    where=where,
                    include=["documents", "metadatas", "distances"],
                ),
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("chroma_query_failed", collection=collection, error=str(exc)[:200])
            return []

        ids = (raw.get("ids") or [[]])[0]
        documents = (raw.get("documents") or [[]])[0]
        metadatas = (raw.get("metadatas") or [[]])[0]
        distances = (raw.get("distances") or [[]])[0]

        results: list[SearchResult] = []
        for index, record_id in enumerate(ids):
            distance = float(distances[index]) if index < len(distances) else 1.0
            results.append(
                SearchResult(
                    id=record_id,
                    content=documents[index] if index < len(documents) else "",
                    metadata=dict(metadatas[index] or {}) if index < len(metadatas) else {},
                    # Cosine distance in [0, 2] -> similarity in [0, 1].
                    score=max(0.0, 1.0 - (distance / 2.0)),
                    distance=distance,
                )
            )
        return results

    def count(self, collection: str, *, where: dict[str, Any] | None = None) -> int:
        try:
            if where is None:
                return int(self._with_collection(collection, lambda handle: handle.count()))
            found = self._with_collection(
                collection, lambda handle: handle.get(where=where, include=[])
            )
            return len(found.get("ids", []))
        except Exception as exc:  # noqa: BLE001
            logger.warning("chroma_count_failed", collection=collection, error=str(exc)[:200])
            return 0

    def list_collections(self) -> list[dict[str, Any]]:
        report: list[dict[str, Any]] = []
        for name in ALL_COLLECTIONS:
            try:
                report.append(
                    {
                        "name": name,
                        "description": COLLECTION_DESCRIPTIONS.get(name, ""),
                        "vector_count": int(
                            self._with_collection(name, lambda handle: handle.count())
                        ),
                        "status": "healthy",
                    }
                )
            except Exception as exc:  # noqa: BLE001
                report.append(
                    {
                        "name": name,
                        "description": COLLECTION_DESCRIPTIONS.get(name, ""),
                        "vector_count": 0,
                        "status": "error",
                        "error": str(exc)[:200],
                    }
                )
        return report

    def health(self) -> dict[str, Any]:
        try:
            heartbeat = self.client.heartbeat()
            collections = self.list_collections()
            return {
                "provider": self.provider,
                "status": "connected",
                "mode": self._mode,
                "heartbeat_ns": heartbeat,
                "persist_directory": None if self._mode == "server" else settings.chroma_persist_directory,
                "host": settings.chroma_host if self._mode == "server" else None,
                "port": settings.chroma_port if self._mode == "server" else None,
                "tenant": settings.chroma_tenant,
                "database": settings.chroma_database,
                "collections": collections,
                "total_vectors": sum(item.get("vector_count", 0) for item in collections),
            }
        except Exception as exc:  # noqa: BLE001
            return {
                "provider": self.provider,
                "status": "error",
                "mode": self._mode,
                "detail": str(exc)[:300],
                "collections": [],
                "total_vectors": 0,
            }
