"""Vector store contract.

All retrieval in the platform goes through this interface, backed by Chroma
(spec section 8). Nothing else in the codebase may talk to a vector database
directly.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any

# Collections defined by the specification.
COLLECTION_REQUIREMENTS = "qe_requirements"
COLLECTION_KNOWLEDGE = "qe_knowledge"
COLLECTION_TEST_CASES = "qe_test_cases"
COLLECTION_DEFECTS = "qe_defects"
COLLECTION_EXECUTION_HISTORY = "qe_execution_history"
COLLECTION_CODE_CONTEXT = "qe_code_context"
# Powers conversational agent selection: the copilot matches a user's intent
# against embedded agent capability descriptions rather than keywords.
COLLECTION_AGENT_CATALOG = "qe_agent_catalog"

ALL_COLLECTIONS: tuple[str, ...] = (
    COLLECTION_REQUIREMENTS,
    COLLECTION_KNOWLEDGE,
    COLLECTION_TEST_CASES,
    COLLECTION_DEFECTS,
    COLLECTION_EXECUTION_HISTORY,
    COLLECTION_CODE_CONTEXT,
    COLLECTION_AGENT_CATALOG,
)

COLLECTION_DESCRIPTIONS: dict[str, str] = {
    COLLECTION_REQUIREMENTS: "Requirements, user stories and acceptance criteria.",
    COLLECTION_KNOWLEDGE: "Confluence pages, SOPs, architecture and framework documentation.",
    COLLECTION_TEST_CASES: "Test scenarios and test cases, used for reuse and duplicate detection.",
    COLLECTION_DEFECTS: "Defect records used for similarity search and duplicate triage.",
    COLLECTION_EXECUTION_HISTORY: "Historical failures and signatures used as RCA evidence.",
    COLLECTION_CODE_CONTEXT: "Repository, framework and utility code context.",
    COLLECTION_AGENT_CATALOG: "Agent capability descriptions, used for conversational agent selection.",
}

# Metadata keys every vector record must carry (spec section 8).
REQUIRED_METADATA_KEYS: tuple[str, ...] = (
    "project_id",
    "source_type",
    "source_id",
    "document_id",
    "document_version",
    "chunk_id",
    "module",
    "artifact_type",
    "created_at",
    "access_scope",
)

# Never embed or store these -- guards against credential leakage into vectors.
FORBIDDEN_METADATA_KEYS: frozenset[str] = frozenset(
    {"api_key", "password", "secret", "token", "credential", "connection_string"}
)


@dataclass(slots=True)
class VectorRecord:
    """One embeddable chunk plus its filterable metadata."""

    id: str
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    embedding: list[float] | None = None


@dataclass(slots=True)
class SearchResult:
    id: str
    content: str
    metadata: dict[str, Any]
    score: float
    distance: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata,
            "score": round(self.score, 4),
            "distance": round(self.distance, 4),
        }


class VectorStore(abc.ABC):
    """Interface implemented by `ChromaVectorStore` (and the in-memory fallback)."""

    provider: str = "base"

    @abc.abstractmethod
    def ensure_collection(self, name: str, *, metadata: dict[str, Any] | None = None) -> None: ...

    @abc.abstractmethod
    def upsert(self, collection: str, records: list[VectorRecord]) -> int: ...

    @abc.abstractmethod
    def query(
        self,
        collection: str,
        query_embedding: list[float],
        *,
        limit: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[SearchResult]: ...

    @abc.abstractmethod
    def delete_by_source(self, collection: str, *, project_id: str, source_id: str) -> int: ...

    @abc.abstractmethod
    def delete_by_document(self, collection: str, *, document_id: str) -> int: ...

    @abc.abstractmethod
    def count(self, collection: str, *, where: dict[str, Any] | None = None) -> int: ...

    @abc.abstractmethod
    def list_collections(self) -> list[dict[str, Any]]: ...

    @abc.abstractmethod
    def health(self) -> dict[str, Any]: ...

    @abc.abstractmethod
    def reset_collection(self, name: str) -> None: ...


def sanitize_metadata(metadata: dict[str, Any]) -> dict[str, Any]:
    """Strip secrets and coerce values to Chroma-compatible scalars.

    Chroma metadata accepts only str/int/float/bool, so lists are joined and
    nested objects are dropped rather than silently failing at insert time.
    """
    clean: dict[str, Any] = {}
    for key, value in metadata.items():
        if any(marker in key.lower() for marker in FORBIDDEN_METADATA_KEYS):
            continue
        if value is None:
            continue
        if isinstance(value, (str, int, float, bool)):
            clean[key] = value
        elif isinstance(value, (list, tuple, set)):
            flattened = [str(item) for item in value if isinstance(item, (str, int, float, bool))]
            if flattened:
                clean[key] = ",".join(flattened)
        # Nested dicts are intentionally omitted.
    return clean


def build_where(
    project_id: str | None = None, *, require_project: bool = True, **filters: Any
) -> dict[str, Any] | None:
    """Compose a Chroma `where` clause, always scoping to a project when given.

    Project scoping is what prevents cross-project retrieval (spec section 8).

    Embeddings from every project share one collection, so this clause is the
    whole boundary -- and `if project_id:` treats an empty string or None as
    "no filter", which silently widens a search to every tenant's documents
    instead of failing. That is the worst shape a security bug can take, so it
    now raises. Pass `require_project=False` only for a deliberately
    platform-wide operation.
    """
    clauses: list[dict[str, Any]] = []
    if project_id:
        clauses.append({"project_id": {"$eq": project_id}})
    elif require_project:
        raise ValueError(
            "A project_id is required to query the vector store; refusing to "
            "search across every project."
        )
    for key, value in filters.items():
        if value is None:
            continue
        if isinstance(value, (list, tuple, set)):
            values = [item for item in value if item is not None]
            if values:
                clauses.append({key: {"$in": list(values)}})
        else:
            clauses.append({key: {"$eq": value}})

    if not clauses:
        return None
    if len(clauses) == 1:
        return clauses[0]
    return {"$and": clauses}
