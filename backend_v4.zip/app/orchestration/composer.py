"""Compose a governed flow from a plain-English description.

"Check PAY-201 is ready; if it scores below 80 get business sign-off; then
generate scenarios, test cases and test data" becomes a real, runnable graph:
agents in the order they were described, a decision where the text branches,
and approval gates where it asks for a person.

Two signals pick each agent, so drafts are predictable yet not brittle:

  * capability phrases ("test data", "root cause", "playwright") found in the
    text, kept in the order they appear;
  * for a sentence no phrase covers, the copilot's own ranking -- intent
    classification plus semantic similarity over the agent catalogue.

Nothing is saved here. The composer returns a draft with the reason for every
step; the user reviews it and creates the flow, which stays fully editable.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.copilot.planner import CONFIDENCE_FLOOR, CopilotPlanner
from app.core.logging import get_logger
from app.models.agent import Agent
from app.models.project import Project
from app.models.testing import Requirement

logger = get_logger(__name__)

# Capability phrase -> agent key. Earlier rules win where matches overlap.
CAPABILITY_RULES: list[tuple[str, str]] = [
    (r"\b(readiness|ready for test\w*|completeness|well[- ]formed|story quality)\b", "user-story-completeness"),
    (r"\b(domain knowledge|business rules?|knowledge base)\b", "test-knowledge"),
    (r"\bscenarios?\b", "test-scenario-generator"),
    (r"\b(test cases?|test design)\b", "test-design"),
    (r"\b(test data|synthetic data|data sets?)\b", "test-data-generator"),
    (r"\b(playwright|automation scripts?|automated scripts?|automate)\b", "auto-script-generator"),
    (r"\b(execute|execution|run the (tests|suite|regression)|run tests)\b", "automated-test-execution"),
    (r"\b(failure analysis|analy[sz]e (the )?failures?|classify (the )?failures?|triage)\b", "automation-failure-analysis"),
    (r"\b(root cause|rca)\b", "automated-rca"),
    (r"\b(self[- ]heal\w*|heal (the )?locators?|broken locators?)\b", "self-healing-automation"),
    (r"\b(defects?|bugs?|jira tickets?)\b", "jira-defect-assistant"),
    (r"\b(regression|retest\w*)\b", "regression-suite-optimization"),
    (r"\b(defect risk|predict\w*|riskiest)\b", "defect-prediction"),
    (r"\b(coverage|traceability)\b", "traceability-coverage"),
    (r"\b(accessibility|wcag|a11y)\b", "accessibility-test"),
    (r"\b(uat|user acceptance)\b", "uat-assistant"),
    (r"\b(duplicates?|duplicated)\b", "duplicate-test-detection"),
    (r"\b(performance|load test\w*|k6|locust)\b", "performance-test-generator"),
    (r"\b(observability|flaky|quality trends?)\b", "observability"),
]

APPROVAL_PATTERN = re.compile(
    r"\b(approv\w*|sign[\s-]?off|signs? off|human review|manual review|reviewed by|review by|lead review)\b",
    re.IGNORECASE,
)
CONDITION_PATTERN = re.compile(r"\b(if|only when|only if|unless|when (it|the \w+) (scores?|is))\b", re.IGNORECASE)
COMPARISON_HINT = re.compile(
    r"\b(\d{1,3}|below|above|under|over|less|more|at least|scores?|threshold|confiden\w*|pass\w*|fail\w*)\b",
    re.IGNORECASE,
)
NUMBER_PATTERN = re.compile(r"\b(\d{1,3})\s*%?")
CLAUSE_BOUNDARY = re.compile(r"[.;:\n]|\bthen\b|\bafter that\b|\bfinally\b", re.IGNORECASE)
STORY_KEY = re.compile(r"\b[A-Z][A-Z0-9]{1,9}-\d{1,6}\b")

# "raise defects after QE lead approval": the gate comes before the work it guards.
GATE_FIRST = re.compile(r"\b(after|once|following|subject to|with)\b[\w\s-]{0,30}$", re.IGNORECASE)

SCHEDULE_HINTS: list[tuple[re.Pattern[str], dict[str, Any]]] = [
    (re.compile(r"\b(hourly|every hour)\b", re.IGNORECASE), {"frequency": "hourly", "time": "00:00"}),
    (re.compile(r"\b(nightly|every night|overnight)\b", re.IGNORECASE), {"frequency": "daily", "time": "02:00"}),
    (re.compile(r"\b(every morning)\b", re.IGNORECASE), {"frequency": "daily", "time": "07:00"}),
    (re.compile(r"\b(daily|every day)\b", re.IGNORECASE), {"frequency": "daily", "time": "06:00"}),
    (re.compile(r"\b(weekly|every week)\b", re.IGNORECASE), {"frequency": "weekly", "time": "07:00", "weekday": 0}),
]
WEEKDAY_NAMES = ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")

ROLE_HINTS: list[tuple[str, str]] = [
    ("business", "business_user"),
    ("product owner", "business_user"),
    ("uat", "business_user"),
    ("admin", "admin"),
]
ROLE_LABELS = {"business_user": "Business sign-off", "admin": "Admin approval", "qe_lead": "QE Lead approval"}

MAIN_X = 120
BRANCH_X = 460
ROW_HEIGHT = 150


@dataclass
class _Event:
    position: int
    kind: str  # agent | approval | condition
    phrase: str
    clause: int
    reason: str
    agent: Agent | None = None
    role: str = "qe_lead"
    threshold: int | None = None


@dataclass
class ComposedStep:
    node_key: str
    node_type: str
    label: str
    reason: str
    agent_key: str | None = None
    agent_name: str | None = None
    risk_level: str | None = None
    branch: str | None = None  # "false" for the alternate path of a decision


@dataclass
class Composition:
    name: str
    description: str
    steps: list[ComposedStep] = field(default_factory=list)
    nodes: list[dict[str, Any]] = field(default_factory=list)
    edges: list[dict[str, Any]] = field(default_factory=list)
    variables: dict[str, Any] = field(default_factory=dict)
    schedule: dict[str, Any] | None = None
    warnings: list[str] = field(default_factory=list)

    @property
    def agent_keys(self) -> list[str]:
        return [step.agent_key for step in self.steps if step.agent_key]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "steps": [asdict(step) for step in self.steps],
            "nodes": self.nodes,
            "edges": self.edges,
            "variables": self.variables,
            "schedule": self.schedule,
            "warnings": self.warnings,
            "agent_count": len(self.agent_keys),
            "approval_gates": sum(
                1 for node in self.nodes if node["node_type"] == "approval" or node.get("requires_approval")
            ),
            "conditions": sum(1 for node in self.nodes if node["node_type"] == "condition"),
        }


class FlowComposer:
    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    def compose(self, description: str, project: Project, *, name: str | None = None) -> Composition:
        text = " ".join((description or "").split())
        agents = self._agents(project)
        events = self._phrase_events(text, agents)
        events.extend(self._semantic_events(text, project, agents, events))
        events = self._tidy(sorted(events, key=lambda event: event.position))

        composition = Composition(name="", description=text)
        variables = self._variables(text, project, events)
        self._build_graph(composition, events, variables)
        composition.variables = variables
        composition.schedule = self._schedule(text)
        composition.name = (name or "").strip() or self._suggest_name(events)

        if not composition.agent_keys:
            composition.warnings.append(
                "No agent matched the description. Name the work to be done, for example "
                "“check story readiness, then generate test scenarios”."
            )
        for key, value in variables.items():
            if value in ("", None):
                composition.warnings.append(f"Set “{key}” before the first run.")
        return composition

    # ------------------------------------------------------------------
    # Understanding the description
    # ------------------------------------------------------------------
    def _agents(self, project: Project) -> dict[str, Agent]:
        rows = self.session.execute(
            select(Agent).where(
                Agent.is_deleted.is_(False),
                Agent.is_published.is_(True),
                (Agent.project_id.is_(None)) | (Agent.project_id == project.id),
            )
        ).scalars()
        return {agent.key: agent for agent in rows}

    @staticmethod
    def _clauses(text: str) -> list[tuple[int, int]]:
        """(start, end) spans of the clauses the description is made of."""
        spans, start = [], 0
        for boundary in CLAUSE_BOUNDARY.finditer(text):
            spans.append((start, boundary.start()))
            start = boundary.end()
        spans.append((start, len(text)))
        return [(s, e) for s, e in spans if text[s:e].strip()]

    def _clause_index(self, text: str, position: int) -> int:
        for index, (start, end) in enumerate(self._clauses(text)):
            if start <= position <= end:
                return index
        return -1

    def _clause_text(self, text: str, position: int) -> str:
        for start, end in self._clauses(text):
            if start <= position <= end:
                return text[start:end].strip()
        return ""

    def _phrase_events(self, text: str, agents: dict[str, Agent]) -> list[_Event]:
        events: list[_Event] = []
        claimed: list[tuple[int, int]] = []

        for pattern, agent_key in CAPABILITY_RULES:
            agent = agents.get(agent_key)
            if agent is None:
                continue
            for match in re.finditer(pattern, text, re.IGNORECASE):
                if any(match.start() < end and start < match.end() for start, end in claimed):
                    continue
                claimed.append(match.span())
                events.append(
                    _Event(
                        position=match.start(),
                        kind="agent",
                        phrase=match.group(0),
                        clause=self._clause_index(text, match.start()),
                        agent=agent,
                        reason=f"You mentioned “{match.group(0)}”: {agent.name} does exactly that.",
                    )
                )

        for match in APPROVAL_PATTERN.finditer(text):
            clause = self._clause_text(text, match.start()).lower()
            role = next((role for hint, role in ROLE_HINTS if hint in clause), "qe_lead")
            position = match.start()
            if GATE_FIRST.search(text[max(0, position - 40):position]):
                guarded = [
                    event.position
                    for event in events
                    if event.kind == "agent"
                    and event.position < position
                    and event.clause == self._clause_index(text, position)
                ]
                if guarded:
                    position = max(guarded) - 1
            events.append(
                _Event(
                    position=position,
                    kind="approval",
                    phrase=match.group(0),
                    clause=self._clause_index(text, match.start()),
                    role=role,
                    reason=f"You asked for “{match.group(0)}”, so the run pauses until a person decides.",
                )
            )

        for match in CONDITION_PATTERN.finditer(text):
            clause = self._clause_text(text, match.start())
            tail = clause[max(0, clause.lower().find(match.group(0).lower())):]
            if not COMPARISON_HINT.search(tail):
                continue  # "check if the story..." is not a decision
            number = NUMBER_PATTERN.search(tail)
            events.append(
                _Event(
                    position=match.start(),
                    kind="condition",
                    phrase=tail[:90],
                    clause=self._clause_index(text, match.start()),
                    threshold=int(number.group(1)) if number else None,
                    reason=f"You described a decision: “{tail[:90]}”.",
                )
            )
        return events

    def _semantic_events(
        self, text: str, project: Project, agents: dict[str, Agent], events: list[_Event]
    ) -> list[_Event]:
        """Ask the copilot's ranking about sentences no capability phrase covered."""
        covered = {event.clause for event in events}
        planner: CopilotPlanner | None = None
        found: list[_Event] = []
        for index, (start, end) in enumerate(self._clauses(text)):
            clause = text[start:end].strip()
            if index in covered or len(clause.split()) < 3:
                continue
            try:
                planner = planner or CopilotPlanner(self.session)
                _, _, candidates = planner.rank_agents(clause, project)
            except Exception as exc:  # noqa: BLE001 - a ranking failure must not block composing
                logger.warning("composer_ranking_failed", error=str(exc)[:160])
                continue
            best = next((c for c in candidates if c.agent_key in agents), None)
            if best is None or best.score < CONFIDENCE_FLOOR:
                continue
            found.append(
                _Event(
                    position=start,
                    kind="agent",
                    phrase=clause,
                    clause=index,
                    agent=agents[best.agent_key],
                    reason=f"Closest match for “{clause[:70]}” ({round(best.score * 100)}% match).",
                )
            )
        return found

    @staticmethod
    def _tidy(events: list[_Event]) -> list[_Event]:
        """Drop repeats: an agent already in the flow, two approvals in one clause, back-to-back decisions."""
        tidy: list[_Event] = []
        seen_agents: set[str] = set()
        for event in events:
            previous = tidy[-1] if tidy else None
            if event.kind == "agent":
                if event.agent.key in seen_agents:
                    continue
                seen_agents.add(event.agent.key)
            if previous and event.kind == previous.kind == "approval" and event.clause == previous.clause:
                continue
            if previous and event.kind == previous.kind == "condition":
                continue
            tidy.append(event)
        return tidy

    # ------------------------------------------------------------------
    # Building the graph
    # ------------------------------------------------------------------
    def _build_graph(self, composition: Composition, events: list[_Event], variables: dict[str, Any]) -> None:
        nodes: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []
        used: set[str] = set()
        row = 0

        def add_node(base: str, node: dict[str, Any]) -> str:
            slug = re.sub(r"[^a-z0-9]+", "_", base.lower()).strip("_")[:40] or "step"
            key, suffix = slug, 2
            while key in used:
                key, suffix = f"{slug}_{suffix}", suffix + 1
            used.add(key)
            nodes.append({"node_key": key, **node})
            return key

        def connect(source: str, target: str, branch: str | None = None) -> None:
            edges.append({"source_node_key": source, "target_node_key": target, "branch_label": branch})

        # tail: where the main path continues; open_true: a decision whose "true"
        # path is the next main step; rejoin: alternate-path steps that merge back.
        tail = add_node("start", {"node_type": "start", "label": "Start", "position_x": MAIN_X, "position_y": 80})
        open_true: str | None = None
        rejoin: list[str] = []

        def append_main(base: str, node: dict[str, Any]) -> str:
            nonlocal row, tail, open_true, rejoin
            row += 1
            key = add_node(base, {**node, "position_x": MAIN_X, "position_y": 80 + row * ROW_HEIGHT})
            connect(tail, key, "true" if tail == open_true else None)
            for waiting in rejoin:
                connect(waiting, key)
            tail, open_true, rejoin = key, None, []
            return key

        last_agent: Agent | None = None
        index = 0
        while index < len(events):
            event = events[index]

            if event.kind == "agent":
                agent = event.agent
                key = append_main(
                    agent.key,
                    {
                        "node_type": "agent",
                        "label": agent.name,
                        "agent_id": agent.id,
                        "input_mapping": self._input_mapping(agent, variables),
                        "requires_approval": bool(agent.requires_approval),
                        "approval_role": "qe_lead" if agent.requires_approval else None,
                        "retry_policy": {"max_attempts": 2, "backoff_seconds": 2},
                    },
                )
                composition.steps.append(
                    ComposedStep(key, "agent", agent.name, event.reason, agent.key, agent.name, agent.risk_level)
                )
                last_agent = agent

            elif event.kind == "approval":
                label = ROLE_LABELS.get(event.role, "Human approval")
                key = append_main(
                    "approval",
                    {
                        "node_type": "approval",
                        "label": label,
                        "approval_role": event.role,
                        "config": {
                            "reason": f"Requested in the flow description: “{event.phrase}”.",
                            "risk_level": "medium",
                        },
                    },
                )
                composition.steps.append(ComposedStep(key, "approval", label, event.reason))

            elif event.kind == "condition":
                if last_agent is None:
                    composition.warnings.append(
                        f"“{event.phrase}” comes before any step it could check, so no decision was added."
                    )
                    index += 1
                    continue
                expression, label = self._condition(last_agent, event, variables)
                key = append_main(
                    "decision", {"node_type": "condition", "label": label, "condition_expression": expression}
                )
                composition.steps.append(ComposedStep(key, "condition", label, event.reason))

                following = events[index + 1] if index + 1 < len(events) else None
                branch_position = {"position_x": BRANCH_X, "position_y": 80 + (row + 1) * ROW_HEIGHT}
                if following is not None and following.kind == "approval" and following.clause == event.clause:
                    # "if it scores below 80, get business sign-off": the sign-off is
                    # the alternate path, and it rejoins the flow at the next step.
                    branch_label = ROLE_LABELS.get(following.role, "Human review")
                    branch_key = add_node(
                        "review",
                        {
                            "node_type": "approval",
                            "label": branch_label,
                            "approval_role": following.role,
                            "config": {"reason": f"The decision “{label}” was not met.", "risk_level": "medium"},
                            **branch_position,
                        },
                    )
                    composition.steps.append(
                        ComposedStep(branch_key, "approval", branch_label, following.reason, branch="false")
                    )
                    rejoin = [branch_key]
                    index += 1
                else:
                    branch_key = add_node(
                        "stopped", {"node_type": "end", "label": "Stopped: bar not met", **branch_position}
                    )
                connect(key, branch_key, "false")
                open_true = key

            index += 1

        append_main("end", {"node_type": "end", "label": "Complete"})
        composition.nodes = nodes
        composition.edges = edges

    @staticmethod
    def _condition(agent: Agent, event: _Event, variables: dict[str, Any]) -> tuple[str, str]:
        if agent.key == "user-story-completeness":
            variables["completeness_threshold"] = event.threshold or variables.get("completeness_threshold") or 80
            return "user_story_completeness.outputs.completeness_score >= completeness_threshold", "Story ready?"
        threshold = event.threshold or 80
        bar = threshold / 100 if threshold > 1 else float(threshold)
        return f"{agent.key.replace('-', '_')}.confidence >= {bar:.2f}", f"{agent.name} confident?"

    @staticmethod
    def _input_mapping(agent: Agent, variables: dict[str, Any]) -> dict[str, str]:
        properties = (agent.input_schema or {}).get("properties") or {}
        mapping = {name: f"${name}" for name in properties if name in variables}
        if agent.key == "user-story-completeness" and "completeness_threshold" in variables:
            mapping["threshold"] = "$completeness_threshold"
        return mapping

    # ------------------------------------------------------------------
    def _variables(self, text: str, project: Project, events: list[_Event]) -> dict[str, Any]:
        agents = [event.agent for event in events if event.kind == "agent" and event.agent]
        required: list[str] = []
        accepted: set[str] = set()
        for agent in agents:
            schema = agent.input_schema or {}
            accepted.update((schema.get("properties") or {}).keys())
            required.extend(name for name in schema.get("required") or [] if name not in required)

        # Values the description names go in; a required input it does not name
        # stays empty (and is flagged) rather than guessed.
        variables: dict[str, Any] = {}
        if "requirement_key" in accepted:
            known = set(
                self.session.execute(
                    select(Requirement.external_key).where(
                        Requirement.project_id == project.id, Requirement.is_deleted.is_(False)
                    )
                ).scalars()
            )
            mentioned = [key for key in STORY_KEY.findall(text) if key in known]
            if mentioned:
                variables["requirement_key"] = mentioned[0]
        if "module" in accepted:
            module = next((m for m in (project.modules or []) if m.lower() in text.lower()), None)
            if module:
                variables["module"] = module
        if "query" in required:
            variables["query"] = text[:200]
        for name in required:
            variables.setdefault(name, "")
        if any(agent.key == "user-story-completeness" for agent in agents):
            variables.setdefault("completeness_threshold", 80)
        return variables

    @staticmethod
    def _schedule(text: str) -> dict[str, Any] | None:
        """A suggested schedule when the description says how often the flow runs."""
        lowered = text.lower()
        for weekday, name in enumerate(WEEKDAY_NAMES):
            if re.search(rf"\bevery {name}\b|\bon {name}s\b", lowered):
                return {"enabled": True, "frequency": "weekly", "time": "07:00", "weekday": weekday}
        for pattern, schedule in SCHEDULE_HINTS:
            if pattern.search(text):
                return {"enabled": True, "weekday": 0, **schedule}
        return None

    @staticmethod
    def _suggest_name(events: list[_Event]) -> str:
        agents = [event.agent for event in events if event.kind == "agent" and event.agent]
        if not agents:
            return "Custom QE Flow"

        def short(agent: Agent) -> str:
            trimmed = re.sub(r"\b(Agent|Generator|Assistant|Automation|Automated|Detection|Check)\b", "", agent.name)
            return " ".join(trimmed.split()) or agent.name

        if len(agents) == 1:
            return f"{short(agents[0])} Flow"
        return f"{short(agents[0])} to {short(agents[-1])}"
