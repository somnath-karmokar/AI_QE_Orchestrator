"""Flow graph model, condition evaluation and validation.

A flow is a directed graph of typed nodes. This module owns the pure graph
concerns -- structure, reachability, condition expressions, topological order --
so the engine in `engine.py` deals only with execution.
"""

from __future__ import annotations

import ast
import operator
import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

from app.core.errors import ValidationError
from app.core.logging import get_logger
from app.models.flow import AgentFlow, AgentFlowEdge, AgentFlowNode

logger = get_logger(__name__)

TERMINAL_NODE_TYPES = {"end"}
AGENTIC_NODE_TYPES = {"agent"}


@dataclass
class FlowNode:
    key: str
    node_type: str
    label: str
    agent_id: str | None = None
    agent_version: str | None = None
    sequence: int = 0
    config: dict[str, Any] = field(default_factory=dict)
    input_mapping: dict[str, Any] = field(default_factory=dict)
    output_mapping: dict[str, Any] = field(default_factory=dict)
    condition_expression: str | None = None
    llm_config: dict[str, Any] = field(default_factory=dict)
    retry_policy: dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int | None = None
    on_failure: str = "fail_flow"
    requires_approval: bool = False
    approval_role: str | None = None
    cost_limit_usd: float | None = None
    position: tuple[float, float] = (0.0, 0.0)

    @classmethod
    def from_row(cls, row: AgentFlowNode) -> FlowNode:
        return cls(
            key=row.node_key,
            node_type=row.node_type,
            label=row.label,
            agent_id=row.agent_id,
            agent_version=row.agent_version,
            sequence=row.sequence,
            config=row.config or {},
            input_mapping=row.input_mapping or {},
            output_mapping=row.output_mapping or {},
            condition_expression=row.condition_expression,
            llm_config=row.llm_config or {},
            retry_policy=row.retry_policy or {},
            timeout_seconds=row.timeout_seconds,
            on_failure=row.on_failure,
            requires_approval=row.requires_approval,
            approval_role=row.approval_role,
            cost_limit_usd=row.cost_limit_usd,
            position=(row.position_x, row.position_y),
        )


@dataclass
class FlowEdge:
    source: str
    target: str
    branch_label: str | None = None
    condition_expression: str | None = None

    @classmethod
    def from_row(cls, row: AgentFlowEdge) -> FlowEdge:
        return cls(
            source=row.source_node_key,
            target=row.target_node_key,
            branch_label=row.branch_label,
            condition_expression=row.condition_expression,
        )


class FlowGraph:
    """Executable view of a stored flow."""

    def __init__(self, nodes: list[FlowNode], edges: list[FlowEdge], variables: dict[str, Any] | None = None):
        self.nodes: dict[str, FlowNode] = {node.key: node for node in nodes}
        self.edges = edges
        self.variables = variables or {}
        self._outgoing: dict[str, list[FlowEdge]] = defaultdict(list)
        self._incoming: dict[str, list[FlowEdge]] = defaultdict(list)
        for edge in edges:
            self._outgoing[edge.source].append(edge)
            self._incoming[edge.target].append(edge)

    @classmethod
    def from_flow(cls, flow: AgentFlow) -> FlowGraph:
        return cls(
            nodes=[FlowNode.from_row(row) for row in flow.nodes],
            edges=[FlowEdge.from_row(row) for row in flow.edges],
            variables=flow.variables or {},
        )

    @classmethod
    def from_payload(cls, nodes: list[dict[str, Any]], edges: list[dict[str, Any]]) -> FlowGraph:
        """A graph from unsaved node/edge dictionaries, e.g. a composer draft."""
        return cls(
            nodes=[
                FlowNode(
                    key=node["node_key"],
                    node_type=node["node_type"],
                    label=node.get("label", node["node_key"]),
                    agent_id=node.get("agent_id"),
                    condition_expression=node.get("condition_expression"),
                    requires_approval=bool(node.get("requires_approval")),
                    approval_role=node.get("approval_role"),
                    position=(node.get("position_x", 0.0), node.get("position_y", 0.0)),
                )
                for node in nodes
            ],
            edges=[
                FlowEdge(
                    source=edge["source_node_key"],
                    target=edge["target_node_key"],
                    branch_label=edge.get("branch_label"),
                    condition_expression=edge.get("condition_expression"),
                )
                for edge in edges
            ],
        )

    # ----- structure ---------------------------------------------------------
    def outgoing(self, node_key: str) -> list[FlowEdge]:
        return self._outgoing.get(node_key, [])

    def incoming(self, node_key: str) -> list[FlowEdge]:
        return self._incoming.get(node_key, [])

    def start_nodes(self) -> list[FlowNode]:
        explicit = [node for node in self.nodes.values() if node.node_type == "start"]
        if explicit:
            return explicit
        roots = [node for node in self.nodes.values() if not self._incoming.get(node.key)]
        return roots or sorted(self.nodes.values(), key=lambda node: node.sequence)[:1]

    def topological_order(self) -> list[str]:
        """Kahn's algorithm; nodes still unvisited after the sweep are in a cycle.

        Edges pointing at a node that no longer exists are ignored here. They are
        a real problem, but `validate()` reports them as dangling edges -- this
        method must not crash on a half-edited graph.
        """
        indegree = {
            key: sum(1 for edge in self._incoming.get(key, []) if edge.source in self.nodes)
            for key in self.nodes
        }
        queue = deque(sorted([key for key, degree in indegree.items() if degree == 0]))
        order: list[str] = []
        while queue:
            key = queue.popleft()
            order.append(key)
            for edge in self._outgoing.get(key, []):
                if edge.target not in indegree:
                    continue
                indegree[edge.target] -= 1
                if indegree[edge.target] == 0:
                    queue.append(edge.target)
        return order

    def has_cycle(self) -> bool:
        return len(self.topological_order()) != len(self.nodes)

    def unreachable_nodes(self) -> list[str]:
        reachable: set[str] = set()
        queue = deque(node.key for node in self.start_nodes())
        while queue:
            key = queue.popleft()
            if key in reachable:
                continue
            reachable.add(key)
            for edge in self._outgoing.get(key, []):
                if edge.target in self.nodes:
                    queue.append(edge.target)
        return sorted(set(self.nodes) - reachable)

    # ----- validation --------------------------------------------------------
    def validate(self) -> dict[str, Any]:
        """Structural validation surfaced in the Flow Builder before a run."""
        errors: list[dict[str, str]] = []
        warnings: list[dict[str, str]] = []

        if not self.nodes:
            errors.append({"code": "empty_flow", "message": "The flow contains no nodes."})
            return {"valid": False, "errors": errors, "warnings": warnings, "node_count": 0, "edge_count": 0}

        for edge in self.edges:
            if edge.source not in self.nodes:
                errors.append({"code": "dangling_edge", "message": f"Edge source '{edge.source}' does not exist."})
            if edge.target not in self.nodes:
                errors.append({"code": "dangling_edge", "message": f"Edge target '{edge.target}' does not exist."})

        if not self.start_nodes():
            errors.append({"code": "no_start", "message": "The flow has no start node and no root node."})

        if self.has_cycle():
            errors.append(
                {"code": "cycle", "message": "The flow contains a cycle; loops must use an explicit loop node."}
            )

        for node in self.nodes.values():
            if node.node_type == "agent" and not node.agent_id:
                errors.append(
                    {"code": "missing_agent", "message": f"Agent node '{node.label}' has no agent assigned."}
                )
            if node.node_type == "condition":
                if not node.condition_expression and not any(
                    edge.condition_expression for edge in self.outgoing(node.key)
                ):
                    errors.append(
                        {
                            "code": "missing_condition",
                            "message": f"Condition node '{node.label}' has no expression on the node or its edges.",
                        }
                    )
                branches = {edge.branch_label for edge in self.outgoing(node.key)}
                if not {"true", "false"}.issubset(branches) and len(self.outgoing(node.key)) < 2:
                    warnings.append(
                        {
                            "code": "single_branch",
                            "message": f"Condition '{node.label}' has one outgoing path; the alternate case ends the flow.",
                        }
                    )
            if node.node_type == "approval" and not node.approval_role:
                warnings.append(
                    {
                        "code": "no_approval_role",
                        "message": f"Approval node '{node.label}' has no role; the default QE Lead will be used.",
                    }
                )
            if node.node_type not in TERMINAL_NODE_TYPES and not self.outgoing(node.key):
                warnings.append(
                    {"code": "dead_end", "message": f"Node '{node.label}' has no outgoing path and ends the flow."}
                )

        for key in self.unreachable_nodes():
            warnings.append(
                {"code": "unreachable", "message": f"Node '{self.nodes[key].label}' is unreachable from the start."}
            )

        agent_nodes = [node for node in self.nodes.values() if node.node_type == "agent"]
        if not agent_nodes:
            warnings.append({"code": "no_agents", "message": "The flow contains no agent nodes."})

        return {
            "valid": not errors,
            "errors": errors,
            "warnings": warnings,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "agent_node_count": len(agent_nodes),
            "execution_order": self.topological_order(),
        }


# ---------------------------------------------------------------------------
# Condition evaluation
# ---------------------------------------------------------------------------

# A deliberately small expression language. Conditions come from user input, so
# evaluation is an AST walk over an allowlist -- never `eval`.
_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
}
_ALLOWED_COMPARE = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda left, right: left in right,
    ast.NotIn: lambda left, right: left not in right,
}

_VARIABLE_PATH = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_-]*)*$")


def resolve_path(context: dict[str, Any], path: str) -> Any:
    """Resolve `a.b.c` against nested dictionaries, returning None when absent."""
    current: Any = context
    for part in path.split("."):
        if isinstance(current, dict):
            if part in current:
                current = current[part]
                continue
            return None
        current = getattr(current, part, None)
        if current is None:
            return None
    return current


class _ConditionEvaluator(ast.NodeVisitor):
    def __init__(self, context: dict[str, Any]) -> None:
        self.context = context

    def visit(self, node: ast.AST) -> Any:  # noqa: ANN401
        method = getattr(self, f"visit_{type(node).__name__}", None)
        if method is None:
            raise ValidationError(f"Unsupported expression element: {type(node).__name__}.")
        return method(node)

    def visit_Expression(self, node: ast.Expression) -> Any:  # noqa: N802, ANN401
        return self.visit(node.body)

    def visit_Constant(self, node: ast.Constant) -> Any:  # noqa: N802, ANN401
        return node.value

    def visit_Name(self, node: ast.Name) -> Any:  # noqa: N802, ANN401
        if node.id in {"true", "True"}:
            return True
        if node.id in {"false", "False"}:
            return False
        if node.id in {"null", "None"}:
            return None
        return self.context.get(node.id)

    def visit_Attribute(self, node: ast.Attribute) -> Any:  # noqa: N802, ANN401
        parts: list[str] = []
        current: ast.AST = node
        while isinstance(current, ast.Attribute):
            parts.insert(0, current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.insert(0, current.id)
            return resolve_path(self.context, ".".join(parts))
        raise ValidationError("Only dotted variable paths are supported in conditions.")

    def visit_Subscript(self, node: ast.Subscript) -> Any:  # noqa: N802, ANN401
        container = self.visit(node.value)
        key = self.visit(node.slice)
        try:
            return container[key]
        except (KeyError, IndexError, TypeError):
            return None

    def visit_BoolOp(self, node: ast.BoolOp) -> Any:  # noqa: N802, ANN401
        values = [self.visit(value) for value in node.values]
        if isinstance(node.op, ast.And):
            return all(values)
        return any(values)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:  # noqa: N802, ANN401
        if isinstance(node.op, ast.Not):
            return not self.visit(node.operand)
        if isinstance(node.op, ast.USub):
            return -self.visit(node.operand)
        raise ValidationError("Unsupported unary operator in condition.")

    def visit_BinOp(self, node: ast.BinOp) -> Any:  # noqa: N802, ANN401
        handler = _ALLOWED_BINOPS.get(type(node.op))
        if handler is None:
            raise ValidationError("Unsupported arithmetic operator in condition.")
        return handler(self.visit(node.left), self.visit(node.right))

    def visit_Compare(self, node: ast.Compare) -> Any:  # noqa: N802, ANN401
        left = self.visit(node.left)
        for op, comparator in zip(node.ops, node.comparators, strict=False):
            handler = _ALLOWED_COMPARE.get(type(op))
            if handler is None:
                raise ValidationError("Unsupported comparison operator in condition.")
            right = self.visit(comparator)
            if left is None or right is None:
                # Missing data must not crash a run; treat as a failed comparison.
                if not isinstance(op, (ast.Eq, ast.NotEq, ast.In, ast.NotIn)):
                    return False
            if not handler(left, right):
                return False
            left = right
        return True

    def visit_List(self, node: ast.List) -> Any:  # noqa: N802, ANN401
        return [self.visit(element) for element in node.elts]

    def visit_Tuple(self, node: ast.Tuple) -> Any:  # noqa: N802, ANN401
        return tuple(self.visit(element) for element in node.elts)


def evaluate_condition(expression: str | None, context: dict[str, Any]) -> bool:
    """Evaluate a flow condition safely. An unparseable condition is False."""
    if not expression or not expression.strip():
        return True

    text = expression.strip()
    # Accept the friendlier operator spellings used in the Flow Builder UI.
    text = re.sub(r"\bAND\b", " and ", text)
    text = re.sub(r"\bOR\b", " or ", text)
    text = re.sub(r"\bNOT\b", " not ", text)

    try:
        tree = ast.parse(text, mode="eval")
        result = _ConditionEvaluator(context).visit(tree)
        return bool(result)
    except ValidationError:
        raise
    except SyntaxError as exc:
        raise ValidationError(
            f"Condition '{expression}' is not a valid expression.", details={"error": str(exc)}
        ) from exc
    except Exception as exc:  # noqa: BLE001
        logger.warning("condition_evaluation_failed", expression=expression, error=str(exc)[:160])
        return False


def apply_mapping(mapping: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    """Resolve an input/output mapping against the run context.

    Values may be literals, or `$path.to.value` references into run variables.
    """
    resolved: dict[str, Any] = {}
    for target, source in mapping.items():
        if isinstance(source, str) and source.startswith("$"):
            path = source[1:]
            if _VARIABLE_PATH.match(path):
                resolved[target] = resolve_path(context, path)
            else:
                resolved[target] = None
        else:
            resolved[target] = source
    return resolved
