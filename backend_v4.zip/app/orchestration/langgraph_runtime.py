"""Flow orchestration on LangGraph.

`FlowEngine` walks a stored flow with a worklist loop. This runtime replaces that
loop with LangGraph: the stored graph is compiled to a `StateGraph`, and
LangGraph decides what runs next, fans out to parallel branches, and stops.

What LangGraph owns
    Scheduling. Each flow node becomes a graph node, each edge a conditional
    edge, the run's variables are the graph *state*, and LangGraph executes the
    supersteps, merges parallel branches' updates, and enforces the step limit.

What stays on the platform
    Everything a node *does* -- running an agent, evaluating a condition,
    raising an approval, calling a tool, applying policy, recording the step --
    is the existing `FlowEngine` code, called unchanged. This class reimplements
    none of it, so an approval gate, a failure policy or a budget behaves the
    same on either runtime by construction rather than by parallel maintenance.

Why the ledger, not a LangGraph checkpointer
    A run is durable because every step is committed to the database as it
    completes (that is also the audit trail). A pause at an approval gate ends
    the graph run; resuming replays the completed steps from that ledger and
    continues. Adding a second store of run state -- a checkpointer -- would need
    keeping the two consistent, and the ledger is the record auditors read. So
    the checkpointer and `interrupt()` are deliberately not used.

Behaviour that differs from the native runtime, on purpose
    Parallel branches. Branches fanned out from one node run in the same LangGraph
    superstep: each sees the state as it was when they were scheduled, their
    updates merge at the end of the step, and they run in a deterministic order
    (LangGraph sorts them by node key) rather than edge order. The native loop
    ran them one after another, each seeing the last one's writes -- which made
    "parallel" a misnomer and let one branch depend on another by accident.
    They are still executed one at a time (`max_concurrency=1`): the node code
    shares one database session, which is not safe to use concurrently.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Annotated, Any, TypedDict

from langgraph.errors import GraphRecursionError
from langgraph.graph import END, START, StateGraph

from app.models.flow import AgentFlow
from app.models.project import Environment, Project
from app.models.run import AgentRun, AgentRunStep
from app.orchestration.engine import MAX_STEPS, FlowEngine
from app.orchestration.graph import FlowGraph

# LangGraph rejects these characters in a node name, and flow keys are free text.
_UNSAFE = re.compile(r"[:|]")


def _merge_variables(current: dict[str, Any] | None, update: dict[str, Any] | None) -> dict[str, Any]:
    """How parallel branches' writes to the shared variables combine."""
    return {**(current or {}), **(update or {})}


class FlowState(TypedDict):
    """The graph's state: the run variables every node reads and writes."""

    variables: Annotated[dict[str, Any], _merge_variables]


def graph_node_names(graph: FlowGraph) -> dict[str, str]:
    """Flow node key -> a name LangGraph will accept, unique within the graph."""
    names: dict[str, str] = {}
    used: set[str] = {START, END}
    for key in graph.nodes:
        name = _UNSAFE.sub("_", key) or "node"
        while name in used:
            name += "_"
        used.add(name)
        names[key] = name
    return names


def _changed(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    """Only the variables a node changed.

    Returning the whole dictionary would let a parallel sibling's stale copy of a
    variable overwrite this node's fresh value when the branches merge.
    """
    return {key: value for key, value in after.items() if key not in before or before[key] != value}


@dataclass
class _Walk:
    """Everything one walk of one run needs, shared by that walk's node functions.

    Node functions run one at a time (see the module docstring), so this is
    plain mutable state rather than something that needs locking.
    """

    run: AgentRun
    flow: AgentFlow
    graph: FlowGraph
    project: Project
    environment: Environment | None
    existing_steps: list[AgentRunStep]
    completed: set[str]
    names: dict[str, str] = field(default_factory=dict)
    visited: set[str] = field(default_factory=set)
    routes: dict[str, list[str]] = field(default_factory=dict)
    sequence: int = 0
    # Set when the flow stops: "awaiting_approval", "cancelled" or "completed".
    halt: str | None = None


class LangGraphFlowEngine(FlowEngine):
    """Runs a flow by compiling it to a LangGraph `StateGraph`."""

    engine_name = "langgraph"

    def _walk(
        self,
        run: AgentRun,
        flow: AgentFlow,
        graph: FlowGraph,
        project: Project,
        environment: Environment | None,
        variables: dict[str, Any],
    ) -> str:
        walk = self.new_walk(run, flow, graph, project, environment)
        compiled = self.compile(walk)

        try:
            final = compiled.invoke(
                {"variables": dict(variables)},
                config={
                    "recursion_limit": MAX_STEPS,
                    # One node at a time: they share this run's database session.
                    "max_concurrency": 1,
                    "run_name": f"flow:{flow.key}",
                    "metadata": {"run_id": run.id, "flow_id": flow.id, "project_id": run.project_id},
                },
            )
        except GraphRecursionError:
            self._log(run, "flow_guard", f"Step limit of {MAX_STEPS} reached; stopping.", {})
            return walk.halt or "completed"

        # The caller keeps this dictionary to persist at the end of the run.
        variables.update(final["variables"])
        return walk.halt or "completed"

    # ------------------------------------------------------------------
    # Compilation
    # ------------------------------------------------------------------
    def new_walk(
        self,
        run: AgentRun,
        flow: AgentFlow,
        graph: FlowGraph,
        project: Project,
        environment: Environment | None,
    ) -> _Walk:
        """The state for walking `run`, including what a previous attempt already finished."""
        existing_steps = self._steps(run)
        return _Walk(
            run=run,
            flow=flow,
            graph=graph,
            project=project,
            environment=environment,
            existing_steps=existing_steps,
            completed={step.node_key for step in existing_steps if step.status in {"succeeded", "skipped"}},
            sequence=len(existing_steps),
        )

    def compile(self, walk: _Walk):  # noqa: ANN201 - CompiledStateGraph
        """The stored flow as a LangGraph graph, wired to this run's node functions."""
        graph = walk.graph
        walk.names = graph_node_names(graph)

        builder = StateGraph(FlowState)
        for key in graph.nodes:
            builder.add_node(walk.names[key], self._node_function(walk, key))

        for node in graph.start_nodes():
            builder.add_edge(START, walk.names[node.key])

        for key in graph.nodes:
            # Every target this node *could* route to, so the compiled graph can be
            # drawn and inspected; which of them is taken is decided at run time.
            possible = sorted({edge.target for edge in graph.outgoing(key) if edge.target in graph.nodes})
            if possible:
                builder.add_conditional_edges(
                    walk.names[key],
                    self._router(walk, key),
                    [walk.names[target] for target in possible],
                )

        return builder.compile()

    def _router(self, walk: _Walk, key: str):  # noqa: ANN202
        """The conditional edge out of a node: whichever targets it decided on."""

        def route(state: FlowState) -> list[str]:  # noqa: ARG001
            targets = walk.routes.pop(key, [])
            return [walk.names[target] for target in targets if target in walk.names]

        return route

    def _node_function(self, walk: _Walk, key: str):  # noqa: ANN202
        """One flow node as a LangGraph node.

        The control flow here mirrors the native loop's checks, in the same order,
        because LangGraph can reach a node more than once (two branches meeting)
        where the loop's worklist could not.
        """
        node = walk.graph.nodes[key]

        def run_node(state: FlowState) -> dict[str, Any]:
            walk.routes[key] = []  # by default nothing follows: a skipped visit routes nowhere

            if walk.halt is not None:
                return {}  # an earlier node already stopped the flow
            if self.cancellation.is_cancelled:
                self._log(walk.run, "flow_cancelled", "Run cancelled by request.", {})
                walk.halt = "cancelled"
                return {}
            if key in walk.visited:
                return {}  # reached a second time; it has already run

            if node.node_type == "join":
                upstream = {edge.source for edge in walk.graph.incoming(key)}
                if not upstream.issubset(walk.visited | walk.completed):
                    return {}  # a later arrival will trigger it again

            walk.visited.add(key)
            variables = dict(state["variables"])
            before = dict(variables)

            if key in walk.completed:
                previous = next(step for step in walk.existing_steps if step.node_key == key)
                self._replay_step(node, previous, variables)
                walk.routes[key] = self._next_nodes(walk.graph, node, variables, walk.run)
                return {"variables": _changed(before, variables)}

            walk.sequence += 1
            self._pace(node)
            outcome = self._execute_node(
                walk.run,
                walk.flow,
                walk.graph,
                node,
                walk.sequence,
                walk.project,
                walk.environment,
                variables,
            )

            if outcome == "awaiting_approval":
                walk.halt = "awaiting_approval"
            elif outcome == "cancelled":
                walk.halt = "cancelled"
            elif outcome == "stop_flow":
                walk.halt = "completed"
            elif outcome == "stop_branch":
                pass  # this branch ends; the others carry on
            else:
                walk.routes[key] = self._next_nodes(walk.graph, node, variables, walk.run)

            return {"variables": _changed(before, variables)}

        return run_node


__all__ = ["FlowState", "LangGraphFlowEngine", "graph_node_names"]
