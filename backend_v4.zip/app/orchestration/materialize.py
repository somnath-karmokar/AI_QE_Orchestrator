"""Turn a flow definition (nodes, edges, variables) into a stored, validated flow.

One code path for the seeded demo flows, flows created from a template, and
flows drafted by the composer, so every flow starts life the same way:
validated, versioned and ready to run.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from app.models.agent import Agent
from app.models.flow import AgentFlow, AgentFlowEdge, AgentFlowNode, AgentFlowVersion
from app.models.project import Project
from app.orchestration.graph import FlowGraph


def materialize_flow(
    session: Session,
    project: Project,
    definition: dict[str, Any],
    agents: dict[str, Agent],
    *,
    key: str | None = None,
    name: str | None = None,
    status: str = "published",
    version: str = "1.0.0",
    is_template: bool = False,
    created_by: str | None = None,
    owner: str | None = None,
    default_environment_id: str | None = None,
    change_summary: str = "Initial version.",
    pin_agent_versions: bool = False,
) -> AgentFlow:
    """Create the flow, its nodes and edges, validate it and record its first version."""
    flow = AgentFlow(
        project_id=project.id,
        key=key or definition["key"],
        name=name or definition["name"],
        description=definition.get("description"),
        category=definition.get("category", "Custom"),
        status=status,
        version=version,
        is_template=is_template,
        trigger_type="manual",
        variables=dict(definition.get("variables") or {}),
        default_environment_id=default_environment_id,
        cost_budget_usd=float(definition.get("cost_budget_usd", 5.0)),
        token_budget=int(definition.get("token_budget", 150_000)),
        tags=list(definition.get("tags") or []),
        owner=owner or created_by,
        created_by=created_by,
        schedule={"enabled": False},
        governance=dict(definition.get("governance") or {"budget_alert_percent": 80, "notify_on_failure": True}),
    )
    session.add(flow)
    session.flush()

    for entry in definition["nodes"]:
        payload = dict(entry)
        agent_key = payload.pop("agent_key", None)
        agent = agents.get(agent_key) if agent_key else None
        session.add(
            AgentFlowNode(
                flow_id=flow.id,
                agent_id=payload.pop("agent_id", None) or (agent.id if agent else None),
                agent_version=payload.pop("agent_version", None)
                or (agent.version if agent is not None and pin_agent_versions else None),
                node_key=payload.pop("node_key"),
                node_type=payload.pop("node_type"),
                label=payload.pop("label"),
                position_x=payload.pop("position_x", 0.0),
                position_y=payload.pop("position_y", 0.0),
                sequence=payload.pop("sequence", 0),
                config=payload.pop("config", {}),
                input_mapping=payload.pop("input_mapping", {}),
                output_mapping=payload.pop("output_mapping", {}),
                condition_expression=payload.pop("condition_expression", None),
                retry_policy=payload.pop("retry_policy", {}),
                timeout_seconds=payload.pop("timeout_seconds", None),
                requires_approval=payload.pop("requires_approval", False),
                approval_role=payload.pop("approval_role", None),
                on_failure=payload.pop("on_failure", "fail_flow"),
                cost_limit_usd=payload.pop("cost_limit_usd", None),
            )
        )

    for edge in definition["edges"]:
        source, target, branch = edge if isinstance(edge, (list, tuple)) else (
            edge["source_node_key"], edge["target_node_key"], edge.get("branch_label")
        )
        session.add(
            AgentFlowEdge(flow_id=flow.id, source_node_key=source, target_node_key=target, branch_label=branch)
        )
    session.flush()

    session.refresh(flow)
    flow.validation_result = FlowGraph.from_flow(flow).validate()
    session.add(
        AgentFlowVersion(
            flow_id=flow.id,
            version=version,
            change_summary=change_summary,
            published_at=datetime.now(UTC) if status == "published" else None,
            graph_snapshot={
                "nodes": [node.node_key for node in flow.nodes],
                "edges": [{"source": edge.source_node_key, "target": edge.target_node_key} for edge in flow.edges],
            },
        )
    )
    session.flush()
    return flow
