"""Choosing the runtime that executes a flow.

`ORCHESTRATION_ENGINE` selects it. LangGraph is imported only when it is chosen,
so the native runtime works without the dependency installed.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.worker import CancellationToken
from app.orchestration.engine import FlowEngine


def build_engine(
    session: Session,
    *,
    cancellation: CancellationToken | None = None,
    kind: str | None = None,
) -> FlowEngine:
    """The engine for one run. `kind` overrides the setting (used by tests)."""
    chosen = kind or settings.orchestration_engine

    if chosen == "langgraph":
        from app.orchestration.langgraph_runtime import LangGraphFlowEngine  # noqa: PLC0415

        return LangGraphFlowEngine(session, cancellation=cancellation)
    if chosen == "native":
        return FlowEngine(session, cancellation=cancellation)
    raise ValueError(f"Unknown orchestration engine '{chosen}'. Use 'langgraph' or 'native'.")
