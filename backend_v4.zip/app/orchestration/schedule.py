"""Flow schedules: validation, next-run calculation and plain-English descriptions.

Schedules are deliberately simple -- hourly, daily or weekly at a time of day,
in UTC -- because that covers how QE flows actually run (nightly regression,
a weekly readiness report) and it is explainable to anyone at a glance.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from app.core.errors import ValidationError

FREQUENCIES = ("hourly", "daily", "weekly")
WEEKDAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")


def normalise_schedule(raw: dict[str, Any] | None) -> dict[str, Any]:
    """Validate a schedule payload and return it in canonical form."""
    if not raw:
        return {"enabled": False}
    enabled = bool(raw.get("enabled"))
    frequency = str(raw.get("frequency") or "daily")
    if frequency not in FREQUENCIES:
        raise ValidationError(f"Schedule frequency must be one of {', '.join(FREQUENCIES)}.")

    time_text = str(raw.get("time") or "07:00")
    try:
        hour, minute = (int(part) for part in time_text.split(":", 1))
    except ValueError as exc:
        raise ValidationError("Schedule time must look like HH:MM.") from exc
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValidationError("Schedule time must be a valid 24-hour time.")

    weekday = int(raw.get("weekday", 0))
    if not 0 <= weekday <= 6:
        raise ValidationError("Schedule weekday must be 0 (Monday) to 6 (Sunday).")

    return {
        "enabled": enabled,
        "frequency": frequency,
        "time": f"{hour:02d}:{minute:02d}",
        "weekday": weekday,
    }


def next_run_after(schedule: dict[str, Any] | None, after: datetime) -> datetime | None:
    """The first scheduled moment strictly after `after`, or None when disabled."""
    if not schedule or not schedule.get("enabled"):
        return None
    after = after.astimezone(UTC) if after.tzinfo else after.replace(tzinfo=UTC)
    hour, minute = (int(part) for part in str(schedule.get("time", "07:00")).split(":", 1))
    frequency = schedule.get("frequency", "daily")

    if frequency == "hourly":
        candidate = after.replace(minute=minute, second=0, microsecond=0)
        return candidate if candidate > after else candidate + timedelta(hours=1)

    candidate = after.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if frequency == "daily":
        return candidate if candidate > after else candidate + timedelta(days=1)

    days_ahead = (int(schedule.get("weekday", 0)) - after.weekday()) % 7
    candidate += timedelta(days=days_ahead)
    return candidate if candidate > after else candidate + timedelta(days=7)


def describe_schedule(schedule: dict[str, Any] | None) -> str:
    if not schedule or not schedule.get("enabled"):
        return "Not scheduled"
    frequency = schedule.get("frequency", "daily")
    time_text = schedule.get("time", "07:00")
    if frequency == "hourly":
        return f"Every hour at :{time_text.split(':', 1)[1]}"
    if frequency == "daily":
        return f"Daily at {time_text} UTC"
    return f"Every {WEEKDAYS[int(schedule.get('weekday', 0))]} at {time_text} UTC"
