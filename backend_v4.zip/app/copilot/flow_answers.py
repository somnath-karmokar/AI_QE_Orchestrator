"""Answers to questions about a flow, a run, or the flows in a project.

Every figure comes from the same services the Flow Studio screens use, so the
copilot and the UI can never disagree. Each answer carries the evidence it was
built from and a link to the screen that shows it in full.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.project import Project
from app.models.run import AgentRun
from app.orchestration.schedule import describe_schedule
from app.services.flow_insights import FlowInsights, studio_overview
from app.services.run_collaboration import run_collaboration

ROLE_LABELS = {
    "qe_lead": "QE Lead",
    "business_user": "Business / UAT",
    "qe_engineer": "QE Engineer",
    "admin": "Platform Admin",
}


@dataclass
class FlowAnswer:
    content: str
    evidence: list[dict[str, Any]] = field(default_factory=list)
    navigation: dict[str, Any] = field(default_factory=dict)
    suggestions: list[str] = field(default_factory=list)


def _person(email: str | None) -> str:
    if not email:
        return "nobody yet"
    if "@" not in email:
        return email
    return " ".join(part.capitalize() for part in email.split("@")[0].replace("-", ".").split(".") if part)


def _percent(value: float | None) -> str:
    return "not measurable yet" if value is None else f"{round(value * 100)}%"


def _duration(milliseconds: float | int | None) -> str:
    if not milliseconds:
        return "no time recorded"
    seconds = milliseconds / 1000
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes, rest = divmod(round(seconds), 60)
    if minutes < 60:
        return f"{minutes}m {rest:02d}s"
    hours, rest_minutes = divmod(minutes, 60)
    return f"{hours}h {rest_minutes:02d}m"


def _metric(label: str, value: str, detail: str | None = None) -> dict[str, Any]:
    return {"type": "metric", "label": label, "value": value, "detail": detail}


def _as_of() -> dict[str, Any]:
    return {
        "type": "source",
        "title": "Live platform state",
        "detail": f"Read from runs, approvals and audit entries at {datetime.now(UTC).strftime('%d %b %Y %H:%M UTC')}.",
    }


def _triggers(flow: AgentFlow) -> str:
    """How the flow can be started, as a sentence fragment."""
    parts = ["by hand"]
    if (flow.schedule or {}).get("enabled"):
        parts.append(describe_schedule(flow.schedule).lower())
    if flow.webhook_token_hash:
        parts.append("from the API")
    return ", ".join(parts)


def _trigger_chip(flow: AgentFlow) -> str:
    """How the flow can be started, as a short label."""
    parts = ["Manual"]
    if (flow.schedule or {}).get("enabled"):
        parts.append(describe_schedule(flow.schedule))
    if flow.webhook_token_hash:
        parts.append("API")
    return " · ".join(parts)


# ---------------------------------------------------------------------------
# What a flow is
# ---------------------------------------------------------------------------
def explain_flow(session: Session, flow: AgentFlow) -> FlowAnswer:
    nodes = sorted(flow.nodes, key=lambda node: (node.position_y, node.position_x))
    agents = {
        agent.id: agent
        for agent in session.execute(
            select(Agent).where(Agent.id.in_([node.agent_id for node in nodes if node.agent_id]))
        ).scalars()
    }
    steps = [node for node in nodes if node.node_type in {"agent", "approval", "condition"}]
    agent_steps = [node for node in steps if node.node_type == "agent"]
    gates = [node for node in steps if node.node_type == "approval" or node.requires_approval]
    decisions = [node for node in steps if node.node_type == "condition"]

    chain = " → ".join(
        (agents[node.agent_id].name if node.agent_id in agents else node.label)
        if node.node_type == "agent"
        else f"[{node.label}]"
        for node in steps[:8]
    )
    lines = [
        f"{flow.name} ({flow.status}, v{flow.version}) — {flow.description or 'no description recorded'}",
        f"It runs {len(agent_steps)} agents in this order: {chain}"
        + (f" and {len(steps) - 8} more steps." if len(steps) > 8 else "."),
    ]
    if gates:
        roles = {ROLE_LABELS.get(node.approval_role or "qe_lead", "QE Lead") for node in gates}
        lines.append(
            f"{len(gates)} step(s) pause for human approval by {', '.join(sorted(roles))}: "
            + ", ".join(node.label for node in gates[:3])
            + "."
        )
    else:
        lines.append("No step needs human approval.")
    if decisions:
        lines.append(
            "It branches at "
            + ", ".join(f"'{node.label}'" for node in decisions[:2])
            + f", so not every run takes the same path."
        )
    lines.append(
        f"Owned by {_person(flow.owner or flow.created_by)}; it can be started {_triggers(flow)}; "
        f"each run may spend up to €{flow.cost_budget_usd:.2f}."
    )
    if (flow.variables or {}):
        inputs = ", ".join(f"{key}" for key in list(flow.variables)[:5])
        lines.append(f"Run inputs: {inputs}.")

    return FlowAnswer(
        content="\n".join(lines),
        evidence=[
            _metric("Agents", str(len(agent_steps))),
            _metric("Approval gates", str(len(gates))),
            _metric("Budget per run", f"€{flow.cost_budget_usd:.2f}"),
            _metric("Triggers", _trigger_chip(flow)),
            _as_of(),
        ],
        navigation={"route": f"/flows/{flow.id}", "label": f"{flow.name} workspace"},
        suggestions=[
            f"How is {flow.name} doing?",
            f"Why did the last run of {flow.name} end that way?",
            f"Run {flow.name}",
        ],
    )


# ---------------------------------------------------------------------------
# How a flow is doing
# ---------------------------------------------------------------------------
def flow_health(session: Session, flow: AgentFlow, window_days: int = 30) -> FlowAnswer:
    insights = FlowInsights(session, flow)
    dashboard = insights.dashboard(window_days)
    kpis = dashboard["kpis"]
    observability = insights.observability(window_days)
    slo = observability["slo"]

    if not kpis["runs"]:
        return FlowAnswer(
            content=(
                f"{flow.name} has not run in the last {window_days} days, so there is nothing to report on its "
                f"health. It is {flow.status} and can be started {_triggers(flow)}."
            ),
            evidence=[_as_of()],
            navigation={"route": f"/flows/{flow.id}", "label": f"{flow.name} workspace"},
            suggestions=[f"What does {flow.name} do?", f"Run {flow.name}"],
        )

    delta = dashboard["deltas"]["success_rate"]
    trend = ""
    if delta is not None and abs(delta) >= 0.01:
        trend = f" That is {abs(delta) * 100:.0f} points {'better' if delta > 0 else 'worse'} than the previous {window_days} days."

    lines = [
        f"{flow.name} ran {kpis['runs']} times in the last {window_days} days and {_percent(kpis['success_rate'])} "
        f"of finished runs succeeded.{trend}",
        f"A typical run takes {_duration(kpis['p50_duration_ms'])} and costs €{kpis['avg_cost_usd']:.2f} against a "
        f"€{flow.cost_budget_usd:.2f} budget; the slowest 5% take {_duration(kpis['p95_duration_ms'])}.",
    ]
    if slo["status"] == "at_risk":
        lines.append(
            f"It is below its reliability target of {_percent(slo['target_success_rate'])}, so it counts as at risk."
        )
    elif slo["status"] == "healthy":
        lines.append(f"It is meeting its reliability target of {_percent(slo['target_success_rate'])}.")

    weakest = min(
        (row for row in dashboard["step_health"] if row["failures"] and row["success_rate"] is not None),
        key=lambda row: row["success_rate"],
        default=None,
    )
    if weakest:
        lines.append(
            f"The weakest step is '{weakest['label']}' at {_percent(weakest['success_rate'])}"
            + (f", most often: {weakest['top_error'].rstrip('.')}" if weakest["top_error"] else "")
            + "."
        )
    if dashboard["pending_approvals"]:
        lines.append(f"{len(dashboard['pending_approvals'])} run(s) are waiting for a human decision right now.")
    last = dashboard["last_run"]
    if last:
        lines.append(
            f"The last run (#{last['run_number']}) {last['status'].replace('_', ' ')} "
            f"and took {_duration(last['duration_ms'])}."
        )

    return FlowAnswer(
        content="\n".join(lines),
        evidence=[
            _metric("Runs", str(kpis["runs"]), f"last {window_days} days"),
            _metric("Success rate", _percent(kpis["success_rate"])),
            _metric("Typical run", _duration(kpis["p50_duration_ms"])),
            _metric("Cost per run", f"€{kpis['avg_cost_usd']:.2f}"),
            _metric("Effort saved", f"{kpis['hours_saved']} h", "estimated"),
            _as_of(),
        ],
        navigation={"route": f"/flows/{flow.id}", "label": f"{flow.name} dashboard"},
        suggestions=[
            f"Why did the last run of {flow.name} end that way?",
            f"What does {flow.name} do?",
            f"Is {flow.name} under control?",
        ],
    )


# ---------------------------------------------------------------------------
# Governance posture of a flow
# ---------------------------------------------------------------------------
def flow_governance(session: Session, flow: AgentFlow) -> FlowAnswer:
    governance = FlowInsights(session, flow).governance(90)
    posture = governance["posture"]
    failed = [check for check in posture["checks"] if check["status"] == "fail"]
    warned = [check for check in posture["checks"] if check["status"] == "warn"]
    approvals = governance["approvals"]
    settings = governance["settings"]

    lines = [
        f"{flow.name} passes {posture['passed']} of {posture['total']} governance checks.",
        f"It is owned by {_person(settings.get('owner'))}; "
        + (
            f"only {', '.join(ROLE_LABELS.get(role, role) for role in settings['run_roles'])} can run it."
            if settings.get("run_roles")
            else "anyone with run permission can run it."
        ),
    ]
    if failed:
        lines.append("Needs fixing: " + "; ".join(f"{check['title']} — {check['detail']}" for check in failed))
    if warned:
        lines.append("Worth a look: " + "; ".join(check["title"] for check in warned) + ".")
    if not failed and not warned:
        lines.append("Nothing is outstanding.")
    lines.append(
        f"{approvals['total']} human decisions were recorded in the last 90 days"
        + (
            f", taking a median of {approvals['median_decision_hours']} hours."
            if approvals["median_decision_hours"] is not None
            else "."
        )
    )
    budget = governance["budget"]
    lines.append(
        f"Runs stop at €{budget['per_run_budget_usd']:.2f}; the average run uses €{budget['avg_run_cost_usd']:.2f} "
        f"and {budget['runs_over_alert']} run(s) crossed the alert threshold."
    )

    return FlowAnswer(
        content="\n".join(lines),
        evidence=[
            _metric("Posture", f"{posture['passed']}/{posture['total']} checks"),
            _metric("Human decisions", str(approvals["total"]), "last 90 days"),
            _metric("Budget per run", f"€{budget['per_run_budget_usd']:.2f}"),
            _as_of(),
        ],
        navigation={"route": f"/flows/{flow.id}/governance", "label": f"{flow.name} governance"},
        suggestions=[f"How is {flow.name} doing?", f"What does {flow.name} do?"],
    )


# ---------------------------------------------------------------------------
# What happened in a run
# ---------------------------------------------------------------------------
def review_run(session: Session, run: AgentRun) -> FlowAnswer:
    view = run_collaboration(session, run)
    graph, stats = view["graph"], view["stats"]
    nodes = {node["node_key"]: node for node in graph["nodes"]}
    failed = [node for node in graph["nodes"] if node["state"] == "failed"]
    waiting = [node for node in graph["nodes"] if node["state"] == "awaiting_approval"]
    title = view["run"]["flow_name"] or run.title

    lines = [
        f"Run #{run.run_number} of {title} {run.status.replace('_', ' ')} "
        f"({view['run']['trigger']} trigger, {_duration(run.duration_ms)}, €{run.total_cost_usd:.2f})."
    ]
    if failed:
        node = failed[0]
        lines.append(
            f"It stopped at '{node['label']}': {node['error'] or 'no error was recorded'}"
            + (f" (attempt {node['attempt']})." if node.get("attempt", 1) > 1 else ".")
        )
        before = [item for item in graph["nodes"] if item["state"] == "succeeded" and item["node_type"] == "agent"]
        if before:
            lines.append(
                f"Everything before it completed: {', '.join(item['label'] for item in before[-3:])}."
            )
    elif waiting:
        lines.append(
            f"It is paused at '{waiting[0]['label']}' waiting for a human decision, so nothing after it has run yet."
        )
    else:
        handoffs = [message for message in view["conversation"] if message["kind"] == "handoff"]
        if handoffs:
            lines.append(
                "The agents handed over in order: "
                + " → ".join(nodes[message["node_key"]]["label"] for message in handoffs[:6] if message["node_key"] in nodes)
                + "."
            )
        last = handoffs[-1] if handoffs else None
        if last:
            lines.append(f"Final result: {last['text']}")

    decisions = [message for message in view["conversation"] if message["kind"] == "decision"]
    for decision in decisions[:2]:
        reads = decision["data"].get("reads") or []
        fact = f" ({reads[0]['path']} = {reads[0]['value']})" if reads else ""
        lines.append(f"Decision '{nodes.get(decision['node_key'], {}).get('label', 'decision')}'{fact}: {decision['text']}")

    approvals = [message for message in view["conversation"] if message["kind"] == "approval_decision"]
    for approval in approvals[:2]:
        who = next((p["name"] for p in view["participants"] if p["key"] == approval["from"]), "Someone")
        gate = nodes.get(approval["node_key"], {}).get("label", "a gate")
        lines.append(f"{who} decided at '{gate}': {approval['text']}")

    return FlowAnswer(
        content="\n".join(lines),
        evidence=[
            _metric("Steps", f"{run.completed_step_count}/{run.step_count}"),
            _metric("Duration", _duration(run.duration_ms)),
            _metric("Cost", f"€{run.total_cost_usd:.2f}"),
            _metric("Hand-offs", str(stats["handoffs"])),
            _as_of(),
        ],
        navigation={"route": f"/runs/{run.id}", "label": f"Run #{run.run_number} collaboration"},
        suggestions=[
            "Replay this run",
            f"How is {title} doing?",
            "Which flows need attention?",
        ],
    )


# ---------------------------------------------------------------------------
# The flows in a project
# ---------------------------------------------------------------------------
def flow_inventory(session: Session, project: Project, message: str) -> FlowAnswer:
    overview = studio_overview(session, project, 30)
    flows = overview["flows"]
    totals = overview["totals"]
    lowered = message.lower()

    if "schedul" in lowered:
        selected = [flow for flow in flows if (flow["schedule"] or {}).get("enabled")]
        headline = f"{len(selected)} of {totals['flows']} flows run on a schedule."
        describe = lambda flow: f"{flow['name']} — {flow['schedule_description']}"  # noqa: E731
    elif any(word in lowered for word in ("attention", "problem", "failing", "risk", "unhealthy", "broken")):
        selected = [
            flow
            for flow in flows
            if flow["pending_approvals"]
            or flow["last_status"] == "failed"
            or (flow["success_rate"] is not None and flow["success_rate"] < 0.9)
            or not flow["validation_valid"]
        ]
        headline = (
            f"{len(selected)} flow(s) need attention." if selected else "No flow needs attention right now."
        )
        describe = lambda flow: (  # noqa: E731
            f"{flow['name']} — {_percent(flow['success_rate'])} success"
            + (f", {flow['pending_approvals']} awaiting approval" if flow["pending_approvals"] else "")
            + (", last run failed" if flow["last_status"] == "failed" else "")
        )
    elif "api" in lowered or "ci" in lowered.split():
        selected = [flow for flow in flows if flow["api_trigger_enabled"]]
        headline = f"{len(selected)} flow(s) can be triggered from the API."
        describe = lambda flow: f"{flow['name']} — owned by {_person(flow['owner'])}"  # noqa: E731
    elif any(word in lowered for word in ("cost", "spend", "expensive")):
        selected = sorted(flows, key=lambda flow: -flow["total_cost_usd"])[:5]
        headline = f"AI spend across flows in the last 30 days is €{totals['total_cost_usd']:.2f}."
        describe = lambda flow: (  # noqa: E731
            f"{flow['name']} — €{flow['total_cost_usd']:.2f} over {flow['runs']} runs "
            f"(€{flow['avg_cost_usd']:.2f} each)"
        )
    else:
        selected = flows
        headline = (
            f"This project has {totals['flows']} flows ({totals['published']} published, "
            f"{totals['scheduled']} scheduled, {totals['api_enabled']} API-triggered). "
            f"They ran {totals['runs']} times in the last 30 days at {_percent(totals['success_rate'])} success."
        )
        describe = lambda flow: (  # noqa: E731
            f"{flow['name']} — {flow['runs']} runs, {_percent(flow['success_rate'])} success, "
            f"€{flow['avg_cost_usd']:.2f} per run"
        )

    lines = [headline]
    lines.extend(f"• {describe(flow)}" for flow in selected[:8])
    if len(selected) > 8:
        lines.append(f"…and {len(selected) - 8} more.")

    return FlowAnswer(
        content="\n".join(lines),
        evidence=[
            _metric("Flows", str(totals["flows"])),
            _metric("Runs", str(totals["runs"]), "last 30 days"),
            _metric("Success rate", _percent(totals["success_rate"])),
            _metric("AI spend", f"€{totals['total_cost_usd']:.2f}", "last 30 days"),
            _as_of(),
        ],
        navigation={"route": "/flows", "label": "Flow Studio"},
        suggestions=(
            [f"How is {selected[0]['name']} doing?", f"What does {selected[0]['name']} do?"] if selected else []
        )
        + ["Which flows need attention?"],
    )
