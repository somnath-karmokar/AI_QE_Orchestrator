"""Resolve the flow or run a question is about.

Users name flows loosely -- "the RCA flow", "regression intelligence", "that
flow" -- so a question is matched against the project's real flows by their
significant words. A match is only accepted when it is clearly ahead of the
runner-up; otherwise the copilot asks which one was meant rather than guessing,
because answering about the wrong flow is worse than asking.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.flow import AgentFlow
from app.models.project import Project
from app.models.run import AgentRun

# Words that carry no identity: every flow is a "flow" that someone "runs".
STOPWORDS = {
    "the", "a", "an", "of", "for", "to", "and", "our", "my", "this", "that", "these", "those",
    "flow", "flows", "workflow", "workflows", "run", "runs", "running", "ran", "last", "latest",
    "how", "what", "why", "when", "who", "which", "is", "are", "was", "were", "did", "does", "do",
    "show", "me", "tell", "about", "in", "on", "it", "its", "doing", "going", "much", "many",
    "cost", "costs", "status", "health", "healthy", "failed", "fail", "failing", "succeed",
    "please", "can", "you", "we", "us", "there", "has", "have", "had", "with", "at", "by", "from",
}

ACCEPT_SCORE = 0.45  # a match must cover this share of a flow's distinctive words
LEAD_MARGIN = 0.12  # ... and beat the runner-up by this much
CANDIDATE_SCORE = 0.25  # weaker matches are offered as "did you mean"

RUN_NUMBER = re.compile(r"\brun\s*#?\s*(\d{1,6})\b", re.IGNORECASE)
LAST_RUN = re.compile(r"\b(last|latest|most recent|previous)\s+(run|execution|time)\b", re.IGNORECASE)


@dataclass
class FlowReference:
    flow: AgentFlow | None = None
    run: AgentRun | None = None
    candidates: list[AgentFlow] = field(default_factory=list)
    """Flows that matched about equally; the copilot asks which one was meant."""
    named_but_unknown: str | None = None
    """The user clearly named a flow, but no flow in the project matches it."""
    wants_last_run: bool = False
    from_context: bool = False


def project_flows(session: Session, project: Project) -> list[AgentFlow]:
    return list(
        session.execute(
            select(AgentFlow)
            .where(AgentFlow.project_id == project.id, AgentFlow.is_deleted.is_(False))
            .order_by(AgentFlow.name)
        ).scalars()
    )


def _tokens(value: str) -> set[str]:
    return {word for word in re.split(r"[^a-z0-9]+", value.lower()) if word and word not in STOPWORDS}


def score_flow(message_tokens: set[str], flow: AgentFlow) -> float:
    """Share of the flow's distinctive words the message mentions."""
    flow_tokens = _tokens(f"{flow.name} {flow.key}")
    if not flow_tokens:
        return 0.0
    hits = len(flow_tokens & message_tokens)
    if not hits:
        return 0.0
    # Reward covering the flow's name; a single shared word like "payment" is weak.
    return hits / len(flow_tokens)


def resolve(
    session: Session,
    message: str,
    project: Project,
    carried: dict[str, Any] | None = None,
) -> FlowReference:
    """Find the flow and/or run the message is about."""
    reference = FlowReference()
    flows = project_flows(session, project)
    message_tokens = _tokens(message)

    scored = sorted(((score_flow(message_tokens, flow), flow) for flow in flows), key=lambda item: -item[0])
    if scored and scored[0][0] >= ACCEPT_SCORE:
        best_score, best = scored[0]
        runner_up = scored[1][0] if len(scored) > 1 else 0.0
        if best_score - runner_up >= LEAD_MARGIN:
            reference.flow = best
        else:
            reference.candidates = [flow for score, flow in scored if score >= CANDIDATE_SCORE][:4]
    elif scored:
        reference.candidates = [flow for score, flow in scored if score >= CANDIDATE_SCORE][:4]

    # A name in quotes that matches no flow is worth repeating back, even when
    # a weak candidate exists, so the answer does not silently change the subject.
    if reference.flow is None:
        for phrase in re.findall(r"[\"'“”']([^\"'“”']{3,60})[\"'“”']", message):
            if _tokens(phrase):
                reference.named_but_unknown = phrase.strip()
                break

    # ----- run reference -----
    match = RUN_NUMBER.search(message)
    if match:
        run = session.execute(
            select(AgentRun).where(AgentRun.project_id == project.id, AgentRun.run_number == int(match.group(1)))
        ).scalar_one_or_none()
        if run is not None:
            reference.run = run
            if reference.flow is None and run.flow_id:
                reference.flow = session.get(AgentFlow, run.flow_id)
        else:
            reference.named_but_unknown = reference.named_but_unknown or f"run #{match.group(1)}"

    if reference.run is None and LAST_RUN.search(message):
        reference.wants_last_run = True

    # ----- carry the subject of the conversation forward -----
    if reference.flow is None and not reference.candidates and carried:
        carried_id = carried.get("flow_id")
        if carried_id:
            flow = session.get(AgentFlow, carried_id)
            if flow is not None and not flow.is_deleted and flow.project_id == project.id:
                reference.flow = flow
                reference.from_context = True

    if reference.wants_last_run and reference.run is None:
        statement = select(AgentRun).where(AgentRun.project_id == project.id, AgentRun.flow_id.is_not(None))
        if reference.flow is not None:
            statement = statement.where(AgentRun.flow_id == reference.flow.id)
        reference.run = session.execute(statement.order_by(AgentRun.created_at.desc()).limit(1)).scalar_one_or_none()
        if reference.flow is None and reference.run is not None and reference.run.flow_id:
            reference.flow = session.get(AgentFlow, reference.run.flow_id)

    return reference


def latest_run(session: Session, flow: AgentFlow, *, failed_only: bool = False) -> AgentRun | None:
    statement = select(AgentRun).where(AgentRun.flow_id == flow.id)
    if failed_only:
        statement = statement.where(AgentRun.status.in_(["failed", "partially_succeeded"]))
    return session.execute(statement.order_by(AgentRun.created_at.desc()).limit(1)).scalar_one_or_none()
