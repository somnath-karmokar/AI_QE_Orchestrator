"""Agentic planner: understand intent, then choose the right specialist agents.

Selection is grounded in two independent signals rather than a keyword table:

  1. semantic similarity between the user's message and each agent's embedded
     capability description (Chroma, `qe_agent_catalog`);
  2. an intent classification, itself resolved by similarity against labelled
     example phrasings.

The two are combined into a score with a stated rationale, so the UI can show
*why* an agent was chosen and what else was considered. Nothing here bypasses
the model router, the cost tracker or the governance engine.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.cost.tracker import UsageContext
from app.ai.router.model_router import ModelRouter
from app.copilot.intent import (
    INTENTS,
    ExtractedEntities,
    flow_intent_hint,
    intent_corpus,
    navigation_target,
)
from app.core.logging import get_logger
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.project import Project
from app.vectorstore.base import COLLECTION_AGENT_CATALOG, build_where
from app.vectorstore.factory import get_vector_store

logger = get_logger(__name__)

# Intent -> the agents that satisfy it, most appropriate first. This is a prior,
# not the decision: semantic similarity can promote a different agent, and the
# combined score is what selects.
INTENT_AGENTS: dict[str, list[str]] = {
    "assess_requirement": ["user-story-completeness"],
    "generate_tests": ["test-scenario-generator", "test-design"],
    "generate_automation": ["auto-script-generator"],
    "generate_test_data": ["test-data-generator", "test-data-management"],
    "run_execution": ["automated-test-execution"],
    "diagnose_failure": ["automation-failure-analysis", "automated-rca"],
    "predict_risk": ["defect-prediction"],
    "optimize_regression": ["regression-suite-optimization"],
    "analyze_impact": ["wickes-change-impact-analyzer"],
    "plan_coverage": ["coverage-planning"],
    "coverage_report": ["traceability-coverage"],
    "quality_status": ["observability", "traceability-coverage"],
    "prepare_uat": ["uat-assistant"],
    "accessibility_check": ["accessibility-test"],
    "knowledge_question": ["test-knowledge"],
}

# Questions about the flows themselves, answered from recorded platform state.
FLOW_INTENTS = {"flow_explain", "flow_health", "flow_run_review", "flow_governance", "flow_inventory"}

# Intents answered from retrieval rather than by running an agent.
ANSWER_INTENTS = {"knowledge_question", "quality_status", "coverage_report"} | FLOW_INTENTS

# Multi-agent intents that map onto a pre-built flow instead of a single agent.
INTENT_FLOWS: dict[str, str] = {
    "generate_automation": "requirement-to-automated-test",
    "diagnose_failure": "failure-to-rca-defect",
    "optimize_regression": "regression-intelligence",
}

CONFIDENCE_FLOOR = 0.34

# Intents that are meaningless without a story or module to act on.
_SUBJECT_REQUIRED = {"generate_tests", "generate_automation", "generate_test_data",
                     "prepare_uat", "accessibility_check"}


@dataclass
class AgentCandidate:
    agent_id: str
    agent_key: str
    name: str
    category: str
    risk_level: str
    requires_approval: bool
    semantic_score: float
    intent_score: float
    rationale: str

    @property
    def score(self) -> float:
        # Semantic match dominates; the intent prior breaks ties and rescues
        # phrasings the embedding alone would score poorly.
        return round(self.semantic_score * 0.6 + self.intent_score * 0.4, 4)

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "agent_key": self.agent_key,
            "name": self.name,
            "category": self.category,
            "risk_level": self.risk_level,
            "requires_approval": self.requires_approval,
            "score": self.score,
            "semantic_score": round(self.semantic_score, 4),
            "intent_score": round(self.intent_score, 4),
            "rationale": self.rationale,
        }


@dataclass
class Plan:
    kind: str  # answer | run_agent | run_flow | clarify | navigate | refused
    intent: str
    intent_confidence: float
    summary: str
    reasoning: str
    entities: ExtractedEntities
    considered: list[AgentCandidate] = field(default_factory=list)
    selected: list[AgentCandidate] = field(default_factory=list)
    flow_key: str | None = None
    agent_inputs: dict[str, Any] = field(default_factory=dict)
    navigation: dict[str, Any] = field(default_factory=dict)
    clarify_options: list[str] = field(default_factory=list)
    # The user's original words. Retrieval must search what was actually asked,
    # not an entity carried over from an earlier turn.
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "intent": self.intent,
            "intent_confidence": round(self.intent_confidence, 3),
            "summary": self.summary,
            "reasoning": self.reasoning,
            "entities": self.entities.to_dict(),
            "considered": [candidate.to_dict() for candidate in self.considered],
            "selected": [candidate.to_dict() for candidate in self.selected],
            "flow_key": self.flow_key,
            "agent_inputs": self.agent_inputs,
            "navigation": self.navigation,
            "clarify_options": self.clarify_options,
        }


class CopilotPlanner:
    """Resolves a natural-language message into an executable plan."""

    def __init__(self, session: Session) -> None:
        self.session = session
        self.router = ModelRouter(session)
        self.store = get_vector_store()

    # ------------------------------------------------------------------
    def plan(
        self,
        message: str,
        *,
        project: Project,
        entities: ExtractedEntities,
        history: list[dict[str, str]] | None = None,
    ) -> Plan:
        intent, intent_confidence, intent_scores = self._classify_intent(message, project)
        candidates = self._score_agents(message, project, intent)

        # Explicit wording about a flow beats the embedding, which mixes up
        # "what does it do" with "how is it doing".
        hinted = flow_intent_hint(message, has_flow_context=bool(entities.flow_id))
        if hinted is not None:
            intent = hinted
            intent_confidence = max(intent_confidence, 0.75)

        # Navigation is checked first: "show me the defects" should move the
        # user, not run an agent.
        if intent == "navigate" or self._looks_like_navigation(message):
            target = navigation_target(message)
            if target is not None:
                route, label = target
                return Plan(
                    kind="navigate",
                    intent="navigate",
                    intent_confidence=max(intent_confidence, 0.7),
                    summary=f"Opening {label}.",
                    reasoning=f"The message asks to view a part of the platform; '{label}' is the closest match.",
                    entities=entities,
                    message=message,
                    considered=candidates[:4],
                    navigation={"route": route, "label": label},
                )

        # Too weak a signal to act on: ask rather than guess.
        if intent_confidence < CONFIDENCE_FLOOR:
            return Plan(
                kind="clarify",
                intent=intent,
                intent_confidence=intent_confidence,
                summary="I am not confident enough about what you need to pick the right agent.",
                reasoning=(
                    f"The closest intent was '{INTENTS.get(intent, {}).get('label', intent)}' at "
                    f"{intent_confidence:.0%} confidence, below the {CONFIDENCE_FLOOR:.0%} floor."
                ),
                entities=entities,
                message=message,
                considered=candidates[:4],
                clarify_options=self._clarify_options(intent_scores),
            )

        # A question about a flow is only answered once it is clear which flow.
        if intent in FLOW_INTENTS and intent != "flow_inventory" and not entities.flow_id:
            clarify = self._clarify_flow(project, entities, intent, intent_confidence, message, candidates)
            if clarify is not None:
                return clarify

        # Answer-shaped intents are served from retrieval and platform state.
        if intent in ANSWER_INTENTS:
            # A flow question is answered from recorded runs, approvals and audit
            # entries: no agent is involved, so none is credited.
            about_flows = intent in FLOW_INTENTS
            return Plan(
                kind="answer",
                intent=intent,
                intent_confidence=intent_confidence,
                summary=INTENTS[intent]["label"],
                reasoning=(
                    f"Classified as '{INTENTS[intent]['label']}' ({intent_confidence:.0%}). "
                    + (
                        "Answered from this project's recorded runs, approvals and audit entries — "
                        "the same data the flow workspace shows."
                        if about_flows
                        else "This is answerable from indexed knowledge and current project state, "
                        "so no agent run is needed."
                    )
                ),
                entities=entities,
                message=message,
                considered=[] if about_flows else candidates[:4],
                selected=[] if about_flows else candidates[:1],
            )

        # Multi-step intents run a pre-built, governed flow.
        flow_key = INTENT_FLOWS.get(intent)
        if flow_key and self._flow_exists(project, flow_key) and self._warrants_flow(intent, message, entities):
            flow = self._flow(project, flow_key)
            return Plan(
                kind="run_flow",
                intent=intent,
                intent_confidence=intent_confidence,
                summary=f"Running the '{flow.name}' flow.",
                reasoning=(
                    f"'{INTENTS[intent]['label']}' needs several agents in sequence. The pre-built "
                    f"'{flow.name}' flow already chains them with the right conditions and approval gates, "
                    "so it is used instead of invoking agents one at a time."
                ),
                entities=entities,
                message=message,
                considered=candidates[:5],
                selected=candidates[:3],
                flow_key=flow_key,
                agent_inputs=self._build_inputs(intent, entities, project, message),
            )

        # Single specialist agent.
        if not candidates:
            return Plan(
                kind="clarify",
                intent=intent,
                intent_confidence=intent_confidence,
                summary="No agent in this project can serve that request.",
                reasoning="Nothing in the agent catalogue matched the request closely enough to run.",
                entities=entities,
                message=message,
                clarify_options=self._clarify_options(intent_scores),
            )

        best = candidates[0]
        missing = self._missing_inputs(best, entities, project)

        # Generation intents need a subject. Running "generate test cases" with
        # no story and no module would produce something arbitrary, so ask.
        if not missing and intent in _SUBJECT_REQUIRED and not (
            entities.requirement_key or entities.module
        ):
            missing = ["requirement_key"]
        if missing:
            return Plan(
                kind="clarify",
                intent=intent,
                intent_confidence=intent_confidence,
                summary=f"{best.name} needs a bit more detail before it can run.",
                reasoning=(
                    f"Selected {best.name} at {best.score:.0%} match, but it requires "
                    f"{', '.join(missing)} and the message did not supply that."
                ),
                entities=entities,
                message=message,
                considered=candidates[:4],
                selected=[best],
                clarify_options=self._input_prompts(missing, project),
            )

        return Plan(
            kind="run_agent",
            intent=intent,
            intent_confidence=intent_confidence,
            summary=f"Running {best.name}.",
            reasoning=(
                f"Classified as '{INTENTS[intent]['label']}' ({intent_confidence:.0%}). "
                f"{best.name} scored {best.score:.0%} — {best.rationale}"
                + (
                    f" Runner-up was {candidates[1].name} at {candidates[1].score:.0%}."
                    if len(candidates) > 1
                    else ""
                )
            ),
            entities=entities,
            message=message,
            considered=candidates[:5],
            selected=[best],
            agent_inputs=self._build_inputs(intent, entities, project, message),
        )

    def _clarify_flow(
        self,
        project: Project,
        entities: ExtractedEntities,
        intent: str,
        confidence: float,
        message: str,
        candidates: list[AgentCandidate],
    ) -> Plan | None:
        """Ask which flow was meant, unless there is only one it could be."""
        from app.copilot.flow_resolver import project_flows  # noqa: PLC0415 - avoids an import cycle

        flows = project_flows(self.session, project)
        if not flows:
            return Plan(
                kind="clarify",
                intent=intent,
                intent_confidence=confidence,
                summary="This project has no flows yet.",
                reasoning="A flow question was asked, but the project contains no flows to report on.",
                entities=entities,
                message=message,
                clarify_options=["Create a flow in Flow Studio", "Which agents are available?"],
            )
        if len(flows) == 1:
            entities.flow_id, entities.flow_key, entities.flow_name = flows[0].id, flows[0].key, flows[0].name
            return None

        # Offer what matched, then fill up with real flows so there is always a way forward.
        named = list(entities.flow_candidates)
        for flow in flows:
            if len(named) >= 4:
                break
            if flow.name not in named:
                named.append(flow.name)
        unknown = entities.unknown_flow
        summary = (
            f"I could not find a flow called '{unknown}' in this project. These are the flows I can report on:"
            if unknown
            else "Which flow do you mean?"
        )
        question = {
            "flow_explain": "What does {name} do?",
            "flow_health": "How is {name} doing?",
            "flow_run_review": "Why did the last run of {name} end that way?",
            "flow_governance": "Is {name} under control?",
        }.get(intent, "How is {name} doing?")
        return Plan(
            kind="clarify",
            intent=intent,
            intent_confidence=confidence,
            summary=summary,
            reasoning=(
                "The question is about a flow, but the wording matched "
                + (f"{len(entities.flow_candidates)} flows equally." if entities.flow_candidates else "no flow by name.")
                + " Answering about the wrong flow would be worse than asking."
            ),
            entities=entities,
            message=message,
            considered=candidates[:3],
            clarify_options=[question.format(name=name) for name in named[:4]],
        )

    def rank_agents(self, text: str, project: Project) -> tuple[str, float, list[AgentCandidate]]:
        """Intent and ranked candidate agents for a piece of text, without planning a turn.

        The flow composer uses this to pick an agent for each step a user describes,
        so flows and conversations select agents by exactly the same signals.
        """
        intent, confidence, _ = self._classify_intent(text, project)
        return intent, confidence, self._score_agents(text, project, intent)

    # ------------------------------------------------------------------
    # Intent classification
    # ------------------------------------------------------------------
    def _classify_intent(self, message: str, project: Project) -> tuple[str, float, dict[str, float]]:
        """Classify by embedding the message against labelled example phrasings."""
        corpus = intent_corpus()
        texts = [message] + [example for _, example in corpus]
        try:
            vectors = self.router.embed(texts, UsageContext(project_id=project.id)).vectors
        except Exception as exc:  # noqa: BLE001
            logger.warning("intent_embedding_failed", error=str(exc)[:160])
            return "knowledge_question", 0.3, {}

        query = vectors[0]
        scores: dict[str, list[float]] = {}
        for (intent, _), vector in zip(corpus, vectors[1:], strict=False):
            scores.setdefault(intent, []).append(_cosine(query, vector))

        # An intent's score is its best matching example, softened by its mean
        # so a single lucky phrase does not dominate.
        ranked = {
            intent: round(max(values) * 0.75 + statistics.fmean(values) * 0.25, 4)
            for intent, values in scores.items()
        }
        best = max(ranked.items(), key=lambda item: item[1])
        return best[0], best[1], ranked

    @staticmethod
    def _looks_like_navigation(message: str) -> bool:
        lowered = message.lower().strip()
        return lowered.startswith(("show me", "open ", "take me", "go to", "navigate")) and navigation_target(
            message
        ) is not None

    # ------------------------------------------------------------------
    # Agent scoring
    # ------------------------------------------------------------------
    def _score_agents(self, message: str, project: Project, intent: str) -> list[AgentCandidate]:
        agents = {
            agent.key: agent
            for agent in self.session.execute(
                select(Agent).where(
                    Agent.is_deleted.is_(False),
                    Agent.is_published.is_(True),
                    (Agent.project_id.is_(None)) | (Agent.project_id == project.id),
                )
            )
            .scalars()
            .all()
        }
        if not agents:
            return []

        # Semantic match against embedded capability descriptions.
        semantic: dict[str, float] = {}
        try:
            embedding = self.router.embed([message], UsageContext(project_id=project.id)).vectors[0]
            hits = self.store.query(
                COLLECTION_AGENT_CATALOG,
                embedding,
                limit=12,
                where=build_where(project_id=project.id),
            )
            for hit in hits:
                key = str(hit.metadata.get("agent_key", ""))
                if key:
                    semantic[key] = max(semantic.get(key, 0.0), hit.score)
        except Exception as exc:  # noqa: BLE001 - fall back to the intent prior
            logger.warning("agent_catalog_search_failed", error=str(exc)[:160])

        preferred = INTENT_AGENTS.get(intent, [])
        candidates: list[AgentCandidate] = []

        for key, agent in agents.items():
            semantic_score = semantic.get(key, 0.0)
            if key in preferred:
                # Rank within the prior matters: first choice scores highest.
                position = preferred.index(key)
                intent_score = round(max(0.4, 1.0 - position * 0.22), 3)
            else:
                intent_score = 0.0

            if semantic_score <= 0.0 and intent_score <= 0.0:
                continue

            if intent_score >= 0.8 and semantic_score >= 0.55:
                rationale = "it is the designated agent for this intent and its description matches the request."
            elif intent_score >= 0.4:
                rationale = f"it is registered as a handler for '{INTENTS.get(intent, {}).get('label', intent)}'."
            else:
                rationale = "its capability description is semantically close to the request."

            candidates.append(
                AgentCandidate(
                    agent_id=agent.id,
                    agent_key=key,
                    name=agent.name,
                    category=agent.category,
                    risk_level=agent.risk_level,
                    requires_approval=agent.requires_approval,
                    semantic_score=semantic_score,
                    intent_score=intent_score,
                    rationale=rationale,
                )
            )

        candidates.sort(key=lambda candidate: candidate.score, reverse=True)
        return candidates

    # ------------------------------------------------------------------
    # Inputs and gaps
    # ------------------------------------------------------------------
    def _missing_inputs(
        self, candidate: AgentCandidate, entities: ExtractedEntities, project: Project
    ) -> list[str]:
        """Required agent inputs the message did not supply."""
        agent = self.session.get(Agent, candidate.agent_id)
        if agent is None:
            return []
        required = (agent.input_schema or {}).get("required", [])
        available = self._build_inputs("", entities, project)
        return [field for field in required if not available.get(field)]

    @staticmethod
    def _input_prompts(missing: list[str], project: Project) -> list[str]:
        prompts: list[str] = []
        for field in missing:
            if field in ("requirement_key", "requirement_id"):
                prompts.append("Which story? For example: PAY-201")
            elif field == "module":
                modules = ", ".join((project.modules or [])[:4])
                prompts.append(f"Which module? For example: {modules}")
            elif field == "query":
                prompts.append("What should I look up?")
            elif field == "defect_id":
                prompts.append("Which defect? For example: DEF-0003")
            elif field == "change_request_id":
                prompts.append("Which change request? For example: CR-1001")
            else:
                prompts.append(f"What value should I use for {field.replace('_', ' ')}?")
        return prompts

    @staticmethod
    def _build_inputs(
        intent: str, entities: ExtractedEntities, project: Project, message: str = ""
    ) -> dict[str, Any]:
        """Map resolved entities onto the input names agents expect."""
        inputs: dict[str, Any] = {}
        if intent == "plan_coverage" and entities.requirement_key:
            inputs["requirement_keys"] = [entities.requirement_key]
        if entities.requirement_key:
            inputs["requirement_key"] = entities.requirement_key
        if entities.requirement_id:
            inputs["requirement_id"] = entities.requirement_id
        if entities.defect_id:
            inputs["defect_id"] = entities.defect_id
        if entities.execution_id:
            inputs["execution_id"] = entities.execution_id
        if entities.module:
            inputs["module"] = entities.module
        if entities.modules:
            inputs["changed_modules"] = entities.modules
            inputs["modules"] = entities.modules
        if entities.suite_type:
            inputs["suite_type"] = entities.suite_type
        if entities.browser:
            inputs["browser"] = entities.browser
        # Knowledge-style agents take a free-text query.
        inputs.setdefault("query", entities.requirement_key or entities.module or project.name)
        return inputs

    @staticmethod
    def _warrants_flow(intent: str, message: str, entities: ExtractedEntities) -> bool:
        """Prefer a full flow only when the request is genuinely multi-step."""
        lowered = message.lower()
        if any(word in lowered for word in ("end to end", "end-to-end", "full", "everything", "whole")):
            return True
        if intent == "generate_automation":
            # "automate PAY-201" from scratch is the whole pipeline.
            return bool(entities.requirement_key)
        if intent == "diagnose_failure":
            return bool(entities.execution_id) and "root cause" not in lowered
        return False

    def _flow_exists(self, project: Project, key: str) -> bool:
        return self._flow(project, key) is not None

    def _flow(self, project: Project, key: str) -> AgentFlow | None:
        return self.session.execute(
            select(AgentFlow).where(
                AgentFlow.project_id == project.id,
                AgentFlow.key == key,
                AgentFlow.is_deleted.is_(False),
            )
        ).scalar_one_or_none()

    @staticmethod
    def _clarify_options(intent_scores: dict[str, float]) -> list[str]:
        """Offer the next-best interpretations as concrete follow-ups."""
        ranked = sorted(intent_scores.items(), key=lambda item: item[1], reverse=True)[:3]
        return [INTENTS[intent]["examples"][0] for intent, _ in ranked if intent in INTENTS]


def _cosine(left: list[float], right: list[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=False))
    # Embeddings from the pipeline are L2-normalised, so the dot product is the
    # cosine; clamp to guard against tiny numerical overshoot.
    return max(0.0, min(1.0, dot))
