"""MCP registry: resolves server keys to adapters and governs every tool call.

This is the single choke point between agents and the outside world. It applies
the tool allowlist, the environment restrictions and the approval requirements
before an adapter ever runs (spec sections 9, 18 and 30).
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import PolicyViolationError
from app.core.logging import get_logger
from app.core.mode import forbid_stand_in
from app.mcp.base import MCPServerAdapter, ToolDefinition, ToolResult
from app.mcp.servers.jira import JiraDemoAdapter, JiraRestAdapter
from app.mcp.servers.knowledge_servers import (
    CICDDemoAdapter,
    ConfluenceDemoAdapter,
    DatabaseDemoAdapter,
    GitDemoAdapter,
)
from app.mcp.servers.playwright_server import PlaywrightMCPAdapter
from app.mcp.servers.tenant_data import TenantDataAdapter
from app.models.project import MCPServer

logger = get_logger(__name__)

# key -> {connector_mode: adapter class}
ADAPTERS: dict[str, dict[str, type[MCPServerAdapter]]] = {
    "jira": {"demo": JiraDemoAdapter, "real": JiraRestAdapter},
    "confluence": {"demo": ConfluenceDemoAdapter, "real": ConfluenceDemoAdapter},
    "git": {"demo": GitDemoAdapter, "real": GitDemoAdapter},
    "database": {"demo": DatabaseDemoAdapter, "real": DatabaseDemoAdapter},
    "cicd": {"demo": CICDDemoAdapter, "real": CICDDemoAdapter},
    "playwright": {"demo": PlaywrightMCPAdapter, "real": PlaywrightMCPAdapter},
    # The customer's own connected systems. There is no demo variant on
    # purpose: it reads real data sources or it has none to read, and inventing
    # rows "from the customer's database" is the one stand-in that would be
    # indistinguishable from a breach of their actual data.
    "tenant_data": {"demo": TenantDataAdapter, "real": TenantDataAdapter},
}

SERVER_METADATA: dict[str, dict[str, Any]] = {
    "jira": {
        "name": "Jira MCP",
        "description": "Story retrieval, defect creation and issue commentary.",
        "icon": "Ticket",
    },
    "confluence": {
        "name": "Confluence MCP",
        "description": "Requirements, SOPs and architecture documentation.",
        "icon": "BookOpen",
    },
    "git": {
        "name": "Git MCP",
        "description": "Repository access, code context and change history.",
        "icon": "GitBranch",
    },
    "database": {
        "name": "Database MCP",
        "description": "Read-only queries, record validation and SQL generation.",
        "icon": "Database",
    },
    "cicd": {
        "name": "CI/CD MCP",
        "description": "Pipeline triggering and build status.",
        "icon": "Workflow",
    },
    "playwright": {
        "name": "Playwright MCP",
        "description": "Browser automation, inspection and test execution.",
        "icon": "MonitorPlay",
    },
    "tenant_data": {
        "name": "Connected data sources",
        "description": "Systems this project's own owners connected, read with their credentials.",
        "icon": "Database",
    },
}


class MCPRegistry:
    """Per-request registry bound to a session, project and environment."""

    def __init__(
        self,
        session: Session,
        project_id: str,
        *,
        environment_id: str | None = None,
        environment_allows_writes: bool = True,
    ) -> None:
        self.session = session
        self.project_id = project_id
        self.environment_id = environment_id
        self.environment_allows_writes = environment_allows_writes
        self._adapters: dict[str, MCPServerAdapter] = {}
        self._configs: dict[str, MCPServer] = {}
        self._load_configs()

    def _load_configs(self) -> None:
        rows = list(
            self.session.execute(
                select(MCPServer).where(
                    (MCPServer.project_id == self.project_id) | (MCPServer.project_id.is_(None))
                )
            )
            .scalars()
            .all()
        )
        # Project-scoped rows take precedence over global ones.
        for row in sorted(rows, key=lambda item: item.project_id is None, reverse=True):
            self._configs[row.key] = row

    # ----- adapter resolution ------------------------------------------------
    def adapter(self, server_key: str) -> MCPServerAdapter:
        if server_key in self._adapters:
            return self._adapters[server_key]

        variants = ADAPTERS.get(server_key)
        if variants is None:
            raise PolicyViolationError(
                f"MCP server '{server_key}' is not registered on this platform.",
                details={"server": server_key},
            )

        config = self._configs.get(server_key)
        mode = config.connector_mode if config else "demo"
        adapter_class = variants.get(mode)
        # The question is whether the adapter we are about to use invents data,
        # which the adapter itself answers. Asking the *configured mode* instead
        # would refuse a connector that is real in both modes -- `tenant_data`
        # reads the customer's own systems and has no invented variant to fall
        # back to.
        if adapter_class is None or adapter_class.connector_mode != "real":
            # A demo adapter answers with invented tickets, commits and rows.
            # In production that is indistinguishable from the real thing.
            forbid_stand_in(
                f"the '{server_key}' MCP server",
                f"It resolves to the demo connector (mode '{mode}'), which returns invented data.",
                "Set its connector mode to live, disable the server, or set APP_MODE=local.",
            )
            adapter_class = variants["demo"]
        adapter = adapter_class(
            {
                "session": self.session,
                "project_id": self.project_id,
                "environment_id": self.environment_id,
                "config": config.config if config else {},
            }
        )
        self._adapters[server_key] = adapter
        return adapter

    def available_servers(self) -> list[str]:
        return [key for key, config in self._configs.items() if config.is_enabled and key in ADAPTERS]

    def list_tools(self, server_key: str) -> list[ToolDefinition]:
        return self.adapter(server_key).list_tools()

    def describe(self) -> list[dict[str, Any]]:
        """Full inventory for the Integrations / MCP screen."""
        inventory: list[dict[str, Any]] = []
        for key in ADAPTERS:
            config = self._configs.get(key)
            metadata = SERVER_METADATA.get(key, {})
            try:
                adapter = self.adapter(key)
                tools = [definition.to_dict() for definition in adapter.list_tools()]
                health = adapter.health()
            except Exception as exc:  # noqa: BLE001
                tools, health = [], {"status": "error", "detail": str(exc)[:200]}
            inventory.append(
                {
                    "key": key,
                    "name": metadata.get("name", key),
                    "description": metadata.get("description", ""),
                    "icon": metadata.get("icon", "Plug"),
                    "is_enabled": config.is_enabled if config else True,
                    "connector_mode": config.connector_mode if config else "demo",
                    "status": health.get("status", "unknown"),
                    "health": health,
                    "tools": tools,
                    "allowed_tools": config.allowed_tools if config else [],
                    "requires_approval_tools": config.requires_approval_tools if config else [],
                }
            )
        return inventory

    # ----- governed invocation ----------------------------------------------
    def check_permission(
        self, server_key: str, tool_name: str, *, agent_allowed_tools: list[str] | None = None
    ) -> dict[str, Any]:
        """Authorise a tool call. Raises `PolicyViolationError` when denied."""
        config = self._configs.get(server_key)
        if config is not None and not config.is_enabled:
            raise PolicyViolationError(
                f"MCP server '{server_key}' is disabled for this project.",
                details={"server": server_key},
            )

        adapter = self.adapter(server_key)
        definition = adapter.tool(tool_name)
        if definition is None:
            raise PolicyViolationError(
                f"Tool '{tool_name}' is not exposed by MCP server '{server_key}'.",
                details={"server": server_key, "tool": tool_name},
            )

        # Server-level allowlist.
        allowlist = (config.allowed_tools if config else None) or []
        if allowlist and tool_name not in allowlist:
            raise PolicyViolationError(
                f"Tool '{tool_name}' is not on the allowlist for MCP server '{server_key}'.",
                details={"server": server_key, "tool": tool_name, "allowed": allowlist},
            )

        # Agent-level allowlist: an agent may only use tools it declares.
        if agent_allowed_tools is not None and f"{server_key}.{tool_name}" not in agent_allowed_tools:
            if server_key not in agent_allowed_tools:
                raise PolicyViolationError(
                    f"This agent is not permitted to call '{server_key}.{tool_name}'.",
                    details={"server": server_key, "tool": tool_name},
                )

        # Environment restriction: read-only environments reject mutating tools.
        if definition.mutating and not self.environment_allows_writes:
            raise PolicyViolationError(
                f"Tool '{tool_name}' mutates state and the selected environment is read-only.",
                details={"server": server_key, "tool": tool_name, "environment_id": self.environment_id},
            )

        requires_approval = definition.requires_approval or tool_name in (
            (config.requires_approval_tools if config else None) or []
        )
        return {
            "allowed": True,
            "requires_approval": requires_approval,
            "risk_level": definition.risk_level,
            "mutating": definition.mutating,
        }

    def invoke(
        self,
        server_key: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        agent_allowed_tools: list[str] | None = None,
        approval_granted: bool = False,
    ) -> ToolResult:
        decision = self.check_permission(
            server_key, tool_name, agent_allowed_tools=agent_allowed_tools
        )
        if decision["requires_approval"] and not approval_granted:
            raise PolicyViolationError(
                f"Tool '{server_key}.{tool_name}' requires human approval before it can run.",
                details={"server": server_key, "tool": tool_name, "requires_approval": True},
            )

        result = self.adapter(server_key).invoke(tool_name, arguments)
        logger.info(
            "mcp_tool_call",
            server=server_key,
            tool=tool_name,
            success=result.success,
            duration_ms=result.duration_ms,
        )
        return result
