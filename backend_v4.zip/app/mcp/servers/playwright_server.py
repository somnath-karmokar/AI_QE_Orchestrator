"""Playwright MCP server.

Exposes browser primitives as tools. Two execution backends sit behind the same
tool surface:

  * simulated -- deterministic DOM/interaction model used when no application
    under test is reachable (the demo default);
  * live      -- real Python Playwright, enabled with `PLAYWRIGHT_ENABLED=true`
    once an application URL is configured.

`inspect` returns locator candidates ranked by robustness, which is what the
script generator and the self-healing agent both consume.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Any

from app.core.config import settings
from app.core.errors import ToolExecutionError
from app.core.logging import get_logger
from app.mcp.base import MCPServerAdapter, ToolDefinition, ToolParameter

logger = get_logger(__name__)

PLAYWRIGHT_TOOLS = [
    ToolDefinition(
        name="open_browser",
        description="Start a browser session.",
        parameters=[
            ToolParameter("browser", "string", "Browser engine", enum=["chromium", "firefox", "webkit"]),
            ToolParameter("headless", "boolean", "Run headless", default=True),
        ],
        mutating=True,
    ),
    ToolDefinition(
        name="navigate",
        description="Navigate the active page to a URL.",
        parameters=[ToolParameter("url", "string", "Target URL", required=True)],
        mutating=True,
    ),
    ToolDefinition(
        name="click",
        description="Click an element identified by a locator.",
        parameters=[ToolParameter("locator", "string", "Playwright locator", required=True)],
        mutating=True,
    ),
    ToolDefinition(
        name="fill",
        description="Fill an input field.",
        parameters=[
            ToolParameter("locator", "string", "Playwright locator", required=True),
            ToolParameter("value", "string", "Value to enter", required=True),
        ],
        mutating=True,
    ),
    ToolDefinition(
        name="screenshot",
        description="Capture a screenshot of the current page.",
        parameters=[ToolParameter("name", "string", "Artifact name", default="screenshot")],
    ),
    ToolDefinition(
        name="inspect",
        description="Inspect the page and return ranked locator candidates for an element.",
        parameters=[
            ToolParameter("description", "string", "Natural-language element description", required=True),
            ToolParameter("url", "string", "Page URL to inspect"),
        ],
    ),
    ToolDefinition(
        name="execute_test",
        description="Execute a generated Playwright test script.",
        parameters=[
            ToolParameter("script_path", "string", "Script file path", required=True),
            ToolParameter("browser", "string", "Browser engine", enum=["chromium", "firefox", "webkit"]),
        ],
        mutating=True,
        risk_level="medium",
    ),
]

# Locator strategies ordered by resilience. The generator prefers the top of
# this list and only falls back to XPath when nothing better is available
# (spec section 10: avoid brittle XPath).
LOCATOR_STRATEGY_RANK: list[tuple[str, float]] = [
    ("test_id", 0.97),
    ("role", 0.93),
    ("label", 0.90),
    ("placeholder", 0.84),
    ("text", 0.78),
    ("css", 0.66),
    ("xpath", 0.42),
]


def build_locator_candidates(description: str, *, seed: str = "") -> list[dict[str, Any]]:
    """Produce ranked locator candidates for an element description.

    Deterministic: the same description always yields the same candidates, so
    healing proposals are reproducible and reviewable.
    """
    slug = "-".join(
        word.lower() for word in description.replace("/", " ").split() if word.isalnum() or "-" in word
    )[:48] or "element"
    digest = hashlib.md5(f"{description}:{seed}".encode()).hexdigest()  # noqa: S324
    role = "button" if any(word in description.lower() for word in ("button", "submit", "click")) else "textbox"
    label = description.strip().title()

    templates: dict[str, str] = {
        "test_id": f'page.get_by_test_id("{slug}")',
        "role": f'page.get_by_role("{role}", name="{label}")',
        "label": f'page.get_by_label("{label}")',
        "placeholder": f'page.get_by_placeholder("{label}")',
        "text": f'page.get_by_text("{label}", exact=False)',
        "css": f'page.locator("[data-qa=\'{slug}\']")',
        "xpath": f'page.locator("xpath=//*[contains(text(),\'{label}\')]")',
    }

    candidates: list[dict[str, Any]] = []
    for index, (strategy, base_confidence) in enumerate(LOCATOR_STRATEGY_RANK):
        # Small deterministic jitter differentiates otherwise equal candidates.
        jitter = (int(digest[index * 2 : index * 2 + 2], 16) % 7) / 100.0
        candidates.append(
            {
                "strategy": strategy,
                "locator": templates[strategy],
                "confidence": round(max(0.05, base_confidence - jitter), 3),
                "rationale": _strategy_rationale(strategy),
            }
        )
    candidates.sort(key=lambda item: item["confidence"], reverse=True)
    return candidates


def _strategy_rationale(strategy: str) -> str:
    return {
        "test_id": "Dedicated test id is stable across styling and copy changes.",
        "role": "Accessible role and name survive DOM restructuring.",
        "label": "Associated label text is stable and accessibility-friendly.",
        "placeholder": "Placeholder text is reasonably stable but user-visible copy can change.",
        "text": "Visible text is readable but breaks on copy changes and localisation.",
        "css": "Attribute selector is acceptable when a QA hook attribute exists.",
        "xpath": "Positional XPath is brittle; use only when no better anchor exists.",
    }.get(strategy, "")


class PlaywrightMCPAdapter(MCPServerAdapter):
    key = "playwright"
    display_name = "Playwright MCP"
    description = "Browser automation, page inspection and test execution."

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        super().__init__(context)
        self.live = settings.playwright_enabled and self._playwright_available()
        self.connector_mode = "real" if self.live else "demo"
        self._session_state: dict[str, Any] = {"browser": None, "url": None, "actions": []}

    @staticmethod
    def _playwright_available() -> bool:
        try:
            import playwright  # noqa: F401, PLC0415

            return True
        except ImportError:
            return False

    def list_tools(self) -> list[ToolDefinition]:
        return PLAYWRIGHT_TOOLS

    # ----- session tools -----------------------------------------------------
    def tool_open_browser(self, browser: str | None = None, headless: bool = True) -> dict[str, Any]:
        engine = browser or settings.playwright_browser
        self._session_state["browser"] = engine
        self._session_state["actions"] = []
        return {
            "browser": engine,
            "headless": headless,
            "mode": self.connector_mode,
            "session_started_at": datetime.now(UTC).isoformat(),
        }

    def tool_navigate(self, url: str) -> dict[str, Any]:
        if self._session_state["browser"] is None:
            raise ToolExecutionError("No browser session is open. Call open_browser first.")
        self._session_state["url"] = url
        self._record("navigate", {"url": url})
        return {"url": url, "status": "loaded", "mode": self.connector_mode}

    def tool_click(self, locator: str) -> dict[str, Any]:
        self._require_page()
        self._record("click", {"locator": locator})
        return {"locator": locator, "action": "click", "success": True}

    def tool_fill(self, locator: str, value: str) -> dict[str, Any]:
        self._require_page()
        # Values may contain credentials; never echo them back.
        self._record("fill", {"locator": locator, "value": "***"})
        return {"locator": locator, "action": "fill", "success": True, "value_length": len(value)}

    def tool_screenshot(self, name: str = "screenshot") -> dict[str, Any]:
        self._require_page()
        filename = f"{name}-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}.png"
        path = f"{settings.execution_artifacts_dir}/{filename}"
        self._record("screenshot", {"name": filename})
        return {
            "artifact_type": "screenshot",
            "name": filename,
            "path": path,
            "captured": self.live,
            "mode": self.connector_mode,
        }

    def tool_inspect(self, description: str, url: str | None = None) -> dict[str, Any]:
        target_url = url or self._session_state.get("url") or ""
        candidates = build_locator_candidates(description, seed=target_url)
        return {
            "description": description,
            "url": target_url,
            "candidates": candidates,
            "recommended": candidates[0],
            "mode": self.connector_mode,
        }

    def tool_execute_test(self, script_path: str, browser: str | None = None) -> dict[str, Any]:
        """Delegated to the execution service, which owns retries and artifacts."""
        return {
            "script_path": script_path,
            "browser": browser or settings.playwright_browser,
            "mode": self.connector_mode,
            "note": "Test execution is orchestrated by the Execution Center; see /api/v1/executions.",
        }

    # ----- helpers -----------------------------------------------------------
    def _require_page(self) -> None:
        if self._session_state.get("url") is None:
            raise ToolExecutionError("No page is loaded. Call navigate first.")

    def _record(self, action: str, payload: dict[str, Any]) -> None:
        self._session_state["actions"].append(
            {"action": action, "at": datetime.now(UTC).isoformat(), **payload}
        )

    def health(self) -> dict[str, Any]:
        return {
            "server": self.key,
            "display_name": self.display_name,
            "status": "online",
            "connector_mode": self.connector_mode,
            "live_browser": self.live,
            "browser": settings.playwright_browser,
            "detail": (
                "Live Playwright browser automation is enabled."
                if self.live
                else "Simulated browser backend; set PLAYWRIGHT_ENABLED=true and install browsers for live runs."
            ),
            "tool_count": len(self.list_tools()),
        }
