"""Agents reaching a customer's own connected systems.

The registry is the only way an agent touches anything outside this platform, so
a tenant's data sources are reachable the same way: as an MCP server whose tools
resolve against `data_sources` rather than against a built-in connector.

Three things make this safe to hand an agent:

  * **The project is fixed by the run, not by the argument.** An agent names a
    data source by key; which project that key is looked up in comes from the
    registry's context. There is no argument an agent can set -- or a prompt can
    talk it into setting -- that reaches another tenant's source.
  * **Credentials are decrypted at the moment of the call** and go into the
    request, never into the result. A tool result is written to the run ledger
    and shown on screen, so anything returned here is effectively public within
    the project.
  * **Reads only, unless the source says otherwise.** A data source is
    `allow_writes=False` by default, and `fetch` refuses anything but GET
    against a source that has not been opened up deliberately.

What this does *not* do is pretend to query every kind. HTTP-shaped sources are
genuinely called; a Postgres or an S3 bucket needs its driver, and `fetch`
says so rather than returning something invented.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import urljoin, urlparse

from app.core.errors import ToolExecutionError
from app.core.logging import get_logger
from app.mcp.base import MCPServerAdapter, ToolDefinition, ToolParameter
from app.services import data_sources
from app.services.data_source_probes import TIMEOUT_SECONDS, AddressRefused, resolve_public

logger = get_logger(__name__)

# Kinds this adapter can genuinely call. Everything else is reported as
# unsupported rather than answered with a plausible-looking invention.
CALLABLE_KINDS = ("rest_api", "graphql", "jira", "confluence")


class TenantDataAdapter(MCPServerAdapter):
    """Reads the data sources the project's own owners connected."""

    key = "tenant_data"
    display_name = "Connected data sources"
    description = "The customer's own systems, connected to this project."
    connector_mode = "real"

    # ----- context -----------------------------------------------------------
    @property
    def _session(self):  # noqa: ANN202
        session = self.context.get("session")
        if session is None:
            raise ToolExecutionError("No database session is available to resolve data sources.")
        return session

    @property
    def _project_id(self) -> str:
        project_id = self.context.get("project_id")
        if not project_id:
            raise ToolExecutionError("No project is in scope, so no data source can be resolved.")
        return project_id

    def _resolve(self, key: str):  # noqa: ANN202
        """Find one enabled source by key, within this run's project only."""
        for source in data_sources.list_for_project(self._session, self._project_id):
            if source.key == key or source.name == key:
                if not source.is_enabled:
                    raise ToolExecutionError(f"The data source '{key}' is disabled.")
                return source
        raise ToolExecutionError(
            f"This project has no connected data source called '{key}'."
        )

    # ----- tools -------------------------------------------------------------
    def list_tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="list_sources",
                description="List the data sources connected to this project.",
                returns="array",
            ),
            ToolDefinition(
                name="fetch",
                description=(
                    "Read from a connected HTTP data source. The stored credential is "
                    "attached automatically; it is never returned."
                ),
                parameters=[
                    ToolParameter(
                        name="source",
                        description="The key or name of the connected data source.",
                        required=True,
                    ),
                    ToolParameter(
                        name="path",
                        description="A path relative to the source's base URL, e.g. /v1/orders.",
                        required=True,
                    ),
                    ToolParameter(
                        name="method",
                        description="HTTP method. Anything other than GET needs a source that allows writes.",
                        enum=["GET", "POST", "PUT", "PATCH", "DELETE"],
                        default="GET",
                    ),
                ],
                risk_level="medium",
            ),
        ]

    def tool_list_sources(self) -> list[dict[str, Any]]:
        """What this project has connected, with no credential material."""
        return [
            {
                "key": source.key,
                "name": source.name,
                "kind": source.kind,
                "status": source.status,
                "is_enabled": source.is_enabled,
                "allow_writes": source.allow_writes,
                "callable": source.kind in CALLABLE_KINDS,
            }
            for source in data_sources.list_for_project(self._session, self._project_id)
        ]

    def tool_fetch(self, source: str, path: str, method: str = "GET") -> dict[str, Any]:
        row = self._resolve(source)

        if row.kind not in CALLABLE_KINDS:
            raise ToolExecutionError(
                f"'{row.name}' is a {row.kind} source. This build can call HTTP-shaped "
                f"sources ({', '.join(CALLABLE_KINDS)}); reading a {row.kind} needs its "
                "own driver and is not implemented, so nothing was fetched."
            )

        method = (method or "GET").upper()
        if method != "GET" and not row.allow_writes:
            raise ToolExecutionError(
                f"'{row.name}' is connected read-only. A {method} needs the source to be "
                "changed to allow writes, which is a decision for its owner."
            )

        base = (row.config or {}).get("base_url") or (row.config or {}).get("endpoint") or ""
        if not base:
            raise ToolExecutionError(f"'{row.name}' has no base URL configured.")

        # Join, then re-check the address: `path` comes from a model, and a
        # model reads untrusted content. An absolute URL or a `..` that climbed
        # out of the base would otherwise be a way to aim this at any host.
        url = urljoin(base if base.endswith("/") else base + "/", path.lstrip("/"))
        parsed = urlparse(url)
        if parsed.netloc != urlparse(base).netloc:
            raise ToolExecutionError(
                "That path resolves outside the data source's own host, so it was not fetched."
            )
        try:
            resolve_public(parsed.hostname or "", parsed.port or (443 if parsed.scheme == "https" else 80))
        except AddressRefused as refused:
            raise ToolExecutionError(str(refused)) from None

        import httpx  # noqa: PLC0415

        secrets = data_sources.credentials(row)
        headers = {"Accept": "application/json"}
        if token := (secrets.get("bearer_token") or secrets.get("api_token")):
            headers["Authorization"] = f"Bearer {token}"
        elif key := secrets.get("api_key"):
            headers["X-API-Key"] = key

        try:
            response = httpx.request(
                method, url, headers=headers, timeout=TIMEOUT_SECONDS, follow_redirects=False
            )
        except httpx.HTTPError as error:
            raise ToolExecutionError(f"The request to '{row.name}' failed: {error}") from None

        logger.info(
            "tenant_data_fetch",
            project_id=self._project_id,
            source=row.key,
            status=response.status_code,
        )

        try:
            body = response.json()
        except ValueError:
            body = response.text[:4000]

        # Deliberately no request headers in the result: they carry the token,
        # and this result is written to the run ledger.
        return {
            "source": row.key,
            "url": url,
            "status_code": response.status_code,
            "body": body,
        }
