"""Confluence, Git, Database and CI/CD MCP servers (demo adapters).

Each reads genuine project state -- indexed knowledge documents, seeded
repository metadata, test data sets -- so agents receive answers grounded in the
same data the UI displays.
"""

from __future__ import annotations

import hashlib
import re
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import ToolExecutionError
from app.mcp.base import MCPServerAdapter, ToolDefinition, ToolParameter
from app.models.knowledge import KnowledgeDocument
from app.models.project import Project
from app.models.testing import TestDataSet

# ---------------------------------------------------------------------------
# Confluence
# ---------------------------------------------------------------------------

CONFLUENCE_TOOLS = [
    ToolDefinition(
        name="get_page",
        description="Retrieve a Confluence page by title or external id.",
        parameters=[ToolParameter("page_ref", "string", "Page title or id", required=True)],
    ),
    ToolDefinition(
        name="search_pages",
        description="Search Confluence pages by keyword.",
        parameters=[
            ToolParameter("query", "string", "Search term", required=True),
            ToolParameter("limit", "integer", "Maximum results", default=5),
        ],
    ),
    ToolDefinition(
        name="list_spaces",
        description="List the Confluence spaces configured for this project.",
        parameters=[],
    ),
]


class ConfluenceDemoAdapter(MCPServerAdapter):
    key = "confluence"
    display_name = "Confluence MCP"
    description = "Requirements, SOPs and architecture documentation."
    connector_mode = "demo"

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        super().__init__(context)
        self.session: Session = self.context["session"]
        self.project_id: str = self.context["project_id"]

    def list_tools(self) -> list[ToolDefinition]:
        return CONFLUENCE_TOOLS

    def tool_get_page(self, page_ref: str) -> dict[str, Any]:
        document = self.session.execute(
            select(KnowledgeDocument).where(
                KnowledgeDocument.project_id == self.project_id,
                KnowledgeDocument.source_type == "confluence",
                (KnowledgeDocument.external_id == page_ref) | (KnowledgeDocument.title == page_ref),
            )
        ).scalar_one_or_none()
        if document is None:
            raise ToolExecutionError(f"Confluence page '{page_ref}' was not found.")
        return {
            "page_id": document.external_id,
            "title": document.title,
            "content": document.content,
            "version": document.version,
            "module": document.module,
            "url": document.url,
            "author": document.author,
        }

    def tool_search_pages(self, query: str, limit: int = 5) -> dict[str, Any]:
        pattern = f"%{query}%"
        rows = list(
            self.session.execute(
                select(KnowledgeDocument)
                .where(
                    KnowledgeDocument.project_id == self.project_id,
                    KnowledgeDocument.source_type == "confluence",
                    (KnowledgeDocument.title.ilike(pattern)) | (KnowledgeDocument.content.ilike(pattern)),
                )
                .limit(max(1, min(limit, 25)))
            )
            .scalars()
            .all()
        )
        return {
            "total": len(rows),
            "pages": [
                {
                    "page_id": row.external_id,
                    "title": row.title,
                    "module": row.module,
                    "excerpt": row.content[:280],
                }
                for row in rows
            ],
        }

    def tool_list_spaces(self) -> dict[str, Any]:
        project = self.session.get(Project, self.project_id)
        space = project.confluence_space if project else None
        return {"spaces": [{"key": space, "name": f"{project.name} Space"}] if space else []}


# ---------------------------------------------------------------------------
# Git
# ---------------------------------------------------------------------------

GIT_TOOLS = [
    ToolDefinition(
        name="list_repositories",
        description="List repositories registered for this project.",
        parameters=[],
    ),
    ToolDefinition(
        name="get_file",
        description="Read a source file from the indexed code context.",
        parameters=[ToolParameter("path", "string", "Repository-relative file path", required=True)],
    ),
    ToolDefinition(
        name="list_changed_files",
        description="List files changed for a module or recent commit window.",
        parameters=[
            ToolParameter("module", "string", "Functional module"),
            ToolParameter("since_days", "integer", "Look-back window in days", default=14),
        ],
    ),
    ToolDefinition(
        name="get_commit_history",
        description="Recent commit history, optionally filtered by module.",
        parameters=[
            ToolParameter("module", "string", "Functional module"),
            ToolParameter("limit", "integer", "Maximum commits", default=10),
        ],
    ),
]


class GitDemoAdapter(MCPServerAdapter):
    key = "git"
    display_name = "Git MCP"
    description = "Repository, code context and change history."
    connector_mode = "demo"

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        super().__init__(context)
        self.session: Session = self.context["session"]
        self.project_id: str = self.context["project_id"]

    def list_tools(self) -> list[ToolDefinition]:
        return GIT_TOOLS

    def _code_documents(self) -> list[KnowledgeDocument]:
        return list(
            self.session.execute(
                select(KnowledgeDocument).where(
                    KnowledgeDocument.project_id == self.project_id,
                    KnowledgeDocument.source_type == "git",
                )
            )
            .scalars()
            .all()
        )

    def tool_list_repositories(self) -> dict[str, Any]:
        project = self.session.get(Project, self.project_id)
        if project is None or not project.git_repository:
            return {"repositories": []}
        return {
            "repositories": [
                {
                    "name": project.git_repository.rstrip("/").rsplit("/", 1)[-1],
                    "url": project.git_repository,
                    "default_branch": "main",
                    "modules": project.modules,
                }
            ]
        }

    def tool_get_file(self, path: str) -> dict[str, Any]:
        document = next(
            (doc for doc in self._code_documents() if doc.external_id == path or doc.title == path), None
        )
        if document is None:
            raise ToolExecutionError(f"File '{path}' is not present in the indexed code context.")
        return {
            "path": document.external_id,
            "content": document.content,
            "module": document.module,
            "size_bytes": len(document.content.encode()),
        }

    def tool_list_changed_files(self, module: str | None = None, since_days: int = 14) -> dict[str, Any]:
        cutoff = datetime.now(UTC) - timedelta(days=max(1, since_days))
        documents = [
            doc
            for doc in self._code_documents()
            if (module is None or doc.module == module) and doc.updated_at.replace(tzinfo=UTC) >= cutoff
        ]
        return {
            "since": cutoff.isoformat(),
            "module": module,
            "files": [
                {
                    "path": doc.external_id,
                    "module": doc.module,
                    "last_modified": doc.updated_at.isoformat(),
                    "change_type": "modified",
                }
                for doc in documents
            ],
        }

    def tool_get_commit_history(self, module: str | None = None, limit: int = 10) -> dict[str, Any]:
        """Derive a stable commit log from indexed code documents.

        Hashes are deterministic functions of the document identity, so the same
        project always shows the same history across resets.
        """
        documents = [doc for doc in self._code_documents() if module is None or doc.module == module]
        commits: list[dict[str, Any]] = []
        for index, doc in enumerate(documents[: max(1, min(limit, 50))]):
            digest = hashlib.sha1(f"{doc.id}:{doc.version}".encode()).hexdigest()  # noqa: S324
            commits.append(
                {
                    "sha": digest[:10],
                    "message": f"Update {doc.module} - {doc.title}",
                    "author": doc.author or "platform.engineer",
                    "module": doc.module,
                    "files": [doc.external_id],
                    "committed_at": (doc.updated_at - timedelta(hours=index)).isoformat(),
                }
            )
        return {"total": len(commits), "commits": commits}


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

DATABASE_TOOLS = [
    ToolDefinition(
        name="execute_read_query",
        description="Run a read-only SELECT against a test data set. Writes are rejected.",
        parameters=[
            ToolParameter("query", "string", "SELECT statement", required=True),
            ToolParameter("data_set", "string", "Target data set name"),
            ToolParameter("limit", "integer", "Maximum rows", default=25),
        ],
        risk_level="medium",
    ),
    ToolDefinition(
        name="validate_record",
        description="Assert that a record with the given field values exists.",
        parameters=[
            ToolParameter("data_set", "string", "Data set name", required=True),
            ToolParameter("filters", "object", "Field/value pairs to match", required=True),
        ],
    ),
    ToolDefinition(
        name="compare_results",
        description="Compare an expected payload against a stored record.",
        parameters=[
            ToolParameter("data_set", "string", "Data set name", required=True),
            ToolParameter("expected", "object", "Expected field values", required=True),
            ToolParameter("key_field", "string", "Field used to locate the record", required=True),
        ],
    ),
    ToolDefinition(
        name="generate_sql",
        description="Generate parameterised SQL for a data-setup or validation intent.",
        parameters=[
            ToolParameter("intent", "string", "insert | select | cleanup", required=True, enum=["insert", "select", "cleanup"]),
            ToolParameter("table", "string", "Target table", required=True),
            ToolParameter("fields", "array", "Column names"),
        ],
    ),
]

_WRITE_STATEMENT = re.compile(
    r"\b(insert|update|delete|drop|truncate|alter|create|grant|revoke)\b", re.IGNORECASE
)


class DatabaseDemoAdapter(MCPServerAdapter):
    key = "database"
    display_name = "Database MCP"
    description = "Read-only query, record validation and SQL generation."
    connector_mode = "demo"

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        super().__init__(context)
        self.session: Session = self.context["session"]
        self.project_id: str = self.context["project_id"]

    def list_tools(self) -> list[ToolDefinition]:
        return DATABASE_TOOLS

    def _data_set(self, name: str | None) -> TestDataSet | None:
        statement = select(TestDataSet).where(
            TestDataSet.project_id == self.project_id, TestDataSet.is_deleted.is_(False)
        )
        if name:
            statement = statement.where(TestDataSet.name == name)
        return self.session.execute(statement).scalars().first()

    def tool_execute_read_query(
        self, query: str, data_set: str | None = None, limit: int = 25
    ) -> dict[str, Any]:
        # Read-only enforcement: the tool refuses anything that mutates state,
        # regardless of what an agent or a prompt-injected document asks for.
        if _WRITE_STATEMENT.search(query):
            raise ToolExecutionError(
                "Only read-only SELECT statements are permitted through the Database MCP."
            )
        if not query.strip().lower().startswith("select"):
            raise ToolExecutionError("Query must begin with SELECT.")

        target = self._data_set(data_set)
        if target is None:
            raise ToolExecutionError("No test data set is available for this project.")

        rows = (target.records or [])[: max(1, min(limit, 200))]
        columns = list(rows[0].keys()) if rows else list((target.schema_definition or {}).get("fields", []))
        return {"data_set": target.name, "columns": columns, "row_count": len(rows), "rows": rows}

    def tool_validate_record(self, data_set: str, filters: dict[str, Any]) -> dict[str, Any]:
        target = self._data_set(data_set)
        if target is None:
            raise ToolExecutionError(f"Data set '{data_set}' was not found.")
        matches = [
            record
            for record in (target.records or [])
            if all(str(record.get(key)) == str(value) for key, value in filters.items())
        ]
        return {
            "data_set": data_set,
            "filters": filters,
            "exists": bool(matches),
            "match_count": len(matches),
            "sample": matches[0] if matches else None,
        }

    def tool_compare_results(
        self, data_set: str, expected: dict[str, Any], key_field: str
    ) -> dict[str, Any]:
        target = self._data_set(data_set)
        if target is None:
            raise ToolExecutionError(f"Data set '{data_set}' was not found.")
        key_value = expected.get(key_field)
        actual = next(
            (record for record in (target.records or []) if str(record.get(key_field)) == str(key_value)),
            None,
        )
        if actual is None:
            return {"matched": False, "reason": f"No record found where {key_field}={key_value}.", "differences": []}

        differences = [
            {"field": field, "expected": value, "actual": actual.get(field)}
            for field, value in expected.items()
            if str(actual.get(field)) != str(value)
        ]
        return {"matched": not differences, "differences": differences, "actual": actual}

    def tool_generate_sql(self, intent: str, table: str, fields: list[str] | None = None) -> dict[str, Any]:
        columns = fields or ["id", "created_at"]
        if intent == "insert":
            placeholders = ", ".join(f":{column}" for column in columns)
            sql = f"INSERT INTO {table} ({', '.join(columns)})\nVALUES ({placeholders});"
        elif intent == "cleanup":
            sql = f"DELETE FROM {table}\nWHERE {columns[0]} = :{columns[0]};"
        else:
            sql = f"SELECT {', '.join(columns)}\nFROM {table}\nWHERE {columns[0]} = :{columns[0]};"
        return {
            "intent": intent,
            "table": table,
            "sql": sql,
            "parameters": columns,
            "note": "Parameterised to avoid SQL injection; bind values at execution time.",
        }


# ---------------------------------------------------------------------------
# CI/CD
# ---------------------------------------------------------------------------

CICD_TOOLS = [
    ToolDefinition(
        name="trigger_pipeline",
        description="Trigger a CI pipeline for a branch or suite.",
        parameters=[
            ToolParameter("pipeline", "string", "Pipeline name", required=True),
            ToolParameter("branch", "string", "Branch", default="main"),
            ToolParameter("suite", "string", "Test suite to run"),
        ],
        mutating=True,
        risk_level="high",
        requires_approval=True,
    ),
    ToolDefinition(
        name="get_pipeline_status",
        description="Fetch the status of a pipeline run.",
        parameters=[ToolParameter("pipeline", "string", "Pipeline name", required=True)],
    ),
    ToolDefinition(
        name="get_build_artifacts",
        description="List artifacts produced by a pipeline run.",
        parameters=[ToolParameter("pipeline", "string", "Pipeline name", required=True)],
    ),
]


class CICDDemoAdapter(MCPServerAdapter):
    key = "cicd"
    display_name = "CI/CD MCP"
    description = "Pipeline triggering and build status."
    connector_mode = "demo"

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        super().__init__(context)
        self.project_id: str = self.context.get("project_id", "")

    def list_tools(self) -> list[ToolDefinition]:
        return CICD_TOOLS

    def tool_trigger_pipeline(
        self, pipeline: str, branch: str = "main", suite: str | None = None
    ) -> dict[str, Any]:
        run_id = hashlib.sha1(f"{self.project_id}:{pipeline}:{branch}".encode()).hexdigest()[:8]  # noqa: S324
        return {
            "pipeline": pipeline,
            "branch": branch,
            "suite": suite,
            "run_id": run_id,
            "status": "queued",
            "queued_at": datetime.now(UTC).isoformat(),
            "note": "Demo connector: pipeline trigger recorded but no external system was called.",
        }

    def tool_get_pipeline_status(self, pipeline: str) -> dict[str, Any]:
        digest = int(hashlib.sha1(f"{self.project_id}:{pipeline}".encode()).hexdigest()[:6], 16)  # noqa: S324
        statuses = ["succeeded", "succeeded", "running", "failed"]
        return {
            "pipeline": pipeline,
            "status": statuses[digest % len(statuses)],
            "duration_seconds": 180 + (digest % 420),
            "last_run_at": (datetime.now(UTC) - timedelta(hours=digest % 12)).isoformat(),
        }

    def tool_get_build_artifacts(self, pipeline: str) -> dict[str, Any]:
        return {
            "pipeline": pipeline,
            "artifacts": [
                {"name": "test-report.html", "type": "report", "size_kb": 412},
                {"name": "junit-results.xml", "type": "junit", "size_kb": 88},
                {"name": "coverage.xml", "type": "coverage", "size_kb": 54},
            ],
        }
