"""Jira MCP server.

The demo adapter is backed by real rows in `requirements` and `defects`, so
tool calls read and write genuine application state rather than returning
canned literals. `JiraRestAdapter` is the seam where a real Jira client drops
in behind the identical tool surface.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.errors import ToolExecutionError
from app.mcp.base import MCPServerAdapter, ToolDefinition, ToolParameter
from app.models.defect import Defect
from app.models.testing import Requirement

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="get_story",
        description="Fetch a user story with its acceptance criteria by issue key.",
        parameters=[ToolParameter("issue_key", "string", "Jira issue key, e.g. PAY-201", required=True)],
    ),
    ToolDefinition(
        name="search_stories",
        description="Search stories by text, module, status or sprint.",
        parameters=[
            ToolParameter("query", "string", "Free-text search term"),
            ToolParameter("module", "string", "Restrict to a functional module"),
            ToolParameter("status", "string", "Restrict to a workflow status"),
            ToolParameter("limit", "integer", "Maximum results", default=10),
        ],
    ),
    ToolDefinition(
        name="update_story",
        description="Update the status or add labels to a story.",
        parameters=[
            ToolParameter("issue_key", "string", "Jira issue key", required=True),
            ToolParameter("status", "string", "New workflow status"),
            ToolParameter("labels", "array", "Labels to add"),
        ],
        mutating=True,
        risk_level="medium",
        requires_approval=True,
    ),
    ToolDefinition(
        name="create_defect",
        description="Raise a defect against a module with reproduction steps.",
        parameters=[
            ToolParameter("title", "string", "Defect summary", required=True),
            ToolParameter("description", "string", "Detailed description", required=True),
            ToolParameter("module", "string", "Affected module"),
            ToolParameter("severity", "string", "Severity", enum=["blocker", "critical", "major", "minor", "trivial"]),
            ToolParameter("priority", "string", "Priority", enum=["critical", "high", "medium", "low"]),
            ToolParameter("steps_to_reproduce", "array", "Ordered reproduction steps"),
        ],
        mutating=True,
        risk_level="high",
        requires_approval=True,
    ),
    ToolDefinition(
        name="add_comment",
        description="Add a comment to a story or defect.",
        parameters=[
            ToolParameter("issue_key", "string", "Issue key", required=True),
            ToolParameter("comment", "string", "Comment body", required=True),
        ],
        mutating=True,
        risk_level="medium",
    ),
]


class JiraDemoAdapter(MCPServerAdapter):
    key = "jira"
    display_name = "Jira MCP"
    description = "Story, defect and comment operations against the project tracker."
    connector_mode = "demo"

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        super().__init__(context)
        self.session: Session = self.context["session"]
        self.project_id: str = self.context["project_id"]

    def list_tools(self) -> list[ToolDefinition]:
        return TOOLS

    # ----- read tools --------------------------------------------------------
    def tool_get_story(self, issue_key: str) -> dict[str, Any]:
        requirement = self.session.execute(
            select(Requirement).where(
                Requirement.project_id == self.project_id, Requirement.external_key == issue_key
            )
        ).scalar_one_or_none()
        if requirement is None:
            raise ToolExecutionError(f"Story '{issue_key}' was not found in this project.")
        return self._serialize_requirement(requirement)

    def tool_search_stories(
        self,
        query: str | None = None,
        module: str | None = None,
        status: str | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        statement = select(Requirement).where(
            Requirement.project_id == self.project_id, Requirement.is_deleted.is_(False)
        )
        if query:
            pattern = f"%{query}%"
            statement = statement.where(
                or_(
                    Requirement.title.ilike(pattern),
                    Requirement.description.ilike(pattern),
                    Requirement.external_key.ilike(pattern),
                )
            )
        if module:
            statement = statement.where(Requirement.module == module)
        if status:
            statement = statement.where(Requirement.status == status)

        rows = list(self.session.execute(statement.limit(max(1, min(limit, 50)))).scalars().all())
        return {
            "total": len(rows),
            "stories": [self._serialize_requirement(row, include_body=False) for row in rows],
        }

    # ----- write tools -------------------------------------------------------
    def tool_update_story(
        self, issue_key: str, status: str | None = None, labels: list[str] | None = None
    ) -> dict[str, Any]:
        requirement = self.session.execute(
            select(Requirement).where(
                Requirement.project_id == self.project_id, Requirement.external_key == issue_key
            )
        ).scalar_one_or_none()
        if requirement is None:
            raise ToolExecutionError(f"Story '{issue_key}' was not found in this project.")

        changes: dict[str, Any] = {}
        if status:
            changes["status"] = {"from": requirement.status, "to": status}
            requirement.status = status
        if labels:
            merged = sorted(set(requirement.labels or []) | set(labels))
            changes["labels"] = {"from": requirement.labels, "to": merged}
            requirement.labels = merged
        self.session.flush()
        return {"issue_key": issue_key, "updated": True, "changes": changes}

    def tool_create_defect(
        self,
        title: str,
        description: str,
        module: str = "General",
        severity: str = "major",
        priority: str = "medium",
        steps_to_reproduce: list[str] | None = None,
    ) -> dict[str, Any]:
        sequence = (
            self.session.execute(
                select(Defect).where(Defect.project_id == self.project_id).order_by(Defect.created_at.desc())
            )
            .scalars()
            .first()
        )
        next_number = 1
        if sequence is not None and sequence.external_key and "-" in sequence.external_key:
            try:
                next_number = int(sequence.external_key.rsplit("-", 1)[1]) + 1
            except ValueError:
                next_number = 1

        defect = Defect(
            project_id=self.project_id,
            external_key=f"DEF-{next_number:04d}",
            title=title,
            description=description,
            module=module,
            severity=severity,
            priority=priority,
            steps_to_reproduce=steps_to_reproduce or [],
            source="agent",
            is_ai_suggested=True,
            status="open",
            jira_sync_state="synced_demo",
        )
        self.session.add(defect)
        self.session.flush()
        return {
            "defect_id": defect.id,
            "issue_key": defect.external_key,
            "created": True,
            "url": f"https://jira.example.com/browse/{defect.external_key}",
        }

    def tool_add_comment(self, issue_key: str, comment: str) -> dict[str, Any]:
        requirement = self.session.execute(
            select(Requirement).where(
                Requirement.project_id == self.project_id, Requirement.external_key == issue_key
            )
        ).scalar_one_or_none()
        target = "requirement"
        if requirement is None:
            defect = self.session.execute(
                select(Defect).where(
                    Defect.project_id == self.project_id, Defect.external_key == issue_key
                )
            ).scalar_one_or_none()
            if defect is None:
                raise ToolExecutionError(f"Issue '{issue_key}' was not found in this project.")
            defect.labels = sorted(set(defect.labels or []) | {"ai-comment"})
            target = "defect"
            self.session.flush()

        return {
            "issue_key": issue_key,
            "target": target,
            "comment_added": True,
            "created_at": datetime.now(UTC).isoformat(),
        }

    # ----- helpers -----------------------------------------------------------
    @staticmethod
    def _serialize_requirement(requirement: Requirement, include_body: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "issue_key": requirement.external_key,
            "id": requirement.id,
            "title": requirement.title,
            "status": requirement.status,
            "priority": requirement.priority,
            "module": requirement.module,
            "epic": requirement.epic,
            "sprint": requirement.sprint,
            "story_points": requirement.story_points,
            "labels": requirement.labels,
            "acceptance_criteria": requirement.acceptance_criteria,
        }
        if include_body:
            payload["description"] = requirement.description
        return payload


class JiraRestAdapter(JiraDemoAdapter):
    """Placeholder for the real Jira connector.

    Subclassing keeps the tool surface identical; each `tool_*` method would be
    reimplemented against the Jira REST API using credentials resolved from the
    secret store. Until that work lands, the mode is reported honestly so the
    Integrations screen never claims a live connection that does not exist.
    """

    connector_mode = "real"

    def health(self) -> dict[str, Any]:
        return {
            "server": self.key,
            "display_name": self.display_name,
            "status": "not_implemented",
            "connector_mode": self.connector_mode,
            "detail": "Real Jira connector is not implemented in this build; configure demo mode.",
            "tool_count": len(self.list_tools()),
        }
