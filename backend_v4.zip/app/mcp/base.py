"""MCP abstraction: discoverable tools behind a uniform, governed interface.

Agents never touch Jira, a database or a browser directly. They call a tool by
name; the registry resolves the server, the governance layer authorises the
call, and the adapter performs it. Demo adapters and real connectors implement
the same `MCPServerAdapter` contract, so switching one for the other is
configuration (spec sections 9 and 38).
"""

from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from app.core.errors import ToolExecutionError
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass(slots=True)
class ToolParameter:
    name: str
    type: str = "string"
    description: str = ""
    required: bool = False
    enum: list[str] | None = None
    default: Any = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "type": self.type,
            "description": self.description,
            "required": self.required,
        }
        if self.enum:
            payload["enum"] = self.enum
        if self.default is not None:
            payload["default"] = self.default
        return payload


@dataclass(slots=True)
class ToolDefinition:
    """Discoverable description of one tool."""

    name: str
    description: str
    parameters: list[ToolParameter] = field(default_factory=list)
    # Read-only tools can run unattended; mutating ones can require approval.
    mutating: bool = False
    risk_level: str = "low"
    requires_approval: bool = False
    returns: str = "object"

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": [parameter.to_dict() for parameter in self.parameters],
            "mutating": self.mutating,
            "risk_level": self.risk_level,
            "requires_approval": self.requires_approval,
            "returns": self.returns,
        }

    def to_openai_tool(self) -> dict[str, Any]:
        """Render as an OpenAI/Azure tool-calling schema."""
        properties: dict[str, Any] = {}
        required: list[str] = []
        for parameter in self.parameters:
            entry: dict[str, Any] = {"type": parameter.type, "description": parameter.description}
            if parameter.enum:
                entry["enum"] = parameter.enum
            properties[parameter.name] = entry
            if parameter.required:
                required.append(parameter.name)
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {"type": "object", "properties": properties, "required": required},
            },
        }


@dataclass(slots=True)
class ToolResult:
    tool: str
    server: str
    success: bool
    data: Any = None
    error: str | None = None
    duration_ms: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool": self.tool,
            "server": self.server,
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "metadata": self.metadata,
        }


class MCPServerAdapter(abc.ABC):
    """Base class for every MCP server, demo or real."""

    key: str = "base"
    display_name: str = "MCP Server"
    description: str = ""
    connector_mode: str = "demo"

    def __init__(self, context: dict[str, Any] | None = None) -> None:
        # Carries project_id, environment and a database session where needed.
        self.context = context or {}

    @abc.abstractmethod
    def list_tools(self) -> list[ToolDefinition]: ...

    def tool(self, name: str) -> ToolDefinition | None:
        return next((definition for definition in self.list_tools() if definition.name == name), None)

    def _handler(self, name: str) -> Callable[..., Any] | None:
        """Tools map to `tool_<name>` methods on the adapter."""
        return getattr(self, f"tool_{name}", None)

    def invoke(self, name: str, arguments: dict[str, Any] | None = None) -> ToolResult:
        definition = self.tool(name)
        if definition is None:
            return ToolResult(
                tool=name, server=self.key, success=False, error=f"Tool '{name}' is not exposed by {self.key}."
            )

        handler = self._handler(name)
        if handler is None:  # pragma: no cover - guards a mis-declared tool
            return ToolResult(
                tool=name, server=self.key, success=False, error=f"Tool '{name}' has no implementation."
            )

        arguments = arguments or {}
        missing = [
            parameter.name
            for parameter in definition.parameters
            if parameter.required and parameter.name not in arguments
        ]
        if missing:
            return ToolResult(
                tool=name,
                server=self.key,
                success=False,
                error=f"Missing required argument(s): {', '.join(missing)}.",
            )

        started = time.perf_counter()
        try:
            data = handler(**arguments)
            duration_ms = int((time.perf_counter() - started) * 1000)
            logger.debug("tool_invoked", server=self.key, tool=name, duration_ms=duration_ms)
            return ToolResult(
                tool=name,
                server=self.key,
                success=True,
                data=data,
                duration_ms=duration_ms,
                metadata={"connector_mode": self.connector_mode},
            )
        except ToolExecutionError as exc:
            return ToolResult(
                tool=name,
                server=self.key,
                success=False,
                error=exc.message,
                duration_ms=int((time.perf_counter() - started) * 1000),
            )
        except Exception as exc:  # noqa: BLE001 - tool failures must not kill a run
            logger.warning("tool_failed", server=self.key, tool=name, error=str(exc)[:200])
            return ToolResult(
                tool=name,
                server=self.key,
                success=False,
                error=str(exc)[:400],
                duration_ms=int((time.perf_counter() - started) * 1000),
            )

    def health(self) -> dict[str, Any]:
        return {
            "server": self.key,
            "display_name": self.display_name,
            "status": "online",
            "connector_mode": self.connector_mode,
            "tool_count": len(self.list_tools()),
        }
