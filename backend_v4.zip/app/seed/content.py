"""Synthetic content for the demo project.

An ABC Retailer digital experience: realistic stories, documentation, defects
and code context. Deliberately uneven -- some stories are well-formed, others
have gaps -- so the completeness, coverage and risk agents have something real
to find rather than a uniformly perfect corpus.
"""

from __future__ import annotations

from typing import Any

PROJECT_KEY = "ABCR"
PROJECT_NAME = "ABC Retailer Digital Experience"

MODULES: list[str] = [
    "Login",
    "Customer Profile",
    "Accounts",
    "Payments",
    "Beneficiaries",
    "Transaction History",
]

ENVIRONMENTS: list[dict[str, Any]] = [
    {
        "key": "dev",
        "name": "Development",
        "base_url": "https://dev.abcr.example.test",
        "api_base_url": "https://api-dev.abcr.example.test",
        "is_production_like": False,
        "allows_write_actions": True,
        "database_alias": "abcr_dev",
        "description": "Feature development and unit-level verification.",
    },
    {
        "key": "sit",
        "name": "System Integration Test",
        "base_url": "https://sit.abcr.example.test",
        "api_base_url": "https://api-sit.abcr.example.test",
        "is_production_like": False,
        "allows_write_actions": True,
        "database_alias": "abcr_sit",
        "description": "Integrated component testing with stubbed third parties.",
    },
    {
        "key": "uat",
        "name": "User Acceptance Test",
        "base_url": "https://uat.abcr.example.test",
        "api_base_url": "https://api-uat.abcr.example.test",
        "is_production_like": True,
        "allows_write_actions": True,
        "database_alias": "abcr_uat",
        "description": "Business acceptance with production-like data volumes.",
    },
    {
        "key": "perf",
        "name": "Performance",
        "base_url": "https://perf.abcr.example.test",
        "api_base_url": "https://api-perf.abcr.example.test",
        "is_production_like": True,
        "allows_write_actions": True,
        "database_alias": "abcr_perf",
        "description": "Load and endurance testing at production scale.",
    },
    {
        "key": "prod",
        "name": "Production",
        "base_url": "https://abcr.example.test",
        "api_base_url": "https://api.abcr.example.test",
        "is_production_like": True,
        # Governance: no agent may perform a write action here.
        "allows_write_actions": False,
        "database_alias": "abcr_prod",
        "description": "Live environment. Read-only for automation and agents.",
    },
]


# ---------------------------------------------------------------------------
# Requirements
# ---------------------------------------------------------------------------
# `quality` marks how complete each story is, which the completeness agent
# independently rediscovers from the content itself.

REQUIREMENTS: list[dict[str, Any]] = [
    {
        "key": "LOGIN-101",
        "module": "Login",
        "title": "Customer authenticates with username and password",
        "priority": "critical",
        "status": "done",
        "points": 5,
        "epic": "Secure Access",
        "sprint": "Sprint 41",
        "quality": "high",
        "description": (
            "As an ABC Retailer customer I want to sign in with my username and password so that I can "
            "access my accounts securely.\n\n"
            "The sign-in form must validate that both fields are present before submission. On success the "
            "customer is taken to the account dashboard and a session is established with a 15 minute "
            "inactivity timeout. On failure the system must return a generic error that does not reveal "
            "whether the username exists, to avoid account enumeration.\n\n"
            "After five consecutive invalid password attempts the account is locked for 30 minutes and an "
            "email notification is sent. The lockout counter resets on a successful sign-in. The "
            "authentication service must respond within 800ms at the 95th percentile under normal load, and "
            "the form must be fully operable by keyboard."
        ),
        "acceptance_criteria": [
            "Given valid credentials, when the customer signs in, then the account dashboard is displayed within 3 seconds.",
            "Given an invalid password, when the customer signs in, then a generic error is shown and no indication is given as to whether the username exists.",
            "Given five consecutive failed attempts, when the customer submits again, then the account is locked for 30 minutes and a notification email is sent.",
            "Given a locked account, when valid credentials are supplied, then sign-in is refused with a lockout message and the remaining lock duration.",
            "Given an established session, when the customer is inactive for 15 minutes, then the session expires and re-authentication is required.",
        ],
        "labels": ["security", "authentication", "critical-path"],
        "change_frequency": 4,
        "risk_score": 0.72,
    },
    {
        "key": "LOGIN-102",
        "module": "Login",
        "title": "Customer resets a forgotten password",
        "priority": "high",
        "status": "in_test",
        "points": 3,
        "epic": "Secure Access",
        "sprint": "Sprint 42",
        "quality": "medium",
        "description": (
            "As a customer who has forgotten my password I want to reset it so that I can regain access.\n\n"
            "The customer requests a reset link by email. The link is single-use and expires after 30 minutes. "
            "The new password must satisfy the password policy."
        ),
        "acceptance_criteria": [
            "Given a registered email, when a reset is requested, then a single-use link valid for 30 minutes is sent.",
            "Given an expired reset link, when it is opened, then the customer is told the link has expired and is offered a new one.",
        ],
        "labels": ["authentication", "self-service"],
        "change_frequency": 2,
        "risk_score": 0.48,
    },
    {
        "key": "PAY-201",
        "module": "Payments",
        "title": "Customer makes a domestic payment to a saved beneficiary",
        "priority": "critical",
        "status": "in_test",
        "points": 8,
        "epic": "Move Money",
        "sprint": "Sprint 42",
        "quality": "high",
        "description": (
            "As a customer I want to send money to a beneficiary I have already saved so that I can pay "
            "people I trust quickly.\n\n"
            "The customer selects a verified beneficiary, enters an amount and an optional reference, and "
            "confirms. The system validates that the amount is greater than zero, that sufficient funds are "
            "available including any arranged overdraft, and that the amount does not exceed the customer's "
            "daily payment limit of 10,000 in account currency.\n\n"
            "Payments above 1,000 require step-up authentication via a one-time passcode. On success the "
            "payment is submitted to the payment gateway, the customer sees a confirmation with the payment "
            "reference, and the transaction appears in transaction history immediately with status Pending. "
            "If the gateway is unavailable the payment must not be debited and the customer must see a clear "
            "retry message. Duplicate submissions within 60 seconds for the same beneficiary and amount must "
            "be rejected as a potential duplicate."
        ),
        "acceptance_criteria": [
            "Given a verified beneficiary and sufficient funds, when the customer submits a payment of 500, then the payment is accepted and a reference is displayed.",
            "Given a payment amount that exceeds the available balance, when the customer submits, then the payment is rejected with an insufficient funds message and no debit occurs.",
            "Given a cumulative daily total that would exceed 10,000, when the customer submits, then the payment is rejected with a daily limit message.",
            "Given a payment above 1,000, when the customer confirms, then a one-time passcode is required before the payment is submitted.",
            "Given the payment gateway is unavailable, when the customer submits, then no debit occurs and a retry message is displayed.",
            "Given an identical payment submitted within 60 seconds, when the customer confirms, then the duplicate is rejected.",
        ],
        "labels": ["payments", "critical-path", "regulatory"],
        "change_frequency": 9,
        "risk_score": 0.91,
    },
    {
        "key": "PAY-202",
        "module": "Payments",
        "title": "Customer schedules a future-dated payment",
        "priority": "high",
        "status": "in_development",
        "points": 5,
        "epic": "Move Money",
        "sprint": "Sprint 43",
        "quality": "medium",
        "description": (
            "As a customer I want to schedule a payment for a future date so that bills are paid on time.\n\n"
            "The customer chooses a date up to 12 months ahead. Scheduled payments can be cancelled up to "
            "23:59 the day before execution. Sufficient funds are checked on the execution date, not at "
            "scheduling time."
        ),
        "acceptance_criteria": [
            "Given a valid future date within 12 months, when the payment is scheduled, then it appears in the scheduled payments list.",
            "Given a date more than 12 months ahead, when the customer submits, then the payment is rejected with a validation message.",
            "Given insufficient funds on the execution date, when the payment executes, then it fails and the customer is notified.",
        ],
        "labels": ["payments", "scheduling"],
        "change_frequency": 6,
        "risk_score": 0.66,
    },
    {
        "key": "PAY-203",
        "module": "Payments",
        "title": "Customer cancels a scheduled payment",
        "priority": "medium",
        "status": "ready",
        "points": 2,
        "epic": "Move Money",
        "sprint": "Sprint 43",
        "quality": "low",
        "description": "Customer should be able to cancel a scheduled payment before it executes.",
        "acceptance_criteria": [],
        "labels": ["payments"],
        "change_frequency": 1,
        "risk_score": 0.35,
    },
    {
        "key": "ACC-301",
        "module": "Accounts",
        "title": "Customer views account balances and details",
        "priority": "critical",
        "status": "done",
        "points": 3,
        "epic": "Account Insight",
        "sprint": "Sprint 40",
        "quality": "high",
        "description": (
            "As a customer I want to see all my accounts and their balances so that I know where I stand.\n\n"
            "The dashboard lists every account the customer holds with the account name, masked account "
            "number showing only the last four digits, currency, available balance and current balance. "
            "Accounts are ordered with current accounts first, then savings, then credit. Closed accounts are "
            "hidden by default but can be revealed.\n\n"
            "Balances must be no more than 60 seconds stale. If the balance service is unavailable the "
            "account is shown with a clear 'balance unavailable' indicator rather than a zero, because "
            "showing zero would be dangerously misleading. The list must be readable by screen readers with "
            "correct table semantics."
        ),
        "acceptance_criteria": [
            "Given a customer with multiple accounts, when the dashboard loads, then every open account is listed with masked number, currency and both balances.",
            "Given the balance service is unavailable, when the dashboard loads, then the account shows a balance unavailable indicator and never a zero balance.",
            "Given a closed account, when the dashboard loads, then it is hidden until the customer chooses to show closed accounts.",
            "Given a screen reader, when the account list is read, then each account is announced with its name, masked number and balance.",
        ],
        "labels": ["accounts", "accessibility", "critical-path"],
        "change_frequency": 3,
        "risk_score": 0.58,
    },
    {
        "key": "ACC-302",
        "module": "Accounts",
        "title": "Customer downloads an account statement",
        "priority": "medium",
        "status": "ready",
        "points": 3,
        "epic": "Account Insight",
        "sprint": "Sprint 44",
        "quality": "medium",
        "description": (
            "As a customer I want to download a statement as PDF so that I have a record for my files. "
            "Statements are available for the last 24 months and are generated on demand."
        ),
        "acceptance_criteria": [
            "Given a selected month within the last 24 months, when the customer requests a statement, then a PDF is generated and downloaded.",
            "Given a month older than 24 months, when the customer requests a statement, then the request is refused with an explanation.",
        ],
        "labels": ["accounts", "documents"],
        "change_frequency": 2,
        "risk_score": 0.4,
    },
    {
        "key": "BEN-401",
        "module": "Beneficiaries",
        "title": "Customer adds a new payment beneficiary",
        "priority": "high",
        "status": "in_test",
        "points": 5,
        "epic": "Move Money",
        "sprint": "Sprint 42",
        "quality": "high",
        "description": (
            "As a customer I want to add a new beneficiary so that I can pay someone new.\n\n"
            "The customer supplies the beneficiary name, account identifier and bank code. The system "
            "validates the account identifier format and performs a confirmation-of-payee check against the "
            "receiving bank. If the name does not match, the customer is warned and must explicitly confirm "
            "before continuing, because this is the primary control against authorised push payment fraud.\n\n"
            "New beneficiaries enter a 24 hour cooling-off period during which payments to them are capped "
            "at 500. Adding a beneficiary requires step-up authentication. All mandatory fields must be "
            "validated with field-level error messages announced to assistive technology."
        ),
        "acceptance_criteria": [
            "Given valid beneficiary details with a matching confirmation-of-payee result, when the customer confirms, then the beneficiary is saved as verified.",
            "Given a confirmation-of-payee name mismatch, when the customer proceeds, then a warning is shown and explicit confirmation is required before saving.",
            "Given an invalid account identifier format, when the customer submits, then a field-level validation error is shown and the beneficiary is not saved.",
            "Given a beneficiary added less than 24 hours ago, when a payment above 500 is attempted, then it is rejected due to the cooling-off cap.",
            "Given a new beneficiary is being added, when the customer confirms, then step-up authentication is required.",
        ],
        "labels": ["beneficiaries", "fraud-prevention", "regulatory"],
        "change_frequency": 7,
        "risk_score": 0.84,
    },
    {
        "key": "BEN-402",
        "module": "Beneficiaries",
        "title": "Customer deletes a saved beneficiary",
        "priority": "medium",
        "status": "done",
        "points": 2,
        "epic": "Move Money",
        "sprint": "Sprint 41",
        "quality": "medium",
        "description": (
            "As a customer I want to remove a beneficiary I no longer use. Deletion requires confirmation "
            "and does not affect payments already submitted."
        ),
        "acceptance_criteria": [
            "Given a saved beneficiary, when the customer confirms deletion, then the beneficiary is removed from the list.",
            "Given a beneficiary with payments in flight, when it is deleted, then those payments are unaffected.",
        ],
        "labels": ["beneficiaries"],
        "change_frequency": 1,
        "risk_score": 0.3,
    },
    {
        "key": "TXN-501",
        "module": "Transaction History",
        "title": "Customer views and filters transaction history",
        "priority": "high",
        "status": "done",
        "points": 5,
        "epic": "Account Insight",
        "sprint": "Sprint 40",
        "quality": "high",
        "description": (
            "As a customer I want to see and filter my transactions so that I can find a specific payment.\n\n"
            "Transactions are listed newest first with date, description, amount, running balance and status. "
            "The customer can filter by date range, amount range, transaction type and free-text description, "
            "and combine filters. Results are paginated at 50 per page.\n\n"
            "The default view covers the last 90 days. History is retained for 7 years and older periods are "
            "retrievable by explicit date range. Filtering must return within 2 seconds for a 12 month range. "
            "Amounts must be announced with their currency and debit/credit direction for screen reader users, "
            "not conveyed by colour alone."
        ),
        "acceptance_criteria": [
            "Given a customer with transactions, when the history loads, then the last 90 days are shown newest first with a running balance.",
            "Given a date range filter, when it is applied, then only transactions within that range are shown.",
            "Given combined date and amount filters, when they are applied, then only transactions matching all filters are shown.",
            "Given more than 50 results, when the history loads, then results are paginated at 50 per page.",
            "Given a screen reader, when a transaction is read, then the amount is announced with currency and direction rather than by colour alone.",
        ],
        "labels": ["transactions", "accessibility", "performance"],
        "change_frequency": 5,
        "risk_score": 0.62,
    },
    {
        "key": "TXN-502",
        "module": "Transaction History",
        "title": "Customer exports transactions to CSV",
        "priority": "low",
        "status": "ready",
        "points": 2,
        "epic": "Account Insight",
        "sprint": "Sprint 45",
        "quality": "low",
        "description": "Export the filtered transaction list to CSV.",
        "acceptance_criteria": [],
        "labels": ["transactions", "export"],
        "change_frequency": 0,
        "risk_score": 0.22,
    },
    {
        "key": "PRF-601",
        "module": "Customer Profile",
        "title": "Customer updates contact details",
        "priority": "high",
        "status": "in_test",
        "points": 3,
        "epic": "Self Service",
        "sprint": "Sprint 43",
        "quality": "high",
        "description": (
            "As a customer I want to update my email address, phone number and postal address so that "
            "ABC Retailer can reach me.\n\n"
            "Email and phone changes require verification of the new value before they take effect: a code is "
            "sent to the new address or number and must be entered. Address changes take effect immediately "
            "but generate a notification to the previous email address, so that an unauthorised change is "
            "visible to the customer.\n\n"
            "All changes are written to the audit log with the previous and new values. Personal data must be "
            "masked in application logs. Field validation must reject malformed email addresses and phone "
            "numbers with a field-level message."
        ),
        "acceptance_criteria": [
            "Given a new email address, when the customer submits, then a verification code is sent to the new address and the change applies only after it is entered.",
            "Given a malformed email address, when the customer submits, then a field-level validation error is shown and nothing is saved.",
            "Given an address change, when it is saved, then a notification is sent to the previous email address.",
            "Given any contact change, when it is saved, then an audit record captures the previous and new values.",
        ],
        "labels": ["profile", "security", "audit"],
        "change_frequency": 4,
        "risk_score": 0.55,
    },
    {
        "key": "PRF-602",
        "module": "Customer Profile",
        "title": "Customer sets communication preferences",
        "priority": "low",
        "status": "ready",
        "points": 2,
        "epic": "Self Service",
        "sprint": "Sprint 45",
        "quality": "low",
        "description": "Allow the customer to choose which notifications they receive.",
        "acceptance_criteria": [],
        "labels": ["profile"],
        "change_frequency": 1,
        "risk_score": 0.25,
    },
    {
        "key": "PAY-204",
        "module": "Payments",
        "title": "Customer makes an international payment",
        "priority": "high",
        "status": "refinement",
        "points": 13,
        "epic": "Move Money",
        "sprint": "Sprint 44",
        "quality": "medium",
        "description": (
            "As a customer I want to send money abroad. The customer selects the destination country and "
            "currency, sees the exchange rate and fees before confirming, and receives an estimated arrival "
            "date. Sanctions screening applies to every international payment."
        ),
        "acceptance_criteria": [
            "Given a destination country and currency, when the customer proceeds, then the exchange rate and total fees are displayed before confirmation.",
            "Given a payment that fails sanctions screening, when it is submitted, then it is held for review and the customer is informed of the delay.",
        ],
        "labels": ["payments", "regulatory", "fx"],
        "change_frequency": 8,
        "risk_score": 0.88,
    },
    {
        "key": "ACC-303",
        "module": "Accounts",
        "title": "Customer views arranged overdraft details",
        "priority": "medium",
        "status": "ready",
        "points": 3,
        "epic": "Account Insight",
        "sprint": "Sprint 44",
        "quality": "medium",
        "description": (
            "As a customer I want to see my arranged overdraft limit, the amount used and the interest rate "
            "so that I understand my borrowing. The representative APR must be displayed alongside."
        ),
        "acceptance_criteria": [
            "Given an account with an arranged overdraft, when the details are viewed, then the limit, used amount and interest rate are shown.",
            "Given an account without an overdraft, when the details are viewed, then no overdraft section is shown.",
        ],
        "labels": ["accounts", "regulatory"],
        "change_frequency": 2,
        "risk_score": 0.44,
    },
    {
        "key": "LOGIN-103",
        "module": "Login",
        "title": "Customer signs in with biometric authentication",
        "priority": "medium",
        "status": "refinement",
        "points": 8,
        "epic": "Secure Access",
        "sprint": "Sprint 45",
        "quality": "low",
        "description": "Support fingerprint and face recognition sign-in on mobile devices.",
        "acceptance_criteria": [],
        "labels": ["authentication", "mobile"],
        "change_frequency": 3,
        "risk_score": 0.6,
    },
    {
        "key": "TXN-503",
        "module": "Transaction History",
        "title": "Customer disputes a transaction",
        "priority": "high",
        "status": "ready",
        "points": 8,
        "epic": "Account Insight",
        "sprint": "Sprint 45",
        "quality": "medium",
        "description": (
            "As a customer I want to raise a dispute against a transaction I do not recognise. The dispute "
            "creates a case, provisionally credits the customer where regulation requires it, and notifies "
            "the fraud team."
        ),
        "acceptance_criteria": [
            "Given a settled transaction, when the customer raises a dispute, then a case is created and the customer receives a reference.",
            "Given a disputed card transaction, when the case is created, then a provisional credit is applied within the regulatory window.",
        ],
        "labels": ["transactions", "regulatory", "fraud"],
        "change_frequency": 5,
        "risk_score": 0.75,
    },
    {
        "key": "BEN-403",
        "module": "Beneficiaries",
        "title": "Customer edits a saved beneficiary nickname",
        "priority": "low",
        "status": "done",
        "points": 1,
        "epic": "Move Money",
        "sprint": "Sprint 41",
        "quality": "medium",
        "description": (
            "As a customer I want to rename a beneficiary so the list is easier to scan. Only the display "
            "nickname is editable; account details are immutable and require deletion and re-adding."
        ),
        "acceptance_criteria": [
            "Given a saved beneficiary, when the nickname is changed, then the new nickname is shown in the list.",
            "Given a saved beneficiary, when the customer attempts to change the account number, then the field is not editable.",
        ],
        "labels": ["beneficiaries"],
        "change_frequency": 0,
        "risk_score": 0.18,
    },
    {
        "key": "PRF-603",
        "module": "Customer Profile",
        "title": "Customer views their consent and data sharing settings",
        "priority": "medium",
        "status": "ready",
        "points": 5,
        "epic": "Self Service",
        "sprint": "Sprint 46",
        "quality": "medium",
        "description": (
            "As a customer I want to see and withdraw the consents I have given for open banking data "
            "sharing. Withdrawal takes effect immediately and is confirmed in writing."
        ),
        "acceptance_criteria": [
            "Given active consents, when the customer views the consent page, then each third party, scope and expiry is listed.",
            "Given an active consent, when the customer withdraws it, then access is revoked immediately and a confirmation is sent.",
        ],
        "labels": ["profile", "regulatory", "open-banking"],
        "change_frequency": 3,
        "risk_score": 0.52,
    },
    {
        "key": "ACC-304",
        "module": "Accounts",
        "title": "Customer opens a new savings account",
        "priority": "medium",
        "status": "refinement",
        "points": 13,
        "epic": "Account Insight",
        "sprint": "Sprint 46",
        "quality": "low",
        "description": "Allow existing customers to open a savings account online.",
        "acceptance_criteria": [],
        "labels": ["accounts", "onboarding"],
        "change_frequency": 2,
        "risk_score": 0.5,
    },
    {
        "key": "PAY-205",
        "module": "Payments",
        "title": "Customer sets up a standing order",
        "priority": "medium",
        "status": "ready",
        "points": 5,
        "epic": "Move Money",
        "sprint": "Sprint 46",
        "quality": "medium",
        "description": (
            "As a customer I want to set up a recurring payment on a fixed schedule. The customer chooses "
            "frequency, start date and optional end date or occurrence count."
        ),
        "acceptance_criteria": [
            "Given a frequency and start date, when the standing order is created, then it appears in the scheduled payments list with its next execution date.",
            "Given a standing order with an end date, when the end date passes, then no further payments execute.",
        ],
        "labels": ["payments", "scheduling"],
        "change_frequency": 3,
        "risk_score": 0.47,
    },
    {
        "key": "LOGIN-104",
        "module": "Login",
        "title": "Customer signs out and session is terminated",
        "priority": "high",
        "status": "done",
        "points": 2,
        "epic": "Secure Access",
        "sprint": "Sprint 40",
        "quality": "high",
        "description": (
            "As a customer I want to sign out so that nobody else can use my session.\n\n"
            "Sign-out invalidates the session token server side, not merely client side, and clears session "
            "storage in the browser. After sign-out the browser back button must not expose account data "
            "from the previous session. A confirmation is shown and the customer is returned to the sign-in "
            "page. Any concurrent sessions on other devices are unaffected unless the customer chooses "
            "sign out everywhere."
        ),
        "acceptance_criteria": [
            "Given an active session, when the customer signs out, then the session token is invalidated server side.",
            "Given a signed-out session, when the customer presses the browser back button, then no account data from the previous session is displayed.",
            "Given sign out everywhere is chosen, when it is confirmed, then all sessions on all devices are terminated.",
        ],
        "labels": ["authentication", "security", "critical-path"],
        "change_frequency": 1,
        "risk_score": 0.5,
    },
]


# ---------------------------------------------------------------------------
# Confluence-style documentation
# ---------------------------------------------------------------------------

CONFLUENCE_DOCUMENTS: list[dict[str, Any]] = [
    {
        "id": "ABCR-ARCH-01",
        "title": "ABC Retailer Digital Experience - Solution Architecture",
        "module": "Accounts",
        "author": "Enterprise Architecture",
        "content": (
            "# Solution Architecture\n\n"
            "The digital experience is a React single-page application served through a CDN, calling a "
            "backend-for-frontend over HTTPS. The BFF aggregates six downstream domain services: Identity, "
            "Customer, Accounts, Payments, Beneficiaries and Transactions.\n\n"
            "## Session management\n"
            "Sessions are JWT-based with a 15 minute inactivity timeout and a 12 hour absolute lifetime. "
            "Tokens are signed by the Identity service and validated at the BFF. Refresh happens silently "
            "while the customer is active.\n\n"
            "## Payments flow\n"
            "Payment submission is synchronous to the BFF and asynchronous downstream. The BFF writes a "
            "payment intent, calls the Payments service, and returns a reference. The Payments service "
            "calls the external gateway with a 5 second timeout and two retries with exponential backoff. "
            "Idempotency is enforced with a client-supplied key held for 24 hours.\n\n"
            "## Known constraints\n"
            "The Accounts balance service caches balances for 60 seconds. Under sustained load above 400 "
            "requests per second the authentication service has previously exhibited connection pool "
            "exhaustion, surfacing as gateway timeouts on sign-in."
        ),
    },
    {
        "id": "ABCR-SOP-02",
        "title": "QE Standard Operating Procedure - Regression Testing",
        "module": "Payments",
        "author": "Quality Engineering",
        "content": (
            "# Regression Testing SOP\n\n"
            "## Scope selection\n"
            "Regression scope is selected by change impact. Any module with a code change in the release "
            "is in scope at full depth. Modules without changes are covered by their critical-path tests "
            "only, unless historical failure rate exceeds 15 percent, in which case full depth applies.\n\n"
            "## Entry criteria\n"
            "All in-scope stories meet the completeness threshold of 80. The test environment passes its "
            "health check. Test data is provisioned and masked.\n\n"
            "## Exit criteria\n"
            "All critical and high priority cases executed. Zero open blocker or critical defects. Flaky "
            "rate below 2 percent. Automation coverage of regression-critical paths at or above 80 percent.\n\n"
            "## Defect severity\n"
            "Blocker: no workaround, critical journey unavailable. Critical: critical journey degraded or "
            "financial impact. Major: functional deviation with a workaround. Minor: cosmetic or low impact."
        ),
    },
    {
        "id": "ABCR-RULE-03",
        "title": "Payment Business Rules and Limits",
        "module": "Payments",
        "author": "Product Management",
        "content": (
            "# Payment Business Rules\n\n"
            "## Limits\n"
            "Daily payment limit is 10,000 in account currency, applied cumulatively across all payments "
            "in a rolling 24 hour window. Single payment limit is 5,000. Payments above 1,000 require "
            "step-up authentication with a one-time passcode.\n\n"
            "## New beneficiary cooling-off\n"
            "Beneficiaries added within the last 24 hours are capped at 500 per payment. This is a fraud "
            "control and cannot be waived by the customer.\n\n"
            "## Duplicate detection\n"
            "A payment with the same beneficiary, amount and reference submitted within 60 seconds of a "
            "prior payment is treated as a duplicate and rejected. The customer may override explicitly.\n\n"
            "## Insufficient funds\n"
            "Available balance includes any arranged overdraft. Payments are rejected before submission if "
            "available balance is insufficient. No partial payments are permitted.\n\n"
            "## Cut-off times\n"
            "Domestic payments submitted before 16:30 on a working day settle same day. After cut-off they "
            "settle the next working day and the customer is told so before confirming."
        ),
    },
    {
        "id": "ABCR-A11Y-04",
        "title": "Accessibility Standard - WCAG 2.2 AA",
        "module": "Customer Profile",
        "author": "Design System Team",
        "content": (
            "# Accessibility Standard\n\n"
            "All customer-facing journeys must meet WCAG 2.2 Level AA.\n\n"
            "## Forms\n"
            "Every input has a programmatically associated visible label. Validation errors are announced "
            "via an alert region and are associated with the field via aria-describedby. Error messages "
            "state what is wrong and how to fix it.\n\n"
            "## Colour and contrast\n"
            "Text meets 4.5:1 contrast. Status must never be conveyed by colour alone: debits and credits "
            "carry an explicit sign and a text label, not only red and green.\n\n"
            "## Keyboard\n"
            "Every interactive element is reachable and operable by keyboard with a visible focus "
            "indicator. Modal dialogs trap focus and return it to the trigger on close.\n\n"
            "## Testing\n"
            "Automated axe-core checks run in CI and gate on critical and serious violations. Automated "
            "checks catch roughly half of real accessibility defects; a manual keyboard and screen reader "
            "pass is required for each release."
        ),
    },
    {
        "id": "ABCR-TDM-05",
        "title": "Test Data Management Policy",
        "module": "Accounts",
        "author": "Quality Engineering",
        "content": (
            "# Test Data Management\n\n"
            "## Principles\n"
            "No production personal data is permitted in any non-production environment. All test data is "
            "either synthetically generated or irreversibly masked at source.\n\n"
            "## Masking\n"
            "Names, email addresses, phone numbers, account identifiers and card numbers are masked. "
            "Masking preserves format so validation logic still exercises correctly.\n\n"
            "## Refresh\n"
            "Test data sets are refreshed every 30 days or when the underlying schema changes. A data set "
            "not refreshed within 30 days is flagged stale and must not be used for release verification.\n\n"
            "## Coverage\n"
            "Each data set must contain valid, invalid and boundary records. A set without negative and "
            "boundary records cannot support the negative test cases that depend on it."
        ),
    },
    {
        "id": "ABCR-AUTO-06",
        "title": "Automation Framework Standards",
        "module": "Login",
        "author": "Automation Guild",
        "content": (
            "# Automation Framework Standards\n\n"
            "## Technology\n"
            "Python Playwright with pytest. Page object pattern is mandatory: no raw locators in test "
            "bodies.\n\n"
            "## Locator strategy\n"
            "Locators are chosen in this order of preference: data-testid, accessible role and name, "
            "associated label, placeholder, visible text, CSS attribute selector. XPath is a last resort "
            "and any XPath locator must carry a comment explaining why nothing better was available.\n\n"
            "## Waiting\n"
            "Never use fixed sleeps. Use Playwright web-first assertions, which retry until the timeout. "
            "A test that needs a sleep to pass is hiding a race condition.\n\n"
            "## Test independence\n"
            "Every test provisions its own data and cleans up after itself. Tests must pass when run in "
            "any order and in parallel.\n\n"
            "## Flakiness\n"
            "A test failing intermittently more than 2 percent of runs is quarantined and fixed. Quarantine "
            "is not a resting place: quarantined tests are fixed or deleted within one sprint."
        ),
    },
    {
        "id": "ABCR-INC-07",
        "title": "Incident Retrospective - Authentication Timeouts",
        "module": "Login",
        "author": "Site Reliability",
        "content": (
            "# Incident Retrospective: Authentication Timeouts\n\n"
            "## Summary\n"
            "During a peak period the authentication service returned gateway timeouts to approximately 8 "
            "percent of sign-in attempts over 40 minutes.\n\n"
            "## Root cause\n"
            "The Identity service connection pool was sized at 50 connections while sustained load reached "
            "420 requests per second. Connections were held for the full duration of a downstream directory "
            "lookup that had itself slowed, exhausting the pool. Requests queued and then exceeded the "
            "5 second gateway timeout.\n\n"
            "## Contributing factors\n"
            "The directory lookup had no timeout of its own. Pool exhaustion produced no alert. Load "
            "testing had been run at 200 requests per second, half of observed peak.\n\n"
            "## Actions\n"
            "Connection pool increased and made configurable. Directory lookup given a 2 second timeout. "
            "Pool saturation alert added at 80 percent. Performance test profile raised to 500 requests "
            "per second.\n\n"
            "## Test signature\n"
            "Automated sign-in tests failed with 'Timeout 30000ms exceeded' and gateway 504 responses. "
            "This signature indicates infrastructure saturation rather than an application defect."
        ),
    },
    {
        "id": "ABCR-PERF-08",
        "title": "Performance Service Level Objectives",
        "module": "Transaction History",
        "author": "Performance Engineering",
        "content": (
            "# Performance SLOs\n\n"
            "| Journey | p95 target | Peak load |\n"
            "| --- | --- | --- |\n"
            "| Sign-in | 800ms | 500 rps |\n"
            "| Account dashboard | 1200ms | 350 rps |\n"
            "| Payment submission | 1500ms | 120 rps |\n"
            "| Transaction history, 12 months | 2000ms | 200 rps |\n\n"
            "Error rate must remain below 1 percent at peak. Performance tests run against the perf "
            "environment at production-like data volumes; results against smaller data sets are not "
            "comparable and must not be used for sign-off."
        ),
    },
]


# ---------------------------------------------------------------------------
# Git-style code context
# ---------------------------------------------------------------------------

CODE_DOCUMENTS: list[dict[str, Any]] = [
    {
        "id": "src/pages/payments/PaymentForm.tsx",
        "title": "PaymentForm component",
        "module": "Payments",
        "author": "frontend.team",
        "content": (
            "// Payment submission form.\n"
            "// Validates amount, enforces the daily limit client side as a courtesy,\n"
            "// and relies on the server as the authority.\n"
            "export function PaymentForm({ beneficiaries, limits }: Props) {\n"
            "  const [amount, setAmount] = useState('');\n"
            "  const [beneficiaryId, setBeneficiaryId] = useState('');\n"
            "  const requiresStepUp = Number(amount) > limits.stepUpThreshold;\n"
            "  // data-testid attributes are required by the automation standard\n"
            "  return (\n"
            "    <form data-testid=\"payment-form\" onSubmit={handleSubmit}>\n"
            "      <BeneficiarySelect data-testid=\"beneficiary-select\" />\n"
            "      <AmountInput data-testid=\"payment-amount\" aria-label=\"Payment amount\" />\n"
            "      <button data-testid=\"payment-submit\" type=\"submit\">Continue</button>\n"
            "    </form>\n"
            "  );\n"
            "}"
        ),
    },
    {
        "id": "services/payments/limit_policy.py",
        "title": "Payment limit policy",
        "module": "Payments",
        "author": "payments.team",
        "content": (
            "DAILY_LIMIT = Decimal('10000.00')\n"
            "SINGLE_PAYMENT_LIMIT = Decimal('5000.00')\n"
            "STEP_UP_THRESHOLD = Decimal('1000.00')\n"
            "NEW_BENEFICIARY_CAP = Decimal('500.00')\n"
            "NEW_BENEFICIARY_WINDOW_HOURS = 24\n\n"
            "def check_limits(payment, rolling_total, beneficiary):\n"
            "    \"\"\"Return a rejection reason, or None when the payment is permitted.\"\"\"\n"
            "    if payment.amount <= 0:\n"
            "        return 'AMOUNT_NOT_POSITIVE'\n"
            "    if payment.amount > SINGLE_PAYMENT_LIMIT:\n"
            "        return 'SINGLE_PAYMENT_LIMIT_EXCEEDED'\n"
            "    if rolling_total + payment.amount > DAILY_LIMIT:\n"
            "        return 'DAILY_LIMIT_EXCEEDED'\n"
            "    if beneficiary.is_within_cooling_off and payment.amount > NEW_BENEFICIARY_CAP:\n"
            "        return 'NEW_BENEFICIARY_CAP_EXCEEDED'\n"
            "    return None"
        ),
    },
    {
        "id": "services/identity/session.py",
        "title": "Session management",
        "module": "Login",
        "author": "identity.team",
        "content": (
            "INACTIVITY_TIMEOUT_MINUTES = 15\n"
            "ABSOLUTE_LIFETIME_HOURS = 12\n"
            "MAX_FAILED_ATTEMPTS = 5\n"
            "LOCKOUT_MINUTES = 30\n\n"
            "# Connection pool raised from 50 after the peak-load incident;\n"
            "# see ABCR-INC-07. Directory lookup now has its own 2s timeout.\n"
            "CONNECTION_POOL_SIZE = int(os.environ.get('IDENTITY_POOL_SIZE', '200'))\n"
            "DIRECTORY_LOOKUP_TIMEOUT_SECONDS = 2\n\n"
            "def authenticate(username: str, password: str) -> AuthResult:\n"
            "    account = directory.lookup(username, timeout=DIRECTORY_LOOKUP_TIMEOUT_SECONDS)\n"
            "    if account.is_locked:\n"
            "        return AuthResult.locked(account.lock_expires_at)\n"
            "    if not verify(password, account.password_hash):\n"
            "        account.register_failure()\n"
            "        # Generic error: never reveal whether the username exists.\n"
            "        return AuthResult.invalid()\n"
            "    account.reset_failures()\n"
            "    return AuthResult.success(issue_session(account))"
        ),
    },
    {
        "id": "src/pages/accounts/AccountList.tsx",
        "title": "AccountList component",
        "module": "Accounts",
        "author": "frontend.team",
        "content": (
            "// Account dashboard list.\n"
            "// When the balance service fails we must render an explicit unavailable\n"
            "// state -- rendering 0 would be dangerously misleading to the customer.\n"
            "export function AccountList({ accounts, balanceError }: Props) {\n"
            "  return (\n"
            "    <table data-testid=\"account-list\">\n"
            "      <caption className=\"sr-only\">Your accounts</caption>\n"
            "      {accounts.map((account) => (\n"
            "        <AccountRow\n"
            "          key={account.id}\n"
            "          maskedNumber={maskAccountNumber(account.number)}\n"
            "          balance={balanceError ? null : account.availableBalance}\n"
            "        />\n"
            "      ))}\n"
            "    </table>\n"
            "  );\n"
            "}"
        ),
    },
    {
        "id": "tests/support/conftest.py",
        "title": "Automation fixtures",
        "module": "Login",
        "author": "automation.guild",
        "content": (
            "# Shared fixtures. Credentials come from the environment,\n"
            "# never from source control.\n"
            "@pytest.fixture(scope='session')\n"
            "def credentials() -> dict[str, str]:\n"
            "    return {\n"
            "        'username': os.environ['TEST_USERNAME'],\n"
            "        'password': os.environ['TEST_PASSWORD'],\n"
            "    }\n\n"
            "@pytest.fixture\n"
            "def authenticated_page(page, base_url, credentials):\n"
            "    LoginPage(page, base_url).open().sign_in(credentials)\n"
            "    return page"
        ),
    },
]


# ---------------------------------------------------------------------------
# Defects
# ---------------------------------------------------------------------------
# `age_days` positions each defect on the timeline so trend charts have shape.

DEFECTS: list[dict[str, Any]] = [
    {
        "key": "DEF-0001",
        "module": "Login",
        "title": "Authentication times out under sustained peak load",
        "severity": "critical",
        "priority": "critical",
        "status": "resolved",
        "age_days": 62,
        "signature": "TIMEOUT_EXCEEDED",
        "cluster": "auth-timeout",
        "description": (
            "During peak load the sign-in request returns a gateway timeout for roughly 8 percent of "
            "attempts. Reproduced at 420 requests per second in the performance environment."
        ),
        "steps": [
            "Drive sign-in load at 420 requests per second in the perf environment.",
            "Observe the error rate on the authentication endpoint.",
            "Note gateway 504 responses once the connection pool saturates.",
        ],
        "resolution": "Connection pool raised to 200 and made configurable; directory lookup given a 2 second timeout.",
    },
    {
        "key": "DEF-0002",
        "module": "Payments",
        "title": "Daily limit validation uses calendar day instead of rolling 24 hours",
        "severity": "major",
        "priority": "high",
        "status": "resolved",
        "age_days": 48,
        "signature": "ASSERTION_FAILED",
        "cluster": "payment-limits",
        "description": (
            "The daily payment limit resets at midnight rather than applying a rolling 24 hour window, so a "
            "customer can send 10,000 at 23:55 and a further 10,000 at 00:05."
        ),
        "steps": [
            "Submit payments totalling 10,000 shortly before midnight.",
            "Submit a further payment shortly after midnight.",
            "Observe that the second payment is accepted.",
        ],
        "resolution": "Limit calculation changed to a rolling 24 hour window keyed on submission timestamp.",
    },
    {
        "key": "DEF-0003",
        "module": "Payments",
        "title": "Duplicate payment accepted when submitted twice rapidly",
        "severity": "critical",
        "priority": "critical",
        "status": "in_progress",
        "age_days": 21,
        "signature": "ASSERTION_FAILED",
        "cluster": "payment-duplicate",
        "description": (
            "Submitting the same payment twice within a second creates two payments. The idempotency key "
            "appears not to be applied when the second request arrives before the first has been persisted."
        ),
        "steps": [
            "Select a saved beneficiary and enter an amount of 250.",
            "Submit the payment and immediately submit again before the confirmation renders.",
            "Observe two payments in transaction history with distinct references.",
        ],
    },
    {
        "key": "DEF-0004",
        "module": "Beneficiaries",
        "title": "Confirmation-of-payee mismatch warning can be bypassed with the browser back button",
        "severity": "critical",
        "priority": "critical",
        "status": "open",
        "age_days": 9,
        "signature": "ASSERTION_FAILED",
        "cluster": "beneficiary-cop",
        "description": (
            "After a confirmation-of-payee name mismatch the customer can press the browser back button and "
            "resubmit, and the beneficiary saves as verified without the explicit confirmation step. This "
            "defeats the primary control against authorised push payment fraud."
        ),
        "steps": [
            "Add a beneficiary whose name does not match the receiving bank record.",
            "When the mismatch warning appears, press the browser back button.",
            "Resubmit the form and observe the beneficiary saved with verified status.",
        ],
    },
    {
        "key": "DEF-0005",
        "module": "Accounts",
        "title": "Balance shows zero instead of unavailable when the balance service fails",
        "severity": "critical",
        "priority": "high",
        "status": "resolved",
        "age_days": 35,
        "signature": "ASSERTION_FAILED",
        "cluster": "balance-display",
        "description": (
            "When the balance service is unavailable the dashboard renders 0.00 rather than an unavailable "
            "indicator, which could lead a customer to believe their account is empty."
        ),
        "steps": [
            "Make the balance service unavailable.",
            "Load the account dashboard.",
            "Observe a 0.00 balance rather than an unavailable indicator.",
        ],
        "resolution": "Null balance now renders an explicit unavailable state; the component no longer coerces null to zero.",
    },
    {
        "key": "DEF-0006",
        "module": "Transaction History",
        "title": "Combined date and amount filters return incorrect results",
        "severity": "major",
        "priority": "high",
        "status": "in_progress",
        "age_days": 14,
        "signature": "ASSERTION_FAILED",
        "cluster": "txn-filter",
        "description": (
            "Applying a date range and an amount range together returns transactions matching either filter "
            "rather than both. The query appears to build an OR where an AND is intended."
        ),
        "steps": [
            "Open transaction history.",
            "Apply a date range of last 7 days and an amount range above 500.",
            "Observe transactions outside the date range appearing in the results.",
        ],
    },
    {
        "key": "DEF-0007",
        "module": "Login",
        "title": "Account lockout counter does not reset after successful sign-in",
        "severity": "major",
        "priority": "medium",
        "status": "resolved",
        "age_days": 40,
        "signature": "ASSERTION_FAILED",
        "cluster": "auth-lockout",
        "description": (
            "The failed attempt counter persists after a successful sign-in, so a customer who fails four "
            "times, succeeds, then fails once is locked out unexpectedly."
        ),
        "steps": [
            "Fail sign-in four times.",
            "Sign in successfully.",
            "Fail sign-in once more and observe the account locked.",
        ],
        "resolution": "Counter now reset on successful authentication.",
    },
    {
        "key": "DEF-0008",
        "module": "Customer Profile",
        "title": "Email change applies before the verification code is entered",
        "severity": "critical",
        "priority": "critical",
        "status": "open",
        "age_days": 5,
        "signature": "ASSERTION_FAILED",
        "cluster": "profile-verification",
        "description": (
            "The new email address is written to the customer record when the change is submitted, before "
            "the verification code is entered. If the address is mistyped the customer loses notifications "
            "and the account recovery path."
        ),
        "steps": [
            "Open contact details and change the email address.",
            "Submit but do not enter the verification code.",
            "Observe the customer record already reflects the new address.",
        ],
    },
    {
        "key": "DEF-0009",
        "module": "Payments",
        "title": "Payment amount field accepts more than two decimal places",
        "severity": "minor",
        "priority": "low",
        "status": "open",
        "age_days": 27,
        "signature": "VALIDATION_FAILED",
        "cluster": "payment-validation",
        "description": (
            "The amount field accepts values such as 10.999, which are then rounded inconsistently between "
            "the confirmation screen and the submitted payment."
        ),
        "steps": [
            "Enter a payment amount of 10.999.",
            "Observe the confirmation screen shows 11.00 while the submitted amount is 10.99.",
        ],
    },
    {
        "key": "DEF-0010",
        "module": "Accounts",
        "title": "Account list is not announced correctly by screen readers",
        "severity": "major",
        "priority": "medium",
        "status": "in_progress",
        "age_days": 18,
        "signature": "A11Y_VIOLATION",
        "cluster": "a11y-accounts",
        "description": (
            "The account list renders as a set of divs without table semantics, so a screen reader announces "
            "the values without their column meaning. WCAG 2.2 AA success criterion 1.3.1."
        ),
        "steps": [
            "Enable a screen reader.",
            "Open the account dashboard.",
            "Observe balances announced without their associated account or column header.",
        ],
    },
    {
        "key": "DEF-0011",
        "module": "Beneficiaries",
        "title": "New beneficiary cooling-off cap not applied to scheduled payments",
        "severity": "critical",
        "priority": "critical",
        "status": "open",
        "age_days": 3,
        "signature": "ASSERTION_FAILED",
        "cluster": "beneficiary-cooling-off",
        "description": (
            "A scheduled payment to a beneficiary added minutes earlier executes for the full amount, "
            "bypassing the 500 cooling-off cap. The cap is checked at scheduling time but the beneficiary "
            "is no longer new when the payment executes."
        ),
        "steps": [
            "Add a new beneficiary.",
            "Schedule a payment of 2,000 to that beneficiary for the following day.",
            "Observe the payment executes in full despite the cooling-off cap.",
        ],
    },
    {
        "key": "DEF-0012",
        "module": "Transaction History",
        "title": "Transaction history slow for 12 month ranges",
        "severity": "major",
        "priority": "high",
        "status": "in_progress",
        "age_days": 11,
        "signature": "TIMEOUT_EXCEEDED",
        "cluster": "txn-performance",
        "description": (
            "A 12 month transaction query takes 4.2 seconds at the 95th percentile against the SLO of 2 "
            "seconds. The query appears to lack an index on the composite of account and booking date."
        ),
        "steps": [
            "Open transaction history for an account with high transaction volume.",
            "Set the date range to the last 12 months.",
            "Measure the response time and observe it exceeds 4 seconds.",
        ],
    },
    {
        "key": "DEF-0013",
        "module": "Login",
        "title": "Sign-out does not invalidate the session server side",
        "severity": "critical",
        "priority": "critical",
        "status": "resolved",
        "age_days": 55,
        "signature": "ASSERTION_FAILED",
        "cluster": "auth-session",
        "description": (
            "Sign-out clears the browser session but the token remains valid server side until expiry, so a "
            "captured token continues to work after the customer has signed out."
        ),
        "steps": [
            "Sign in and capture the session token.",
            "Sign out.",
            "Replay a request with the captured token and observe it succeeds.",
        ],
        "resolution": "Sign-out now revokes the token server side and adds it to the revocation list.",
    },
    {
        "key": "DEF-0014",
        "module": "Payments",
        "title": "Step-up authentication skipped for payments exactly at the threshold",
        "severity": "major",
        "priority": "high",
        "status": "resolved",
        "age_days": 30,
        "signature": "ASSERTION_FAILED",
        "cluster": "payment-stepup",
        "description": (
            "A payment of exactly 1,000 does not trigger step-up authentication. The comparison uses a "
            "strict greater-than where the rule intends greater-than-or-equal."
        ),
        "steps": [
            "Submit a payment of exactly 1,000.",
            "Observe that no one-time passcode is requested.",
        ],
        "resolution": "Comparison changed to greater-than-or-equal; boundary test added at 999.99, 1000.00 and 1000.01.",
    },
    {
        "key": "DEF-0015",
        "module": "Customer Profile",
        "title": "Personal data appears unmasked in application logs",
        "severity": "critical",
        "priority": "critical",
        "status": "resolved",
        "age_days": 44,
        "signature": "SECURITY_VIOLATION",
        "cluster": "profile-logging",
        "description": (
            "Contact detail updates log the full email address and phone number at INFO level, so personal "
            "data reaches the central log store unmasked."
        ),
        "steps": [
            "Update a contact email address.",
            "Inspect the application log for the request.",
            "Observe the full email address recorded in plain text.",
        ],
        "resolution": "Masking filter applied at the logging layer for all contact fields.",
    },
    {
        "key": "DEF-0016",
        "module": "Beneficiaries",
        "title": "Beneficiary account number field accepts invalid checksum",
        "severity": "major",
        "priority": "medium",
        "status": "open",
        "age_days": 16,
        "signature": "VALIDATION_FAILED",
        "cluster": "beneficiary-validation",
        "description": (
            "The account identifier is validated for length and character set but not for checksum, so a "
            "mistyped digit is accepted and the payment fails downstream with an unhelpful error."
        ),
        "steps": [
            "Add a beneficiary with a valid-length identifier containing a single mistyped digit.",
            "Observe the beneficiary saves successfully.",
            "Attempt a payment and observe an unhelpful downstream failure.",
        ],
    },
    {
        "key": "DEF-0017",
        "module": "Accounts",
        "title": "Closed accounts appear in the account selector for payments",
        "severity": "major",
        "priority": "medium",
        "status": "resolved",
        "age_days": 38,
        "signature": "ASSERTION_FAILED",
        "cluster": "accounts-filter",
        "description": (
            "Closed accounts are hidden on the dashboard but still appear in the from-account selector on "
            "the payment form, where selecting one produces a downstream error."
        ),
        "steps": [
            "Ensure the customer has a closed account.",
            "Open the payment form and inspect the from-account selector.",
            "Observe the closed account listed.",
        ],
        "resolution": "Selector now filters on account status rather than relying on the dashboard filter.",
    },
    {
        "key": "DEF-0018",
        "module": "Transaction History",
        "title": "Running balance incorrect when transactions share a timestamp",
        "severity": "major",
        "priority": "medium",
        "status": "open",
        "age_days": 7,
        "signature": "ASSERTION_FAILED",
        "cluster": "txn-balance",
        "description": (
            "When two transactions carry an identical booking timestamp the running balance column is "
            "computed in a non-deterministic order, so the displayed balance differs between page loads."
        ),
        "steps": [
            "Find an account with two transactions sharing a booking timestamp.",
            "Load transaction history and note the running balance.",
            "Reload and observe the running balance differs.",
        ],
    },
    {
        "key": "DEF-0019",
        "module": "Payments",
        "title": "Payment confirmation does not state the settlement date after cut-off",
        "severity": "minor",
        "priority": "low",
        "status": "open",
        "age_days": 23,
        "signature": "ASSERTION_FAILED",
        "cluster": "payment-messaging",
        "description": (
            "Payments submitted after the 16:30 cut-off settle the next working day, but the confirmation "
            "screen does not say so, generating avoidable customer contact."
        ),
        "steps": [
            "Submit a domestic payment after 16:30 on a working day.",
            "Observe the confirmation makes no reference to next working day settlement.",
        ],
    },
    {
        "key": "DEF-0020",
        "module": "Login",
        "title": "Focus not returned to trigger when the session timeout dialog closes",
        "severity": "minor",
        "priority": "low",
        "status": "open",
        "age_days": 12,
        "signature": "A11Y_VIOLATION",
        "cluster": "a11y-login",
        "description": (
            "When the session timeout warning dialog is dismissed, keyboard focus is lost to the document "
            "body rather than returning to the element that had focus. WCAG 2.2 AA success criterion 2.4.3."
        ),
        "steps": [
            "Remain inactive until the session timeout warning appears.",
            "Dismiss the dialog with the keyboard.",
            "Observe focus is lost rather than restored.",
        ],
    },
    {
        "key": "DEF-0021",
        "module": "Payments",
        "title": "Payment form locator changed, breaking automation",
        "severity": "minor",
        "priority": "medium",
        "status": "resolved",
        "age_days": 20,
        "signature": "LOCATOR_NOT_FOUND",
        "cluster": "automation-locator",
        "description": (
            "A UI refactor renamed the submit button's test id from payment-submit-btn to payment-submit, "
            "breaking six automated tests. No product defect; automation debt."
        ),
        "steps": [
            "Run the payments regression suite after the UI refactor.",
            "Observe six tests failing with locator resolution errors.",
        ],
        "resolution": "Locators updated via governed self-healing and a UI contract test added to catch test-id changes.",
    },
    {
        "key": "DEF-0022",
        "module": "Accounts",
        "title": "Statement PDF omits the closing balance",
        "severity": "major",
        "priority": "medium",
        "status": "open",
        "age_days": 6,
        "signature": "ASSERTION_FAILED",
        "cluster": "statement-content",
        "description": (
            "The generated statement PDF lists transactions and the opening balance but omits the closing "
            "balance, which is a regulatory content requirement."
        ),
        "steps": [
            "Request a statement for a month with transactions.",
            "Open the generated PDF.",
            "Observe no closing balance is present.",
        ],
    },
]
