"""Seed orchestration: schema bootstrap, catalogue, demo project and indexing.

Idempotent by design -- running it twice leaves the same database, so it is safe
to call on startup. `reset=True` drops everything first, which is what the demo
reset endpoint uses.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import engine, session_scope
from app.core.logging import get_logger
from app.knowledge.service import KnowledgeService
from app.models.base import Base
from app.models.defect import Defect
from app.models.knowledge import KnowledgeSource
from app.models.project import Project
from app.models.testing import Execution, ExecutionTest, Requirement, TestCase
from app.seed import content
from app.seed.catalog import (
    seed_agents,
    seed_ai_catalog,
    seed_governance_policies,
    seed_mcp_servers,
    seed_roles_and_users,
    seed_vector_configuration,
)
from app.seed.api_clients import seed_demo_api_client, seed_project_members
from app.seed.data_sources import seed_data_sources
from app.seed.business_flows import seed_business_flows
from app.seed.demo_project import DemoProjectBuilder
from app.seed.flow_history import seed_flow_history
from app.seed.flows import seed_demo_flows
from app.vectorstore.base import ALL_COLLECTIONS
from app.vectorstore.factory import get_vector_store

logger = get_logger(__name__)


def create_schema() -> None:
    """Create any missing tables. Alembic owns migrations in production."""
    Base.metadata.create_all(bind=engine)


def drop_schema() -> None:
    Base.metadata.drop_all(bind=engine)


def is_seeded(session: Session) -> bool:
    return (
        session.execute(select(Project).where(Project.key == content.PROJECT_KEY)).scalar_one_or_none()
        is not None
    )


def seed_all(*, reset: bool = False, index_knowledge: bool = True) -> dict[str, Any]:
    """Seed the platform. Returns a summary for the API and CLI."""
    started = datetime.now(UTC)

    if reset:
        logger.info("seed_reset_started")
        store = get_vector_store()
        for collection in ALL_COLLECTIONS:
            try:
                store.reset_collection(collection)
            except Exception as exc:  # noqa: BLE001
                logger.warning("collection_reset_failed", collection=collection, error=str(exc)[:160])
        drop_schema()

    create_schema()

    with session_scope() as session:
        if not reset and is_seeded(session):
            logger.info("seed_skipped_already_present")
            return {"seeded": False, "reason": "already_seeded", "project_key": content.PROJECT_KEY}

        users = seed_roles_and_users(session)
        seed_ai_catalog(session)
        seed_vector_configuration(session)
        seed_governance_policies(session)
        seed_mcp_servers(session, project_id=None)
        agents = seed_agents(session)

        project = DemoProjectBuilder(session).build(users, agents)
        # The journeys the project's tests belong to, so change impact and
        # post-repair validation have a graph to walk.
        seed_business_flows(session, project)
        flows = seed_demo_flows(session, project, agents)
        seed_flow_history(session, project, flows)
        # One API user, so the integration surface and the API user portal are
        # demonstrable without an operator issuing a key first.
        seed_demo_api_client(session, project)
        # Membership is the tenant boundary: without it the seeded users would
        # sign in to a platform that shows them nothing.
        seed_project_members(session, project, users)
        # Two systems the customer owns, so the data source screen and the
        # encrypted credential store are both visible on a fresh install.
        seed_data_sources(session, project)
        session.commit()

        summary = _summarize(session, project)

    if index_knowledge:
        indexed = index_project_knowledge()
        summary["knowledge"] = indexed

    summary["seeded"] = True
    summary["duration_ms"] = int((datetime.now(UTC) - started).total_seconds() * 1000)
    logger.info("seed_complete", **{key: value for key, value in summary.items() if isinstance(value, (int, str))})
    return summary


def index_project_knowledge(project_key: str = content.PROJECT_KEY) -> dict[str, int]:
    """Embed the demo corpus into Chroma.

    Runs in its own session after seeding so a vector-store outage degrades the
    demo's retrieval rather than blocking the whole seed.
    """
    counts = {"documents": 0, "chunks": 0, "test_cases": 0, "defects": 0, "failures": 0, "agents": 0}

    with session_scope() as session:
        project = session.execute(
            select(Project).where(Project.key == project_key)
        ).scalar_one_or_none()
        if project is None:
            return counts

        knowledge = KnowledgeService(session)
        sources = {
            source.key: source
            for source in session.execute(
                select(KnowledgeSource).where(KnowledgeSource.project_id == project.id)
            )
            .scalars()
            .all()
        }

        # --- Confluence documentation -------------------------------------
        confluence = sources.get("confluence-space")
        if confluence is not None:
            for document in content.CONFLUENCE_DOCUMENTS:
                row = knowledge.ingest_document(
                    project_id=project.id,
                    source=confluence,
                    external_id=document["id"],
                    title=document["title"],
                    content=document["content"],
                    module=document["module"],
                    artifact_type="documentation",
                    author=document["author"],
                    url=f"https://confluence.example.com/ABCR/{document['id']}",
                    tags=["confluence", document["module"].lower().replace(" ", "-")],
                    collection=confluence.collection_name,
                )
                counts["documents"] += 1
                counts["chunks"] += row.chunk_count
            _mark_synced(confluence, len(content.CONFLUENCE_DOCUMENTS))

        # --- Code context -------------------------------------------------
        git_source = sources.get("git-repository")
        if git_source is not None:
            for document in content.CODE_DOCUMENTS:
                row = knowledge.ingest_document(
                    project_id=project.id,
                    source=git_source,
                    external_id=document["id"],
                    title=document["title"],
                    content=document["content"],
                    module=document["module"],
                    artifact_type="source_code",
                    author=document["author"],
                    url=f"https://git.example.com/abc-retailer/abcr-digital/blob/main/{document['id']}",
                    tags=["code", document["module"].lower().replace(" ", "-")],
                    collection=git_source.collection_name,
                )
                counts["documents"] += 1
                counts["chunks"] += row.chunk_count
            _mark_synced(git_source, len(content.CODE_DOCUMENTS))

        # --- Requirements --------------------------------------------------
        jira_source = sources.get("jira-stories")
        if jira_source is not None:
            requirements = list(
                session.execute(select(Requirement).where(Requirement.project_id == project.id))
                .scalars()
                .all()
            )
            for requirement in requirements:
                criteria = "\n".join(f"- {item}" for item in (requirement.acceptance_criteria or []))
                body = (
                    f"{requirement.title}\n\n{requirement.description or ''}\n\n"
                    f"Acceptance criteria:\n{criteria}"
                )
                row = knowledge.ingest_document(
                    project_id=project.id,
                    source=jira_source,
                    external_id=requirement.external_key,
                    title=f"{requirement.external_key} {requirement.title}",
                    content=body,
                    module=requirement.module,
                    artifact_type="requirement",
                    url=f"https://jira.example.com/browse/{requirement.external_key}",
                    tags=requirement.labels,
                    collection=jira_source.collection_name,
                )
                counts["documents"] += 1
                counts["chunks"] += row.chunk_count
            _mark_synced(jira_source, len(requirements))

        # --- Test cases (duplicate detection and reuse) ---------------------
        test_source = sources.get("test-repository")
        if test_source is not None:
            cases = list(
                session.execute(
                    select(TestCase).where(
                        TestCase.project_id == project.id, TestCase.is_deleted.is_(False)
                    )
                )
                .scalars()
                .all()
            )
            counts["test_cases"] = knowledge.index_texts(
                project_id=project.id,
                collection=test_source.collection_name,
                items=[
                    {
                        "id": case.id,
                        "content": (
                            f"{case.title}. {case.objective or ''} "
                            + " ".join(str(step.get("action", "")) for step in (case.steps or []))
                            + f" Expected: {case.expected_result or ''}"
                        ),
                        "metadata": {
                            "source_type": "test_case",
                            "source_id": test_source.id,
                            "test_case_id": case.id,
                            "title": case.title,
                            "external_id": case.key,
                            "module": case.module,
                            "artifact_type": "test_case",
                            "priority": case.priority,
                        },
                    }
                    for case in cases
                ],
            )
            _mark_synced(test_source, len(cases))

        # --- Defects (similarity and duplicate triage) ----------------------
        defect_source = sources.get("defect-history")
        if defect_source is not None:
            defects = list(
                session.execute(
                    select(Defect).where(Defect.project_id == project.id, Defect.is_deleted.is_(False))
                )
                .scalars()
                .all()
            )
            counts["defects"] = knowledge.index_texts(
                project_id=project.id,
                collection=defect_source.collection_name,
                items=[
                    {
                        "id": defect.id,
                        "content": f"{defect.title}. {defect.description or ''}",
                        "metadata": {
                            "source_type": "defect",
                            "source_id": defect_source.id,
                            "defect_id": defect.id,
                            "title": defect.title,
                            "external_id": defect.external_key,
                            "module": defect.module,
                            "artifact_type": "defect",
                            "severity": defect.severity,
                            "failure_signature": defect.failure_signature or "",
                        },
                    }
                    for defect in defects
                ],
            )
            _mark_synced(defect_source, len(defects))

        # --- Execution failure history (RCA evidence) -----------------------
        execution_source = sources.get("execution-history")
        if execution_source is not None:
            failures = list(
                session.execute(
                    select(ExecutionTest)
                    .join(Execution, Execution.id == ExecutionTest.execution_id)
                    .where(
                        Execution.project_id == project.id,
                        ExecutionTest.result.in_(["failed", "flaky"]),
                    )
                    .limit(300)
                )
                .scalars()
                .all()
            )
            counts["failures"] = knowledge.index_texts(
                project_id=project.id,
                collection=execution_source.collection_name,
                items=[
                    {
                        "id": failure.id,
                        "content": (
                            f"{failure.name} in {failure.module} {failure.result} with "
                            f"{failure.failure_signature or 'no signature'}: {failure.failure_message or ''}"
                        ),
                        "metadata": {
                            "source_type": "execution",
                            "source_id": execution_source.id,
                            "execution_test_id": failure.id,
                            "title": failure.name,
                            "module": failure.module,
                            "artifact_type": "failure",
                            "failure_signature": failure.failure_signature or "",
                            "failure_category": failure.failure_category or "",
                            "result": failure.result,
                        },
                    }
                    for failure in failures
                ],
            )
            _mark_synced(execution_source, len(failures))

        # Agent capability descriptions power conversational agent selection.
        from app.copilot.service import index_agent_catalog  # noqa: PLC0415

        counts["agents"] = index_agent_catalog(session, project)

        knowledge.sync_collection_stats()
        session.commit()

    logger.info("knowledge_indexed", **counts)
    return counts


def _mark_synced(source: KnowledgeSource, document_count: int) -> None:
    source.sync_status = "indexed"
    source.last_synced_at = datetime.now(UTC)
    source.document_count = document_count


def _summarize(session: Session, project: Project) -> dict[str, Any]:
    from sqlalchemy import func  # noqa: PLC0415

    from app.models.agent import Agent  # noqa: PLC0415
    from app.models.flow import AgentFlow  # noqa: PLC0415
    from app.models.testing import TestScenario, TestScript  # noqa: PLC0415

    def count(model, *conditions) -> int:  # noqa: ANN001
        statement = select(func.count(model.id))
        for condition in conditions:
            statement = statement.where(condition)
        return int(session.execute(statement).scalar_one() or 0)

    return {
        "project_key": project.key,
        "project_id": project.id,
        "agents": count(Agent),
        "flows": count(AgentFlow, AgentFlow.project_id == project.id),
        "requirements": count(Requirement, Requirement.project_id == project.id),
        "scenarios": count(TestScenario, TestScenario.project_id == project.id),
        "test_cases": count(TestCase, TestCase.project_id == project.id),
        "test_scripts": count(TestScript, TestScript.project_id == project.id),
        "executions": count(Execution, Execution.project_id == project.id),
        "execution_tests": count(ExecutionTest),
        "defects": count(Defect, Defect.project_id == project.id),
    }
