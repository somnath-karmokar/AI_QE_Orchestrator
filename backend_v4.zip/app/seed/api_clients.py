"""One API user, so the integration surface is demonstrable out of the box.

Every other part of the demo is explorable the moment it is seeded. The
integration API was not: a key is shown once at creation and only a hash is
kept, so a fresh install had nothing to sign into the API user portal with and
every agent's API endpoint panel read "no key can call this yet".

This seeds a key whose token is a fixed, obviously-fake demo string, exactly as
the demo accounts share one obviously-fake password. It is only ever created by
the demo seed, and `APP_MODE=production` refuses to start while demo mode is on,
so it cannot follow anyone into a real deployment.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.core.security import hash_api_token
from app.models.integration import IntegrationClient
from app.models.project import Project

logger = get_logger(__name__)

# Deliberately recognisable: nobody should mistake this for a real credential,
# and it is greppable if it ever turns up somewhere it should not.
DEMO_API_KEY = "qei_demo-acme-partner-platform"
DEMO_CLIENT_NAME = "acme-partner-platform"


def seed_demo_api_client(session: Session, project: Project) -> IntegrationClient | None:
    """Give the demo project one project-wide API user."""
    existing = session.execute(
        select(IntegrationClient).where(
            IntegrationClient.project_id == project.id,
            IntegrationClient.name == DEMO_CLIENT_NAME,
            IntegrationClient.is_deleted.is_(False),
        )
    ).scalars().first()
    if existing is not None:
        return existing

    client = IntegrationClient(
        project_id=project.id,
        name=DEMO_CLIENT_NAME,
        description="A partner platform calling this project's agents and flows.",
        platform="acme",
        token_hash=hash_api_token(DEMO_API_KEY),
        token_hint=DEMO_API_KEY[-4:],
        scopes=["catalog:read", "flows:run", "agents:run", "runs:read", "runs:cancel", "approvals:read", "runs:logs"],
        # The whole project, which is what makes the portal worth looking at.
        grants_all_flows=True,
        grants_all_agents=True,
        rate_limit_per_minute=60,
        created_by="seed",
    )
    session.add(client)
    session.flush()
    logger.info("seed_demo_api_client", name=DEMO_CLIENT_NAME, token_hint=client.token_hint)
    return client


def seed_project_members(session: Session, project: Project, users: dict) -> int:
    """Put every demo user in the demo project.

    Membership is the tenant boundary, so without this the seeded users would
    sign in and see nothing at all.
    """
    from app.models.identity import ProjectMember  # noqa: PLC0415

    existing = {
        row.user_id
        for row in session.execute(
            select(ProjectMember).where(ProjectMember.project_id == project.id)
        ).scalars()
    }
    added = 0
    for user in users.values():
        if user.id in existing:
            continue
        session.add(
            ProjectMember(
                project_id=project.id,
                user_id=user.id,
                access="owner" if user.role_key == "admin" else "member",
                added_by="seed",
            )
        )
        added += 1
    session.flush()
    logger.info("seed_project_members", project=project.key, added=added)
    return added
