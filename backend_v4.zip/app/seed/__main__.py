"""Seed the demo data from the command line.

    python -m app.seed            # seed if the demo project is missing
    python -m app.seed --reset    # drop everything and rebuild from the deterministic seed

Run it while the API is stopped: a reset drops tables and vector collections.
"""

from __future__ import annotations

import argparse
import json
import sys
import time


def main() -> int:
    parser = argparse.ArgumentParser(prog="python -m app.seed", description=__doc__.splitlines()[0])
    parser.add_argument("--reset", action="store_true", help="drop all data first and rebuild it")
    parser.add_argument("--no-index", action="store_true", help="skip embedding documents into Chroma")
    args = parser.parse_args()

    from app.seed.runner import seed_all  # noqa: PLC0415 - settings load on import

    print("Resetting and seeding demo data..." if args.reset else "Seeding demo data...", flush=True)
    started = time.perf_counter()
    summary = seed_all(reset=args.reset, index_knowledge=not args.no_index)
    print(json.dumps(summary, indent=2, default=str))
    print(f"Done in {time.perf_counter() - started:.0f}s", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
