"""The customer journeys the demo project's tests actually belong to.

Modules group tests by where they were filed. These group them by what a
customer does, which is what makes "a repair here needs checking over there" a
question the platform can answer.

Test cases are attached to steps by module, so the graph reflects the demo data
rather than a hand-written list that drifts out of date.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.models.project import Project
from app.models.testing import BusinessFlow, BusinessFlowStep, TestCase, TestDependency

logger = get_logger(__name__)

# Each step names what it touches and what must remain true after it. The
# assertions are business outcomes: healing may never change them, and they are
# what a repair downstream is validated against.
JOURNEYS: list[dict] = [
    {
        "key": "payment-journey",
        "name": "Make a payment",
        "description": "Sign in, choose a beneficiary, enter an amount, confirm and pay.",
        "criticality": "critical",
        "owner": "priya.raman@example.com",
        "modules": ["Login", "Beneficiaries", "Payments", "Accounts"],
        "steps": [
            {
                "key": "sign-in",
                "name": "Sign in",
                "module": "Login",
                "ui_components": ["login-form", "username-field", "password-field"],
                "api_endpoints": ["/api/session"],
                "data_entities": ["user"],
                "assertions": ["The customer reaches the account overview."],
            },
            {
                "key": "choose-beneficiary",
                "name": "Choose a beneficiary",
                "module": "Beneficiaries",
                "ui_components": ["beneficiary-list", "beneficiary-search"],
                "api_endpoints": ["/api/beneficiaries"],
                "data_entities": ["beneficiary"],
                "assertions": ["Only the customer's own beneficiaries are listed."],
            },
            {
                "key": "enter-amount",
                "name": "Enter an amount",
                "module": "Payments",
                "ui_components": ["amount-field", "currency-selector", "promo-code"],
                "api_endpoints": ["/api/payments/quote"],
                "data_entities": ["account"],
                "assertions": ["The daily limit is applied before the payment is offered."],
            },
            {
                "key": "confirm-payment",
                "name": "Confirm and pay",
                "module": "Payments",
                "ui_components": ["checkout-submit-btn", "pay-now", "order-total"],
                "api_endpoints": ["/api/payments"],
                "data_entities": ["payment"],
                "assertions": [
                    "The amount debited equals the amount confirmed.",
                    "A confirmation reference is shown to the customer.",
                ],
            },
            {
                "key": "see-statement",
                "name": "See it on the statement",
                "module": "Accounts",
                "ui_components": ["transaction-list", "running-balance"],
                "api_endpoints": ["/api/accounts/transactions"],
                "data_entities": ["transaction"],
                "assertions": ["The running balance reflects the payment exactly once."],
            },
        ],
    },
    {
        "key": "profile-journey",
        "name": "Update customer details",
        "description": "Change an email or address, verify it, and see it applied.",
        "criticality": "high",
        "owner": "sara.lindqvist@example.com",
        "modules": ["Login", "Customer Profile"],
        "steps": [
            {
                "key": "open-profile",
                "name": "Open the profile",
                "module": "Customer Profile",
                "ui_components": ["profile-panel"],
                "api_endpoints": ["/api/profile"],
                "data_entities": ["customer"],
                "assertions": ["The details shown belong to the signed-in customer."],
            },
            {
                "key": "change-details",
                "name": "Change the details",
                "module": "Customer Profile",
                "ui_components": ["email-field", "address-field", "save-button"],
                "api_endpoints": ["/api/profile"],
                "data_entities": ["customer"],
                "assertions": ["A change is only saved after it is verified."],
            },
        ],
    },
]


def seed_business_flows(session: Session, project: Project) -> dict[str, int]:
    """Create the journeys and attach the project's tests to their steps."""
    existing = {
        row.key
        for row in session.execute(
            select(BusinessFlow).where(BusinessFlow.project_id == project.id)
        )
        .scalars()
        .all()
    }

    created_flows = 0
    created_steps = 0
    for journey in JOURNEYS:
        if journey["key"] in existing:
            continue
        flow = BusinessFlow(
            project_id=project.id,
            key=journey["key"],
            name=journey["name"],
            description=journey["description"],
            criticality=journey["criticality"],
            owner=journey["owner"],
            modules=list(journey["modules"]),
        )
        session.add(flow)
        session.flush()
        created_flows += 1

        for position, step in enumerate(journey["steps"]):
            session.add(
                BusinessFlowStep(
                    business_flow_id=flow.id,
                    position=position,
                    key=step["key"],
                    name=step["name"],
                    module=step["module"],
                    ui_components=list(step["ui_components"]),
                    api_endpoints=list(step["api_endpoints"]),
                    data_entities=list(step["data_entities"]),
                    assertions=list(step["assertions"]),
                )
            )
            created_steps += 1
    session.flush()

    links = _attach_tests(session, project)
    logger.info(
        "business_flows_seeded",
        flows=created_flows,
        steps=created_steps,
        dependencies=links,
    )
    return {"flows": created_flows, "steps": created_steps, "dependencies": links}


def _attach_tests(session: Session, project: Project) -> int:
    """Link each automated test to the step its module belongs to.

    By module, because that is the association the demo data actually supports.
    A real deployment would derive this from the test's own steps; inventing a
    finer-grained mapping here would look more precise than it is.
    """
    steps = list(
        session.execute(
            select(BusinessFlowStep)
            .join(BusinessFlow, BusinessFlow.id == BusinessFlowStep.business_flow_id)
            .where(BusinessFlow.project_id == project.id)
            .order_by(BusinessFlowStep.position)
        )
        .scalars()
        .all()
    )
    if not steps:
        return 0

    by_module: dict[str, list[BusinessFlowStep]] = {}
    for step in steps:
        by_module.setdefault((step.module or "").lower(), []).append(step)

    existing = {
        (row.test_case_id, row.business_flow_step_id)
        for row in session.execute(
            select(TestDependency).where(TestDependency.project_id == project.id)
        )
        .scalars()
        .all()
    }

    created = 0
    cases = list(
        session.execute(
            select(TestCase).where(
                TestCase.project_id == project.id, TestCase.is_deleted.is_(False)
            )
        )
        .scalars()
        .all()
    )
    for case in cases:
        candidates = by_module.get((case.module or "").lower(), [])
        if not candidates:
            continue
        # The first step of the module is the one the test covers; later steps
        # in the same module are traversed on the way through.
        for index, step in enumerate(candidates):
            key = (case.id, step.id)
            if key in existing:
                continue
            session.add(
                TestDependency(
                    project_id=project.id,
                    test_case_id=case.id,
                    business_flow_step_id=step.id,
                    relationship_type="covers" if index == 0 else "traverses",
                )
            )
            existing.add(key)
            created += 1
    session.flush()
    return created
