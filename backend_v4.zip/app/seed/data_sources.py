"""Two connected data sources, so the screen is not empty on a fresh install.

Deliberately modest. A demo credential is still a credential as far as the code
is concerned -- it goes through the same encryption path as a real one, which is
half the point of seeding it: the demo shows a stored credential that cannot be
read back, rather than a screenshot of one.

The hosts are `.example` names from RFC 2606, so nothing here resolves and a
connection test reports honestly that it could not reach them. That is better
than pointing at something real and better than a seeded green tick.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.models.datasource import DataSource
from app.models.project import Project
from app.services import data_sources

logger = get_logger(__name__)

DEMO_SOURCES = (
    {
        "name": "Order warehouse (read-only)",
        "kind": "postgres",
        "description": "The customer's reporting replica, used to verify what a test wrote.",
        "connection": {
            "host": "warehouse.acme-retail.example",
            "port": 5432,
            "database": "orders",
            "username": "qe_reader",
            "password": "demo-only-not-a-real-password",
        },
    },
    {
        "name": "Checkout API (staging)",
        "kind": "rest_api",
        "description": "The customer's own staging API, called by agents during a run.",
        "connection": {
            "base_url": "https://api.staging.acme-retail.example",
            "api_key": "demo-only-not-a-real-key",
        },
    },
)


def seed_data_sources(session: Session, project: Project) -> int:
    """Connect the demo data sources, once."""
    existing = {
        row.key
        for row in session.execute(
            select(DataSource).where(DataSource.project_id == project.id)
        ).scalars()
    }
    added = 0
    for spec in DEMO_SOURCES:
        if data_sources.slug(spec["name"]) in existing:
            continue
        data_sources.create(
            session,
            project_id=project.id,
            name=spec["name"],
            kind=spec["kind"],
            connection=dict(spec["connection"]),
            description=spec["description"],
            actor="seed",
        )
        added += 1

    logger.info("seed_data_sources", project=project.key, added=added)
    return added
