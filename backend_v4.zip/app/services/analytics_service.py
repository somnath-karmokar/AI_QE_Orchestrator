"""Dashboard KPIs, trends, coverage and traceability (spec §14, §16).

Every number here is computed from persisted state -- no hard-coded dashboard
values (spec §37).
"""

from __future__ import annotations

import statistics
from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.cost.tracker import CostTracker
from app.models.agent import Agent
from app.models.defect import Defect, DefectPrediction, RootCauseAnalysis
from app.models.governance import ApprovalRequest
from app.models.llm import LLMUsage
from app.models.run import AgentRun
from app.models.testing import (
    Execution,
    ExecutionTest,
    HealingRecord,
    RegressionAnalysis,
    Requirement,
    TestCase,
    TestScenario,
    TestScript,
)


class AnalyticsService:
    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Dashboard
    # ------------------------------------------------------------------
    def dashboard(self, project_id: str, window_days: int = 30) -> dict[str, Any]:
        since = datetime.now(UTC) - timedelta(days=window_days)

        coverage = self.coverage(project_id)
        executions = list(
            self.session.execute(
                select(Execution)
                .where(Execution.project_id == project_id, Execution.created_at >= since)
                .order_by(Execution.created_at.asc())
            )
            .scalars()
            .all()
        )

        pass_rates = [execution.pass_rate for execution in executions if execution.total_tests]
        current_pass_rate = round(statistics.fmean(pass_rates), 4) if pass_rates else 0.0

        # Trend: recent third versus earliest third of the window.
        third = max(1, len(pass_rates) // 3)
        trend_pp = (
            round((statistics.fmean(pass_rates[-third:]) - statistics.fmean(pass_rates[:third])) * 100, 1)
            if len(pass_rates) >= 3
            else 0.0
        )

        total_tests = sum(execution.total_tests for execution in executions)
        flaky_total = sum(execution.flaky for execution in executions)
        healed_total = sum(execution.healed for execution in executions)
        flaky_rate = round(flaky_total / total_tests, 4) if total_tests else 0.0

        regression = (
            self.session.execute(
                select(RegressionAnalysis)
                .where(RegressionAnalysis.project_id == project_id)
                .order_by(RegressionAnalysis.created_at.desc())
            )
            .scalars()
            .first()
        )

        cost = CostTracker(self.session).breakdown(project_id, days=window_days)

        # Mean time to diagnose: how long RCA takes from defect creation.
        rca_rows = list(
            self.session.execute(
                select(RootCauseAnalysis).where(RootCauseAnalysis.project_id == project_id)
            )
            .scalars()
            .all()
        )
        diagnose_hours: list[float] = []
        for rca in rca_rows:
            if not rca.defect_id:
                continue
            defect = self.session.get(Defect, rca.defect_id)
            if defect is None:
                continue
            delta = rca.created_at.replace(tzinfo=UTC) - defect.created_at.replace(tzinfo=UTC)
            if delta.total_seconds() > 0:
                diagnose_hours.append(delta.total_seconds() / 3600)

        runs = list(
            self.session.execute(
                select(AgentRun).where(AgentRun.project_id == project_id, AgentRun.created_at >= since)
            )
            .scalars()
            .all()
        )
        approvals = list(
            self.session.execute(
                select(ApprovalRequest).where(ApprovalRequest.project_id == project_id)
            )
            .scalars()
            .all()
        )
        decided = [item for item in approvals if item.status in {"approved", "rejected"}]

        # AI automation rate: share of artifacts an agent produced.
        agent_generated = int(
            self.session.execute(
                select(func.count(TestCase.id)).where(
                    TestCase.project_id == project_id,
                    TestCase.generated_by_agent.is_not(None),
                    TestCase.is_deleted.is_(False),
                )
            ).scalar_one()
            or 0
        )
        all_cases = coverage["totals"]["test_cases"]
        ai_automation_rate = round(agent_generated / all_cases, 4) if all_cases else 0.0

        # Agent runs append new predictions, so keep only the latest per module.
        predictions = self._latest_predictions(project_id)
        # Prediction accuracy is only meaningful once outcomes are observed.
        observed = [item for item in predictions if item.outcome_observed is not None]
        prediction_accuracy = (
            round(sum(1 for item in observed if item.outcome_observed) / len(observed), 4)
            if observed
            else None
        )

        return {
            "window_days": window_days,
            "kpis": {
                "automation_coverage": coverage["automation_coverage"],
                "requirement_coverage": coverage["requirement_coverage"],
                "regression_optimization": round((regression.reduction_percent if regression else 0.0) / 100, 4),
                "defect_prediction_accuracy": prediction_accuracy,
                "test_pass_rate": current_pass_rate,
                "flaky_test_rate": flaky_rate,
                "mean_time_to_diagnose_hours": (
                    round(statistics.fmean(diagnose_hours), 2) if diagnose_hours else None
                ),
                "ai_automation_rate": ai_automation_rate,
                "ai_cost_usd": cost["total_cost_usd"],
                "human_approval_rate": (
                    round(len(decided) / len(approvals), 4) if approvals else 0.0
                ),
            },
            "deltas": {"test_pass_rate_pp": trend_pp},
            "totals": {
                **coverage["totals"],
                "executions": len(executions),
                "tests_executed": total_tests,
                "healed_tests": healed_total,
                "agent_runs": len(runs),
                "pending_approvals": sum(1 for item in approvals if item.status == "pending"),
            },
            "charts": {
                "execution_trend": self.execution_trend(project_id, window_days),
                "defect_trend": self.defect_trend(project_id, window_days),
                "failure_categories": self.failure_categories(project_id, window_days),
                "agent_utilization": self.agent_utilization(project_id, window_days),
                "coverage_by_module": coverage["by_module"],
                "quality_risk": [
                    {
                        "module": item.module,
                        "probability": item.probability,
                        "risk_band": item.risk_band,
                    }
                    for item in sorted(predictions, key=lambda row: row.probability, reverse=True)
                ],
                "cost_by_agent": cost["by_agent"][:8],
            },
            "summary": self.intelligence_summary(project_id, coverage, regression, trend_pp, flaky_rate),
        }

    def intelligence_summary(
        self,
        project_id: str,
        coverage: dict[str, Any],
        regression: RegressionAnalysis | None,
        trend_pp: float,
        flaky_rate: float,
    ) -> str:
        """Narrative summary generated from the metrics above (spec §16)."""
        parts: list[str] = []

        high_risk = [
            item for item in self._latest_predictions(project_id) if item.risk_band == "high"
        ]
        if high_risk:
            modules = ", ".join(item.module for item in high_risk[:2])
            parts.append(
                f"Quality risk is concentrated in {modules}, where defect likelihood reaches "
                f"{high_risk[0].probability:.0%} over the next {high_risk[0].horizon_days} days."
            )

        if regression is not None and regression.reduction_percent:
            parts.append(
                f"Regression optimisation selected {len(regression.selected_tests)} of "
                f"{len(regression.selected_tests) + len(regression.skipped_tests)} automated tests, "
                f"reducing estimated suite duration by {regression.reduction_percent:.0f}%."
            )

        if trend_pp:
            direction = "improved" if trend_pp > 0 else "declined"
            parts.append(f"Pass rate has {direction} by {abs(trend_pp):.1f} points across the window.")

        uncovered = coverage["totals"]["requirements"] - coverage["totals"]["covered_requirements"]
        if uncovered:
            parts.append(f"{uncovered} requirement(s) still have no test coverage.")

        if flaky_rate > 0.02:
            parts.append(
                f"Flaky rate of {flaky_rate:.2%} is above the 2% threshold and is eroding trust in the suite."
            )

        return " ".join(parts) or "Quality signals are stable across the selected window."

    def _latest_predictions(self, project_id: str) -> list[DefectPrediction]:
        """Most recent prediction per module, highest probability first."""
        rows = list(
            self.session.execute(
                select(DefectPrediction)
                .where(DefectPrediction.project_id == project_id)
                .order_by(DefectPrediction.created_at.desc())
            )
            .scalars()
            .all()
        )
        latest: dict[str, DefectPrediction] = {}
        for row in rows:
            latest.setdefault(row.target_ref, row)
        return sorted(latest.values(), key=lambda item: item.probability, reverse=True)

    # ------------------------------------------------------------------
    # Charts
    # ------------------------------------------------------------------
    def execution_trend(self, project_id: str, window_days: int = 30) -> list[dict[str, Any]]:
        since = datetime.now(UTC) - timedelta(days=window_days)
        rows = list(
            self.session.execute(
                select(Execution)
                .where(Execution.project_id == project_id, Execution.created_at >= since)
                .order_by(Execution.created_at.asc())
            )
            .scalars()
            .all()
        )
        return [
            {
                "date": row.created_at.date().isoformat(),
                "name": row.name,
                "passed": row.passed,
                "failed": row.failed,
                "skipped": row.skipped,
                "flaky": row.flaky,
                "pass_rate": round(row.pass_rate * 100, 1),
                "duration_minutes": round(row.duration_ms / 60000, 1),
            }
            for row in rows
        ]

    def defect_trend(self, project_id: str, window_days: int = 30) -> list[dict[str, Any]]:
        since = datetime.now(UTC) - timedelta(days=window_days)
        rows = list(
            self.session.execute(
                select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )

        buckets: dict[str, dict[str, int]] = {}
        for offset in range(window_days, -1, -1):
            day = (datetime.now(UTC) - timedelta(days=offset)).date().isoformat()
            buckets[day] = {"opened": 0, "resolved": 0}

        for row in rows:
            created = row.created_at.date().isoformat()
            if created in buckets:
                buckets[created]["opened"] += 1
            if row.resolved_at:
                resolved = row.resolved_at.date().isoformat()
                if resolved in buckets:
                    buckets[resolved]["resolved"] += 1

        open_count = sum(1 for row in rows if row.status in {"open", "triage", "in_progress"} and row.created_at.replace(tzinfo=UTC) < since)
        series: list[dict[str, Any]] = []
        for day, values in buckets.items():
            open_count += values["opened"] - values["resolved"]
            series.append({"date": day, **values, "open": max(0, open_count)})
        return series

    def failure_categories(self, project_id: str, window_days: int = 30) -> list[dict[str, Any]]:
        since = datetime.now(UTC) - timedelta(days=window_days)
        rows = self.session.execute(
            select(ExecutionTest.failure_category, func.count(ExecutionTest.id))
            .join(Execution, Execution.id == ExecutionTest.execution_id)
            .where(
                Execution.project_id == project_id,
                ExecutionTest.created_at >= since,
                ExecutionTest.failure_category.is_not(None),
            )
            .group_by(ExecutionTest.failure_category)
            .order_by(func.count(ExecutionTest.id).desc())
        ).all()

        labels = {
            "locator_drift": "Locator drift",
            "timing": "Timing / synchronisation",
            "application_defect": "Application defect",
            "environment": "Environment",
            "test_data": "Test data",
        }
        total = sum(row[1] for row in rows) or 1
        return [
            {
                "category": row[0],
                "label": labels.get(row[0], row[0].replace("_", " ").title()),
                "count": row[1],
                "share": round(row[1] / total, 4),
            }
            for row in rows
        ]

    def agent_utilization(self, project_id: str, window_days: int = 30) -> list[dict[str, Any]]:
        since = datetime.now(UTC) - timedelta(days=window_days)
        rows = self.session.execute(
            select(
                LLMUsage.agent_key,
                func.count(LLMUsage.id),
                func.sum(LLMUsage.total_tokens),
                func.sum(LLMUsage.estimated_cost_usd),
                func.avg(LLMUsage.latency_ms),
            )
            .where(LLMUsage.project_id == project_id, LLMUsage.created_at >= since)
            .group_by(LLMUsage.agent_key)
            .order_by(func.count(LLMUsage.id).desc())
        ).all()

        agent_names = {
            agent.key: agent.name
            for agent in self.session.execute(select(Agent)).scalars().all()
        }
        return [
            {
                "agent_key": row[0],
                "agent_name": agent_names.get(row[0], row[0]),
                "invocations": int(row[1] or 0),
                "tokens": int(row[2] or 0),
                "cost_usd": round(float(row[3] or 0), 6),
                "avg_latency_ms": int(row[4] or 0),
            }
            for row in rows
            if row[0]
        ][:12]

    # ------------------------------------------------------------------
    # Coverage and traceability
    # ------------------------------------------------------------------
    def coverage(self, project_id: str) -> dict[str, Any]:
        requirements = list(
            self.session.execute(
                select(Requirement).where(
                    Requirement.project_id == project_id, Requirement.is_deleted.is_(False)
                )
            )
            .scalars()
            .all()
        )
        scenarios = list(
            self.session.execute(
                select(TestScenario).where(
                    TestScenario.project_id == project_id, TestScenario.is_deleted.is_(False)
                )
            )
            .scalars()
            .all()
        )
        cases = list(
            self.session.execute(
                select(TestCase).where(TestCase.project_id == project_id, TestCase.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )
        automated_case_ids = {
            row[0]
            for row in self.session.execute(
                select(TestScript.test_case_id).where(
                    TestScript.project_id == project_id, TestScript.is_deleted.is_(False)
                )
            ).all()
            if row[0]
        }
        defects = list(
            self.session.execute(
                select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )

        scenarios_by_requirement: dict[str, list[TestScenario]] = {}
        for scenario in scenarios:
            if scenario.requirement_id:
                scenarios_by_requirement.setdefault(scenario.requirement_id, []).append(scenario)
        cases_by_scenario: dict[str, list[TestCase]] = {}
        for case in cases:
            if case.scenario_id:
                cases_by_scenario.setdefault(case.scenario_id, []).append(case)

        covered = automated = executed = 0
        module_stats: dict[str, dict[str, int]] = {}

        for requirement in requirements:
            linked_scenarios = scenarios_by_requirement.get(requirement.id, [])
            linked_cases = [
                case for scenario in linked_scenarios for case in cases_by_scenario.get(scenario.id, [])
            ]
            has_automation = any(case.id in automated_case_ids for case in linked_cases)
            has_execution = any(case.execution_count > 0 for case in linked_cases)

            if linked_cases:
                covered += 1
            if has_automation:
                automated += 1
            if has_execution:
                executed += 1

            stats = module_stats.setdefault(
                requirement.module,
                {"requirements": 0, "covered": 0, "automated": 0, "test_cases": 0, "defects": 0},
            )
            stats["requirements"] += 1
            stats["covered"] += 1 if linked_cases else 0
            stats["automated"] += 1 if has_automation else 0
            stats["test_cases"] += len(linked_cases)

        for defect in defects:
            if defect.module in module_stats:
                module_stats[defect.module]["defects"] += 1

        total = len(requirements) or 1
        risk_weighted = [req for req in requirements if req.risk_score >= 0.6]
        risk_covered = sum(
            1
            for req in risk_weighted
            if any(
                cases_by_scenario.get(scenario.id)
                for scenario in scenarios_by_requirement.get(req.id, [])
            )
        )

        return {
            "requirement_coverage": round(covered / total, 4),
            "scenario_coverage": round(
                len([req for req in requirements if scenarios_by_requirement.get(req.id)]) / total, 4
            ),
            "automation_coverage": round(automated / total, 4),
            "execution_coverage": round(executed / total, 4),
            "defect_coverage": round(
                len({defect.requirement_id for defect in defects if defect.requirement_id}) / total, 4
            ),
            "risk_coverage": round(risk_covered / len(risk_weighted), 4) if risk_weighted else 1.0,
            "totals": {
                "requirements": len(requirements),
                "covered_requirements": covered,
                "scenarios": len(scenarios),
                "test_cases": len(cases),
                "automated_test_cases": len(automated_case_ids),
                "defects": len(defects),
            },
            "by_module": [
                {
                    "module": module,
                    **stats,
                    "coverage": round(stats["covered"] / stats["requirements"], 4)
                    if stats["requirements"]
                    else 0.0,
                    "automation": round(stats["automated"] / stats["requirements"], 4)
                    if stats["requirements"]
                    else 0.0,
                }
                for module, stats in sorted(module_stats.items())
            ],
        }

    def traceability(self, project_id: str, module: str | None = None) -> dict[str, Any]:
        requirement_query = select(Requirement).where(
            Requirement.project_id == project_id, Requirement.is_deleted.is_(False)
        )
        if module:
            requirement_query = requirement_query.where(Requirement.module == module)
        requirements = list(self.session.execute(requirement_query).scalars().all())

        scenarios = list(
            self.session.execute(
                select(TestScenario).where(
                    TestScenario.project_id == project_id, TestScenario.is_deleted.is_(False)
                )
            )
            .scalars()
            .all()
        )
        cases = list(
            self.session.execute(
                select(TestCase).where(TestCase.project_id == project_id, TestCase.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )
        scripts = list(
            self.session.execute(
                select(TestScript).where(
                    TestScript.project_id == project_id, TestScript.is_deleted.is_(False)
                )
            )
            .scalars()
            .all()
        )
        defects = list(
            self.session.execute(
                select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )

        scenarios_by_requirement: dict[str, list[TestScenario]] = {}
        for scenario in scenarios:
            if scenario.requirement_id:
                scenarios_by_requirement.setdefault(scenario.requirement_id, []).append(scenario)
        cases_by_scenario: dict[str, list[TestCase]] = {}
        for case in cases:
            if case.scenario_id:
                cases_by_scenario.setdefault(case.scenario_id, []).append(case)
        scripts_by_case: dict[str, list[TestScript]] = {}
        for script in scripts:
            if script.test_case_id:
                scripts_by_case.setdefault(script.test_case_id, []).append(script)
        defects_by_case: dict[str, list[Defect]] = {}
        for defect in defects:
            if defect.test_case_id:
                defects_by_case.setdefault(defect.test_case_id, []).append(defect)

        rows: list[dict[str, Any]] = []
        for requirement in requirements:
            linked_scenarios = scenarios_by_requirement.get(requirement.id, [])
            scenario_rows: list[dict[str, Any]] = []

            for scenario in linked_scenarios:
                linked_cases = cases_by_scenario.get(scenario.id, [])
                case_rows = [
                    {
                        "id": case.id,
                        "key": case.key,
                        "title": case.title,
                        "priority": case.priority,
                        "is_automated": case.is_automated,
                        "last_result": case.last_result,
                        "execution_count": case.execution_count,
                        "scripts": [
                            {"id": script.id, "file_path": script.file_path, "framework": script.framework}
                            for script in scripts_by_case.get(case.id, [])
                        ],
                        "defects": [
                            {
                                "id": defect.id,
                                "key": defect.external_key,
                                "title": defect.title,
                                "severity": defect.severity,
                                "status": defect.status,
                            }
                            for defect in defects_by_case.get(case.id, [])
                        ],
                    }
                    for case in linked_cases
                ]
                scenario_rows.append(
                    {
                        "id": scenario.id,
                        "key": scenario.key,
                        "title": scenario.title,
                        "type": scenario.scenario_type,
                        "test_cases": case_rows,
                    }
                )

            all_cases = [case for scenario in linked_scenarios for case in cases_by_scenario.get(scenario.id, [])]
            rows.append(
                {
                    "requirement": {
                        "id": requirement.id,
                        "key": requirement.external_key,
                        "title": requirement.title,
                        "module": requirement.module,
                        "priority": requirement.priority,
                        "status": requirement.status,
                        "risk_score": requirement.risk_score,
                        "acceptance_criteria_count": len(requirement.acceptance_criteria or []),
                    },
                    "scenarios": scenario_rows,
                    "counts": {
                        "scenarios": len(linked_scenarios),
                        "test_cases": len(all_cases),
                        "automated": sum(1 for case in all_cases if case.is_automated),
                        "executed": sum(1 for case in all_cases if case.execution_count > 0),
                        "defects": sum(len(defects_by_case.get(case.id, [])) for case in all_cases),
                    },
                    "status": "covered" if all_cases else "uncovered",
                }
            )

        uncovered = [row for row in rows if row["status"] == "uncovered"]
        return {
            "rows": rows,
            "summary": {
                "requirements": len(rows),
                "covered": len(rows) - len(uncovered),
                "uncovered": len(uncovered),
                "uncovered_keys": [row["requirement"]["key"] for row in uncovered],
                "modules": sorted({row["requirement"]["module"] for row in rows}),
            },
        }

    # ------------------------------------------------------------------
    # Defect intelligence
    # ------------------------------------------------------------------
    def defect_insights(self, project_id: str) -> dict[str, Any]:
        defects = list(
            self.session.execute(
                select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )
        healing = list(
            self.session.execute(select(HealingRecord).where(HealingRecord.project_id == project_id))
            .scalars()
            .all()
        )

        by_status = Counter(defect.status for defect in defects)
        by_severity = Counter(defect.severity for defect in defects)
        by_module = Counter(defect.module for defect in defects)
        clusters = Counter(defect.cluster_key for defect in defects if defect.cluster_key)

        resolution_days: list[float] = []
        for defect in defects:
            if defect.resolved_at:
                delta = defect.resolved_at.replace(tzinfo=UTC) - defect.created_at.replace(tzinfo=UTC)
                resolution_days.append(delta.total_seconds() / 86400)

        return {
            "total": len(defects),
            "open": sum(by_status.get(status, 0) for status in ("open", "triage", "in_progress")),
            "resolved": by_status.get("resolved", 0) + by_status.get("closed", 0),
            "ai_suggested": sum(1 for defect in defects if defect.is_ai_suggested),
            "by_status": dict(by_status),
            "by_severity": dict(by_severity),
            "by_module": dict(by_module),
            "clusters": [
                {"cluster": key, "count": count} for key, count in clusters.most_common(10) if count > 1
            ],
            "mean_resolution_days": round(statistics.fmean(resolution_days), 2) if resolution_days else None,
            "healing": {
                "total": len(healing),
                "applied": sum(1 for record in healing if record.status == "applied"),
                "pending_review": sum(1 for record in healing if record.status == "proposed"),
                "mean_confidence": (
                    round(statistics.fmean([record.confidence for record in healing]), 3) if healing else None
                ),
            },
        }
