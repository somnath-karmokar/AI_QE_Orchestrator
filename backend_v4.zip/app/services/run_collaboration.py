"""How the agents in a run worked together, rebuilt from what the run recorded.

Agents in a flow collaborate through the orchestrator's shared run context: each
agent reads the run inputs and every earlier agent's published result, and
publishes its own result for the agents after it. Decisions read those results
to choose a path, and people approve or reject at gates.

This service turns a run's steps, approvals and events into three views of that
collaboration:

  * a graph of the flow with the state of every node and hand-off;
  * a conversation -- who handed what to whom, in order, with timestamps, so the
    UI can replay a finished run or follow a live one;
  * the shared context -- every fact published, who wrote it and who used it.

Nothing is invented: every message is derived from a stored step output, error,
approval decision or engine event.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest
from app.models.run import AgentMessage, AgentRun, AgentRunStep
from app.orchestration.graph import resolve_path

ROLE_LABELS = {
    "admin": "Platform Admin",
    "qe_lead": "QE Lead",
    "qe_engineer": "QE Engineer",
    "business_user": "Business / UAT",
}
FINISHED = {"succeeded", "partially_succeeded", "failed", "cancelled"}
REFERENCE = re.compile(r"\$?([A-Za-z_][A-Za-z0-9_-]*)((?:\.[A-Za-z_][A-Za-z0-9_-]*)+)")


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def _iso(value: datetime | None) -> str | None:
    value = _aware(value)
    return value.isoformat() if value else None


def _alias(key: str | None) -> str:
    return (key or "").replace("-", "_")


def _person(email: str | None) -> str:
    if not email:
        return "Someone"
    if "@" not in email:
        return email
    return " ".join(part.capitalize() for part in re.split(r"[._-]+", email.split("@")[0]) if part)


def _preview(value: Any, limit: int = 90) -> str:
    if isinstance(value, dict):
        if value.get("summary"):
            text = str(value["summary"])
        else:
            text = ", ".join(f"{key}={_preview(item, 24)}" for key, item in list(value.items())[:4])
    elif isinstance(value, list):
        text = f"{len(value)} item{'s' if len(value) != 1 else ''}"
    else:
        text = str(value)
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _join(names: list[str]) -> str:
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def _highlights(output: dict[str, Any]) -> list[dict[str, Any]]:
    """The few numbers worth saying out loud when an agent hands over its result."""
    items: list[dict[str, Any]] = []
    for key, value in (output.get("outputs") or {}).items():
        label = key.replace("_", " ")
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)):
            items.append({"label": label, "value": round(value, 3) if isinstance(value, float) else value})
        elif isinstance(value, list) and value:
            items.append({"label": label, "value": len(value)})
        if len(items) >= 4:
            break
    for key in ("findings", "recommendations", "artifacts"):
        if len(items) >= 5:
            break
        count = len(output.get(key) or [])
        if count:
            items.append({"label": key, "value": count})
    return items


class RunCollaboration:
    def __init__(self, session: Session, run: AgentRun) -> None:
        self.session = session
        self.run = run
        self.flow = session.get(AgentFlow, run.flow_id) if run.flow_id else None
        self.steps = list(
            session.execute(
                select(AgentRunStep).where(AgentRunStep.run_id == run.id).order_by(AgentRunStep.sequence)
            ).scalars()
        )
        self.step_by_node = {step.node_key: step for step in self.steps}
        agent_ids = {step.agent_id for step in self.steps if step.agent_id}
        if self.flow is not None:
            agent_ids |= {node.agent_id for node in self.flow.nodes if node.agent_id}
        self.agents = (
            {agent.id: agent for agent in session.execute(select(Agent).where(Agent.id.in_(agent_ids))).scalars()}
            if agent_ids
            else {}
        )
        self.approvals = list(
            session.execute(
                select(ApprovalRequest).where(ApprovalRequest.run_id == run.id).order_by(ApprovalRequest.created_at)
            ).scalars()
        )
        self.events = list(
            session.execute(
                select(AgentMessage).where(AgentMessage.run_id == run.id).order_by(AgentMessage.sequence)
            ).scalars()
        )

    # ------------------------------------------------------------------
    def build(self) -> dict[str, Any]:
        nodes, edges = self._graph()
        participants = self._participants(nodes)
        conversation = self._conversation(nodes, edges, participants)
        context = self._context(nodes)
        agent_keys = {node["node_key"] for node in nodes if node["node_type"] == "agent" and node["step_id"]}
        return {
            "run": {
                "id": self.run.id,
                "run_number": self.run.run_number,
                "title": self.run.title,
                "status": self.run.status,
                "trigger": self.run.trigger,
                "triggered_by": self.run.triggered_by,
                "started_at": _iso(self.run.started_at),
                "finished_at": _iso(self.run.finished_at),
                "duration_ms": self.run.duration_ms,
                "flow_id": self.run.flow_id,
                "flow_name": self.flow.name if self.flow else None,
                "flow_version": self.run.flow_version,
                "is_live": self.run.status in {"queued", "running"},
            },
            "graph": {"nodes": nodes, "edges": edges},
            "participants": list(participants.values()),
            "conversation": conversation,
            "context": context,
            "stats": {
                "agents": len(agent_keys),
                "messages": len(conversation),
                "handoffs": sum(1 for message in conversation if message["kind"] == "handoff"),
                "decisions": sum(1 for message in conversation if message["kind"] == "decision"),
                "human_decisions": sum(1 for message in conversation if message["kind"] == "approval_decision"),
                "shared_facts": len(context),
            },
        }

    # ------------------------------------------------------------------
    # Graph
    # ------------------------------------------------------------------
    def _flow_nodes(self) -> list[Any]:
        if self.flow is not None:
            return sorted(self.flow.nodes, key=lambda node: (node.position_y, node.position_x))
        return []

    def _graph(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        run_finished = self.run.status in FINISHED
        run_ok = self.run.status in {"succeeded", "partially_succeeded"}
        nodes: list[dict[str, Any]] = []

        flow_nodes = self._flow_nodes()
        if not flow_nodes:  # a single-agent run
            for index, step in enumerate(self.steps):
                agent = self.agents.get(step.agent_id)
                nodes.append(self._node_dict(step.node_key, "agent", step.label, 120, 80 + index * 150, agent, step, run_finished))
            return nodes, []

        for node in flow_nodes:
            agent = self.agents.get(node.agent_id) if node.agent_id else None
            step = self.step_by_node.get(node.node_key)
            entry = self._node_dict(
                node.node_key, node.node_type, node.label, node.position_x, node.position_y, agent, step, run_finished
            )
            entry["approval_role"] = node.approval_role
            entry["requires_approval"] = bool(node.requires_approval)
            entry["condition_expression"] = node.condition_expression
            if node.node_type == "start":
                entry["state"] = "succeeded" if self.run.started_at else "pending"
            nodes.append(entry)

        by_key = {node["node_key"]: node for node in nodes}
        edges: list[dict[str, Any]] = []
        for edge in self.flow.edges:
            source, target = by_key.get(edge.source_node_key), by_key.get(edge.target_node_key)
            if source is None or target is None:
                continue
            state = "pending"
            source_done = source["state"] in {"succeeded", "skipped"}
            target_reached = bool(target["step_id"]) or (target["node_type"] == "end" and run_ok)
            if source["node_type"] == "condition" and source["step_id"]:
                decision = bool((self.step_by_node[source["node_key"]].output or {}).get("result"))
                chosen = (edge.branch_label or "true").lower() == ("true" if decision else "false")
                state = "traversed" if chosen and (target_reached or not run_finished) else "not_taken"
                if chosen and target["state"] in {"running", "awaiting_approval"}:
                    state = "active"
            elif source_done and target_reached:
                state = "active" if target["state"] in {"running", "awaiting_approval"} else "traversed"
            elif source_done and run_finished and target["state"] == "not_reached":
                state = "not_taken"
            edges.append(
                {
                    "id": f"{edge.source_node_key}->{edge.target_node_key}",
                    "source": edge.source_node_key,
                    "target": edge.target_node_key,
                    "branch_label": edge.branch_label,
                    "state": state,
                    "handoff": self._handoff(source) if state in {"traversed", "active"} else None,
                }
            )

        # The end node is reached once any path into it was walked.
        for node in nodes:
            if node["node_type"] == "end":
                walked = any(edge["target"] == node["node_key"] and edge["state"] == "traversed" for edge in edges)
                node["state"] = ("succeeded" if run_ok else "failed") if walked and run_finished else (
                    "not_reached" if run_finished else "pending"
                )
        return nodes, edges

    def _node_dict(
        self,
        key: str,
        node_type: str,
        label: str,
        x: float,
        y: float,
        agent: Agent | None,
        step: AgentRunStep | None,
        run_finished: bool,
    ) -> dict[str, Any]:
        state = step.status if step else ("not_reached" if run_finished else "pending")
        if state == "pending" and step is not None and run_finished:
            state = "not_reached"
        output = (step.output or {}) if step else {}
        return {
            "node_key": key,
            "node_type": node_type,
            "label": label,
            "position_x": x,
            "position_y": y,
            "agent_key": agent.key if agent else None,
            "agent_name": agent.name if agent else None,
            "agent_icon": agent.icon if agent else None,
            "risk_level": agent.risk_level if agent else None,
            "state": state,
            "step_id": step.id if step else None,
            "sequence": step.sequence if step else None,
            "attempt": step.attempt if step else None,
            "started_at": _iso(step.started_at) if step else None,
            "finished_at": _iso(step.finished_at) if step else None,
            "duration_ms": step.duration_ms if step else 0,
            "confidence": step.confidence if step else None,
            "cost_usd": round(step.cost_usd, 5) if step else 0.0,
            "tokens": step.total_tokens if step else 0,
            "summary": output.get("summary") if node_type == "agent" else None,
            "decision": output.get("result") if node_type == "condition" and step else None,
            "error": step.error if step else None,
        }

    def _handoff(self, source: dict[str, Any]) -> dict[str, Any] | None:
        step = self.step_by_node.get(source["node_key"])
        if step is None or source["node_type"] not in {"agent", "condition", "approval"}:
            return None
        output = step.output or {}
        if source["node_type"] == "agent":
            return {"summary": _preview(output.get("summary") or "Result published.", 140), "highlights": _highlights(output)}
        if source["node_type"] == "condition":
            return {"summary": f"Decision: {'yes' if output.get('result') else 'no'}", "highlights": []}
        return {"summary": "Approved" if step.status == "succeeded" else "Rejected", "highlights": []}

    # ------------------------------------------------------------------
    # Participants
    # ------------------------------------------------------------------
    def _participants(self, nodes: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        participants: dict[str, dict[str, Any]] = {
            "orchestrator": {
                "key": "orchestrator",
                "name": "Orchestrator",
                "kind": "orchestrator",
                "icon": "Workflow",
                "subtitle": "Routes work and keeps the shared context",
                "color_index": None,
            }
        }
        agent_index = 0
        for node in nodes:
            if node["node_type"] == "agent":
                participants[node["node_key"]] = {
                    "key": node["node_key"],
                    "name": node["label"],
                    "kind": "agent",
                    "icon": node["agent_icon"] or "Bot",
                    "subtitle": node["agent_name"] or "Agent",
                    "color_index": agent_index,
                }
                agent_index += 1
            elif node["node_type"] == "condition":
                participants[node["node_key"]] = {
                    "key": node["node_key"],
                    "name": node["label"],
                    "kind": "decision",
                    "icon": "GitBranch",
                    "subtitle": "Decision",
                    "color_index": None,
                }
            elif node["node_type"] == "approval":
                participants[node["node_key"]] = {
                    "key": node["node_key"],
                    "name": node["label"],
                    "kind": "gate",
                    "icon": "UserCheck",
                    "subtitle": f"Approval gate · {ROLE_LABELS.get(node.get('approval_role') or 'qe_lead', 'QE Lead')}",
                    "color_index": None,
                }
        for approval in self.approvals:
            key = self._human_key(approval)
            participants.setdefault(
                key,
                {
                    "key": key,
                    "name": _person(approval.decided_by) if approval.decided_by else ROLE_LABELS.get(approval.required_role, approval.required_role),
                    "kind": "human",
                    "icon": "User",
                    "subtitle": ROLE_LABELS.get(approval.required_role, approval.required_role),
                    "color_index": None,
                },
            )
        return participants

    @staticmethod
    def _human_key(approval: ApprovalRequest) -> str:
        return f"person:{approval.decided_by}" if approval.decided_by else f"role:{approval.required_role}"

    # ------------------------------------------------------------------
    # Conversation
    # ------------------------------------------------------------------
    def _conversation(
        self,
        nodes: list[dict[str, Any]],
        edges: list[dict[str, Any]],
        participants: dict[str, dict[str, Any]],
    ) -> list[dict[str, Any]]:
        by_key = {node["node_key"]: node for node in nodes}
        messages: list[dict[str, Any]] = []
        counter = 0

        def recipients_for(node_key: str) -> tuple[list[str], list[str]]:
            outgoing = [edge for edge in edges if edge["source"] == node_key and edge["state"] in {"traversed", "active"}]
            to = []
            for edge in outgoing:
                target = by_key[edge["target"]]
                to.append("orchestrator" if target["node_type"] == "end" else target["node_key"])
            return (to or ["orchestrator"]), [edge["id"] for edge in outgoing]

        def add(at: datetime | None, kind: str, sender: str, to: list[str], text: str, **extra: Any) -> None:
            nonlocal counter
            counter += 1
            messages.append(
                {
                    "id": f"m{counter}",
                    "order": counter,
                    "at": _iso(at) or _iso(self.run.started_at) or _iso(self.run.created_at),
                    "kind": kind,
                    "from": sender,
                    "to": [key for key in dict.fromkeys(to) if key in participants],
                    "text": text,
                    "node_key": extra.get("node_key"),
                    "node_state": extra.get("node_state"),
                    "edges": extra.get("edges", []),
                    "data": extra.get("data", {}),
                }
            )

        # Kick-off: the orchestrator seeds the shared context and starts the first steps.
        inputs = {key: value for key, value in (self.run.inputs or {}).items() if not str(key).startswith("_")}
        start = next((node for node in nodes if node["node_type"] == "start"), None)
        first_to, first_edges = recipients_for(start["node_key"]) if start else ([], [])
        who = _person(self.run.triggered_by) if self.run.triggered_by and "@" in self.run.triggered_by else (self.run.triggered_by or "system")
        input_text = ", ".join(f"{key} = {_preview(value, 30)}" for key, value in list(inputs.items())[:4])
        add(
            self.run.started_at or self.run.created_at,
            "kickoff",
            "orchestrator",
            first_to,
            f"Run #{self.run.run_number} started by {who} ({self.run.trigger}). "
            + (f"Shared context seeded with {input_text}." if input_text else "No run inputs were needed."),
            node_key=start["node_key"] if start else None,
            node_state="succeeded",
            edges=first_edges,
            data={"inputs": {key: _preview(value, 40) for key, value in inputs.items()}},
        )

        retry_events = [event for event in self.events if event.event_type in {"step_retry", "step_failed"}]
        approvals_by_node: dict[str, list[ApprovalRequest]] = {}
        for approval in self.approvals:
            approvals_by_node.setdefault(approval.subject_ref or "", []).append(approval)

        published: list[str] = []  # agent node keys whose results are in the shared context
        for step in self.steps:
            node = by_key.get(step.node_key)
            if node is None:
                continue
            at_start = step.started_at or step.created_at

            for approval in approvals_by_node.get(step.node_key, []):
                human = self._human_key(approval)
                role_label = ROLE_LABELS.get(approval.required_role, approval.required_role)
                add(
                    approval.created_at,
                    "approval_request",
                    step.node_key,
                    [human],
                    f"{role_label} approval needed before this goes ahead. {approval.reason}",
                    node_key=step.node_key,
                    node_state="awaiting_approval",
                    data={"risk_level": approval.risk_level, "required_role": approval.required_role},
                )
                if approval.status in {"approved", "rejected"}:
                    to, edge_ids = (recipients_for(step.node_key) if step.node_type == "approval" else ([step.node_key], []))
                    verdict = "Approved" if approval.status == "approved" else "Rejected"
                    add(
                        approval.decided_at,
                        "approval_decision",
                        human,
                        to if approval.status == "approved" else ["orchestrator"],
                        f"{verdict}." + (f" {approval.decision_notes}" if approval.decision_notes else ""),
                        node_key=step.node_key,
                        node_state=("succeeded" if step.node_type == "approval" else "running")
                        if approval.status == "approved"
                        else "failed",
                        edges=edge_ids if approval.status == "approved" else [],
                        data={"decision": approval.status},
                    )

            if step.node_type == "agent":
                reads = self._explicit_reads(step.node_key, participants)
                sources = [participants[key]["name"] for key in published[-3:]]
                inputs_used = {key: _preview(value, 30) for key, value in (step.inputs or {}).items() if not str(key).startswith("_")}
                sentences = ["On it."]
                if inputs_used:
                    sentences.append(
                        "Using " + ", ".join(f"{key} = {value}" for key, value in list(inputs_used.items())[:3]) + "."
                    )
                if reads:
                    sentences.append(
                        "Reading "
                        + ", ".join(f"{read['path']} from {participants[read['from']]['name']}" for read in reads)
                        + "."
                    )
                elif sources:
                    sentences.append("Building on results from " + _join(sources) + ".")
                if step.started_at or step.status != "pending":
                    add(
                        at_start,
                        "acknowledge",
                        step.node_key,
                        [read["from"] for read in reads] or published[-1:] or ["orchestrator"],
                        " ".join(sentences),
                        node_key=step.node_key,
                        node_state="running",
                        data={"inputs": inputs_used, "reads": reads},
                    )

                for event in retry_events:
                    if event.content.startswith(f"'{step.label}' attempt") and event.event_type == "step_retry":
                        detail = event.content.split(": ", 1)[-1]
                        add(
                            event.created_at,
                            "retry",
                            step.node_key,
                            ["orchestrator"],
                            f"That attempt failed ({_preview(detail, 110)}). Trying again.",
                            node_key=step.node_key,
                            node_state="running",
                        )

                output = step.output or {}
                if step.status == "succeeded":
                    to, edge_ids = recipients_for(step.node_key)
                    tools = [f"{call.get('server')}.{call.get('tool')}" for call in (step.tool_calls or []) if isinstance(call, dict)]
                    add(
                        step.finished_at,
                        "handoff",
                        step.node_key,
                        to,
                        str(output.get("summary") or "Done; result published to the shared context."),
                        node_key=step.node_key,
                        node_state="succeeded",
                        edges=edge_ids,
                        data={
                            "confidence": step.confidence,
                            "highlights": _highlights(output),
                            "duration_ms": step.duration_ms,
                            "cost_usd": round(step.cost_usd, 5),
                            "tools": tools[:4],
                            "context_key": _alias(step.agent_key or step.node_key),
                        },
                    )
                    published.append(step.node_key)
                elif step.status in {"failed", "cancelled"} and step.error and not step.error.startswith("Rejected by"):
                    add(
                        step.finished_at or at_start,
                        "failure",
                        step.node_key,
                        ["orchestrator"],
                        f"I couldn't complete this: {_preview(step.error, 160)}",
                        node_key=step.node_key,
                        node_state="failed",
                    )

            elif step.node_type == "condition":
                output = step.output or {}
                decision = bool(output.get("result"))
                to, edge_ids = recipients_for(step.node_key)
                # The values read are listed with the message, so the text states only the outcome.
                reads = self._condition_reads(output.get("expression") or "", participants)
                add(
                    step.finished_at or step.created_at,
                    "decision",
                    step.node_key,
                    to,
                    f"Checked `{output.get('expression')}`: {'yes' if decision else 'no'}, so the flow continues to "
                    + ", ".join(participants[key]["name"] if key != "orchestrator" else "completion" for key in to)
                    + ".",
                    node_key=step.node_key,
                    node_state="succeeded" if step.status != "failed" else "failed",
                    edges=edge_ids,
                    data={"expression": output.get("expression"), "result": decision, "reads": reads},
                )

        if self.run.status in FINISHED:
            end = next((node for node in nodes if node["node_type"] == "end" and node["state"] != "not_reached"), None)
            into_end = [edge["id"] for edge in edges if end and edge["target"] == end["node_key"] and edge["state"] == "traversed"]
            add(
                self.run.finished_at,
                "complete",
                "orchestrator",
                list(published) or ["orchestrator"],
                self.run.summary or f"Run {self.run.status}.",
                node_key=end["node_key"] if end else None,
                node_state=end["state"] if end else None,
                edges=into_end,
                data={"status": self.run.status, "duration_ms": self.run.duration_ms, "cost_usd": round(self.run.total_cost_usd, 5)},
            )

        # Generation order follows the steps as the engine ran them, which is the
        # causal order; timestamps can tie or drift by milliseconds between rows.
        for index, message in enumerate(messages):
            message["index"] = index
        return messages

    def _alias_owner(self, participants: dict[str, dict[str, Any]]) -> dict[str, str]:
        owners: dict[str, str] = {}
        for step in self.steps:
            if step.node_type == "agent":
                owners[_alias(step.agent_key)] = step.node_key
                owners[_alias(step.node_key)] = step.node_key
        if self.flow is not None:
            for node in self.flow.nodes:
                agent = self.agents.get(node.agent_id) if node.agent_id else None
                if agent is not None:
                    owners.setdefault(_alias(agent.key), node.node_key)
                    owners.setdefault(_alias(node.node_key), node.node_key)
        return {alias: key for alias, key in owners.items() if key in participants}

    def _explicit_reads(self, node_key: str, participants: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
        node = next((item for item in (self.flow.nodes if self.flow else []) if item.node_key == node_key), None)
        if node is None:
            return []
        owners = self._alias_owner(participants)
        reads = []
        for value in (node.input_mapping or {}).values():
            if not isinstance(value, str):
                continue
            match = REFERENCE.fullmatch(value.strip())
            if match and _alias(match.group(1)) in owners and owners[_alias(match.group(1))] != node_key:
                reads.append({"from": owners[_alias(match.group(1))], "path": f"{match.group(1)}{match.group(2)}"})
        return reads

    def _condition_reads(self, expression: str, participants: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
        owners = self._alias_owner(participants)
        reads = []
        for match in REFERENCE.finditer(expression):
            alias = _alias(match.group(1))
            owner = owners.get(alias)
            if owner is None:
                continue
            step = self.step_by_node.get(owner)
            value = resolve_path({alias: (step.output or {}) if step else {}}, f"{alias}{match.group(2)}")
            if value is None:
                continue
            reads.append({"from": owner, "path": f"{match.group(1)}{match.group(2)}", "value": _preview(value, 30)})
        return reads

    # ------------------------------------------------------------------
    # Shared context
    # ------------------------------------------------------------------
    def _context(self, nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
        references: dict[str, set[str]] = {}
        if self.flow is not None:
            for node in self.flow.nodes:
                texts = [str(value) for value in (node.input_mapping or {}).values()] + [node.condition_expression or ""]
                for text in texts:
                    for token in re.findall(r"\$?([A-Za-z_][A-Za-z0-9_-]*)", text):
                        references.setdefault(_alias(token), set()).add(node.node_key)

        entries: list[dict[str, Any]] = []
        for key, value in (self.run.inputs or {}).items():
            if str(key).startswith("_"):
                continue
            entries.append(
                {
                    "key": key,
                    "kind": "input",
                    "written_by": "orchestrator",
                    "written_at": _iso(self.run.started_at or self.run.created_at),
                    "preview": _preview(value),
                    "used_by": sorted(references.get(_alias(key), set())),
                }
            )
        for step in self.steps:
            if step.node_type == "agent" and step.status == "succeeded":
                alias = _alias(step.agent_key or step.node_key)
                later = [
                    other.node_key
                    for other in self.steps
                    if other.sequence > step.sequence and other.node_type in {"agent", "condition"}
                ]
                explicit = references.get(alias, set())
                entries.append(
                    {
                        "key": alias,
                        "kind": "agent_result",
                        "written_by": step.node_key,
                        "written_at": _iso(step.finished_at),
                        "preview": _preview(step.output or {}),
                        "used_by": sorted(explicit & set(later)) or later[:1],
                        "available_to": later,
                        "fields": sorted((step.output or {}).get("outputs", {}).keys())[:8],
                    }
                )
            elif step.node_type == "condition" and step.status in {"succeeded", "failed"}:
                entries.append(
                    {
                        "key": f"decision:{step.node_key}",
                        "kind": "decision",
                        "written_by": step.node_key,
                        "written_at": _iso(step.finished_at or step.created_at),
                        "preview": "yes" if (step.output or {}).get("result") else "no",
                        "used_by": [],
                    }
                )
        for approval in self.approvals:
            if approval.status in {"approved", "rejected"}:
                entries.append(
                    {
                        "key": f"approval:{approval.subject_ref}",
                        "kind": "approval",
                        "written_by": self._human_key(approval),
                        "written_at": _iso(approval.decided_at),
                        "preview": approval.status,
                        "used_by": [approval.subject_ref] if approval.subject_ref else [],
                    }
                )
        entries.sort(key=lambda entry: entry["written_at"] or "")
        return entries


def run_collaboration(session: Session, run: AgentRun) -> dict[str, Any]:
    return RunCollaboration(session, run).build()
