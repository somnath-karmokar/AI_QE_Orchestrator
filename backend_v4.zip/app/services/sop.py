"""The standard operating procedure for a platform that consumes our agents and flows.

The organisation's SOPs (requirement_docs/Strands_Agent_SOP.docx) are written per
agent because each of those agents is its own deployed service: start app.py,
check /health, watch its logs. Here every agent and flow runs inside one
platform behind one API, so twenty-five copies of the same procedure would be
noise that drifts. There is one SOP, for the consumer, and anything specific to
one agent or flow -- who approves it, how long it takes -- is in that agent's
or flow's model card under `operations`.

Built from the same guardrail contract, scopes and dispositions the API itself
uses, so the procedure cannot promise what the platform does not do. The
Markdown copy in docs/integration/SOP.md is rendered from this and checked by
the test suite, so the two cannot disagree either.
"""

from __future__ import annotations

from typing import Any

from app.core.config import settings
from app.models.integration import SCOPES
from app.services.integration import DISPOSITIONS, guardrail_contract

SOP_VERSION = "1.0"
API = settings.api_prefix


def consumer_sop() -> dict[str, Any]:
    obligations = guardrail_contract([])["caller_obligations"]
    return {
        "title": f"SOP - Consuming {settings.app_name} agents and flows",
        "version": SOP_VERSION,
        "purpose": (
            "Call the platform's agents and flows from another system, know what each run did, "
            "and keep the evidence governance asks for."
        ),
        "audience": "Engineers integrating a pipeline, portal or agent platform, and the people who operate it.",
        "workflow": [
            {"step": "Authenticate", "detail": f"Send X-API-Key on every request. GET {API}/integration/me proves the key works without starting anything."},
            {"step": "Discover", "detail": f"GET {API}/integration/catalog lists what this key may call, with input schemas."},
            {"step": "Review", "detail": "Read the model card (owner, model, controls, observed performance) and golden dataset of each agent or flow before relying on it."},
            {"step": "Start", "detail": "POST to the invoke path with an X-Idempotency-Key. The response is a run with a run_id; the work continues in the background."},
            {"step": "Poll", "detail": f"GET {API}/integration/runs/{{run_id}} until is_terminal is true. Branch on disposition, never on status."},
            {"step": "Approvals", "detail": "waiting_for_approval is a normal pause: a named role must decide. Keep polling; do not retry."},
            {"step": "Result", "detail": "outputs is keyed by agent key; each value is that agent's result in the standard contract."},
            {"step": "Evidence", "detail": f"GET {API}/integration/runs/{{run_id}}/log for the governance log of that run (scope runs:logs)."},
        ],
        "dispositions": sorted(set(DISPOSITIONS.values())),
        "operations": [
            {"when": "Before go-live", "action": "Run each golden dataset's edge cases against your project to prove your integration handles refusals."},
            {"when": "Daily", "action": f"Call GET {API}/integration/me; alert if the key is expired or revoked, or if expires_at is near."},
            {"when": "Continuously", "action": f"Poll GET {API}/integration/audit-events from the last next_cursor into your SIEM. The cursor never repeats or skips an entry."},
            {"when": "Weekly", "action": f"Review GET {API}/integration/metrics: success rate, p95 duration, cost, model fallbacks and approval waits."},
            {"when": "On a model card change", "action": "Compare version, model and prompt versions with the last review; re-run the golden dataset."},
            {"when": "Every key rotation", "action": "Ask the operator to rotate; the old token stops working immediately, so deploy the new one first."},
        ],
        "incidents": [
            {"signal": "401", "meaning": "The key is missing, wrong, expired or revoked.", "action": "Check GET /integration/me with the key; ask the operator for a new one."},
            {"signal": "403", "meaning": "The key lacks the scope for this call; the error names it.", "action": "Ask the operator to grant that scope."},
            {"signal": "404", "meaning": "Not granted, or does not exist -- deliberately the same answer.", "action": "Check the catalog; ask for a grant."},
            {"signal": "200 with X-Idempotent-Replay: true", "meaning": "That idempotency key already started a run for this resource; you were given that run back, even if your inputs differ.", "action": "Use a new idempotency key for genuinely new work."},
            {"signal": "422", "meaning": "An input was refused; invalid_inputs says which and suggests a fix.", "action": "Correct the input. Never drop the field silently."},
            {"signal": "429", "meaning": "The key's rate limit was reached.", "action": "Back off; the limit is in GET /integration/me."},
            {"signal": "disposition failed", "meaning": "The run finished unsuccessfully.", "action": "Read the run log's activities for the failing step and error; start a new run once fixed."},
            {"signal": "disposition refused", "meaning": "A policy blocked the run.", "action": "Read the run log's policy decisions; raise it with the flow owner, not by retrying."},
        ],
        "escalation": "The platform operator who issued your API key. Quote the run_id and the X-Correlation-ID from the response.",
        "caller_obligations": obligations,
        "scopes": SCOPES,
    }


def render_markdown(sop: dict[str, Any]) -> str:
    """The same SOP as a document, for people who read documents."""
    lines = [
        f"# {sop['title']}",
        "",
        f"Version {sop['version']}. Generated from `app/services/sop.py`; served live at "
        f"`GET {API}/integration/sop`. Do not edit by hand.",
        "",
        "## Purpose",
        "",
        sop["purpose"],
        "",
        f"**Audience:** {sop['audience']}",
        "",
        "## Workflow",
        "",
    ]
    lines += [f"{i}. **{item['step']}** - {item['detail']}" for i, item in enumerate(sop["workflow"], start=1)]
    lines += ["", "Dispositions: " + ", ".join(f"`{d}`" for d in sop["dispositions"]) + ".", "", "## Operations", ""]
    lines += ["| When | Action |", "| --- | --- |"]
    lines += [f"| {item['when']} | {item['action']} |" for item in sop["operations"]]
    lines += ["", "## Incidents", "", "| Signal | Meaning | Action |", "| --- | --- | --- |"]
    lines += [f"| {item['signal']} | {item['meaning']} | {item['action']} |" for item in sop["incidents"]]
    lines += ["", "## Escalation", "", sop["escalation"], "", "## Caller obligations", ""]
    lines += [f"- {item}" for item in sop["caller_obligations"]]
    lines += ["", "## Scopes", "", "| Scope | Grants |", "| --- | --- |"]
    lines += [f"| `{scope}` | {meaning} |" for scope, meaning in sorted(sop["scopes"].items())]
    return "\n".join(lines) + "\n"
