"""Selecting impacted tests from a customer's own git repo of test packs.

The Wickes model's SELECT step (slide 2) reads: "tests where journey is
impacted, rank by defect probability, de-duplicate, enforce 100% P1 journey
coverage floor." This module does that against a *real* local git repository
of test files, not our platform's own seeded database rows -- the point of the
demo is to show the agent reasoning over a customer's actual artefacts (their
git repo, their Jira export) rather than only data we pre-loaded for it.

Each test file carries a small header block the way a real suite's metadata
would be discovered -- from tags, a manifest, or (as here) a structured
comment -- naming its journey, priority and topic tags:

    # journey: checkout-payment
    # priority: P1
    # tags: payment, apple-pay, pci, 3ds

`scan_repo` reads every test file once; `select_impacted` does the ranking,
de-duplication and P1-floor enforcement the pipeline promises.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

HEADER_PATTERN = re.compile(
    r"#\s*journey:\s*(?P<journey>[\w.-]+)\s*\n"
    r"#\s*priority:\s*(?P<priority>P[0-3])\s*\n"
    r"#\s*tags:\s*(?P<tags>[^\n]+)",
)
DEFECT_HISTORY_PATTERN = re.compile(r"#\s*defect_history:\s*(?P<count>\d+)\s+in\s+last\s+90d")


@dataclass(slots=True)
class TestFile:
    path: Path
    journey: str
    priority: str
    tags: tuple[str, ...]
    recent_defects: int
    title: str

    @property
    def relative(self) -> str:
        return str(self.path)


def scan_repo(repo_root: Path) -> list[TestFile]:
    """Every test file under `repo_root` that carries the header block.

    A file without one is skipped rather than guessed at -- an untagged test is
    exactly the gap a real onboarding would need to flag, not something to
    silently include or exclude.
    """
    files: list[TestFile] = []
    for path in sorted(repo_root.rglob("test_*.py")):
        text = path.read_text(encoding="utf-8")
        match = HEADER_PATTERN.search(text)
        if not match:
            continue
        defect_match = DEFECT_HISTORY_PATTERN.search(text)
        title_match = re.search(r'"""\s*\n?\s*(.+?)\s*\n', text)
        files.append(
            TestFile(
                path=path.relative_to(repo_root),
                journey=match.group("journey"),
                priority=match.group("priority"),
                tags=tuple(t.strip() for t in match.group("tags").split(",") if t.strip()),
                recent_defects=int(defect_match.group("count")) if defect_match else 0,
                title=title_match.group(1) if title_match else path.stem,
            )
        )
    return files


@dataclass(slots=True)
class SelectedTest:
    test: TestFile
    reason: str
    rank_score: float


def select_impacted(
    files: list[TestFile],
    *,
    journey: str,
    change_tags: tuple[str, ...],
    enforce_p1_floor: bool = True,
) -> list[SelectedTest]:
    """Tests genuinely relevant to the change, ranked, deduplicated, P1-complete.

    Two distinct mechanisms, both named on slide 2, and kept genuinely
    separate rather than collapsed into one "select the whole journey" pass:

      * **Relevance** -- a test is selected when it shares a tag with the
        change: a proxy for "the dependency graph/code diff touches what this
        test exercises". Living in the same journey folder is *not* on its
        own a reason to include a test here -- a journey can hold dozens of
        tests untouched by one specific change, and selecting all of them
        regardless would leave "rank by defect probability" and
        "de-duplicate" nothing to do, since everything would already be in.
      * **The P1 floor** -- applied afterwards, unconditionally: every P1
        test in the change's journey is added even when it shared no tag with
        the change, so a P1 test the tag heuristic missed is never silently
        dropped. This is the part of the sentence that is genuinely a floor:
        a guarantee layered on top of relevance, not another way of computing
        it -- and it is the only place a bare journey match matters.

    Being in the same journey *and* sharing a tag still ranks a test above one
    that only shares a tag, so the ordering reflects both signals even though
    membership alone decides nothing.
    """
    change_tag_set = {t.lower() for t in change_tags}
    selected: dict[str, SelectedTest] = {}

    for test in files:
        tag_overlap = {t.lower() for t in test.tags} & change_tag_set
        if not tag_overlap:
            continue
        journey_hit = test.journey == journey
        reason_parts = [f"tags overlap: {', '.join(sorted(tag_overlap))}"]
        if journey_hit:
            reason_parts.append(f"journey '{journey}' matches")
        rank = len(tag_overlap) * 2 + (1 if journey_hit else 0) + min(test.recent_defects, 5) * 0.5
        selected[test.relative] = SelectedTest(test=test, reason="; ".join(reason_parts), rank_score=rank)

    if enforce_p1_floor:
        # Every P1 test in the impacted journey, whether or not the tag
        # heuristic above happened to catch it -- "100% P1 journey coverage
        # floor" is a guarantee, not a best-effort.
        for test in files:
            if test.journey == journey and test.priority == "P1" and test.relative not in selected:
                selected[test.relative] = SelectedTest(
                    test=test, reason="P1 journey coverage floor (always included)", rank_score=1,
                )

    return sorted(selected.values(), key=lambda s: (-s.rank_score, s.test.relative))


def git_log_summary(repo_root: Path, *, limit: int = 5) -> list[str]:
    """The repo's own recent history, for the log narrative -- proof this is a
    real git repository, not a fixture pretending to be one."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), "log", f"-{limit}", "--pretty=format:%h %s"],
            capture_output=True, text=True, timeout=10, check=True,
        )
        return [line for line in result.stdout.splitlines() if line.strip()]
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return []
