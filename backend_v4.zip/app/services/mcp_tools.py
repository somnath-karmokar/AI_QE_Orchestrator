"""The platform's agents and flows, described as MCP tools.

One idea holds this together: an MCP tool call is the *same* operation as the
REST call, routed differently. Both resolve the same client, check the same
scopes, start the same run and return the same disposition. Duplicating the
logic would let the two drift, and drift here means one route enforcing a
guarantee the other does not.

Tool names are stable identifiers an agent may store, so they are derived from
the flow or agent key rather than from a display name somebody may rename.
"""

from __future__ import annotations

import json
import re
from typing import Any

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import NotFoundError, ValidationError
from app.core.logging import get_logger
from app.governance.policy_engine import AuditService
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.integration import IntegrationClient
from app.models.run import AgentRun
from app.services.flow_triggers import trigger_flow
from app.services.input_validation import describe_effective, validate_inputs
from app.services.run_logs import run_log
from app.services.integration import (
    claim_run,
    granted_agents,
    granted_flows,
    resolve_agent,
    run_envelope,
    started_by,
)
from app.services.run_service import RunService

logger = get_logger(__name__)

# The MCP revision this server implements.
PROTOCOL_VERSION = "2024-11-05"

SERVER_INFO = {
    "name": settings.app_name,
    "version": settings.app_version,
}

# Tool names must be stable and safe to store.
_UNSAFE = re.compile(r"[^a-z0-9_]+")


def tool_name(prefix: str, key: str) -> str:
    return f"{prefix}_{_UNSAFE.sub('_', key.lower()).strip('_')}"[:64]


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def build_tool_list(session: Session, client: IntegrationClient) -> list[dict[str, Any]]:
    """Every tool this key may call, and nothing else.

    A key that was not granted a flow does not see it here and cannot call it.
    The listing is the authorisation boundary, not a convenience filter.
    """
    tools: list[dict[str, Any]] = []

    if client.has_scope("flows:run"):
        for flow in granted_flows(session, client):
            tools.append(_flow_tool(flow))

    if client.has_scope("agents:run"):
        for agent in granted_agents(session, client):
            tools.append(_agent_tool(agent))

    if client.has_scope("runs:read"):
        tools.append(_get_run_tool())

    if client.has_scope("runs:logs"):
        tools.append(_get_run_log_tool())

    return tools


def _flow_tool(flow: AgentFlow) -> dict[str, Any]:
    variables = flow.variables or {}
    return {
        "name": tool_name("run_flow", flow.key),
        "title": flow.name,
        "description": (
            f"{flow.description or flow.name}\n\n"
            "Starts a flow and returns immediately with a run id and a disposition. "
            "The work is not finished when this returns: poll get_run until is_terminal "
            "is true. A disposition of waiting_for_approval means a named person must "
            "approve before it continues; that is not a failure and retrying will not "
            "clear it."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                name: {
                    "type": _json_type(value),
                    "description": f"Flow variable '{name}'.",
                    "default": value,
                }
                for name, value in variables.items()
            },
            # False, and enforced: an input the flow does not declare is
            # refused rather than ignored, because ignoring it would run on the
            # default and return a confident answer about the wrong thing.
            "additionalProperties": False,
        },
        "_meta": {
            "flow_id": flow.id,
            "kind": "flow",
            "requires_approval": any(
                (node.node_type or "") == "approval" for node in (flow.nodes or [])
            ),
        },
    }


def _agent_tool(agent: Agent) -> dict[str, Any]:
    schema = agent.input_schema or {"type": "object", "properties": {}}
    return {
        "name": tool_name("run_agent", agent.handler_key or agent.key),
        "title": agent.name,
        "description": (
            f"{agent.description or agent.name}\n\n"
            "Runs a single agent. Asynchronous: poll get_run until is_terminal is true."
            + (
                "\n\nThis agent requires human approval before its output is acted on."
                if agent.requires_approval
                else ""
            )
        ),
        "inputSchema": schema if schema.get("type") else {"type": "object", "properties": {}},
        "_meta": {
            "agent_key": agent.handler_key,
            "kind": "agent",
            "risk_level": agent.risk_level,
            "requires_approval": agent.requires_approval,
        },
    }


def _get_run_tool() -> dict[str, Any]:
    return {
        "name": "get_run",
        "title": "Get run status and result",
        "description": (
            "Reads a run this key started. Branch on `disposition`: pending, "
            "waiting_for_approval, succeeded, failed, cancelled or refused. "
            "`is_terminal` says whether it is worth polling again."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {"type": "string", "description": "The run id returned when work started."}
            },
            "required": ["run_id"],
        },
        "_meta": {"kind": "query"},
    }


def _get_run_log_tool() -> dict[str, Any]:
    return {
        "name": "get_run_log",
        "title": "Get the governance log of a run",
        "description": (
            "Reads the log of a run this key started: which agents ran, on which models, "
            "for how long and at what cost, under which policies and approvals. Secrets and "
            "personal data are masked; prompts and tool arguments are not included."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {"type": "string", "description": "The run id returned when work started."}
            },
            "required": ["run_id"],
        },
        "_meta": {"kind": "query"},
    }


def _json_type(value: Any) -> str:  # noqa: ANN401
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "string"


# ---------------------------------------------------------------------------
# Invocation
# ---------------------------------------------------------------------------


def call_tool(
    session: Session, client: IntegrationClient, name: str, arguments: dict[str, Any]
) -> dict[str, Any]:
    """Run a tool and return an MCP tool result.

    Every path here ends in the same `run_envelope` the REST surface returns, so
    an agent and a pipeline see identical facts about the same run.
    """
    # Only a tool this key was listed can be called. `get_run` used to be
    # answered before this check, so a key without `runs:read` could still read
    # runs over MCP while the REST route refused it -- the listing was a
    # convenience rather than the boundary its docstring says it is.
    for tool in build_tool_list(session, client):
        if tool["name"] != name:
            continue
        meta = tool["_meta"]
        if name == "get_run":
            return _tool_result(_get_run(session, client, arguments))
        if name == "get_run_log":
            return _log_result(run_log(session, _owned_run(session, client, arguments)))
        if meta["kind"] == "flow":
            return _tool_result(_run_flow(session, client, meta["flow_id"], arguments))
        if meta["kind"] == "agent":
            return _tool_result(_run_agent(session, client, meta["agent_key"], arguments))

    # Ungranted and non-existent are the same answer, as they are over REST, so
    # the tool list cannot be used to discover what a project contains.
    raise NotFoundError(NOT_AVAILABLE_MESSAGE)


NOT_AVAILABLE_MESSAGE = "No such tool is available to this API key."


def _tool_result(envelope: dict[str, Any]) -> dict[str, Any]:
    """An MCP tool result: readable text plus the structured payload.

    Both are returned deliberately. The text is what a model reads when it is
    deciding what to do next; the structured content is what code branches on.
    """
    return {
        "content": [{"type": "text", "text": _summarise(envelope)}],
        "structuredContent": envelope,
        "isError": False,
    }


def _summarise(envelope: dict[str, Any]) -> str:
    """The sentence a model should act on, not a dump of the payload."""
    disposition = envelope.get("disposition")
    run_id = envelope.get("run_id")

    if disposition == "waiting_for_approval":
        waiting = (envelope.get("guardrails") or {}).get("awaiting_approval") or []
        who = waiting[0].get("required_role", "a reviewer") if waiting else "a reviewer"
        what = waiting[0].get("title", "an action") if waiting else "an action"
        return (
            f"Run {run_id} is waiting for {who} to approve: {what}. "
            "This is not a failure and it has not stopped. Do not retry; a person decides next."
        )
    if disposition == "succeeded":
        return f"Run {run_id} succeeded. {envelope.get('summary') or ''}".strip()
    if disposition == "failed":
        return f"Run {run_id} failed: {envelope.get('error') or 'no reason recorded'}."
    if disposition == "refused":
        return f"Run {run_id} was refused by policy: {envelope.get('error') or 'see the audit log'}."
    if disposition == "cancelled":
        return f"Run {run_id} was cancelled."
    return (
        f"Run {run_id} is {disposition}. Poll get_run with this id until is_terminal is true."
    )


def _run_flow(
    session: Session, client: IntegrationClient, flow_id: str, arguments: dict[str, Any]
) -> dict[str, Any]:
    flow = session.get(AgentFlow, flow_id)
    if flow is None or flow.is_deleted:
        raise NotFoundError(NOT_AVAILABLE_MESSAGE)

    # The same check the REST route applies. An agent that mistypes an
    # argument must be told, not quietly given a run on the defaults.
    checked = validate_inputs(
        _flow_tool(flow)["inputSchema"], arguments, defaults=flow.variables or {}
    )
    if not checked.ok:
        raise ValidationError(
            "These arguments do not match what this tool accepts.",
            details={**checked.to_details(), "accepts": sorted(flow.variables or {})},
        )

    run = trigger_flow(
        session,
        flow,
        trigger="api",
        triggered_by=f"integration:{client.name}",
        inputs=arguments,
        title=f"MCP: {flow.name}",
    )
    claim_run(run, client)
    _audit(session, client, "integration.mcp_flow_started", run.id, flow.name, arguments)
    envelope = run_envelope(session, run)
    envelope["inputs_applied"] = describe_effective(checked.effective, arguments)
    return envelope


def _run_agent(
    session: Session, client: IntegrationClient, agent_key: str, arguments: dict[str, Any]
) -> dict[str, Any]:
    agent = resolve_agent(session, client, agent_key)
    if agent is None:
        raise NotFoundError(NOT_AVAILABLE_MESSAGE)

    checked = validate_inputs(agent.input_schema, arguments)
    if not checked.ok:
        raise ValidationError(
            "These arguments do not match what this tool accepts.",
            details=checked.to_details(),
        )

    service = RunService(session)
    run = service.start_agent_run(
        agent_id=agent.id,
        project_id=client.project_id,
        inputs=arguments,
        triggered_by=f"integration:{client.name}",
        kind="agent",
    )
    # Creating the run is not running it; see the REST endpoint.
    service.dispatch(run)
    claim_run(run, client)
    _audit(session, client, "integration.mcp_agent_invoked", run.id, agent.name, arguments)
    envelope = run_envelope(session, run)
    envelope["inputs_applied"] = describe_effective(checked.effective, arguments)
    return envelope


def _owned_run(session: Session, client: IntegrationClient, arguments: dict[str, Any]) -> AgentRun:
    run_id = arguments.get("run_id")
    if not run_id:
        raise ValidationError("A run_id is required.")

    run = session.get(AgentRun, run_id)
    # A key reads its own runs and no others -- the same rule the REST route
    # applies, for the same reason.
    if (
        run is None
        or run.project_id != client.project_id
        or not started_by(run, client)
    ):
        raise NotFoundError("No such run is available to this API key.")
    return run


def _get_run(
    session: Session, client: IntegrationClient, arguments: dict[str, Any]
) -> dict[str, Any]:
    return run_envelope(session, _owned_run(session, client, arguments))


def _log_result(log: dict[str, Any]) -> dict[str, Any]:
    """A run log as a tool result: one sentence a model can act on, plus the log."""
    run = log["run"]
    agents = [a["agent"]["key"] for a in log["activities"] if a.get("agent")]
    models = sorted({f"{m['provider']}/{m['model']}" for m in log["usage"]["by_model"]})
    text = (
        f"Run {run['run_id']} is {run['disposition']}. {len(agents)} agent step(s)"
        + (f" ({', '.join(dict.fromkeys(agents))})" if agents else "")
        + (f" on {', '.join(models)}" if models else "")
        + f"; {log['usage']['total_tokens']} tokens, cost {log['usage']['total_cost_usd']} USD; "
        + f"{len(log['approvals'])} approval(s), {len(log['audit'])} audit entr(ies)."
    )
    return {"content": [{"type": "text", "text": text}], "structuredContent": log, "isError": False}


def _audit(
    session: Session,
    client: IntegrationClient,
    action: str,
    run_id: str,
    label: str,
    arguments: dict[str, Any],
) -> None:
    AuditService(session).record(
        action=action,
        entity_type="agent_run",
        entity_id=run_id,
        entity_label=label,
        actor=f"integration:{client.name}",
        actor_type="system",
        project_id=client.project_id,
        input_summary={
            "transport": "mcp",
            "client_platform": client.platform,
            # Keys only: argument values may carry customer data.
            "arguments": sorted(arguments),
        },
    )


def tools_as_openai_functions(session: Session, client: IntegrationClient) -> list[dict[str, Any]]:
    """The same tools in OpenAI function-calling shape.

    Offered because not every caller speaks MCP. A platform built on OpenAI or
    Bedrock tool-use can register these directly, and the underlying call is the
    same one with the same guarantees.
    """
    return [
        {
            "type": "function",
            "function": {
                "name": tool["name"],
                "description": tool["description"],
                "parameters": tool["inputSchema"],
            },
        }
        for tool in build_tool_list(session, client)
    ]


def tools_as_json(session: Session, client: IntegrationClient) -> str:
    return json.dumps(build_tool_list(session, client), indent=2)
