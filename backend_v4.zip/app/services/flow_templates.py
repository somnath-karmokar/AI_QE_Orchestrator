"""The flow template gallery and creating flows from templates.

Templates are proven flow definitions -- the same ones the demo project ships
with, plus lighter starters -- presented with the outcome they deliver, their
steps, their governance gates and an estimated cost per run, so choosing one is
a business decision rather than a graph-reading exercise.
"""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import NotFoundError
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.project import Environment, Project
from app.orchestration.materialize import materialize_flow
from app.seed.flows import FLOW_DEFINITIONS, _node

# Starters that are not seeded as project flows but are useful first flows.
EXTRA_TEMPLATES: list[dict[str, Any]] = [
    {
        "key": "story-readiness-gate",
        "name": "Story Readiness Gate",
        "category": "Requirements",
        "description": (
            "Scores a story for test readiness and only lets well-formed stories through to scenario design; "
            "weak stories go to the business for clarification."
        ),
        "tags": ["starter", "requirements", "governance"],
        "variables": {"requirement_key": "PAY-201", "completeness_threshold": 80},
        "cost_budget_usd": 2.0,
        "nodes": [
            _node("start", "start", "Story Submitted", 0),
            _node(
                "completeness",
                "agent",
                "User Story Completeness",
                1,
                agent_key="user-story-completeness",
                input_mapping={"requirement_key": "$requirement_key", "threshold": "$completeness_threshold"},
            ),
            _node(
                "ready",
                "condition",
                "Ready for test design?",
                2,
                condition_expression="user_story_completeness.outputs.completeness_score >= completeness_threshold",
            ),
            _node(
                "clarify",
                "approval",
                "Business Clarification",
                3,
                column=1,
                approval_role="business_user",
                config={"reason": "The story is below the readiness threshold and needs clarification."},
            ),
            _node(
                "scenarios",
                "agent",
                "Generate Test Scenarios",
                3,
                agent_key="test-scenario-generator",
                input_mapping={"requirement_key": "$requirement_key"},
            ),
            _node("end", "end", "Ready for Design", 4),
        ],
        "edges": [
            ("start", "completeness", None),
            ("completeness", "ready", None),
            ("ready", "scenarios", "true"),
            ("ready", "clarify", "false"),
            ("clarify", "scenarios", None),
            ("scenarios", "end", None),
        ],
    },
]

# Presentation for the gallery: an icon name the web app maps to its icon set,
# and the outcome in one sentence.
TEMPLATE_PRESENTATION: dict[str, dict[str, str]] = {
    "requirement-to-automated-test": {"icon": "Sparkles", "outcome": "Story in, Playwright automation out"},
    "failure-to-rca-defect": {"icon": "Microscope", "outcome": "Failures diagnosed and defects drafted"},
    "regression-intelligence": {"icon": "TrendingDown", "outcome": "Run only the tests a change needs"},
    "release-readiness": {"icon": "Gauge", "outcome": "A go / no-go readiness picture"},
    "uat-preparation": {"icon": "Users", "outcome": "Business-ready UAT scripts and data"},
    "accessibility-compliance": {"icon": "Accessibility", "outcome": "WCAG 2.2 AA findings and CI checks"},
    "story-readiness-gate": {"icon": "ShieldCheck", "outcome": "Only ready stories reach test design"},
}


def _definitions() -> list[dict[str, Any]]:
    return [*FLOW_DEFINITIONS, *EXTRA_TEMPLATES]


def get_definition(key: str) -> dict[str, Any]:
    for definition in _definitions():
        if definition["key"] == key:
            return definition
    raise NotFoundError(f"Template '{key}' was not found.")


def _agents_by_key(session: Session, project: Project) -> dict[str, Agent]:
    rows = session.execute(
        select(Agent).where(
            Agent.is_deleted.is_(False),
            (Agent.project_id.is_(None)) | (Agent.project_id == project.id),
        )
    ).scalars()
    return {agent.key: agent for agent in rows}


def list_templates(session: Session, project: Project) -> list[dict[str, Any]]:
    agents = _agents_by_key(session, project)
    templates = []
    for definition in _definitions():
        steps = []
        estimated_cost = 0.0
        for node in definition["nodes"]:
            if node["node_type"] in {"start", "end"}:
                continue
            agent = agents.get(node.get("agent_key", ""))
            if agent is not None:
                estimated_cost += agent.avg_cost_usd or 0.0
            steps.append(
                {
                    "label": node["label"],
                    "node_type": node["node_type"],
                    "agent_key": node.get("agent_key"),
                    "agent_name": agent.name if agent else None,
                    "risk_level": agent.risk_level if agent else None,
                    "requires_approval": bool(node.get("requires_approval")),
                }
            )
        presentation = TEMPLATE_PRESENTATION.get(definition["key"], {})
        templates.append(
            {
                "key": definition["key"],
                "name": definition["name"],
                "description": definition["description"],
                "category": definition["category"],
                "icon": presentation.get("icon", "Workflow"),
                "outcome": presentation.get("outcome", definition["description"]),
                "tags": definition.get("tags", []),
                "variables": definition.get("variables", {}),
                "steps": steps,
                "agent_count": sum(1 for step in steps if step["node_type"] == "agent"),
                "approval_gates": sum(
                    1 for step in steps if step["node_type"] == "approval" or step["requires_approval"]
                ),
                "conditions": sum(1 for step in steps if step["node_type"] == "condition"),
                "estimated_cost_per_run_usd": round(estimated_cost, 4),
                "cost_budget_usd": definition.get("cost_budget_usd", 5.0),
            }
        )
    return templates


def unique_flow_key(session: Session, project: Project, name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:60] or "flow"
    taken = set(
        session.execute(select(AgentFlow.key).where(AgentFlow.project_id == project.id)).scalars()
    )
    if base not in taken:
        return base
    suffix = 2
    while f"{base}-{suffix}" in taken:
        suffix += 1
    return f"{base}-{suffix}"


def default_environment_id(session: Session, project: Project) -> str | None:
    environment = session.execute(
        select(Environment).where(Environment.project_id == project.id, Environment.key == "sit")
    ).scalar_one_or_none()
    return environment.id if environment else None


def create_from_template(
    session: Session,
    project: Project,
    template_key: str,
    *,
    name: str | None,
    created_by: str,
    description: str | None = None,
    variables: dict[str, Any] | None = None,
    cost_budget_usd: float | None = None,
) -> AgentFlow:
    definition = dict(get_definition(template_key))
    flow_name = (name or definition["name"]).strip()
    if description:
        definition["description"] = description
    if variables:
        definition["variables"] = {**definition.get("variables", {}), **variables}
    if cost_budget_usd is not None:
        definition["cost_budget_usd"] = cost_budget_usd
    definition["tags"] = [tag for tag in definition.get("tags", []) if tag != "demo"] + ["from-template"]

    return materialize_flow(
        session,
        project,
        definition,
        _agents_by_key(session, project),
        key=unique_flow_key(session, project, flow_name),
        name=flow_name,
        status="draft",
        version="0.1.0",
        created_by=created_by,
        owner=created_by,
        default_environment_id=default_environment_id(session, project),
        change_summary=f"Created from the '{definition['name']}' template.",
    )
