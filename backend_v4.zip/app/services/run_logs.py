"""What a calling platform may see of its own runs, for observability and governance.

The run envelope (`integration.run_envelope`) is deliberately flat and leaves the
step graph out, so the graph can change without breaking a caller that only
polls. Governance needs more than that: which agent ran, on which model, for how
long, at what cost, under which policy, and who had to approve it. This module is
that record -- a separate contract with its own version (`LOG_SCHEMA_VERSION`),
*projected* from the internal records rather than exposing them, so internal
fields can change while the shape a caller parses does not.

Three views, one rule about ownership:

  * `run_log`      -- one run, in full: activities, timeline, approvals, audit, usage;
  * `audit_feed`   -- every audit entry across this key's runs, in order, with a
                      cursor, so a SIEM can poll "everything since last time";
  * `usage_metrics`-- aggregates over a window: outcomes, latency, cost, models.

All three cover **runs this key started** and nothing else -- the same rule
`GET /integration/runs/{id}` applies (`owns_run`).

What is deliberately left out:
  * prompts and model responses -- the platform's instructions, and whatever the
    model read;
  * tool call arguments -- whatever the agent looked up;
  * step inputs and outputs -- the run's result is already in the envelope;
  * the identity of platform users who approved or acted -- personal data of
    people a third party has no need to identify. The log says a decision was
    made, what it was, which role was required, and when.

What is included is masked: secrets by key name (`redact_secrets`) and personal
data in free text (`mask_pii`). `LOG_REDACTION` states both in every response,
so a governance reviewer can see the policy rather than infer it.
"""

from __future__ import annotations

import base64
import statistics
from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import ValidationError
from app.core.security import mask_pii, redact_secrets
from app.models.agent import Agent
from app.models.governance import ApprovalRequest, AuditLog
from app.models.integration import IntegrationClient
from app.models.llm import LLMUsage
from app.models.run import AgentMessage, AgentRun
from app.services.integration import TERMINAL, disposition, owns_run

LOG_SCHEMA_VERSION = "1.0"

# The longest free-text field a log carries. Summaries and errors are for a
# person reading a log, not a transcript.
TEXT_LIMIT = 600

LOG_REDACTION: dict[str, Any] = {
    "masked": {
        "secrets": "values under keys naming a secret (api_key, password, token, ...)",
        "personal_data": "email addresses, card numbers, IBANs and SSNs in free text",
    },
    "omitted": [
        "prompts and model responses",
        "tool call arguments",
        "step inputs and outputs (the run's result is in the run envelope)",
        "identity of platform users who approved or acted (the role and decision are kept)",
    ],
}


# ---------------------------------------------------------------------------
# Cleaning
# ---------------------------------------------------------------------------


def _text(value: Any, limit: int = TEXT_LIMIT) -> str | None:  # noqa: ANN401
    if value is None:
        return None
    text = mask_pii(str(value))
    return text if len(text) <= limit else text[:limit] + " [truncated]"


def _clean(value: Any) -> Any:  # noqa: ANN401
    """Secrets out by key name, then personal data out of every string."""
    value = redact_secrets(value)
    if isinstance(value, dict):
        return {key: _clean(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_clean(item) for item in value]
    if isinstance(value, str):
        return _text(value)
    return value


def _iso(moment: datetime | None) -> str | None:
    return moment.isoformat() if moment else None


def _aware(moment: datetime | None) -> datetime | None:
    if moment is not None and moment.tzinfo is None:
        return moment.replace(tzinfo=UTC)
    return moment


# ---------------------------------------------------------------------------
# One run
# ---------------------------------------------------------------------------


def _run_audit_condition(run_ids: Any):  # noqa: ANN001, ANN202, ANN401
    """Audit rows belonging to these runs.

    By `run_id`, and by `entity_id` for rows written before the integration
    routes recorded the run id -- otherwise a key's older history would lose
    the very entries that say it started those runs.
    """
    return or_(
        AuditLog.run_id.in_(run_ids),
        and_(AuditLog.entity_type == "agent_run", AuditLog.entity_id.in_(run_ids)),
    )


def audit_entry(entry: AuditLog) -> dict[str, Any]:
    """One audit row as a caller may see it."""
    return {
        "event_id": entry.id,
        "at": _iso(entry.created_at),
        "run_id": entry.run_id or (entry.entity_id if entry.entity_type == "agent_run" else None),
        "action": entry.action,
        "actor_type": entry.actor_type,
        # A platform user is a person; say that one acted, not who.
        "actor": "a platform user" if entry.actor_type == "user" else entry.actor,
        "outcome": entry.outcome,
        "severity": entry.severity,
        "entity_type": entry.entity_type,
        "entity_label": _text(entry.entity_label, 200),
        "reason": _text(entry.reason),
        "model_used": entry.model_used,
        "tool_used": entry.tool_used,
        "confidence": entry.confidence,
        "policy_result": _clean(entry.policy_result or {}),
        "input_summary": _clean(entry.input_summary or {}),
        "output_summary": _clean(entry.output_summary or {}),
    }


def _activity(step: Any) -> dict[str, Any]:  # noqa: ANN401
    """One step of a run, projected into the stable log shape."""
    decision = step.policy_decision or {}
    return {
        "sequence": step.sequence,
        "node_key": step.node_key,
        "kind": step.node_type,
        "label": step.label,
        "agent": {"key": step.agent_key, "version": step.agent_version} if step.agent_key else None,
        "status": step.status,
        "attempt": step.attempt,
        "started_at": _iso(step.started_at),
        "finished_at": _iso(step.finished_at),
        "duration_ms": step.duration_ms,
        "confidence": step.confidence,
        "model": (
            {"provider": step.provider, "model": step.model, "deployment": step.deployment}
            if step.provider
            else None
        ),
        "usage": {
            "prompt_tokens": step.prompt_tokens,
            "completion_tokens": step.completion_tokens,
            "total_tokens": step.total_tokens,
            "cost_usd": round(step.cost_usd or 0.0, 6),
        },
        # Which tools, and whether they worked -- never with what arguments.
        "tools": [
            {
                "server": call.get("server"),
                "tool": call.get("tool"),
                "success": call.get("success"),
                "duration_ms": call.get("duration_ms"),
                "error": _text(call.get("error"), 300),
            }
            for call in (step.tool_calls or [])
            if isinstance(call, dict)
        ],
        "policy": (
            {
                "effect": decision.get("effect"),
                "requires_approval": decision.get("requires_approval"),
                "policies": [
                    policy.get("key")
                    for policy in decision.get("matched_policies") or []
                    if isinstance(policy, dict)
                ],
            }
            if decision
            else None
        ),
        "evidence_count": len(step.evidence or []),
        "error": _text(step.error),
    }


def _usage_by_model(rows: list[LLMUsage]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[LLMUsage]] = defaultdict(list)
    for row in rows:
        grouped[(row.provider, row.model)].append(row)
    return [
        {
            "provider": provider,
            "model": model,
            "calls": len(items),
            "failed_calls": sum(1 for item in items if not item.success),
            "fallback_calls": sum(1 for item in items if item.fallback_used),
            "prompt_tokens": sum(item.prompt_tokens or 0 for item in items),
            "completion_tokens": sum(item.completion_tokens or 0 for item in items),
            "cost_usd": round(sum(item.estimated_cost_usd or 0.0 for item in items), 6),
            "avg_latency_ms": int(statistics.fmean(item.latency_ms or 0 for item in items)),
        }
        for (provider, model), items in sorted(grouped.items())
    ]


def run_log(session: Session, run: AgentRun) -> dict[str, Any]:
    """Everything a caller may know about one of its runs."""
    agent_key = None
    if run.agent_id:
        agent = session.get(Agent, run.agent_id)
        agent_key = agent.key if agent else None

    messages = list(
        session.execute(
            select(AgentMessage).where(AgentMessage.run_id == run.id).order_by(AgentMessage.sequence)
        ).scalars()
    )
    approvals = list(
        session.execute(
            select(ApprovalRequest)
            .where(ApprovalRequest.run_id == run.id)
            .order_by(ApprovalRequest.created_at)
        ).scalars()
    )
    audit = list(
        session.execute(
            select(AuditLog)
            .where(AuditLog.project_id == run.project_id, _run_audit_condition([run.id]))
            .order_by(AuditLog.created_at, AuditLog.id)
        ).scalars()
    )
    usage_rows = list(session.execute(select(LLMUsage).where(LLMUsage.run_id == run.id)).scalars())

    state = disposition(run.status)
    if state == "pending" and any(a.status == "pending" for a in approvals):
        state = "waiting_for_approval"

    return {
        "schema_version": LOG_SCHEMA_VERSION,
        "run": {
            "run_id": run.id,
            "run_number": run.run_number,
            "kind": run.kind,
            "title": run.title,
            "status": run.status,
            "disposition": state,
            "is_terminal": state in TERMINAL,
            "flow_id": run.flow_id,
            "flow_version": run.flow_version,
            "agent_key": agent_key,
            "correlation_id": run.correlation_id,
            "idempotency_key": run.idempotency_key,
            "created_at": _iso(run.created_at),
            "started_at": _iso(run.started_at),
            "finished_at": _iso(run.finished_at),
            "duration_ms": run.duration_ms,
            "inputs": _clean(run.inputs or {}),
            "summary": _text(run.summary),
            "error": _text(run.error),
        },
        "activities": [_activity(step) for step in sorted(run.steps, key=lambda s: (s.sequence, s.attempt or 0))],
        "timeline": [
            {
                "sequence": message.sequence,
                "at": _iso(message.created_at),
                "type": message.event_type,
                "message": _text(message.content),
            }
            for message in messages
        ],
        "approvals": [
            {
                "approval_id": approval.id,
                "title": _text(approval.title, 200),
                "reason": _text(approval.reason),
                "risk_level": approval.risk_level,
                "required_role": approval.required_role,
                "status": approval.status,
                "requested_at": _iso(approval.created_at),
                "expires_at": _iso(approval.expires_at),
                "decided_at": _iso(approval.decided_at),
                "decision_notes": _text(approval.decision_notes),
            }
            for approval in approvals
        ],
        "audit": [audit_entry(entry) for entry in audit],
        "usage": {
            "total_tokens": run.total_tokens,
            "total_cost_usd": round(run.total_cost_usd or 0.0, 6),
            "by_model": _usage_by_model(usage_rows),
        },
        "redaction": LOG_REDACTION,
        "links": {
            "run": f"{settings.api_prefix}/integration/runs/{run.id}",
            "self": f"{settings.api_prefix}/integration/runs/{run.id}/log",
        },
    }


# ---------------------------------------------------------------------------
# The audit feed
# ---------------------------------------------------------------------------


def _encode_cursor(entry: AuditLog) -> str:
    raw = f"{_aware(entry.created_at).isoformat()}|{entry.id}"
    return base64.urlsafe_b64encode(raw.encode()).decode().rstrip("=")


def _decode_cursor(cursor: str) -> tuple[datetime, str]:
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        moment, entry_id = base64.urlsafe_b64decode(padded.encode()).decode().split("|", 1)
        return _aware(datetime.fromisoformat(moment)), entry_id
    except (ValueError, UnicodeDecodeError):
        raise ValidationError(
            "That cursor is not one this API issued. Use the next_cursor from a previous "
            "response, or omit it to start from the beginning."
        ) from None


def audit_feed(
    session: Session,
    client: IntegrationClient,
    *,
    since: datetime | None = None,
    cursor: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """Every audit entry for this key's runs, oldest first, resumable.

    Ordered by (time, id) with the cursor naming the last entry returned, so
    polling from a cursor neither repeats an entry nor skips one written in the
    same instant -- the two ways a timestamp-only cursor loses governance
    records.
    """
    own_runs = select(AgentRun.id).where(
        AgentRun.project_id == client.project_id, owns_run(client)
    ).scalar_subquery()
    statement = select(AuditLog).where(
        AuditLog.project_id == client.project_id, _run_audit_condition(own_runs)
    )
    if since is not None:
        statement = statement.where(AuditLog.created_at >= _aware(since))
    if cursor:
        after_at, after_id = _decode_cursor(cursor)
        statement = statement.where(
            or_(
                AuditLog.created_at > after_at,
                and_(AuditLog.created_at == after_at, AuditLog.id > after_id),
            )
        )
    rows = list(
        session.execute(
            statement.order_by(AuditLog.created_at, AuditLog.id).limit(limit)
        ).scalars()
    )
    return {
        "schema_version": LOG_SCHEMA_VERSION,
        "items": [audit_entry(entry) for entry in rows],
        # Always returned, so a poller that caught up keeps its place; an empty
        # page hands back the cursor it was given.
        "next_cursor": _encode_cursor(rows[-1]) if rows else cursor,
        "has_more": len(rows) == limit,
        "redaction": LOG_REDACTION,
    }


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


def _percentile(values: list[int], fraction: float) -> int | None:
    """Nearest-rank percentile; None when there is nothing to rank."""
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int(round(fraction * len(ordered) + 0.5)) - 1))
    return ordered[index]


def usage_metrics(session: Session, client: IntegrationClient, *, days: int = 30) -> dict[str, Any]:
    """Outcomes, latency, cost and model use across this key's runs in a window."""
    until = datetime.now(UTC)
    since = until - timedelta(days=days)
    runs = list(
        session.execute(
            select(AgentRun).where(
                AgentRun.project_id == client.project_id,
                owns_run(client),
                AgentRun.created_at >= since,
            )
        ).scalars()
    )
    run_ids = [run.id for run in runs]

    by_state = Counter(disposition(run.status) for run in runs)
    finished = [run for run in runs if disposition(run.status) in TERMINAL]
    durations = [run.duration_ms for run in finished if run.duration_ms]

    agent_keys = {
        agent.id: agent.key
        for agent in session.execute(
            select(Agent).where(Agent.id.in_({run.agent_id for run in runs if run.agent_id}))
        ).scalars()
    } if runs else {}

    per_resource: dict[tuple[str, str], list[AgentRun]] = defaultdict(list)
    for run in runs:
        if run.flow_id:
            per_resource[("flow", run.flow_id)].append(run)
        elif run.agent_id:
            per_resource[("agent", agent_keys.get(run.agent_id, run.agent_id))].append(run)

    usage_rows = (
        list(session.execute(select(LLMUsage).where(LLMUsage.run_id.in_(run_ids))).scalars())
        if run_ids
        else []
    )
    approvals = (
        list(session.execute(select(ApprovalRequest).where(ApprovalRequest.run_id.in_(run_ids))).scalars())
        if run_ids
        else []
    )
    waits = [
        int((_aware(a.decided_at) - _aware(a.created_at)).total_seconds())
        for a in approvals
        if a.decided_at and a.created_at
    ]
    failures = Counter(
        _text(run.error, 160) for run in runs if disposition(run.status) == "failed" and run.error
    )

    return {
        "schema_version": LOG_SCHEMA_VERSION,
        "window": {"days": days, "from": since.isoformat(), "to": until.isoformat()},
        "runs": {
            "total": len(runs),
            "by_disposition": dict(sorted(by_state.items())),
            # Of the runs that finished: a pending run has not failed yet.
            "success_rate": round(by_state["succeeded"] / len(finished), 4) if finished else None,
            "duration_ms": {
                "p50": _percentile(durations, 0.5),
                "p95": _percentile(durations, 0.95),
                "max": max(durations) if durations else None,
                "sample": len(durations),
            },
            "total_tokens": sum(run.total_tokens or 0 for run in runs),
            "total_cost_usd": round(sum(run.total_cost_usd or 0.0 for run in runs), 6),
        },
        "by_resource": [
            {
                "kind": kind,
                "id": identifier,
                "runs": len(items),
                "succeeded": sum(1 for r in items if disposition(r.status) == "succeeded"),
                "failed": sum(1 for r in items if disposition(r.status) == "failed"),
                "p50_duration_ms": _percentile([r.duration_ms for r in items if r.duration_ms], 0.5),
                "cost_usd": round(sum(r.total_cost_usd or 0.0 for r in items), 6),
            }
            for (kind, identifier), items in sorted(per_resource.items())
        ],
        "by_model": _usage_by_model(usage_rows),
        "approvals": {
            "requested": len(approvals),
            "pending": sum(1 for a in approvals if a.status == "pending"),
            "approved": sum(1 for a in approvals if a.status == "approved"),
            "rejected": sum(1 for a in approvals if a.status == "rejected"),
            "median_wait_seconds": int(statistics.median(waits)) if waits else None,
        },
        "top_failures": [
            {"error": error, "runs": count} for error, count in failures.most_common(5)
        ],
    }
