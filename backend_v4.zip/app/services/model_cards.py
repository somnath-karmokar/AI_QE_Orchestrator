"""Model cards for agents and flows, generated from what is actually deployed.

A model card is the document a consuming team reads before it trusts an agent:
who owns it, which model it runs on, what it accepts and returns, what controls
apply, how it has actually performed. The field names follow the model cards
already in use in this organisation (see requirement_docs/model-card.json), so
a reviewer comparing two cards finds the same things in the same places.

Every card is generated on request from the live definition. A card written by
hand is correct on the day it is written and drifts from then on; this one
cannot describe a model, a schema or a budget the agent no longer has.

Three rules keep it honest, each learned the hard way somewhere else:

  * **Performance is observed, never asserted.** It is computed from recorded
    runs in the project. The marketplace figures on the agent row are seeded
    demo statistics and are deliberately not used. Too few runs to say anything
    is reported as exactly that.
  * **A control is listed only if code enforces it**, with the file that does.
    Where something a reviewer would expect is absent -- a circuit breaker -- the
    card says so rather than leaving the reader to assume it.
  * **Prompts are identified, not published.** The card names each prompt
    template and its version, so a change to what an agent is told is visible
    to governance, without handing a caller the instructions to craft input
    against.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.agents.base import AGENT_OUTPUT_SCHEMA
from app.ai.prompts import templates
from app.ai.router.model_router import ModelRouter, RoutingRequest
from app.core.config import settings
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import GovernancePolicy
from app.models.project import Project
from app.models.run import AgentRun, AgentRunStep
from app.services.integration import (
    TERMINAL,
    _flow_descriptor,
    disposition,
    guardrail_contract,
)
from app.services.run_logs import _percentile

MODEL_CARD_VERSION = "1.0"

# Below this many recorded runs, a rate or a percentile describes luck rather
# than the agent, so none is reported.
MIN_SAMPLE = 5
PERFORMANCE_WINDOW_DAYS = 30

API = settings.api_prefix


def _iso(moment: datetime | None) -> str | None:
    return moment.isoformat() if moment else None


def _active_policies(session: Session, project_id: str) -> list[GovernancePolicy]:
    return list(
        session.execute(
            select(GovernancePolicy)
            .where(
                GovernancePolicy.is_enabled.is_(True),
                or_(GovernancePolicy.project_id == project_id, GovernancePolicy.project_id.is_(None)),
            )
            .order_by(GovernancePolicy.priority)
        ).scalars()
    )


# ---------------------------------------------------------------------------
# Observed performance
# ---------------------------------------------------------------------------


def observed_performance(
    session: Session,
    project_id: str,
    *,
    agent_key: str | None = None,
    flow_id: str | None = None,
    days: int = PERFORMANCE_WINDOW_DAYS,
) -> dict[str, Any]:
    """What recorded runs in this project show, and how much they show.

    For an agent, every execution of it in any run -- a flow step or a direct
    invocation -- because that is the agent's behaviour. For a flow, its runs.
    """
    since = datetime.now(UTC) - timedelta(days=days)
    if agent_key is not None:
        rows = list(
            session.execute(
                select(
                    AgentRunStep.status,
                    AgentRunStep.duration_ms,
                    AgentRunStep.total_tokens,
                    AgentRunStep.cost_usd,
                    AgentRunStep.finished_at,
                )
                .join(AgentRun, AgentRun.id == AgentRunStep.run_id)
                .where(
                    AgentRun.project_id == project_id,
                    AgentRunStep.agent_key == agent_key,
                    AgentRunStep.created_at >= since,
                )
            ).all()
        )
        finished = [row for row in rows if row.status in ("succeeded", "failed")]
        succeeded = sum(1 for row in finished if row.status == "succeeded")
    else:
        rows = list(
            session.execute(
                select(
                    AgentRun.status,
                    AgentRun.duration_ms,
                    AgentRun.total_tokens,
                    AgentRun.total_cost_usd.label("cost_usd"),
                    AgentRun.finished_at,
                ).where(
                    AgentRun.project_id == project_id,
                    AgentRun.flow_id == flow_id,
                    AgentRun.created_at >= since,
                )
            ).all()
        )
        finished = [row for row in rows if disposition(row.status) in TERMINAL]
        succeeded = sum(1 for row in finished if disposition(row.status) == "succeeded")

    durations = [row.duration_ms for row in finished if row.duration_ms]
    enough = len(finished) >= MIN_SAMPLE
    last = max((row.finished_at for row in finished if row.finished_at), default=None)
    return {
        "source": f"recorded runs in this project over the last {days} days",
        "window_days": days,
        "sample_size": len(finished),
        "insufficient_data": not enough,
        "success_rate": round(succeeded / len(finished), 4) if enough else None,
        "duration_ms": {
            "p50": _percentile(durations, 0.5) if enough else None,
            "p95": _percentile(durations, 0.95) if enough else None,
        },
        "avg_tokens": int(sum(row.total_tokens or 0 for row in finished) / len(finished)) if enough else None,
        "avg_cost_usd": round(sum(row.cost_usd or 0.0 for row in finished) / len(finished), 6) if enough else None,
        "last_run_at": _iso(last),
        "note": (
            None
            if enough
            else f"Fewer than {MIN_SAMPLE} finished runs in the window, so no rates are reported."
        ),
    }


# ---------------------------------------------------------------------------
# Pieces shared by agents and flows
# ---------------------------------------------------------------------------


def _resolved_model(session: Session, project: Project, capability: str, complexity: str, agent_config: dict) -> dict[str, Any]:
    """The model the router would choose right now -- resolved, not assumed."""
    try:
        decision = ModelRouter(session).resolve(
            RoutingRequest(
                capability=capability,
                complexity=complexity,
                agent_config=agent_config or {},
                project_config=project.llm_config or {},
            ),
            project_id=project.id,
        )
    except Exception as error:  # noqa: BLE001 - a card must still render
        return {"resolved": False, "detail": str(error)[:200]}
    selection = decision.selection
    return {
        "resolved": True,
        "provider": selection.provider,
        "model": selection.model,
        "deployment": selection.deployment,
        "capability": capability,
        "complexity": complexity,
        "temperature": selection.temperature,
        "max_tokens": selection.max_tokens,
        "resolved_from": decision.source,
        "fallback": (
            {"provider": decision.fallback.provider, "model": decision.fallback.model}
            if decision.fallback
            else None
        ),
        "note": (
            "Resolved at the time this card was generated. A flow node or the project can "
            "pin a different model; the model actually used is recorded per run in its log."
        ),
    }


def _tools(refs: list[str]) -> list[dict[str, Any]]:
    """The tools an agent may call, with their schemas, from the MCP registry."""
    from app.mcp.registry import ADAPTERS, SERVER_METADATA  # noqa: PLC0415

    described: list[dict[str, Any]] = []
    for ref in refs or []:
        server, _, only = ref.partition(".")
        if server == "knowledge":
            described.append(
                {
                    "name": "knowledge.retrieve",
                    "description": "Semantic retrieval from this project's Knowledge Fabric. Read-only.",
                    "mutating": False,
                    "risk_level": "low",
                }
            )
            continue
        variants = ADAPTERS.get(server)
        if variants is None:
            described.append({"name": ref, "description": "Not a registered tool server.", "available": False})
            continue
        try:
            definitions = (variants.get("real") or variants["demo"])({}).list_tools()
        except Exception:  # noqa: BLE001
            definitions = []
        for definition in definitions:
            if only and definition.name != only:
                continue
            described.append(
                {
                    "name": f"{server}.{definition.name}",
                    "server": SERVER_METADATA.get(server, {}).get("name", server),
                    "description": definition.description,
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            p.name: {"type": p.type, "description": p.description, **({"enum": p.enum} if p.enum else {})}
                            for p in definition.parameters
                        },
                        "required": [p.name for p in definition.parameters if p.required],
                    },
                    "mutating": definition.mutating,
                    "risk_level": definition.risk_level,
                    "requires_approval": definition.requires_approval,
                }
            )
    return described


def _prompts(agent_key: str) -> list[dict[str, Any]]:
    """Which instructions an agent is given, by id and version -- not by text."""
    listed = [
        {"id": t.id, "version": t.version, "purpose": t.purpose}
        for t in templates()
        if t.id.startswith(f"agent.{agent_key}.") or t.id == "shared.agent_system"
    ]
    return sorted(listed, key=lambda item: item["id"])


def _controls(session: Session, project_id: str, *, computed_outputs: bool = False) -> list[dict[str, Any]]:
    """Controls enforced in code, each with where. Nothing aspirational."""
    policies = _active_policies(session, project_id)
    controls = [
        {"id": item["id"], "statement": item["statement"], "enforced_by": item["enforced_by"]}
        for item in guardrail_contract(policies)["guarantees"]
    ]
    controls += [
        {
            "id": "untrusted_content_fenced",
            "statement": (
                "Content the platform does not control -- caller inputs, retrieved documents, "
                "captured pages -- reaches a model only inside a fence carrying a per-run nonce, "
                "and is labelled as data, not instruction."
            ),
            "enforced_by": "app/ai/prompts/safety.py",
        },
        {
            "id": "inputs_validated",
            "statement": (
                "An input the agent does not declare, or of the wrong type, is refused before "
                "anything runs, with a suggestion when it looks like a typo."
            ),
            "enforced_by": "app/services/input_validation.py",
        },
        {
            "id": "tenant_isolation",
            "statement": "A run, its data and its logs are confined to the project it ran in.",
            "enforced_by": "app/core/tenancy.py",
        },
        {
            "id": "logs_redacted",
            "statement": (
                "Run logs and audit feeds mask secrets and personal data and omit prompts, tool "
                "arguments and the identity of platform users."
            ),
            "enforced_by": "app/services/run_logs.py",
        },
    ]
    if ModelRouter(session).pii_masking_required(project_id):
        controls.append(
            {
                "id": "pii_masked_before_model",
                "statement": (
                    "Email addresses, card numbers, IBANs and SSNs are masked in every message "
                    "before it is sent to a model provider."
                ),
                "enforced_by": "app/ai/router/model_router.py",
            }
        )
    if computed_outputs:
        controls.append(
            {
                "id": "computed_outputs_authoritative",
                "statement": (
                    "This agent's outputs are computed from project state. A model contributes "
                    "wording and judgement; it cannot replace or re-derive the computed figures."
                ),
                "enforced_by": "app/agents/base.py",
            }
        )
    return controls


def _resilience(retry_policy: dict | None, timeout_seconds: int | None, fallback: dict | None) -> dict[str, Any]:
    retry_policy = retry_policy or {}
    return {
        "retry": {
            "max_attempts": int(retry_policy.get("max_attempts", 1)),
            "backoff": "linear",
            "backoff_seconds": float(retry_policy.get("backoff_seconds", 1.0)),
            "detail": "Waits backoff_seconds x attempt between attempts, capped at 5 seconds.",
            "applied_by": "app/orchestration/engine.py",
        },
        "timeout_seconds": timeout_seconds or 120,
        "fallback_model": fallback,
        "budgets": "Checked before each model call; exceeding one stops the run.",
        # Said, because a reviewer comparing cards will look for it.
        "circuit_breaker": {
            "provided": False,
            "instead": (
                "Retries per the policy above, then the fallback model. A run that still fails "
                "reports disposition 'failed'."
            ),
        },
    }


def _monitoring() -> dict[str, Any]:
    return {
        "per_run_log": {
            "endpoint": f"GET {API}/integration/runs/{{run_id}}/log",
            "scope": "runs:logs",
            "contains": ["activities (agent, model, duration, tokens, cost, tools, policy)", "timeline", "approvals", "audit", "usage by model"],
        },
        "audit_feed": {
            "endpoint": f"GET {API}/integration/audit-events",
            "scope": "runs:logs",
            "pagination": "cursor; resume from next_cursor",
        },
        "metrics": {
            "endpoint": f"GET {API}/integration/metrics",
            "scope": "runs:logs",
            "metrics": [
                "runs by disposition",
                "success_rate",
                "duration p50/p95",
                "tokens and cost",
                "model calls, failures and fallbacks",
                "approval wait",
            ],
        },
        "tracing": {
            "request_header": "X-Correlation-ID (echoed on every response; generated if absent)",
            "run_field": "correlation_id on every run envelope and log",
        },
        "logging": {"format": "structured JSON, server side", "carries": ["correlation_id", "run_id"]},
    }


def _operations(*, requires_approval: bool, approval_roles: list[str], typical_ms: int | None) -> dict[str, Any]:
    return {
        "sop": f"GET {API}/integration/sop",
        "calling": "Start a run, then poll the run until is_terminal is true. Send X-Idempotency-Key when starting.",
        "approval": (
            f"Runs pause at an approval gate and report 'waiting_for_approval' until a person with role "
            f"{', '.join(sorted(set(approval_roles))) or 'the required role'} decides. This is not a failure."
            if requires_approval
            else "No approval gate is configured; a governance policy can still require one per invocation."
        ),
        "expected_duration_ms": typical_ms,
        "on_failure": "Read the run log's activities and top errors; retry only a run that reached 'failed'.",
        "escalation": "The platform operator who issued your API key.",
    }


# ---------------------------------------------------------------------------
# Agent cards
# ---------------------------------------------------------------------------


def agent_model_card(session: Session, agent: Agent, project: Project) -> dict[str, Any]:
    from app.agents.registry import AGENT_CLASS_BY_KEY  # noqa: PLC0415
    from app.services.golden_datasets import dataset_summary  # noqa: PLC0415

    agent_class = AGENT_CLASS_BY_KEY.get(agent.handler_key or agent.key)
    capability = agent.capability or getattr(agent_class, "capability", "generation")
    complexity = getattr(agent_class, "complexity", "standard")
    model = _resolved_model(session, project, capability, complexity, agent.llm_config or {})
    performance = observed_performance(session, project.id, agent_key=agent.key)
    key = agent.handler_key or agent.key

    return {
        "model_card_version": MODEL_CARD_VERSION,
        "generated_at": datetime.now(UTC).isoformat(),
        "generated_from": "the live agent definition; regenerated on every request",
        "name": agent.name,
        "key": key,
        "id": agent.id,
        "type": "agent",
        "description": agent.description,
        "category": agent.category,
        "version": agent.version,
        "lifecycle_state": agent.lifecycle_state,
        "is_builtin": agent.is_builtin,
        "framework": "AI QE Orchestrator agent runtime",
        "language": "python",
        "owner": "AI QE Orchestrator platform team" if agent.is_builtin else (agent.created_by or "unassigned"),
        "business_owner": project.name,
        "lob": project.business_domain,
        "goal": agent.goal,
        "capabilities": [capability],
        "model": model,
        "prompts": _prompts(key),
        "tools": _tools(list(agent.supported_tools or [])),
        "operating_modes": [
            {
                "mode": "Invoke",
                "endpoint": f"POST {API}/integration/agents/{key}/runs",
                "scope": "agents:run",
                "description": "Run this agent once. Asynchronous: poll the returned run.",
            },
            {
                "mode": "Flow step",
                "description": "Run as a step inside a flow, with that step's retry, timeout and approval settings.",
            },
        ],
        "input_schema": agent.input_schema or {"type": "object", "properties": {}},
        "output_schema": agent.output_schema or AGENT_OUTPUT_SCHEMA,
        "governance": {
            "risk_level": agent.risk_level,
            "requires_approval": agent.requires_approval,
            "cost_tier": agent.cost_tier,
            "budgets": {"cost_usd_per_invocation": agent.cost_budget_usd, "tokens_per_invocation": agent.token_budget},
            "guardrails": list(agent.guardrails or []),
            "active_policies": guardrail_contract(_active_policies(session, project.id))["active_policies"],
        },
        "compliance": {
            "controls": _controls(session, project.id, computed_outputs=bool(getattr(agent_class, "computed_outputs", False))),
        },
        "resilience": _resilience(agent.retry_policy, agent.timeout_seconds, model.get("fallback")),
        "security": {
            "authentication": "X-API-Key issued per calling system, with explicit scopes",
            "scopes": {"invoke": "agents:run", "read_result": "runs:read", "read_logs": "runs:logs", "read_card": "catalog:read"},
            "rate_limiting": f"Per API key; the limit is reported by GET {API}/integration/me",
            "prompt_injection_defence": "untrusted content fenced with a per-run nonce; instruction-like content is audited",
            "output_validation": "every answer is coerced to the output contract before it is returned",
        },
        "performance_characteristics": performance,
        "golden_dataset": dataset_summary(session, agent=agent),
        "endpoints": [
            {"method": "POST", "path": f"{API}/integration/agents/{key}/runs", "scope": "agents:run", "description": "Invoke"},
            {"method": "GET", "path": f"{API}/integration/runs/{{run_id}}", "scope": "runs:read", "description": "Status and result"},
            {"method": "GET", "path": f"{API}/integration/runs/{{run_id}}/log", "scope": "runs:logs", "description": "Governance log"},
            {"method": "GET", "path": f"{API}/integration/agents/{key}/model-card", "scope": "catalog:read", "description": "This card"},
            {"method": "GET", "path": f"{API}/integration/agents/{key}/golden-dataset", "scope": "catalog:read", "description": "Golden dataset"},
        ],
        "monitoring": _monitoring(),
        "operations": _operations(
            requires_approval=agent.requires_approval,
            approval_roles=[],
            typical_ms=performance["duration_ms"]["p50"],
        ),
        "created_at": _iso(agent.created_at),
        "last_updated": _iso(agent.updated_at),
    }


# ---------------------------------------------------------------------------
# Flow cards
# ---------------------------------------------------------------------------


def flow_model_card(session: Session, flow: AgentFlow, project: Project) -> dict[str, Any]:
    from app.services.golden_datasets import dataset_summary  # noqa: PLC0415

    agents = {
        agent.id: agent
        for agent in session.execute(
            select(Agent).where(Agent.id.in_({n.agent_id for n in flow.nodes if n.agent_id}))
        ).scalars()
    } if flow.nodes else {}

    nodes = []
    approval_gates = []
    for node in sorted(flow.nodes, key=lambda n: (n.sequence, n.node_key)):
        agent = agents.get(node.agent_id)
        gated = node.node_type == "approval" or bool(node.requires_approval)
        if gated:
            approval_gates.append({"node": node.node_key, "label": node.label, "role": node.approval_role})
        nodes.append(
            {
                "key": node.node_key,
                "type": node.node_type,
                "label": node.label,
                "agent": (
                    {"key": agent.handler_key or agent.key, "name": agent.name, "version": node.agent_version or agent.version}
                    if agent
                    else None
                ),
                "requires_approval": gated,
                "approval_role": node.approval_role,
                "on_failure": node.on_failure,
                "retry_policy": node.retry_policy or (agent.retry_policy if agent else None),
                "timeout_seconds": node.timeout_seconds or (agent.timeout_seconds if agent else None),
                "cost_limit_usd": node.cost_limit_usd,
                "pinned_model": (node.llm_config or {}).get("model"),
            }
        )

    used_agents = []
    seen: set[str] = set()
    for node in nodes:
        agent_ref = node["agent"]
        if agent_ref and agent_ref["key"] not in seen:
            seen.add(agent_ref["key"])
            used_agents.append(
                {**agent_ref, "model_card": f"{API}/integration/agents/{agent_ref['key']}/model-card"}
            )

    performance = observed_performance(session, project.id, flow_id=flow.id)
    governance = flow.governance or {}

    return {
        "model_card_version": MODEL_CARD_VERSION,
        "generated_at": datetime.now(UTC).isoformat(),
        "generated_from": "the live flow definition; regenerated on every request",
        "name": flow.name,
        "key": flow.key,
        "id": flow.id,
        "type": "flow",
        "description": flow.description,
        "category": flow.category,
        "version": flow.version,
        "status": flow.status,
        "framework": (
            "LangGraph StateGraph" if settings.orchestration_engine == "langgraph" else "native flow engine"
        ),
        "language": "python",
        "owner": flow.owner,
        "business_owner": project.name,
        "lob": project.business_domain,
        "trigger": {"type": flow.trigger_type, "schedule": flow.schedule or {"enabled": False}},
        "nodes": nodes,
        "edges": [
            {
                "from": edge.source_node_key,
                "to": edge.target_node_key,
                "branch": edge.branch_label,
                "condition": edge.condition_expression,
            }
            for edge in flow.edges
        ],
        "agents": used_agents,
        "input_schema": _flow_descriptor(flow)["input_schema"],
        "output_schema": {
            "type": "object",
            "description": "Keyed by agent key; each value is that agent's result in the standard contract.",
            "additionalProperties": AGENT_OUTPUT_SCHEMA,
        },
        "governance": {
            "run_roles": governance.get("run_roles", []),
            "slo_success_rate": governance.get("slo_success_rate"),
            "budget_alert_percent": governance.get("budget_alert_percent"),
            "notify_on_failure": governance.get("notify_on_failure"),
            "budgets": {"cost_usd_per_run": flow.cost_budget_usd, "tokens_per_run": flow.token_budget},
            "approval_gates": approval_gates,
            "active_policies": guardrail_contract(_active_policies(session, project.id))["active_policies"],
        },
        "compliance": {"controls": _controls(session, project.id)},
        "resilience": {
            **_resilience({}, None, None),
            "per_node": "Each node carries its own retry policy, timeout and failure behaviour; see nodes.",
        },
        "security": {
            "authentication": "X-API-Key issued per calling system, with explicit scopes",
            "scopes": {"invoke": "flows:run", "read_result": "runs:read", "read_logs": "runs:logs", "read_card": "catalog:read"},
            "rate_limiting": f"Per API key; the limit is reported by GET {API}/integration/me",
        },
        "performance_characteristics": {
            **performance,
            "slo_success_rate": governance.get("slo_success_rate"),
            "meets_slo": (
                performance["success_rate"] >= governance["slo_success_rate"]
                if performance["success_rate"] is not None and governance.get("slo_success_rate") is not None
                else None
            ),
        },
        "golden_dataset": dataset_summary(session, flow=flow),
        "endpoints": [
            {"method": "POST", "path": f"{API}/integration/flows/{flow.id}/runs", "scope": "flows:run", "description": "Start"},
            {"method": "GET", "path": f"{API}/integration/runs/{{run_id}}", "scope": "runs:read", "description": "Status and result"},
            {"method": "GET", "path": f"{API}/integration/runs/{{run_id}}/log", "scope": "runs:logs", "description": "Governance log"},
            {"method": "GET", "path": f"{API}/integration/flows/{flow.id}/model-card", "scope": "catalog:read", "description": "This card"},
            {"method": "GET", "path": f"{API}/integration/flows/{flow.id}/golden-dataset", "scope": "catalog:read", "description": "Golden dataset"},
        ],
        "monitoring": _monitoring(),
        "operations": _operations(
            requires_approval=bool(approval_gates),
            approval_roles=[gate["role"] for gate in approval_gates if gate["role"]],
            typical_ms=performance["duration_ms"]["p50"],
        ),
        "created_at": _iso(flow.created_at),
        "last_updated": _iso(flow.updated_at),
    }
