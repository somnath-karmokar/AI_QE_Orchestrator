"""Everything a flow's own workspace shows: dashboard, observability, governance and report.

Each flow is operated as an independent product -- its own KPIs, its own
telemetry, its own controls and its own shareable report -- so a QE lead can
answer "is this flow healthy, what does it cost, and is it under control?"
without reading project-wide dashboards.

All figures are computed from persisted runs, steps, LLM usage, approvals and
audit entries; nothing here is hard-coded.
"""

from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from datetime import UTC, date, datetime, timedelta
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.governance import ApprovalRequest, AuditLog, GovernancePolicy
from app.models.llm import LLMUsage
from app.models.project import Project
from app.models.run import AgentMessage, AgentRun, AgentRunStep
from app.orchestration.schedule import describe_schedule

FINISHED = {"succeeded", "failed", "cancelled"}
ATTENTION = {"awaiting_approval", "running", "queued"}
# A conservative, stated assumption: the manual effort one successful agent step replaces.
MINUTES_SAVED_PER_STEP = 25
DEFAULT_SLO_SUCCESS = 0.9


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def _iso(value: datetime | None) -> str | None:
    value = _aware(value)
    return value.isoformat() if value else None


def _percentile(values: list[float], percent: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = (len(ordered) - 1) * percent
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def window_start(now: datetime, window_days: int) -> datetime:
    """Midnight UTC at the start of a window of whole days ending today, so totals match daily charts."""
    first = (now.astimezone(UTC) - timedelta(days=window_days - 1)).date()
    return datetime(first.year, first.month, first.day, tzinfo=UTC)


def _rate(part: int, whole: int) -> float | None:
    return round(part / whole, 4) if whole else None


def _outcome(status: str) -> str:
    if status == "succeeded":
        return "succeeded"
    if status in ATTENTION:
        return "attention"
    return "failed"


class FlowInsights:
    def __init__(self, session: Session, flow: AgentFlow) -> None:
        self.session = session
        self.flow = flow
        self.now = datetime.now(UTC)

    # ------------------------------------------------------------------
    # Data access
    # ------------------------------------------------------------------
    def _runs(self, since: datetime | None = None, until: datetime | None = None) -> list[AgentRun]:
        statement = select(AgentRun).where(AgentRun.flow_id == self.flow.id)
        if since is not None:
            statement = statement.where(AgentRun.created_at >= since)
        if until is not None:
            statement = statement.where(AgentRun.created_at < until)
        return list(self.session.execute(statement.order_by(AgentRun.created_at.asc())).scalars())

    def _steps(self, runs: list[AgentRun]) -> list[AgentRunStep]:
        if not runs:
            return []
        ids = [run.id for run in runs]
        return list(
            self.session.execute(select(AgentRunStep).where(AgentRunStep.run_id.in_(ids))).scalars()
        )

    def _usage(self, since: datetime) -> list[LLMUsage]:
        return list(
            self.session.execute(
                select(LLMUsage).where(LLMUsage.flow_id == self.flow.id, LLMUsage.created_at >= since)
            ).scalars()
        )

    def _days(self, window_days: int) -> list[date]:
        today = self.now.date()
        return [today - timedelta(days=offset) for offset in range(window_days - 1, -1, -1)]

    # ------------------------------------------------------------------
    # Shared figures
    # ------------------------------------------------------------------
    def _kpis(self, runs: list[AgentRun], steps: list[AgentRunStep]) -> dict[str, Any]:
        finished = [run for run in runs if run.status in FINISHED]
        succeeded = [run for run in finished if run.status == "succeeded"]
        durations = [run.duration_ms for run in finished if run.duration_ms]
        costs = [run.total_cost_usd for run in runs if run.total_cost_usd]
        agent_steps_ok = sum(1 for step in steps if step.node_type == "agent" and step.status == "succeeded")
        budget = self.flow.cost_budget_usd or 0.0
        avg_cost = statistics.fmean(costs) if costs else 0.0
        return {
            "runs": len(runs),
            "finished_runs": len(finished),
            "succeeded_runs": len(succeeded),
            "failed_runs": sum(1 for run in finished if run.status != "succeeded"),
            "attention_runs": sum(1 for run in runs if run.status in ATTENTION),
            "success_rate": _rate(len(succeeded), len(finished)),
            "p50_duration_ms": round(_percentile(durations, 0.5)),
            "p95_duration_ms": round(_percentile(durations, 0.95)),
            "total_cost_usd": round(sum(costs), 4),
            "avg_cost_usd": round(avg_cost, 4),
            "budget_utilisation": round(avg_cost / budget, 4) if budget else None,
            "total_tokens": sum(run.total_tokens for run in runs),
            "automated_steps": agent_steps_ok,
            "hours_saved": round(agent_steps_ok * MINUTES_SAVED_PER_STEP / 60, 1),
        }

    @staticmethod
    def _delta(current: float | None, previous: float | None) -> float | None:
        if current is None or previous is None:
            return None
        return round(current - previous, 4)

    def _daily(self, runs: list[AgentRun], window_days: int) -> list[dict[str, Any]]:
        buckets: dict[date, list[AgentRun]] = defaultdict(list)
        for run in runs:
            buckets[_aware(run.created_at).date()].append(run)
        series = []
        for day in self._days(window_days):
            day_runs = buckets.get(day, [])
            outcomes = Counter(_outcome(run.status) for run in day_runs)
            finished = [run for run in day_runs if run.status in FINISHED]
            durations = [run.duration_ms for run in finished if run.duration_ms]
            series.append(
                {
                    "date": day.isoformat(),
                    "runs": len(day_runs),
                    "succeeded": outcomes.get("succeeded", 0),
                    "failed": outcomes.get("failed", 0),
                    "attention": outcomes.get("attention", 0),
                    "success_rate": _rate(outcomes.get("succeeded", 0), len(finished)),
                    "cost_usd": round(sum(run.total_cost_usd for run in day_runs), 4),
                    "tokens": sum(run.total_tokens for run in day_runs),
                    "p50_duration_ms": round(_percentile(durations, 0.5)) if durations else None,
                }
            )
        return series

    @staticmethod
    def _run_row(run: AgentRun) -> dict[str, Any]:
        return {
            "id": run.id,
            "run_number": run.run_number,
            "title": run.title,
            "status": run.status,
            "trigger": run.trigger,
            "triggered_by": run.triggered_by,
            "created_at": _iso(run.created_at),
            "started_at": _iso(run.started_at),
            "finished_at": _iso(run.finished_at),
            "duration_ms": run.duration_ms,
            "total_cost_usd": round(run.total_cost_usd, 4),
            "total_tokens": run.total_tokens,
            "step_count": run.step_count,
            "completed_step_count": run.completed_step_count,
            "summary": run.summary,
        }

    def _step_health(self, steps: list[AgentRunStep]) -> list[dict[str, Any]]:
        order = {node.node_key: (node.position_y, node.position_x) for node in self.flow.nodes}
        grouped: dict[str, list[AgentRunStep]] = defaultdict(list)
        for step in steps:
            if step.node_type in {"agent", "approval", "tool"}:
                grouped[step.node_key].append(step)

        rows = []
        for node_key, node_steps in grouped.items():
            finished = [step for step in node_steps if step.status in {"succeeded", "failed", "skipped"}]
            ok = sum(1 for step in finished if step.status in {"succeeded", "skipped"})
            durations = [step.duration_ms for step in node_steps if step.duration_ms]
            confidences = [step.confidence for step in node_steps if step.confidence is not None]
            errors = Counter((step.error or "").split("\n", 1)[0][:120] for step in node_steps if step.error)
            rows.append(
                {
                    "node_key": node_key,
                    "label": node_steps[-1].label,
                    "node_type": node_steps[-1].node_type,
                    "agent_key": node_steps[-1].agent_key,
                    "executions": len(node_steps),
                    "success_rate": _rate(ok, len(finished)),
                    "failures": sum(1 for step in node_steps if step.status == "failed"),
                    "retries": sum(1 for step in node_steps if (step.attempt or 1) > 1),
                    "p50_duration_ms": round(_percentile(durations, 0.5)),
                    "p95_duration_ms": round(_percentile(durations, 0.95)),
                    "avg_cost_usd": round(statistics.fmean([step.cost_usd for step in node_steps]), 4),
                    "total_cost_usd": round(sum(step.cost_usd for step in node_steps), 4),
                    "total_tokens": sum(step.total_tokens for step in node_steps),
                    "avg_confidence": round(statistics.fmean(confidences), 3) if confidences else None,
                    "top_error": errors.most_common(1)[0][0] if errors else None,
                }
            )
        rows.sort(key=lambda row: order.get(row["node_key"], (10_000, 0)))
        return rows

    def _pending_approvals(self) -> list[ApprovalRequest]:
        return list(
            self.session.execute(
                select(ApprovalRequest)
                .join(AgentRun, AgentRun.id == ApprovalRequest.run_id)
                .where(AgentRun.flow_id == self.flow.id, ApprovalRequest.status == "pending")
                .order_by(ApprovalRequest.created_at.desc())
            ).scalars()
        )

    # ------------------------------------------------------------------
    # Dashboard
    # ------------------------------------------------------------------
    def dashboard(self, window_days: int = 30) -> dict[str, Any]:
        since = window_start(self.now, window_days)
        runs = self._runs(since)
        steps = self._steps(runs)
        previous_runs = self._runs(since - timedelta(days=window_days), since)
        kpis = self._kpis(runs, steps)
        previous = self._kpis(previous_runs, self._steps(previous_runs))

        last_run = self.session.execute(
            select(AgentRun).where(AgentRun.flow_id == self.flow.id).order_by(AgentRun.created_at.desc()).limit(1)
        ).scalar_one_or_none()
        recent = list(reversed(runs[-10:]))
        pending = self._pending_approvals()

        return {
            "flow": self.flow_header(),
            "window_days": window_days,
            "kpis": kpis,
            "deltas": {
                "runs": kpis["runs"] - previous["runs"],
                "success_rate": self._delta(kpis["success_rate"], previous["success_rate"]),
                "p50_duration_ms": kpis["p50_duration_ms"] - previous["p50_duration_ms"]
                if previous["finished_runs"]
                else None,
                "avg_cost_usd": round(kpis["avg_cost_usd"] - previous["avg_cost_usd"], 4)
                if previous["runs"]
                else None,
            },
            "daily": self._daily(runs, window_days),
            "triggers": [
                {"trigger": trigger, "runs": count}
                for trigger, count in Counter(run.trigger for run in runs).most_common()
            ],
            "step_health": self._step_health(steps),
            "recent_runs": [self._run_row(run) for run in recent],
            "last_run": self._run_row(last_run) if last_run else None,
            "pending_approvals": [
                {
                    "id": approval.id,
                    "title": approval.title,
                    "risk_level": approval.risk_level,
                    "required_role": approval.required_role,
                    "created_at": _iso(approval.created_at),
                    "run_id": approval.run_id,
                }
                for approval in pending
            ],
            "assumptions": {"minutes_saved_per_step": MINUTES_SAVED_PER_STEP},
        }

    def flow_header(self) -> dict[str, Any]:
        flow = self.flow
        agent_nodes = [node for node in flow.nodes if node.node_type == "agent"]
        return {
            "id": flow.id,
            "key": flow.key,
            "name": flow.name,
            "description": flow.description,
            "category": flow.category,
            "status": flow.status,
            "version": flow.version,
            "owner": flow.owner or flow.created_by,
            "tags": flow.tags or [],
            "agent_count": len(agent_nodes),
            "approval_gates": sum(
                1 for node in flow.nodes if node.node_type == "approval" or node.requires_approval
            ),
            "cost_budget_usd": flow.cost_budget_usd,
            "schedule": flow.schedule or {"enabled": False},
            "schedule_description": describe_schedule(flow.schedule),
            "next_run_at": _iso(flow.next_run_at),
            "api_trigger_enabled": bool(flow.webhook_token_hash),
            "run_count": flow.run_count,
            "last_run_at": _iso(flow.last_run_at),
            "created_at": _iso(flow.created_at),
            "updated_at": _iso(flow.updated_at),
        }

    # ------------------------------------------------------------------
    # Observability
    # ------------------------------------------------------------------
    def observability(self, window_days: int = 14) -> dict[str, Any]:
        since = window_start(self.now, window_days)
        runs = self._runs(since)
        steps = self._steps(runs)
        usage = self._usage(since)
        run_numbers = {run.id: run.run_number for run in runs}

        models: dict[tuple[str, str], dict[str, Any]] = {}
        for row in usage:
            entry = models.setdefault(
                (row.provider, row.model),
                {"provider": row.provider, "model": row.model, "calls": 0, "tokens": 0, "cost_usd": 0.0,
                 "latencies": [], "errors": 0, "fallbacks": 0},
            )
            entry["calls"] += 1
            entry["tokens"] += row.total_tokens
            entry["cost_usd"] += row.estimated_cost_usd
            entry["latencies"].append(row.latency_ms)
            entry["errors"] += 0 if row.success else 1
            entry["fallbacks"] += 1 if row.fallback_used else 0
        model_rows = [
            {
                **{key: value for key, value in entry.items() if key != "latencies"},
                "cost_usd": round(entry["cost_usd"], 4),
                "p50_latency_ms": round(_percentile(entry["latencies"], 0.5)),
                "p95_latency_ms": round(_percentile(entry["latencies"], 0.95)),
                "error_rate": _rate(entry["errors"], entry["calls"]),
            }
            for entry in models.values()
        ]
        model_rows.sort(key=lambda row: row["cost_usd"], reverse=True)

        failed_steps = [step for step in steps if step.status == "failed"]
        failure_signatures = Counter(
            ((step.label, (step.error or "Unknown error").split("\n", 1)[0][:140]) for step in failed_steps)
        )

        events = []
        if runs:
            events = list(
                self.session.execute(
                    select(AgentMessage)
                    .where(AgentMessage.run_id.in_([run.id for run in runs]))
                    .order_by(AgentMessage.created_at.desc())
                    .limit(30)
                ).scalars()
            )

        durations = [run.duration_ms for run in runs if run.status in FINISHED and run.duration_ms]
        finished = [run for run in runs if run.status in FINISHED]

        # Where run time goes: agents working versus people deciding.
        approvals = (
            list(
                self.session.execute(
                    select(ApprovalRequest).where(
                        ApprovalRequest.run_id.in_([run.id for run in finished]),
                        ApprovalRequest.decided_at.is_not(None),
                    )
                ).scalars()
            )
            if finished
            else []
        )
        human_wait_ms = sum(
            (_aware(item.decided_at) - _aware(item.created_at)).total_seconds() * 1000 for item in approvals
        )
        total_ms = sum(run.duration_ms for run in finished)
        agent_ms = sum(step.duration_ms for step in steps if step.node_type == "agent")
        succeeded = sum(1 for run in finished if run.status == "succeeded")
        slo_target = float((self.flow.governance or {}).get("slo_success_rate", DEFAULT_SLO_SUCCESS))
        success_rate = _rate(succeeded, len(finished))
        # Error budget: the failures the SLO allows in this window, and how many are used.
        allowed_failures = len(finished) * (1 - slo_target)
        used_failures = len(finished) - succeeded

        return {
            "flow": self.flow_header(),
            "window_days": window_days,
            "slo": {
                "target_success_rate": slo_target,
                "success_rate": success_rate,
                "error_budget_remaining": round(1 - used_failures / allowed_failures, 4)
                if allowed_failures
                else (1.0 if used_failures == 0 else 0.0),
                "status": "no_data"
                if success_rate is None
                else "healthy"
                if success_rate >= slo_target
                else "at_risk",
            },
            "latency": {
                "p50_ms": round(_percentile(durations, 0.5)),
                "p90_ms": round(_percentile(durations, 0.9)),
                "p95_ms": round(_percentile(durations, 0.95)),
                "max_ms": max(durations) if durations else 0,
            },
            "time_split": {
                "agent_ms": round(agent_ms),
                "human_wait_ms": round(human_wait_ms),
                "orchestration_ms": max(0, round(total_ms - agent_ms - human_wait_ms)),
                "avg_agent_ms_per_run": round(agent_ms / len(finished)) if finished else 0,
                "avg_human_wait_ms_per_run": round(human_wait_ms / len(finished)) if finished else 0,
            },
            "daily": self._daily(runs, window_days),
            "step_latency": [
                {key: row[key] for key in ("node_key", "label", "node_type", "executions", "p50_duration_ms",
                                            "p95_duration_ms", "retries", "failures", "avg_confidence",
                                            "total_tokens", "total_cost_usd")}
                for row in self._step_health(steps)
                if row["node_type"] != "approval"
            ],
            "models": model_rows,
            "llm_totals": {
                "calls": len(usage),
                "tokens": sum(row.total_tokens for row in usage),
                "cost_usd": round(sum(row.estimated_cost_usd for row in usage), 4),
                "fallbacks": sum(1 for row in usage if row.fallback_used),
                "errors": sum(1 for row in usage if not row.success),
            },
            "failures": [
                {"step": label, "signature": signature, "count": count}
                for (label, signature), count in failure_signatures.most_common(8)
            ],
            "retries": sum(1 for step in steps if (step.attempt or 1) > 1),
            "events": [
                {
                    "id": event.id,
                    "run_id": event.run_id,
                    "run_number": run_numbers.get(event.run_id),
                    "event_type": event.event_type,
                    "content": event.content,
                    "created_at": _iso(event.created_at),
                }
                for event in events
            ],
        }

    # ------------------------------------------------------------------
    # Governance
    # ------------------------------------------------------------------
    def governance(self, window_days: int = 90) -> dict[str, Any]:
        flow = self.flow
        since = window_start(self.now, window_days)
        settings = {"budget_alert_percent": 80, "notify_on_failure": True, "run_roles": [], **(flow.governance or {})}
        agents = {
            agent.id: agent
            for agent in self.session.execute(
                select(Agent).where(Agent.id.in_([node.agent_id for node in flow.nodes if node.agent_id]))
            ).scalars()
        }

        controls = []
        for node in sorted(flow.nodes, key=lambda item: (item.position_y, item.position_x)):
            if node.node_type not in {"agent", "approval", "tool"}:
                continue
            agent = agents.get(node.agent_id) if node.agent_id else None
            controls.append(
                {
                    "node_key": node.node_key,
                    "label": node.label,
                    "node_type": node.node_type,
                    "agent_name": agent.name if agent else None,
                    "risk_level": agent.risk_level if agent else ("medium" if node.node_type == "approval" else None),
                    "human_gate": node.node_type == "approval" or node.requires_approval,
                    "approval_role": node.approval_role
                    or ("qe_lead" if node.node_type == "approval" or node.requires_approval else None),
                    "agent_version": node.agent_version or (agent.version if agent else None),
                    "version_pinned": bool(node.agent_version),
                    "cost_limit_usd": node.cost_limit_usd,
                    "retry": (node.retry_policy or {}).get("max_attempts"),
                    "timeout_seconds": node.timeout_seconds,
                }
            )

        runs = self._runs(since)
        run_ids = [run.id for run in runs]
        approvals = (
            list(
                self.session.execute(
                    select(ApprovalRequest)
                    .where(ApprovalRequest.run_id.in_(run_ids))
                    .order_by(ApprovalRequest.created_at.desc())
                ).scalars()
            )
            if run_ids
            else []
        )
        decision_hours = [
            (_aware(approval.decided_at) - _aware(approval.created_at)).total_seconds() / 3600
            for approval in approvals
            if approval.decided_at
        ]

        alert_percent = float(settings.get("budget_alert_percent") or 80) / 100
        over_alert = [
            run for run in runs if flow.cost_budget_usd and run.total_cost_usd >= flow.cost_budget_usd * alert_percent
        ]

        audit = list(
            self.session.execute(
                select(AuditLog)
                .where(
                    or_(
                        AuditLog.entity_id == flow.id,
                        AuditLog.run_id.in_(run_ids) if run_ids else AuditLog.id.is_(None),
                    )
                )
                .order_by(AuditLog.created_at.desc())
                .limit(40)
            ).scalars()
        )

        policies = list(
            self.session.execute(
                select(GovernancePolicy)
                .where(
                    GovernancePolicy.is_enabled.is_(True),
                    or_(GovernancePolicy.project_id.is_(None), GovernancePolicy.project_id == flow.project_id),
                )
                .order_by(GovernancePolicy.priority.asc())
            ).scalars()
        )

        checks = self._posture_checks(controls, settings, over_alert)
        passed = sum(1 for check in checks if check["status"] == "pass")

        return {
            "flow": self.flow_header(),
            "window_days": window_days,
            "posture": {
                "score": round(passed / len(checks), 4) if checks else 1.0,
                "passed": passed,
                "total": len(checks),
                "checks": checks,
            },
            "settings": {
                "owner": flow.owner or flow.created_by,
                "run_roles": settings.get("run_roles") or [],
                "budget_alert_percent": settings.get("budget_alert_percent"),
                "notify_on_failure": bool(settings.get("notify_on_failure")),
                "cost_budget_usd": flow.cost_budget_usd,
                "token_budget": flow.token_budget,
                "slo_success_rate": float(settings.get("slo_success_rate", DEFAULT_SLO_SUCCESS)),
            },
            "controls": controls,
            "approvals": {
                "total": len(approvals),
                "by_status": dict(Counter(approval.status for approval in approvals)),
                "median_decision_hours": round(statistics.median(decision_hours), 1) if decision_hours else None,
                "recent": [
                    {
                        "id": approval.id,
                        "title": approval.title,
                        "status": approval.status,
                        "risk_level": approval.risk_level,
                        "required_role": approval.required_role,
                        "decided_by": approval.decided_by,
                        "decision_notes": approval.decision_notes,
                        "created_at": _iso(approval.created_at),
                        "decided_at": _iso(approval.decided_at),
                    }
                    for approval in approvals[:12]
                ],
            },
            "budget": {
                "per_run_budget_usd": flow.cost_budget_usd,
                "alert_threshold_usd": round((flow.cost_budget_usd or 0) * alert_percent, 4),
                "runs_over_alert": len(over_alert),
                "max_run_cost_usd": round(max((run.total_cost_usd for run in runs), default=0.0), 4),
                "avg_run_cost_usd": round(statistics.fmean([run.total_cost_usd for run in runs]), 4) if runs else 0.0,
            },
            "policies": [
                {
                    "key": policy.key,
                    "name": policy.name,
                    "policy_type": policy.policy_type,
                    "effect": policy.effect,
                    "severity": policy.severity,
                    "enforcement_count": policy.enforcement_count,
                }
                for policy in policies
            ],
            "versions": [
                {
                    "version": version.version,
                    "change_summary": version.change_summary,
                    "published_at": _iso(version.published_at),
                    "created_at": _iso(version.created_at),
                    "created_by": version.created_by,
                }
                for version in sorted(flow.versions, key=lambda item: _aware(item.created_at), reverse=True)
            ],
            "audit": [
                {
                    "id": entry.id,
                    "actor": entry.actor,
                    "action": entry.action,
                    "entity_type": entry.entity_type,
                    "entity_label": entry.entity_label,
                    "outcome": entry.outcome,
                    "severity": entry.severity,
                    "reason": entry.reason,
                    "created_at": _iso(entry.created_at),
                }
                for entry in audit
            ],
        }

    def _posture_checks(
        self, controls: list[dict[str, Any]], settings: dict[str, Any], over_alert: list[AgentRun]
    ) -> list[dict[str, Any]]:
        flow = self.flow
        risky_ungated = [
            control["label"]
            for control in controls
            if control["node_type"] == "agent" and control["risk_level"] == "high" and not control["human_gate"]
        ]
        unpinned = [control["label"] for control in controls if control["node_type"] == "agent" and not control["version_pinned"]]
        validation = flow.validation_result or {}

        def check(key: str, title: str, ok: bool, detail: str, *, warn_only: bool = False) -> dict[str, Any]:
            return {"key": key, "title": title, "status": "pass" if ok else ("warn" if warn_only else "fail"),
                    "detail": detail}

        return [
            check("owner", "Accountable owner assigned", bool(flow.owner or flow.created_by),
                  f"Owned by {flow.owner or flow.created_by}." if (flow.owner or flow.created_by) else "No owner is set."),
            check("validated", "Graph validates cleanly", bool(validation.get("valid")),
                  "No validation errors." if validation.get("valid") else "Fix validation errors before running."),
            check("published", "Running a published version", flow.status == "published",
                  f"Version {flow.version} is published." if flow.status == "published"
                  else f"Status is {flow.status}; publish to lock the version that runs.", warn_only=True),
            check("high_risk_gated", "High-risk agents behind a human gate", not risky_ungated,
                  "Every high-risk step needs approval." if not risky_ungated
                  else "No approval on: " + ", ".join(risky_ungated) + "."),
            check("budget", "Cost budget per run", bool(flow.cost_budget_usd),
                  f"Runs stop at €{flow.cost_budget_usd:.2f}; alert at {settings.get('budget_alert_percent', 80)}%."
                  if flow.cost_budget_usd else "No cost ceiling is set."),
            check("budget_alerts", "Runs within the budget alert", not over_alert,
                  "No run crossed the alert threshold." if not over_alert
                  else f"{len(over_alert)} run(s) crossed the alert threshold.", warn_only=True),
            check("pinned_versions", "Agent versions pinned", not unpinned,
                  "Every agent step runs a fixed version." if not unpinned
                  else f"{len(unpinned)} step(s) follow the latest agent version.", warn_only=True),
            check("failure_alerts", "Failure notifications on", bool(settings.get("notify_on_failure")),
                  "The owner is notified when a run fails." if settings.get("notify_on_failure")
                  else "Failures are not notified.", warn_only=True),
        ]

    # ------------------------------------------------------------------
    # Report
    # ------------------------------------------------------------------
    def report(self, window_days: int = 30) -> dict[str, Any]:
        dashboard = self.dashboard(window_days)
        observability = self.observability(window_days)
        governance = self.governance(window_days)
        kpis = dashboard["kpis"]
        project = self.session.get(Project, self.flow.project_id)

        highlights: list[str] = []
        if kpis["runs"]:
            rate = kpis["success_rate"]
            highlights.append(
                f"{kpis['runs']} runs in the last {window_days} days"
                + (f", {round(rate * 100)}% succeeded." if rate is not None else ".")
            )
            highlights.append(
                f"{kpis['automated_steps']} agent steps completed, an estimated {kpis['hours_saved']} hours of manual QE effort."
            )
            highlights.append(
                f"Typical run takes {_duration_text(kpis['p50_duration_ms'])} and costs €{kpis['avg_cost_usd']:.2f} "
                f"against a €{self.flow.cost_budget_usd:.2f} budget."
            )
        else:
            highlights.append(f"No runs in the last {window_days} days.")
        highlights.append(
            f"Governance posture {governance['posture']['passed']}/{governance['posture']['total']} checks passed; "
            f"{governance['approvals']['total']} human approvals recorded."
        )

        recommendations = self._recommendations(dashboard, observability, governance)

        return {
            "title": f"{self.flow.name}: flow report",
            "project": project.name if project else None,
            "generated_at": self.now.isoformat(),
            "period": {
                "days": window_days,
                "from": window_start(self.now, window_days).date().isoformat(),
                "to": self.now.date().isoformat(),
            },
            "flow": dashboard["flow"],
            "highlights": highlights,
            "kpis": kpis,
            "deltas": dashboard["deltas"],
            "daily": dashboard["daily"],
            "step_health": dashboard["step_health"],
            "slo": observability["slo"],
            "latency": observability["latency"],
            "models": observability["models"],
            "failures": observability["failures"],
            "posture": governance["posture"],
            "approvals": governance["approvals"],
            "budget": governance["budget"],
            "recent_runs": dashboard["recent_runs"],
            "recommendations": recommendations,
            "assumptions": dashboard["assumptions"],
        }

    def _recommendations(
        self, dashboard: dict[str, Any], observability: dict[str, Any], governance: dict[str, Any]
    ) -> list[dict[str, str]]:
        kpis = dashboard["kpis"]
        items: list[dict[str, str]] = []
        weakest = min(
            (row for row in dashboard["step_health"] if row["success_rate"] is not None and row["failures"]),
            key=lambda row: row["success_rate"],
            default=None,
        )
        if observability["slo"]["status"] == "at_risk" and weakest:
            items.append({
                "priority": "high",
                "title": f"Stabilise “{weakest['label']}”",
                "detail": f"It fails {weakest['failures']} time(s) and succeeds {round(weakest['success_rate'] * 100)}% of the time"
                + (f"; most common error: {weakest['top_error']}." if weakest["top_error"] else "."),
            })
        for check in governance["posture"]["checks"]:
            if check["status"] == "fail":
                items.append({"priority": "high", "title": check["title"], "detail": check["detail"]})
        if kpis["budget_utilisation"] and kpis["budget_utilisation"] > 0.8:
            items.append({
                "priority": "medium",
                "title": "Review the cost budget",
                "detail": f"Average run uses {round(kpis['budget_utilisation'] * 100)}% of its budget; route routine steps to a lighter model or raise the ceiling.",
            })
        slow = max(dashboard["step_health"], key=lambda row: row["p95_duration_ms"], default=None)
        if slow and kpis["p95_duration_ms"] and slow["p95_duration_ms"] > kpis["p95_duration_ms"] * 0.5:
            if slow["node_type"] == "approval":
                items.append({
                    "priority": "medium",
                    "title": f"Shorten the wait at “{slow['label']}”",
                    "detail": f"Decisions take up to {_duration_text(slow['p95_duration_ms'])}, most of the run's time; "
                    "add a backup approver or raise the auto-approve confidence bar for low-risk cases.",
                })
            else:
                items.append({
                    "priority": "medium",
                    "title": f"Speed up “{slow['label']}”",
                    "detail": f"Its p95 of {_duration_text(slow['p95_duration_ms'])} is the largest share of run time.",
                })
        if dashboard["pending_approvals"]:
            items.append({
                "priority": "medium",
                "title": "Clear pending approvals",
                "detail": f"{len(dashboard['pending_approvals'])} run(s) are waiting for a human decision.",
            })
        if not (self.flow.schedule or {}).get("enabled") and not self.flow.webhook_token_hash:
            if kpis["runs"] >= 8:
                items.append({
                    "priority": "low",
                    "title": "Put the flow on a schedule",
                    "detail": "It runs often enough that a schedule would remove the manual trigger.",
                })
        for check in governance["posture"]["checks"]:
            if check["status"] == "warn":
                items.append({"priority": "low", "title": check["title"], "detail": check["detail"]})
        if not items:
            items.append({"priority": "low", "title": "No action needed", "detail": "The flow is healthy and within its controls."})
        return items[:8]


def report_markdown(report: dict[str, Any]) -> str:
    """A portable copy of the report for email, Confluence or a release pack."""
    kpis = report["kpis"]
    flow = report["flow"]

    def pct(value: float | None) -> str:
        return "n/a" if value is None else f"{round(value * 100)}%"

    lines = [
        f"# {report['title']}",
        "",
        f"**Project:** {report['project']}  ",
        f"**Period:** {report['period']['from']} to {report['period']['to']} ({report['period']['days']} days)  ",
        f"**Owner:** {flow['owner'] or 'Unassigned'} · **Version:** {flow['version']} ({flow['status']}) · "
        f"**Schedule:** {flow['schedule_description']}",
        "",
        "## Highlights",
        "",
        *[f"- {line}" for line in report["highlights"]],
        "",
        "## Key figures",
        "",
        "| Measure | Value |",
        "| --- | --- |",
        f"| Runs | {kpis['runs']} |",
        f"| Success rate | {pct(kpis['success_rate'])} |",
        f"| Typical duration (p50) | {_duration_text(kpis['p50_duration_ms'])} |",
        f"| Slowest 5% (p95) | {_duration_text(kpis['p95_duration_ms'])} |",
        f"| Average cost per run | €{kpis['avg_cost_usd']:.2f} |",
        f"| Total cost | €{kpis['total_cost_usd']:.2f} |",
        f"| Agent steps completed | {kpis['automated_steps']} |",
        f"| Estimated effort saved | {kpis['hours_saved']} h |",
        "",
        "## Step health",
        "",
        "| Step | Executions | Success | p95 | Avg cost | Avg confidence |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
        *[
            f"| {row['label']} | {row['executions']} | {pct(row['success_rate'])} | "
            f"{_duration_text(row['p95_duration_ms'])} | €{row['avg_cost_usd']:.3f} | "
            f"{'n/a' if row['avg_confidence'] is None else pct(row['avg_confidence'])} |"
            for row in report["step_health"]
        ],
        "",
        "## Governance",
        "",
        f"Posture: **{report['posture']['passed']}/{report['posture']['total']}** checks passed.",
        "",
        *[f"- {'✅' if check['status'] == 'pass' else '⚠️' if check['status'] == 'warn' else '❌'} "
          f"**{check['title']}**: {check['detail']}" for check in report["posture"]["checks"]],
        "",
        f"Human approvals: {report['approvals']['total']} "
        + (f"(median decision time {report['approvals']['median_decision_hours']} h)."
           if report["approvals"]["median_decision_hours"] is not None else "."),
        "",
        "## Recommendations",
        "",
        *[f"{index}. **{item['title']}** ({item['priority']}): {item['detail']}"
          for index, item in enumerate(report["recommendations"], start=1)],
        "",
        f"_Effort saved assumes {report['assumptions']['minutes_saved_per_step']} minutes of manual work per "
        "successful agent step. Costs are estimates from token usage._",
        "",
    ]
    return "\n".join(lines)


def _duration_text(milliseconds: float | int | None) -> str:
    if not milliseconds:
        return "0s"
    seconds = milliseconds / 1000
    if seconds < 60:
        return f"{seconds:.1f}s" if seconds < 10 else f"{round(seconds)}s"
    minutes, rest = divmod(round(seconds), 60)
    return f"{minutes}m {rest:02d}s"


def studio_overview(session: Session, project: Project, window_days: int = 30) -> dict[str, Any]:
    """The Flow Studio home: every flow with its own health at a glance."""
    now = datetime.now(UTC)
    since = window_start(now, window_days)
    flows = list(
        session.execute(
            select(AgentFlow)
            .where(AgentFlow.project_id == project.id, AgentFlow.is_deleted.is_(False))
            .order_by(AgentFlow.updated_at.desc())
        ).scalars()
    )
    runs = list(
        session.execute(
            select(AgentRun).where(
                AgentRun.project_id == project.id, AgentRun.flow_id.is_not(None), AgentRun.created_at >= since
            )
        ).scalars()
    )
    by_flow: dict[str, list[AgentRun]] = defaultdict(list)
    for run in runs:
        by_flow[run.flow_id].append(run)
    pending = session.execute(
        select(ApprovalRequest.run_id, AgentRun.flow_id)
        .join(AgentRun, AgentRun.id == ApprovalRequest.run_id)
        .where(ApprovalRequest.status == "pending", AgentRun.project_id == project.id)
    ).all()
    pending_by_flow = Counter(flow_id for _, flow_id in pending)
    days = [(now.date() - timedelta(days=offset)) for offset in range(13, -1, -1)]

    items = []
    for flow in flows:
        flow_runs = sorted(by_flow.get(flow.id, []), key=lambda run: _aware(run.created_at))
        finished = [run for run in flow_runs if run.status in FINISHED]
        succeeded = sum(1 for run in finished if run.status == "succeeded")
        per_day = Counter(_aware(run.created_at).date() for run in flow_runs)
        last = flow_runs[-1] if flow_runs else None
        items.append(
            {
                **FlowInsights(session, flow).flow_header(),
                "runs": len(flow_runs),
                "success_rate": _rate(succeeded, len(finished)),
                "avg_cost_usd": round(statistics.fmean([run.total_cost_usd for run in flow_runs]), 4)
                if flow_runs
                else 0.0,
                "total_cost_usd": round(sum(run.total_cost_usd for run in flow_runs), 4),
                "p50_duration_ms": round(_percentile([run.duration_ms for run in finished if run.duration_ms], 0.5)),
                "last_status": last.status if last else None,
                "pending_approvals": pending_by_flow.get(flow.id, 0),
                "activity": [per_day.get(day, 0) for day in days],
                "validation_valid": bool((flow.validation_result or {}).get("valid")),
            }
        )

    finished_all = [run for run in runs if run.status in FINISHED]
    return {
        "window_days": window_days,
        "totals": {
            "flows": len(flows),
            "published": sum(1 for flow in flows if flow.status == "published"),
            "scheduled": sum(1 for flow in flows if (flow.schedule or {}).get("enabled")),
            "api_enabled": sum(1 for flow in flows if flow.webhook_token_hash),
            "runs": len(runs),
            "success_rate": _rate(sum(1 for run in finished_all if run.status == "succeeded"), len(finished_all)),
            "total_cost_usd": round(sum(run.total_cost_usd for run in runs), 4),
            "pending_approvals": len(pending),
            "hours_saved": round(
                sum(run.completed_step_count for run in runs if run.status == "succeeded")
                * MINUTES_SAVED_PER_STEP
                / 60,
                1,
            ),
        },
        "flows": items,
    }
