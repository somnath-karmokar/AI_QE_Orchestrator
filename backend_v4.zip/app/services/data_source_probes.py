"""Does this data source actually answer?

A connection test is the one moment the platform makes a network request to an
address a *tenant* chose. That is server-side request forgery by construction,
so this module treats every submitted host as hostile:

  * the address is resolved and every resulting IP is checked before anything
    connects, so a hostname that resolves to a private address is refused even
    though it looked public;
  * loopback, link-local, private and reserved ranges are all refused, which
    covers the cloud metadata endpoint at 169.254.169.254 -- the usual target,
    because it hands out the platform's own credentials;
  * redirects are not followed, since a permitted host that redirects to an
    internal one would otherwise walk straight through the check;
  * the timeout is short and fixed, so the test cannot be used to hold
    connections open or to time internal hosts.

The second rule here is honesty. A probe reports only what it actually checked:
a TCP connection proves something is listening, not that the credentials work,
and the result says so rather than showing a green tick the check did not earn.
"""

from __future__ import annotations

import ipaddress
import socket
from typing import Any
from urllib.parse import urlparse

from app.core.config import settings
from app.core.crypto import SecretBundle
from app.core.logging import get_logger
from app.models.datasource import DataSource

logger = get_logger(__name__)

# Short on purpose: a probe is interactive, and a long timeout is what makes
# port scanning through this endpoint worthwhile.
TIMEOUT_SECONDS = 5.0

DEFAULT_PORTS = {
    "postgres": 5432,
    "mysql": 3306,
    "sqlserver": 1433,
    "oracle": 1521,
    "mongodb": 27017,
    "elasticsearch": 9200,
}


class AddressRefused(Exception):
    """The address is one this platform will not connect to."""


def _check_ip(address: str) -> None:
    ip = ipaddress.ip_address(address)
    if (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
    ):
        raise AddressRefused(
            f"{address} is a private or reserved address. A data source must point at a "
            "reachable external system, not at this platform's own network."
        )


def resolve_public(host: str, port: int) -> list[tuple[Any, ...]]:
    """Resolve a host, refusing it unless *every* address it yields is public.

    Every address, not the first: a name that returns one public and one
    internal address would otherwise pass the check and then connect to the
    internal one.
    """
    if not host:
        raise AddressRefused("No host was supplied.")

    # An IP literal never needs resolving, and checking it directly avoids a
    # DNS lookup for an address that is about to be refused anyway.
    try:
        _check_ip(host)
        return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (host, port))]
    except ValueError:
        pass  # not a literal; resolve it below

    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as error:
        raise AddressRefused(f"'{host}' could not be resolved ({error.strerror or error}).") from None

    for info in infos:
        _check_ip(info[4][0])
    return infos


def _tcp_probe(host: str, port: int) -> dict[str, Any]:
    try:
        infos = resolve_public(host, port)
    except AddressRefused as refused:
        return {"ok": False, "check": "address", "detail": str(refused)}

    last_error = "no address answered"
    for family, socktype, proto, _canon, sockaddr in infos:
        try:
            with socket.socket(family, socktype, proto) as sock:
                sock.settimeout(TIMEOUT_SECONDS)
                sock.connect(sockaddr)
            return {
                "ok": True,
                "check": "tcp",
                "detail": f"A service is listening on {host}:{port}.",
                # Said plainly, because a green tick that seems to mean more
                # than it does is worse than no test at all.
                "proves": "The host is reachable. The credentials were not used.",
            }
        except (TimeoutError, OSError) as error:
            last_error = str(error)
    return {"ok": False, "check": "tcp", "detail": f"Could not connect to {host}:{port} -- {last_error}"}


def _http_probe(url: str, secrets: SecretBundle) -> dict[str, Any]:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return {"ok": False, "check": "url", "detail": "The URL must start with http:// or https://."}

    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        resolve_public(parsed.hostname or "", port)
    except AddressRefused as refused:
        return {"ok": False, "check": "address", "detail": str(refused)}

    import httpx  # noqa: PLC0415

    headers = {"User-Agent": "AI-QE-Orchestrator/data-source-probe"}
    if token := (secrets.get("bearer_token") or secrets.get("api_token")):
        headers["Authorization"] = f"Bearer {token}"
    elif key := secrets.get("api_key"):
        headers["X-API-Key"] = key

    try:
        # follow_redirects stays off: a redirect is how an allowed host sends
        # this request somewhere the address check already refused.
        response = httpx.get(
            url, headers=headers, timeout=TIMEOUT_SECONDS, follow_redirects=False
        )
    except httpx.HTTPError as error:
        return {"ok": False, "check": "http", "detail": f"The request failed: {error}"}

    authenticated = bool(headers.get("Authorization") or headers.get("X-API-Key"))
    if response.status_code in (401, 403):
        return {
            "ok": False,
            "check": "http",
            "detail": f"The endpoint answered {response.status_code}; the credentials were rejected.",
        }
    return {
        "ok": response.status_code < 500,
        "check": "http",
        "detail": f"The endpoint answered {response.status_code}.",
        "proves": (
            "The endpoint is reachable and accepted the credentials."
            if authenticated
            else "The endpoint is reachable. No credentials were sent."
        ),
    }


def probe(source: DataSource, secrets: SecretBundle) -> dict[str, Any]:
    """Test one data source, as far as its kind allows."""
    config = source.config or {}

    if settings.demo_mode and not config.get("host") and not config.get("base_url"):
        # The seeded demo sources point at nothing, and inventing a green tick
        # for them would make the screen lie about every other source too.
        return {
            "ok": False,
            "check": "none",
            "detail": "This demo data source has no address configured, so nothing was tested.",
        }

    if source.kind in DEFAULT_PORTS:
        host = config.get("host", "")
        port = int(config.get("port") or DEFAULT_PORTS[source.kind])
        return _tcp_probe(host, port)

    if source.kind in ("rest_api", "graphql", "jira", "confluence"):
        url = config.get("base_url") or config.get("endpoint") or ""
        return _http_probe(url, secrets)

    if source.kind == "file_upload":
        return {
            "ok": True,
            "check": "none",
            "detail": "Uploaded files need no connection.",
            "proves": "Nothing was contacted.",
        }

    # S3, GCS, Azure Blob, Snowflake and the rest need their vendor SDKs to
    # test properly. Saying so is better than a check that always passes.
    return {
        "ok": False,
        "check": "unsupported",
        "detail": (
            f"A connection test for '{source.kind}' is not implemented in this build, "
            "so this source is left unverified rather than reported as connected."
        ),
    }
