"""The Wickes 15-dimension weighted risk model.

Specified in `requirement_docs_2/AI QE Use Case_Change Impact Risk Analyzer_for
Somnath.pptx` (slides 1-3) and `image (13).png`. This module is a literal,
testable implementation of that formula -- not our platform's generic impact
score (`app.agents.implementations.planning.IMPACT_FACTOR_WEIGHTS`), which
stays as it is for every other project. This one is specific to one client's
methodology and lives apart from it on purpose.

The formula, exactly as specified:

  * 15 dimensions, each scored 1 (low) to 5 (high), each carrying a weight of
    x1, x2 or x3 (`DIMENSIONS`). Weighted score = Σ(dimension score × weight).
    Sum of weights is 28, so the reachable range is 28-140. The deck's own
    band table states "24-140" for the same score; that 4-point gap is an
    inconsistency in the source slide, not a mechanic to reproduce -- the band
    *boundaries* are what govern coverage and are followed exactly (`BANDS`).
  * A veto rule: a 5 on Business Criticality, Security/data privacy or
    Peak-trading/freeze exposure escalates to the next band up, regardless of
    total (`apply_veto`).
  * A separate confidence/control modifier, Probability + Impact - Confidence
    - Control (each 1-5, so -8..+8). The worked example (slide 3) computes a
    modifier of +2 and bands the run on the base weighted score of 124 alone
    -- the modifier is reported as a directional read ("risk elevated"), not
    multiplied into the banded score. Multiplying would have taken 124 to 248,
    which the deck does not do anywhere. `net_modifier` follows the worked
    example's mechanics, not the ambiguous "×" in slide 1's headline formula.

`score_apple_pay_worked_example()` reproduces slide 3's own numbers
(124/140, Critical/P1, veto on Business Criticality & Security) exactly, and
`tests/test_wickes_risk_model.py` holds the module to it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# The 15 dimensions
# ---------------------------------------------------------------------------

# (key, label, weight, low-anchor, high-anchor) -- anchors are the deck's own
# 1-and-5 descriptions (slide 2), shown to a reviewer so a score of 5 means
# the same thing every time it is given, by a person or by the heuristic below.
DIMENSIONS: tuple[tuple[str, str, int, str, str], ...] = (
    ("business_criticality", "Business criticality", 3, "Low operational impact", "Revenue / customer-journey critical"),
    ("customer_journey_impact", "Customer journey impact", 3, "Localised function", "End-to-end P1 customer journey"),
    ("systems_affected", "Systems affected", 2, "Single application", "Multiple integrated platforms"),
    ("integration_complexity", "Integration complexity", 2, "Few interfaces", "Interconnected ecosystem"),
    ("technical_complexity", "Technical complexity", 2, "Simple, understood change", "Complex / novel technical change"),
    ("third_party_dependency", "Third-party / vendor dependency", 2, "Fully TCS-owned", "Multiple external vendors"),
    ("peak_trading_exposure", "Peak-trading / freeze exposure", 2, "Outside peak", "Easter / Christmas or freeze"),
    ("security_data_privacy", "Security / data privacy", 2, "No PII / payment data", "PCI-DSS / GDPR / payment data"),
    ("regulatory_impact", "Regulatory impact", 2, "No regulatory exposure", "PCI-DSS / GDPR / audit scope"),
    ("data_change", "Data change", 2, "Minimal", "Migration or transformation"),
    ("legacy_tech_debt", "Legacy / tech-debt exposure", 2, "Modern, documented", "Legacy / tech-debt, low coverage"),
    ("environment_readiness", "Environment & test data readiness", 1, "Stable env, data ready", "Unstable / shared, data gaps"),
    ("historical_defect_rate", "Historical defect rate", 1, "Stable component", "Frequently changing hotspot"),
    ("rollback_recoverability", "Rollback / recoverability", 1, "Simple proven rollback", "Irreversible / hard to roll back"),
    ("deployment_scope", "Deployment scope", 1, "Single team", "Multi-programme, multi-domain"),
)
DIMENSION_KEYS = tuple(d[0] for d in DIMENSIONS)
WEIGHT_BY_KEY = {d[0]: d[2] for d in DIMENSIONS}
TOTAL_WEIGHT = sum(d[2] for d in DIMENSIONS)  # 28
MIN_SCORE = TOTAL_WEIGHT * 1  # 28
MAX_SCORE = TOTAL_WEIGHT * 5  # 140

# Any 5 here auto-escalates the band (slide 1 "Veto / Override Rule").
VETO_DIMENSIONS = ("business_criticality", "security_data_privacy", "peak_trading_exposure")

# (band, low, high, coverage commitment) -- slide 1 table 4 / slide 2 table 2,
# reconciled (slide 2's "High/P2" reads 66-95 like slide 1; both agree).
BANDS: tuple[tuple[str, int, int, str], ...] = (
    (
        "Critical / P1", 96, 140,
        "100% automated E2E on critical journeys - cross-system integration, data "
        "integrity, performance, security & operational readiness.",
    ),
    (
        "High / P2", 66, 95,
        "Full P2 journey automation, regression across all impacted domains, "
        "targeted NFT & security scans.",
    ),
    (
        "Medium / P3", 42, 65,
        "AI-selected impacted regression, interface & API validation, "
        "exploratory testing on the change.",
    ),
    (
        "Low", 24, 41,
        "Change verification plus smoke of directly impacted automated tests - "
        "fast release path.",
    ),
)
BAND_ORDER = [b[0] for b in BANDS]  # highest first -- what "escalate" walks toward

CHANGE_TYPES = ("New", "Changed", "Migration / Conversion", "Third-party", "Critical")


def band_for(score: int) -> str:
    """Which band a score falls in. Below the lowest band's floor is still Low
    (the demo cannot hand the pipeline a score under 28, but a CR entered by
    hand always could) and above the top is still Critical/P1 -- clamped
    rather than left undefined, since a route with no band is the one route
    the veto rule and the coverage table cannot act on."""
    for band, low, high, _coverage in BANDS:
        if low <= score <= high:
            return band
    return BAND_ORDER[0] if score > BANDS[0][2] else BAND_ORDER[-1]


def coverage_for(band: str) -> str:
    return next(coverage for name, _lo, _hi, coverage in BANDS if name == band)


def apply_veto(scores: dict[str, int], band: str) -> tuple[str, list[str]]:
    """Escalate one band up for every veto dimension scoring 5, and say which."""
    triggered = [key for key in VETO_DIMENSIONS if scores.get(key, 0) >= 5]
    if not triggered:
        return band, triggered
    index = BAND_ORDER.index(band)
    escalated = BAND_ORDER[max(0, index - 1)]
    return escalated, triggered


def net_modifier(*, probability: int, impact: int, confidence: int, control: int) -> int:
    """Probability + Impact - Confidence - Control. Reported alongside the
    banded score as a directional read (see module docstring); it does not
    change the band."""
    return probability + impact - confidence - control


def veto_narrative(result: "RiskAssessment") -> str:
    """The one correct English sentence for what the veto rule did, used by
    every presentation layer (the demo script, the platform agent) so neither
    can independently get it wrong.

    'Escalated' is only true when the band actually moved. A change that was
    already Critical/P1 on its base score and then trips the veto rule (as the
    client's own worked example does) did not move anywhere -- the veto
    confirms the band rather than raising it, and saying "escalated to
    Critical/P1" when it started at Critical/P1 reads as a move that did not
    happen.
    """
    if not result.veto_triggered:
        return f"No veto dimension scored 5; band stands at {result.band}."
    dims = ", ".join(result.veto_triggered)
    if result.band == result.band_before_veto:
        return (
            f"Veto rule triggered on {dims} (each scored 5) -- already at the top band "
            f"({result.band}) on its base score, so the veto confirms it rather than raising it."
        )
    return f"Veto rule triggered on {dims} (each scored 5) -- escalated from {result.band_before_veto} to {result.band}."


def modifier_reading(modifier: int) -> str:
    if modifier > 0:
        return "risk elevated"
    if modifier < 0:
        return "risk contained"
    return "risk neutral"


@dataclass(slots=True)
class DimensionAssessment:
    key: str
    label: str
    weight: int
    score: int
    weighted: int
    rationale: str


@dataclass(slots=True)
class RiskAssessment:
    change_id: str
    change_title: str
    dimensions: list[DimensionAssessment]
    base_score: int
    max_score: int
    band_before_veto: str
    band: str
    veto_triggered: list[str]
    modifier: int
    modifier_reading: str
    coverage_commitment: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "change_id": self.change_id,
            "change_title": self.change_title,
            "dimensions": [
                {
                    "key": d.key,
                    "label": d.label,
                    "weight": d.weight,
                    "score": d.score,
                    "weighted": d.weighted,
                    "rationale": d.rationale,
                }
                for d in self.dimensions
            ],
            "base_score": self.base_score,
            "max_score": self.max_score,
            "band_before_veto": self.band_before_veto,
            "band": self.band,
            "veto_triggered": self.veto_triggered,
            "modifier": self.modifier,
            "modifier_reading": self.modifier_reading,
            "coverage_commitment": self.coverage_commitment,
        }


def assess(
    *,
    change_id: str,
    change_title: str,
    scores: dict[str, int],
    rationale: dict[str, str] | None = None,
    probability: int,
    impact: int,
    confidence: int,
    control: int,
) -> RiskAssessment:
    """Score, band, veto and modifier -- the SCORE and BAND steps of the pipeline."""
    missing = [key for key in DIMENSION_KEYS if key not in scores]
    if missing:
        raise ValueError(f"Missing dimension score(s): {missing}")
    out_of_range = {k: v for k, v in scores.items() if not (1 <= v <= 5)}
    if out_of_range:
        raise ValueError(f"Dimension score(s) out of 1-5 range: {out_of_range}")

    rationale = rationale or {}
    dims = [
        DimensionAssessment(
            key=key, label=label, weight=weight,
            score=scores[key], weighted=scores[key] * weight,
            rationale=rationale.get(key, ""),
        )
        for key, label, weight, _lo, _hi in DIMENSIONS
    ]
    base_score = sum(d.weighted for d in dims)
    pre_veto_band = band_for(base_score)
    final_band, triggered = apply_veto(scores, pre_veto_band)
    modifier = net_modifier(probability=probability, impact=impact, confidence=confidence, control=control)

    return RiskAssessment(
        change_id=change_id,
        change_title=change_title,
        dimensions=dims,
        base_score=base_score,
        max_score=MAX_SCORE,
        band_before_veto=pre_veto_band,
        band=final_band,
        veto_triggered=triggered,
        modifier=modifier,
        modifier_reading=modifier_reading(modifier),
        coverage_commitment=coverage_for(final_band),
    )


# ---------------------------------------------------------------------------
# Heuristic dimension scoring: derives the 1-5 scores from a change's own
# text, the way the platform's diagram claims ("AI ... Risk score assigned")
# rather than requiring an analyst to have already scored all 15 by hand.
#
# Deliberately keyword-driven and deterministic, not an LLM call: a client
# demo has to reproduce the same score every run, on stage, with no network
# dependency. It is the same shape of signal a real system would use --
# PCI/GDPR mentions, peak-trading dates, vendor names, migration language --
# just without a model in the loop. Swapping in an LLM-backed scorer later
# only has to keep this function's signature.
# ---------------------------------------------------------------------------

_KEYWORDS: dict[str, dict[int, tuple[str, ...]]] = {
    "business_criticality": {
        5: ("checkout", "payment", "order", "revenue", "basket", "cart"),
        3: ("account", "pricing", "promotion", "loyalty"),
    },
    "customer_journey_impact": {
        5: ("checkout", "payment", "delivery", "click and collect", "click & collect", "p1 journey", "end-to-end"),
        3: ("search", "browse", "wishlist", "store locator"),
    },
    "systems_affected": {
        5: ("hybris", "sap commerce", "multiple platform", "cross-system", "integration hub"),
        3: ("two system", "second system", "downstream"),
    },
    "integration_complexity": {
        5: ("interconnected", "multiple interface", "orchestrat"),
        3: ("api", "webhook", "interface"),
    },
    "technical_complexity": {
        5: ("novel", "rearchitect", "rewrite", "complex", "refactor core"),
        3: ("moderate", "extend", "enhance"),
    },
    "third_party_dependency": {
        5: ("apple pay", "google pay", "paypal", "adyen", "worldpay", "vendor", "third-party", "third party", "supplier"),
        3: ("external api", "partner"),
    },
    "peak_trading_exposure": {
        5: ("christmas", "easter", "peak", "black friday", "freeze", "boxing day"),
        3: ("seasonal", "promotion period"),
    },
    "security_data_privacy": {
        5: ("pci", "payment card", "card data", "auth", "3d secure", "3ds", "gdpr", "pii", "personal data"),
        3: ("login", "session", "token"),
    },
    "regulatory_impact": {
        5: ("pci-dss", "pci dss", "gdpr", "audit scope", "regulatory"),
        3: ("compliance", "accessibility", "wcag"),
    },
    "data_change": {
        5: ("migration", "data migration", "conversion", "transform", "schema change"),
        3: ("data model", "new field", "mapping"),
    },
    "legacy_tech_debt": {
        5: ("legacy", "deprecated", "tech debt", "technical debt", "low coverage", "undocumented"),
        3: ("ageing", "aging", "outdated"),
    },
    "environment_readiness": {
        5: ("unstable environment", "shared environment", "data gap", "no test data"),
        3: ("shared env", "limited data"),
    },
    "historical_defect_rate": {
        5: ("frequently changing", "hotspot", "repeat defect", "recurring defect", "known issue"),
        3: ("occasional defect",),
    },
    "rollback_recoverability": {
        5: ("irreversible", "no rollback", "hard to roll back", "one-way migration"),
        3: ("manual rollback", "partial rollback"),
    },
    "deployment_scope": {
        5: ("multi-programme", "multi programme", "multi-domain", "cross-team", "multiple team"),
        3: ("two team", "shared release"),
    },
}


def _score_dimension(key: str, text: str) -> tuple[int, str]:
    lowered = text.lower()
    tiers = _KEYWORDS.get(key, {})
    for level in (5, 3):
        for phrase in tiers.get(level, ()):
            if phrase in lowered:
                return level, f"matched '{phrase}'"
    return 1, "no risk signal found in the change text"


def suggest_scores(change_text: str) -> tuple[dict[str, int], dict[str, str]]:
    """Derive all 15 dimension scores from a change request's free text.

    This is the AI-assist half of the SCORE step: a first pass a reviewer
    corrects, not a black box. Every score carries the phrase that produced it
    (`rationale`), so "why did this get a 5" always has an answer in the text
    that was fed in, never in a model's head.
    """
    scores: dict[str, int] = {}
    rationale: dict[str, str] = {}
    for key in DIMENSION_KEYS:
        score, why = _score_dimension(key, change_text)
        scores[key] = score
        rationale[key] = why
    return scores, rationale


# ---------------------------------------------------------------------------
# The worked example from slide 3, as a fixture other code (and tests) can
# call by name rather than re-typing the fifteen numbers.
# ---------------------------------------------------------------------------


def apple_pay_worked_example_scores() -> dict[str, int]:
    """The exact per-dimension scores slide 3 lists for the Apple Pay change."""
    return {
        "business_criticality": 5,
        "customer_journey_impact": 5,
        "systems_affected": 5,
        "integration_complexity": 5,
        "technical_complexity": 4,
        "third_party_dependency": 5,
        "peak_trading_exposure": 4,
        "security_data_privacy": 5,
        "regulatory_impact": 5,
        "data_change": 3,
        "legacy_tech_debt": 4,
        "environment_readiness": 4,
        "historical_defect_rate": 4,
        "rollback_recoverability": 3,
        "deployment_scope": 3,
    }


def score_apple_pay_worked_example() -> RiskAssessment:
    """Reproduces slide 3's numbers exactly: 124/140, Critical/P1, veto on
    Business Criticality & Security, modifier +2 (risk elevated)."""
    return assess(
        change_id="CR-DEMO-APPLEPAY",
        change_title="Hybris Checkout & Payment - Apple Pay auth change",
        scores=apple_pay_worked_example_scores(),
        probability=4,
        impact=5,
        confidence=4,
        control=3,
    )
