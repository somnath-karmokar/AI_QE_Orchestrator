"""How a third party would call one agent or one flow.

The integration API is discoverable once you hold a key -- the catalog and the
OpenAPI document describe everything that key may invoke. This is the other
direction: an operator looking at *one* agent or flow in the web app, asking
"what is the endpoint for this, and who can already call it?"

Two things make the answer trustworthy rather than decorative:

* **Who can call it** is computed by asking the real authorisation rules
  (`resolve_flow`, `resolve_agent`) about every key in the project, so this
  panel cannot advertise access the API would then refuse.
* **Why it cannot be called** is stated when that is the case -- a draft flow,
  an unpublished agent -- along with what to do about it, rather than showing an
  endpoint that would answer 404.

Nothing here exposes a secret: a key is identified by its name and the last few
characters of its token, which is all the operator UI ever shows.
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.agent import Agent
from app.models.flow import AgentFlow
from app.models.integration import IntegrationClient
from app.services.integration import resolve_agent, resolve_flow
from app.services.mcp_tools import tool_name

# A placeholder per JSON type, so the sample body is the right shape even when
# the schema declares no default.
_SAMPLE_BY_TYPE: dict[str, Any] = {
    "string": "...",
    "integer": 0,
    "number": 0,
    "boolean": True,
    "array": [],
    "object": {},
}


def _sample_body(schema: dict[str, Any]) -> dict[str, Any]:
    """A request body worth pasting: every required input, plus declared defaults."""
    properties: dict[str, Any] = schema.get("properties") or {}
    required = set(schema.get("required") or [])

    inputs: dict[str, Any] = {}
    for name, definition in properties.items():
        if not isinstance(definition, dict):
            continue
        if "default" in definition and definition["default"] is not None:
            inputs[name] = definition["default"]
        elif name in required:
            inputs[name] = _SAMPLE_BY_TYPE.get(definition.get("type", "string"), "...")

    return {"inputs": inputs}


def _curl(url: str, body: dict[str, Any]) -> str:
    """The call as a one-liner somebody can paste into a terminal."""
    # Six spaces, so the closing brace lines up under the opening one: the
    # snippet is meant to be read as well as pasted.
    payload = json.dumps(body, indent=2)
    indented = payload.replace("\n", "\n" + " " * 6)
    return (
        f"curl -X POST {url} \\\n"
        f'  -H "X-API-Key: $QE_API_KEY" \\\n'
        f'  -H "X-Idempotency-Key: $(uuidgen)" \\\n'
        f'  -H "Content-Type: application/json" \\\n'
        f"  -d '{indented}'"
    )


def _keys_that_can_call(
    session: Session,
    project_id: str,
    *,
    flow_id: str | None = None,
    agent_key: str | None = None,
) -> list[dict[str, Any]]:
    """Every live key in this project that the real rules would let through."""
    clients = (
        session.execute(
            select(IntegrationClient).where(
                IntegrationClient.project_id == project_id,
                IntegrationClient.is_deleted.is_(False),
                IntegrationClient.is_active.is_(True),
            )
        )
        .scalars()
        .all()
    )

    allowed: list[dict[str, Any]] = []
    for client in clients:
        # Expiry as well as revocation: an expired key is refused at the door,
        # so listing it here would promise access that does not exist.
        if not client.is_usable():
            continue
        if flow_id is not None:
            if resolve_flow(session, client, flow_id) is None:
                continue
            project_wide = flow_id not in (client.allowed_flow_ids or [])
        else:
            if resolve_agent(session, client, agent_key or "") is None:
                continue
            project_wide = (agent_key or "") not in (client.allowed_agent_keys or [])

        allowed.append(
            {
                "name": client.name,
                "platform": client.platform,
                # The last few characters only -- never the token.
                "token_hint": client.token_hint,
                "grant": "project-wide" if project_wide else "named explicitly",
                "expires_at": client.expires_at.isoformat() if client.expires_at else None,
            }
        )
    return sorted(allowed, key=lambda entry: entry["name"])


def _envelope(
    *,
    kind: str,
    identifier: str,
    name: str,
    path: str,
    scope: str,
    input_schema: dict[str, Any],
    mcp_tool: str,
    base_url: str,
    keys: list[dict[str, Any]],
    available: bool,
    unavailable_reason: str | None,
) -> dict[str, Any]:
    prefix = settings.api_prefix
    url = f"{base_url.rstrip('/')}{prefix}{path}"
    body = _sample_body(input_schema)

    return {
        "kind": kind,
        "id": identifier,
        "name": name,
        # Whether a third party could call this right now, and if not, why.
        "available": available,
        "unavailable_reason": unavailable_reason,
        "endpoint": {"method": "POST", "path": f"{prefix}{path}", "url": url},
        "authentication": {
            "scheme": "api_key",
            "header": "X-API-Key",
            "scope_required": scope,
            "issued_by": "an operator, through POST /api/v1/integration-clients",
        },
        "input_schema": input_schema,
        "example": {"body": body, "curl": _curl(url, body)},
        "polling": {
            "note": "202 means accepted, not finished. Poll until is_terminal is true.",
            "path": f"{prefix}/integration/runs/{{run_id}}",
        },
        "mcp": {
            "tool": mcp_tool,
            "endpoint": f"POST {prefix}/mcp",
            "note": "The same capability for a calling agent rather than a pipeline.",
        },
        "documentation": {
            "quickstart": "docs/integration/QUICKSTART.md",
            "openapi": f"{prefix}/integration/openapi.json",
            "swagger": "/api/integration-docs",
        },
        "keys": keys,
    }


def flow_api_access(session: Session, flow: AgentFlow, *, base_url: str) -> dict[str, Any]:
    """The third-party contract for one flow."""
    from app.services.integration import _flow_descriptor  # noqa: PLC0415

    descriptor = _flow_descriptor(flow)
    keys = _keys_that_can_call(session, flow.project_id, flow_id=flow.id)

    published = flow.status == "published"
    reason = None
    if not published and not keys:
        reason = (
            "This flow is a draft, so a project-wide grant does not reach it. Publish it, or "
            "issue a key that names this flow explicitly."
        )
    elif not keys:
        reason = "No API key in this project can call it yet. Issue one, or widen an existing one."

    return _envelope(
        kind="flow",
        identifier=flow.id,
        name=flow.name,
        path=f"/integration/flows/{flow.id}/runs",
        scope="flows:run",
        input_schema=descriptor["input_schema"],
        mcp_tool=tool_name("run_flow", flow.key),
        base_url=base_url,
        keys=keys,
        available=bool(keys),
        unavailable_reason=reason,
    )


def agent_api_access(
    session: Session, agent: Agent, *, project_id: str, base_url: str
) -> dict[str, Any]:
    """The third-party contract for one agent, as seen from one project.

    The project comes from the caller rather than the agent: a built-in belongs
    to no project (`project_id` is NULL) and is reachable from all of them, so
    "which keys can call this" only means something once a project is named.
    """
    key = agent.handler_key or agent.key
    keys = _keys_that_can_call(session, project_id, agent_key=key)

    reason = None
    if not agent.is_published:
        reason = "This agent is not published, so no key can invoke it. Publish it first."
    elif not keys:
        reason = "No API key in this project can call it yet. Issue one, or widen an existing one."

    return _envelope(
        kind="agent",
        identifier=key,
        name=agent.name,
        path=f"/integration/agents/{key}/runs",
        scope="agents:run",
        input_schema=agent.input_schema or {"type": "object", "properties": {}},
        mcp_tool=tool_name("run_agent", key),
        base_url=base_url,
        keys=keys,
        available=bool(keys) and agent.is_published,
        unavailable_reason=reason,
    )
