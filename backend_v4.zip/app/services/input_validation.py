"""Checking that a caller's data is the data the flow will actually run on.

The failure this prevents is quiet and therefore expensive. A calling platform
sends `changed_moduls` instead of `changed_modules`; the key does not match
anything the flow declares, so the flow runs on its **default** value and
returns a confident, green result about the wrong thing. Nobody is told. The
caller believes it tested what it asked for.

An error is a much better outcome than a wrong answer, so unknown keys are
refused rather than ignored, with a suggestion when one is close enough to be an
obvious typo.

A deliberately small JSON Schema subset -- types, `required`, `enum`, `format`
where it is cheap -- because that is all a flow variable or an agent input
schema uses here. Adding a dependency to check four things would be a poor
trade, and a partial checker that silently passed what it could not read would
be worse than none.
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import Any

# JSON Schema type names mapped to what Python actually produces from JSON.
_TYPES: dict[str, tuple[type, ...]] = {
    "string": (str,),
    "integer": (int,),
    "number": (int, float),
    "boolean": (bool,),
    "array": (list,),
    "object": (dict,),
}


@dataclass(slots=True)
class InputError:
    field: str
    message: str
    suggestion: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"field": self.field, "message": self.message}
        if self.suggestion:
            payload["did_you_mean"] = self.suggestion
        return payload


@dataclass(slots=True)
class ValidationOutcome:
    errors: list[InputError] = field(default_factory=list)
    # What will actually be used, once declared defaults are filled in. Returned
    # to the caller so "run it with my data" is verifiable rather than assumed.
    effective: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_details(self) -> dict[str, Any]:
        return {"invalid_inputs": [error.to_dict() for error in self.errors]}


def _type_of(value: Any) -> str:  # noqa: ANN401
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "null"


def _matches(value: Any, expected: str) -> bool:  # noqa: ANN401
    allowed = _TYPES.get(expected)
    if allowed is None:
        return True  # an unrecognised type constrains nothing
    # A bool is an int in Python; JSON Schema does not agree.
    if expected in {"integer", "number"} and isinstance(value, bool):
        return False
    return isinstance(value, allowed)


def validate_inputs(
    schema: dict[str, Any] | None,
    inputs: dict[str, Any] | None,
    *,
    defaults: dict[str, Any] | None = None,
    allow_unknown: bool = False,
) -> ValidationOutcome:
    """Check what a caller sent against what the flow or agent declares.

    `defaults` are the flow's own variables, used both to fill in what the
    caller omitted and to recognise a near-miss key as a typo.
    """
    schema = schema or {}
    inputs = inputs or {}
    defaults = defaults or {}
    properties: dict[str, Any] = schema.get("properties") or {}
    outcome = ValidationOutcome()

    known = set(properties) | set(defaults)

    # 1. Unknown keys. Refused, not ignored -- this is the quiet failure.
    if not allow_unknown:
        for name in inputs:
            if name in known:
                continue
            close = difflib.get_close_matches(name, sorted(known), n=1, cutoff=0.7)
            outcome.errors.append(
                InputError(
                    field=name,
                    message=(
                        f"'{name}' is not an input this accepts. Sending it would have no "
                        f"effect, and the run would silently use the declared default instead."
                    ),
                    suggestion=close[0] if close else None,
                )
            )

    # 2. Required fields the caller left out and nothing else supplies.
    for name in schema.get("required") or []:
        if name in inputs or name in defaults:
            continue
        outcome.errors.append(InputError(field=name, message=f"'{name}' is required."))

    # 3. Declared constraints on what was sent.
    for name, value in inputs.items():
        rules = properties.get(name)
        if not isinstance(rules, dict):
            continue

        expected = rules.get("type")
        if isinstance(expected, str) and not _matches(value, expected):
            outcome.errors.append(
                InputError(
                    field=name,
                    message=(
                        f"'{name}' should be {expected}, but {_type_of(value)} was sent "
                        f"({value!r})."
                    ),
                )
            )
            continue

        choices = rules.get("enum")
        if isinstance(choices, list) and value not in choices:
            close = difflib.get_close_matches(str(value), [str(c) for c in choices], n=1, cutoff=0.6)
            outcome.errors.append(
                InputError(
                    field=name,
                    message=f"'{name}' must be one of: {', '.join(str(c) for c in choices)}.",
                    suggestion=close[0] if close else None,
                )
            )
            continue

        if expected == "array":
            item_rules = rules.get("items")
            item_type = item_rules.get("type") if isinstance(item_rules, dict) else None
            if isinstance(item_type, str):
                for index, item in enumerate(value):
                    if not _matches(item, item_type):
                        outcome.errors.append(
                            InputError(
                                field=f"{name}[{index}]",
                                message=f"Every item of '{name}' should be {item_type}.",
                            )
                        )

    outcome.effective = {**defaults, **inputs}
    return outcome


def describe_effective(
    effective: dict[str, Any], inputs: dict[str, Any] | None
) -> dict[str, Any]:
    """What the run will use, and where each value came from.

    Returned on every accepted start, so a caller can confirm the platform ran
    on the data it sent rather than taking it on trust.
    """
    supplied = set(inputs or {})
    return {
        name: {
            "value": value,
            "source": "caller" if name in supplied else "flow_default",
        }
        for name, value in sorted(effective.items())
        if not name.startswith("_")
    }
