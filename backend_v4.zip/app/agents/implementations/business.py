"""UAT and business-facing agents (catalogue entries 22-23)."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select

from app.agents.scoping import owned_execution_test
from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.models.defect import Defect, DefectAnalysis
from app.models.testing import Requirement, TestCase
from app.vectorstore.base import COLLECTION_DEFECTS


class UATAssistantAgent(BaseAgent):
    key = "uat-assistant"
    name = "UAT Assistant"
    category = "UAT"
    description = "Turns test cases into business-language UAT scripts with sign-off criteria."
    capability = "generation"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "UserCheck"
    supported_tools = ["knowledge", "jira"]
    goal = "Let business users validate a release without reading technical test cases."
    system_instructions = (
        "You are a UAT coordinator writing for business users, not engineers. Use plain business language, "
        "avoid technical jargon and system internals, and make each step something a business user can perform."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "module": {"type": "string"},
            "requirement_key": {"type": "string"},
            "limit": {"type": "integer", "default": 8},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        statement = select(TestCase).where(
            TestCase.project_id == ctx.project_id,
            TestCase.is_deleted.is_(False),
            TestCase.priority.in_(["critical", "high"]),
        )
        if inputs.get("module"):
            statement = statement.where(TestCase.module == inputs["module"])

        requirement = None
        if inputs.get("requirement_key"):
            requirement = ctx.session.execute(
                select(Requirement).where(
                    Requirement.project_id == ctx.project_id,
                    Requirement.external_key == inputs["requirement_key"],
                )
            ).scalar_one_or_none()
            if requirement is not None:
                statement = statement.where(TestCase.requirement_id == requirement.id)

        cases = list(
            ctx.session.execute(statement.limit(int(inputs.get("limit", 8)))).scalars().all()
        )
        return {"cases": cases, "requirement": requirement, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        cases: list[TestCase] = context.get("cases", [])
        listing = "\n".join(f"- {case.key} {case.title} ({case.module})" for case in cases)
        return [
            self.system_message(ctx),
            self.task_message("agent.uat-assistant.rewrite", test_cases=listing or "none"),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        cases: list[TestCase] = context.get("cases", [])
        if not cases:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No high-priority test cases were available to convert into UAT scripts.",
                "recommendations": [{"action": "Design test cases before preparing UAT."}],
                "next_action": "design_tests",
            }

        scripts: list[dict[str, Any]] = []
        for index, case in enumerate(cases, start=1):
            scripts.append(
                {
                    "uat_id": f"UAT-{index:03d}",
                    "test_case_key": case.key,
                    "title": self._business_title(case.title),
                    "business_objective": self._business_objective(case),
                    "module": case.module,
                    "who": "Business user with standard access to the application.",
                    "steps": self._business_steps(case),
                    "sign_off_criteria": self._sign_off(case),
                    "estimated_minutes": max(3, len(case.steps or []) * 2),
                }
            )

        total_minutes = sum(script["estimated_minutes"] for script in scripts)
        return {
            "status": "success",
            "confidence": 0.85,
            "summary": (
                f"Prepared {len(scripts)} UAT script(s) covering "
                f"{len({script['module'] for script in scripts})} module(s), "
                f"about {total_minutes} minutes of business validation."
            ),
            "findings": [
                {
                    "uat_id": script["uat_id"],
                    "title": script["title"],
                    "module": script["module"],
                    "estimated_minutes": script["estimated_minutes"],
                }
                for script in scripts
            ],
            "recommendations": [
                {"priority": "medium", "action": "Schedule a UAT walkthrough session with the business sponsor before sign-off."},
                {"priority": "low", "action": "Prepare the masked UAT data set so business users never see production data."},
            ],
            "reasoning_summary": (
                "High-priority test cases were rewritten into business language: system actions became user "
                "actions, technical assertions became observable outcomes, and each script gained explicit "
                "sign-off criteria."
            ),
            "next_action": "report",
            "outputs": {"script_count": len(scripts), "total_minutes": total_minutes, "scripts": scripts},
        }

    @staticmethod
    def _business_title(title: str) -> str:
        cleaned = title.replace("Verify ", "Confirm ").replace("Validate ", "Check ")
        return cleaned[:160]

    @staticmethod
    def _business_objective(case: TestCase) -> str:
        return (
            case.objective
            or f"Confirm the {case.module} process behaves as the business expects."
        )

    @staticmethod
    def _business_steps(case: TestCase) -> list[dict[str, Any]]:
        steps: list[dict[str, Any]] = []
        for index, step in enumerate(case.steps or [], start=1):
            action = str(step.get("action", ""))
            business_action = (
                action.replace("Navigate to", "Open")
                .replace("Authenticate as the prepared test user", "Sign in with your test account")
                .replace("Verify the resulting state in the UI and backing data", "Check that the result on screen matches what you expected")
                .replace("Submit the request and wait for confirmation", "Submit and wait for the confirmation message")
            )
            steps.append({"step": index, "action": business_action, "expected": None})
        if not steps:
            steps = [{"step": 1, "action": f"Complete the {case.module} process end to end.", "expected": None}]
        if steps:
            steps[-1]["expected"] = case.expected_result
        return steps

    @staticmethod
    def _sign_off(case: TestCase) -> list[str]:
        return [
            case.expected_result or "The process completes as expected.",
            "No error messages appear that the business has not agreed to.",
            "The resulting record is visible and correct in the application.",
        ]


class JiraDefectAssistantAgent(BaseAgent):
    key = "jira-defect-assistant"
    name = "Jira Defect Assistant"
    category = "Defect Intelligence"
    description = "Drafts a well-formed defect with severity, priority and duplicate check, then raises it on approval."
    capability = "structured_extraction"
    complexity = "standard"
    risk_level = "high"
    cost_tier = "medium"
    icon = "Ticket"
    requires_approval = True
    supported_tools = ["jira", "knowledge"]
    goal = "Produce defects developers can act on immediately, without duplicates."
    system_instructions = (
        "You are a defect triage specialist. Write a defect a developer can reproduce from the description "
        "alone. Recommend severity and priority with justification, and always check for duplicates first."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "Defect summary; derived from RCA when omitted"},
            "description": {"type": "string"},
            "module": {"type": "string"},
            "execution_test_id": {"type": "string"},
            "create_in_jira": {"type": "boolean", "default": False},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []

        # Chain naturally from an upstream RCA step when one ran in this flow.
        rca = ctx.variables.get("automated-rca") or ctx.variables.get("automated-defect-rca") or {}
        rca_outputs = rca.get("outputs", {}) if isinstance(rca, dict) else {}

        title = inputs.get("title") or (
            f"{rca_outputs.get('module', 'Application')}: {rca_outputs.get('probable_root_cause')}"
            if rca_outputs.get("probable_root_cause")
            else None
        )
        module = inputs.get("module") or rca_outputs.get("module") or "General"

        similar = (
            ctx.knowledge.find_similar(
                title, project_id=ctx.project_id, collection=COLLECTION_DEFECTS, limit=5, min_score=0.8
            )
            if title
            else []
        )

        return {
            "title": title,
            "module": module,
            "rca_outputs": rca_outputs,
            "similar_defects": similar,
            "tool_calls": tool_calls,
            "evidence": [
                {"ref": f"[D{index}]", "title": hit.metadata.get("title", "Defect"), "score": round(hit.score, 3)}
                for index, hit in enumerate(similar, start=1)
            ],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        similar = "\n".join(
            f"- {hit.metadata.get('title', hit.content[:80])} (similarity {hit.score:.2f})"
            for hit in context.get("similar_defects", [])
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.jira-defect-assistant.draft",
                proposed_title=context.get("title"),
                root_cause_analysis=context.get("rca_outputs"),
                similar_existing_defects=similar or "none",
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        title = context.get("title") or inputs.get("title")
        if not title:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No defect title could be derived; run RCA first or supply a title.",
                "next_action": "run_rca",
            }

        module = context.get("module", "General")
        rca_outputs = context.get("rca_outputs", {})
        similar = context.get("similar_defects", [])

        # Duplicate gate: a near-identical existing defect stops the draft.
        duplicate = next((hit for hit in similar if hit.score >= 0.9), None)
        if duplicate is not None:
            return {
                "status": "needs_review",
                "confidence": round(duplicate.score, 3),
                "summary": (
                    f"Likely duplicate of an existing defect "
                    f"('{duplicate.metadata.get('title', 'existing defect')}', "
                    f"{duplicate.score:.0%} similarity); no new defect drafted."
                ),
                "findings": [
                    {
                        "type": "duplicate",
                        "existing_defect": duplicate.metadata.get("external_id"),
                        "title": duplicate.metadata.get("title"),
                        "similarity": round(duplicate.score, 3),
                    }
                ],
                "recommendations": [
                    {"priority": "high", "action": "Add this occurrence as a comment on the existing defect instead of raising a new one."}
                ],
                "reasoning_summary": (
                    f"Semantic search over the defect collection returned a match at {duplicate.score:.0%} "
                    "similarity, above the 90% duplicate threshold."
                ),
                "next_action": "add_comment",
                "outputs": {"duplicate_detected": True, "duplicate_of": duplicate.metadata.get("external_id")},
            }

        severity, priority, justification = self._severity_and_priority(rca_outputs, module)
        confidence = rca_outputs.get("confidence", 0.75)

        description = self._description(title, module, rca_outputs)
        steps = self._reproduction_steps(module, rca_outputs)

        return {
            "status": "success",
            "confidence": round(float(confidence), 3),
            "summary": f"Drafted defect '{title[:120]}' at {severity} severity / {priority} priority.",
            "findings": [
                {"field": "severity", "value": severity, "justification": justification},
                {"field": "priority", "value": priority, "justification": justification},
                {"field": "similar_defects", "value": len(similar), "justification": "Checked before drafting to avoid duplicates."},
            ],
            "recommendations": [
                {"priority": "high", "action": "Review the draft and approve creation in Jira."},
            ],
            "reasoning_summary": (
                f"Severity and priority were derived from the RCA category and affected test count. "
                f"{len(similar)} similar defect(s) were checked; none exceeded the 90% duplicate threshold."
            ),
            "next_action": "await_approval",
            "outputs": {
                "duplicate_detected": False,
                "title": title,
                "description": description,
                "module": module,
                "severity": severity,
                "priority": priority,
                "steps_to_reproduce": steps,
                "evidence": rca_outputs.get("evidence", []),
                "create_in_jira": bool(inputs.get("create_in_jira", False)),
                "execution_test_id": getattr(
                    owned_execution_test(ctx, inputs.get("execution_test_id")), "id", None
                ),
            },
        }

    @staticmethod
    def _severity_and_priority(rca_outputs: dict[str, Any], module: str) -> tuple[str, str, str]:
        affected = int(rca_outputs.get("affected_test_count", 1) or 1)
        category = rca_outputs.get("category", "application")

        if category == "infrastructure" or affected >= 8:
            return "critical", "critical", f"{affected} tests affected in {module}; blocks the suite."
        if category == "application" and affected >= 3:
            return "major", "high", f"{affected} tests affected in {module} with a confirmed functional deviation."
        if category in {"automation", "test_data"}:
            return "minor", "medium", "Root cause lies in test assets rather than the product."
        return "major", "medium", f"Single-test functional deviation in {module}."

    @staticmethod
    def _description(title: str, module: str, rca_outputs: dict[str, Any]) -> str:
        evidence_lines = "\n".join(
            f"- {item.get('detail', item)}" for item in (rca_outputs.get("evidence") or [])[:5]
        )
        return (
            f"{title}\n\n"
            f"Module: {module}\n"
            f"Probable root cause: {rca_outputs.get('probable_root_cause', 'Under investigation')}\n"
            f"Confidence: {float(rca_outputs.get('confidence', 0)) * 100:.0f}%\n"
            f"Affected tests: {rca_outputs.get('affected_test_count', 'unknown')}\n\n"
            f"Evidence:\n{evidence_lines or '- See linked execution artifacts.'}\n\n"
            f"Recommended action: {rca_outputs.get('recommended_action', 'Triage with the owning team.')}"
        )

    @staticmethod
    def _reproduction_steps(module: str, rca_outputs: dict[str, Any]) -> list[str]:
        return [
            f"Open the {module} screen in the affected environment.",
            "Sign in with a standard test account.",
            f"Perform the {module} operation described in the failing test.",
            "Observe the failure described above rather than the expected outcome.",
        ]

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        if outputs.get("duplicate_detected") or not outputs.get("title"):
            return []

        # Creating the issue in Jira is a mutating, approval-gated tool call;
        # without approval the defect is still drafted locally for review.
        created: dict[str, Any] | None = None
        if outputs.get("create_in_jira") and ctx.approval_granted:
            created = self.call_tool(
                ctx,
                "jira",
                "create_defect",
                {
                    "title": outputs["title"],
                    "description": outputs["description"],
                    "module": outputs["module"],
                    "severity": outputs["severity"],
                    "priority": outputs["priority"],
                    "steps_to_reproduce": outputs["steps_to_reproduce"],
                },
            )

        if created and created.get("defect_id"):
            defect = ctx.session.get(Defect, created["defect_id"])
        else:
            defect = Defect(
                project_id=ctx.project_id,
                title=outputs["title"][:400],
                description=outputs["description"],
                module=outputs["module"],
                severity=outputs["severity"],
                priority=outputs["priority"],
                status="triage",
                source="agent",
                created_by_agent=self.key,
                is_ai_suggested=True,
                ai_confidence=payload.get("confidence"),
                steps_to_reproduce=outputs["steps_to_reproduce"],
                evidence=outputs.get("evidence", []),
                execution_test_id=outputs.get("execution_test_id"),
            )
            ctx.session.add(defect)
            ctx.session.flush()

        if defect is None:
            return []

        ctx.session.add(
            DefectAnalysis(
                defect_id=defect.id,
                run_id=ctx.run_id,
                agent_key=self.key,
                analysis_type="triage",
                summary=payload["summary"],
                recommended_severity=outputs["severity"],
                recommended_priority=outputs["priority"],
                confidence=payload.get("confidence", 0.0),
                findings=payload.get("findings", []),
                recommendations=payload.get("recommendations", []),
            )
        )
        ctx.session.flush()

        return [
            {
                "type": "defect",
                "label": f"{defect.external_key or 'Draft'} {defect.title}",
                "entity_type": "defect",
                "entity_id": defect.id,
                "created_in_jira": bool(created),
            }
        ]
