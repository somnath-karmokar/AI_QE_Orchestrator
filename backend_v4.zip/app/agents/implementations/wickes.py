"""The Impact Analyzer Agent (internally: the Wickes change-impact analyzer), as
a real platform agent.

Everything this agent needs already exists as tested, standalone modules --
`app.services.wickes_risk_model` (the 15-dimension formula, reproduced exactly
against the client's own worked example) and `app.services.wickes_test_pack`
(selecting impacted tests from a real git repo). This class is the thin layer
that makes those callable the same way every other agent is callable: from the
Agent Details "Test this agent" panel, from `POST /agents/{id}/test`, and from
the external integration API (`POST /integration/agents/{key}/runs`) with a
model card and a golden dataset generated for it like any other.

A run is not against this platform's database -- it reads a change request
from the local Jira-shaped CSV and selects tests from the local git repo (see
`demo/wickes-change-impact/README.md`), which is the point of the demo: the
agent reasoning over a customer's own artefacts, not our seeded rows. That
also means `ctx.project` names the project the run is billed and logged
against, and nothing about which project's requirements or test cases it
reads -- there are none, on purpose.

`computed_outputs = True`: the band, the score and which tests were selected
are arithmetic and a keyword match over a real repository, not something a
language model should be free to restate differently. A real provider's reply
still supplies the summary's wording; it cannot move the score.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.services.wickes_risk_model import DIMENSIONS, RiskAssessment, assess, suggest_scores, veto_narrative
from app.services.wickes_test_pack import SelectedTest, TestFile, git_log_summary, scan_repo, select_impacted

# backend/app/agents/implementations/wickes.py -> parents[4] is the repo root
# (matches scripts/build_wickes_demo_data.py's own REPO_ROOT, one level less
# deep since that script lives directly under backend/).
_REPO_ROOT = Path(__file__).resolve().parents[4]
DEMO_ROOT = _REPO_ROOT / "demo" / "wickes-change-impact"
CHANGE_BOARD_CSV = DEMO_ROOT / "change_requests.csv"
TEST_PACK_REPO = DEMO_ROOT / "test-pack-repo"

_DIMENSION_KEYS = tuple(key for key, *_ in DIMENSIONS)


def _read_change_board() -> list[dict[str, str]]:
    """The Jira-shaped change board. Read fresh every call, not cached at
    import time -- a demo operator re-running `build_wickes_demo_data.py`
    between runs should see the new data immediately, not a stale copy."""
    if not CHANGE_BOARD_CSV.exists():
        return []
    with CHANGE_BOARD_CSV.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def _change_request_options() -> tuple[list[str], list[str]]:
    """Enum values and matching display labels for the input schema's
    dropdown, e.g. `CR-1001` paired with `CR-1001 - Apple Pay auth change`.

    Read at class-definition time so the schema (seeded once into the agent's
    database row) lists the change board as it existed when the platform
    started. Wrapped defensively: an agent module failing to import because a
    demo CSV has not been generated yet would take the whole platform down
    with it, which is a far worse failure than an empty dropdown.
    """
    try:
        rows = _read_change_board()
    except OSError:
        return [], []
    values = [row["issue_key"] for row in rows if row.get("issue_key")]
    labels = [f"{row['issue_key']} - {row.get('summary', '')}" for row in rows if row.get("issue_key")]
    return values, labels


_CHANGE_IDS, _CHANGE_LABELS = _change_request_options()


class WickesChangeImpactAgent(BaseAgent):
    key = "wickes-change-impact-analyzer"
    name = "Impact Analyzer Agent"
    category = "Risk & Compliance"
    description = (
        "Scores a change against Wickes's own 15-dimension weighted risk model, bands it, "
        "applies the veto rule, and selects the impacted tests from the customer's test-pack "
        "repository -- reproducing their worked example (Apple Pay checkout, 124/140, "
        "Critical/P1) exactly."
    )
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"  # read-only: no write reaches Jira, the repo, or any other system
    cost_tier = "low"
    icon = "Gauge"
    computed_outputs = True
    supported_tools: list[str] = []
    goal = "Score change requests by Wickes's own risk model and select exactly the tests each one calls for."
    system_instructions = (
        "You are the Wickes Change Impact & Risk Analyzer. Score the change on the client's own "
        "15 weighted dimensions, apply the veto rule and band it, then read out which tests were "
        "selected and why. Do not invent a score, a band or a test the trace does not show -- "
        "every number here is arithmetic, not judgement."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "change_request_id": {
                "type": "string",
                "description": (
                    "A change request from the Wickes change board (demo/wickes-change-impact/"
                    "change_requests.csv). Run scripts/build_wickes_demo_data.py first if the "
                    "list below is empty."
                ),
                **({"enum": _CHANGE_IDS, "enumNames": _CHANGE_LABELS} if _CHANGE_IDS else {}),
            },
        },
        "required": ["change_request_id"],
    }

    # ------------------------------------------------------------------
    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        change_id = str(inputs.get("change_request_id") or "").strip()
        rows = _read_change_board()
        row = next((r for r in rows if r["issue_key"] == change_id), None)

        if row is None:
            return {
                "row": None,
                "change_id": change_id,
                "available": [r["issue_key"] for r in rows],
                "evidence": [],
                "tool_calls": [],
            }

        scores = {key: int(row[key]) for key in _DIMENSION_KEYS}
        result = assess(
            change_id=row["issue_key"],
            change_title=row["summary"],
            scores=scores,
            probability=int(row["probability"]),
            impact=int(row["impact"]),
            confidence=int(row["confidence"]),
            control=int(row["control"]),
        )
        ai_suggested, ai_rationale = suggest_scores(row["description"])
        ai_agreement = sum(1 for key in scores if ai_suggested[key] == scores[key])

        files: list[TestFile] = []
        history: list[str] = []
        repo_error: str | None = None
        try:
            if TEST_PACK_REPO.exists():
                files = scan_repo(TEST_PACK_REPO)
                history = git_log_summary(TEST_PACK_REPO)
            else:
                repo_error = f"Test pack repo not found at {TEST_PACK_REPO}."
        except OSError as error:
            repo_error = str(error)

        tags = tuple(t.strip() for t in row.get("tags", "").split(",") if t.strip())
        selected: list[SelectedTest] = select_impacted(files, journey=row["journey"], change_tags=tags) if files else []

        return {
            "row": row,
            "change_id": change_id,
            "result": result,
            "ai_suggested": ai_suggested,
            "ai_rationale": ai_rationale,
            "ai_agreement": ai_agreement,
            "files_scanned": len(files),
            "journeys_scanned": len({f.journey for f in files}),
            "repo_history": history,
            "repo_error": repo_error,
            "selected": selected,
            "evidence": [],
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        row = context.get("row")
        result: RiskAssessment | None = context.get("result")
        selected: list[SelectedTest] = context.get("selected") or []
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.wickes-change-impact-analyzer.assess",
                change=row or {"change_request_id": context.get("change_id"), "found": False},
                trace=result.to_dict() if result else {},
                selected_tests=[
                    {"path": str(item.test.path), "priority": item.test.priority, "reason": item.reason}
                    for item in selected
                ],
            ),
        ]

    # ------------------------------------------------------------------
    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        row = context.get("row")
        if row is None:
            available = context.get("available") or []
            return {
                "status": "failed",
                "confidence": 0.2,
                "summary": (
                    f"Change request '{context.get('change_id')}' was not found on the change "
                    "board."
                ),
                "next_action": "abort",
                "reasoning_summary": (
                    "[1] INPUT: looked up the change request on the Wickes change board "
                    f"({CHANGE_BOARD_CSV.name}) and found no matching issue key.\n"
                    f"Available change requests: {', '.join(available) or 'none -- run scripts/build_wickes_demo_data.py'}."
                ),
                "outputs": {"change_request_id": context.get("change_id"), "available": available},
            }

        result: RiskAssessment = context["result"]
        selected: list[SelectedTest] = context["selected"]
        by_priority: dict[str, int] = {}
        for item in selected:
            by_priority[item.test.priority] = by_priority.get(item.test.priority, 0) + 1

        findings = [
            {
                "type": "dimension_score",
                "dimension": d.key,
                "label": d.label,
                "weight": d.weight,
                "score": d.score,
                "weighted": d.weighted,
                "detail": f"{d.label} scored {d.score}/5 (weight x{d.weight} = {d.weighted}).",
            }
            for d in result.dimensions
        ]
        findings.append(
            {
                "type": "band",
                "severity": result.band.split(" /")[0].lower(),
                "detail": (
                    f"Base weighted score {result.base_score}/{result.max_score} bands as "
                    f"{result.band_before_veto}. {veto_narrative(result)}"
                ),
            }
        )
        findings.append(
            {
                "type": "modifier",
                "detail": (
                    f"Confidence/control modifier = Probability + Impact - Confidence - Control "
                    f"= {result.modifier:+d} ({result.modifier_reading})."
                ),
            }
        )
        for item in selected:
            findings.append(
                {
                    "type": "selected_test",
                    "priority": item.test.priority,
                    "path": str(item.test.path),
                    "detail": f"[{item.test.priority}] {item.test.path} - {item.reason}",
                }
            )

        recommendations = [
            {
                "priority": "critical" if result.band == "Critical / P1" else "high" if result.band == "High / P2" else "medium",
                "action": f"Coverage commitment for {result.band}: {result.coverage_commitment}",
            }
        ]
        if result.veto_triggered:
            dims = ", ".join(result.veto_triggered)
            recommendations.append(
                {
                    "priority": "high",
                    "action": (
                        f"Veto rule triggered on [{dims}] -- confirm this is reviewed at "
                        f"{result.band}, the band its base score alone would already require."
                        if result.band == result.band_before_veto
                        else (
                            f"Veto rule triggered on [{dims}] -- escalated from "
                            f"{result.band_before_veto} to {result.band}; confirm this is "
                            "reviewed at the higher band even though the base score alone "
                            "would not have required it."
                        )
                    ),
                }
            )
        p1_count = by_priority.get("P1", 0)
        if p1_count:
            recommendations.append(
                {
                    "priority": "high",
                    "action": f"{p1_count} P1 test(s) must pass before this change releases (P1 coverage floor).",
                }
            )
        if context.get("repo_error"):
            recommendations.append(
                {"priority": "medium", "action": f"Test-pack repo issue: {context['repo_error']}"}
            )

        priorities = ", ".join(f"{p}: {n}" for p, n in sorted(by_priority.items()))
        reasoning_summary = (
            f"[1] INPUT: read {row['issue_key']} ({row['summary']}) from the Wickes change board "
            f"-- journey '{row['journey']}', change type '{row['change_type']}'.\n"
            f"[1b] AI-ASSIST: an independent keyword read of the change's own text agreed with "
            f"the confirmed dimension scores on {context['ai_agreement']}/{len(_DIMENSION_KEYS)} "
            "dimensions; the confirmed scores were used for scoring, not the suggestion.\n"
            f"[2] SCORE: base weighted score = sum(dimension score x weight) across "
            f"{len(_DIMENSION_KEYS)} dimensions = {result.base_score}/{result.max_score}.\n"
            f"[3] BAND: {result.band_before_veto} before the veto rule. {veto_narrative(result)} "
            f"Modifier {result.modifier:+d} ({result.modifier_reading}).\n"
            f"[4] SELECT: scanned {context['files_scanned']} tagged test file(s) across "
            f"{context['journeys_scanned']} journeys in the test-pack repo; selected "
            f"{len(selected)} test(s) by tag relevance plus the P1 coverage floor ({priorities or 'none'}).\n"
            f"[5] OUTPUT: coverage commitment for {result.band} -- {result.coverage_commitment}\n"
            "[6] LEARN: this outcome is recorded; escaped defects and incidents feed the "
            "quarterly re-tuning of the 15 dimension weights and band thresholds."
        )

        summary = (
            f"{row['issue_key']} ({row['summary']}) scores {result.base_score}/{result.max_score} "
            f"-> {result.band}"
            + (f" (veto: {', '.join(result.veto_triggered)})" if result.veto_triggered else "")
            + f". {len(selected)} test(s) selected ({priorities or 'none'})."
        )

        return {
            "status": "success",
            "confidence": 0.95 if not context.get("repo_error") else 0.7,
            "summary": summary,
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": reasoning_summary,
            "next_action": "review_release_gate" if result.band in ("Critical / P1", "High / P2") else "proceed",
            "outputs": {
                **result.to_dict(),
                "selected_tests": [
                    {
                        "path": str(item.test.path),
                        "priority": item.test.priority,
                        "journey": item.test.journey,
                        "tags": list(item.test.tags),
                        "reason": item.reason,
                    }
                    for item in selected
                ],
                "test_counts_by_priority": by_priority,
                "ai_suggested_scores": context["ai_suggested"],
                "ai_agreement_dimensions": context["ai_agreement"],
                "repo_history": context.get("repo_history") or [],
            },
        }
