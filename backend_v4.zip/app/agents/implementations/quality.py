"""Defect intelligence, RCA and observability agents (catalogue entries 17-21)."""

from __future__ import annotations

import statistics
from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import func, select

from app.agents.scoping import owned, owned_execution, owned_execution_test
from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.agents.implementations.automation import classify_failure
from app.models.defect import Defect, DefectAnalysis, DefectPrediction, RootCauseAnalysis
from app.models.testing import Execution, ExecutionTest, Requirement, TestCase
from app.vectorstore.base import COLLECTION_DEFECTS, COLLECTION_EXECUTION_HISTORY, COLLECTION_TEST_CASES

# Root-cause hypotheses, each with the evidence pattern that supports it.
_ROOT_CAUSE_LIBRARY: list[dict[str, Any]] = [
    {
        "key": "service_timeout",
        "category": "infrastructure",
        "cause": "Downstream service timeout under load",
        "markers": ("timeout", "timed out", "gateway", "504", "deadline"),
        "action": "Review the service timeout and connection-pool configuration for the affected dependency.",
    },
    {
        "key": "auth_session",
        "category": "application",
        "cause": "Authentication session expiring earlier than the configured TTL",
        "markers": ("unauthorized", "401", "session", "token", "expired", "forbidden"),
        "action": "Verify session TTL and refresh handling between the gateway and the identity provider.",
    },
    {
        "key": "validation_rule",
        "category": "application",
        "cause": "Validation rule rejecting input the specification permits",
        "markers": ("validation", "invalid", "rejected", "constraint", "must be"),
        "action": "Reconcile the implemented validation rule against the acceptance criteria.",
    },
    {
        "key": "data_state",
        "category": "test_data",
        "cause": "Test data not in the state the assertion expects",
        "markers": ("no such record", "not found", "missing", "duplicate key", "empty"),
        "action": "Refresh the test data set and add a setup assertion before the main flow.",
    },
    {
        "key": "ui_contract",
        "category": "automation",
        "cause": "UI structure changed, breaking the element contract the test relies on",
        "markers": ("locator", "selector", "not attached", "strict mode", "no element"),
        "action": "Adopt test-id based locators and coordinate a UI contract with the front-end team.",
    },
    {
        "key": "concurrency",
        "category": "application",
        "cause": "Race condition between concurrent requests producing inconsistent state",
        "markers": ("concurrent", "race", "deadlock", "conflict", "409"),
        "action": "Add idempotency keys and review transaction isolation for the affected operation.",
    },
]


def _match_root_cause(text: str) -> dict[str, Any]:
    lowered = (text or "").lower()
    scored = [
        (sum(1 for marker in entry["markers"] if marker in lowered), entry) for entry in _ROOT_CAUSE_LIBRARY
    ]
    scored.sort(key=lambda item: item[0], reverse=True)
    if scored and scored[0][0] > 0:
        return scored[0][1]
    return {
        "key": "undetermined",
        "category": "application",
        "cause": "Root cause not determinable from the available evidence",
        "action": "Capture a full trace and DOM snapshot on the next occurrence to enable diagnosis.",
    }


class DefectPredictionAgent(BaseAgent):
    key = "defect-prediction"
    name = "Defect Prediction Agent"
    category = "Defect Intelligence"
    description = "Predicts where defects are most likely to surface next, using change, complexity and history."
    capability = "reasoning"
    complexity = "complex"
    risk_level = "medium"
    cost_tier = "high"
    icon = "TrendingUp"
    supported_tools = ["knowledge", "git"]
    goal = "Direct test effort toward the modules most likely to fail."
    system_instructions = (
        "You are a quality risk analyst. Predict defect likelihood per module, name the drivers, "
        "and recommend where to concentrate testing."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "horizon_days": {"type": "integer", "default": 14},
            "modules": {"type": "array"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        window_start = datetime.now(UTC) - timedelta(days=90)

        defects_by_module = {
            row[0]: row[1]
            for row in ctx.session.execute(
                select(Defect.module, func.count(Defect.id))
                .where(Defect.project_id == ctx.project_id, Defect.created_at >= window_start)
                .group_by(Defect.module)
            ).all()
        }
        requirements_by_module = {
            row[0]: (row[1], row[2] or 0)
            for row in ctx.session.execute(
                select(
                    Requirement.module,
                    func.count(Requirement.id),
                    func.sum(Requirement.change_frequency),
                )
                .where(Requirement.project_id == ctx.project_id, Requirement.is_deleted.is_(False))
                .group_by(Requirement.module)
            ).all()
        }
        failures_by_module = {
            row[0]: row[1]
            for row in ctx.session.execute(
                select(ExecutionTest.module, func.count(ExecutionTest.id))
                .join(Execution, Execution.id == ExecutionTest.execution_id)
                .where(
                    Execution.project_id == ctx.project_id,
                    ExecutionTest.result.in_(["failed", "flaky"]),
                    ExecutionTest.created_at >= window_start,
                )
                .group_by(ExecutionTest.module)
            ).all()
        }
        coverage_by_module = {
            row[0]: row[1]
            for row in ctx.session.execute(
                select(TestCase.module, func.count(TestCase.id))
                .where(TestCase.project_id == ctx.project_id, TestCase.is_deleted.is_(False))
                .group_by(TestCase.module)
            ).all()
        }
        return {
            "defects_by_module": defects_by_module,
            "requirements_by_module": requirements_by_module,
            "failures_by_module": failures_by_module,
            "coverage_by_module": coverage_by_module,
            "evidence": [],
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.defect-prediction.predict",
                {"horizon_days": int(inputs.get("horizon_days", 14))},
                defect_history=context.get("defects_by_module", {}),
                execution_failures=context.get("failures_by_module", {}),
                coverage=context.get("coverage_by_module", {}),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        defects = context.get("defects_by_module", {})
        requirements = context.get("requirements_by_module", {})
        failures = context.get("failures_by_module", {})
        coverage = context.get("coverage_by_module", {})
        horizon = int(inputs.get("horizon_days", 14))

        modules = set(defects) | set(requirements) | set(failures) | set(coverage)
        if inputs.get("modules"):
            modules &= set(inputs["modules"])
        if not modules:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "Insufficient history to predict defects.",
                "next_action": "ingest_requirements",
            }

        max_defects = max(defects.values(), default=1) or 1
        max_failures = max(failures.values(), default=1) or 1
        max_churn = max((value[1] for value in requirements.values()), default=1) or 1

        predictions: list[dict[str, Any]] = []
        for module in sorted(modules):
            defect_count = defects.get(module, 0)
            failure_count = failures.get(module, 0)
            requirement_count, churn = requirements.get(module, (0, 0))
            case_count = coverage.get(module, 0)

            # Normalised drivers, weighted by how predictive each is in practice.
            defect_density = defect_count / max_defects
            failure_density = failure_count / max_failures
            churn_score = churn / max_churn
            coverage_gap = 1.0 - min(1.0, case_count / max(1, requirement_count * 3))

            probability = round(
                min(
                    0.97,
                    defect_density * 0.35
                    + failure_density * 0.28
                    + churn_score * 0.22
                    + coverage_gap * 0.15,
                ),
                3,
            )
            band = "high" if probability >= 0.6 else "medium" if probability >= 0.33 else "low"

            drivers = []
            if defect_density > 0.4:
                drivers.append({"driver": "Recent defect density", "weight": round(defect_density * 0.35, 3), "detail": f"{defect_count} defect(s) in the last 90 days."})
            if failure_density > 0.4:
                drivers.append({"driver": "Execution failure rate", "weight": round(failure_density * 0.28, 3), "detail": f"{failure_count} failed or flaky test result(s)."})
            if churn_score > 0.4:
                drivers.append({"driver": "Requirement churn", "weight": round(churn_score * 0.22, 3), "detail": f"Change frequency of {churn} across {requirement_count} requirement(s)."})
            if coverage_gap > 0.4:
                drivers.append({"driver": "Coverage gap", "weight": round(coverage_gap * 0.15, 3), "detail": f"{case_count} test case(s) for {requirement_count} requirement(s)."})
            if not drivers:
                drivers.append({"driver": "Baseline risk", "weight": probability, "detail": "No dominant driver; risk is diffuse."})

            predictions.append(
                {
                    "module": module,
                    "probability": probability,
                    "risk_band": band,
                    "predicted_severity": "critical" if probability >= 0.7 else "major" if probability >= 0.4 else "minor",
                    "drivers": drivers,
                    "defect_count_90d": defect_count,
                    "failure_count_90d": failure_count,
                    "test_case_count": case_count,
                    "recommended_actions": self._actions(band, module, coverage_gap),
                }
            )

        predictions.sort(key=lambda item: item["probability"], reverse=True)
        high = [item for item in predictions if item["risk_band"] == "high"]

        return {
            "status": "success",
            "confidence": 0.81,
            "summary": (
                f"Predicted defect risk across {len(predictions)} module(s) over {horizon} days; "
                f"{len(high)} at high risk, led by {predictions[0]['module']} at {predictions[0]['probability']:.0%}."
            ),
            "findings": predictions,
            "recommendations": [
                {"priority": "high", "action": f"{item['module']}: {item['recommended_actions'][0]}"}
                for item in high[:5]
            ],
            "reasoning_summary": (
                "Risk was scored from four normalised drivers -- recent defect density, execution failure rate, "
                "requirement churn and coverage gap -- weighted by their observed predictive value."
            ),
            "next_action": "optimize_regression",
            "outputs": {"horizon_days": horizon, "predictions": predictions, "high_risk_count": len(high)},
        }

    @staticmethod
    def _actions(band: str, module: str, coverage_gap: float) -> list[str]:
        actions: list[str] = []
        if band == "high":
            actions.append(f"Prioritise {module} in the next regression cycle and add exploratory testing.")
        elif band == "medium":
            actions.append(f"Include {module} in the regression suite and monitor failure trends.")
        else:
            actions.append(f"Maintain current {module} coverage; no additional action needed.")
        if coverage_gap > 0.5:
            actions.append(f"Close the {module} coverage gap: generate scenarios for uncovered requirements.")
        return actions

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        predictions = payload.get("outputs", {}).get("predictions", [])
        artifacts: list[dict[str, Any]] = []
        for prediction in predictions:
            row = DefectPrediction(
                project_id=ctx.project_id,
                run_id=ctx.run_id,
                target_type="module",
                target_ref=prediction["module"],
                module=prediction["module"],
                probability=prediction["probability"],
                predicted_severity=prediction["predicted_severity"],
                risk_band=prediction["risk_band"],
                drivers=prediction["drivers"],
                recommended_actions=prediction["recommended_actions"],
                horizon_days=payload.get("outputs", {}).get("horizon_days", 14),
            )
            ctx.session.add(row)
            ctx.session.flush()
            artifacts.append(
                {
                    "type": "defect_prediction",
                    "label": f"{prediction['module']} risk {prediction['probability']:.0%}",
                    "entity_type": "defect_prediction",
                    "entity_id": row.id,
                }
            )
        return artifacts


class AutomatedRCAAgent(BaseAgent):
    key = "automated-rca"
    name = "Automated RCA Agent"
    category = "RCA"
    description = "Determines the probable root cause of a failure from evidence and historical precedent."
    capability = "reasoning"
    complexity = "complex"
    risk_level = "medium"
    cost_tier = "high"
    icon = "Microscope"
    supported_tools = ["knowledge", "git", "database"]
    goal = "Explain why a failure happened, with evidence and a confidence you can act on."
    system_instructions = (
        "You are a root cause analyst. State the single most probable cause, the evidence supporting it, "
        "your confidence, the affected tests and the recommended action. Never speculate beyond the evidence."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "execution_id": {"type": "string"},
            "execution_test_id": {"type": "string"},
            "defect_id": {"type": "string"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        failures: list[ExecutionTest] = []

        if inputs.get("execution_test_id"):
            test = owned_execution_test(ctx, inputs["execution_test_id"])
            failures = [test] if test else []
        else:
            execution_id = inputs.get("execution_id") or ctx.variables.get("execution_id")
            if execution_id:
                named = owned_execution(ctx, execution_id)
                execution_id = named.id if named else None
            else:
                execution = (
                    ctx.session.execute(
                        select(Execution)
                        .where(Execution.project_id == ctx.project_id, Execution.failed > 0)
                        .order_by(Execution.created_at.desc())
                    )
                    .scalars()
                    .first()
                )
                execution_id = execution.id if execution else None
            if execution_id:
                failures = list(
                    ctx.session.execute(
                        select(ExecutionTest).where(
                            ExecutionTest.execution_id == execution_id,
                            ExecutionTest.result == "failed",
                        )
                    )
                    .scalars()
                    .all()
                )

        signature_text = " ".join((test.failure_message or "") for test in failures[:5])
        similar_history = (
            ctx.knowledge.retrieve(
                signature_text,
                project_id=ctx.project_id,
                collection=COLLECTION_EXECUTION_HISTORY,
                limit=6,
            )
            if signature_text.strip()
            else []
        )
        similar_defects = (
            ctx.knowledge.retrieve(
                signature_text, project_id=ctx.project_id, collection=COLLECTION_DEFECTS, limit=4
            )
            if signature_text.strip()
            else []
        )

        module = failures[0].module if failures else None
        commits = self.call_tool(
            ctx, "git", "get_commit_history", {"module": module, "limit": 5}, tool_calls=tool_calls
        ) if module else None

        evidence = [
            {
                "ref": f"[H{index}]",
                "title": hit.metadata.get("title", "Historical failure"),
                "source_type": "execution_history",
                "score": round(hit.score, 3),
            }
            for index, hit in enumerate(similar_history, start=1)
        ]

        return {
            "failures": failures,
            "similar_history": similar_history,
            "similar_defects": similar_defects,
            "commits": commits,
            "evidence": evidence,
            "tool_calls": tool_calls,
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        failures: list[ExecutionTest] = context.get("failures", [])
        listing = "\n".join(
            f"- {test.name} [{test.module}]: {(test.failure_message or '')[:220]}" for test in failures[:10]
        )
        history = "\n".join(
            f"- score {hit.score:.2f}: {hit.content[:160]}" for hit in context.get("similar_history", [])
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.automated-rca.analyse",
                failures=listing or "none",
                similar_historical_failures=history or "none",
                recent_commits=context.get("commits"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        failures: list[ExecutionTest] = context.get("failures", [])
        similar_history = context.get("similar_history", [])
        similar_defects = context.get("similar_defects", [])
        commits = context.get("commits") or {}

        if not failures:
            return {
                "status": "success",
                "confidence": 0.85,
                "summary": "No failures were available for root cause analysis.",
                "next_action": "report",
                "outputs": {},
            }

        combined_text = " ".join((test.failure_message or "") for test in failures)
        hypothesis = _match_root_cause(combined_text)
        category_key, category_spec = classify_failure(combined_text)

        # Confidence is built from independent, stateable signals so the number
        # can be defended rather than asserted.
        signals: list[dict[str, Any]] = []
        confidence = 0.42

        if hypothesis["key"] != "undetermined":
            confidence += 0.18
            signals.append({"signal": "Failure signature matched a known cause pattern", "weight": 0.18})

        precedent_count = len(similar_history)
        if precedent_count:
            boost = min(0.2, precedent_count * 0.04)
            confidence += boost
            signals.append({"signal": f"{precedent_count} similar historical failure(s) retrieved", "weight": round(boost, 3)})

        if similar_defects:
            confidence += 0.08
            signals.append({"signal": f"{len(similar_defects)} related defect(s) share this signature", "weight": 0.08})

        module_counter = Counter(test.module for test in failures)
        if len(module_counter) == 1 and len(failures) > 1:
            confidence += 0.08
            signals.append({"signal": f"All {len(failures)} failures are confined to {next(iter(module_counter))}", "weight": 0.08})

        recent_commits = commits.get("commits", []) if isinstance(commits, dict) else []
        if recent_commits:
            confidence += 0.06
            signals.append({"signal": f"{len(recent_commits)} recent commit(s) touch the affected module", "weight": 0.06})

        confidence = round(min(0.96, confidence), 3)

        evidence = [
            {"type": "failure_count", "detail": f"{len(failures)} test(s) failed with a consistent signature."},
            {"type": "classification", "detail": f"Failure class: {category_spec['label']}."},
        ]
        evidence.extend(
            {"type": "historical_match", "detail": f"Similarity {hit.score:.2f}: {hit.content[:140]}"}
            for hit in similar_history[:3]
        )
        evidence.extend(
            {"type": "recent_change", "detail": f"{commit.get('sha')}: {commit.get('message')}"}
            for commit in recent_commits[:3]
        )

        return {
            "status": "success",
            "confidence": confidence,
            "summary": (
                f"Probable root cause: {hypothesis['cause']} "
                f"({confidence:.0%} confidence, {len(failures)} affected test(s))."
            ),
            "findings": signals,
            "recommendations": [
                {"priority": "high", "action": hypothesis["action"]},
                {
                    "priority": "medium",
                    "action": f"Add a targeted regression check for {next(iter(module_counter))} to detect recurrence.",
                },
            ],
            "reasoning_summary": (
                f"Matched the failure signature against a root-cause library, then corroborated it with "
                f"{precedent_count} historical precedent(s), {len(similar_defects)} related defect(s) and "
                f"{len(recent_commits)} recent change(s). Confidence is the sum of these independent signals."
            ),
            "next_action": "create_defect",
            "outputs": {
                "probable_root_cause": hypothesis["cause"],
                "category": hypothesis["category"],
                "confidence": confidence,
                "affected_test_count": len(failures),
                "affected_tests": [
                    {"id": test.id, "name": test.name, "module": test.module} for test in failures[:20]
                ],
                "evidence": evidence,
                "recommended_action": hypothesis["action"],
                "module": next(iter(module_counter)),
                "execution_id": failures[0].execution_id,
                "historical_similarity": [
                    {"score": round(hit.score, 3), "excerpt": hit.content[:160]} for hit in similar_history[:5]
                ],
                "related_code_changes": recent_commits[:5],
            },
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        if not outputs.get("probable_root_cause"):
            return []

        rca = RootCauseAnalysis(
            project_id=ctx.project_id,
            # Resolved references only: a raw input would link this record to
            # another project's defect or test, or to a key that is not an id.
            defect_id=getattr(owned(ctx, Defect, inputs.get("defect_id"), key_column=Defect.external_key), "id", None),
            execution_id=getattr(owned_execution(ctx, outputs.get("execution_id")), "id", None),
            execution_test_id=getattr(owned_execution_test(ctx, inputs.get("execution_test_id")), "id", None),
            run_id=ctx.run_id,
            title=f"RCA: {outputs['probable_root_cause'][:200]}",
            probable_root_cause=outputs["probable_root_cause"],
            category=outputs.get("category", "application"),
            confidence=outputs.get("confidence", 0.0),
            evidence=outputs.get("evidence", []),
            contributing_factors=payload.get("findings", []),
            affected_tests=outputs.get("affected_tests", []),
            historical_similarity=outputs.get("historical_similarity", []),
            related_code_changes=outputs.get("related_code_changes", []),
            recommended_action=outputs.get("recommended_action"),
            agent_key=self.key,
        )
        ctx.session.add(rca)
        ctx.session.flush()
        return [
            {
                "type": "root_cause_analysis",
                "label": rca.title,
                "entity_type": "root_cause_analysis",
                "entity_id": rca.id,
                "confidence": rca.confidence,
            }
        ]


class AutomatedDefectRCAAgent(AutomatedRCAAgent):
    """RCA anchored on an existing defect rather than on a raw execution failure."""

    key = "automated-defect-rca"
    name = "Automated Defect RCA"
    category = "RCA"
    description = "Runs root cause analysis for a logged defect, linking it to tests, requirements and changes."
    icon = "FileSearch"
    input_schema = {
        "type": "object",
        "required": ["defect_id"],
        "properties": {"defect_id": {"type": "string", "description": "Defect to analyse"}},
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        defect = owned(ctx, Defect, inputs.get("defect_id"), key_column=Defect.external_key)
        if defect is None:
            return {"failures": [], "similar_history": [], "similar_defects": [], "evidence": [], "tool_calls": []}

        # Anchor on the defect's own failing test when it has one.
        if defect.execution_test_id:
            inputs = {**inputs, "execution_test_id": defect.execution_test_id}
        elif defect.execution_id:
            inputs = {**inputs, "execution_id": defect.execution_id}

        context = super().gather_context(ctx, inputs)
        context["defect"] = defect

        signature = f"{defect.title} {defect.description or ''}"
        context["similar_defects"] = ctx.knowledge.find_similar(
            signature,
            project_id=ctx.project_id,
            collection=COLLECTION_DEFECTS,
            limit=5,
            exclude_id=defect.id,
        )
        return context

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        defect: Defect | None = context.get("defect")
        if defect is None:
            return {
                "status": "failed",
                "confidence": 0.2,
                "summary": f"Defect '{inputs.get('defect_id')}' was not found.",
                "next_action": "abort",
            }

        payload = super().draft(ctx, inputs, context)
        if not payload.get("outputs"):
            # No failing test attached: analyse the defect narrative itself.
            hypothesis = _match_root_cause(f"{defect.title} {defect.description or ''}")
            similar = context.get("similar_defects", [])
            confidence = round(min(0.9, 0.5 + 0.06 * len(similar)), 3)
            payload = {
                "status": "success",
                "confidence": confidence,
                "summary": f"Probable root cause for {defect.external_key or defect.id}: {hypothesis['cause']}.",
                "findings": [
                    {"signal": "Defect narrative matched a known cause pattern", "weight": 0.5},
                    {"signal": f"{len(similar)} similar defect(s) retrieved", "weight": round(0.06 * len(similar), 3)},
                ],
                "recommendations": [{"priority": "high", "action": hypothesis["action"]}],
                "reasoning_summary": (
                    f"No failing execution was attached to this defect, so the analysis is based on the "
                    f"defect narrative and {len(similar)} similar historical defect(s)."
                ),
                "next_action": "update_defect",
                "outputs": {
                    "probable_root_cause": hypothesis["cause"],
                    "category": hypothesis["category"],
                    "confidence": confidence,
                    "recommended_action": hypothesis["action"],
                    "evidence": [
                        {"type": "similar_defect", "detail": hit.content[:160]} for hit in similar[:3]
                    ],
                    "module": defect.module,
                },
            }

        payload["outputs"]["defect_id"] = defect.id
        payload["outputs"]["defect_key"] = defect.external_key
        payload["summary"] = f"{defect.external_key or 'Defect'}: {payload['summary']}"
        return payload

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        artifacts = super().persist(ctx, inputs, payload)
        defect_id = payload.get("outputs", {}).get("defect_id")
        if defect_id:
            defect = owned(ctx, Defect, defect_id, key_column=Defect.external_key)
            if defect is not None:
                ctx.session.add(
                    DefectAnalysis(
                        defect_id=defect.id,
                        run_id=ctx.run_id,
                        agent_key=self.key,
                        analysis_type="rca",
                        summary=payload["summary"],
                        confidence=payload.get("confidence", 0.0),
                        findings=payload.get("findings", []),
                        recommendations=payload.get("recommendations", []),
                    )
                )
                ctx.session.flush()
        return artifacts


class DuplicateTestCaseDetectionAgent(BaseAgent):
    key = "duplicate-test-detection"
    name = "Duplicate Test Case Detection"
    category = "Test Design"
    description = "Finds semantically duplicated test cases so the suite can be consolidated."
    capability = "classification"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "Copy"
    supported_tools = ["knowledge"]
    goal = "Remove redundant tests without losing coverage."
    system_instructions = (
        "You are a test suite curator. Identify genuine duplicates, distinguish them from similar-but-distinct "
        "cases, and recommend which to keep."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "module": {"type": "string"},
            "similarity_threshold": {"type": "number", "default": 0.86},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        statement = select(TestCase).where(
            TestCase.project_id == ctx.project_id, TestCase.is_deleted.is_(False)
        )
        if inputs.get("module"):
            statement = statement.where(TestCase.module == inputs["module"])
        cases = list(ctx.session.execute(statement.limit(200)).scalars().all())

        threshold = float(inputs.get("similarity_threshold", 0.86))
        pairs: list[dict[str, Any]] = []
        seen: set[tuple[str, str]] = set()

        for case in cases:
            signature = f"{case.title} {case.objective or ''}"
            matches = ctx.knowledge.find_similar(
                signature,
                project_id=ctx.project_id,
                collection=COLLECTION_TEST_CASES,
                limit=4,
                exclude_id=case.id,
                min_score=threshold,
            )
            for match in matches:
                other_id = match.metadata.get("test_case_id") or match.id
                if other_id == case.id:
                    continue
                pair_key = tuple(sorted([case.id, other_id]))
                if pair_key in seen:
                    continue
                seen.add(pair_key)
                pairs.append(
                    {
                        "case_id": case.id,
                        "case_key": case.key,
                        "case_title": case.title,
                        "duplicate_id": other_id,
                        "duplicate_title": match.metadata.get("title", match.content[:80]),
                        "similarity": round(match.score, 3),
                        "module": case.module,
                    }
                )

        return {"cases": cases, "pairs": pairs, "threshold": threshold, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        pairs = context.get("pairs", [])
        listing = "\n".join(
            f"- {pair['case_key']} '{pair['case_title']}' ~ '{pair['duplicate_title']}' ({pair['similarity']})"
            for pair in pairs[:30]
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.duplicate-test-detection.review", candidate_pairs=listing or "none"
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        pairs = context.get("pairs", [])
        cases = context.get("cases", [])
        threshold = context.get("threshold", 0.86)

        if not pairs:
            return {
                "status": "success",
                "confidence": 0.9,
                "summary": f"No duplicate test cases found above a {threshold:.0%} similarity threshold "
                f"across {len(cases)} case(s).",
                "next_action": "report",
                "outputs": {"duplicate_count": 0, "pairs": []},
            }

        estimated_saving_ms = len(pairs) * 4200
        return {
            "status": "needs_review",
            "confidence": round(min(0.95, statistics.fmean([pair["similarity"] for pair in pairs])), 3),
            "summary": (
                f"Found {len(pairs)} likely duplicate pair(s) among {len(cases)} test case(s); "
                f"consolidating would save roughly {estimated_saving_ms / 60000:.1f} minutes per run."
            ),
            "findings": pairs,
            "recommendations": [
                {
                    "priority": "medium",
                    "action": f"Retain {pair['case_key']} and retire the duplicate (similarity {pair['similarity']:.0%}).",
                    "case_id": pair["case_id"],
                    "duplicate_id": pair["duplicate_id"],
                }
                for pair in pairs[:15]
            ],
            "reasoning_summary": (
                f"Each case was embedded and compared against the test-case collection; pairs scoring above "
                f"{threshold:.0%} cosine similarity were surfaced for human confirmation rather than "
                "deleted automatically."
            ),
            "next_action": "review_duplicates",
            "outputs": {"duplicate_count": len(pairs), "pairs": pairs, "threshold": threshold},
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        pairs = payload.get("outputs", {}).get("pairs", [])
        for pair in pairs:
            case = owned(ctx, TestCase, pair.get("case_id"))
            if case is not None:
                # Flag only -- retirement stays a human decision.
                case.duplicate_of_id = pair["duplicate_id"]
                case.duplicate_similarity = pair["similarity"]
        ctx.session.flush()
        return []


class ObservabilityAgent(BaseAgent):
    key = "observability"
    name = "Observability Agent"
    category = "Reporting"
    description = "Analyses execution trends, recurring failure signatures and flaky behaviour."
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "Activity"
    supported_tools = ["knowledge", "cicd"]
    goal = "Surface systemic quality signals that single runs hide."
    system_instructions = (
        "You are an observability analyst. Report trends, recurring signatures and instability, "
        "and say what each signal implies."
    )
    input_schema = {"type": "object", "properties": {"window_days": {"type": "integer", "default": 30}}}

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        window = int(inputs.get("window_days", 30))
        since = datetime.now(UTC) - timedelta(days=window)

        executions = list(
            ctx.session.execute(
                select(Execution)
                .where(Execution.project_id == ctx.project_id, Execution.created_at >= since)
                .order_by(Execution.created_at.asc())
            )
            .scalars()
            .all()
        )
        failing_tests = list(
            ctx.session.execute(
                select(ExecutionTest)
                .join(Execution, Execution.id == ExecutionTest.execution_id)
                .where(
                    Execution.project_id == ctx.project_id,
                    ExecutionTest.result.in_(["failed", "flaky"]),
                    ExecutionTest.created_at >= since,
                )
            )
            .scalars()
            .all()
        )
        return {"executions": executions, "failing_tests": failing_tests, "window": window, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        executions = context.get("executions", [])
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.observability.trends",
                {"window_days": int(context.get("window") or 0)},
                executions="\n".join(
                    f"- {execution.name}: {execution.pass_rate:.2%} pass, {execution.failed} failed"
                    for execution in executions[-15:]
                )
                or "none",
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        executions: list[Execution] = context.get("executions", [])
        failing_tests: list[ExecutionTest] = context.get("failing_tests", [])
        window = context.get("window", 30)

        if not executions:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": f"No executions recorded in the last {window} days.",
                "next_action": "start_execution",
            }

        pass_rates = [execution.pass_rate for execution in executions]
        # Compare the recent third against the earlier third to detect drift.
        third = max(1, len(pass_rates) // 3)
        early = statistics.fmean(pass_rates[:third])
        recent = statistics.fmean(pass_rates[-third:])
        trend_delta = round((recent - early) * 100, 1)

        signature_counter = Counter(
            test.failure_signature or classify_failure(test.failure_message)[1]["label"]
            for test in failing_tests
        )
        recurring = [
            {"signature": signature, "occurrences": count, "implication": "Recurring failure; treat as systemic rather than incidental."}
            for signature, count in signature_counter.most_common(5)
            if count > 1
        ]

        flaky_tests = [test for test in failing_tests if test.result == "flaky"]
        flaky_names = Counter(test.name for test in flaky_tests)
        flaky_rate = round(len(flaky_tests) / max(1, sum(execution.total_tests for execution in executions)), 4)

        module_failures = Counter(test.module for test in failing_tests)
        avg_duration = statistics.fmean([execution.duration_ms for execution in executions if execution.duration_ms]) if any(e.duration_ms for e in executions) else 0

        findings = [
            {"metric": "Pass rate trend", "value": f"{trend_delta:+.1f}pp", "detail": f"Recent {recent:.1%} vs earlier {early:.1%}."},
            {"metric": "Flaky rate", "value": f"{flaky_rate:.2%}", "detail": f"{len(flaky_tests)} flaky result(s) across {len(executions)} execution(s)."},
            {"metric": "Recurring signatures", "value": str(len(recurring)), "detail": "Failure signatures seen more than once."},
            {"metric": "Most affected module", "value": module_failures.most_common(1)[0][0] if module_failures else "none", "detail": f"{module_failures.most_common(1)[0][1] if module_failures else 0} failure(s)."},
            {"metric": "Average run duration", "value": f"{avg_duration / 1000:.0f}s", "detail": "Mean wall-clock duration per execution."},
        ]

        recommendations: list[dict[str, Any]] = []
        if trend_delta < -3:
            recommendations.append({"priority": "high", "action": f"Pass rate declined {abs(trend_delta):.1f} points; investigate before the next release gate."})
        if flaky_rate > 0.02:
            recommendations.append({"priority": "high", "action": f"Flaky rate is {flaky_rate:.2%}; stabilise the top offenders: {', '.join(name for name, _ in flaky_names.most_common(3))}."})
        for item in recurring[:3]:
            recommendations.append({"priority": "medium", "action": f"Signature '{item['signature']}' recurred {item['occurrences']} times; run RCA once and fix systemically."})

        return {
            "status": "success",
            "confidence": 0.87,
            "summary": (
                f"Over {window} days: pass rate trend {trend_delta:+.1f}pp, flaky rate {flaky_rate:.2%}, "
                f"{len(recurring)} recurring failure signature(s)."
            ),
            "findings": findings,
            "recommendations": recommendations or [{"priority": "low", "action": "Quality signals are stable; no action required."}],
            "reasoning_summary": (
                "Compared the most recent third of executions against the earliest third to detect drift, then "
                "grouped failures by signature and module to separate systemic issues from one-off failures."
            ),
            "next_action": "report",
            "outputs": {
                "window_days": window,
                "execution_count": len(executions),
                "pass_rate_trend_pp": trend_delta,
                "current_pass_rate": round(recent, 4),
                "flaky_rate": flaky_rate,
                "recurring_signatures": recurring,
                "failures_by_module": dict(module_failures),
            },
        }
