"""Test data agents (catalogue entries 7-9)."""

from __future__ import annotations

import random
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select

from app.agents.scoping import owned
from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.ai.providers.mock import stable_seed
from app.core.security import mask_pii
from app.models.testing import TestCase, TestDataSet

# Field archetypes the generator recognises from a schema definition. Keeping
# this table-driven means a new field type is one entry, not a new code path.
_FIRST_NAMES = ["Alex", "Priya", "Jordan", "Mei", "Samuel", "Nadia", "Tomas", "Aisha", "Liam", "Sofia"]
_LAST_NAMES = ["Fernandes", "Okafor", "Nakamura", "Silva", "Kowalski", "Haddad", "Novak", "Bergman"]
_CITIES = ["Lisbon", "Singapore", "Toronto", "Manchester", "Pune", "Dublin", "Krakow", "Auckland"]
_CURRENCIES = ["EUR", "GBP", "USD", "SGD", "AUD"]
_STATUSES = ["ACTIVE", "PENDING", "SUSPENDED", "CLOSED"]


class TestDataGeneratorAgent(BaseAgent):
    key = "test-data-generator"
    name = "Test Data Generator"
    category = "Test Data"
    description = "Generates masked synthetic data sets covering valid, invalid and boundary combinations."
    capability = "generation"
    complexity = "standard"
    risk_level = "medium"
    cost_tier = "medium"
    icon = "Table"
    supported_tools = ["database", "knowledge"]
    goal = "Produce realistic, privacy-safe test data matched to the cases that will consume it."
    system_instructions = (
        "You are a test data engineer. Generate data that exercises valid, invalid and boundary "
        "conditions. Never emit real personal data; all values must be synthetic and masked."
    )
    input_schema = {
        "type": "object",
        "required": ["module"],
        "properties": {
            "module": {"type": "string", "description": "Module the data supports"},
            "record_count": {"type": "integer", "default": 12},
            "include_negative": {"type": "boolean", "default": True},
            "fields": {"type": "array", "description": "Explicit field list; inferred when omitted"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        module = inputs["module"]
        cases = list(
            ctx.session.execute(
                select(TestCase)
                .where(
                    TestCase.project_id == ctx.project_id,
                    TestCase.module == module,
                    TestCase.is_deleted.is_(False),
                )
                .limit(20)
            )
            .scalars()
            .all()
        )
        knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
            f"{module} data model fields validation rules",
            project_id=ctx.project_id,
            limit=3,
            module=module,
        )
        return {"cases": cases, "knowledge": knowledge_block, "evidence": evidence, "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        cases: list[TestCase] = context.get("cases", [])
        case_titles = "\n".join(f"- {case.key} {case.title}" for case in cases[:15])
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.test-data-generator.generate",
                {"record_count": int(inputs.get("record_count", 12))},
                module=inputs["module"],
                test_cases=case_titles or "none",
                domain_knowledge=context.get("knowledge"),
            ),
        ]

    def _infer_fields(self, module: str, explicit: list[str] | None) -> list[str]:
        if explicit:
            return list(explicit)
        lowered = module.lower()
        if "login" in lowered or "auth" in lowered:
            return ["user_id", "username", "password_hash", "account_status", "failed_attempts", "locked"]
        if "payment" in lowered or "transaction" in lowered:
            return ["payment_id", "account_id", "beneficiary_id", "amount", "currency", "status", "value_date"]
        if "beneficiar" in lowered:
            return ["beneficiary_id", "account_id", "name", "iban_masked", "bank_code", "country", "verified"]
        if "account" in lowered:
            return ["account_id", "customer_id", "account_type", "balance", "currency", "status"]
        if "profile" in lowered or "customer" in lowered:
            return ["customer_id", "full_name", "email_masked", "phone_masked", "city", "kyc_status"]
        return ["id", "name", "status", "amount", "created_at"]

    def _value_for(self, field: str, rng: random.Random, variant: str, index: int) -> Any:
        """Generate one field value, biased by the variant under construction."""
        lowered = field.lower()
        boundary = variant == "boundary"
        invalid = variant == "invalid"

        if lowered.endswith("_id") or lowered == "id":
            return f"{field.replace('_id', '').upper()[:4] or 'REC'}-{1000 + index}"
        if "password" in lowered:
            return "pbkdf2$masked$" + format(rng.getrandbits(48), "012x")
        if "username" in lowered:
            return f"qa.user{index:03d}"
        if "email" in lowered:
            return mask_pii(f"qa.user{index:03d}@example.com")
        if "phone" in lowered:
            return "[REDACTED_PHONE]"
        if "iban" in lowered:
            return f"GB29 **** **** **** {rng.randint(1000, 9999)}"
        if "name" in lowered:
            return f"{rng.choice(_FIRST_NAMES)} {rng.choice(_LAST_NAMES)}"
        if "amount" in lowered or "balance" in lowered:
            if invalid:
                return -abs(round(rng.uniform(1, 500), 2))
            if boundary:
                return rng.choice([0.0, 0.01, 9999.99, 10000.00, 10000.01])
            return round(rng.uniform(10, 4500), 2)
        if "currency" in lowered:
            return "XXX" if invalid else rng.choice(_CURRENCIES)
        if "status" in lowered:
            if "kyc" in lowered:
                return rng.choice(["VERIFIED", "PENDING", "REJECTED"])
            return "UNKNOWN" if invalid else rng.choice(_STATUSES)
        if "attempts" in lowered:
            return 5 if boundary else rng.randint(0, 3)
        if "locked" in lowered or "verified" in lowered:
            return rng.choice([True, False])
        if "country" in lowered:
            return rng.choice(["PT", "SG", "CA", "GB", "IN"])
        if "city" in lowered:
            return rng.choice(_CITIES)
        if "code" in lowered:
            return f"BNK{rng.randint(100, 999)}"
        if "date" in lowered or lowered.endswith("_at"):
            offset = timedelta(days=rng.randint(-120, 30))
            return (datetime.now(UTC) + offset).date().isoformat()
        if "type" in lowered:
            return rng.choice(["CURRENT", "SAVINGS", "CREDIT"])
        return f"{field}-{index}"

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        module = inputs["module"]
        record_count = max(1, min(int(inputs.get("record_count", 12)), 200))
        include_negative = bool(inputs.get("include_negative", True))
        fields = self._infer_fields(module, inputs.get("fields"))

        rng = random.Random(stable_seed(ctx.project_id, module, record_count))
        records: list[dict[str, Any]] = []
        variant_counts = {"valid": 0, "invalid": 0, "boundary": 0}

        for index in range(record_count):
            if not include_negative:
                variant = "valid"
            elif index % 4 == 3:
                variant = "invalid"
            elif index % 4 == 2:
                variant = "boundary"
            else:
                variant = "valid"
            variant_counts[variant] += 1

            record = {field: self._value_for(field, rng, variant, index + 1) for field in fields}
            record["_variant"] = variant
            records.append(record)

        contains_pii_fields = [
            field for field in fields if any(hint in field.lower() for hint in ("name", "email", "phone", "iban"))
        ]

        return {
            "status": "success",
            "confidence": 0.9,
            "summary": (
                f"Generated {len(records)} synthetic records for {module} "
                f"({variant_counts['valid']} valid, {variant_counts['invalid']} invalid, "
                f"{variant_counts['boundary']} boundary)."
            ),
            "findings": [
                {"variant": variant, "count": count, "purpose": self._variant_purpose(variant)}
                for variant, count in variant_counts.items()
                if count
            ],
            "recommendations": (
                [{"action": f"Masked {len(contains_pii_fields)} PII-shaped field(s) before storage."}]
                if contains_pii_fields
                else []
            ),
            "reasoning_summary": (
                f"Inferred {len(fields)} fields for {module} from the module archetype and generated a "
                "deterministic mix of valid, invalid and boundary records; PII-shaped fields were masked at source."
            ),
            "next_action": "generate_scripts",
            "outputs": {
                "module": module,
                "data_set_name": f"{module} synthetic data set",
                "fields": fields,
                "records": records,
                "record_count": len(records),
                "contains_pii": bool(contains_pii_fields),
                "masked_fields": contains_pii_fields,
            },
        }

    @staticmethod
    def _variant_purpose(variant: str) -> str:
        return {
            "valid": "Exercises the happy path and confirms successful processing.",
            "invalid": "Drives validation and error-handling assertions.",
            "boundary": "Probes limits, thresholds and just-outside-range behaviour.",
        }[variant]

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        records = outputs.get("records", [])
        if not records:
            return []

        data_set = TestDataSet(
            project_id=ctx.project_id,
            name=outputs["data_set_name"],
            description=f"Synthetic data generated by {self.name} for the {outputs['module']} module.",
            module=outputs["module"],
            data_type="synthetic",
            environment_id=ctx.environment.id if ctx.environment else None,
            schema_definition={"fields": outputs.get("fields", [])},
            records=records,
            record_count=len(records),
            contains_pii=bool(outputs.get("contains_pii")),
            masking_applied=True,
            generated_by_agent=self.key,
        )
        ctx.session.add(data_set)
        ctx.session.flush()
        return [
            {
                "type": "test_data_set",
                "label": data_set.name,
                "entity_type": "test_data_set",
                "entity_id": data_set.id,
                "record_count": data_set.record_count,
            }
        ]


class TestDataManagementAgent(BaseAgent):
    key = "test-data-management"
    name = "Test Data Management Agent"
    category = "Test Data"
    description = "Audits existing data sets for staleness, PII exposure and refresh needs."
    capability = "classification"
    complexity = "simple"
    risk_level = "medium"
    cost_tier = "low"
    icon = "DatabaseZap"
    supported_tools = ["database"]
    goal = "Keep test data current, compliant and fit for the suites that consume it."
    system_instructions = (
        "You are a test data steward. Assess each data set for freshness, masking compliance and coverage, "
        "and recommend refresh or remediation."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "module": {"type": "string"},
            "staleness_days": {"type": "integer", "default": 30},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        statement = select(TestDataSet).where(
            TestDataSet.project_id == ctx.project_id, TestDataSet.is_deleted.is_(False)
        )
        if inputs.get("module"):
            statement = statement.where(TestDataSet.module == inputs["module"])
        return {
            "data_sets": list(ctx.session.execute(statement).scalars().all()),
            "evidence": [],
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        data_sets: list[TestDataSet] = context.get("data_sets", [])
        listing = "\n".join(
            f"- {ds.name} ({ds.module}): {ds.record_count} records, pii={ds.contains_pii}, "
            f"masked={ds.masking_applied}, updated {ds.updated_at.date()}"
            for ds in data_sets
        )
        return [
            self.system_message(ctx),
            self.task_message("agent.test-data-management.audit", data_sets=listing or "none"),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        data_sets: list[TestDataSet] = context.get("data_sets", [])
        if not data_sets:
            return {
                "status": "partial",
                "confidence": 0.35,
                "summary": "No test data sets exist for the requested scope.",
                "recommendations": [{"action": "Run the Test Data Generator to create a baseline data set."}],
                "next_action": "generate_test_data",
            }

        staleness_days = int(inputs.get("staleness_days", 30))
        cutoff = datetime.now(UTC) - timedelta(days=staleness_days)
        findings: list[dict[str, Any]] = []
        recommendations: list[dict[str, Any]] = []

        for data_set in data_sets:
            updated = data_set.updated_at.replace(tzinfo=UTC)
            age_days = (datetime.now(UTC) - updated).days
            issues: list[str] = []
            if updated < cutoff:
                issues.append(f"Not refreshed in {age_days} days.")
            if data_set.contains_pii and not data_set.masking_applied:
                issues.append("Contains PII-shaped fields without masking applied.")
            if data_set.record_count < 5:
                issues.append("Fewer than 5 records; unlikely to cover negative and boundary paths.")

            findings.append(
                {
                    "data_set": data_set.name,
                    "module": data_set.module,
                    "record_count": data_set.record_count,
                    "age_days": age_days,
                    "status": "attention" if issues else "healthy",
                    "issues": issues,
                }
            )
            for issue in issues:
                recommendations.append(
                    {
                        "priority": "high" if "PII" in issue else "medium",
                        "action": f"{data_set.name}: {issue}",
                        "data_set_id": data_set.id,
                    }
                )

        attention = [item for item in findings if item["status"] == "attention"]
        return {
            "status": "success" if not attention else "needs_review",
            "confidence": 0.92,
            "summary": (
                f"Audited {len(data_sets)} data set(s); {len(attention)} need attention "
                f"({len(recommendations)} action(s) recommended)."
            ),
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": (
                f"Each data set was checked against a {staleness_days}-day freshness window, masking "
                "compliance and a minimum-coverage threshold."
            ),
            "next_action": "refresh_data" if attention else "report",
            "outputs": {"audited": len(data_sets), "needs_attention": len(attention)},
        }


class DBScriptGeneratorAgent(BaseAgent):
    key = "db-script-generator"
    name = "DB Script Generator"
    category = "Test Data"
    description = "Generates parameterised setup, validation and cleanup SQL for a data set."
    capability = "generation"
    complexity = "simple"
    risk_level = "medium"
    cost_tier = "low"
    icon = "FileCode2"
    supported_tools = ["database"]
    goal = "Produce safe, parameterised SQL that provisions and tears down test data."
    system_instructions = (
        "You are a database engineer writing test-support SQL. Always parameterise values, "
        "always provide a matching cleanup script, and never generate destructive statements without a WHERE clause."
    )
    input_schema = {
        "type": "object",
        "required": ["table"],
        "properties": {
            "table": {"type": "string", "description": "Target table"},
            "data_set_id": {"type": "string"},
            "fields": {"type": "array"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        data_set = None
        if inputs.get("data_set_id"):
            data_set = owned(ctx, TestDataSet, inputs["data_set_id"])

        fields = inputs.get("fields") or (
            (data_set.schema_definition or {}).get("fields", []) if data_set else []
        ) or ["id", "name", "status"]

        generated = self.call_tool(
            ctx,
            "database",
            "generate_sql",
            {"intent": "insert", "table": inputs["table"], "fields": fields},
            tool_calls=tool_calls,
        )
        return {"data_set": data_set, "fields": fields, "generated": generated, "tool_calls": tool_calls, "evidence": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.db-script-generator.generate",
                table=inputs["table"],
                fields=context.get("fields"),
                tool_generated_sql=context.get("generated"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        table = inputs["table"]
        fields: list[str] = context.get("fields", [])
        key_field = fields[0] if fields else "id"
        columns = ", ".join(fields)
        placeholders = ", ".join(f":{field}" for field in fields)

        scripts = [
            {
                "name": "setup",
                "purpose": "Insert the test record before execution.",
                "sql": f"INSERT INTO {table} ({columns})\nVALUES ({placeholders});",
            },
            {
                "name": "validate",
                "purpose": "Assert the record exists with the expected values after execution.",
                "sql": f"SELECT {columns}\nFROM {table}\nWHERE {key_field} = :{key_field};",
            },
            {
                "name": "cleanup",
                "purpose": "Remove the test record so runs stay idempotent.",
                "sql": f"DELETE FROM {table}\nWHERE {key_field} = :{key_field};",
            },
        ]

        return {
            "status": "success",
            "confidence": 0.88,
            "summary": f"Generated {len(scripts)} parameterised SQL script(s) for '{table}'.",
            "findings": [{"script": script["name"], "purpose": script["purpose"]} for script in scripts],
            "recommendations": [
                {"action": "Run the cleanup script in test teardown to keep executions idempotent."}
            ],
            "reasoning_summary": (
                f"Derived the column list from the data set schema and keyed setup, validation and cleanup on "
                f"'{key_field}'. Every value is bound as a parameter rather than interpolated."
            ),
            "next_action": "generate_scripts",
            "outputs": {"table": table, "key_field": key_field, "scripts": scripts},
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        data_set_id = inputs.get("data_set_id")
        if not data_set_id:
            return []
        # Written to, so above all it must be this project's data set.
        data_set = owned(ctx, TestDataSet, data_set_id)
        if data_set is None:
            return []
        data_set.sql_scripts = payload.get("outputs", {}).get("scripts", [])
        ctx.session.flush()
        return [
            {
                "type": "sql_scripts",
                "label": f"SQL scripts for {data_set.name}",
                "entity_type": "test_data_set",
                "entity_id": data_set.id,
            }
        ]
