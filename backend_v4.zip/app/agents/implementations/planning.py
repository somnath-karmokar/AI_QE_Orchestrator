"""Deciding what to test: the coverage a scope needs.

**Coverage Planning** -- "what should we write, in what order, with the days we
have?" It gives every requirement a risk tier, holds it to the coverage that tier
requires, and turns the shortfall into a backlog ordered by risk removed per
engineer-day. When the backlog does not fit the capacity, it says what was
deferred and what risk that leaves, rather than quietly planning less.

It computes its answer from recorded project state in `gather_context`, so the
prompt and the deterministic draft reason over the same facts. Every threshold and
effort figure it uses is returned with the result, because a plan whose
assumptions are hidden cannot be argued with -- only accepted or ignored.

(The platform's change-impact analysis is `WickesChangeImpactAgent`, branded
"Impact Analyzer Agent" in the marketplace -- see
`app/agents/implementations/wickes.py`.)
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select

from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.models.defect import Defect
from app.models.testing import (
    BusinessFlow,
    Requirement,
    TestCase,
    TestDependency,
    TestScenario,
)

PRIORITY_WEIGHT = {"critical": 1.0, "high": 0.75, "medium": 0.5, "low": 0.25}
SEVERITY_WEIGHT = {"blocker": 1.0, "critical": 1.0, "major": 0.6, "minor": 0.25, "trivial": 0.1}
OPEN_DEFECT_STATUSES = {"new", "open", "triaged", "in_progress", "reopened"}

# A test this flaky or this recently red is coverage nobody can rely on.
FLAKY_THRESHOLD = 0.2
FAILING_RESULTS = {"failed", "error", "broken"}


def _clean_list(value: Any) -> list[str]:  # noqa: ANN401
    """A caller's list, stripped and de-duplicated, keeping its order."""
    if value is None:
        return []
    if isinstance(value, str):
        value = value.split(",")
    seen: dict[str, None] = {}
    for item in value:
        text = str(item).strip()
        if text and text.lower() not in {key.lower() for key in seen}:
            seen[text] = None
    return list(seen)


def _aware(moment: datetime | None) -> datetime | None:
    if moment is not None and moment.tzinfo is None:
        return moment.replace(tzinfo=UTC)
    return moment


def _is_unstable(case: TestCase) -> bool:
    return (case.flakiness_score or 0.0) >= FLAKY_THRESHOLD or case.last_result in FAILING_RESULTS


def _requirements_by_key(session: Any, project_id: str) -> dict[str, Requirement]:  # noqa: ANN401
    rows = session.execute(
        select(Requirement).where(
            Requirement.project_id == project_id, Requirement.is_deleted.is_(False)
        )
    ).scalars()
    return {row.external_key.upper(): row for row in rows}


def _live_cases(session: Any, project_id: str) -> list[TestCase]:  # noqa: ANN401
    return list(
        session.execute(
            select(TestCase).where(
                TestCase.project_id == project_id, TestCase.is_deleted.is_(False)
            )
        )
        .scalars()
        .all()
    )


def _defects(session: Any, project_id: str) -> list[Defect]:  # noqa: ANN401
    return list(
        session.execute(
            select(Defect).where(Defect.project_id == project_id, Defect.is_deleted.is_(False))
        )
        .scalars()
        .all()
    )


# ===========================================================================
# Prompt block fitting (used by Coverage Planning's build_messages)
# ===========================================================================

# Each fenced block is cut at app.ai.prompts.safety.DEFAULT_MAX_CHARS. A list
# cut there arrives as broken JSON with its most important rows possibly gone,
# so lists are fitted to a budget below that limit instead: whole rows only,
# worst first, and the block says how many of how many it shows.
BLOCK_BUDGET_CHARS = 3500


def _rendered_size(value: Any, depth: int) -> int:  # noqa: ANN401
    """Characters `value` takes once the fence pretty-prints it at `depth`.

    Measured the way `app.ai.prompts.library` renders a block -- JSON with an
    indent of two -- because compact JSON undercounts it by half or more.
    """
    text = json.dumps(value, indent=2, default=str, ensure_ascii=False)
    return len(text) + len(text.splitlines()) * 2 * depth + 2


def _fit(rows: list[Any], *, budget: int = BLOCK_BUDGET_CHARS, depth: int = 2) -> dict[str, Any]:
    """As many whole rows as fit the budget, with the total they were taken from.

    `depth` is how deeply the list sits inside its block, since every level
    adds indentation to every line.
    """
    shown: list[Any] = []
    used = 80  # the wrapper's own keys
    for row in rows:
        size = _rendered_size(row, depth)
        if used + size > budget:
            break
        shown.append(row)
        used += size
    return {"showing": len(shown), "of": len(rows), "rows": shown}


# ===========================================================================
# Coverage Planning
# ===========================================================================

# What each risk tier must have before it counts as covered.
TIER_POLICY: dict[str, dict[str, Any]] = {
    "critical": {"scenario_types": ["positive", "negative", "edge"], "min_cases": 4, "min_automated": 2, "execution_days": 30},
    "high": {"scenario_types": ["positive", "negative"], "min_cases": 3, "min_automated": 1, "execution_days": 30},
    "medium": {"scenario_types": ["positive", "negative"], "min_cases": 2, "min_automated": 0, "execution_days": None},
    "low": {"scenario_types": ["positive"], "min_cases": 1, "min_automated": 0, "execution_days": None},
}
TIER_WEIGHT = {"critical": 1.0, "high": 0.7, "medium": 0.4, "low": 0.15}

# Engineer-days per unit of work. Estimates, stated so they can be corrected.
EFFORT_DAYS = {
    "write_case": 0.3,
    "automate_case": 0.5,
    # Running what already exists: roughly 10 minutes by hand, 2-3 automated.
    "execute_manual_case": 0.02,
    "execute_automated_case": 0.005,
    "stabilise_case": 0.5,
    "cover_journey_step": 0.75,
}

# How much of a requirement's risk each kind of gap represents.
GAP_WEIGHT = {
    "missing_positive": 1.0,
    "missing_negative": 0.9,
    "missing_edge": 0.6,
    "too_few_cases": 0.5,
    "not_automated": 0.6,
    "not_executed": 0.7,
    "unstable": 0.5,
    "journey_step_untested": 0.9,
}


# How each gap reads to a person; the codes stay in `gaps` for machines.
GAP_PHRASE = {
    "missing_positive": "no positive-path test",
    "missing_negative": "no negative-path test",
    "missing_edge": "no edge-case test",
    "too_few_cases": "too few tests",
    "not_automated": "too little automation",
    "not_executed": "not run recently enough",
    "unstable": "flaky or failing tests",
    "journey_step_untested": "a journey step with no test",
}


def schedule(items: list[dict[str, Any]], capacity: float) -> float:
    """Order work by risk removed per day and fit it to the capacity.

    Sorts `items` in place, marks each `planned` or not, numbers them by `rank`,
    and returns the days left over. Greedy by efficiency, with one deliberate
    departure from a plain greedy fill: an item too large for what is left is
    skipped rather than ending the plan, so a big critical item that does not fit
    does not also push out the small ones ranked after it.
    """
    # The tier breaks ties so that, at equal efficiency, the more important
    # requirement goes first.
    items.sort(
        key=lambda item: (-item["priority_score"], -TIER_WEIGHT[item["tier"]], item.get("requirement") or "")
    )
    remaining = capacity
    for rank, item in enumerate(items, start=1):
        item["rank"] = rank
        item["planned"] = item["effort_days"] <= remaining + 1e-9
        if item["planned"]:
            remaining -= item["effort_days"]
    return remaining


def _tier(requirement: Requirement, open_defect_weight: float) -> tuple[str, float, dict[str, float]]:
    basis = {
        "priority": PRIORITY_WEIGHT.get(requirement.priority, 0.5),
        "risk_score": float(requirement.risk_score or 0.0),
        "change_frequency": min(requirement.change_frequency or 0, 10) / 10,
        "open_defects": min(1.0, open_defect_weight / 2),
    }
    score = (
        0.45 * basis["priority"]
        + 0.25 * basis["risk_score"]
        + 0.15 * basis["change_frequency"]
        + 0.15 * basis["open_defects"]
    )
    if score >= 0.7:
        tier = "critical"
    elif score >= 0.5:
        tier = "high"
    elif score >= 0.3:
        tier = "medium"
    else:
        tier = "low"
    return tier, round(score, 3), {k: round(v, 3) for k, v in basis.items()}


class CoveragePlanningAgent(BaseAgent):
    key = "coverage-planning"
    computed_outputs = True
    name = "Coverage Planning Agent"
    category = "Planning"
    description = (
        "Holds every requirement to the coverage its risk tier requires and turns the shortfall "
        "into a prioritised, effort-estimated plan that fits the capacity available."
    )
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "Target"
    supported_tools = ["knowledge"]
    goal = "Spend the testing days available where they remove the most risk, and say what is left."
    system_instructions = (
        "You are a coverage planner. Judge coverage against what each requirement's risk demands, "
        "not against a flat count; order work by risk removed per day; and be explicit about "
        "what does not fit and the risk that leaves."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "scope": {"type": "string", "description": "Release, sprint or label for this plan"},
            "modules": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Modules in scope; all when omitted",
            },
            "requirement_keys": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Specific requirements in scope, e.g. PAY-201",
            },
            "capacity_days": {
                "type": "number",
                "default": 10,
                "description": "Engineer-days available for the plan",
            },
            "include_journeys": {
                "type": "boolean",
                "default": True,
                "description": "Also plan tests for business journey steps nothing covers",
            },
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        session, project_id = ctx.session, ctx.project_id
        all_requirements = _requirements_by_key(session, project_id)

        keys = [key.upper() for key in _clean_list(inputs.get("requirement_keys"))]
        modules = {m.lower() for m in _clean_list(inputs.get("modules"))}
        unresolved = [key for key in keys if key not in all_requirements]

        in_scope = [
            row
            for key, row in sorted(all_requirements.items())
            if (not keys or key in keys) and (not modules or (row.module or "").lower() in modules)
        ]

        try:
            capacity = max(0.0, float(inputs.get("capacity_days", 10)))
        except (TypeError, ValueError):
            capacity = 10.0

        cases = _live_cases(session, project_id)
        scenarios = {
            row.id: row
            for row in session.execute(
                select(TestScenario).where(
                    TestScenario.project_id == project_id, TestScenario.is_deleted.is_(False)
                )
            ).scalars()
        }
        # A duplicate case repeats coverage someone already has; counting it
        # would make a requirement look better tested than it is.
        cases_by_requirement: dict[str, list[TestCase]] = {}
        duplicates = 0
        for case in cases:
            if case.duplicate_of_id:
                duplicates += 1
                continue
            requirement_id = case.requirement_id or (
                scenarios[case.scenario_id].requirement_id if case.scenario_id in scenarios else None
            )
            if requirement_id:
                cases_by_requirement.setdefault(requirement_id, []).append(case)

        defect_weight: dict[str, float] = {}
        for defect in _defects(session, project_id):
            if defect.status in OPEN_DEFECT_STATUSES and defect.requirement_id:
                defect_weight[defect.requirement_id] = defect_weight.get(
                    defect.requirement_id, 0.0
                ) + SEVERITY_WEIGHT.get(defect.severity, 0.3)

        now = datetime.now(UTC)
        rows: list[dict[str, Any]] = []
        items: list[dict[str, Any]] = []

        for requirement in in_scope:
            tier, tier_score, basis = _tier(requirement, defect_weight.get(requirement.id, 0.0))
            policy = TIER_POLICY[tier]
            linked = cases_by_requirement.get(requirement.id, [])
            types = sorted(
                {
                    scenarios[case.scenario_id].scenario_type
                    for case in linked
                    if case.scenario_id in scenarios
                }
            )
            automated = sum(1 for case in linked if case.is_automated)
            unstable = [case for case in linked if _is_unstable(case)]
            last_run = max((_aware(case.last_executed_at) for case in linked if case.last_executed_at), default=None)
            window = policy["execution_days"]
            executed_ok = window is None or (last_run is not None and last_run >= now - timedelta(days=window))

            gaps: list[dict[str, Any]] = []

            def add(kind: str, work: str, units: int, detail: str, effort: float | None = None) -> None:
                effort = round(EFFORT_DAYS[work] * units if effort is None else effort, 2)
                value = TIER_WEIGHT[tier] * GAP_WEIGHT[kind]
                gaps.append(
                    {
                        "requirement": requirement.external_key,
                        "module": requirement.module,
                        "tier": tier,
                        "gap": kind,
                        "work": work,
                        "units": units,
                        "effort_days": effort,
                        "risk_removed": round(value, 3),
                        "priority_score": round(value / effort, 3) if effort else value,
                        "detail": detail,
                    }
                )

            missing_types = [t for t in policy["scenario_types"] if t not in types]
            for scenario_type in missing_types:
                add(
                    f"missing_{scenario_type}",
                    "write_case",
                    1,
                    f"No {scenario_type}-path test; a {tier} requirement needs one.",
                )
            shortfall = policy["min_cases"] - len(linked) - len(missing_types)
            if shortfall > 0:
                add(
                    "too_few_cases",
                    "write_case",
                    shortfall,
                    f"{len(linked)} test(s); a {tier} requirement needs at least {policy['min_cases']}.",
                )
            automation_gap = policy["min_automated"] - automated
            if automation_gap > 0:
                add(
                    "not_automated",
                    "automate_case",
                    automation_gap,
                    f"{automated} automated; a {tier} requirement needs at least {policy['min_automated']}.",
                )
            if linked and not executed_ok:
                manual = len(linked) - automated
                add(
                    "not_executed",
                    "execute",
                    len(linked),
                    (
                        "Never executed."
                        if last_run is None
                        else f"Last executed {last_run.date().isoformat()}; a {tier} requirement needs a run within {window} days."
                    ),
                    effort=max(
                        0.05,
                        manual * EFFORT_DAYS["execute_manual_case"]
                        + automated * EFFORT_DAYS["execute_automated_case"],
                    ),
                )
            if unstable:
                add(
                    "unstable",
                    "stabilise_case",
                    len(unstable),
                    f"{len(unstable)} test(s) flaky or failing, so their coverage cannot be relied on.",
                )

            items.extend(gaps)
            rows.append(
                {
                    "requirement": requirement.external_key,
                    "title": requirement.title,
                    "module": requirement.module,
                    "priority": requirement.priority,
                    "tier": tier,
                    "tier_score": tier_score,
                    "tier_basis": basis,
                    "required": {k: v for k, v in policy.items()},
                    "current": {
                        "test_cases": len(linked),
                        "scenario_types": types,
                        "automated": automated,
                        "unstable": len(unstable),
                        "last_executed": last_run.isoformat() if last_run else None,
                    },
                    "gaps": [gap["gap"] for gap in gaps],
                    "meets_target": not gaps,
                }
            )

        # Journey steps nothing covers, weighted by the journey's criticality.
        journey_rows: list[dict[str, Any]] = []
        if inputs.get("include_journeys", True):
            covered_steps = {
                row[0]
                for row in session.execute(
                    select(TestDependency.business_flow_step_id).where(
                        TestDependency.project_id == project_id
                    )
                ).all()
            }
            flows = session.execute(
                select(BusinessFlow).where(
                    BusinessFlow.project_id == project_id, BusinessFlow.is_deleted.is_(False)
                )
            ).scalars()
            for flow in flows:
                for step in flow.steps:
                    if modules and (step.module or "").lower() not in modules:
                        continue
                    if step.id in covered_steps:
                        continue
                    tier = flow.criticality if flow.criticality in TIER_WEIGHT else "medium"
                    value = TIER_WEIGHT[tier] * GAP_WEIGHT["journey_step_untested"]
                    effort = EFFORT_DAYS["cover_journey_step"]
                    journey_rows.append({"journey": flow.name, "step": step.name, "tier": tier})
                    items.append(
                        {
                            "requirement": None,
                            "journey": flow.name,
                            "step": step.name,
                            "module": step.module,
                            "tier": tier,
                            "gap": "journey_step_untested",
                            "work": "cover_journey_step",
                            "units": 1,
                            "effort_days": effort,
                            "risk_removed": round(value, 3),
                            "priority_score": round(value / effort, 3),
                            "detail": f"'{step.name}' in {flow.name} has no test at all.",
                        }
                    )

        remaining = schedule(items, capacity)

        planned = [item for item in items if item["planned"]]
        deferred = [item for item in items if not item["planned"]]
        unplanned_requirements = {item["requirement"] for item in deferred if item["requirement"]}

        def weighted(met: set[str]) -> float:
            total = sum(TIER_WEIGHT[row["tier"]] for row in rows)
            got = sum(TIER_WEIGHT[row["tier"]] for row in rows if row["requirement"] in met)
            return round(got / total, 4) if total else 0.0

        met_now = {row["requirement"] for row in rows if row["meets_target"]}
        met_after = {row["requirement"] for row in rows if row["requirement"] not in unplanned_requirements}

        analysis = {
            "scope": {
                "label": str(inputs.get("scope") or "").strip() or None,
                "modules": sorted(modules),
                "requirement_keys": keys,
                "requirements_in_scope": len(rows),
            },
            "capacity": {
                "days_available": capacity,
                "days_planned": round(capacity - remaining, 2),
                "days_needed_for_everything": round(sum(item["effort_days"] for item in items), 2),
            },
            "coverage": {
                "meeting_target_now": len(met_now),
                "meeting_target_after_plan": len(met_after),
                "risk_weighted_now": weighted(met_now),
                "risk_weighted_after_plan": weighted(met_after),
                "by_tier": {
                    tier: {
                        "requirements": sum(1 for row in rows if row["tier"] == tier),
                        "meeting_target_now": sum(1 for row in rows if row["tier"] == tier and row["requirement"] in met_now),
                        "meeting_target_after_plan": sum(
                            1 for row in rows if row["tier"] == tier and row["requirement"] in met_after
                        ),
                    }
                    for tier in TIER_POLICY
                },
            },
            "requirements": rows,
            "untested_journey_steps": journey_rows,
            "plan": planned,
            "deferred": deferred,
            "unresolved_requirements": unresolved,
            "duplicates_excluded": duplicates,
            "assumptions": {
                "tier_policy": TIER_POLICY,
                "effort_days": EFFORT_DAYS,
                "gap_weights": GAP_WEIGHT,
                "tier_weights": TIER_WEIGHT,
                "tier_formula": "0.45*priority + 0.25*risk_score + 0.15*change_frequency + 0.15*open_defects",
                "unstable_means": f"flakiness >= {FLAKY_THRESHOLD} or last result failed",
            },
        }
        return {"analysis": analysis, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        analysis = context.get("analysis") or {}
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.coverage-planning.plan",
                requirements=_fit(
                    [
                        {key: row[key] for key in ("requirement", "priority", "tier", "gaps")}
                        for row in analysis.get("requirements", [])
                    ]
                ),
                gaps=_fit(
                    [
                        {
                            key: item.get(key)
                            for key in ("rank", "requirement", "step", "tier", "gap", "effort_days", "planned")
                        }
                        for item in analysis.get("plan", []) + analysis.get("deferred", [])
                    ]
                ),
                capacity={
                    **analysis.get("capacity", {}),
                    "scope": analysis.get("scope"),
                    "coverage": {
                        key: value
                        for key, value in (analysis.get("coverage") or {}).items()
                        if key != "by_tier"
                    },
                },
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        analysis = context["analysis"]
        rows = analysis["requirements"]
        if not rows:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No requirements match this scope, so there is nothing to plan.",
                "recommendations": [
                    {
                        "priority": "high",
                        "action": "Widen the scope, or ingest the requirements for these modules first.",
                    }
                ],
                "next_action": "ingest_requirements",
                "outputs": analysis,
            }

        coverage = analysis["coverage"]
        capacity = analysis["capacity"]
        plan = analysis["plan"]
        deferred = analysis["deferred"]
        deferred_critical = sorted(
            {item["requirement"] or item.get("step") for item in deferred if item["tier"] == "critical"}
        )

        findings = [
            {
                "type": "requirement_coverage",
                "severity": row["tier"],
                "requirement": row["requirement"],
                "module": row["module"],
                "tier": row["tier"],
                "meets_target": row["meets_target"],
                "gaps": row["gaps"],
                "detail": (
                    f"{row['requirement']} ({row['tier']}): "
                    + (
                    "meets its target."
                    if row["meets_target"]
                    else "; ".join(GAP_PHRASE.get(gap, gap) for gap in row["gaps"]) + "."
                )
                ),
            }
            for row in sorted(rows, key=lambda r: (r["meets_target"], -TIER_WEIGHT[r["tier"]], r["requirement"]))
        ]
        for step in analysis["untested_journey_steps"]:
            findings.append(
                {
                    "type": "journey_step_untested",
                    "severity": step["tier"],
                    "detail": f"'{step['step']}' in {step['journey']} has no test.",
                }
            )

        recommendations = [
            {
                "priority": item["tier"] if item["tier"] in ("critical", "high") else "medium",
                "action": (
                    f"#{item['rank']} {item['requirement'] or item.get('journey')}: {item['detail']} "
                    f"({item['work'].replace('_', ' ')} x{item['units']}, {item['effort_days']}d)"
                ),
            }
            for item in plan[:6]
        ]
        if deferred_critical:
            shortfall = round(capacity["days_needed_for_everything"] - capacity["days_available"], 1)
            recommendations.append(
                {
                    "priority": "critical",
                    "action": (
                        f"Capacity leaves critical work undone on {', '.join(deferred_critical[:5])}. "
                        f"Add about {shortfall} engineer-day(s), or record that this risk is accepted."
                    ),
                }
            )
        for key in analysis["unresolved_requirements"]:
            recommendations.append(
                {"priority": "medium", "action": f"{key} is not a requirement in this project; it was left out."}
            )

        label = analysis["scope"]["label"]
        summary = (
            (f"{label}: " if label else "")
            + f"{len(rows)} requirement(s) in scope; {coverage['meeting_target_now']} meet their risk-tier "
            f"target today. The plan schedules {len(plan)} of {len(plan) + len(deferred)} work item(s) in "
            f"{capacity['days_planned']} of {capacity['days_available']} engineer-day(s), raising that to "
            f"{coverage['meeting_target_after_plan']} (risk-weighted coverage "
            f"{coverage['risk_weighted_now']:.0%} to {coverage['risk_weighted_after_plan']:.0%})."
            + (
                f" {len(deferred)} item(s) deferred, including critical work on {len(deferred_critical)} item(s)."
                if deferred_critical
                else (f" {len(deferred)} lower-risk item(s) deferred." if deferred else " Nothing is deferred.")
            )
        )

        design_work = any(item["work"] in ("write_case", "cover_journey_step") for item in plan)
        return {
            "status": "partial" if analysis["unresolved_requirements"] else "success",
            "confidence": 0.85,
            "summary": summary,
            "findings": findings,
            "recommendations": recommendations,
            "reasoning_summary": (
                "Tiered each requirement by priority, risk, change frequency and open defects; held it to "
                "that tier's required scenario types, case count, automation and execution recency; "
                "ignored duplicate cases; and packed the gaps into the capacity by risk removed per day."
            ),
            "next_action": "generate_scenarios" if design_work else ("automate" if plan else "report"),
            "outputs": {
                **analysis,
                "effort_days_note": "Effort figures are estimates; correct EFFORT_DAYS for your team.",
            },
        }
