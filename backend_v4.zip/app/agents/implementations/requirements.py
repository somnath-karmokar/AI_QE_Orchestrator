"""Requirement and planning agents (catalogue entries 1-6)."""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import func, select

from app.agents.scoping import owned
from app.agents.base import AgentContext, BaseAgent
from app.ai.providers.base import ChatMessage
from app.models.testing import Requirement, TestCase, TestScenario, TestScript, TraceabilityLink
from app.vectorstore.base import COLLECTION_KNOWLEDGE, COLLECTION_REQUIREMENTS

# Signals a well-formed story is expected to carry. Used both to score
# completeness and to explain the score to the user.
_COMPLETENESS_CHECKS: list[tuple[str, str, str]] = [
    ("acceptance_criteria", "Acceptance criteria", "Add explicit, testable acceptance criteria."),
    ("description_depth", "Description detail", "Expand the description to cover the business rule and flow."),
    ("negative_paths", "Negative and error paths", "State expected behaviour for invalid and error conditions."),
    ("data_requirements", "Data requirements", "Identify the test data and preconditions needed."),
    ("non_functional", "Non-functional expectations", "Note performance, security or accessibility expectations."),
    ("dependencies", "Dependencies", "Call out upstream services or integrations this story depends on."),
]

_NEGATIVE_HINTS = ("invalid", "error", "fail", "reject", "denied", "unauthorized", "timeout", "exceed", "locked")
_DATA_HINTS = ("data", "account", "record", "customer", "balance", "amount", "limit", "credential")
_NFR_HINTS = ("performance", "response time", "security", "accessib", "wcag", "latency", "throughput", "audit")
_DEPENDENCY_HINTS = ("service", "api", "integration", "downstream", "upstream", "gateway", "provider")


def _find_requirement(ctx: AgentContext, inputs: dict[str, Any]) -> Requirement | None:
    """Resolve a requirement from either its id or its external key."""
    requirement_id = inputs.get("requirement_id")
    if requirement_id:
        requirement = owned(ctx, Requirement, requirement_id)
        if requirement is not None:
            return requirement
    key = inputs.get("requirement_key") or inputs.get("issue_key")
    if key:
        return ctx.session.execute(
            select(Requirement).where(
                Requirement.project_id == ctx.project_id, Requirement.external_key == key
            )
        ).scalar_one_or_none()
    return None


class UserStoryCompletenessAgent(BaseAgent):
    key = "user-story-completeness"
    name = "User Story Completeness Check"
    category = "Requirements"
    description = "Scores a user story against QE readiness criteria and lists the specific gaps blocking test design."
    capability = "structured_extraction"
    complexity = "simple"
    risk_level = "low"
    cost_tier = "low"
    icon = "ClipboardCheck"
    supported_tools = ["jira", "knowledge"]
    goal = "Determine whether a story contains enough detail to design tests from."
    system_instructions = (
        "You are a senior QE analyst reviewing user stories for testability. "
        "Score completeness from 0-100 and identify concrete, actionable gaps."
    )
    input_schema = {
        "type": "object",
        "required": ["requirement_key"],
        "properties": {
            "requirement_key": {"type": "string", "description": "Story key, e.g. PAY-201"},
            "requirement_id": {"type": "string", "description": "Internal requirement id"},
            "threshold": {"type": "integer", "description": "Score below which review is required", "default": 80},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        requirement = _find_requirement(ctx, inputs)
        story = None
        if requirement is not None:
            story = self.call_tool(
                ctx, "jira", "get_story", {"issue_key": requirement.external_key}, tool_calls=tool_calls
            )

        context_block, evidence = ("", [])
        if requirement is not None:
            context_block, evidence = ctx.knowledge.retrieve_context_block(
                f"{requirement.title} {requirement.module} acceptance criteria",
                project_id=ctx.project_id,
                collection=COLLECTION_KNOWLEDGE,
                limit=3,
                module=requirement.module,
            )

        return {
            "requirement": requirement,
            "story": story,
            "knowledge": context_block,
            "evidence": evidence,
            "tool_calls": tool_calls,
        }

    def _score(self, requirement: Requirement) -> tuple[float, list[dict[str, Any]]]:
        """Deterministic rubric over the story's actual content."""
        text = f"{requirement.title} {requirement.description or ''}".lower()
        criteria = requirement.acceptance_criteria or []
        criteria_text = " ".join(str(item) for item in criteria).lower()
        combined = f"{text} {criteria_text}"

        signals: dict[str, bool] = {
            "acceptance_criteria": len(criteria) >= 2,
            "description_depth": len(requirement.description or "") >= 180,
            "negative_paths": any(hint in combined for hint in _NEGATIVE_HINTS),
            "data_requirements": any(hint in combined for hint in _DATA_HINTS),
            "non_functional": any(hint in combined for hint in _NFR_HINTS),
            "dependencies": any(hint in combined for hint in _DEPENDENCY_HINTS),
        }

        # Acceptance criteria and description carry more weight than the rest.
        weights = {
            "acceptance_criteria": 30.0,
            "description_depth": 20.0,
            "negative_paths": 18.0,
            "data_requirements": 12.0,
            "non_functional": 10.0,
            "dependencies": 10.0,
        }
        score = sum(weights[key] for key, passed in signals.items() if passed)

        findings: list[dict[str, Any]] = []
        for signal_key, label, remedy in _COMPLETENESS_CHECKS:
            passed = signals[signal_key]
            findings.append(
                {
                    "check": label,
                    "status": "pass" if passed else "gap",
                    "weight": weights[signal_key],
                    "detail": (
                        f"{label} present in the story."
                        if passed
                        else f"{label} missing or insufficient. {remedy}"
                    ),
                }
            )
        return round(score, 1), findings

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        requirement: Requirement | None = context.get("requirement")
        story_text = "Requirement not found."
        if requirement is not None:
            criteria = "\n".join(f"- {item}" for item in (requirement.acceptance_criteria or [])) or "- none stated"
            story_text = (
                f"Key: {requirement.external_key}\n"
                f"Title: {requirement.title}\n"
                f"Module: {requirement.module}\n"
                f"Status: {requirement.status} | Priority: {requirement.priority}\n"
                f"Description:\n{requirement.description or '(empty)'}\n"
                f"Acceptance criteria:\n{criteria}"
            )

        return [
            self.system_message(ctx),
            self.task_message(
                "agent.user-story-completeness.assess",
                story=story_text,
                related_knowledge=context.get("knowledge") or "none retrieved",
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        requirement: Requirement | None = context.get("requirement")
        threshold = int(inputs.get("threshold", 80))

        if requirement is None:
            return {
                "status": "failed",
                "confidence": 0.2,
                "summary": f"Story '{inputs.get('requirement_key')}' was not found in this project.",
                "findings": [],
                "recommendations": [{"action": "Verify the story key or sync the Jira knowledge source."}],
                "next_action": "abort",
            }

        score, findings = self._score(requirement)
        gaps = [finding for finding in findings if finding["status"] == "gap"]
        passed = score >= threshold

        return {
            "status": "success" if passed else "needs_review",
            "confidence": round(min(0.97, 0.72 + (score / 400.0)), 3),
            "summary": (
                f"{requirement.external_key} scored {score:.0f}/100 for test readiness "
                f"({len(gaps)} gap{'s' if len(gaps) != 1 else ''} identified)."
            ),
            "findings": findings,
            "recommendations": [
                {"priority": "high" if gap["weight"] >= 18 else "medium", "action": gap["detail"]}
                for gap in gaps
            ],
            "reasoning_summary": (
                f"Applied a six-point readiness rubric to {requirement.external_key}. "
                f"{len(findings) - len(gaps)} of {len(findings)} checks passed, "
                f"weighted to a score of {score:.0f}."
            ),
            "next_action": "generate_scenarios" if passed else "request_clarification",
            "outputs": {
                "requirement_id": requirement.id,
                "requirement_key": requirement.external_key,
                "completeness_score": score,
                "threshold": threshold,
                "passed": passed,
                "gap_count": len(gaps),
                "module": requirement.module,
            },
        }

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        requirement_id = outputs.get("requirement_id")
        if not requirement_id:
            return []
        # The payload is the model's answer under a real provider; an id in it
        # is a claim, and is only honoured inside this project.
        requirement = owned(ctx, Requirement, requirement_id)
        if requirement is None:
            return []
        requirement.completeness_score = outputs.get("completeness_score")
        requirement.completeness_findings = payload.get("findings", [])
        requirement.last_analyzed_at = datetime.now(UTC)
        ctx.session.flush()
        return [
            {
                "type": "requirement_assessment",
                "label": f"Completeness assessment for {requirement.external_key}",
                "entity_type": "requirement",
                "entity_id": requirement.id,
            }
        ]


class TestKnowledgeAgent(BaseAgent):
    key = "test-knowledge"
    name = "Test Knowledge Agent"
    category = "Requirements"
    description = "Retrieves grounded context from the Knowledge Fabric: requirements, documentation, prior tests and defects."
    capability = "structured_extraction"
    complexity = "simple"
    risk_level = "low"
    cost_tier = "low"
    icon = "Library"
    supported_tools = ["knowledge", "confluence"]
    goal = "Assemble the evidence base later agents reason over."
    system_instructions = (
        "You are a knowledge retrieval specialist for quality engineering. "
        "Summarise what the retrieved material establishes, citing each source."
    )
    input_schema = {
        "type": "object",
        "required": ["query"],
        "properties": {
            "query": {"type": "string", "description": "What to look up"},
            "module": {"type": "string", "description": "Restrict to a module"},
            "limit": {"type": "integer", "description": "Chunks to retrieve", "default": 6},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        query = inputs["query"]
        module = inputs.get("module")
        limit = int(inputs.get("limit", 6))

        knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
            query, project_id=ctx.project_id, collection=COLLECTION_KNOWLEDGE, limit=limit, module=module
        )
        requirement_hits = ctx.knowledge.retrieve(
            query, project_id=ctx.project_id, collection=COLLECTION_REQUIREMENTS, limit=4, module=module
        )
        test_hits = ctx.knowledge.retrieve(
            query, project_id=ctx.project_id, collection="qe_test_cases", limit=4, module=module
        )

        for hit in requirement_hits:
            evidence.append(
                {
                    "ref": f"[R{len(evidence) + 1}]",
                    "title": hit.metadata.get("title", "Requirement"),
                    "source_type": "requirement",
                    "external_id": hit.metadata.get("external_id"),
                    "score": round(hit.score, 3),
                }
            )

        return {
            "knowledge": knowledge_block,
            "evidence": evidence,
            "requirement_hits": requirement_hits,
            "test_hits": test_hits,
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.test-knowledge.summarise",
                query=inputs["query"],
                retrieved_context=context.get("knowledge"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        evidence = context.get("evidence", [])
        requirement_hits = context.get("requirement_hits", [])
        test_hits = context.get("test_hits", [])
        top_score = max((item.get("score", 0) for item in evidence), default=0.0)

        findings = [
            {
                "source": item.get("title"),
                "source_type": item.get("source_type"),
                "external_id": item.get("external_id"),
                "relevance": item.get("score"),
            }
            for item in evidence[:8]
        ]

        return {
            "status": "success" if evidence else "partial",
            "confidence": round(min(0.95, 0.45 + top_score / 2), 3),
            "summary": (
                f"Retrieved {len(evidence)} knowledge item(s), {len(requirement_hits)} related requirement(s) "
                f"and {len(test_hits)} related test(s) for '{inputs['query']}'."
            ),
            "findings": findings,
            "recommendations": (
                []
                if evidence
                else [{"action": "Index additional documentation; retrieval returned no grounded context."}]
            ),
            "reasoning_summary": (
                f"Semantic search across the knowledge, requirement and test-case collections, "
                f"scoped to project {ctx.project.key}"
                + (f" and module {inputs['module']}." if inputs.get("module") else ".")
            ),
            "next_action": "generate_scenarios",
            "outputs": {
                "context": context.get("knowledge", ""),
                "evidence_count": len(evidence),
                "related_requirements": [
                    hit.metadata.get("external_id") for hit in requirement_hits if hit.metadata.get("external_id")
                ],
                "related_tests": [hit.metadata.get("external_id") for hit in test_hits],
            },
        }


class TestScenarioGeneratorAgent(BaseAgent):
    key = "test-scenario-generator"
    name = "Test Scenario Generator"
    category = "Test Design"
    description = "Generates positive, negative and edge-case scenarios from a requirement and its acceptance criteria."
    capability = "generation"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "ListTree"
    supported_tools = ["jira", "knowledge"]
    goal = "Produce complete scenario coverage for a requirement."
    system_instructions = (
        "You are a test design specialist. Derive scenarios that cover the happy path, "
        "every negative and error condition, and the boundary cases implied by the acceptance criteria."
    )
    input_schema = {
        "type": "object",
        "required": ["requirement_key"],
        "properties": {
            "requirement_key": {"type": "string"},
            "requirement_id": {"type": "string"},
            "max_scenarios": {"type": "integer", "default": 8},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        tool_calls: list[dict[str, Any]] = []
        requirement = _find_requirement(ctx, inputs)
        evidence: list[dict[str, Any]] = []
        knowledge_block = ""
        if requirement is not None:
            knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
                f"{requirement.title} {requirement.module} business rules",
                project_id=ctx.project_id,
                limit=4,
                module=requirement.module,
            )
        return {
            "requirement": requirement,
            "knowledge": knowledge_block,
            "evidence": evidence,
            "tool_calls": tool_calls,
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        requirement: Requirement | None = context.get("requirement")
        story_text = "Requirement not found."
        if requirement is not None:
            criteria = "\n".join(f"- {item}" for item in (requirement.acceptance_criteria or []))
            story_text = (
                f"{requirement.external_key}: {requirement.title}\n"
                f"Module: {requirement.module}\n"
                f"Description: {requirement.description}\n"
                f"Acceptance criteria:\n{criteria}"
            )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.test-scenario-generator.generate",
                {"max_scenarios": int(inputs.get("max_scenarios", 8))},
                requirement=story_text,
                domain_knowledge=context.get("knowledge"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        requirement: Requirement | None = context.get("requirement")
        if requirement is None:
            return {
                "status": "failed",
                "confidence": 0.2,
                "summary": f"Requirement '{inputs.get('requirement_key')}' was not found.",
                "next_action": "abort",
            }

        max_scenarios = int(inputs.get("max_scenarios", 8))
        criteria = [str(item) for item in (requirement.acceptance_criteria or [])]
        scenarios: list[dict[str, Any]] = []

        # One positive scenario per acceptance criterion keeps traceability 1:1.
        for index, criterion in enumerate(criteria, start=1):
            scenarios.append(
                {
                    "title": f"Verify {self._condense(criterion)}",
                    "type": "positive",
                    "priority": requirement.priority,
                    "risk_level": "medium",
                    "description": f"Confirm the system satisfies: {criterion}",
                    "covers_criterion": index,
                }
            )

        if not scenarios:
            scenarios.append(
                {
                    "title": f"Verify {self._condense(requirement.title)} succeeds on the primary path",
                    "type": "positive",
                    "priority": requirement.priority,
                    "risk_level": "medium",
                    "description": requirement.description or requirement.title,
                    "covers_criterion": None,
                }
            )

        # Negative and edge scenarios derived from the story's own vocabulary.
        for negative in self._negative_scenarios(requirement):
            scenarios.append(negative)
        for edge in self._edge_scenarios(requirement):
            scenarios.append(edge)

        scenarios = scenarios[:max_scenarios]
        by_type: dict[str, int] = {}
        for scenario in scenarios:
            by_type[scenario["type"]] = by_type.get(scenario["type"], 0) + 1

        return {
            "status": "success",
            "confidence": round(min(0.95, 0.68 + 0.03 * len(criteria)), 3),
            "summary": (
                f"Generated {len(scenarios)} scenarios for {requirement.external_key}: "
                + ", ".join(f"{count} {name}" for name, count in sorted(by_type.items()))
                + "."
            ),
            "findings": scenarios,
            "recommendations": [
                {"action": f"Review {by_type.get('negative', 0)} negative scenarios with the business analyst."}
            ]
            if by_type.get("negative")
            else [],
            "reasoning_summary": (
                f"Derived one positive scenario per acceptance criterion ({len(criteria)} total), then added "
                f"negative and boundary scenarios implied by the story's error and limit vocabulary."
            ),
            "next_action": "generate_test_cases",
            "outputs": {
                "requirement_id": requirement.id,
                "requirement_key": requirement.external_key,
                "module": requirement.module,
                "scenario_count": len(scenarios),
                "scenarios": scenarios,
            },
        }

    @staticmethod
    def _condense(text: str, limit: int = 90) -> str:
        cleaned = re.sub(r"^(given|when|then|and)\s+", "", text.strip(), flags=re.IGNORECASE)
        cleaned = cleaned.rstrip(".")
        return cleaned[:limit]

    def _negative_scenarios(self, requirement: Requirement) -> list[dict[str, Any]]:
        combined = f"{requirement.title} {requirement.description or ''}".lower()
        scenarios: list[dict[str, Any]] = []
        module = requirement.module

        if any(hint in combined for hint in ("login", "authenticat", "credential", "password")):
            scenarios.append(
                {
                    "title": f"Reject {module.lower()} attempt with invalid credentials",
                    "type": "negative",
                    "priority": "high",
                    "risk_level": "high",
                    "description": "Invalid credentials must be rejected with a non-disclosing error message.",
                }
            )
        if any(hint in combined for hint in ("limit", "amount", "balance", "threshold")):
            scenarios.append(
                {
                    "title": f"Reject {module.lower()} request that exceeds the permitted limit",
                    "type": "negative",
                    "priority": "high",
                    "risk_level": "high",
                    "description": "A request above the configured limit must be rejected and explained.",
                }
            )
        if any(hint in combined for hint in ("mandatory", "required", "valid")):
            scenarios.append(
                {
                    "title": f"Reject {module.lower()} submission with missing mandatory fields",
                    "type": "negative",
                    "priority": "medium",
                    "risk_level": "medium",
                    "description": "Field-level validation must block submission and identify each missing field.",
                }
            )
        if not scenarios:
            scenarios.append(
                {
                    "title": f"Handle {module.lower()} failure path gracefully",
                    "type": "negative",
                    "priority": "medium",
                    "risk_level": "medium",
                    "description": "The system must fail safely and communicate the error to the user.",
                }
            )
        return scenarios

    def _edge_scenarios(self, requirement: Requirement) -> list[dict[str, Any]]:
        module = requirement.module
        return [
            {
                "title": f"Validate {module.lower()} behaviour at boundary values",
                "type": "edge",
                "priority": "medium",
                "risk_level": "medium",
                "description": "Exercise minimum, maximum and just-outside-range values for each bounded input.",
            },
            {
                "title": f"Verify {module.lower()} under concurrent requests",
                "type": "edge",
                "priority": "low",
                "risk_level": "medium",
                "description": "Confirm no duplicate or partial state results from simultaneous submissions.",
            },
        ]

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        outputs = payload.get("outputs", {})
        requirement_id = outputs.get("requirement_id")
        scenarios = outputs.get("scenarios", [])
        if not requirement_id or not scenarios:
            return []

        requirement = owned(ctx, Requirement, requirement_id)
        if requirement is None:
            return []

        existing = ctx.session.execute(
            select(func.count(TestScenario.id)).where(TestScenario.project_id == ctx.project_id)
        ).scalar_one()

        artifacts: list[dict[str, Any]] = []
        for offset, scenario in enumerate(scenarios, start=1):
            row = TestScenario(
                project_id=ctx.project_id,
                requirement_id=requirement.id,
                key=f"SCN-{existing + offset:04d}",
                title=scenario.get("title", "Untitled scenario"),
                description=scenario.get("description"),
                scenario_type=scenario.get("type", "positive"),
                module=requirement.module,
                priority=scenario.get("priority", "medium"),
                risk_level=scenario.get("risk_level", "medium"),
                generated_by_agent=self.key,
                generated_by_run_id=ctx.run_id,
                confidence=payload.get("confidence"),
            )
            ctx.session.add(row)
            ctx.session.flush()

            ctx.session.add(
                TraceabilityLink(
                    project_id=ctx.project_id,
                    source_type="requirement",
                    source_id=requirement.id,
                    target_type="scenario",
                    target_id=row.id,
                    link_type="covers",
                    created_by_agent=self.key,
                )
            )
            artifacts.append(
                {
                    "type": "test_scenario",
                    "label": f"{row.key} {row.title}",
                    "entity_type": "test_scenario",
                    "entity_id": row.id,
                }
            )

        ctx.session.flush()
        return artifacts


class TestDesignAgent(BaseAgent):
    key = "test-design"
    name = "Test Design Agent"
    category = "Test Design"
    description = "Expands scenarios into executable test cases with preconditions, ordered steps and expected results."
    capability = "generation"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "FileText"
    supported_tools = ["knowledge", "jira"]
    goal = "Turn scenarios into unambiguous, executable test cases."
    system_instructions = (
        "You are a test design engineer. Write test cases a new team member could execute "
        "without asking questions: explicit preconditions, numbered steps, one verifiable expected result."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "requirement_key": {"type": "string"},
            "requirement_id": {"type": "string"},
            "scenario_ids": {"type": "array", "description": "Specific scenarios to expand"},
            "test_type": {"type": "string", "default": "functional"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        requirement = _find_requirement(ctx, inputs)
        statement = select(TestScenario).where(
            TestScenario.project_id == ctx.project_id, TestScenario.is_deleted.is_(False)
        )
        if inputs.get("scenario_ids"):
            statement = statement.where(TestScenario.id.in_(inputs["scenario_ids"]))
        elif requirement is not None:
            statement = statement.where(TestScenario.requirement_id == requirement.id)
        else:
            statement = statement.limit(10)

        scenarios = list(ctx.session.execute(statement).scalars().all())
        knowledge_block, evidence = ("", [])
        if requirement is not None:
            knowledge_block, evidence = ctx.knowledge.retrieve_context_block(
                f"{requirement.module} test steps preconditions",
                project_id=ctx.project_id,
                limit=3,
                module=requirement.module,
            )
        return {
            "requirement": requirement,
            "scenarios": scenarios,
            "knowledge": knowledge_block,
            "evidence": evidence,
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        scenarios: list[TestScenario] = context.get("scenarios", [])
        listing = "\n".join(
            f"- {scenario.key} [{scenario.scenario_type}] {scenario.title}: {scenario.description or ''}"
            for scenario in scenarios
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.test-design.expand",
                scenarios=listing or "none",
                domain_knowledge=context.get("knowledge"),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        scenarios: list[TestScenario] = context.get("scenarios", [])
        if not scenarios:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No scenarios were available to expand into test cases.",
                "recommendations": [{"action": "Run the Test Scenario Generator first."}],
                "next_action": "generate_scenarios",
            }

        test_cases: list[dict[str, Any]] = []
        for scenario in scenarios:
            test_cases.append(
                {
                    "scenario_id": scenario.id,
                    "scenario_key": scenario.key,
                    "title": scenario.title,
                    "objective": scenario.description or scenario.title,
                    "module": scenario.module,
                    "priority": scenario.priority,
                    "test_type": inputs.get("test_type", "functional"),
                    "preconditions": self._preconditions(scenario),
                    "steps": self._steps(scenario),
                    "expected_result": self._expected_result(scenario),
                }
            )

        return {
            "status": "success",
            "confidence": 0.87,
            "summary": f"Designed {len(test_cases)} test case(s) from {len(scenarios)} scenario(s).",
            "findings": [
                {"title": case["title"], "steps": len(case["steps"]), "priority": case["priority"]}
                for case in test_cases
            ],
            "reasoning_summary": (
                "Each scenario was expanded into preconditions, an ordered interaction sequence and a single "
                "verifiable assertion, with negative cases asserting rejection rather than success."
            ),
            "next_action": "generate_test_data",
            "outputs": {"test_case_count": len(test_cases), "test_cases": test_cases},
        }

    @staticmethod
    def _preconditions(scenario: TestScenario) -> list[str]:
        preconditions = [
            f"The {scenario.module} module is deployed and reachable in the target environment.",
            "A test user with the required entitlements is available.",
        ]
        if scenario.scenario_type == "negative":
            preconditions.append("Validation rules and error messaging are configured as specified.")
        if scenario.scenario_type == "edge":
            preconditions.append("Boundary configuration values are known and documented.")
        return preconditions

    @staticmethod
    def _steps(scenario: TestScenario) -> list[dict[str, Any]]:
        module = scenario.module
        steps: list[dict[str, Any]] = [
            {"step": 1, "action": f"Navigate to the {module} screen.", "data": None},
            {"step": 2, "action": "Authenticate as the prepared test user.", "data": "test credentials"},
        ]
        if scenario.scenario_type == "positive":
            steps.append({"step": 3, "action": f"Complete the {module} flow with valid data.", "data": "valid data set"})
            steps.append({"step": 4, "action": "Submit the request and wait for confirmation.", "data": None})
        elif scenario.scenario_type == "negative":
            steps.append({"step": 3, "action": f"Complete the {module} flow with invalid data.", "data": "invalid data set"})
            steps.append({"step": 4, "action": "Submit the request.", "data": None})
        else:
            steps.append({"step": 3, "action": "Enter the boundary value under test.", "data": "boundary data set"})
            steps.append({"step": 4, "action": "Submit and observe system behaviour.", "data": None})
        steps.append({"step": 5, "action": "Verify the resulting state in the UI and backing data.", "data": None})
        return steps

    @staticmethod
    def _expected_result(scenario: TestScenario) -> str:
        if scenario.scenario_type == "positive":
            return f"The {scenario.module} operation completes successfully and the resulting record reflects the submitted values."
        if scenario.scenario_type == "negative":
            return "The operation is rejected, a specific validation message is displayed, and no state change is persisted."
        return "The system handles the boundary condition deterministically without error or data corruption."

    def persist(
        self, ctx: AgentContext, inputs: dict[str, Any], payload: dict[str, Any]
    ) -> list[dict[str, Any]]:
        cases = payload.get("outputs", {}).get("test_cases", [])
        if not cases:
            return []

        existing = ctx.session.execute(
            select(func.count(TestCase.id)).where(TestCase.project_id == ctx.project_id)
        ).scalar_one()

        artifacts: list[dict[str, Any]] = []
        for offset, case in enumerate(cases, start=1):
            scenario = owned(ctx, TestScenario, case.get("scenario_id"))
            row = TestCase(
                project_id=ctx.project_id,
                scenario_id=scenario.id if scenario else None,
                requirement_id=scenario.requirement_id if scenario else None,
                key=f"TC-{existing + offset:04d}",
                title=case["title"],
                objective=case.get("objective"),
                preconditions=case.get("preconditions", []),
                steps=case.get("steps", []),
                expected_result=case.get("expected_result"),
                test_type=case.get("test_type", "functional"),
                priority=case.get("priority", "medium"),
                module=case.get("module", "General"),
                generated_by_agent=self.key,
            )
            ctx.session.add(row)
            ctx.session.flush()

            if case.get("scenario_id"):
                ctx.session.add(
                    TraceabilityLink(
                        project_id=ctx.project_id,
                        source_type="scenario",
                        source_id=case["scenario_id"],
                        target_type="test_case",
                        target_id=row.id,
                        link_type="covers",
                        created_by_agent=self.key,
                    )
                )
            artifacts.append(
                {
                    "type": "test_case",
                    "label": f"{row.key} {row.title}",
                    "entity_type": "test_case",
                    "entity_id": row.id,
                }
            )

        ctx.session.flush()
        return artifacts


class TestPlanningAgent(BaseAgent):
    key = "test-planning"
    name = "Test Planning Agent"
    category = "Planning"
    description = "Builds a risk-based test plan: scope, approach, effort estimate and entry/exit criteria."
    capability = "reasoning"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "medium"
    icon = "CalendarRange"
    supported_tools = ["jira", "knowledge"]
    goal = "Produce a defensible, risk-weighted test plan for a release or sprint."
    system_instructions = (
        "You are a QE lead producing a test plan. Prioritise by risk and change frequency, "
        "state the approach per module, and give explicit entry and exit criteria."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "scope": {"type": "string", "description": "Release, sprint or module scope"},
            "modules": {"type": "array", "description": "Modules in scope"},
        },
    }

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        statement = select(Requirement).where(
            Requirement.project_id == ctx.project_id, Requirement.is_deleted.is_(False)
        )
        if inputs.get("modules"):
            statement = statement.where(Requirement.module.in_(inputs["modules"]))
        requirements = list(ctx.session.execute(statement).scalars().all())

        coverage = {
            row[0]: row[1]
            for row in ctx.session.execute(
                select(TestCase.module, func.count(TestCase.id))
                .where(TestCase.project_id == ctx.project_id, TestCase.is_deleted.is_(False))
                .group_by(TestCase.module)
            ).all()
        }
        return {"requirements": requirements, "coverage": coverage, "evidence": [], "tool_calls": []}

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        requirements: list[Requirement] = context.get("requirements", [])
        listing = "\n".join(
            f"- {req.external_key} [{req.module}] {req.title} (priority {req.priority}, risk {req.risk_score:.2f})"
            for req in requirements[:40]
        )
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.test-planning.plan",
                scope=inputs.get("scope", "current release"),
                requirements_in_scope=listing or "none",
                existing_coverage=context.get("coverage", {}),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        requirements: list[Requirement] = context.get("requirements", [])
        coverage: dict[str, int] = context.get("coverage", {})
        if not requirements:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No requirements are in scope for planning.",
                "next_action": "ingest_requirements",
            }

        modules: dict[str, list[Requirement]] = {}
        for requirement in requirements:
            modules.setdefault(requirement.module, []).append(requirement)

        priority_weight = {"critical": 1.0, "high": 0.8, "medium": 0.5, "low": 0.25}
        module_plans: list[dict[str, Any]] = []
        total_effort = 0.0

        for module, items in sorted(modules.items()):
            risk = sum(
                priority_weight.get(req.priority, 0.5) + min(req.change_frequency, 10) / 20.0 for req in items
            ) / len(items)
            existing_cases = coverage.get(module, 0)
            # ~3 cases per requirement is the planning heuristic; only the shortfall is estimated.
            target_cases = len(items) * 3
            shortfall = max(0, target_cases - existing_cases)
            effort_days = round(shortfall * 0.35 + len(items) * 0.4, 1)
            total_effort += effort_days

            module_plans.append(
                {
                    "module": module,
                    "requirement_count": len(items),
                    "risk_score": round(min(1.0, risk), 3),
                    "priority": "high" if risk >= 0.75 else "medium" if risk >= 0.5 else "low",
                    "existing_test_cases": existing_cases,
                    "target_test_cases": target_cases,
                    "additional_cases_needed": shortfall,
                    "estimated_effort_days": effort_days,
                    "approach": self._approach(module, risk),
                }
            )

        module_plans.sort(key=lambda item: item["risk_score"], reverse=True)

        return {
            "status": "success",
            "confidence": 0.84,
            "summary": (
                f"Test plan covering {len(requirements)} requirement(s) across {len(module_plans)} module(s); "
                f"estimated {total_effort:.1f} engineer-days, highest risk in {module_plans[0]['module']}."
            ),
            "findings": module_plans,
            "recommendations": [
                {
                    "priority": "high",
                    "action": f"Start with {plan['module']}: {plan['additional_cases_needed']} additional cases needed at risk {plan['risk_score']}.",
                }
                for plan in module_plans[:3]
                if plan["additional_cases_needed"] > 0
            ],
            "reasoning_summary": (
                "Modules ranked by requirement priority and change frequency; effort estimated from the gap "
                "between existing coverage and a three-cases-per-requirement target."
            ),
            "next_action": "generate_scenarios",
            "outputs": {
                "scope": inputs.get("scope", "current release"),
                "total_effort_days": round(total_effort, 1),
                "module_plans": module_plans,
                "entry_criteria": [
                    "All in-scope stories meet the completeness threshold.",
                    "Test environment is provisioned and healthy.",
                    "Test data sets are generated and masked.",
                ],
                "exit_criteria": [
                    "100% of critical and high priority cases executed.",
                    "No open blocker or critical defects.",
                    "Automation coverage for regression-critical paths in place.",
                ],
            },
        }

    @staticmethod
    def _approach(module: str, risk: float) -> str:
        if risk >= 0.75:
            return f"Full functional plus regression and negative-path automation for {module}; peer review of every case."
        if risk >= 0.5:
            return f"Functional coverage with automated regression for the primary {module} journeys."
        return f"Smoke and targeted functional coverage for {module}; automate only stable paths."


class TraceabilityCoverageAgent(BaseAgent):
    key = "traceability-coverage"
    name = "Traceability and Coverage Agent"
    category = "Reporting"
    description = "Builds the requirement-to-defect traceability graph and reports coverage gaps."
    capability = "structured_extraction"
    complexity = "standard"
    risk_level = "low"
    cost_tier = "low"
    icon = "Network"
    supported_tools = ["knowledge"]
    goal = "Expose uncovered requirements and broken traceability chains."
    system_instructions = (
        "You are a coverage analyst. Report what is covered, what is not, and which gaps matter most."
    )
    input_schema = {"type": "object", "properties": {"module": {"type": "string"}}}

    def gather_context(self, ctx: AgentContext, inputs: dict[str, Any]) -> dict[str, Any]:
        module = inputs.get("module")
        requirement_query = select(Requirement).where(
            Requirement.project_id == ctx.project_id, Requirement.is_deleted.is_(False)
        )
        if module:
            requirement_query = requirement_query.where(Requirement.module == module)
        requirements = list(ctx.session.execute(requirement_query).scalars().all())

        scenarios = list(
            ctx.session.execute(
                select(TestScenario).where(
                    TestScenario.project_id == ctx.project_id, TestScenario.is_deleted.is_(False)
                )
            )
            .scalars()
            .all()
        )
        cases = list(
            ctx.session.execute(
                select(TestCase).where(TestCase.project_id == ctx.project_id, TestCase.is_deleted.is_(False))
            )
            .scalars()
            .all()
        )
        automated_case_ids = {
            row[0]
            for row in ctx.session.execute(
                select(TestScript.test_case_id).where(
                    TestScript.project_id == ctx.project_id, TestScript.is_deleted.is_(False)
                )
            ).all()
            if row[0]
        }
        return {
            "requirements": requirements,
            "scenarios": scenarios,
            "cases": cases,
            "automated_case_ids": automated_case_ids,
            "evidence": [],
            "tool_calls": [],
        }

    def build_messages(
        self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]
    ) -> list[ChatMessage]:
        return [
            self.system_message(ctx),
            self.task_message(
                "agent.traceability-coverage.analyse",
                counts=(
                    f"requirements={len(context.get('requirements', []))} "
                    f"scenarios={len(context.get('scenarios', []))} "
                    f"cases={len(context.get('cases', []))} "
                    f"automated={len(context.get('automated_case_ids', set()))}"
                ),
            ),
        ]

    def draft(self, ctx: AgentContext, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        requirements: list[Requirement] = context.get("requirements", [])
        scenarios: list[TestScenario] = context.get("scenarios", [])
        cases: list[TestCase] = context.get("cases", [])
        automated_case_ids: set[str] = context.get("automated_case_ids", set())

        if not requirements:
            return {
                "status": "partial",
                "confidence": 0.3,
                "summary": "No requirements are available to trace.",
                "next_action": "ingest_requirements",
            }

        scenarios_by_requirement: dict[str, list[TestScenario]] = {}
        for scenario in scenarios:
            if scenario.requirement_id:
                scenarios_by_requirement.setdefault(scenario.requirement_id, []).append(scenario)

        cases_by_scenario: dict[str, list[TestCase]] = {}
        for case in cases:
            if case.scenario_id:
                cases_by_scenario.setdefault(case.scenario_id, []).append(case)

        rows: list[dict[str, Any]] = []
        uncovered: list[dict[str, Any]] = []
        scenario_covered = automated_covered = executed_covered = 0

        for requirement in requirements:
            linked_scenarios = scenarios_by_requirement.get(requirement.id, [])
            linked_cases = [
                case for scenario in linked_scenarios for case in cases_by_scenario.get(scenario.id, [])
            ]
            automated = [case for case in linked_cases if case.id in automated_case_ids]
            executed = [case for case in linked_cases if case.execution_count > 0]

            if linked_scenarios:
                scenario_covered += 1
            if automated:
                automated_covered += 1
            if executed:
                executed_covered += 1

            row = {
                "requirement_key": requirement.external_key,
                "requirement_id": requirement.id,
                "title": requirement.title,
                "module": requirement.module,
                "priority": requirement.priority,
                "scenario_count": len(linked_scenarios),
                "test_case_count": len(linked_cases),
                "automated_count": len(automated),
                "executed_count": len(executed),
                "status": "covered" if linked_cases else "uncovered",
            }
            rows.append(row)
            if not linked_cases:
                uncovered.append(row)

        total = len(requirements)
        return {
            "status": "success",
            "confidence": 0.95,
            "summary": (
                f"{scenario_covered}/{total} requirements have scenarios, "
                f"{automated_covered}/{total} have automation, {len(uncovered)} are uncovered."
            ),
            "findings": rows,
            "recommendations": [
                {
                    "priority": "high" if row["priority"] in ("critical", "high") else "medium",
                    "action": f"{row['requirement_key']} ({row['module']}) has no test coverage.",
                }
                for row in uncovered[:10]
            ],
            "reasoning_summary": (
                "Walked the requirement -> scenario -> test case -> automation -> execution chain and flagged "
                "every requirement whose chain terminates early."
            ),
            "next_action": "generate_scenarios" if uncovered else "report",
            "outputs": {
                "requirement_coverage": round(scenario_covered / total, 4),
                "automation_coverage": round(automated_covered / total, 4),
                "execution_coverage": round(executed_covered / total, 4),
                "uncovered_count": len(uncovered),
                "matrix": rows,
            },
        }
