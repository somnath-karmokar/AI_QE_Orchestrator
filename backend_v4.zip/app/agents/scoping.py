"""Looking up a row an agent was told about, without leaving the run's project.

Agents take identifiers as inputs -- an execution, a failing test, a defect, a
data set -- and those inputs can come from another platform over the
integration API. `session.get(Model, identifier)` loads the row whatever project
it belongs to, so every agent that did that would read, and in two cases write,
another tenant's data for anyone holding the right UUID. Being hard to guess is
not a boundary: identifiers turn up in links, logs and screenshots.

Every identifier-driven lookup in an agent goes through here instead. A row from
another project is simply not found, which is what the caller would see if the
identifier were wrong -- the same rule the API applies (404, never "not yours").

Where a model has a key people actually use (`DEF-0003`, `PAY-201`, `TC-0006`)
it is accepted in place of the internal id, because a calling platform knows the
key and has no reason to know our primary keys.
"""

from __future__ import annotations

from typing import Any, TypeVar

from sqlalchemy import or_, select

from app.agents.base import AgentContext
from app.models.testing import Execution, ExecutionTest

ModelT = TypeVar("ModelT")


def owned(ctx: AgentContext, model: type[ModelT], identifier: Any, *, key_column: Any = None) -> ModelT | None:  # noqa: ANN401
    """One row of this run's project, by id or by its human key."""
    if not identifier:
        return None
    value = str(identifier)
    match = [model.id == value]
    if key_column is not None:
        match.append(key_column == value)
    statement = select(model).where(or_(*match), model.project_id == ctx.project_id)
    if hasattr(model, "is_deleted"):
        statement = statement.where(model.is_deleted.is_(False))
    return ctx.session.execute(statement).scalars().first()


def owned_execution(ctx: AgentContext, identifier: Any) -> Execution | None:  # noqa: ANN401
    return owned(ctx, Execution, identifier)


def project_executions(ctx: AgentContext):  # noqa: ANN201 - a SQLAlchemy subquery
    """Ids of this project's executions, for filtering execution tests."""
    return select(Execution.id).where(Execution.project_id == ctx.project_id).scalar_subquery()


def owned_execution_test(ctx: AgentContext, identifier: Any) -> ExecutionTest | None:  # noqa: ANN401
    """An execution test belongs to a project through its execution."""
    if not identifier:
        return None
    return ctx.session.execute(
        select(ExecutionTest).where(
            ExecutionTest.id == str(identifier),
            ExecutionTest.execution_id.in_(project_executions(ctx)),
        )
    ).scalars().first()
