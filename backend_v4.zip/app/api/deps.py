"""Shared FastAPI dependencies: session, authentication, authorization, paging."""

from __future__ import annotations

from collections.abc import Callable
from typing import Annotated

from fastapi import Depends, Header, Query, Request
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.errors import AuthenticationError, NotFoundError
from app.core.security import Principal, principal_from_token
from app.core.tenancy import assert_project_access
from app.models.project import Project
from app.schemas.common import PaginationParams

# `scope="function"` makes the session commit when the handler returns, *before*
# the response is sent. FastAPI's default runs a yield-dependency's teardown after
# the response has gone out, and that teardown is where `get_db` commits. With the
# default, a client is told a write succeeded before it exists: a key issued in one
# request was refused by the very next, and a commit that failed (a locked
# database, a constraint) failed after the client had already been told "201" and
# was never reported to it. Nothing here streams from this session, so it needs no
# longer life than the handler.
DbSession = Annotated[Session, Depends(get_db, scope="function")]


def get_principal(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
) -> Principal:
    """Resolve the caller from the bearer token."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise AuthenticationError("An authentication token is required.")
    principal = principal_from_token(authorization.split(" ", 1)[1].strip())
    request.state.principal = principal
    return principal


CurrentUser = Annotated[Principal, Depends(get_principal)]


def require_permission(permission: str) -> Callable[[Principal], Principal]:
    """Dependency factory enforcing a single permission."""

    def _dependency(principal: CurrentUser) -> Principal:
        principal.require(permission)
        return principal

    return _dependency


def get_pagination(
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> PaginationParams:
    return PaginationParams(limit=limit, offset=offset)


Pagination = Annotated[PaginationParams, Depends(get_pagination)]


def get_project(project_id: str, session: DbSession, principal: CurrentUser) -> Project:
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.", details={"project_id": project_id})
    assert_project_access(session, principal, project.id)
    return project


CurrentProject = Annotated[Project, Depends(get_project)]


def scoped_project_id(
    session: DbSession,
    principal: CurrentUser,
    project_id: Annotated[str, Query()],
) -> str:
    """A `project_id` query parameter the caller is actually a member of.

    Dozens of endpoints read `?project_id=`, trusting it. Any of them would
    serve another tenant's requirements, test cases, scripts or analytics to
    anyone holding the matching read permission. Declaring the parameter through
    this dependency means the check happens by construction: an endpoint that
    forgets it does not silently leak, it fails to declare the parameter at all.
    """
    assert_project_access(session, principal, project_id)
    return project_id


ScopedProjectId = Annotated[str, Depends(scoped_project_id)]


def optional_scoped_project_id(
    session: DbSession,
    principal: CurrentUser,
    project_id: Annotated[str | None, Query()] = None,
) -> str | None:
    """As `scoped_project_id`, where omitting the parameter means "all of mine".

    The endpoint must then still narrow its own query with `scope_to_accessible`;
    this only stops a caller naming somebody else's project explicitly.
    """
    if project_id is not None:
        assert_project_access(session, principal, project_id)
    return project_id


OptionalScopedProjectId = Annotated[str | None, Depends(optional_scoped_project_id)]
