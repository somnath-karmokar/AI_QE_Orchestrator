"""Knowledge Fabric endpoints: sources, documents, search and sync."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select

from app.api.deps import DbSession, Pagination, ScopedProjectId, require_permission
from app.core.errors import NotFoundError
from app.core.security import Principal
from app.core.tenancy import get_owned
from app.core.worker import job_queue
from app.knowledge.service import KnowledgeService
from app.models.knowledge import KnowledgeDocument, KnowledgeSource
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import (
    KnowledgeDocumentOut,
    KnowledgeSearchHit,
    KnowledgeSearchRequest,
    KnowledgeSourceOut,
)

router = APIRouter(prefix="/knowledge", tags=["Knowledge Fabric"])


@router.get("", summary="Knowledge Fabric overview")
def overview(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
    project_id: ScopedProjectId,
) -> dict:
    return KnowledgeService(session).overview(project_id)


@router.get("/sources", response_model=list[KnowledgeSourceOut], summary="List knowledge sources")
def list_sources(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
    project_id: ScopedProjectId,
) -> list[KnowledgeSourceOut]:
    rows = list(
        session.execute(
            select(KnowledgeSource)
            .where(KnowledgeSource.project_id == project_id, KnowledgeSource.is_deleted.is_(False))
            .order_by(KnowledgeSource.name)
        )
        .scalars()
        .all()
    )
    return [KnowledgeSourceOut.model_validate(row) for row in rows]


@router.get("/documents", response_model=Page[KnowledgeDocumentOut], summary="List indexed documents")
def list_documents(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
    project_id: ScopedProjectId,
    source_type: Annotated[str | None, Query()] = None,
    module: Annotated[str | None, Query()] = None,
    search: Annotated[str | None, Query()] = None,
) -> Page[KnowledgeDocumentOut]:
    statement = select(KnowledgeDocument).where(
        KnowledgeDocument.project_id == project_id, KnowledgeDocument.is_deleted.is_(False)
    )
    if source_type:
        statement = statement.where(KnowledgeDocument.source_type == source_type)
    if module:
        statement = statement.where(KnowledgeDocument.module == module)
    if search:
        statement = statement.where(KnowledgeDocument.title.ilike(f"%{search}%"))

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(KnowledgeDocument.title).limit(pagination.limit).offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[KnowledgeDocumentOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/documents/{document_id}", summary="Get a document with its content")
def get_document(
    document_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
) -> dict:
    row = get_owned(session, principal, KnowledgeDocument, document_id, label="Document")
    return {
        **KnowledgeDocumentOut.model_validate(row).model_dump(),
        "content": row.content,
        "chunks": [
            {"index": chunk.chunk_index, "tokens": chunk.token_estimate, "content": chunk.content}
            for chunk in sorted(row.chunks, key=lambda item: item.chunk_index)
        ],
    }


@router.post("/search", response_model=list[KnowledgeSearchHit], summary="Semantic search")
def search(
    payload: KnowledgeSearchRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("knowledge:read"))],
    project_id: ScopedProjectId,
) -> list[KnowledgeSearchHit]:
    results = KnowledgeService(session).retrieve(
        payload.query,
        project_id=project_id,
        collection=payload.collection,
        limit=payload.limit,
        module=payload.module,
    )
    return [
        KnowledgeSearchHit(id=item.id, content=item.content, score=item.score, metadata=item.metadata)
        for item in results
    ]


@router.post("/sync", response_model=MessageResponse, status_code=202, summary="Re-index knowledge sources")
def sync(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("knowledge:write"))],
    project_id: ScopedProjectId,
) -> MessageResponse:
    """Re-index in the background; embedding the corpus is not a request-time job."""
    from app.seed.runner import index_project_knowledge  # noqa: PLC0415
    from app.models.project import Project  # noqa: PLC0415

    project = session.get(Project, project_id)
    if project is None:
        raise NotFoundError(f"Project '{project_id}' was not found.")

    job = job_queue.submit(
        f"knowledge-sync:{project_id}",
        index_project_knowledge,
        project.key,
        job_metadata={"project_id": project_id},
    )
    return MessageResponse(
        message="Knowledge synchronisation started.",
        details={"job_id": job.job_id, "project_key": project.key},
    )
