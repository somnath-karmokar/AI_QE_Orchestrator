"""Inbound triggers: start a flow from CI, a pipeline or another tool.

These routes use the flow's own API token (`X-Flow-Token`) instead of a user
session, so a pipeline can start exactly one flow and nothing else. The token
is compared against a keyed hash; an unknown flow and a wrong token return the
same 401, so the endpoint does not reveal which flow ids exist.
"""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Header

from app.api.deps import DbSession
from app.core.errors import AuthenticationError
from app.core.security import verify_api_token
from app.models.flow import AgentFlow
from app.schemas.entities import FlowHookRequest
from app.services.flow_triggers import trigger_flow

router = APIRouter(prefix="/hooks", tags=["Triggers"])


@router.post("/flows/{flow_id}", status_code=202, summary="Start a flow with its API token")
def trigger_flow_by_token(
    flow_id: str,
    session: DbSession,
    x_flow_token: Annotated[str | None, Header()] = None,
    payload: FlowHookRequest | None = None,
) -> dict:
    flow = session.get(AgentFlow, flow_id)
    if flow is None or flow.is_deleted or not verify_api_token(x_flow_token or "", flow.webhook_token_hash):
        raise AuthenticationError("A valid X-Flow-Token header is required for this flow.")

    payload = payload or FlowHookRequest()
    run = trigger_flow(
        session,
        flow,
        trigger="api",
        triggered_by=f"api-token …{flow.webhook_token_hint}",
        inputs=payload.inputs,
        title=payload.title,
    )
    return {
        "run_id": run.id,
        "run_number": run.run_number,
        "status": run.status,
        "flow_id": flow.id,
        "flow_name": flow.name,
        "status_url": f"/api/v1/runs/{run.id}",
    }
