"""This platform, exposed as an MCP server.

The REST surface at `/integration` is right for a pipeline: start something,
poll it, read the result. It is the wrong shape for an *agent* on another
platform, which wants to discover callable tools and invoke them without a
human having read documentation first.

Model Context Protocol is how that is done, and the platform already speaks the
client half of it (`app/mcp/`). This is the server half: the same agents and
flows, the same scopes, the same governance, presented as MCP tools.

Implemented directly over JSON-RPC 2.0 rather than through an SDK. MCP is a
small protocol, the transport here is the HTTP stack the platform already
authenticates and rate-limits, and a dependency that only wraps
`{"jsonrpc": "2.0", ...}` would buy nothing.

**The guarantees do not change.** A tool call goes through the same scopes, the
same approval gates and the same audit trail as the REST route. An agent that
calls `run_flow` and gets `waiting_for_approval` is being told a person must
decide -- exactly as a pipeline would be.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request

from app.api.deps import DbSession
from app.api.integration_auth import CurrentClient
from app.core.errors import AppError
from app.core.logging import get_logger
from app.models.integration import IntegrationClient
from app.services.mcp_tools import (
    PROTOCOL_VERSION,
    SERVER_INFO,
    build_tool_list,
    call_tool,
)

logger = get_logger(__name__)

router = APIRouter(prefix="/mcp", tags=["Integration"])

# JSON-RPC 2.0 error codes. The protocol defines the first four; -32000 is the
# reserved range for application errors.
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603
APPLICATION_ERROR = -32000


def _result(request_id: Any, payload: dict[str, Any]) -> dict[str, Any]:  # noqa: ANN401
    return {"jsonrpc": "2.0", "id": request_id, "result": payload}


def _error(request_id: Any, code: int, message: str, data: Any = None) -> dict[str, Any]:  # noqa: ANN401
    error: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {"jsonrpc": "2.0", "id": request_id, "error": error}


@router.post(
    "",
    summary="MCP endpoint (JSON-RPC 2.0)",
    description=(
        "Exposes this platform's agents and flows as MCP tools. Authenticate "
        "with the same `X-API-Key` used by the integration API; a tool is only "
        "listed and only callable if the key was granted it."
    ),
)
async def mcp_endpoint(
    request: Request,
    session: DbSession,
    client: CurrentClient,
) -> dict[str, Any]:
    """One endpoint, dispatching the MCP methods this server supports."""
    try:
        message = await request.json()
    except Exception:  # noqa: BLE001 - a malformed body is a protocol error
        return _error(None, PARSE_ERROR, "Request body is not valid JSON.")

    if not isinstance(message, dict) or message.get("jsonrpc") != "2.0":
        return _error(
            message.get("id") if isinstance(message, dict) else None,
            INVALID_REQUEST,
            "Expected a JSON-RPC 2.0 request object.",
        )

    method = message.get("method")
    request_id = message.get("id")
    params = message.get("params") or {}

    logger.info("mcp_request", method=method, client=client.name)

    if method == "initialize":
        return _result(
            request_id,
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": SERVER_INFO,
                # Read before the first tool call, so an agent knows what it is
                # dealing with rather than discovering it from a refusal.
                "instructions": _instructions(client),
            },
        )

    if method in {"notifications/initialized", "initialized"}:
        # A notification carries no id and expects no result.
        return _result(request_id, {})

    if method == "ping":
        return _result(request_id, {})

    if method == "tools/list":
        return _result(request_id, {"tools": build_tool_list(session, client)})

    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not name:
            return _error(request_id, INVALID_PARAMS, "A tool name is required.")
        return _call(session, client, request_id, name, arguments)

    return _error(request_id, METHOD_NOT_FOUND, f"Method '{method}' is not supported.")


def _call(
    session,  # noqa: ANN001
    client: IntegrationClient,
    request_id: Any,  # noqa: ANN401
    name: str,
    arguments: dict[str, Any],
) -> dict[str, Any]:
    """Invoke a tool, reporting failure the way MCP expects.

    MCP distinguishes a *protocol* failure from a *tool* failure: a tool that
    refuses is a successful call whose result carries `isError`. Collapsing the
    two would make "policy declined this" indistinguishable from "the server is
    broken", and an agent would retry the wrong one.
    """
    try:
        payload = call_tool(session, client, name, arguments)
    except AppError as error:
        return _result(
            request_id,
            {
                "content": [{"type": "text", "text": error.message}],
                "isError": True,
                "structuredContent": {"error": error.code, "details": error.details},
            },
        )
    except Exception as error:  # noqa: BLE001
        logger.error("mcp_tool_failed", tool=name, error=str(error))
        return _error(request_id, INTERNAL_ERROR, "The tool could not be invoked.")

    return _result(request_id, payload)


def _instructions(client: IntegrationClient) -> str:
    """What an agent should know before calling anything here."""
    return (
        "These tools run quality-engineering agents and flows in the AI QE Orchestrator.\n\n"
        "Work is asynchronous. `run_flow` and `run_agent` return a run id and a disposition; "
        "poll `get_run` until `is_terminal` is true.\n\n"
        "`waiting_for_approval` is a normal outcome, not a failure: a named person must approve "
        "the action before it continues. Do not retry it -- retrying will not clear it, and the "
        "run has not failed.\n\n"
        "Self-healing in this platform never changes what a test asserts about the application, "
        "and never records a repair as successful without a re-run that proved it.\n\n"
        f"This key ({client.name}) may invoke only the tools listed by tools/list. "
        "Anything else returns the same not-found answer as a tool that does not exist."
    )
