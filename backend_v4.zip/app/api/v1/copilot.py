"""Conversational copilot endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from app.api.deps import DbSession, Pagination, ScopedProjectId, require_permission
from app.copilot.intent import INTENTS
from app.copilot.service import CopilotService, index_agent_catalog
from app.core.errors import NotFoundError
from app.core.security import Principal
from app.core.tenancy import assert_project_access, reaches_every_project
from app.governance.policy_engine import AuditService
from app.models.conversation import Conversation, ConversationMessage
from app.models.flow import AgentFlow
from app.models.project import Project
from app.schemas.common import MessageResponse, ORMModel, Page

router = APIRouter(prefix="/copilot", tags=["Copilot"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class CopilotMessageRequest(BaseModel):
    project_id: str
    message: str = Field(min_length=1, max_length=4000)
    conversation_id: str | None = None
    environment_id: str | None = None
    is_voice: bool = False
    # When false the copilot explains what it would do and waits for confirmation.
    auto_execute: bool = True


class CopilotMessageOut(ORMModel):
    id: str
    sequence: int
    role: str
    content: str
    plan_kind: str | None = None
    intent: str | None = None
    intent_confidence: float | None = None
    considered_agents: list[Any] = Field(default_factory=list)
    selected_agents: list[Any] = Field(default_factory=list)
    extracted_entities: dict[str, Any] = Field(default_factory=dict)
    reasoning_summary: str | None = None
    run_id: str | None = None
    evidence: list[Any] = Field(default_factory=list)
    artifacts: list[Any] = Field(default_factory=list)
    suggestions: list[Any] = Field(default_factory=list)
    navigation: dict[str, Any] = Field(default_factory=dict)
    provider: str | None = None
    model: str | None = None
    total_tokens: int = 0
    cost_usd: float = 0.0
    duration_ms: int = 0
    policy_decision: dict[str, Any] = Field(default_factory=dict)
    is_voice: bool = False
    feedback: str | None = None
    feedback_note: str | None = None
    created_at: Any = None


class CopilotFeedbackRequest(BaseModel):
    rating: Literal["up", "down"]
    note: str | None = Field(default=None, max_length=1000)


class CopilotTurnResponse(BaseModel):
    conversation_id: str
    title: str
    message: CopilotMessageOut


class ConversationOut(ORMModel):
    id: str
    title: str
    project_id: str
    message_count: int
    total_tokens: int
    total_cost_usd: float
    last_message_at: Any = None
    created_at: Any = None


class ConversationDetail(ConversationOut):
    context: dict[str, Any] = Field(default_factory=dict)
    messages: list[CopilotMessageOut] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


def _may_read_conversation(conversation: Conversation, principal: Principal) -> bool:
    """A copilot conversation is private to the person who had it.

    Stricter than project membership on purpose: a transcript carries what
    someone asked and what they were told, which their colleagues in the same
    project have no business reading. An unattributed conversation belongs to
    nobody and is left to the administrators.
    """
    if reaches_every_project(principal):
        return True
    return bool(conversation.user_id) and conversation.user_id == principal.user_id


@router.post("/message", response_model=CopilotTurnResponse, summary="Send a message to the copilot")
def send_message(
    payload: CopilotMessageRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> CopilotTurnResponse:
    """Resolve intent, select the right agent(s), execute and reply.

    Runs synchronously so the conversation reads naturally; the underlying
    execution is the same governed path the Flow Builder uses.
    """
    project = session.get(Project, payload.project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{payload.project_id}' was not found.")
    # The copilot answers from the project's own knowledge, so asking it a
    # question inside somebody else's project would read their documents out.
    assert_project_access(session, principal, project.id)

    service = CopilotService(session)
    conversation = service.get_or_create_conversation(
        conversation_id=payload.conversation_id,
        project_id=project.id,
        user_id=principal.user_id,
        environment_id=payload.environment_id,
    )
    reply = service.handle_message(
        conversation=conversation,
        message=payload.message,
        project=project,
        actor=principal.email,
        is_voice=payload.is_voice,
        auto_execute=payload.auto_execute,
    )
    session.refresh(conversation)
    return CopilotTurnResponse(
        conversation_id=conversation.id,
        title=conversation.title,
        message=CopilotMessageOut.model_validate(reply),
    )


@router.post(
    "/messages/{message_id}/feedback",
    response_model=CopilotMessageOut,
    summary="Rate a copilot answer",
)
def rate_message(
    message_id: str,
    payload: CopilotFeedbackRequest,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> CopilotMessageOut:
    """Record whether an answer was useful.

    Ratings are what turn a transcript into an evaluation set: a thumbs down with
    a note names a question the copilot should have answered better.
    """
    message = session.get(ConversationMessage, message_id)
    if message is None or message.role != "assistant":
        raise NotFoundError(f"Copilot answer '{message_id}' was not found.")
    # The response echoes the answer's text back, so rating somebody else's
    # answer would also read it. A conversation is private to whoever had it.
    owner = session.get(Conversation, message.conversation_id)
    if owner is None or not _may_read_conversation(owner, principal):
        raise NotFoundError(f"Copilot answer '{message_id}' was not found.")

    message.feedback = payload.rating
    message.feedback_note = (payload.note or "").strip() or None
    message.feedback_by = principal.email
    message.feedback_at = datetime.now(UTC)
    session.flush()

    conversation = session.get(Conversation, message.conversation_id)
    AuditService(session).record(
        action="copilot.feedback",
        entity_type="conversation_message",
        entity_id=message.id,
        entity_label=(message.content or "")[:120],
        actor=principal.email,
        actor_type="user",
        project_id=conversation.project_id if conversation else None,
        reason=f"Answer rated {payload.rating}." + (f" {message.feedback_note}" if message.feedback_note else ""),
        outcome="success" if payload.rating == "up" else "warning",
        severity="info" if payload.rating == "up" else "warning",
        input_summary={"intent": message.intent, "plan": message.plan_kind},
    )
    return CopilotMessageOut.model_validate(message)


@router.get("/conversations", response_model=Page[ConversationOut], summary="List conversations")
def list_conversations(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: ScopedProjectId,
) -> Page[ConversationOut]:
    statement = select(Conversation).where(
        Conversation.project_id == project_id,
        Conversation.is_deleted.is_(False),
        # A conversation is private to the person who had it.
        Conversation.user_id == principal.user_id,
    )
    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(Conversation.last_message_at.desc().nullslast())
            .limit(pagination.limit)
            .offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[ConversationOut.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.get("/conversations/{conversation_id}", response_model=ConversationDetail, summary="Get a conversation")
def get_conversation(
    conversation_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> ConversationDetail:
    conversation = session.get(Conversation, conversation_id)
    if conversation is None or conversation.is_deleted:
        raise NotFoundError(f"Conversation '{conversation_id}' was not found.")
    if not _may_read_conversation(conversation, principal):
        raise NotFoundError(f"Conversation '{conversation_id}' was not found.")
    return ConversationDetail.model_validate(conversation)


@router.delete("/conversations/{conversation_id}", response_model=MessageResponse, summary="Delete a conversation")
def delete_conversation(
    conversation_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
) -> MessageResponse:
    conversation = session.get(Conversation, conversation_id)
    if conversation is None:
        raise NotFoundError(f"Conversation '{conversation_id}' was not found.")
    if not _may_read_conversation(conversation, principal):
        raise NotFoundError(f"Conversation '{conversation_id}' was not found.")
    conversation.soft_delete(principal.email)
    session.flush()
    return MessageResponse(message="Conversation deleted.")


@router.get("/capabilities", summary="What the copilot can do")
def capabilities(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:read"))],
    project_id: ScopedProjectId,
) -> dict[str, Any]:
    """Drives the empty-state suggestions, so the UI never invents examples."""
    project = session.get(Project, project_id)
    if project is None:
        raise NotFoundError(f"Project '{project_id}' was not found.")

    module = (project.modules or ["Payments"])[0]
    # Name a real flow in the examples, so a first-time user asks something answerable.
    flow = session.execute(
        select(AgentFlow)
        .where(AgentFlow.project_id == project.id, AgentFlow.is_deleted.is_(False))
        .order_by(AgentFlow.run_count.desc())
        .limit(1)
    ).scalar_one_or_none()
    flow_name = flow.name if flow else "your flow"

    starters = [
        {"label": "Assess a story", "prompt": "Is PAY-201 ready for testing?"},
        {"label": "Generate tests", "prompt": "Generate test scenarios for PAY-201"},
        {"label": "Ask about a flow", "prompt": f"What does {flow_name} do?"},
        {"label": "Check a flow's health", "prompt": f"How is {flow_name} doing?"},
        {"label": "Review a run", "prompt": f"Why did the last run of {flow_name} end that way?"},
        {"label": "Compare flows", "prompt": "Which flows need attention?"},
        {"label": "Find the risk", "prompt": "Where is the risk in this release?"},
        {"label": "Optimise regression", "prompt": f"We changed {module}, what needs retesting?"},
        {"label": "Ask the knowledge base", "prompt": "What is the daily payment limit?"},
        {"label": "Check coverage", "prompt": "Which requirements are untested?"},
    ]
    return {
        "intents": [
            {"key": key, "label": spec["label"], "example": spec["examples"][0]}
            for key, spec in INTENTS.items()
        ],
        "starters": starters,
        "modules": project.modules or [],
        "flows": [
            {"id": item.id, "name": item.name}
            for item in session.execute(
                select(AgentFlow)
                .where(AgentFlow.project_id == project.id, AgentFlow.is_deleted.is_(False))
                .order_by(AgentFlow.name)
            ).scalars()
        ],
    }


@router.post("/reindex-agents", response_model=MessageResponse, summary="Re-index the agent catalogue")
def reindex_agents(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("agent:write"))],
    project_id: ScopedProjectId,
) -> MessageResponse:
    """Refresh the embeddings the copilot uses to select agents.

    Run this after publishing a custom agent so the copilot can route to it.
    """
    project = session.get(Project, project_id)
    if project is None:
        raise NotFoundError(f"Project '{project_id}' was not found.")
    count = index_agent_catalog(session, project)
    return MessageResponse(
        message=f"Indexed {count} agent capability description(s).",
        details={"indexed": count},
    )
