"""Test engineering endpoints: requirements, scenarios, cases, scripts, data, executions."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, or_, select

from app.api.deps import DbSession, OptionalScopedProjectId, Pagination, ScopedProjectId, require_permission
from app.core.security import Principal
from app.core.storage import tenant_relative_path
from app.core.tenancy import assert_project_access, get_owned, scope_to_accessible
from app.execution.failures import cluster_failures, triage_summary
from app.execution.service import ExecutionService
from app.healing.impact import assess, select_for_change
from app.healing.service import HealingService
from app.services.healing_insights import dashboard as healing_dashboard
from app.models.testing import (
    BusinessFlow,
    Execution,
    ExecutionArtifact,
    HealingRecord,
    RegressionAnalysis,
    Requirement,
    TestCase,
    TestDataSet,
    TestScenario,
    TestScript,
    TraceabilityLink,
)
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import (
    ChangeImpactRequest,
    ExecutionCreate,
    ExecutionDetail,
    ExecutionSummary,
    HealingRecordOut,
    RegressionAnalysisOut,
    RequirementOut,
    ScenarioOut,
    TestCaseOut,
    TestDataSetOut,
    TestScriptOut,
)

router = APIRouter(tags=["Test Engineering"])


def _paginate(session, statement, pagination, schema):  # noqa: ANN001, ANN202
    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(statement.limit(pagination.limit).offset(pagination.offset)).scalars().all()
    )
    return Page(
        items=[schema.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


# ---------------------------------------------------------------------------
# Requirements
# ---------------------------------------------------------------------------


@router.get("/requirements", response_model=Page[RequirementOut], summary="List requirements")
def list_requirements(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    module: Annotated[str | None, Query()] = None,
    status: Annotated[str | None, Query()] = None,
    priority: Annotated[str | None, Query()] = None,
    search: Annotated[str | None, Query()] = None,
) -> Page[RequirementOut]:
    statement = select(Requirement).where(
        Requirement.project_id == project_id, Requirement.is_deleted.is_(False)
    )
    if module:
        statement = statement.where(Requirement.module == module)
    if status:
        statement = statement.where(Requirement.status == status)
    if priority:
        statement = statement.where(Requirement.priority == priority)
    if search:
        pattern = f"%{search}%"
        statement = statement.where(
            or_(Requirement.title.ilike(pattern), Requirement.external_key.ilike(pattern))
        )
    return _paginate(session, statement.order_by(Requirement.external_key), pagination, RequirementOut)


@router.get("/requirements/{requirement_id}", response_model=RequirementOut, summary="Get a requirement")
def get_requirement(
    requirement_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
) -> RequirementOut:
    row = get_owned(session, principal, Requirement, requirement_id, label="Requirement")
    return RequirementOut.model_validate(row)


# ---------------------------------------------------------------------------
# Scenarios and cases
# ---------------------------------------------------------------------------


@router.get("/scenarios", response_model=Page[ScenarioOut], summary="List test scenarios")
def list_scenarios(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    requirement_id: Annotated[str | None, Query()] = None,
    module: Annotated[str | None, Query()] = None,
    scenario_type: Annotated[str | None, Query()] = None,
) -> Page[ScenarioOut]:
    statement = select(TestScenario).where(
        TestScenario.project_id == project_id, TestScenario.is_deleted.is_(False)
    )
    if requirement_id:
        statement = statement.where(TestScenario.requirement_id == requirement_id)
    if module:
        statement = statement.where(TestScenario.module == module)
    if scenario_type:
        statement = statement.where(TestScenario.scenario_type == scenario_type)
    return _paginate(session, statement.order_by(TestScenario.key), pagination, ScenarioOut)


@router.get("/test-cases", response_model=Page[TestCaseOut], summary="List test cases")
def list_test_cases(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    module: Annotated[str | None, Query()] = None,
    priority: Annotated[str | None, Query()] = None,
    is_automated: Annotated[bool | None, Query()] = None,
    scenario_id: Annotated[str | None, Query()] = None,
    search: Annotated[str | None, Query()] = None,
) -> Page[TestCaseOut]:
    statement = select(TestCase).where(TestCase.project_id == project_id, TestCase.is_deleted.is_(False))
    if module:
        statement = statement.where(TestCase.module == module)
    if priority:
        statement = statement.where(TestCase.priority == priority)
    if is_automated is not None:
        statement = statement.where(TestCase.is_automated.is_(is_automated))
    if scenario_id:
        statement = statement.where(TestCase.scenario_id == scenario_id)
    if search:
        pattern = f"%{search}%"
        statement = statement.where(or_(TestCase.title.ilike(pattern), TestCase.key.ilike(pattern)))
    return _paginate(session, statement.order_by(TestCase.key), pagination, TestCaseOut)


@router.get("/test-cases/{test_case_id}", response_model=TestCaseOut, summary="Get a test case")
def get_test_case(
    test_case_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
) -> TestCaseOut:
    row = get_owned(session, principal, TestCase, test_case_id, label="Test case")
    return TestCaseOut.model_validate(row)


@router.get("/test-scripts", response_model=Page[TestScriptOut], summary="List automation scripts")
def list_scripts(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    framework: Annotated[str | None, Query()] = None,
    test_case_id: Annotated[str | None, Query()] = None,
) -> Page[TestScriptOut]:
    statement = select(TestScript).where(
        TestScript.project_id == project_id, TestScript.is_deleted.is_(False)
    )
    if framework:
        statement = statement.where(TestScript.framework == framework)
    if test_case_id:
        statement = statement.where(TestScript.test_case_id == test_case_id)
    return _paginate(session, statement.order_by(TestScript.name), pagination, TestScriptOut)


@router.get("/test-scripts/{script_id}", response_model=TestScriptOut, summary="Get a script with its code")
def get_script(
    script_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
) -> TestScriptOut:
    row = get_owned(session, principal, TestScript, script_id, label="Test script")
    return TestScriptOut.model_validate(row)


@router.get("/test-data", response_model=Page[TestDataSetOut], summary="List test data sets")
def list_test_data(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    module: Annotated[str | None, Query()] = None,
) -> Page[TestDataSetOut]:
    statement = select(TestDataSet).where(
        TestDataSet.project_id == project_id, TestDataSet.is_deleted.is_(False)
    )
    if module:
        statement = statement.where(TestDataSet.module == module)
    return _paginate(session, statement.order_by(TestDataSet.name), pagination, TestDataSetOut)


# ---------------------------------------------------------------------------
# Executions
# ---------------------------------------------------------------------------

executions_router = APIRouter(prefix="/executions", tags=["Execution"])


@executions_router.get("", response_model=Page[ExecutionSummary], summary="List executions")
def list_executions(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("execution:read"))],
    project_id: OptionalScopedProjectId = None,
    status: Annotated[str | None, Query()] = None,
    suite_type: Annotated[str | None, Query()] = None,
) -> Page[ExecutionSummary]:
    statement = scope_to_accessible(select(Execution), Execution.project_id, session, principal)
    if project_id:
        statement = statement.where(Execution.project_id == project_id)
    if status:
        statement = statement.where(Execution.status == status)
    if suite_type:
        statement = statement.where(Execution.suite_type == suite_type)
    return _paginate(
        session, statement.order_by(Execution.created_at.desc()), pagination, ExecutionSummary
    )


@executions_router.post("", response_model=ExecutionDetail, status_code=202, summary="Start an execution")
def start_execution(
    payload: ExecutionCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:write"))],
) -> ExecutionDetail:
    # The project arrives in the body here, so the query-parameter dependency
    # does not cover it.
    assert_project_access(session, principal, payload.project_id)
    service = ExecutionService(session)
    execution = service.create(
        project_id=payload.project_id,
        name=payload.name,
        suite_type=payload.suite_type,
        environment_id=payload.environment_id,
        browser=payload.browser,
        headless=payload.headless,
        parallelism=payload.parallelism,
        test_case_ids=payload.test_case_ids or None,
        module=payload.module,
        triggered_by=principal.email,
    )
    service.dispatch(execution)
    session.refresh(execution)
    return ExecutionDetail.model_validate(execution)


@executions_router.get("/{execution_id}", response_model=ExecutionDetail, summary="Get execution detail")
def get_execution(
    execution_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:read"))],
) -> ExecutionDetail:
    row = get_owned(session, principal, Execution, execution_id, label="Execution")
    return ExecutionDetail.model_validate(row)


@executions_router.post("/{execution_id}/cancel", response_model=ExecutionDetail, summary="Stop an execution")
def cancel_execution(
    execution_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:write"))],
) -> ExecutionDetail:
    get_owned(session, principal, Execution, execution_id, label="Execution")
    return ExecutionDetail.model_validate(ExecutionService(session).cancel(execution_id))


@executions_router.post(
    "/{execution_id}/retry-failed",
    response_model=ExecutionDetail,
    status_code=202,
    summary="Retry only the failed tests",
)
def retry_failed(
    execution_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:write"))],
) -> ExecutionDetail:
    get_owned(session, principal, Execution, execution_id, label="Execution")
    service = ExecutionService(session)
    execution = service.retry_failed(execution_id, triggered_by=principal.email)
    service.dispatch(execution)
    session.refresh(execution)
    return ExecutionDetail.model_validate(execution)


@executions_router.get("/{execution_id}/triage", summary="Group a run's failures by root cause")
def execution_triage(
    execution_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:read"))],
) -> dict:
    """What a run's failures actually amount to.

    Fifty tests broken by one redesign are one problem, not fifty. Grouping by
    signature is what turns a wall of failures into a short list of causes --
    and what stops triage costing one model call per failing test.
    """
    execution = get_owned(session, principal, Execution, execution_id, label="Execution")
    clusters = cluster_failures(list(execution.tests))
    return {
        "execution_id": execution.id,
        "execution_name": execution.name,
        **triage_summary(clusters),
        "clusters": [cluster.to_dict() for cluster in clusters],
    }


@executions_router.get("/{execution_id}/artifacts", summary="List execution artifacts")
def execution_artifacts(
    execution_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:read"))],
) -> list[dict]:
    execution = get_owned(session, principal, Execution, execution_id, label="Execution")
    rows = list(
        session.execute(
            select(ExecutionArtifact).where(ExecutionArtifact.execution_id == execution_id)
        )
        .scalars()
        .all()
    )
    return [
        {
            "id": row.id,
            "artifact_type": row.artifact_type,
            "name": row.name,
            # Relative to this tenant's own storage root. The absolute path
            # describes the server's filesystem, which is the deployment's
            # business and not the caller's.
            "storage_path": tenant_relative_path(execution.project_id, row.storage_path),
            "content_type": row.content_type,
            "size_bytes": row.size_bytes,
            "execution_test_id": row.execution_test_id,
            "metadata": row.artifact_metadata,
        }
        for row in rows
    ]


# ---------------------------------------------------------------------------
# Healing, regression, traceability
# ---------------------------------------------------------------------------


@router.get("/healing", response_model=Page[HealingRecordOut], summary="Self-healing records")
def list_healing(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("execution:read"))],
    project_id: ScopedProjectId,
    status: Annotated[str | None, Query()] = None,
) -> Page[HealingRecordOut]:
    statement = select(HealingRecord).where(HealingRecord.project_id == project_id)
    if status:
        statement = statement.where(HealingRecord.status == status)
    return _paginate(
        session, statement.order_by(HealingRecord.created_at.desc()), pagination, HealingRecordOut
    )


@router.post("/healing/{record_id}/decide", response_model=HealingRecordOut, summary="Approve or reject a healing proposal")
def decide_healing(
    record_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("approval:decide"))],
    decision: Annotated[str, Query(pattern="^(approve|reject)$")],
) -> HealingRecordOut:
    """Approving does not apply the change; it starts proving it.

    The heal is applied as a temporary patch, the affected test is re-run, and the
    script is only versioned if that re-run passes (spec §11). A change the
    healing policy matrix forbids -- an assertion or a business rule -- cannot be
    approved here at all.
    """
    get_owned(session, principal, HealingRecord, record_id, label="Healing record")
    record = HealingService(session).decide(record_id, decision=decision, actor=principal.email)
    return HealingRecordOut.model_validate(record)


@router.get("/healing/analytics", summary="Healing analytics, counted from records")
def healing_analytics(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("execution:read"))],
    project_id: ScopedProjectId,
    window_days: Annotated[int, Query(ge=1, le=365)] = 30,
) -> dict:
    """Every number is counted from persisted records, never modelled.

    The success rate counts only repairs whose re-run passed, so a repair
    applied before validation existed is reported as unproven rather than as a
    success.
    """
    return healing_dashboard(session, project_id, days=window_days)


@router.get("/business-flows", summary="Customer journeys and what each step touches")
def list_business_flows(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
) -> list[dict]:
    """Modules say where a test lives; a journey says what a change touches."""
    flows = list(
        session.execute(
            select(BusinessFlow).where(
                BusinessFlow.project_id == project_id, BusinessFlow.is_deleted.is_(False)
            )
        )
        .scalars()
        .all()
    )
    return [
        {
            "id": flow.id,
            "key": flow.key,
            "name": flow.name,
            "description": flow.description,
            "criticality": flow.criticality,
            "owner": flow.owner,
            "modules": flow.modules,
            "steps": [
                {
                    "id": step.id,
                    "key": step.key,
                    "name": step.name,
                    "position": step.position,
                    "module": step.module,
                    "ui_components": step.ui_components,
                    "api_endpoints": step.api_endpoints,
                    "assertions": step.assertions,
                }
                for step in flow.steps
            ],
        }
        for flow in flows
    ]


@router.get("/impact", summary="What a change reaches, beyond the thing that changed")
def change_impact(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    test_case_id: Annotated[str | None, Query()] = None,
    component: Annotated[str | None, Query()] = None,
) -> dict:
    """Which journey a test or component belongs to, and what else it affects.

    An empty result means no business flow covers it — the platform does not
    know what else this touches, and says so rather than guessing.
    """
    return assess(
        session, project_id=project_id, test_case_id=test_case_id, component=component
    ).to_dict()


@router.post("/impact/select", summary="Choose a regression suite from what changed")
def select_by_impact(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    payload: ChangeImpactRequest | None = None,
) -> dict:
    """Selection by journey rather than by module.

    Every selected test says why it was chosen, so a skipped test is a decision
    someone can argue with rather than a silent omission.
    """
    payload = payload or ChangeImpactRequest()
    return select_for_change(
        session,
        project_id=project_id,
        changed_components=payload.changed_components,
        changed_modules=payload.changed_modules,
        changed_endpoints=payload.changed_endpoints,
    )


@router.get("/regression", response_model=Page[RegressionAnalysisOut], summary="Regression optimisation analyses")
def list_regression(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
) -> Page[RegressionAnalysisOut]:
    statement = select(RegressionAnalysis).where(RegressionAnalysis.project_id == project_id)
    return _paginate(
        session,
        statement.order_by(RegressionAnalysis.created_at.desc()),
        pagination,
        RegressionAnalysisOut,
    )


@router.get("/traceability", summary="Requirement-to-defect traceability matrix")
def traceability_matrix(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
    module: Annotated[str | None, Query()] = None,
) -> dict:
    """Walk requirement -> scenario -> case -> automation -> execution -> defect."""
    from app.services.analytics_service import AnalyticsService  # noqa: PLC0415

    return AnalyticsService(session).traceability(project_id, module=module)


@router.get("/coverage", summary="Coverage metrics")
def coverage(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
) -> dict:
    from app.services.analytics_service import AnalyticsService  # noqa: PLC0415

    return AnalyticsService(session).coverage(project_id)


@router.get("/traceability/links", summary="Raw traceability links")
def traceability_links(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("test:read"))],
    project_id: ScopedProjectId,
) -> list[dict]:
    rows = list(
        session.execute(select(TraceabilityLink).where(TraceabilityLink.project_id == project_id))
        .scalars()
        .all()
    )
    return [
        {
            "id": row.id,
            "source_type": row.source_type,
            "source_id": row.source_id,
            "target_type": row.target_type,
            "target_id": row.target_id,
            "link_type": row.link_type,
            "confidence": row.confidence,
        }
        for row in rows
    ]
