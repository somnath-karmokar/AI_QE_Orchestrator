"""Project, environment and integration endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select

from app.api.deps import CurrentUser, DbSession, Pagination, require_permission
from app.core.tenancy import assert_project_access, scope_to_accessible
from app.core.errors import ConflictError, NotFoundError
from app.core.security import Principal
from app.models.identity import ProjectMember
from app.models.project import Environment, Project
from app.schemas.common import MessageResponse, Page
from app.schemas.entities import (
    EnvironmentCreate,
    EnvironmentOut,
    ProjectCreate,
    ProjectOut,
    ProjectSummary,
    ProjectUpdate,
)

router = APIRouter(prefix="/projects", tags=["Projects"])


@router.get("", response_model=Page[ProjectSummary], summary="List projects")
def list_projects(
    session: DbSession,
    pagination: Pagination,
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
    status: Annotated[str | None, Query()] = None,
    search: Annotated[str | None, Query()] = None,
) -> Page[ProjectSummary]:
    # Only the projects this caller is a member of. Before this, every
    # authenticated user could list every tenant's projects.
    statement = scope_to_accessible(
        select(Project).where(Project.is_deleted.is_(False)), Project.id, session, principal
    )
    if status:
        statement = statement.where(Project.status == status)
    if search:
        pattern = f"%{search}%"
        statement = statement.where(Project.name.ilike(pattern) | Project.key.ilike(pattern))

    total = int(
        session.execute(select(func.count()).select_from(statement.subquery())).scalar_one() or 0
    )
    rows = list(
        session.execute(
            statement.order_by(Project.created_at.desc())
            .limit(pagination.limit)
            .offset(pagination.offset)
        )
        .scalars()
        .all()
    )
    return Page(
        items=[ProjectSummary.model_validate(row) for row in rows],
        total=total,
        limit=pagination.limit,
        offset=pagination.offset,
    )


@router.post("", response_model=ProjectOut, status_code=201, summary="Create a project")
def create_project(
    payload: ProjectCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
) -> ProjectOut:
    existing = session.execute(
        select(Project).where(Project.key == payload.key.upper())
    ).scalar_one_or_none()
    if existing is not None:
        raise ConflictError(
            f"A project with key '{payload.key.upper()}' already exists.",
            details={"key": payload.key},
        )

    project = Project(
        **payload.model_dump(exclude={"key"}),
        key=payload.key.upper(),
        status="onboarding",
        onboarding_step=1,
        created_by=principal.email,
    )
    session.add(project)
    session.flush()

    # Whoever creates a project is its first member; membership is what makes it
    # visible, so without this the creator could not open their own project.
    session.add(
        ProjectMember(
            project_id=project.id,
            user_id=principal.user_id,
            access="owner",
            added_by=principal.email,
        )
    )
    session.flush()
    return ProjectOut.model_validate(project)


@router.get("/{project_id}", response_model=ProjectOut, summary="Get a project")
def get_project_detail(
    project_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
) -> ProjectOut:
    assert_project_access(session, principal, project_id)
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.")
    return ProjectOut.model_validate(project)


@router.patch("/{project_id}", response_model=ProjectOut, summary="Update a project")
def update_project(
    project_id: str,
    payload: ProjectUpdate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
) -> ProjectOut:
    assert_project_access(session, principal, project_id)
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(project, field, value)
    project.updated_by = principal.email
    session.flush()
    return ProjectOut.model_validate(project)


@router.delete("/{project_id}", response_model=MessageResponse, summary="Archive a project")
def delete_project(
    project_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
) -> MessageResponse:
    assert_project_access(session, principal, project_id)
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.")
    # Soft delete: history, runs and audit records must remain intact.
    project.soft_delete(principal.email)
    session.flush()
    return MessageResponse(message=f"Project '{project.name}' was archived.")


@router.get(
    "/{project_id}/environments",
    response_model=list[EnvironmentOut],
    summary="List project environments",
)
def list_environments(
    project_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
) -> list[EnvironmentOut]:
    assert_project_access(session, principal, project_id)
    rows = list(
        session.execute(
            select(Environment).where(Environment.project_id == project_id).order_by(Environment.key)
        )
        .scalars()
        .all()
    )
    return [EnvironmentOut.model_validate(row) for row in rows]


@router.post(
    "/{project_id}/environments",
    response_model=EnvironmentOut,
    status_code=201,
    summary="Add an environment",
)
def create_environment(
    project_id: str,
    payload: EnvironmentCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
) -> EnvironmentOut:
    assert_project_access(session, principal, project_id)
    project = session.get(Project, project_id)
    if project is None or project.is_deleted:
        raise NotFoundError(f"Project '{project_id}' was not found.")

    existing = session.execute(
        select(Environment).where(
            Environment.project_id == project_id, Environment.key == payload.key
        )
    ).scalar_one_or_none()
    if existing is not None:
        raise ConflictError(f"Environment '{payload.key}' already exists in this project.")

    environment = Environment(project_id=project_id, **payload.model_dump(), created_by=principal.email)
    session.add(environment)
    session.flush()
    return EnvironmentOut.model_validate(environment)
