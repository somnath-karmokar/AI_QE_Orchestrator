"""Connect a project to systems the customer owns.

Every route here is scoped by `ScopedProjectId`, so the project in the query
string is one the caller is a member of before any handler runs. A data source
id from another tenant reads as not found, because `data_sources.load` filters
on the project rather than checking afterwards.

No route returns a credential. The response model has no field that could carry
one: a screen learns which credential fields a kind takes, whether one is
stored, and a fingerprint that changes when it does -- never the value.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.api.deps import DbSession, ScopedProjectId, require_permission
from app.core.security import Principal
from app.governance.policy_engine import AuditService
from app.models.datasource import DATA_SOURCE_KINDS, secret_fields_for
from app.schemas.common import MessageResponse
from app.services import data_sources
from app.services.data_sources import OPTIONAL_CONFIG, REQUIRED_CONFIG

router = APIRouter(prefix="/data-sources", tags=["Data Sources"])


class DataSourceCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    kind: str
    description: str | None = Field(default=None, max_length=1000)
    # Host, port, database, bucket, base URL *and* the credential fields, in one
    # object. The service splits them by kind; a client is never trusted to say
    # which half a value belongs in.
    connection: dict[str, Any] = Field(default_factory=dict)
    allow_writes: bool = False


class DataSourceUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    description: str | None = Field(default=None, max_length=1000)
    connection: dict[str, Any] | None = None
    allow_writes: bool | None = None
    is_enabled: bool | None = None


@router.get("/kinds", summary="What kinds of data source can be connected")
def list_kinds(
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
) -> list[dict]:
    """The connection form, described by the server.

    The frontend renders fields from this rather than keeping its own copy,
    so which fields are treated as secret is decided in exactly one place.
    """
    return [
        {
            "kind": kind,
            "required_fields": list(REQUIRED_CONFIG.get(kind, ())),
            "optional_fields": list(OPTIONAL_CONFIG.get(kind, ())),
            "credential_fields": list(secret_fields_for(kind)),
        }
        for kind in DATA_SOURCE_KINDS
    ]


@router.get("", summary="Data sources connected to this project")
def list_data_sources(
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
    project_id: ScopedProjectId,
) -> list[dict]:
    return [
        data_sources.describe(row) for row in data_sources.list_for_project(session, project_id)
    ]


@router.post("", status_code=201, summary="Connect a data source")
def create_data_source(
    payload: DataSourceCreate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
    project_id: ScopedProjectId,
) -> dict:
    source = data_sources.create(
        session,
        project_id=project_id,
        name=payload.name,
        kind=payload.kind,
        connection=payload.connection,
        description=payload.description,
        allow_writes=payload.allow_writes,
        actor=principal.email,
    )
    AuditService(session).record(
        action="data_source.connect",
        entity_type="data_source",
        entity_id=source.id,
        entity_label=source.name,
        actor=principal.email,
        actor_type="user",
        project_id=project_id,
        reason=f"Connected a {source.kind} data source.",
        outcome="success",
        severity="info",
        # Deliberately only the shape of what was submitted. The audit trail is
        # read by more people than the data source screen is.
        input_summary={"kind": source.kind, "credential_supplied": bool(source.secret_bundle)},
    )
    return data_sources.describe(source)


@router.get("/{data_source_id}", summary="One data source")
def get_data_source(
    data_source_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:read"))],
    project_id: ScopedProjectId,
) -> dict:
    return data_sources.describe(data_sources.load(session, project_id, data_source_id))


@router.patch("/{data_source_id}", summary="Update a data source")
def update_data_source(
    data_source_id: str,
    payload: DataSourceUpdate,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
    project_id: ScopedProjectId,
) -> dict:
    source = data_sources.load(session, project_id, data_source_id)
    updated = data_sources.update(
        session,
        source,
        name=payload.name,
        description=payload.description,
        connection=payload.connection,
        allow_writes=payload.allow_writes,
        is_enabled=payload.is_enabled,
        actor=principal.email,
    )
    return data_sources.describe(updated)


@router.post("/{data_source_id}/test", summary="Test the connection")
def test_data_source(
    data_source_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
    project_id: ScopedProjectId,
) -> dict:
    """Try to reach the system, and record honestly what that proved.

    The result carries a `proves` line because a reachability check is not an
    authentication check, and a screen that showed one as the other would have
    people believing a credential works when it has never been used.
    """
    source = data_sources.load(session, project_id, data_source_id)
    return data_sources.test_connection(session, source)


@router.delete("/{data_source_id}", response_model=MessageResponse, summary="Disconnect a data source")
def delete_data_source(
    data_source_id: str,
    session: DbSession,
    principal: Annotated[Principal, Depends(require_permission("project:write"))],
    project_id: ScopedProjectId,
) -> MessageResponse:
    """Disconnect, and destroy the stored credential.

    The row is soft-deleted like everything else so the audit trail still makes
    sense, but the ciphertext is cleared outright: a customer who disconnects a
    source has withdrawn that credential, and keeping it would mean the
    platform still held a working key to their database.
    """
    source = data_sources.load(session, project_id, data_source_id)
    source.secret_bundle = None
    source.secret_fingerprint = None
    source.is_enabled = False
    source.soft_delete(principal.email)
    session.flush()

    AuditService(session).record(
        action="data_source.disconnect",
        entity_type="data_source",
        entity_id=source.id,
        entity_label=source.name,
        actor=principal.email,
        actor_type="user",
        project_id=project_id,
        reason="Disconnected; the stored credential was destroyed.",
        outcome="success",
        severity="info",
    )
    return MessageResponse(message="Data source disconnected and its credential destroyed.")
