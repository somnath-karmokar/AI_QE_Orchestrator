"""API v1 router aggregation."""

from __future__ import annotations

from fastapi import APIRouter

from app.api.v1 import (
    agents, auth, copilot, data_sources, defects, flows, governance, hooks, integration,
    knowledge,
    mcp_server,
    platform, projects, runs, testing,
)

api_router = APIRouter()

# Authentication and identity
api_router.include_router(auth.router)

# Conversational copilot
api_router.include_router(copilot.router)

# Core domain
api_router.include_router(projects.router)
api_router.include_router(agents.router)
api_router.include_router(agents.cart_router)
api_router.include_router(flows.router)
api_router.include_router(runs.router)

# Systems the customer owns, connected to their project.
api_router.include_router(data_sources.router)

# Inbound triggers (flow API tokens, no user session)
api_router.include_router(hooks.router)

# Outward-facing integration surface, plus the keys that authenticate it.
api_router.include_router(integration.router)
api_router.include_router(integration.admin_router)
# The same agents and flows, spoken as MCP, for agent platforms rather than pipelines.
api_router.include_router(mcp_server.router)

# Test engineering
api_router.include_router(testing.router)
api_router.include_router(testing.executions_router)

# Quality intelligence
api_router.include_router(defects.router)

# Knowledge Fabric
api_router.include_router(knowledge.router)

# Governance and AI cost
api_router.include_router(governance.router)
api_router.include_router(governance.audit_router)
api_router.include_router(governance.llm_router)

# Platform services
api_router.include_router(platform.router)
api_router.include_router(platform.ai_router)
api_router.include_router(platform.vector_router)
api_router.include_router(platform.mcp_router)
api_router.include_router(platform.system_router)

__all__ = ["api_router"]
