"""What the platform has learned from healing, and how it gets used again.

The `known_healing` rung began as an exact-string lookup: it fired only when the
*identical* locator had drifted before. That is the least useful version of
memory. A suite where `data-testid` is renamed in a redesign produces forty
different broken locators that are all the same problem, and an exact match
recognises none of them.

This indexes each outcome — the failure, the change, and crucially **whether it
held** — into the vector store, so a new failure can find the near neighbours of
what has worked before. Failed heals are indexed too: knowing that a particular
repair was tried and did not hold is worth as much as knowing one worked.

Retrieval is project-scoped, as everything else here is. One customer's drift
never informs another's.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.knowledge.service import KnowledgeService
from app.models.testing import HealingRecord
from app.vectorstore.base import COLLECTION_EXECUTION_HISTORY

logger = get_logger(__name__)

# Only outcomes worth learning from. A proposal nobody decided teaches nothing.
INDEXABLE_STATUSES = {"applied", "rolled_back", "validation_failed", "rejected"}


def _document(record: HealingRecord) -> str:
    """The text a future failure is matched against.

    Written as a short narrative rather than a field dump, because that is what
    embeds usefully: the failure, what was changed, and what happened next.
    """
    outcome = {
        "applied": "the change was applied after its re-run passed",
        "rolled_back": "the change was discarded because its re-run failed",
        "validation_failed": "the change could not be proved and was not applied",
        "rejected": "a reviewer declined the change",
    }.get(record.status, record.status)

    return (
        f"A {record.failure_class.replace('_', ' ')} failure was repaired as a "
        f"{record.change_type.replace('_', ' ')} change. "
        f"From: {record.original_locator}. To: {record.proposed_locator}. "
        f"Strategy: {record.locator_strategy}. Reason: {record.reason} "
        f"Outcome: {outcome}."
    )


def index_healing_outcome(session: Session, record: HealingRecord) -> bool:
    """Record what this heal taught, for the next one. Returns whether it did.

    Never raises into the caller: failing to learn from a heal must not undo the
    heal itself.
    """
    if record.status not in INDEXABLE_STATUSES:
        return False

    try:
        KnowledgeService(session).index_text(
            project_id=record.project_id,
            collection=COLLECTION_EXECUTION_HISTORY,
            record_id=f"healing:{record.id}",
            content=_document(record),
            metadata={
                "artifact_type": "healing_outcome",
                "source_type": "healing",
                "healing_record_id": record.id,
                "change_type": record.change_type,
                "failure_class": record.failure_class,
                "healing_strategy": record.locator_strategy,
                "status": record.status,
                # The fact that makes this worth retrieving at all.
                "held": record.status == "applied" and record.validation_status == "passed",
                "confidence": record.confidence,
                "original_locator": record.original_locator,
                "proposed_locator": record.proposed_locator,
            },
        )
    except Exception as error:  # noqa: BLE001 - learning is best-effort
        logger.warning("healing_index_failed", healing_record_id=record.id, error=str(error))
        return False

    logger.info("healing_indexed", healing_record_id=record.id, status=record.status)
    return True


def similar_successful_heals(
    session: Session,
    *,
    project_id: str,
    failure_message: str | None,
    original_locator: str,
    limit: int = 5,
    min_score: float = 0.55,
) -> list[dict[str, Any]]:
    """Repairs that held, for failures that look like this one.

    The returned records are re-read from the database rather than trusted from
    the index, so a heal that has since been rolled back cannot be recommended
    by a stale embedding.
    """
    query = f"{failure_message or ''} {original_locator}".strip()
    if not query:
        return []

    try:
        hits = KnowledgeService(session).retrieve(
            query,
            project_id=project_id,
            collection=COLLECTION_EXECUTION_HISTORY,
            limit=limit * 3,
            artifact_type="healing_outcome",
            min_score=min_score,
        )
    except Exception as error:  # noqa: BLE001 - retrieval is an optimisation
        logger.warning("healing_recall_failed", error=str(error))
        return []

    suggestions: list[dict[str, Any]] = []
    seen: set[str] = set()
    for hit in hits:
        record_id = hit.metadata.get("healing_record_id")
        if not record_id or record_id in seen:
            continue
        seen.add(record_id)

        # Re-read the source of truth. The index says what was true when it was
        # written; the record says what is true now.
        record = session.get(HealingRecord, record_id)
        if record is None:
            continue
        if record.status != "applied" or record.validation_status != "passed":
            continue

        suggestions.append(
            {
                "healing_record_id": record.id,
                "score": round(hit.score, 4),
                "change_type": record.change_type,
                "strategy": record.locator_strategy,
                "original_locator": record.original_locator,
                "proposed_locator": record.proposed_locator,
                "reason": record.reason,
            }
        )
        if len(suggestions) >= limit:
            break
    return suggestions


def backfill(session: Session, project_id: str) -> int:
    """Index every decided heal this project already has.

    Run once after upgrading, so memory does not start empty on a platform that
    has been healing for months.
    """
    records = list(
        session.execute(
            select(HealingRecord).where(
                HealingRecord.project_id == project_id,
                HealingRecord.status.in_(sorted(INDEXABLE_STATUSES)),
            )
        )
        .scalars()
        .all()
    )
    return sum(1 for record in records if index_healing_outcome(session, record))
