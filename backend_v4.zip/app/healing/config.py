"""Healing configuration.

Thresholds, confidence weights, the strategy ladder and the change-policy matrix
live here as data, never as constants inside an agent. A deployment tunes healing
by changing configuration; nobody edits Python to make healing stricter.

Overrides come from the environment via `Settings` (``HEALING_*`` variables), so
the demo and an enterprise install differ only in their `.env`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache

from app.core.config import settings

# Ordered cheapest/most-deterministic first. The engine walks this ladder and
# stops at the first strategy that produces a confident candidate, so the LLM is
# consulted only when deterministic evidence has been exhausted.
DEFAULT_STRATEGY_LADDER: tuple[str, ...] = (
    "known_healing",       # this exact drift has been healed before, and it held
    "test_id",             # data-testid / data-test / id explicitly meant for tests
    "accessibility_role",  # role + accessible name
    "label",               # associated <label>, aria-label, placeholder
    "css_structural",      # stable structural CSS path
    "dom_similarity",      # nearest neighbour in the captured DOM snapshot
    "text_content",        # visible text match
    "visual",              # screenshot region match
    "llm_assisted",        # last resort, always evidence-backed
)

# How much each signal contributes to a candidate's confidence. Weights are
# normalised at use, so a deployment can add or drop a signal without having to
# rebalance the rest by hand.
DEFAULT_CONFIDENCE_WEIGHTS: dict[str, float] = {
    "strategy_robustness": 0.30,
    "dom_similarity": 0.20,
    "text_similarity": 0.15,
    "accessibility_match": 0.15,
    "historical_match": 0.15,
    "visual_similarity": 0.05,
    # Timing only: how much of the allowed wait budget is left over after the
    # element's observed arrival. An element that needs nearly all of it is a
    # performance problem being papered over, and should score lower.
    "timing_headroom": 0.20,
    # Test data only: how much a substitute record had to agree on. Matching
    # only the shape is a weaker claim to equivalence than matching tier,
    # currency and limit as well.
    "data_equivalence": 0.25,
}

# How strongly each locator strategy is anchored to something a user can
# perceive. A locator built on an accessible role or an explicit test id survives
# a redesign; one built on a generated class name does not.
ACCESSIBILITY_STRENGTH: dict[str, float] = {
    "test_id": 1.0,
    "role": 0.95,
    "label": 0.90,
    "placeholder": 0.80,
    "text": 0.70,
    "alt": 0.70,
    "title": 0.60,
    "css": 0.40,
    "xpath": 0.25,
}


# What healing is permitted to change, by change type.
#   "auto"      -- may apply without a human, if confidence and validation pass
#   "approval"  -- always needs a named approver, however confident the model is
#   "forbidden" -- never changed by healing, at any confidence, ever
#
# Assertions and business rules are forbidden by design: a test that fails
# because the application is wrong must stay failed. Healing repairs how a test
# finds and drives the application, never what it claims about it.
DEFAULT_CHANGE_POLICY: dict[str, str] = {
    "locator": "auto",
    "timing": "auto",
    "navigation": "approval",
    "test_data": "approval",
    "api_contract": "approval",
    "assertion": "forbidden",
    "business_rule": "forbidden",
    "test_logic": "forbidden",
}


@dataclass(frozen=True, slots=True)
class HealingConfig:
    """Resolved healing settings for one deployment."""

    enabled: bool = True
    # Confidence at or above which a permitted change may skip human approval.
    auto_apply_threshold: float = 0.85
    # Below this, a candidate is not even worth proposing to a human.
    propose_threshold: float = 0.50
    # A candidate must beat the runner-up by this much, or the element is
    # ambiguous and the heal goes to a human regardless of raw confidence.
    ambiguity_margin: float = 0.10
    # A heal must survive a re-run before it is recorded as successful.
    require_validation: bool = True
    # Run that validation in the request, or hand it to the background worker.
    validate_async: bool = False
    # Give up after this many healing attempts on one test, so a permanently
    # broken test cannot loop.
    max_attempts_per_test: int = 3
    # Bounded waits for the timing strategy.
    max_wait_ms: int = 15_000
    max_retries: int = 2

    strategy_ladder: tuple[str, ...] = DEFAULT_STRATEGY_LADDER
    confidence_weights: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_CONFIDENCE_WEIGHTS))
    change_policy: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_CHANGE_POLICY))

    def policy_for(self, change_type: str) -> str:
        """Policy for a change type; anything unrecognised is forbidden."""
        return self.change_policy.get(change_type, "forbidden")

    def score(self, signals: dict[str, float]) -> float:
        """Blend per-signal scores (0..1) into one confidence, normalised by the
        weights of the signals that were actually measured."""
        total_weight = 0.0
        total = 0.0
        for signal, value in signals.items():
            weight = self.confidence_weights.get(signal)
            if weight is None:
                continue
            total += weight * max(0.0, min(1.0, float(value)))
            total_weight += weight
        if total_weight <= 0:
            return 0.0
        return round(total / total_weight, 4)

    def breakdown(self, signals: dict[str, float]) -> list[dict[str, float | str]]:
        """Per-signal contributions, persisted with the record so a reviewer can
        see *why* a number came out where it did."""
        total_weight = sum(
            self.confidence_weights[name] for name in signals if name in self.confidence_weights
        )
        rows: list[dict[str, float | str]] = []
        for signal, value in signals.items():
            weight = self.confidence_weights.get(signal)
            if weight is None:
                continue
            clamped = max(0.0, min(1.0, float(value)))
            rows.append(
                {
                    "signal": signal,
                    "score": round(clamped, 4),
                    "weight": round(weight / total_weight, 4) if total_weight else 0.0,
                    "contribution": round((weight * clamped) / total_weight, 4) if total_weight else 0.0,
                }
            )
        return sorted(rows, key=lambda row: float(row["contribution"]), reverse=True)


@lru_cache(maxsize=1)
def healing_config() -> HealingConfig:
    """The active configuration, built from settings once per process."""
    return HealingConfig(
        enabled=settings.healing_enabled,
        auto_apply_threshold=settings.healing_auto_apply_threshold,
        propose_threshold=settings.healing_propose_threshold,
        ambiguity_margin=settings.healing_ambiguity_margin,
        require_validation=settings.healing_require_validation,
        validate_async=settings.healing_validate_async,
        max_attempts_per_test=settings.healing_max_attempts_per_test,
        max_wait_ms=settings.healing_max_wait_ms,
        max_retries=settings.healing_max_retries,
        confidence_weights={**DEFAULT_CONFIDENCE_WEIGHTS, **(settings.healing_confidence_weights or {})},
        change_policy={**DEFAULT_CHANGE_POLICY, **(settings.healing_change_policy or {})},
    )
