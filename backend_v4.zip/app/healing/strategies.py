"""The healing strategy ladder.

Rungs are tried in a fixed, configured order and the walk **stops at the first
one that produces a confident candidate**. The order is not arbitrary: it runs
from the cheapest and most certain to the most expensive and most speculative.

    known_healing      this exact drift was healed before, and it held
    test_id            a dedicated test id
    accessibility_role role plus accessible name
    label              an associated label
    css_structural     a stable structural path
    dom_similarity     nearest neighbour in the captured DOM
    text_content       visible text
    visual             screenshot region
    llm_assisted       last resort, still evidence-backed

Two things follow from stopping early. The obvious one is cost: a heal that
resolves on the first rung never pays for a model call. The less obvious one is
explainability -- "healed at `test_id`, rung 2 of 9, having tried
`known_healing`" is a sentence a reviewer can check, where "the AI suggested
this" is not.

A rung that produces nothing is recorded as tried. That record is the difference
between "we found the best answer" and "we found the first answer".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.healing.config import ACCESSIBILITY_STRENGTH, HealingConfig, healing_config
from app.healing.dom import candidates_by_strategy, expression_resolves
from app.healing.knowledge import similar_successful_heals
from app.healing.policy import ChangeType
from app.models.testing import HealingRecord

logger = get_logger(__name__)

# Which locator strategies each DOM rung is allowed to emit. A rung that maps to
# no strategy (visual, llm_assisted) has its own resolver.
RUNG_STRATEGIES: dict[str, tuple[str, ...]] = {
    "test_id": ("test_id",),
    "accessibility_role": ("role",),
    "label": ("label", "placeholder"),
    "css_structural": ("css",),
    "dom_similarity": ("test_id", "role", "label", "css", "text"),
    "text_content": ("text",),
}


@dataclass(slots=True)
class LadderResult:
    """What the walk found, and what it had to try to find it."""

    candidates: list[dict[str, Any]] = field(default_factory=list)
    resolved_by: str | None = None
    rungs_tried: list[str] = field(default_factory=list)
    rungs_skipped: list[str] = field(default_factory=list)

    @property
    def found(self) -> bool:
        return bool(self.candidates)

    def to_dict(self) -> dict[str, Any]:
        return {
            "resolved_by": self.resolved_by,
            "rungs_tried": self.rungs_tried,
            "rungs_skipped": self.rungs_skipped,
            "candidate_count": len(self.candidates),
        }

    def evidence(self, ladder: tuple[str, ...]) -> dict[str, str]:
        """A line a reviewer can check, not a claim they must trust."""
        if not self.resolved_by:
            return {
                "type": "strategy_ladder",
                "detail": (
                    f"No strategy produced a candidate. Tried "
                    f"{', '.join(self.rungs_tried) or 'nothing'}."
                ),
            }
        position = ladder.index(self.resolved_by) + 1 if self.resolved_by in ladder else 0
        earlier = [rung for rung in self.rungs_tried if rung != self.resolved_by]
        return {
            "type": "strategy_ladder",
            "detail": (
                f"Resolved by '{self.resolved_by}', rung {position} of {len(ladder)}"
                + (f", after {', '.join(earlier)} produced nothing." if earlier else ".")
            ),
        }


class StrategyLadder:
    """Walks the configured rungs in order and stops at the first that answers."""

    def __init__(self, session: Session, *, config: HealingConfig | None = None) -> None:
        self.session = session
        self.config = config or healing_config()

    # ------------------------------------------------------------------
    def propose_locator(
        self,
        *,
        project_id: str,
        original_locator: str,
        fingerprint: dict[str, Any],
        dom_html: str | None,
        failure_message: str | None = None,
        limit: int = 4,
    ) -> LadderResult:
        result = LadderResult()
        self._failure_message = failure_message

        for rung in self.config.strategy_ladder:
            candidates = self._run_rung(
                rung,
                project_id=project_id,
                original_locator=original_locator,
                fingerprint=fingerprint,
                dom_html=dom_html,
                limit=limit,
            )
            if candidates is None:
                # The rung could not run at all -- no evidence, not implemented
                # here, or switched off. Not the same as "tried and found none".
                result.rungs_skipped.append(rung)
                continue

            result.rungs_tried.append(rung)
            usable = [
                candidate
                for candidate in candidates
                if candidate["confidence"] >= self.config.propose_threshold
            ]
            if usable:
                result.candidates = sorted(
                    usable, key=lambda item: item["confidence"], reverse=True
                )[:limit]
                result.resolved_by = rung
                logger.info(
                    "healing_ladder_resolved",
                    rung=rung,
                    tried=len(result.rungs_tried),
                    confidence=result.candidates[0]["confidence"],
                )
                return result

        logger.info("healing_ladder_exhausted", tried=result.rungs_tried)
        return result

    # ------------------------------------------------------------------
    def _run_rung(
        self,
        rung: str,
        *,
        project_id: str,
        original_locator: str,
        fingerprint: dict[str, Any],
        dom_html: str | None,
        limit: int,
    ) -> list[dict[str, Any]] | None:
        """Candidates from one rung, or None if the rung could not run."""
        if rung == "known_healing":
            return self._known_healing(project_id, original_locator, dom_html)

        if rung in RUNG_STRATEGIES:
            if not dom_html:
                return None  # no captured page, so no DOM rung can run
            return candidates_by_strategy(
                dom_html,
                fingerprint,
                strategies=RUNG_STRATEGIES[rung],
                limit=limit,
            )

        # `visual` needs image comparison and `llm_assisted` needs a model call;
        # neither is wired up yet. Reporting them as skipped is honest, and the
        # record shows a reviewer exactly how far the walk got.
        return None

    # ------------------------------------------------------------------
    def _known_healing(
        self, project_id: str, original_locator: str, dom_html: str | None
    ) -> list[dict[str, Any]]:
        """Has this exact drift been healed before, and did the heal hold?

        The cheapest rung and, when it applies, the most trustworthy: a
        replacement that already survived a re-run is better evidence than any
        amount of DOM similarity.

        It is only trustworthy *when it applies*, though. A heal that worked last
        month says nothing about a page that has changed again, so a remembered
        locator is checked against the captured page before being offered. One
        that is no longer there is dropped and the walk moves on.
        """
        rows = list(
            self.session.execute(
                select(HealingRecord)
                .where(
                    HealingRecord.project_id == project_id,
                    HealingRecord.original_locator == original_locator,
                    HealingRecord.status == "applied",
                    HealingRecord.validation_status == "passed",
                )
                .order_by(HealingRecord.validated_at.desc())
                .limit(5)
            )
            .scalars()
            .all()
        )

        candidates: list[dict[str, Any]] = []
        seen: set[str] = set()

        remembered: list[tuple[Any, float, str]] = [(record, 0.95, "exact") for record in rows]

        # Exact matches are rare in practice: a redesign renames forty test ids
        # and none of them is a string we have seen before. Recall finds the
        # repairs that worked on failures *like* this one, which is what makes
        # memory useful rather than decorative.
        for hit in similar_successful_heals(
            self.session,
            project_id=project_id,
            failure_message=getattr(self, "_failure_message", None),
            original_locator=original_locator,
        ):
            record = self.session.get(HealingRecord, hit["healing_record_id"])
            if record is None or record.id in {item[0].id for item in remembered}:
                continue
            # A remembered-by-similarity repair is a weaker claim than an exact
            # one, and its score says how much weaker.
            remembered.append((record, round(0.72 + 0.2 * hit["score"], 4), "similar"))

        for record, confidence, basis in remembered:
            if record.proposed_locator in seen:
                continue
            seen.add(record.proposed_locator)
            if dom_html and not expression_resolves(dom_html, record.proposed_locator):
                logger.info(
                    "healing_known_locator_stale",
                    locator=record.proposed_locator,
                    reason="not present on the page captured at failure",
                )
                continue
            candidates.append(
                {
                    "strategy": record.locator_strategy,
                    "locator": record.proposed_locator,
                    # High, but never certain: the page may have moved on again.
                    # A re-run still has to prove it, as it does for every heal.
                    "confidence": confidence,
                    "match_score": 1.0 if basis == "exact" else 0.8,
                    "signals": {
                        "historical_match": 1.0 if basis == "exact" else 0.8,
                        "accessibility_match": ACCESSIBILITY_STRENGTH.get(
                            record.locator_strategy, 0.5
                        ),
                    },
                    "rationale": (
                        f"This same drift was healed to {record.proposed_locator} before, "
                        f"and that change passed its re-run."
                        if basis == "exact"
                        else (
                            f"A failure like this one was healed to {record.proposed_locator} "
                            f"before ({record.original_locator}), and that change passed its "
                            f"re-run. The locator is still present on this page."
                        )
                    ),
                }
            )
        return candidates


# ---------------------------------------------------------------------------
# Timing
# ---------------------------------------------------------------------------


def propose_wait(
    *,
    observed_wait_ms: int | None,
    current_timeout_ms: int,
    config: HealingConfig | None = None,
) -> dict[str, Any] | None:
    """A wait long enough for an element that was only slow, not missing.

    Only called when the runner proved the element *does* appear -- it waited,
    and the element arrived. That observation is what makes this a repair rather
    than a guess, and it is why the proposed wait is derived from the measured
    time rather than from a round number someone liked.

    Returns None when waiting would not have helped.
    """
    config = config or healing_config()
    if not observed_wait_ms or observed_wait_ms <= 0:
        return None

    # Headroom over what was actually observed, since a page that took 1.2s once
    # will take longer on a bad day. Capped, so a heal cannot turn a fast suite
    # into a slow one.
    proposed = min(int(observed_wait_ms * 2.5), config.max_wait_ms)
    if proposed <= current_timeout_ms:
        return None

    # Confidence falls as the required wait approaches the ceiling: an element
    # that needs almost all of the budget is a performance problem being papered
    # over, and deserves a human.
    headroom = 1.0 - (observed_wait_ms / config.max_wait_ms)
    confidence = round(max(0.55, min(0.93, 0.6 + 0.35 * headroom)), 4)

    description = f"wait for the element to be attached, up to {proposed}ms"
    return {
        "change_type": ChangeType.TIMING,
        "strategy": "explicit_wait",
        "from": f"wait up to {current_timeout_ms}ms",
        "to": description,
        # Named `locator` so a timing candidate travels through the same
        # pipeline as a locator one: the field means "what this changes to".
        "locator": description,
        "wait_ms": proposed,
        "observed_wait_ms": observed_wait_ms,
        "confidence": confidence,
        "signals": {"timing_headroom": round(headroom, 4)},
        "rationale": (
            f"The element was not missing -- it appeared after {observed_wait_ms}ms, which is "
            f"longer than the {current_timeout_ms}ms the test allowed. Waiting for it explicitly, "
            f"up to {proposed}ms, addresses the cause rather than retrying the whole test."
        ),
    }
