"""Governed self-healing for automated regression suites (spec section 11).

The package is deliberately small and layered:

  * `config`     -- every threshold, weight, ladder and policy as configuration.
  * `policy`     -- what a heal is *allowed* to change, decided before anything runs.
  * `validation` -- temporary patch -> re-run -> validate -> persist or roll back.
  * `service`    -- the operations the API and agents call.

The rule the whole package exists to enforce: a heal is never recorded as
successful until a re-run proved it, and a heal never touches a business
assertion.
"""

from app.healing.config import HealingConfig, healing_config
from app.healing.policy import ChangeType, HealingGate, evaluate_change
from app.healing.service import HealingService
from app.healing.validation import HealingValidationService, ValidationOutcome

__all__ = [
    "ChangeType",
    "HealingConfig",
    "HealingGate",
    "HealingService",
    "HealingValidationService",
    "ValidationOutcome",
    "evaluate_change",
    "healing_config",
]
