"""Repairing a test whose data ran out.

A large share of "flaky" regression failures are nothing of the sort: the account
the test used was closed, the voucher was already redeemed, the record was
cleaned up overnight. The test is correct and the application is correct; the
fixture is gone.

The repair is to run the same test against an equivalent record. Two things make
that safe rather than reckless:

  * **Equivalence is checked, not assumed.** A substitute must have the same
    shape as the record that failed and the same values on whatever the test
    actually depends on — a "gold tier" test substituted with a standard-tier
    account is not the same test any more.
  * **A person always approves it.** Substituting data changes what was tested,
    so the change-policy matrix requires an approver at any confidence. That is
    not a tunable in practice: lowering it would let the platform quietly alter
    the meaning of a result.

Every substitution is recorded, so "this passed on a different account" is never
something a reader has to discover for themselves.
"""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.healing.policy import ChangeType
from app.models.testing import TestDataSet

logger = get_logger(__name__)

# Values that mean "this record cannot be used again".
UNUSABLE_STATES = {
    "closed",
    "expired",
    "locked",
    "used",
    "consumed",
    "redeemed",
    "cancelled",
    "suspended",
    "deleted",
    "inactive",
}

# Keys that identify a record rather than describe it. Two records are
# equivalent when they differ on these and agree on the rest.
IDENTITY_KEYS = {
    "id",
    "ref",
    "reference",
    "account",
    "account_id",
    "account_ref",
    "number",
    "code",
    "card",
    "card_number",
    "voucher",
    "token",
    "email",
    "username",
    "iban",
}

# Keys that say whether a record is usable, rather than what it is.
STATE_KEYS = {"status", "state", "availability", "is_active", "active", "expires_at", "expiry"}

# Real schemas rarely use the bare words: `user_id`, `account_status`,
# `card_number`. Matching on the suffix is what makes this work against data
# somebody else designed.
IDENTITY_SUFFIXES = ("_id", "_ref", "_reference", "_number", "_code", "_key")
STATE_SUFFIXES = ("_status", "_state", "_expiry", "_expires_at")


def _is_identity_key(key: str) -> bool:
    lowered = key.lower()
    return lowered in IDENTITY_KEYS or lowered.endswith(IDENTITY_SUFFIXES)


def _is_state_key(key: str) -> bool:
    lowered = key.lower()
    return lowered in STATE_KEYS or lowered.endswith(STATE_SUFFIXES)

# An identifier in a failure message: LOY-2210, ACC_88123, 4111111111111111.
# The suffix may be a single character -- ACCOUNT-7 is a reference too.
_REFERENCE = re.compile(r"\b([A-Z]{2,}[-_][A-Za-z0-9]+|\d{8,19})\b")


def extract_reference(message: str | None) -> str | None:
    """The record identifier a failure message is complaining about.

    Returning None is a real answer: without knowing *which* record ran out,
    there is nothing to substitute and the failure needs a person.
    """
    if not message:
        return None
    match = _REFERENCE.search(message)
    return match.group(1) if match else None


def _is_usable(record: dict[str, Any]) -> bool:
    for key, value in record.items():
        if not _is_state_key(key):
            continue
        if isinstance(value, bool):
            if key.lower() in {"is_active", "active"} and not value:
                return False
        elif isinstance(value, str) and value.strip().lower() in UNUSABLE_STATES:
            return False
    return True


def _identity_of(record: dict[str, Any]) -> str | None:
    for key, value in record.items():
        if _is_identity_key(key) and value:
            return str(value)
    return None


def _characteristics(record: dict[str, Any]) -> dict[str, Any]:
    """What the record *is*, with identity and state stripped out.

    This is what has to match for a substitution to be the same test: the tier,
    the currency, the limit — not the account number, and not whether it happens
    to be open today.
    """
    return {
        key: value
        for key, value in record.items()
        if not _is_identity_key(key) and not _is_state_key(key)
    }


def find_substitute(
    session: Session,
    *,
    project_id: str,
    module: str | None,
    failed_reference: str | None,
) -> dict[str, Any] | None:
    """An equivalent, usable record for the one that ran out.

    Searches the project's data sets for the record that failed, then for
    another record of the same shape and characteristics that is still usable.
    Returns None when there is no honest substitute -- a test that cannot be run
    on equivalent data should fail and be looked at.
    """
    if not failed_reference:
        return None

    datasets = list(
        session.execute(
            select(TestDataSet).where(
                TestDataSet.project_id == project_id,
                TestDataSet.is_deleted.is_(False),
            )
        )
        .scalars()
        .all()
    )

    # Find the record that failed, so we know what we are matching against.
    source: dict[str, Any] | None = None
    source_dataset: TestDataSet | None = None
    for dataset in datasets:
        for record in dataset.records or []:
            if not isinstance(record, dict):
                continue
            if _identity_of(record) == failed_reference:
                source, source_dataset = record, dataset
                break
        if source is not None:
            break

    if source is None:
        logger.info("data_substitute_unknown_record", reference=failed_reference)
        return None

    wanted = _characteristics(source)
    # Prefer the same data set, then the same module; a substitute from an
    # unrelated set is unlikely to mean the same thing.
    ordered = sorted(
        datasets,
        key=lambda item: (
            0 if item.id == (source_dataset.id if source_dataset else None) else 1,
            0 if module and item.module == module else 1,
        ),
    )

    for dataset in ordered:
        for record in dataset.records or []:
            if not isinstance(record, dict):
                continue
            identity = _identity_of(record)
            if not identity or identity == failed_reference:
                continue
            if not _is_usable(record):
                continue
            if _characteristics(record) != wanted:
                continue
            return {
                "dataset_id": dataset.id,
                "dataset_name": dataset.name,
                "from_reference": failed_reference,
                "to_reference": identity,
                "record": record,
                "matched_on": sorted(wanted),
            }

    logger.info("data_substitute_none_equivalent", reference=failed_reference)
    return None


def propose_substitution(
    session: Session,
    *,
    project_id: str,
    module: str | None,
    failure_message: str | None,
) -> dict[str, Any] | None:
    """A data repair candidate, in the shape the healing pipeline expects."""
    reference = extract_reference(failure_message)
    substitute = find_substitute(
        session, project_id=project_id, module=module, failed_reference=reference
    )
    if substitute is None:
        return None

    matched = substitute["matched_on"]
    # Confidence reflects how much the substitute had to agree on. A record with
    # nothing to match beyond its shape is a weaker claim to equivalence than
    # one that matched tier, currency and limit.
    confidence = round(min(0.94, 0.62 + 0.08 * len(matched)), 4)

    description = f"{substitute['from_reference']} -> {substitute['to_reference']}"
    return {
        "change_type": ChangeType.TEST_DATA,
        "strategy": "equivalent_record",
        "from": substitute["from_reference"],
        "to": substitute["to_reference"],
        "locator": description,
        "confidence": confidence,
        "dataset_id": substitute["dataset_id"],
        "record": substitute["record"],
        "signals": {"historical_match": 0.0, "data_equivalence": round(min(1.0, len(matched) / 4), 4)},
        "rationale": (
            f"{substitute['from_reference']} is no longer usable. "
            f"{substitute['to_reference']} in '{substitute['dataset_name']}' is equivalent on "
            f"{', '.join(matched) if matched else 'its shape'}, and is available. "
            f"Substituting data changes what was tested, so a person approves this."
        ),
    }
