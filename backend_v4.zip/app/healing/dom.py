"""Read a captured page and propose locators that actually exist on it.

Healing without this is guesswork: a model invents a plausible-looking selector
and nobody can say whether the element is there. With it, every candidate is
taken from the DOM that was captured at the moment of failure, so "does this
element exist" stops being a question.

Matching works from a **fingerprint** -- what the element looked like the last
time the locator did resolve (its tag, role, accessible name, text and
attributes). An element in the new page is a candidate to the degree that it
looks like that fingerprint. This is why a renamed `data-testid` heals cleanly:
the role and the accessible name did not change, and the fingerprint remembers
them.

Uses only the standard library, so it works wherever the platform does.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any

# Tags that can be the target of a test locator. Anything else is structure.
INTERACTIVE = {"button", "a", "input", "select", "textarea", "summary", "option", "label"}
# Elements worth locating even though they are not interactive -- assertions read them.
READABLE = {"h1", "h2", "h3", "span", "p", "td", "th", "li", "div", "output"}

IMPLICIT_ROLE = {
    "button": "button",
    "a": "link",
    "select": "combobox",
    "textarea": "textbox",
    "summary": "button",
    "h1": "heading",
    "h2": "heading",
    "h3": "heading",
    "option": "option",
}
INPUT_TYPE_ROLE = {
    "text": "textbox",
    "email": "textbox",
    "password": "textbox",
    "search": "searchbox",
    "tel": "textbox",
    "url": "textbox",
    "number": "spinbutton",
    "checkbox": "checkbox",
    "radio": "radio",
    "submit": "button",
    "button": "button",
    "range": "slider",
}

TEST_ID_ATTRS = ("data-testid", "data-test-id", "data-test", "data-qa", "data-cy")

VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "wbr"}


@dataclass(slots=True)
class Element:
    tag: str
    attrs: dict[str, str] = field(default_factory=dict)
    text: str = ""

    @property
    def test_id(self) -> str | None:
        for name in TEST_ID_ATTRS:
            if self.attrs.get(name):
                return self.attrs[name]
        return None

    @property
    def role(self) -> str | None:
        if self.attrs.get("role"):
            return self.attrs["role"]
        if self.tag == "input":
            return INPUT_TYPE_ROLE.get(self.attrs.get("type", "text").lower(), "textbox")
        return IMPLICIT_ROLE.get(self.tag)

    def accessible_name(self, labels: dict[str, str]) -> str:
        """Roughly what a screen reader would announce."""
        for source in (
            self.attrs.get("aria-label"),
            labels.get(self.attrs.get("id", "")),
            self.text.strip(),
            self.attrs.get("placeholder"),
            self.attrs.get("title"),
            self.attrs.get("alt"),
            self.attrs.get("value") if self.tag == "input" else None,
        ):
            if source and source.strip():
                return " ".join(source.split())
        return ""

    def fingerprint(self, labels: dict[str, str]) -> dict[str, Any]:
        """The identity worth remembering, so drift can be recognised later."""
        return {
            "tag": self.tag,
            "role": self.role,
            "name": self.accessible_name(labels),
            "test_id": self.test_id,
            "id": self.attrs.get("id"),
            "type": self.attrs.get("type"),
            "classes": (self.attrs.get("class") or "").split(),
            "text": " ".join(self.text.split())[:120],
        }


class _Collector(HTMLParser):
    """Builds a flat element list plus the label-for map, in one pass."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.elements: list[Element] = []
        self.labels: dict[str, str] = {}
        self._stack: list[Element] = []
        self._skip = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style"}:
            self._skip += 1
            return
        element = Element(tag=tag, attrs={key: (value or "") for key, value in attrs})
        self.elements.append(element)
        if tag not in VOID:
            self._stack.append(element)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style"}:
            self._skip = max(0, self._skip - 1)
            return
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index].tag == tag:
                closing = self._stack.pop(index)
                del self._stack[index:]
                if closing.tag == "label":
                    target = closing.attrs.get("for")
                    if target:
                        self.labels[target] = " ".join(closing.text.split())
                break

    def handle_data(self, data: str) -> None:
        if self._skip or not data.strip():
            return
        # Text belongs to every open element, which is how inner text works.
        for element in self._stack:
            element.text += data


def parse_page(html: str) -> tuple[list[Element], dict[str, str]]:
    collector = _Collector()
    collector.feed(html or "")
    return collector.elements, collector.labels


def normalise_fingerprint(raw: dict[str, Any]) -> dict[str, Any]:
    """Turn a raw capture from the browser into the shape matching expects.

    Two things the browser does not hand over directly and matching depends on:
    an element's *implicit* role (a `<button>` has role "button" without saying
    so) and its accessible name. Losing either makes a heal fall back to
    comparing test-id spellings, which is how a "cancel" button gets mistaken
    for a "pay" button.
    """
    tag = (raw.get("tag") or "").lower()
    role = raw.get("role")
    if not role:
        role = (
            INPUT_TYPE_ROLE.get((raw.get("type") or "text").lower(), "textbox")
            if tag == "input"
            else IMPLICIT_ROLE.get(tag)
        )
    name = ""
    for source in (raw.get("aria_label"), raw.get("label"), raw.get("text"), raw.get("placeholder")):
        if source and str(source).strip():
            name = " ".join(str(source).split())
            break
    return {
        "tag": tag or None,
        "role": role,
        "name": name,
        "test_id": raw.get("test_id"),
        "id": raw.get("id"),
        "type": raw.get("type"),
        "classes": raw.get("classes") or [],
        "text": " ".join((raw.get("text") or "").split())[:120],
    }


def _tokens(text: str | None) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", (text or "").lower()) if len(token) > 1}


def _overlap(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def _quote(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def locator_expressions(element: Element, labels: dict[str, str]) -> list[tuple[str, str, float]]:
    """Every way to address this element, best strategy first.

    The order is the healing ladder: a dedicated test id, then the accessible
    role and name, then the label, and only then something structural.
    """
    options: list[tuple[str, str, float]] = []
    name = element.accessible_name(labels)

    if element.test_id:
        options.append(("test_id", f'page.get_by_test_id("{_quote(element.test_id)}")', 0.97))
    if element.role and name:
        options.append(
            ("role", f'page.get_by_role("{element.role}", name="{_quote(name)}")', 0.94)
        )
    if labels.get(element.attrs.get("id", "")):
        options.append(
            ("label", f'page.get_by_label("{_quote(labels[element.attrs["id"]])}")', 0.90)
        )
    if element.attrs.get("placeholder"):
        options.append(
            ("placeholder", f'page.get_by_placeholder("{_quote(element.attrs["placeholder"])}")', 0.82)
        )
    if element.tag not in {"input", "select", "textarea"} and element.text.strip():
        text = " ".join(element.text.split())[:60]
        options.append(("text", f'page.get_by_text("{_quote(text)}")', 0.72))
    if element.attrs.get("id"):
        options.append(("css", f'page.locator("#{element.attrs["id"]}")', 0.60))
    return options


def score_against(element: Element, fingerprint: dict[str, Any], labels: dict[str, str]) -> dict[str, float]:
    """How much this element looks like the one the locator used to find."""
    name = element.accessible_name(labels)
    signals: dict[str, float] = {}

    # The accessible name is the strongest signal: it is what a user sees, and
    # redesigns rarely change it.
    signals["text_similarity"] = _overlap(_tokens(name), _tokens(fingerprint.get("name")))

    # Role equality is close to necessary; a button does not become a textbox.
    if fingerprint.get("role"):
        signals["accessibility_match"] = 1.0 if element.role == fingerprint["role"] else 0.0

    # A renamed test id often keeps a token ("promo-code" -> "discount-code").
    if fingerprint.get("test_id") and element.test_id:
        signals["dom_similarity"] = _overlap(
            _tokens(element.test_id), _tokens(fingerprint["test_id"])
        )
    elif fingerprint.get("tag"):
        signals["dom_similarity"] = 1.0 if element.tag == fingerprint["tag"] else 0.0

    return signals


def candidates_from_dom(
    html: str,
    fingerprint: dict[str, Any],
    *,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """Rank the page's elements against the fingerprint and return locators.

    An empty list is a real answer: the element is not on this page, and healing
    should say so rather than invent a selector.
    """
    elements, labels = parse_page(html)
    wanted_role = fingerprint.get("role")

    scored: list[tuple[float, Element, dict[str, float]]] = []
    for element in elements:
        if element.tag not in INTERACTIVE and element.tag not in READABLE:
            continue
        if not element.accessible_name(labels) and not element.test_id:
            continue
        # A different role is a different control, not a weaker match.
        if wanted_role and element.role and element.role != wanted_role:
            continue
        signals = score_against(element, fingerprint, labels)
        if not signals:
            continue

        # Sharing a role is not evidence of being the same element -- every
        # button on the page shares it. Something about this element's identity
        # has to match: its name, or a trace of the old test id. Without that,
        # the element we are looking for is simply not here, and proposing the
        # nearest button would be worse than proposing nothing.
        identity = max(signals.get("text_similarity", 0.0), signals.get("dom_similarity", 0.0))
        if identity <= 0:
            continue

        # A flat mean here; the weighted blend belongs to HealingConfig, which
        # owns what each signal is worth.
        blended = sum(signals.values()) / len(signals)
        if blended <= 0:
            continue
        scored.append((blended, element, signals))

    scored.sort(key=lambda row: row[0], reverse=True)

    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    for blended, element, signals in scored:
        for strategy, expression, robustness in locator_expressions(element, labels):
            if expression in seen:
                continue
            seen.add(expression)
            candidates.append(
                _candidate(element, labels, strategy, expression, robustness, blended, signals)
            )
            break  # one locator per element; the ladder already picked the best
        if len(candidates) >= limit:
            break
    return candidates


def candidates_by_strategy(
    html: str,
    fingerprint: dict[str, Any],
    *,
    strategies: tuple[str, ...] | None = None,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """Every way to address the matching elements, filtered to some strategies.

    `candidates_from_dom` returns the single best locator per element, which is
    what a caller wants when it just needs an answer. The healing ladder needs
    something different: to ask "is there a *test id* candidate?", then "is there
    a *role* candidate?", in a fixed order. This answers that question.
    """
    elements, labels = parse_page(html)
    wanted_role = fingerprint.get("role")
    wanted = set(strategies) if strategies else None

    rows: list[dict[str, Any]] = []
    for element in elements:
        if element.tag not in INTERACTIVE and element.tag not in READABLE:
            continue
        if not element.accessible_name(labels) and not element.test_id:
            continue
        if wanted_role and element.role and element.role != wanted_role:
            continue
        signals = score_against(element, fingerprint, labels)
        if not signals:
            continue
        identity = max(signals.get("text_similarity", 0.0), signals.get("dom_similarity", 0.0))
        if identity <= 0:
            continue
        blended = sum(signals.values()) / len(signals)
        if blended <= 0:
            continue

        for strategy, expression, robustness in locator_expressions(element, labels):
            if wanted is not None and strategy not in wanted:
                continue
            rows.append(
                _candidate(element, labels, strategy, expression, robustness, blended, signals)
            )

    rows.sort(key=lambda row: row["confidence"], reverse=True)
    return rows[:limit]


def expression_resolves(html: str, expression: str) -> bool:
    """Would this locator find something on this page?

    Used to check a remembered heal against the page as it is now. A repair that
    worked last month is not evidence about a page that has moved on again, and
    proposing a locator we can see is absent would waste a re-run and a
    reviewer's attention.
    """
    if not html or not expression:
        return False
    elements, labels = parse_page(html)
    for element in elements:
        for _strategy, candidate, _robustness in locator_expressions(element, labels):
            if candidate == expression:
                return True
    return False


def _candidate(
    element: Element,
    labels: dict[str, str],
    strategy: str,
    expression: str,
    robustness: float,
    blended: float,
    signals: dict[str, float],
) -> dict[str, Any]:
    return {
        "strategy": strategy,
        "locator": expression,
        # Robustness of the strategy, tempered by how well this element matches
        # what we were looking for.
        "confidence": round(robustness * (0.5 + 0.5 * blended), 4),
        "match_score": round(blended, 4),
        "signals": {key: round(value, 4) for key, value in signals.items()},
        "rationale": (
            f"{strategy.replace('_', ' ')} on the <{element.tag}> "
            f"{element.role or 'element'} named "
            f"'{element.accessible_name(labels) or element.test_id}', "
            f"found in the page captured when the test failed."
        ),
    }
