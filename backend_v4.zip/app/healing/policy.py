"""What a heal is allowed to change, decided before anything is applied.

This module is the guard rail the rest of the platform leans on. It answers one
question -- *may this change be made, and by whom* -- from the change type, the
confidence and the ambiguity of the evidence. It is deliberately independent of
the LLM, the agent and the API: no model output can talk its way past it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Final

from app.healing.config import HealingConfig, healing_config


class ChangeType:
    """The kinds of change healing can be asked to make."""

    LOCATOR: Final = "locator"
    TIMING: Final = "timing"
    NAVIGATION: Final = "navigation"
    TEST_DATA: Final = "test_data"
    API_CONTRACT: Final = "api_contract"
    ASSERTION: Final = "assertion"
    BUSINESS_RULE: Final = "business_rule"
    TEST_LOGIC: Final = "test_logic"


# Which failure classes map to which change type. A failure class with no entry
# is not healable -- an application defect is fixed by developers, not by us.
FAILURE_CLASS_CHANGE_TYPE: dict[str, str] = {
    "locator_drift": ChangeType.LOCATOR,
    "element_not_found": ChangeType.LOCATOR,
    "timing": ChangeType.TIMING,
    "timeout": ChangeType.TIMING,
    "synchronisation": ChangeType.TIMING,
    "navigation": ChangeType.NAVIGATION,
    "test_data": ChangeType.TEST_DATA,
    "api_contract": ChangeType.API_CONTRACT,
}


@dataclass(slots=True)
class HealingGate:
    """The decision: may this heal proceed, and on whose authority."""

    change_type: str
    policy: str  # auto | approval | forbidden
    allowed: bool
    requires_approval: bool
    confidence: float
    reasons: list[str] = field(default_factory=list)

    @property
    def decision(self) -> str:
        if not self.allowed:
            return "blocked"
        return "human_review" if self.requires_approval else "auto_apply"

    def to_dict(self) -> dict[str, object]:
        """Shape persisted on `HealingRecord.policy_decision` and written to audit."""
        return {
            "change_type": self.change_type,
            "policy": self.policy,
            "decision": self.decision,
            "allowed": self.allowed,
            "requires_approval": self.requires_approval,
            "confidence": self.confidence,
            "reasons": self.reasons,
        }


def change_type_for(failure_class: str) -> str | None:
    """The change type a failure class would require, or None if not healable."""
    return FAILURE_CLASS_CHANGE_TYPE.get(failure_class)


def evaluate_change(
    *,
    change_type: str,
    confidence: float,
    runner_up_confidence: float = 0.0,
    config: HealingConfig | None = None,
) -> HealingGate:
    """Apply the change-policy matrix, the confidence gate and the ambiguity rule.

    The three can only ever make the outcome stricter, never looser.
    """
    config = config or healing_config()
    policy = config.policy_for(change_type)
    gate = HealingGate(
        change_type=change_type,
        policy=policy,
        allowed=True,
        requires_approval=False,
        confidence=round(confidence, 4),
    )

    if not config.enabled:
        gate.allowed = False
        gate.reasons.append("Self-healing is disabled for this deployment.")
        return gate

    if policy == "forbidden":
        gate.allowed = False
        gate.reasons.append(
            f"Healing may never change '{change_type}'. A test that fails on a business "
            "assertion is reporting a real defect, and must stay failed."
        )
        return gate

    if confidence < config.propose_threshold:
        gate.allowed = False
        gate.reasons.append(
            f"Confidence {confidence:.0%} is below the {config.propose_threshold:.0%} floor "
            "for proposing a change."
        )
        return gate

    if policy == "approval":
        gate.requires_approval = True
        gate.reasons.append(f"Policy requires a named approver for '{change_type}' changes.")

    if confidence < config.auto_apply_threshold:
        gate.requires_approval = True
        gate.reasons.append(
            f"Confidence {confidence:.0%} is below the {config.auto_apply_threshold:.0%} "
            "auto-apply threshold."
        )

    margin = round(confidence - runner_up_confidence, 4)
    if runner_up_confidence and margin < config.ambiguity_margin:
        gate.requires_approval = True
        gate.reasons.append(
            f"Only {margin:.0%} separates the top two candidates, below the "
            f"{config.ambiguity_margin:.0%} margin, so the element is ambiguous."
        )

    if not gate.requires_approval:
        gate.reasons.append(
            f"Confidence {confidence:.0%} clears the auto-apply threshold with an "
            f"unambiguous winner; still subject to re-run validation."
        )
    return gate
