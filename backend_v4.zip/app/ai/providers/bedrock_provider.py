"""AWS Bedrock provider.

Uses Bedrock's **Converse** API rather than per-model `invoke_model` payloads.
That matters: `invoke_model` requires a different request body for every model
family (Anthropic, Meta, Mistral, Amazon all differ), which would put
vendor-shaped branching inside the provider. Converse presents one shape across
families, so switching the configured model is configuration here too, not code.

Credentials are never read from settings. boto3 resolves them through the
standard AWS chain -- environment, shared config, SSO, or the instance/task role
-- so a deployment uses whatever its platform team already runs, and no AWS
secret is ever stored in this application's configuration or database.
"""

from __future__ import annotations

import json
import time
from typing import Any

from app.ai.providers.base import (
    ChatMessage,
    EmbeddingResponse,
    LLMProvider,
    LLMResponse,
    ModelSelection,
    TokenUsage,
)
from app.core.config import settings
from app.core.errors import ProviderError
from app.core.logging import get_logger

logger = get_logger(__name__)

# Bedrock rejects a conversation that does not alternate user/assistant, and it
# takes the system prompt out of band rather than as a message.
_ROLE_MAP = {"user": "user", "assistant": "assistant", "tool": "user"}


def _load_boto3():  # noqa: ANN202
    try:
        import boto3  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover - exercised only without the SDK
        raise ProviderError(
            "The 'boto3' package is required for the AWS Bedrock provider. "
            "Install backend requirements or set DEFAULT_LLM_PROVIDER=mock.",
            details={"missing_dependency": "boto3"},
        ) from exc
    return boto3


class BedrockProvider(LLMProvider):
    """Amazon Bedrock, through the Converse API."""

    key = "bedrock"
    display_name = "AWS Bedrock"

    _client_cache: Any = None
    _embedding_client_cache: Any = None

    # ------------------------------------------------------------------
    def is_configured(self) -> bool:
        """A region is the only thing this application must supply.

        Everything else -- keys, tokens, role assumption -- is AWS's own
        credential chain, which is why there is nothing here to leak.
        """
        if not settings.bedrock_region:
            return False
        try:
            _load_boto3()
        except ProviderError:
            return False
        return True

    def _client(self):  # noqa: ANN202
        if BedrockProvider._client_cache is None:
            boto3 = _load_boto3()
            session_kwargs: dict[str, Any] = {"region_name": settings.bedrock_region}
            if settings.bedrock_profile:
                session_kwargs["profile_name"] = settings.bedrock_profile
            session = boto3.Session(**session_kwargs)
            BedrockProvider._client_cache = session.client(
                "bedrock-runtime",
                endpoint_url=settings.bedrock_endpoint_url or None,
            )
        return BedrockProvider._client_cache

    def _target(self, selection: ModelSelection) -> str:
        """The Bedrock model id or inference-profile ARN to call.

        `deployment` carries it when a routing policy pins one, exactly as it
        carries the deployment name for Azure. Otherwise the model key is used
        directly, so a catalogue entry can name a Bedrock id as-is.
        """
        return selection.deployment or selection.model

    # ------------------------------------------------------------------
    @staticmethod
    def _split_messages(messages: list[ChatMessage]) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
        """Bedrock takes the system prompt separately and wants alternating turns."""
        system: list[dict[str, str]] = []
        turns: list[dict[str, Any]] = []

        for message in messages:
            if message.role == "system":
                system.append({"text": message.content})
                continue
            role = _ROLE_MAP.get(message.role, "user")
            # Consecutive same-role turns are merged rather than rejected: the
            # caller should not have to know Bedrock's alternation rule.
            if turns and turns[-1]["role"] == role:
                turns[-1]["content"].append({"text": message.content})
            else:
                turns.append({"role": role, "content": [{"text": message.content}]})

        if not turns:
            turns = [{"role": "user", "content": [{"text": ""}]}]
        return turns, system

    def chat(
        self,
        messages: list[ChatMessage],
        selection: ModelSelection,
        *,
        response_schema: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        timeout: int | None = None,  # noqa: ARG002 - boto3 timeouts are client-level
        deterministic_draft: dict[str, Any] | None = None,  # noqa: ARG002 - real provider answers
    ) -> LLMResponse:
        client = self._client()
        turns, system = self._split_messages(messages)

        if response_schema:
            # Bedrock has no universal JSON mode across families. Asking for
            # JSON in the system prompt is the portable instruction; the agent's
            # own parser still validates what comes back, so a model that
            # ignores it fails the same way it would on any provider.
            system.append(
                {"text": "Respond with a single valid JSON object and no other text."}
            )

        request: dict[str, Any] = {
            "modelId": self._target(selection),
            "messages": turns,
            "inferenceConfig": {
                "temperature": selection.temperature,
                "maxTokens": selection.max_tokens,
            },
        }
        if system:
            request["system"] = system
        if tools:
            request["toolConfig"] = {"tools": tools}

        started = time.perf_counter()
        try:
            response = client.converse(**request)
        except Exception as exc:  # noqa: BLE001 - normalised into a domain error
            logger.error(
                "llm_call_failed", provider=self.key, model=selection.model, error=str(exc)
            )
            raise ProviderError(
                f"{self.display_name} request failed: {exc}",
                details={"provider": self.key, "model": self._target(selection)},
            ) from exc

        latency_ms = int((time.perf_counter() - started) * 1000)
        content = _text_of(response)

        structured: dict[str, Any] | None = None
        if response_schema and content:
            structured = _parse_json(content, provider=self.key, model=selection.model)

        usage = response.get("usage", {}) or {}
        return LLMResponse(
            content=content,
            selection=selection,
            usage=TokenUsage(
                prompt_tokens=int(usage.get("inputTokens", 0) or 0),
                completion_tokens=int(usage.get("outputTokens", 0) or 0),
            ),
            latency_ms=latency_ms,
            finish_reason=response.get("stopReason", "stop") or "stop",
            structured=structured,
            raw={"provider": self.key, "model_id": self._target(selection)},
        )

    # ------------------------------------------------------------------
    def embed(self, texts: list[str], selection: ModelSelection) -> EmbeddingResponse:
        """Embeddings still go through `invoke_model`; Converse is chat-only.

        Titan and Cohere differ in both request and response shape, so the two
        are handled explicitly rather than guessed at.
        """
        client = self._client()
        model_id = settings.bedrock_embedding_model or self._target(selection)
        started = time.perf_counter()
        vectors: list[list[float]] = []

        try:
            if "cohere" in model_id.lower():
                # Cohere embeds a batch in one call.
                payload = json.dumps({"texts": texts, "input_type": "search_document"})
                raw = client.invoke_model(modelId=model_id, body=payload)
                body = json.loads(raw["body"].read())
                vectors = body.get("embeddings", [])
            else:
                # Titan takes one text per call.
                for text in texts:
                    payload = json.dumps({"inputText": text})
                    raw = client.invoke_model(modelId=model_id, body=payload)
                    body = json.loads(raw["body"].read())
                    vectors.append(body.get("embedding", []))
        except Exception as exc:  # noqa: BLE001
            raise ProviderError(
                f"{self.display_name} embedding request failed: {exc}",
                details={"provider": self.key, "model": model_id},
            ) from exc

        return EmbeddingResponse(
            vectors=vectors,
            model=model_id,
            provider=self.key,
            deployment=selection.deployment,
            usage=TokenUsage(prompt_tokens=sum(len(text.split()) for text in texts)),
            latency_ms=int((time.perf_counter() - started) * 1000),
        )

    # ------------------------------------------------------------------
    def health_check(self) -> dict[str, Any]:
        """Connectivity, without ever returning a credential.

        Reports the region and model ids, which are configuration rather than
        secrets, and says how credentials were resolved without naming them.
        """
        report: dict[str, Any] = {
            "provider": self.key,
            "configured": self.is_configured(),
            "region": settings.bedrock_region,
            "chat_model": settings.bedrock_chat_model,
            "reasoning_model": settings.bedrock_reasoning_model,
            "embedding_model": settings.bedrock_embedding_model,
            "profile": settings.bedrock_profile or "default credential chain",
        }
        if not report["configured"]:
            report["status"] = "not_configured"
            report["detail"] = (
                "Set BEDROCK_REGION and install boto3 to enable AWS Bedrock."
                if settings.bedrock_region
                else "BEDROCK_REGION is not set."
            )
            return report

        try:
            client = self._client()
            # A cheap call that proves credentials and region resolve without
            # spending tokens on an inference request.
            client.meta.client.meta.region_name  # noqa: B018 - attribute probe
            report["status"] = "ready"
        except Exception as exc:  # noqa: BLE001
            report["status"] = "error"
            report["detail"] = str(exc)[:300]
        return report


# ---------------------------------------------------------------------------


def _text_of(response: dict[str, Any]) -> str:
    """Join the text blocks of a Converse response."""
    message = (response.get("output") or {}).get("message") or {}
    blocks = message.get("content") or []
    return "".join(block.get("text", "") for block in blocks if isinstance(block, dict))


def _parse_json(content: str, *, provider: str, model: str) -> dict[str, Any] | None:
    """Read a JSON object out of a reply, tolerating a fenced block.

    Models that have not been given a JSON mode often wrap the object in
    markdown. Recovering from that is fair; inventing a result when the reply
    is not JSON at all is not, so this returns None and lets the agent's own
    validation report it.
    """
    text = content.strip()
    if text.startswith("```"):
        text = text.split("```")[1] if "```" in text[3:] else text.lstrip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        logger.warning("llm_json_parse_failed", provider=provider, model=model)
        return None
    return parsed if isinstance(parsed, dict) else {"result": parsed}
