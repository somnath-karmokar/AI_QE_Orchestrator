"""Provider registry and the built-in model catalogue.

The catalogue is the seed for `llm_providers` / `llm_models` / `llm_deployments`
and the source of the pricing used by the cost recorder.
"""

from __future__ import annotations

from typing import Any

from app.ai.providers.base import LLMProvider
from app.ai.providers.bedrock_provider import BedrockProvider
from app.ai.providers.mock import MockLLMProvider
from app.ai.providers.openai_provider import AzureOpenAIProvider, OpenAIProvider
from app.core.config import settings
from app.core.logging import get_logger
from app.core.mode import forbid_stand_in

logger = get_logger(__name__)

_PROVIDER_CLASSES: dict[str, type[LLMProvider]] = {
    MockLLMProvider.key: MockLLMProvider,
    AzureOpenAIProvider.key: AzureOpenAIProvider,
    OpenAIProvider.key: OpenAIProvider,
    BedrockProvider.key: BedrockProvider,
}

_INSTANCES: dict[str, LLMProvider] = {}


def get_provider(key: str) -> LLMProvider:
    """Return a cached provider instance, falling back to mock when unconfigured."""
    provider_class = _PROVIDER_CLASSES.get(key)
    if provider_class is None:
        logger.warning("unknown_provider_requested", provider=key)
        provider_class = MockLLMProvider
        key = MockLLMProvider.key

    if key not in _INSTANCES:
        _INSTANCES[key] = provider_class()

    provider = _INSTANCES[key]
    if not provider.is_configured():
        # In production this raises rather than quietly answering with the demo
        # model, which would look like a working platform giving poor answers.
        forbid_stand_in(
            f"the {provider.display_name} provider",
            "It is selected but not configured, so calls would use the demo model.",
            "Configure it, or set APP_MODE=local. See docs/llm-providers.md.",
        )
        logger.warning("provider_not_configured_falling_back", provider=key, fallback="mock")
        return get_provider(MockLLMProvider.key)
    return provider


def default_provider_key() -> str:
    return settings.default_llm_provider


def available_providers() -> list[LLMProvider]:
    return [get_provider(key) for key in _PROVIDER_CLASSES]


def provider_health() -> list[dict[str, Any]]:
    """Health for every provider class, never exposing secret values."""
    report: list[dict[str, Any]] = []
    for key, provider_class in _PROVIDER_CLASSES.items():
        instance = _INSTANCES.setdefault(key, provider_class())
        try:
            health = instance.health_check()
        except Exception as exc:  # noqa: BLE001
            health = {"provider": key, "status": "error", "configured": False, "detail": str(exc)[:300]}
        health["is_default"] = key == settings.default_llm_provider
        health["display_name"] = provider_class.display_name
        report.append(health)
    return report


# ---------------------------------------------------------------------------
# Built-in model catalogue
# ---------------------------------------------------------------------------
# `model_key` is the logical identifier agents and routing policies reference.
# `deployment` is the Azure deployment name, which is deliberately kept distinct
# from the model name (spec section 3).

MODEL_CATALOG: list[dict[str, Any]] = [
    # ---- Mock / demo -------------------------------------------------------
    {
        "provider": "mock",
        "model_key": "qe-demo-light",
        "display_name": "Demo Light",
        "family": "demo",
        "tier": "light",
        "capabilities": ["classification", "structured_extraction"],
        "context_window": 32000,
        "max_output_tokens": 2048,
        "input_cost_per_1k": 0.00015,
        "output_cost_per_1k": 0.0006,
        "deployment": None,
    },
    {
        "provider": "mock",
        "model_key": "qe-demo-standard",
        "display_name": "Demo Standard",
        "family": "demo",
        "tier": "standard",
        "capabilities": ["generation", "structured_extraction", "classification"],
        "context_window": 128000,
        "max_output_tokens": 4096,
        "input_cost_per_1k": 0.0025,
        "output_cost_per_1k": 0.01,
        "deployment": None,
    },
    {
        "provider": "mock",
        "model_key": "qe-demo-reasoning",
        "display_name": "Demo Reasoning",
        "family": "demo",
        "tier": "premium",
        "capabilities": ["reasoning", "generation"],
        "context_window": 128000,
        "max_output_tokens": 8192,
        "input_cost_per_1k": 0.005,
        "output_cost_per_1k": 0.015,
        "deployment": None,
    },
    {
        "provider": "mock",
        "model_key": "qe-demo-embedding",
        "display_name": "Demo Embedding",
        "family": "demo",
        "tier": "light",
        "capabilities": ["embedding"],
        "context_window": 8191,
        "max_output_tokens": 0,
        "input_cost_per_1k": 0.00002,
        "output_cost_per_1k": 0.0,
        "deployment": None,
    },
    # ---- Azure OpenAI ------------------------------------------------------
    {
        "provider": "azure_openai",
        "model_key": "gpt-4o-mini",
        "display_name": "GPT-4o mini (Azure)",
        "family": "gpt-4o",
        "tier": "light",
        "capabilities": ["classification", "structured_extraction", "generation"],
        "context_window": 128000,
        "max_output_tokens": 16384,
        "input_cost_per_1k": 0.00015,
        "output_cost_per_1k": 0.0006,
        "deployment": settings.azure_openai_chat_deployment or "qe-gpt-4o-mini",
    },
    {
        "provider": "azure_openai",
        "model_key": "gpt-4o",
        "display_name": "GPT-4o (Azure)",
        "family": "gpt-4o",
        "tier": "standard",
        "capabilities": ["generation", "structured_extraction", "reasoning"],
        "context_window": 128000,
        "max_output_tokens": 16384,
        "input_cost_per_1k": 0.0025,
        "output_cost_per_1k": 0.01,
        "deployment": settings.azure_openai_chat_deployment or "qe-gpt-4o",
    },
    {
        "provider": "azure_openai",
        "model_key": "gpt-4.1",
        "display_name": "GPT-4.1 (Azure)",
        "family": "gpt-4.1",
        "tier": "premium",
        "capabilities": ["reasoning", "generation", "structured_extraction"],
        "context_window": 200000,
        "max_output_tokens": 32768,
        "input_cost_per_1k": 0.005,
        "output_cost_per_1k": 0.015,
        "deployment": settings.azure_openai_reasoning_deployment or "qe-gpt-41",
    },
    {
        "provider": "azure_openai",
        "model_key": "text-embedding-3-small",
        "display_name": "Text Embedding 3 Small (Azure)",
        "family": "embedding",
        "tier": "light",
        "capabilities": ["embedding"],
        "context_window": 8191,
        "max_output_tokens": 0,
        "input_cost_per_1k": 0.00002,
        "output_cost_per_1k": 0.0,
        "deployment": settings.azure_openai_embedding_deployment or "qe-embedding-3-small",
    },
    # ---- OpenAI ------------------------------------------------------------
    {
        "provider": "openai",
        "model_key": "gpt-4o-mini",
        "display_name": "GPT-4o mini",
        "family": "gpt-4o",
        "tier": "light",
        "capabilities": ["classification", "structured_extraction", "generation"],
        "context_window": 128000,
        "max_output_tokens": 16384,
        "input_cost_per_1k": 0.00015,
        "output_cost_per_1k": 0.0006,
        "deployment": None,
    },
    {
        "provider": "openai",
        "model_key": "gpt-4o",
        "display_name": "GPT-4o",
        "family": "gpt-4o",
        "tier": "standard",
        "capabilities": ["generation", "structured_extraction", "reasoning"],
        "context_window": 128000,
        "max_output_tokens": 16384,
        "input_cost_per_1k": 0.0025,
        "output_cost_per_1k": 0.01,
        "deployment": None,
    },
    {
        "provider": "openai",
        "model_key": "text-embedding-3-small",
        "display_name": "Text Embedding 3 Small",
        "family": "embedding",
        "tier": "light",
        "capabilities": ["embedding"],
        "context_window": 8191,
        "max_output_tokens": 0,
        "input_cost_per_1k": 0.00002,
        "output_cost_per_1k": 0.0,
        "deployment": None,
    },
]

PROVIDER_METADATA: dict[str, dict[str, Any]] = {
    "mock": {
        "name": "Deterministic Demo Provider",
        "description": "Offline provider producing reproducible results for demonstrations.",
    },
    "azure_openai": {
        "name": "Azure OpenAI",
        "description": "Primary enterprise LLM provider with deployment-based model addressing.",
    },
    "openai": {
        "name": "OpenAI",
        "description": "Direct OpenAI API provider.",
    },
    "bedrock": {
        "name": "AWS Bedrock",
        "description": "Models hosted in your own AWS account, addressed by model id or inference profile.",
    },
}


# Bedrock model ids are account- and region-specific, and an inference profile
# ARN is equally valid, so there is no fixed catalogue to ship. Entries are
# built from configuration when a deployment has set one -- which also means an
# unconfigured install advertises no Bedrock models rather than models it cannot
# actually call.
_BEDROCK_SLOTS: tuple[tuple[str, str, str, list[str], str], ...] = (
    ("bedrock_chat_model", "Bedrock chat", "standard",
     ["generation", "structured_extraction", "classification"], "chat"),
    ("bedrock_reasoning_model", "Bedrock reasoning", "premium",
     ["reasoning", "generation", "structured_extraction"], "reasoning"),
    ("bedrock_embedding_model", "Bedrock embedding", "light", ["embedding"], "embedding"),
)


def bedrock_catalog() -> list[dict[str, Any]]:
    """Catalogue entries for whatever Bedrock models this deployment configured.

    Pricing is left at zero rather than guessed: Bedrock rates vary by model,
    region and commitment, and a wrong number in a cost report is worse than an
    absent one. A deployment that wants cost tracking sets the rates against
    its own contract in `llm_models`.
    """
    entries: list[dict[str, Any]] = []
    for setting_name, display, tier, capabilities, family in _BEDROCK_SLOTS:
        model_id = getattr(settings, setting_name, None)
        if not model_id:
            continue
        entries.append(
            {
                "provider": "bedrock",
                "model_key": model_id,
                "display_name": f"{display} ({model_id.split('.')[-1][:28]})",
                "family": family,
                "tier": tier,
                "capabilities": capabilities,
                "context_window": 200000,
                "max_output_tokens": 8192,
                "input_cost_per_1k": 0.0,
                "output_cost_per_1k": 0.0,
                "deployment": model_id,
                "pricing_note": "Set against your own AWS rates; not shipped as a guess.",
            }
        )
    return entries


def full_catalog() -> list[dict[str, Any]]:
    """The shipped catalogue plus whatever Bedrock models are configured."""
    return [*MODEL_CATALOG, *bedrock_catalog()]


def catalog_for_provider(provider_key: str) -> list[dict[str, Any]]:
    return [entry for entry in full_catalog() if entry["provider"] == provider_key]


def find_model(provider_key: str, model_key: str) -> dict[str, Any] | None:
    for entry in full_catalog():
        if entry["provider"] == provider_key and entry["model_key"] == model_key:
            return entry
    return None
