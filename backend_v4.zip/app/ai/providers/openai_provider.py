"""Azure OpenAI and OpenAI providers.

Both wrap the same `openai` SDK, differing only in client construction and in
whether a request targets a *deployment* (Azure) or a *model* (OpenAI). The SDK
is imported lazily so the platform boots in demo mode without it installed.
"""

from __future__ import annotations

import json
import time
from typing import Any

from app.ai.providers.base import (
    ChatMessage,
    EmbeddingResponse,
    LLMProvider,
    LLMResponse,
    ModelSelection,
    TokenUsage,
)
from app.core.config import settings
from app.core.errors import ProviderError
from app.core.logging import get_logger

logger = get_logger(__name__)


def _load_openai_module():  # noqa: ANN202
    try:
        import openai  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover - exercised only without the SDK
        raise ProviderError(
            "The 'openai' package is required for Azure OpenAI / OpenAI providers. "
            "Install backend requirements or set DEFAULT_LLM_PROVIDER=mock.",
            details={"missing_dependency": "openai"},
        ) from exc
    return openai


class _BaseOpenAIProvider(LLMProvider):
    """Shared request/response translation for the two OpenAI-compatible providers."""

    def _client(self):  # noqa: ANN202
        raise NotImplementedError

    def _target(self, selection: ModelSelection) -> str:
        """Azure sends the deployment name where OpenAI sends the model name."""
        raise NotImplementedError

    def chat(
        self,
        messages: list[ChatMessage],
        selection: ModelSelection,
        *,
        response_schema: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        timeout: int | None = None,
        deterministic_draft: dict[str, Any] | None = None,
    ) -> LLMResponse:
        client = self._client()
        started = time.perf_counter()

        request: dict[str, Any] = {
            "model": self._target(selection),
            "messages": [message.to_api() for message in messages],
            "temperature": selection.temperature,
            "max_tokens": selection.max_tokens,
            "timeout": timeout or settings.llm_request_timeout_seconds,
        }
        if response_schema:
            # json_object mode is supported across both providers; the agent's
            # prompt carries the schema and its parser validates the result.
            request["response_format"] = {"type": "json_object"}
        if tools:
            request["tools"] = tools

        try:
            completion = client.chat.completions.create(**request)
        except Exception as exc:  # noqa: BLE001 - normalised into a domain error
            logger.error("llm_call_failed", provider=self.key, model=selection.model, error=str(exc))
            raise ProviderError(
                f"{self.display_name} request failed: {exc}",
                details={"provider": self.key, "model": selection.model},
            ) from exc

        latency_ms = int((time.perf_counter() - started) * 1000)
        choice = completion.choices[0]
        content = choice.message.content or ""

        structured: dict[str, Any] | None = None
        if response_schema and content:
            try:
                parsed = json.loads(content)
                structured = parsed if isinstance(parsed, dict) else {"result": parsed}
            except json.JSONDecodeError:
                logger.warning("llm_json_parse_failed", provider=self.key, model=selection.model)

        usage = getattr(completion, "usage", None)
        return LLMResponse(
            content=content,
            selection=selection,
            usage=TokenUsage(
                prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
            ),
            latency_ms=latency_ms,
            finish_reason=choice.finish_reason or "stop",
            structured=structured,
            raw={"provider": self.key, "id": getattr(completion, "id", None)},
        )

    def embed(self, texts: list[str], selection: ModelSelection) -> EmbeddingResponse:
        client = self._client()
        started = time.perf_counter()
        try:
            result = client.embeddings.create(model=self._target(selection), input=texts)
        except Exception as exc:  # noqa: BLE001
            raise ProviderError(
                f"{self.display_name} embedding request failed: {exc}",
                details={"provider": self.key, "model": selection.model},
            ) from exc

        usage = getattr(result, "usage", None)
        return EmbeddingResponse(
            vectors=[item.embedding for item in result.data],
            model=selection.model,
            provider=self.key,
            deployment=selection.deployment,
            usage=TokenUsage(prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0),
            latency_ms=int((time.perf_counter() - started) * 1000),
        )


class AzureOpenAIProvider(_BaseOpenAIProvider):
    """Primary enterprise deployment target."""

    key = "azure_openai"
    display_name = "Azure OpenAI"

    def __init__(self) -> None:
        self._cached_client = None

    def is_configured(self) -> bool:
        return bool(settings.azure_openai_endpoint and settings.azure_openai_api_key)

    def _client(self):  # noqa: ANN202
        if self._cached_client is not None:
            return self._cached_client
        if not self.is_configured():
            raise ProviderError(
                "Azure OpenAI is not configured. Set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY.",
                details={"provider": self.key},
            )
        openai = _load_openai_module()
        self._cached_client = openai.AzureOpenAI(
            azure_endpoint=settings.azure_openai_endpoint,
            api_key=settings.azure_openai_api_key,
            api_version=settings.azure_openai_api_version,
            max_retries=settings.llm_max_retries,
        )
        return self._cached_client

    def _target(self, selection: ModelSelection) -> str:
        """Azure addresses a deployment; fall back to capability defaults from env."""
        if selection.deployment:
            return selection.deployment
        defaults = {
            "reasoning": settings.azure_openai_reasoning_deployment,
            "embedding": settings.azure_openai_embedding_deployment,
        }
        deployment = defaults.get(selection.capability) or settings.azure_openai_chat_deployment
        if not deployment:
            raise ProviderError(
                f"No Azure deployment configured for capability '{selection.capability}'.",
                details={"provider": self.key, "capability": selection.capability},
            )
        return deployment

    def health_check(self) -> dict[str, Any]:
        if not self.is_configured():
            return {
                "provider": self.key,
                "status": "not_configured",
                "configured": False,
                "detail": "AZURE_OPENAI_ENDPOINT / AZURE_OPENAI_API_KEY are not set.",
                "endpoint": settings.azure_openai_endpoint,
            }
        try:
            client = self._client()
            client.models.list()
            status, detail = "connected", "Azure OpenAI endpoint reachable."
        except Exception as exc:  # noqa: BLE001
            status, detail = "error", str(exc)[:300]
        return {
            "provider": self.key,
            "status": status,
            "configured": True,
            "detail": detail,
            "endpoint": settings.azure_openai_endpoint,
            "api_version": settings.azure_openai_api_version,
            "deployments": {
                "chat": settings.azure_openai_chat_deployment,
                "reasoning": settings.azure_openai_reasoning_deployment,
                "embedding": settings.azure_openai_embedding_deployment,
            },
        }


class OpenAIProvider(_BaseOpenAIProvider):
    """Direct OpenAI API provider."""

    key = "openai"
    display_name = "OpenAI"

    def __init__(self) -> None:
        self._cached_client = None

    def is_configured(self) -> bool:
        return bool(settings.openai_api_key)

    def _client(self):  # noqa: ANN202
        if self._cached_client is not None:
            return self._cached_client
        if not self.is_configured():
            raise ProviderError(
                "OpenAI is not configured. Set OPENAI_API_KEY.", details={"provider": self.key}
            )
        openai = _load_openai_module()
        self._cached_client = openai.OpenAI(
            api_key=settings.openai_api_key,
            organization=settings.openai_org_id or None,
            max_retries=settings.llm_max_retries,
        )
        return self._cached_client

    def _target(self, selection: ModelSelection) -> str:
        return selection.model

    def health_check(self) -> dict[str, Any]:
        if not self.is_configured():
            return {
                "provider": self.key,
                "status": "not_configured",
                "configured": False,
                "detail": "OPENAI_API_KEY is not set.",
            }
        try:
            self._client().models.list()
            status, detail = "connected", "OpenAI API reachable."
        except Exception as exc:  # noqa: BLE001
            status, detail = "error", str(exc)[:300]
        return {
            "provider": self.key,
            "status": status,
            "configured": True,
            "detail": detail,
            "models": {
                "chat": settings.openai_chat_model,
                "reasoning": settings.openai_reasoning_model,
                "embedding": settings.openai_embedding_model,
            },
        }
