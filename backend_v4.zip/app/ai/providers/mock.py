"""Deterministic mock provider used when DEMO_MODE=true (spec sections 3 and 38).

Design note -- how this stays honest:

Agents build a real prompt and a real JSON output schema, exactly as they would
for Azure OpenAI. Alongside them they pass a `deterministic_draft`: a payload
the agent derived from actual application state (seeded requirements, execution
history, retrieved knowledge chunks). The mock provider returns that draft as
the completion, with plausible token accounting and latency.

The consequence is that swapping in a real provider changes *who writes the
JSON*, not the contract, the parsing, the persistence or the UI. Agents never
branch on provider, and nothing in the demo path bypasses the router, the cost
recorder or the governance checks.
"""

from __future__ import annotations

import hashlib
import json
import math
import random
import time
from typing import Any

from app.ai.providers.base import (
    ChatMessage,
    EmbeddingResponse,
    LLMProvider,
    LLMResponse,
    ModelSelection,
    TokenUsage,
)
from app.core.config import settings


_PUNCTUATION = ".,;:!?()[]{}\"'`"

# Common English words carry no retrieval signal; including them makes every
# document look similar to every question.
_STOP_WORDS = frozenset(
    """
    a an the and or but if then else of in on at to for from by with without
    is are was were be been being am do does did doing done have has had having
    i you he she it we they me him her us them my your his its our their this
    that these those there here what which who whom whose when where why how
    can could should would will shall may might must not no nor so than as
    about into over under again further once all any both each few more most
    other some such only own same too very just also does own
    """.split()
)


def stable_seed(*parts: object) -> int:
    """Deterministic integer seed derived from arbitrary inputs."""
    digest = hashlib.sha256("|".join(str(part) for part in parts).encode()).hexdigest()
    return int(digest[:16], 16)


def estimate_tokens(text: str) -> int:
    """Cheap token estimate (~4 characters per token) used for budgeting."""
    if not text:
        return 0
    return max(1, math.ceil(len(text) / 4))


class MockLLMProvider(LLMProvider):
    """Deterministic, offline provider with the same contract as the real ones."""

    key = "mock"
    display_name = "Deterministic Demo Model"

    def __init__(self, seed: int | None = None) -> None:
        self._base_seed = seed if seed is not None else settings.seed_random_state

    # ----- chat --------------------------------------------------------------
    def chat(
        self,
        messages: list[ChatMessage],
        selection: ModelSelection,
        *,
        response_schema: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        timeout: int | None = None,
        deterministic_draft: dict[str, Any] | None = None,
    ) -> LLMResponse:
        started = time.perf_counter()
        prompt_text = "\n".join(message.content for message in messages)
        rng = random.Random(stable_seed(self._base_seed, prompt_text[:2000], selection.model))

        if deterministic_draft is not None:
            payload = deterministic_draft
            content = json.dumps(payload, indent=2, default=str)
        elif response_schema:
            payload = self._synthesize_from_schema(response_schema, rng)
            content = json.dumps(payload, indent=2, default=str)
        else:
            payload = None
            content = self._synthesize_prose(prompt_text, rng)

        # Simulated latency keeps the live run timeline believable without
        # actually blocking for a realistic model round-trip.
        simulated_latency = rng.randint(180, 900)
        prompt_tokens = estimate_tokens(prompt_text)
        completion_tokens = estimate_tokens(content)
        elapsed_ms = int((time.perf_counter() - started) * 1000)

        return LLMResponse(
            content=content,
            selection=selection,
            usage=TokenUsage(prompt_tokens=prompt_tokens, completion_tokens=completion_tokens),
            latency_ms=max(elapsed_ms, simulated_latency),
            finish_reason="stop",
            structured=payload,
            raw={"provider": self.key, "simulated": True},
        )

    # ----- embeddings --------------------------------------------------------
    def embed(self, texts: list[str], selection: ModelSelection) -> EmbeddingResponse:
        """Hash-based embeddings: deterministic, offline, and stable across restarts.

        Not semantically trained, but similarity between near-identical texts is
        preserved well enough to demonstrate retrieval, duplicate detection and
        failure-signature matching. Real embeddings arrive by switching provider.
        """
        started = time.perf_counter()
        dimensions = settings.embedding_dimensions
        vectors: list[list[float]] = [self._hash_embedding(text, dimensions) for text in texts]
        prompt_tokens = sum(estimate_tokens(text) for text in texts)
        return EmbeddingResponse(
            vectors=vectors,
            model=selection.model,
            provider=self.key,
            deployment=selection.deployment,
            usage=TokenUsage(prompt_tokens=prompt_tokens),
            latency_ms=int((time.perf_counter() - started) * 1000),
        )

    @staticmethod
    def _hash_embedding(text: str, dimensions: int) -> list[float]:
        """Token-level hashing into a fixed-width vector, L2 normalised.

        Shared vocabulary between two texts lands in the same buckets, so cosine
        similarity behaves like a lexical-overlap score.

        Two refinements keep that score useful for retrieval:

        * stop words are dropped, so "what is the daily payment limit" is matched
          on *limit* and *daily* rather than on *what*, *is* and *the*;
        * each remaining token is weighted by inverse frequency within the text,
          so a term repeated throughout a long document does not swamp the
          distinctive terms that actually make a passage relevant.

        This is a demo-mode approximation. Switching to a real embedding provider
        replaces it entirely -- no calling code changes.
        """
        vector = [0.0] * dimensions
        raw = [token.strip(_PUNCTUATION) for token in text.lower().split()]
        tokens = [token for token in raw if token and token not in _STOP_WORDS and len(token) > 1]
        if not tokens:
            return vector

        counts: dict[str, int] = {}
        for token in tokens:
            counts[token] = counts.get(token, 0) + 1

        for token, count in counts.items():
            # Sub-linear term weighting: presence matters more than repetition.
            weight = 1.0 + math.log(count)
            digest = hashlib.md5(token.encode()).digest()  # noqa: S324 - not security relevant
            index = int.from_bytes(digest[:4], "big") % dimensions
            sign = 1.0 if digest[4] % 2 == 0 else -1.0
            vector[index] += sign * weight
            # A second bucket reduces collisions and sharpens similarity.
            index2 = int.from_bytes(digest[5:9], "big") % dimensions
            vector[index2] += sign * weight * 0.5

        norm = math.sqrt(sum(value * value for value in vector))
        if norm == 0:
            return vector
        return [value / norm for value in vector]

    # ----- health ------------------------------------------------------------
    def health_check(self) -> dict[str, Any]:
        return {
            "provider": self.key,
            "status": "connected",
            "configured": True,
            "detail": "Deterministic demo provider - no external credentials required.",
            "models": ["qe-demo-reasoning", "qe-demo-standard", "qe-demo-light", "qe-demo-embedding"],
        }

    # ----- synthesis helpers -------------------------------------------------
    def _synthesize_from_schema(self, schema: dict[str, Any], rng: random.Random) -> dict[str, Any]:
        """Produce a schema-shaped object when an agent supplied no draft."""
        return self._value_for(schema, rng, depth=0)

    def _value_for(self, schema: dict[str, Any], rng: random.Random, depth: int) -> Any:
        schema_type = schema.get("type", "object")
        if "enum" in schema:
            return schema["enum"][rng.randrange(len(schema["enum"]))]
        if schema_type == "object":
            properties = schema.get("properties", {})
            return {key: self._value_for(sub, rng, depth + 1) for key, sub in properties.items()}
        if schema_type == "array":
            if depth > 3:
                return []
            item_schema = schema.get("items", {"type": "string"})
            return [self._value_for(item_schema, rng, depth + 1) for _ in range(rng.randint(1, 3))]
        if schema_type == "number":
            return round(rng.uniform(0.6, 0.98), 2)
        if schema_type == "integer":
            return rng.randint(1, 20)
        if schema_type == "boolean":
            return rng.random() > 0.4
        return schema.get("description", "Generated by the deterministic demo provider.")

    @staticmethod
    def _synthesize_prose(prompt: str, rng: random.Random) -> str:
        subject = next(
            (line.strip() for line in prompt.splitlines() if line.strip() and not line.startswith("#")),
            "the requested analysis",
        )
        openers = [
            "Analysis complete.",
            "Assessment finished.",
            "Review concluded.",
        ]
        return f"{openers[rng.randrange(len(openers))]} Findings recorded for {subject[:160]}."
