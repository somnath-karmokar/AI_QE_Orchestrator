"""The prompt library: every instruction this platform sends a model, in one place.

Prompts were previously f-strings at the call site. That is fine until you need
to answer any of the questions people actually ask about them:

* *What exactly did we send?* -- an auditor's question, and the honest answer was
  "read the source of whichever agent ran".
* *What changed when the answers got worse?* -- prompts were versioned only by
  whatever commit happened to touch them.
* *Is untrusted content handled safely everywhere?* -- it was not. Each call site
  wrapped its own content, so a single unsafe wrapper (see `safety`) applied to
  every agent at once, and fixing it meant finding all twenty-five call sites.

A template here is identified, versioned and described. Rendering goes through
one path, which is what makes the safety property enforceable rather than
conventional: **trusted text is interpolated, untrusted content is fenced**, and
a caller cannot get the second by accident because it takes a different method.

Versions are integers on the template, not git history. When a prompt's wording
changes in a way that could change answers, bump the version and add a changelog
line -- runs record which version produced them.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from string import Formatter
from typing import Any

from app.ai.prompts.safety import (
    DEFAULT_MAX_CHARS,
    UntrustedBlock,
    fence,
    new_nonce,
    untrusted_preamble,
)


class PromptError(RuntimeError):
    """A template was used in a way that would have produced a wrong prompt."""


@dataclass(frozen=True, slots=True)
class PromptTemplate:
    """One instruction, versioned.

    `text` uses `str.format` placeholders, and every one of them must be declared
    in `inputs`. That is checked at registration, so a typo is a start-up error
    rather than a `KeyError` in front of a customer.
    """

    id: str
    version: int
    purpose: str
    text: str
    inputs: tuple[str, ...] = ()
    changelog: tuple[str, ...] = ()

    @property
    def ref(self) -> str:
        """How a run records which prompt produced it."""
        return f"{self.id}@v{self.version}"

    def placeholders(self) -> set[str]:
        return {name for _, name, _, _ in Formatter().parse(self.text) if name}

    def render(self, **values: Any) -> str:
        """Interpolate trusted values only.

        Untrusted content must not come through here -- it goes through
        `PromptBuilder.untrusted`, which fences it. Nothing enforces that at the
        type level, so the rule is stated where it is easiest to read.
        """
        missing = self.placeholders() - set(values)
        if missing:
            raise PromptError(f"{self.ref} needs {sorted(missing)}, which were not supplied.")
        return self.text.format(**values)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "version": self.version,
            "ref": self.ref,
            "purpose": self.purpose,
            "inputs": list(self.inputs),
            "changelog": list(self.changelog),
            "text": self.text,
        }


# ---------------------------------------------------------------------------
# The registry
# ---------------------------------------------------------------------------

_TEMPLATES: dict[str, PromptTemplate] = {}


def register(template: PromptTemplate) -> PromptTemplate:
    """Add a template, refusing anything that would render wrongly."""
    declared = set(template.inputs)
    used = template.placeholders()

    if used - declared:
        raise PromptError(
            f"{template.ref} uses undeclared placeholder(s) {sorted(used - declared)}."
        )
    if declared - used:
        raise PromptError(
            f"{template.ref} declares input(s) {sorted(declared - used)} it never uses."
        )

    existing = _TEMPLATES.get(template.id)
    if existing is not None and existing.version >= template.version:
        raise PromptError(
            f"'{template.id}' is already registered at v{existing.version}; "
            f"bump the version to replace it."
        )

    _TEMPLATES[template.id] = template
    return template


def get(template_id: str) -> PromptTemplate:
    try:
        return _TEMPLATES[template_id]
    except KeyError:
        raise PromptError(
            f"No prompt template '{template_id}'. Known: {sorted(_TEMPLATES)}"
        ) from None


def templates() -> list[PromptTemplate]:
    """Every registered template, for the library view and for audit."""
    return sorted(_TEMPLATES.values(), key=lambda item: item.id)


# ---------------------------------------------------------------------------
# Building one prompt
# ---------------------------------------------------------------------------


@dataclass
class PromptBuilder:
    """One prompt under construction, holding the fence nonce for its blocks.

    A builder is used for a single prompt and thrown away. The nonce is what
    stops untrusted content closing a block early, so it must not be reused
    across prompts -- content that observed it once could otherwise replay it.
    """

    nonce: str = field(default_factory=new_nonce)
    blocks: list[tuple[str, UntrustedBlock]] = field(default_factory=list)

    @property
    def preamble(self) -> str:
        return untrusted_preamble(self.nonce)

    def untrusted(
        self,
        label: str,
        body: Any,
        *,
        max_chars: int = DEFAULT_MAX_CHARS,
    ) -> str:
        """Fence content the platform does not control.

        Everything an agent reasons over is this: a failure message from the
        application under test, captured DOM, a retrieved document, inputs an
        external platform supplied over the integration API.
        """
        block = fence(label, _as_text(body), nonce=self.nonce, max_chars=max_chars)
        self.blocks.append((label, block))
        return block.rendered

    @property
    def injection_attempts(self) -> list[dict[str, Any]]:
        """Blocks whose content read like an instruction, for logging.

        The fence is the defence; this is the telemetry. Somebody feeding the
        platform 'ignore all previous instructions' is worth knowing about even
        though it did not work.
        """
        return [
            {"block": label, "markers": list(block.suspicious_markers)}
            for label, block in self.blocks
            if block.looks_hostile
        ]

    @property
    def truncated_blocks(self) -> list[str]:
        return [label for label, block in self.blocks if block.truncated]


def _as_text(body: Any) -> str:
    """Render a value for a prompt without `str(dict)` noise where avoidable."""
    if body is None:
        return "none"
    if isinstance(body, str):
        return body
    if isinstance(body, (dict, list, tuple)):
        try:
            return json.dumps(body, indent=2, default=str, ensure_ascii=False)
        except (TypeError, ValueError):
            return str(body)
    return str(body)
