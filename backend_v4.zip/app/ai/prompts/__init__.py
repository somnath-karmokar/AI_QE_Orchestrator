"""Prompt library: the instructions this platform sends models, versioned.

Two responsibilities:

* **`library`** -- a registry of identified, versioned templates, so what was
  sent is auditable and a wording change is a deliberate act with a changelog
  rather than an incidental diff.
* **`safety`** -- one safe way to put untrusted content into a prompt. Every
  agent reasons over content the platform does not control, and the fence here
  is what stops that content being read as instruction.

Importing this package registers the catalogue.
"""

from __future__ import annotations

from app.ai.prompts import catalogue as _catalogue  # noqa: F401 - registers templates
from app.ai.prompts.library import (
    PromptBuilder,
    PromptError,
    PromptTemplate,
    get,
    register,
    templates,
)
from app.ai.prompts.safety import UntrustedBlock, fence, new_nonce, untrusted_preamble

__all__ = [
    "PromptBuilder",
    "PromptError",
    "PromptTemplate",
    "UntrustedBlock",
    "fence",
    "get",
    "new_nonce",
    "register",
    "templates",
    "untrusted_preamble",
]
