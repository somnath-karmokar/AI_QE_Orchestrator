"""Client demo: the Impact Analyzer Agent, running the Wickes risk model.

Reads change requests from a local CSV standing in for the Jira board, and
selects impacted tests from a local git repository standing in for the
customer's own test-pack repo -- so the demo shows the agent reasoning over
artefacts shaped like a customer's actual systems, not our platform's seeded
database. Prints every stage of the pipeline from slide 2 of the client's own
deck as it runs:

    INPUT -> SCORE -> BAND -> SELECT -> OUTPUT -> LEARN

Setup (once, or whenever you want the demo data reset to its known state):

    python scripts/build_wickes_demo_data.py

Run the demo:

    python scripts/run_wickes_impact_analyzer_demo.py
    python scripts/run_wickes_impact_analyzer_demo.py --change CR-1001   # one CR only
    python scripts/run_wickes_impact_analyzer_demo.py --quiet           # summary table only

This calls the same `app.services.wickes_risk_model` and
`app.services.wickes_test_pack` modules the platform ships and
`tests/test_wickes_risk_model.py` / `tests/test_wickes_test_pack.py` hold to
the client's own worked example -- nothing here is demo-only logic that the
tested code doesn't also run.
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    sys.stdout.reconfigure(encoding="utf-8")  # keep this runnable on a plain Windows console
except AttributeError:
    pass

from app.services.wickes_risk_model import (  # noqa: E402
    CHANGE_TYPES,
    DIMENSIONS,
    assess,
    suggest_scores,
    veto_narrative,
)
from app.services.wickes_test_pack import (  # noqa: E402
    git_log_summary,
    scan_repo,
    select_impacted,
)

REPO_ROOT = Path(__file__).resolve().parents[2]
DEMO_ROOT = REPO_ROOT / "demo" / "wickes-change-impact"
TEST_PACK_REPO = DEMO_ROOT / "test-pack-repo"
CSV_PATH = DEMO_ROOT / "change_requests.csv"

RULE = "-" * 78


def banner(text: str) -> None:
    print(f"\n{RULE}\n {text}\n{RULE}")


def step(number: str, name: str, detail: str = "") -> None:
    print(f"\n[{number}] {name}" + (f" - {detail}" if detail else ""))


def pause(seconds: float) -> None:
    """A short, skippable beat so a live narration has room to speak over each
    step rather than the whole run scrolling past in under a second."""
    if seconds:
        time.sleep(seconds)


def load_change_requests(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def print_input(row: dict[str, str]) -> None:
    print(f"    Issue key     : {row['issue_key']}")
    print(f"    Summary       : {row['summary']}")
    print(f"    Journey       : {row['journey']}")
    print(f"    Change type   : {row['change_type']}"
          + ("" if row["change_type"] in CHANGE_TYPES else "  (!! not a recognised change type)"))
    print(f"    Tags          : {row['tags']}")
    print(f"    Description   : {row['description']}")
    print(f"    Status/Sprint : {row['status']} / {row['sprint']}")


def print_ai_suggested_pass(description: str, confirmed: dict[str, int]) -> None:
    """The AI-assist half of SCORE: a first pass from the change's own text,
    shown beside the confirmed scores that are actually used -- an analyst
    (or an earlier AI pass, on a previous change) reviewed and confirmed
    these; this run scores on the confirmed numbers, never the raw suggestion,
    so the live demo is reproducible regardless of the free-text wording."""
    suggested, rationale = suggest_scores(description)
    agreements = sum(1 for key in suggested if suggested[key] == confirmed[key])
    print(f"    AI first-pass read of the change text agreed with the confirmed "
          f"score on {agreements}/{len(suggested)} dimensions.")
    disagreements = [key for key in suggested if suggested[key] != confirmed[key]]
    if disagreements:
        sample = ", ".join(f"{key} (AI {suggested[key]} vs confirmed {confirmed[key]})" for key in disagreements[:3])
        print(f"    Differed on: {sample}"
              + (f" (+{len(disagreements) - 3} more)" if len(disagreements) > 3 else ""))


def print_score_table(result) -> None:  # noqa: ANN001
    print(f"    {'Dimension':<34} {'Wt':>3} {'Score':>5} {'Weighted':>9}")
    for d in result.dimensions:
        print(f"    {d.label:<34} x{d.weight:<2} {d.score:>5} {d.weighted:>9}")
    print(f"    {'-' * 55}")
    print(f"    {'Base Weighted Score':<34} {'':>3} {'':>5} {result.base_score:>6}/{result.max_score}")


def print_band(result) -> None:  # noqa: ANN001
    print(f"    Score {result.base_score}/{result.max_score} bands as {result.band_before_veto} on its own.")
    print(f"    {veto_narrative(result)}")
    print(f"    Modifier = Probability + Impact - Confidence - Control = {result.modifier:+d}  ({result.modifier_reading})")
    print(f"    Coverage commitment: {result.coverage_commitment}")


def print_selection(selected, journey: str) -> None:  # noqa: ANN001
    by_priority: dict[str, int] = {}
    for item in selected:
        by_priority[item.test.priority] = by_priority.get(item.test.priority, 0) + 1
    counts = ", ".join(f"{p}: {by_priority[p]}" for p in sorted(by_priority))
    print(f"    {len(selected)} test(s) selected from the '{journey}' test pack ({counts})")
    for item in selected:
        print(f"      [{item.test.priority}] {item.test.relative}  -  {item.reason}")


def print_output(result, selected, cr: dict[str, str]) -> None:  # noqa: ANN001
    categories = {"security": 0, "accessibility": 0, "performance": 0, "functional": 0}
    for item in selected:
        tags = {t.lower() for t in item.test.tags}
        if tags & {"security", "pci", "dast", "sast"}:
            categories["security"] += 1
        elif tags & {"accessibility", "wcag"}:
            categories["accessibility"] += 1
        elif tags & {"nft", "performance", "peak", "oat"}:
            categories["performance"] += 1
        else:
            categories["functional"] += 1
    print(f"    Change           : {cr['issue_key']} - {cr['summary']}")
    print(f"    Risk band        : {result.band}  (score {result.base_score}/{result.max_score})")
    print(f"    Test scope       : {len(selected)} test(s) - functional {categories['functional']}, "
          f"security {categories['security']}, performance/NFT {categories['performance']}, "
          f"accessibility {categories['accessibility']}")
    print(f"    Coverage commitment: {result.coverage_commitment}")
    print(f"    Release readiness: {_release_readiness(result.band)}")


def _release_readiness(band: str) -> str:
    return {
        "Critical / P1": "Requires the deepest assurance pass before release; treat as a release gate.",
        "High / P2": "Elevated assurance required across all impacted domains before release.",
        "Medium / P3": "Standard AI-selected regression is sufficient; release on the normal cadence.",
        "Low": "Fast release path - verification and smoke of the impacted tests only.",
    }[band]


def print_learn(cr: dict[str, str]) -> None:
    print(f"    Outcome for {cr['issue_key']} recorded. Escaped defects and production incidents from "
          f"this release feed the quarterly re-tuning of the 15 dimension weights and band "
          f"thresholds (Wickes review cadence, slide 1).")


def run_one(row: dict[str, str], files, *, pace: float, quiet: bool) -> tuple:  # noqa: ANN001
    scores = {key: int(row[key]) for key, *_ in DIMENSIONS}
    confirmed_probability = int(row["probability"])
    confirmed_impact = int(row["impact"])
    confirmed_confidence = int(row["confidence"])
    confirmed_control = int(row["control"])

    banner(f"AI Impact Analyzer Agent - {row['issue_key']}")

    step("1", "INPUT", "reading the change record from the Jira board (change_requests.csv)")
    if not quiet:
        print_input(row)
    pause(pace)

    step("1b", "AI-ASSIST", "first-pass dimension read from the change's own free text")
    if not quiet:
        print_ai_suggested_pass(row["description"], scores)
    pause(pace)

    result = assess(
        change_id=row["issue_key"], change_title=row["summary"], scores=scores,
        probability=confirmed_probability, impact=confirmed_impact,
        confidence=confirmed_confidence, control=confirmed_control,
    )

    step("2", "SCORE", "weighted risk = sum(dimension score x weight) across 15 dimensions")
    if not quiet:
        print_score_table(result)
    pause(pace)

    step("3", "BAND", "map score to Critical/High/Medium/Low + apply veto rule")
    print_band(result)
    pause(pace)

    tags = tuple(t.strip() for t in row["tags"].split(",") if t.strip())
    selected = select_impacted(files, journey=row["journey"], change_tags=tags)

    step("4", "SELECT", "tests where journey/tags are impacted, ranked, deduplicated, P1 floor enforced")
    print_selection(selected, row["journey"])
    pause(pace)

    step("5", "OUTPUT", "test scope, coverage and release-confidence read")
    print_output(result, selected, row)
    pause(pace)

    step("6", "LEARN", "escaped defects and incidents re-tune weights next quarter")
    print_learn(row)

    return result, selected


def run_all(*, only: str | None, pace: float, quiet: bool) -> None:
    if not CSV_PATH.exists() or not TEST_PACK_REPO.exists():
        print("Demo data not found. Run this first:\n  python scripts/build_wickes_demo_data.py")
        raise SystemExit(1)

    rows = load_change_requests(CSV_PATH)
    if only:
        rows = [r for r in rows if r["issue_key"] == only]
        if not rows:
            print(f"No change request '{only}' in {CSV_PATH}")
            raise SystemExit(1)

    files = scan_repo(TEST_PACK_REPO)
    log = git_log_summary(TEST_PACK_REPO)

    banner("Wickes Change Impact & Risk Analyzer - live demo")
    print(f"  Test pack repo : {TEST_PACK_REPO}")
    print(f"  {len(files)} tagged test file(s) discovered across "
          f"{len({f.journey for f in files})} journeys")
    if log:
        print("  Recent history :")
        for line in log:
            print(f"    {line}")
    print(f"  Change board   : {CSV_PATH}  ({len(rows)} change request(s) to process)")

    summary = []
    for row in rows:
        result, selected = run_one(row, files, pace=pace, quiet=quiet)
        summary.append((row["issue_key"], row["summary"], result, len(selected)))

    banner("AI Coverage-Planning Agent - release summary across all change requests")
    print(f"    {'Issue':<10} {'Score':>7} {'Band':<15} {'Veto':<6} {'Tests':>6}  Summary")
    for issue, title, result, count in summary:
        veto = "yes" if result.veto_triggered else "no"
        print(f"    {issue:<10} {result.base_score:>4}/{result.max_score:<3} {result.band:<15} "
              f"{veto:<6} {count:>6}  {title[:44]}")
    total_tests = sum(count for *_rest, count in summary)
    print(f"\n    {len(summary)} change request(s) processed, {total_tests} test-selection decision(s) "
          f"made across the release, all traceable to the dimension that drove them.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--change", help="run only this change request's issue key, e.g. CR-1001")
    parser.add_argument("--pace", type=float, default=0.0, help="seconds to pause between pipeline steps (for a live narrated demo)")
    parser.add_argument("--quiet", action="store_true", help="skip the INPUT/SCORE detail tables, print step headers and results only")
    args = parser.parse_args()

    run_all(only=args.change, pace=args.pace, quiet=args.quiet)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
