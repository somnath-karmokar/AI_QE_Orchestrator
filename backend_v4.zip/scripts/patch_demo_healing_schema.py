"""Bring a live demo database up to the healing validation lifecycle.

The demo database is built with `create_all`, not Alembic, so a schema change
needs applying to it directly. This mirrors migration `b2d7419fc305` exactly,
including its data step: records that were marked applied by the old endpoint
never had a re-run, so they stop claiming one.

Safe to run more than once.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = BACKEND_ROOT / "data" / "aiqe.db"

COLUMNS = [
    ("change_type", "VARCHAR(40) NOT NULL DEFAULT 'locator'"),
    ("confidence_breakdown", "JSON"),
    ("patch", "JSON"),
    ("validation_status", "VARCHAR(30) NOT NULL DEFAULT 'not_started'"),
    ("validation_mode", "VARCHAR(20)"),
    ("validation_evidence", "JSON"),
    ("validation_execution_id", "CHAR(36)"),
    ("attempt_count", "INTEGER NOT NULL DEFAULT 0"),
    ("rolled_back_at", "DATETIME"),
    ("approval_request_id", "CHAR(36)"),
]


def main(db_path: Path) -> int:
    if not db_path.exists():
        print(f"No database at {db_path}; nothing to patch.")
        return 0

    con = sqlite3.connect(db_path)
    try:
        existing = {row[1] for row in con.execute("PRAGMA table_info(healing_records)")}
        added = []
        for name, ddl in COLUMNS:
            if name in existing:
                continue
            con.execute(f"ALTER TABLE healing_records ADD COLUMN {name} {ddl}")
            added.append(name)

        for name, columns in (
            ("ix_healing_records_change_type", "change_type"),
            ("ix_healing_records_validation_status", "validation_status"),
        ):
            con.execute(f"CREATE INDEX IF NOT EXISTS {name} ON healing_records ({columns})")

        # A new JSON column is NULL on existing rows, and the model defaults only
        # apply to inserts. Backfill so every row is readable, not just new ones.
        for column, empty in (
            ("confidence_breakdown", "'[]'"),
            ("validation_evidence", "'[]'"),
            ("patch", "'{}'"),
        ):
            con.execute(
                f"UPDATE healing_records SET {column} = {empty} WHERE {column} IS NULL"
            )

        # The old endpoint wrote result_after='passed' on approval without
        # re-running anything. Keep the record, drop the unfounded claim.
        unfounded = con.execute(
            "SELECT count(*) FROM healing_records "
            "WHERE result_after = 'passed' AND (validation_evidence IS NULL OR validation_evidence = '')"
        ).fetchone()[0]
        con.execute(
            """
            UPDATE healing_records
               SET validation_status = 'inconclusive',
                   result_after = NULL,
                   validated_at = NULL
             WHERE result_after = 'passed'
               AND (validation_evidence IS NULL OR validation_evidence = '')
            """
        )
        # `approved_pending_validation` is not a state the lifecycle has any more.
        moved = con.execute(
            "UPDATE healing_records SET status = 'proposed' "
            "WHERE status = 'approved_pending_validation'"
        ).rowcount
        con.commit()
    finally:
        con.close()

    print(f"Columns added      : {', '.join(added) if added else 'none (already current)'}")
    print(f"Unfounded 'passed' : {unfounded} record(s) reset to inconclusive")
    print(f"Legacy status rows : {moved} moved to 'proposed'")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_DB))
