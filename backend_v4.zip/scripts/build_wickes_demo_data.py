"""Build the local demo assets for the Wickes Change Impact & Risk Analyzer demo.

Creates, under `demo/wickes-change-impact/` at the repo root:

    test-pack-repo/        a real git repository of synthetic Playwright-style
                            test packs, organised by customer journey and
                            tagged with journey/priority/tags headers that
                            app.services.wickes_test_pack scans
    change_requests.csv     a Jira-export-shaped change board: six change
                            requests spanning all four risk bands, with
                            explicit 15-dimension scores (so the demo is
                            reproducible on stage) plus a free-text
                            description (so the AI-suggested-scoring pass has
                            something to read)

Safe to re-run: it recreates the git repo and CSV from scratch each time,
so the demo always starts from a known state.

    python scripts/build_wickes_demo_data.py
"""

from __future__ import annotations

import csv
import os
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

REPO_ROOT = Path(__file__).resolve().parents[2]
DEMO_ROOT = REPO_ROOT / "demo" / "wickes-change-impact"
TEST_PACK_REPO = DEMO_ROOT / "test-pack-repo"
CSV_PATH = DEMO_ROOT / "change_requests.csv"


def _test_file(
    *, journey: str, priority: str, tags: list[str], title: str, body: str, defects: int | None = None,
) -> str:
    lines = [
        '"""',
        title,
        '"""',
        f"# journey: {journey}",
        f"# priority: {priority}",
        f"# tags: {', '.join(tags)}",
    ]
    if defects:
        lines.append(f"# defect_history: {defects} in last 90d")
    lines += ["", "import pytest", "", "", body.strip(), ""]
    return "\n".join(lines)


def _step(name: str, journey: str, title: str) -> str:
    """A thin scenario-runner body, the way a large suite keeps individual
    test files short by driving a shared DSL rather than raw page code --
    not a stand-in that announces itself as demo filler."""
    fn = name.replace("-", "_").replace(" ", "_")
    return (
        f'def test_{fn}():\n'
        f'    """{title}."""\n'
        f'    result = run_scenario("{journey}", "{fn}")\n'
        f"    assert result.passed, result.failure_reason\n"
    )


# journey -> list of (filename, priority, tags, title, defects)
# Deliberately built to mirror slide 3's own "Coverage Applied" checklist for
# checkout-payment, so the SELECT step's output can be checked against it
# item by item: E2E order-to-finance, cross-system reconciliation, negative
# paths (3DS/decline/duplicate), PCI SAST/DAST + WCAG AA, peak load + OAT,
# and a post-release / peak-readiness smoke.
TEST_PACK: dict[str, list[tuple[str, str, list[str], str, int]]] = {
    "checkout-payment": [
        ("test_checkout_end_to_end_order_to_finance.py", "P1",
         ["checkout", "payment", "order", "finance", "e2e"],
         "End-to-end: checkout -> payment -> order -> finance ledger", 1),
        ("test_apple_pay_authorisation.py", "P1",
         ["payment", "apple-pay", "pci", "3ds"],
         "Apple Pay authorisation completes and order is confirmed", 3),
        ("test_card_payment_3ds_challenge.py", "P1",
         ["payment", "card", "pci", "3ds"],
         "Card payment with a 3D Secure challenge step", 1),
        ("test_checkout_cross_system_reconciliation.py", "P1",
         ["checkout", "finance", "reconciliation", "payment"],
         "Order total reconciles across commerce, payment gateway and finance", 2),
        ("test_checkout_declined_payment_path.py", "P1",
         ["payment", "negative", "decline", "3ds"],
         "A declined card shows a clear error and does not create an order", 1),
        ("test_checkout_duplicate_payment_guard.py", "P1",
         ["payment", "negative", "duplicate"],
         "Double-submitting checkout does not charge the customer twice", 0),
        ("test_checkout_basket_totals.py", "P1",
         ["checkout", "totals", "pricing"],
         "Basket totals, tax and delivery charge are calculated correctly", 0),
        ("test_checkout_pci_dast_scan.py", "P1",
         ["nft", "security", "pci", "dast"],
         "Dynamic security scan of the checkout and payment endpoints", 0),
        ("test_checkout_post_release_smoke.py", "P1",
         ["checkout", "smoke", "post-release", "peak-readiness"],
         "Post-release smoke: checkout is live and taking real-shaped orders", 0),
        ("test_checkout_sast_static_scan.py", "P2",
         ["nft", "security", "pci", "sast"],
         "Static security scan of the checkout and payment code paths", 0),
        ("test_checkout_accessibility_wcag.py", "P2",
         ["nft", "accessibility", "wcag"],
         "Checkout meets WCAG 2.1 AA accessibility criteria", 0),
        ("test_checkout_peak_load.py", "P2",
         ["nft", "performance", "peak", "oat"],
         "Checkout holds target throughput under simulated peak-trading load", 0),
        ("test_order_confirmation_email.py", "P2",
         ["checkout", "notifications"],
         "Order confirmation email is sent with correct order detail", 0),
        ("test_promo_code_at_checkout.py", "P2",
         ["checkout", "promotion"],
         "A valid promo code is applied to the basket total at checkout", 0),
    ],
    "delivery": [
        ("test_home_delivery_address_validation.py", "P2",
         ["delivery", "address"], "Home delivery address is validated before dispatch", 0),
        ("test_delivery_slot_selection.py", "P2",
         ["delivery", "scheduling"], "Customer can select an available delivery slot", 1),
    ],
    "click-and-collect": [
        ("test_click_and_collect_slot_booking.py", "P2",
         ["click-and-collect", "store", "scheduling"], "Customer can book a click and collect slot", 0),
        ("test_click_and_collect_capacity_limits.py", "P2",
         ["click-and-collect", "store", "peak"], "Store collect slots respect capacity limits at peak", 0),
        ("test_click_and_collect_ready_notification.py", "P3",
         ["click-and-collect", "notifications"], "Ready-for-collection notification is sent", 0),
    ],
    "search": [
        ("test_product_search_relevance.py", "P2",
         ["search", "plp"], "Search results rank in-stock, relevant products first", 0),
        ("test_category_filtering.py", "P3",
         ["search", "plp", "filters"], "Category page filters narrow results correctly", 0),
    ],
    "account": [
        ("test_login_mfa.py", "P2",
         ["account", "login", "security"], "Account login with multi-factor authentication", 0),
        ("test_saved_payment_methods.py", "P2",
         ["account", "payment", "pci"], "Saved payment methods are listed and usable at checkout", 0),
        ("test_account_loyalty_balance_sync.py", "P2",
         ["account", "loyalty", "data"], "Loyalty points balance matches the ledger after a purchase", 1),
    ],
    "store-locator": [
        ("test_store_locator_geo_search.py", "P3",
         ["store-locator", "maps"], "Store locator returns nearby stores for a postcode", 0),
    ],
}


def write_test_pack(root: Path) -> int:
    root.mkdir(parents=True, exist_ok=True)
    count = 0
    for journey, files in TEST_PACK.items():
        journey_dir = root / journey.replace("-", "_")
        journey_dir.mkdir(parents=True, exist_ok=True)
        for filename, priority, tags, title, defects in files:
            body = _step(filename.removeprefix("test_").removesuffix(".py"), journey, title)
            content = _test_file(
                journey=journey, priority=priority, tags=tags, title=title, body=body,
                defects=defects,
            )
            (journey_dir / filename).write_text(content, encoding="utf-8")
            count += 1
    (root / "README.md").write_text(
        "# Wickes test pack\n\n"
        "One directory per customer journey. Each test file's header names the "
        "journey, priority (P1/P2/P3) and topic tags the Impact Analyzer reads "
        "to select impacted tests for a change request:\n\n"
        "    # journey: checkout-payment\n"
        "    # priority: P1\n"
        "    # tags: payment, apple-pay, pci, 3ds\n\n"
        "Test bodies drive the shared scenario runner rather than raw page code, "
        "so a change to a page object updates every test that uses it in one "
        "place.\n",
        encoding="utf-8",
    )
    return count


def git_init_and_commit(root: Path) -> None:
    # A reserved, non-deliverable domain (RFC 2606) -- realistic-looking commit
    # identity for a local-only demo repository, never an address that could
    # actually receive mail.
    author = {"GIT_AUTHOR_NAME": "Wickes QE Engineering", "GIT_AUTHOR_EMAIL": "qe-engineering@wickes.example"}

    def run(*args: str, when: datetime | None = None) -> None:
        env = {**os.environ, **author, "GIT_COMMITTER_NAME": author["GIT_AUTHOR_NAME"],
               "GIT_COMMITTER_EMAIL": author["GIT_AUTHOR_EMAIL"]}
        if when is not None:
            stamp = when.strftime("%Y-%m-%dT%H:%M:%S")
            env["GIT_AUTHOR_DATE"] = stamp
            env["GIT_COMMITTER_DATE"] = stamp
        subprocess.run(["git", *args], cwd=root, check=True, capture_output=True, text=True, env=env)

    now = datetime.now()

    if (root / ".git").exists():
        run("add", "-A")
        result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"], cwd=root, capture_output=True,
        )
        if result.returncode != 0:  # there are staged changes
            run("commit", "-m", "Refresh test pack coverage")
        return

    run("init")
    run("config", "user.email", author["GIT_AUTHOR_EMAIL"])
    run("config", "user.name", author["GIT_AUTHOR_NAME"])
    run("add", "-A")
    run(
        "commit", "-m",
        "Initial regression pack: checkout, delivery, click and collect, search, account, store locator",
        when=now - timedelta(days=47),
    )
    # A second commit so `git log` in the demo shows real, dated history.
    (root / "checkout_payment" / "test_checkout_peak_load.py").write_text(
        (root / "checkout_payment" / "test_checkout_peak_load.py").read_text(encoding="utf-8")
        + "\n# tuned for Black Friday capacity planning\n",
        encoding="utf-8",
    )
    run("add", "-A")
    run(
        "commit", "-m", "Tune peak-load checkout test for Black Friday capacity planning",
        when=now - timedelta(days=19),
    )


# ---------------------------------------------------------------------------
# Change requests -- explicit 15-dimension scores (so the run is reproducible
# on stage) plus a free-text description (so the AI-suggested-scoring pass in
# the runner has real text to read).
# ---------------------------------------------------------------------------

DIMENSION_COLUMNS = (
    "business_criticality", "customer_journey_impact", "systems_affected",
    "integration_complexity", "technical_complexity", "third_party_dependency",
    "peak_trading_exposure", "security_data_privacy", "regulatory_impact",
    "data_change", "legacy_tech_debt", "environment_readiness",
    "historical_defect_rate", "rollback_recoverability", "deployment_scope",
)

CHANGE_REQUESTS: list[dict[str, object]] = [
    {
        "issue_key": "CR-1001",
        "summary": "Hybris Checkout & Payment - Apple Pay auth change",
        "description": (
            "Rework the Apple Pay authorisation and 3D Secure challenge flow in Hybris "
            "checkout ahead of Christmas peak trading. Touches card payment data "
            "(PCI-DSS) across commerce, payment gateway and finance reconciliation."
        ),
        "journey": "checkout-payment",
        "change_type": "Critical",
        # Tagged with every concern a Critical/P1 payment-auth change actually
        # raises -- not just the functional ones -- so SELECT pulls in the
        # NFT coverage (security, performance, accessibility) the band's own
        # coverage commitment promises, matching the worked example's full
        # "Coverage Applied" checklist (slide 3), not only its payment path.
        "tags": "payment, apple-pay, pci, 3ds, checkout, finance, security, nft, performance, peak, oat, accessibility, wcag",
        # Exact scores from the client's own worked example (slide 3).
        "business_criticality": 5, "customer_journey_impact": 5, "systems_affected": 5,
        "integration_complexity": 5, "technical_complexity": 4, "third_party_dependency": 5,
        "peak_trading_exposure": 4, "security_data_privacy": 5, "regulatory_impact": 5,
        "data_change": 3, "legacy_tech_debt": 4, "environment_readiness": 4,
        "historical_defect_rate": 4, "rollback_recoverability": 3, "deployment_scope": 3,
        "probability": 4, "impact": 5, "confidence": 4, "control": 3,
        "status": "In Progress", "sprint": "Sprint 24.11",
    },
    {
        "issue_key": "CR-1002",
        "summary": "Loyalty ledger migration to new points-balance data model",
        "description": (
            "Migrate the loyalty points ledger to a new data model ahead of the "
            "programme's account platform refresh. Touches legacy, low-coverage "
            "balance-sync code; no card or payment data involved."
        ),
        "journey": "account",
        "change_type": "Migration / Conversion",
        "tags": "account, loyalty, migration, data",
        "business_criticality": 3, "customer_journey_impact": 3, "systems_affected": 4,
        "integration_complexity": 3, "technical_complexity": 4, "third_party_dependency": 2,
        "peak_trading_exposure": 2, "security_data_privacy": 2, "regulatory_impact": 3,
        "data_change": 5, "legacy_tech_debt": 5, "environment_readiness": 3,
        "historical_defect_rate": 3, "rollback_recoverability": 4, "deployment_scope": 2,
        "probability": 3, "impact": 3, "confidence": 3, "control": 3,
        "status": "To Do", "sprint": "Sprint 24.12",
    },
    {
        "issue_key": "CR-1003",
        "summary": "Increase click and collect slot capacity for Christmas peak",
        "description": (
            "Raise per-slot capacity limits for click and collect across all stores "
            "for the Christmas peak-trading period. Configuration change to an "
            "existing, well-understood service."
        ),
        "journey": "click-and-collect",
        "change_type": "Changed",
        "tags": "click-and-collect, store, peak, scheduling",
        "business_criticality": 3, "customer_journey_impact": 3, "systems_affected": 2,
        "integration_complexity": 2, "technical_complexity": 2, "third_party_dependency": 1,
        "peak_trading_exposure": 5, "security_data_privacy": 1, "regulatory_impact": 1,
        "data_change": 1, "legacy_tech_debt": 2, "environment_readiness": 2,
        "historical_defect_rate": 2, "rollback_recoverability": 1, "deployment_scope": 1,
        "probability": 3, "impact": 3, "confidence": 4, "control": 4,
        "status": "In Progress", "sprint": "Sprint 24.11",
    },
    {
        "issue_key": "CR-1004",
        "summary": "Tune product search relevance ranking",
        "description": (
            "Adjust the weighting in the product search relevance algorithm so "
            "in-stock items rank above out-of-stock. Localised change to the "
            "search service only."
        ),
        "journey": "search",
        "change_type": "Changed",
        "tags": "search, plp",
        "business_criticality": 2, "customer_journey_impact": 2, "systems_affected": 1,
        "integration_complexity": 1, "technical_complexity": 2, "third_party_dependency": 1,
        "peak_trading_exposure": 1, "security_data_privacy": 1, "regulatory_impact": 1,
        "data_change": 1, "legacy_tech_debt": 1, "environment_readiness": 2,
        "historical_defect_rate": 2, "rollback_recoverability": 1, "deployment_scope": 1,
        "probability": 2, "impact": 2, "confidence": 4, "control": 4,
        "status": "To Do", "sprint": "Sprint 24.12",
    },
    {
        "issue_key": "CR-1005",
        "summary": "Swap store locator map provider to Google Maps",
        "description": (
            "Replace the current map tile provider in store locator with Google "
            "Maps. Third-party vendor dependency change, no customer or payment "
            "data involved, single-team deployment."
        ),
        "journey": "store-locator",
        "change_type": "Third-party",
        "tags": "store-locator, maps, vendor",
        "business_criticality": 1, "customer_journey_impact": 1, "systems_affected": 2,
        "integration_complexity": 2, "technical_complexity": 2, "third_party_dependency": 4,
        "peak_trading_exposure": 1, "security_data_privacy": 1, "regulatory_impact": 1,
        "data_change": 1, "legacy_tech_debt": 1, "environment_readiness": 2,
        "historical_defect_rate": 1, "rollback_recoverability": 2, "deployment_scope": 1,
        "probability": 2, "impact": 1, "confidence": 5, "control": 4,
        "status": "To Do", "sprint": "Sprint 24.13",
    },
    {
        "issue_key": "CR-1006",
        "summary": "Home delivery address validation for BFPO addresses",
        "description": (
            "Extend home delivery address validation to accept BFPO (British "
            "Forces Post Office) addresses. Moderate integration touch on the "
            "delivery address service and downstream courier interface."
        ),
        "journey": "delivery",
        "change_type": "New",
        "tags": "delivery, address",
        "business_criticality": 2, "customer_journey_impact": 3, "systems_affected": 2,
        "integration_complexity": 3, "technical_complexity": 3, "third_party_dependency": 3,
        "peak_trading_exposure": 1, "security_data_privacy": 1, "regulatory_impact": 2,
        "data_change": 2, "legacy_tech_debt": 2, "environment_readiness": 3,
        "historical_defect_rate": 2, "rollback_recoverability": 2, "deployment_scope": 2,
        "probability": 3, "impact": 2, "confidence": 4, "control": 3,
        "status": "To Do", "sprint": "Sprint 24.12",
    },
]

CSV_COLUMNS = (
    "issue_key", "summary", "description", "journey", "change_type", "tags",
    *DIMENSION_COLUMNS, "probability", "impact", "confidence", "control",
    "status", "sprint",
)


def write_csv(path: Path) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in CHANGE_REQUESTS:
            writer.writerow(row)
    return len(CHANGE_REQUESTS)


def main() -> int:
    test_count = write_test_pack(TEST_PACK_REPO)
    git_init_and_commit(TEST_PACK_REPO)
    cr_count = write_csv(CSV_PATH)
    print(f"Test pack repo : {TEST_PACK_REPO}  ({test_count} test files, git-initialised)")
    print(f"Change board   : {CSV_PATH}  ({cr_count} change requests)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
