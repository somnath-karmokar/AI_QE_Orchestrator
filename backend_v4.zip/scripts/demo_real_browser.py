"""Show self-healing against a real browser and a real DOM.

Runs the whole lifecycle in front of you, with nothing simulated:

    1. the test runs against the markup it was written for, and passes
       -- while it passes, the platform records what the element looked like
    2. the front end is redesigned (v2: every test id renamed, roles and
       labels untouched) and the same test now fails, for real
    3. the page is captured at the moment of failure -- DOM, accessibility
       tree, screenshot, console, network
    4. healing reads that captured page and proposes the element that is
       actually there

Requires the platform to be running (it serves the application under test):

    python -m uvicorn app.main:app --host 127.0.0.1 --port 8100
    python scripts/demo_real_browser.py
"""

from __future__ import annotations

import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Real browser execution, decided before settings are read.
os.environ.setdefault("PLAYWRIGHT_ENABLED", "true")
# A deliberately impatient test, so the late-rendering panel in step 5 fails the
# way a real one would rather than passing by luck.
os.environ.setdefault("PLAYWRIGHT_TIMEOUT_MS", "800")

from sqlalchemy import select  # noqa: E402

from app.agents.base import AgentContext  # noqa: E402
from app.agents.implementations.automation import SelfHealingAgent  # noqa: E402
from app.core import config as config_module  # noqa: E402
from app.core.database import session_scope  # noqa: E402
from app.execution.service import ExecutionService  # noqa: E402
from app.models.project import Project  # noqa: E402
from app.models.testing import (  # noqa: E402
    Execution,
    ExecutionArtifact,
    FailureEvidence,
    TestCase,
    TestScript,
)

BASE = "http://127.0.0.1:8100"
V1 = f"{BASE}/demo-app/v1/checkout.html"
V2 = f"{BASE}/demo-app/v2/checkout.html"
RUN_NAME = "Real browser demonstration"

# What the test was written against, in v1's markup.
ORIGINAL_LOCATORS = [
    {
        "name": "submit",
        "description": "Pay now button",
        "strategy": "test_id",
        "locator": 'page.get_by_test_id("checkout-submit-btn")',
        "confidence": 0.95,
    },
    {
        "name": "promo",
        "description": "Promo code field",
        "strategy": "test_id",
        "locator": 'page.get_by_test_id("promo-code")',
        "confidence": 0.95,
    },
]

# A second test, against the loyalty panel v2 renders late. Its locator is
# correct on both pages -- the only thing wrong is how long the test waits.
SLOW_ELEMENT_LOCATORS = [
    {
        "name": "loyalty",
        "description": "Loyalty points",
        "strategy": "test_id",
        "locator": 'page.get_by_test_id("loyalty-points")',
        "confidence": 0.95,
    },
]


def rule(title: str) -> None:
    print(f"\n{title}\n{'-' * len(title)}")


def reachable(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=5) as response:  # noqa: S310 - fixed localhost URL
            return response.status == 200
    except (urllib.error.URLError, OSError):
        return False


def run_against(url: str, name: str, case_id: str, project_id: str) -> str:
    config_module.settings.demo_app_base_url = url
    with session_scope() as session:
        service = ExecutionService(session)
        execution = service.create(
            project_id=project_id,
            name=name,
            suite_type="regression",
            test_case_ids=[case_id],
            triggered_by="demo",
        )
        service.run(execution.id)
        return execution.id


def main() -> int:
    if not reachable(V1):
        print(f"The application under test is not reachable at {V1}.")
        print("Start the platform first:  python -m uvicorn app.main:app --port 8100")
        return 1

    with session_scope() as session:
        project = session.execute(select(Project).where(Project.key == "ABCR")).scalar_one_or_none()
        if project is None:
            print("The demo project (ABCR) was not found. Seed the platform first.")
            return 1
        row = session.execute(
            select(TestCase, TestScript)
            .join(TestScript, TestScript.test_case_id == TestCase.id)
            .where(TestCase.project_id == project.id, TestCase.is_automated.is_(True))
        ).first()
        if row is None:
            print("No automated test case with a script was found.")
            return 1
        case, script = row
        # Point the test at the checkout, as it was written.
        script.locators = [dict(item) for item in ORIGINAL_LOCATORS]
        session.flush()
        case_id, script_id, project_id, case_title = case.id, script.id, project.id, case.title

    print(f"Test under demonstration: {case_title}")
    print("Locators:", ", ".join(item["locator"] for item in ORIGINAL_LOCATORS))

    # ---------------------------------------------------------------- 1
    rule("1. The test runs against the markup it was written for")
    run_against(V1, f"{RUN_NAME} (v1)", case_id, project_id)
    with session_scope() as session:
        execution = (
            session.execute(select(Execution).where(Execution.name == f"{RUN_NAME} (v1)"))
            .scalars()
            .first()
        )
        print(f"   {V1}")
        print(f"   result: {execution.status}  passed={execution.passed} failed={execution.failed}")
        script = session.get(TestScript, script_id)
        for locator in script.locators:
            finger = locator.get("fingerprint") or {}
            print(
                f"   remembered '{locator['name']}': role={finger.get('role')} "
                f"name={finger.get('name')!r} test_id={finger.get('test_id')!r}"
            )
    print("   -- while the locator still resolves, the platform records the element.")

    # ---------------------------------------------------------------- 2
    rule("2. The front end is redesigned, and the same test runs again")
    execution_id = run_against(V2, f"{RUN_NAME} (v2)", case_id, project_id)
    with session_scope() as session:
        execution = session.get(Execution, execution_id)
        print(f"   {V2}")
        print(f"   result: {execution.status}  passed={execution.passed} failed={execution.failed}")
        for test in execution.tests:
            print(f"   {test.failure_category}: {(test.failure_message or '')[:96]}")

    # ---------------------------------------------------------------- 3
    rule("3. The page was captured at the moment of failure")
    with session_scope() as session:
        artifacts = list(
            session.execute(
                select(ExecutionArtifact).where(ExecutionArtifact.execution_id == execution_id)
            )
            .scalars()
            .all()
        )
        for artifact in artifacts:
            exists = Path(artifact.storage_path).is_file()
            print(
                f"   {artifact.artifact_type:<20} {artifact.size_bytes:>7} bytes   "
                f"on disk: {exists}"
            )
        evidence = (
            session.execute(
                select(FailureEvidence).where(FailureEvidence.execution_id == execution_id)
            )
            .scalars()
            .first()
        )
        if evidence:
            print(f"   capture mode        : {evidence.capture_mode}")
            print(f"   page                : {evidence.page_title!r} at {evidence.page_url}")
            print(f"   failed locator      : {evidence.failed_locator}")
            print(f"   DOM captured        : {len(evidence.dom_html or '')} characters")
            print(f"   accessibility tree  : {'captured' if evidence.accessibility_tree else 'none'}")

    # ---------------------------------------------------------------- 4
    rule("4. Healing reads that page and proposes what is actually there")
    with session_scope() as session:
        execution = session.get(Execution, execution_id)
        project = session.get(Project, execution.project_id)
        agent = SelfHealingAgent()
        ctx = AgentContext(session=session, project=project, variables={"execution_id": execution_id})
        gathered = agent.gather_context(ctx, {"execution_id": execution_id})
        payload = agent.draft(ctx, {"execution_id": execution_id}, gathered)

        for finding in payload.get("findings", []):
            print(f"   from       : {finding['original_locator']}")
            print(f"   to         : {finding['proposed_locator']}   [{finding['strategy']}]")
            print(f"   confidence : {finding['confidence']:.0%}    decision: {finding['decision']}")
            print(f"   grounded in captured page: {finding.get('grounded_in_evidence')}")
            for item in finding["evidence"]:
                if item["type"] in {"page_evidence", "margin", "policy"}:
                    print(f"     - {item['detail']}")
            print()

    # ---------------------------------------------------------------- 5
    rule("5. The same pipeline, a different kind of fault")
    print("   Not every failing locator is a wrong locator. The loyalty panel renders")
    print("   late, so this test's locator is correct and its patience is not.\n")

    with session_scope() as session:
        script = session.get(TestScript, script_id)
        script.locators = [dict(item) for item in SLOW_ELEMENT_LOCATORS]
        session.flush()

    timing_execution_id = run_against(V2, f"{RUN_NAME} (slow element)", case_id, project_id)
    with session_scope() as session:
        execution = session.get(Execution, timing_execution_id)
        test = next(iter(execution.tests), None)
        print(f"   result: {execution.status}  classified as: {test.failure_category if test else '?'}")
        evidence = (
            session.execute(
                select(FailureEvidence).where(
                    FailureEvidence.execution_id == timing_execution_id
                )
            )
            .scalars()
            .first()
        )
        if evidence and evidence.observed_wait_ms:
            print(
                f"   the element was not missing: it appeared after "
                f"{evidence.observed_wait_ms}ms, against a "
                f"{config_module.settings.playwright_timeout_ms}ms budget"
            )

        project = session.get(Project, project_id)
        agent = SelfHealingAgent()
        ctx = AgentContext(
            session=session, project=project, variables={"execution_id": timing_execution_id}
        )
        gathered = agent.gather_context(ctx, {"execution_id": timing_execution_id})
        payload = agent.draft(ctx, {"execution_id": timing_execution_id}, gathered)
        for finding in payload.get("findings", []):
            print(f"\n   change type : {finding['change_type']}")
            print(f"   repair      : {finding['proposed_locator']}")
            print(f"   confidence  : {finding['confidence']:.0%}    decision: {finding['decision']}")
            print(f"   the locator is left exactly as it was: {finding['original_locator']}")

    print(
        "\n   Two failures that look identical to a test -- 'locator resolved to 0 elements' --"
        "\n   and two opposite repairs. Telling them apart is the whole job."
    )

    print("\nNothing here was simulated: a real browser, a real failure, a real page.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
