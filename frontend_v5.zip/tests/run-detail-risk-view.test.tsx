/**
 * The Run Detail page's premium risk-scoring view and modern step log --
 * both detected structurally (from `output.outputs` carrying a risk shape,
 * and from `reasoning_summary` carrying `[marker] LABEL:` sections), so this
 * exercises them through whatever agent happens to return that shape rather
 * than asserting anything about a specific agent key.
 */
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import RunDetailPage from '@/pages/RunDetailPage';
import { api } from '@/services/api';
import type { RunDetail } from '@/types';

function run(): RunDetail {
  return {
    id: 'run-1',
    project_id: 'project-1',
    agent_id: 'agent-wickes',
    run_number: 95,
    title: 'Impact Analyzer Agent',
    kind: 'agent',
    status: 'succeeded',
    trigger: 'manual',
    started_at: '2026-09-22T09:00:00Z',
    finished_at: '2026-09-22T09:00:01Z',
    duration_ms: 464,
    total_tokens: 7709,
    total_cost_usd: 0.0913,
    step_count: 1,
    completed_step_count: 1,
    summary: 'CR-1001 (Apple Pay auth change) scores 124/140 -> Critical / P1.',
    triggered_by: 'priya.raman@example.com',
    correlation_id: 'corr-1',
    inputs: { change_request_id: 'CR-1001' },
    outputs: {},
    variables: {},
    prompt_tokens: 7000,
    completion_tokens: 709,
    steps: [
      {
        id: 'step-1',
        node_key: 'wickes',
        node_type: 'agent',
        label: 'Impact Analyzer Agent',
        sequence: 1,
        status: 'succeeded',
        agent_id: 'agent-wickes',
        agent_key: 'wickes-change-impact-analyzer',
        attempt: 1,
        duration_ms: 205,
        inputs: { change_request_id: 'CR-1001' },
        reasoning_summary:
          "[1] INPUT: read CR-1001 (Apple Pay auth change) from the Wickes change board.\n" +
          '[2] SCORE: base weighted score = 124/140.\n' +
          '[3] BAND: Critical / P1 before the veto rule. Already at the top band.\n',
        evidence: [],
        tool_calls: [],
        artifacts: [],
        confidence: 0.95,
        policy_decision: {},
        total_tokens: 7709,
        cost_usd: 0.0913,
        output: {
          status: 'success',
          confidence: 0.95,
          summary: 'CR-1001 scores 124/140 -> Critical / P1.',
          findings: [
            { type: 'dimension_score', dimension: 'business_criticality', label: 'Business criticality', weight: 3, score: 5, weighted: 15 },
            { type: 'band', severity: 'critical', detail: 'Base weighted score 124/140 bands as Critical / P1.' },
          ],
          recommendations: [{ priority: 'critical', action: 'Coverage commitment for Critical / P1.' }],
          artifacts: [],
          next_action: 'review_release_gate',
          outputs: {
            change_id: 'CR-1001',
            change_title: 'Apple Pay auth change',
            band: 'Critical / P1',
            band_before_veto: 'Critical / P1',
            base_score: 124,
            max_score: 140,
            veto_triggered: ['business_criticality', 'security_data_privacy'],
            modifier: 2,
            modifier_reading: 'risk elevated',
            coverage_commitment: '100% automated E2E on critical journeys.',
            dimensions: [
              { key: 'business_criticality', label: 'Business criticality', weight: 3, score: 5, weighted: 15 },
              { key: 'technical_complexity', label: 'Technical complexity', weight: 2, score: 4, weighted: 8 },
              { key: 'environment_readiness', label: 'Environment readiness', weight: 1, score: 2, weighted: 2 },
            ],
            selected_tests: [
              { path: 'checkout-payment/apple-pay-3ds.spec.ts', priority: 'P1', journey: 'checkout-payment', reason: 'tag match: apple-pay' },
            ],
            test_counts_by_priority: { P1: 9, P2: 8 },
          },
        },
      },
    ],
  };
}

function renderPage() {
  return render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <MemoryRouter initialEntries={['/runs/run-1']}>
        <Routes>
          <Route path="/runs/:runId" element={<RunDetailPage />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('RunDetailPage - risk-scoring view', () => {
  it('renders the band, score and a veto callout from output.outputs, not just a text dump', async () => {
    vi.spyOn(api, 'getRun').mockResolvedValue(run());

    renderPage();

    expect(await screen.findByText('124')).toBeInTheDocument();
    expect(screen.getAllByText('Critical / P1').length).toBeGreaterThan(0);
    expect(screen.getByText(/veto rule triggered/i)).toBeInTheDocument();
    expect(screen.getByText(/business_criticality, security_data_privacy/)).toBeInTheDocument();
  });

  it('shows every scored dimension with its own weight and score, not one dumped paragraph', async () => {
    vi.spyOn(api, 'getRun').mockResolvedValue(run());

    renderPage();

    expect(await screen.findByText('Business criticality')).toBeInTheDocument();
    expect(screen.getByText('Technical complexity')).toBeInTheDocument();
    expect(screen.getByText('Environment readiness')).toBeInTheDocument();
  });

  it('suppresses the generic Findings list once the risk card covers the same data', async () => {
    vi.spyOn(api, 'getRun').mockResolvedValue(run());

    renderPage();

    await screen.findByText('124');
    expect(screen.queryByText('Findings')).not.toBeInTheDocument();
  });

  it('renders a marked-up reasoning summary as a step timeline, not one paragraph', async () => {
    vi.spyOn(api, 'getRun').mockResolvedValue(run());

    renderPage();

    expect(await screen.findByText('[1]')).toBeInTheDocument();
    expect(screen.getByText('INPUT')).toBeInTheDocument();
    expect(screen.getByText('[2]')).toBeInTheDocument();
    expect(screen.getByText('SCORE')).toBeInTheDocument();
  });

  it('offers a download button that triggers the browser print/save-as-PDF flow', async () => {
    vi.spyOn(api, 'getRun').mockResolvedValue(run());
    const printSpy = vi.spyOn(window, 'print').mockImplementation(() => {});

    renderPage();

    const button = await screen.findByRole('button', { name: /download report/i });
    button.click();

    expect(printSpy).toHaveBeenCalledTimes(1);
  });

  it('drops the one-step timeline sidebar so the report uses the full width', async () => {
    vi.spyOn(api, 'getRun').mockResolvedValue(run());

    renderPage();

    await screen.findByText('124');
    expect(screen.queryByText('Flow timeline')).not.toBeInTheDocument();
  });
});
