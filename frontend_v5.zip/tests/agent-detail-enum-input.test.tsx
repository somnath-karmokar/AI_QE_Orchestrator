/**
 * The Agent Details "Test this agent" panel, for an input the agent declares
 * as an `enum` -- e.g. the Wickes agent's `change_request_id`, which must be
 * picked from the client's actual change board, not typed freehand.
 *
 * What matters: an enum-typed input renders a real `<select>` (so a user can
 * only submit a value the agent actually recognises), it is seeded with
 * `enumNames` as friendly labels rather than bare codes, the chosen value is
 * what gets sent to run the agent, and a plain string input without an enum
 * still renders as free text exactly as it always has -- this must not change
 * behaviour for every other agent's inputs.
 */
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import AgentDetailPage from '@/pages/AgentDetailPage';
import { api } from '@/services/api';
import type { AgentDetail } from '@/types';

vi.mock('@/hooks', async () => {
  const actual = await vi.importActual<typeof import('@/hooks')>('@/hooks');
  return { ...actual, useProjectId: () => 'project-1' };
});

function agent(overrides: Partial<AgentDetail> = {}): AgentDetail {
  return {
    id: 'agent-wickes',
    key: 'wickes-change-impact-analyzer',
    name: 'Wickes Change Impact & Risk Analyzer',
    summary: 'Scores a change against the 15-dimension risk model.',
    description: 'Scores a change against the 15-dimension risk model.',
    category: 'Risk & Compliance',
    icon: 'Gauge',
    version: '1.0.0',
    lifecycle_state: 'active',
    risk_level: 'low',
    cost_tier: 'low',
    requires_approval: false,
    is_builtin: true,
    is_published: true,
    supported_tools: [],
    tags: [],
    usage_count: 0,
    success_rate: 0,
    avg_duration_ms: 0,
    avg_cost_usd: 0,
    rating: 0,
    capability: 'reasoning',
    input_schema: {
      type: 'object',
      required: ['change_request_id'],
      properties: {
        change_request_id: {
          type: 'string',
          description: 'A change request from the Wickes change board.',
          enum: ['CR-1001', 'CR-1002'],
          enumNames: ['CR-1001 - Apple Pay auth change', 'CR-1002 - Loyalty ledger migration'],
        },
      },
    },
    output_schema: { type: 'object' },
    llm_config: {},
    temperature: 0.1,
    max_tokens: 2000,
    token_budget: 10000,
    cost_budget_usd: 1,
    retry_policy: { max_attempts: 1 },
    timeout_seconds: 60,
    guardrails: [],
    mcp_servers: [],
    ...overrides,
  };
}

function renderPage() {
  return render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <MemoryRouter initialEntries={['/agents/agent-wickes']}>
        <Routes>
          <Route path="/agents/:agentId" element={<AgentDetailPage />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('AgentDetailPage - enum-typed test inputs', () => {
  it('renders an enum input as a select, not a free-text box', async () => {
    vi.spyOn(api, 'getAgent').mockResolvedValue(agent());
    vi.spyOn(api, 'agentVersions').mockResolvedValue([]);
    vi.spyOn(api, 'getCart').mockResolvedValue([]);

    renderPage();

    const select = await screen.findByLabelText(/change request id/i);
    expect(select.tagName).toBe('SELECT');
  });

  it('labels each option from enumNames, not the bare enum code', async () => {
    vi.spyOn(api, 'getAgent').mockResolvedValue(agent());
    vi.spyOn(api, 'agentVersions').mockResolvedValue([]);
    vi.spyOn(api, 'getCart').mockResolvedValue([]);

    renderPage();

    expect(await screen.findByRole('option', { name: 'CR-1001 - Apple Pay auth change' })).toBeInTheDocument();
    expect(screen.getByRole('option', { name: 'CR-1002 - Loyalty ledger migration' })).toBeInTheDocument();
  });

  it('runs the agent with the selected change request', async () => {
    vi.spyOn(api, 'getAgent').mockResolvedValue(agent());
    vi.spyOn(api, 'agentVersions').mockResolvedValue([]);
    vi.spyOn(api, 'getCart').mockResolvedValue([]);
    const testAgent = vi.spyOn(api, 'testAgent').mockResolvedValue({ id: 'run-1' } as never);

    renderPage();

    const select = await screen.findByLabelText(/change request id/i);
    fireEvent.change(select, { target: { value: 'CR-1002' } });
    fireEvent.click(screen.getByRole('button', { name: /run test/i }));

    await waitFor(() =>
      expect(testAgent).toHaveBeenCalledWith('agent-wickes', {
        project_id: 'project-1',
        inputs: { change_request_id: 'CR-1002' },
      }),
    );
  });

  it('a plain string input with no enum still renders as free text', async () => {
    vi.spyOn(api, 'getAgent').mockResolvedValue(
      agent({
        input_schema: {
          type: 'object',
          required: ['requirement_key'],
          properties: { requirement_key: { type: 'string', description: 'e.g. PAY-201' } },
        },
      }),
    );
    vi.spyOn(api, 'agentVersions').mockResolvedValue([]);
    vi.spyOn(api, 'getCart').mockResolvedValue([]);

    renderPage();

    const input = await screen.findByLabelText(/requirement key/i);
    expect(input.tagName).toBe('INPUT');
  });
});
