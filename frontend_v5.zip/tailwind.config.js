/** @type {import('tailwindcss').Config} */
// Enterprise palette from spec §25: deep navy, professional blue, cool gray.
// Deliberately no neon, no gradients, restrained semantic colour.
export default {
  // .js/.jsx included for the metrics dashboard feature (src/features/metrics-dashboard),
  // which is plain JSX, not TypeScript.
  content: ['./index.html', './src/**/*.{ts,tsx,js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#EEF3F9', 100: '#D5E1EF', 200: '#AAC1DC', 300: '#7599C4',
          400: '#3F6DA5', 500: '#145DA0', 600: '#104C84', 700: '#0B2E59',
          800: '#082343', 900: '#05192F',
        },
        brand: {
          50: '#EDF4FB', 100: '#D3E4F6', 200: '#A6C8EC', 300: '#6FA5DE',
          400: '#3C82CE', 500: '#145DA0', 600: '#114E86', 700: '#0D3D69',
          800: '#0A2E4F', 900: '#071F35',
        },
        surface: { DEFAULT: '#FFFFFF', muted: '#F7F9FC', sunken: '#EFF3F8' },
        line: { DEFAULT: '#D9E1EA', strong: '#BCC9D7', subtle: '#E8EEF4' },
        ink: { DEFAULT: '#172033', secondary: '#5F6B7A', tertiary: '#8B95A3', inverse: '#FFFFFF' },
        success: { DEFAULT: '#238636', bg: '#E9F5EC', border: '#B7DFC1', text: '#146C2A' },
        warning: { DEFAULT: '#B7791F', bg: '#FDF5E7', border: '#EFD7A6', text: '#8F5F14' },
        danger:  { DEFAULT: '#C53030', bg: '#FCEDED', border: '#F0BFBF', text: '#9B2121' },
        info:    { DEFAULT: '#2563EB', bg: '#EAF1FE', border: '#BFD5FB', text: '#1D4FD8' },
        // Metrics dashboard feature only (src/features/metrics-dashboard) --
        // named `dashCyan`, not `brand`, so it can't collide with this
        // platform's own brand-* palette used everywhere else in the app.
        dashCyan: {
          50: '#effcff', 100: '#cff7fe', 200: '#a5effb', 300: '#67e1f4', 400: '#22c9e4',
          500: '#06a9ca', 600: '#0788a9', 700: '#0b6d89', 800: '#115870', 900: '#134a60',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Consolas', 'monospace'],
        // Metrics dashboard feature only.
        montserrat: ['Montserrat', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
      },
      fontSize: {
        '2xs': ['11px', { lineHeight: '16px' }],
        xs: ['12px', { lineHeight: '18px' }],
        sm: ['13px', { lineHeight: '20px' }],
        base: ['14px', { lineHeight: '22px' }],
        md: ['15px', { lineHeight: '24px' }],
        lg: ['16px', { lineHeight: '26px' }],
        xl: ['18px', { lineHeight: '28px' }],
        '2xl': ['20px', { lineHeight: '30px' }],
        '3xl': ['24px', { lineHeight: '34px' }],
        '4xl': ['30px', { lineHeight: '40px' }],
      },
      borderRadius: { sm: '4px', DEFAULT: '6px', md: '6px', lg: '8px', xl: '12px' },
      boxShadow: {
        card: '0 1px 2px 0 rgba(23, 32, 51, 0.04)',
        raised: '0 2px 8px -2px rgba(23, 32, 51, 0.10), 0 1px 2px 0 rgba(23, 32, 51, 0.05)',
        popover: '0 8px 24px -6px rgba(23, 32, 51, 0.16), 0 2px 6px -2px rgba(23, 32, 51, 0.08)',
      },
      transitionDuration: { DEFAULT: '150ms' },
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'slide-up': { from: { opacity: '0', transform: 'translateY(4px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
      },
      animation: {
        'fade-in': 'fade-in 150ms ease-out',
        'slide-up': 'slide-up 180ms ease-out',
        shimmer: 'shimmer 1.6s infinite',
        // Metrics dashboard feature only -- reuses Tailwind's built-in
        // `pulse` keyframe, just slower, so no new keyframe is needed.
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
    },
  },
  plugins: [],
};
