/** Shared API contract types, mirroring the backend Pydantic schemas. */

export interface Page<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

export interface SystemInfo {
  app_name: string;
  version: string;
  environment: string;
  demo_mode: boolean;
  default_llm_provider: string;
  playwright_enabled: boolean;
  vector_store: { provider: string; status: string; mode: string; total_vectors: number };
  database: string;
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  job_title?: string | null;
  avatar_initials?: string | null;
  is_active: boolean;
  role_key: string;
  permissions: string[];
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_in_minutes: number;
  user: User;
}

/* -------------------------------------------------------------------------- */

export interface Environment {
  id: string;
  key: string;
  name: string;
  description?: string | null;
  base_url?: string | null;
  api_base_url?: string | null;
  is_production_like: boolean;
  allows_write_actions: boolean;
  health_status: string;
}

export interface Integration {
  id: string;
  kind: string;
  name: string;
  description?: string | null;
  connector_mode: string;
  status: string;
  base_url?: string | null;
  last_sync_at?: string | null;
  config: Record<string, unknown>;
}

export interface ProjectSummary {
  id: string;
  key: string;
  name: string;
  description?: string | null;
  status: string;
  business_domain?: string | null;
  modules: string[];
  tags: string[];
}

export interface ProjectDetail extends ProjectSummary {
  application_url?: string | null;
  jira_project_key?: string | null;
  confluence_space?: string | null;
  git_repository?: string | null;
  onboarding_step: number;
  qe_policies: Record<string, unknown>;
  execution_config: Record<string, unknown>;
  llm_config: Record<string, unknown>;
  cost_budget_usd: number;
  environments: Environment[];
  integrations: Integration[];
  created_at?: string | null;
}

/* -------------------------------------------------------------------------- */

export interface AgentSummary {
  id: string;
  key: string;
  name: string;
  summary?: string | null;
  description?: string | null;
  category: string;
  icon: string;
  version: string;
  lifecycle_state: string;
  risk_level: string;
  cost_tier: string;
  requires_approval: boolean;
  is_builtin: boolean;
  is_published: boolean;
  supported_tools: string[];
  tags: string[];
  usage_count: number;
  success_rate: number;
  avg_duration_ms: number;
  avg_cost_usd: number;
  rating: number;
  project_id?: string | null;
}

export interface AgentDetail extends AgentSummary {
  goal?: string | null;
  system_instructions?: string | null;
  capability: string;
  input_schema: JsonSchema;
  output_schema: JsonSchema;
  llm_config: Record<string, unknown>;
  temperature: number;
  max_tokens: number;
  token_budget: number;
  cost_budget_usd: number;
  retry_policy: Record<string, unknown>;
  timeout_seconds: number;
  guardrails: string[];
  mcp_servers: string[];
  handler_key?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface JsonSchema {
  type?: string;
  required?: string[];
  properties?: Record<
    string,
    {
      type?: string;
      description?: string;
      default?: unknown;
      enum?: string[];
      /** Display label for each `enum` value, same order, same length. */
      enumNames?: string[];
    }
  >;
}

export interface CartItem {
  id: string;
  agent_id: string;
  project_id: string;
  sequence: number;
  notes?: string | null;
  config_overrides: Record<string, unknown>;
  agent?: AgentSummary | null;
}

/* -------------------------------------------------------------------------- */

export interface FlowNode {
  id: string;
  node_key: string;
  node_type: string;
  label: string;
  agent_id?: string | null;
  agent_version?: string | null;
  position_x: number;
  position_y: number;
  sequence: number;
  config: Record<string, unknown>;
  input_mapping: Record<string, unknown>;
  output_mapping: Record<string, unknown>;
  condition_expression?: string | null;
  llm_config: Record<string, unknown>;
  retry_policy: Record<string, unknown>;
  timeout_seconds?: number | null;
  on_failure: string;
  requires_approval: boolean;
  approval_role?: string | null;
  cost_limit_usd?: number | null;
}

export interface FlowEdge {
  id: string;
  source_node_key: string;
  target_node_key: string;
  branch_label?: string | null;
  condition_expression?: string | null;
}

export interface FlowValidation {
  valid: boolean;
  errors: { code: string; message: string }[];
  warnings: { code: string; message: string }[];
  node_count?: number;
  edge_count?: number;
  agent_node_count?: number;
  execution_order?: string[];
}

export interface FlowSummary {
  id: string;
  key: string;
  name: string;
  description?: string | null;
  category: string;
  status: string;
  version: string;
  is_template: boolean;
  project_id: string;
  tags: string[];
  run_count: number;
  last_run_at?: string | null;
  cost_budget_usd: number;
  validation_result: FlowValidation;
  owner?: string | null;
  trigger_type: string;
  schedule: FlowSchedule;
  schedule_description: string;
  next_run_at?: string | null;
  api_trigger_enabled: boolean;
  webhook_token_hint?: string | null;
  governance: Partial<FlowGovernanceSettings>;
  updated_at?: string | null;
}

export interface FlowDetail extends FlowSummary {
  variables: Record<string, unknown>;
  default_environment_id?: string | null;
  llm_config: Record<string, unknown>;
  token_budget: number;
  nodes: FlowNode[];
  edges: FlowEdge[];
  created_at?: string | null;
  created_by?: string | null;
}

/* ---- Flow Studio --------------------------------------------------------- */

export interface FlowSchedule {
  enabled: boolean;
  frequency?: 'hourly' | 'daily' | 'weekly';
  time?: string;
  weekday?: number;
}

export interface FlowGovernanceSettings {
  run_roles: string[];
  budget_alert_percent: number;
  notify_on_failure: boolean;
  slo_success_rate: number;
}

export interface FlowTemplateStep {
  label: string;
  node_type: string;
  agent_key?: string | null;
  agent_name?: string | null;
  risk_level?: string | null;
  requires_approval: boolean;
}

export interface FlowTemplate {
  key: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  outcome: string;
  tags: string[];
  variables: Record<string, unknown>;
  steps: FlowTemplateStep[];
  agent_count: number;
  approval_gates: number;
  conditions: number;
  estimated_cost_per_run_usd: number;
  cost_budget_usd: number;
}

export interface ComposedStep {
  node_key: string;
  node_type: string;
  label: string;
  reason: string;
  agent_key?: string | null;
  agent_name?: string | null;
  risk_level?: string | null;
  branch?: string | null;
}

export interface FlowComposition {
  name: string;
  description: string;
  steps: ComposedStep[];
  nodes: Array<Record<string, unknown> & { node_key: string; node_type: string; label: string }>;
  edges: Array<{ source_node_key: string; target_node_key: string; branch_label?: string | null }>;
  variables: Record<string, unknown>;
  schedule: FlowSchedule | null;
  warnings: string[];
  agent_count: number;
  approval_gates: number;
  conditions: number;
  validation: FlowValidation;
}

export interface FlowHeader {
  id: string;
  key: string;
  name: string;
  description?: string | null;
  category: string;
  status: string;
  version: string;
  owner?: string | null;
  tags: string[];
  agent_count: number;
  approval_gates: number;
  cost_budget_usd: number;
  schedule: FlowSchedule;
  schedule_description: string;
  next_run_at?: string | null;
  api_trigger_enabled: boolean;
  run_count: number;
  last_run_at?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface FlowCardSummary extends FlowHeader {
  runs: number;
  success_rate: number | null;
  avg_cost_usd: number;
  total_cost_usd: number;
  p50_duration_ms: number;
  last_status: string | null;
  pending_approvals: number;
  activity: number[];
  validation_valid: boolean;
}

export interface FlowStudioOverview {
  window_days: number;
  totals: {
    flows: number;
    published: number;
    scheduled: number;
    api_enabled: number;
    runs: number;
    success_rate: number | null;
    total_cost_usd: number;
    pending_approvals: number;
    hours_saved: number;
  };
  flows: FlowCardSummary[];
}

export interface FlowKpis {
  runs: number;
  finished_runs: number;
  succeeded_runs: number;
  failed_runs: number;
  attention_runs: number;
  success_rate: number | null;
  p50_duration_ms: number;
  p95_duration_ms: number;
  total_cost_usd: number;
  avg_cost_usd: number;
  budget_utilisation: number | null;
  total_tokens: number;
  automated_steps: number;
  hours_saved: number;
}

export interface FlowDailyPoint {
  date: string;
  runs: number;
  succeeded: number;
  failed: number;
  attention: number;
  success_rate: number | null;
  cost_usd: number;
  tokens: number;
  p50_duration_ms: number | null;
}

export interface FlowRunRow {
  id: string;
  run_number: number;
  title: string;
  status: string;
  trigger: string;
  triggered_by?: string | null;
  created_at?: string | null;
  started_at?: string | null;
  finished_at?: string | null;
  duration_ms: number;
  total_cost_usd: number;
  total_tokens: number;
  step_count: number;
  completed_step_count: number;
  summary?: string | null;
}

export interface FlowStepHealth {
  node_key: string;
  label: string;
  node_type: string;
  agent_key?: string | null;
  executions: number;
  success_rate: number | null;
  failures: number;
  retries: number;
  p50_duration_ms: number;
  p95_duration_ms: number;
  avg_cost_usd: number;
  total_cost_usd: number;
  total_tokens: number;
  avg_confidence: number | null;
  top_error?: string | null;
}

export interface FlowDashboard {
  flow: FlowHeader;
  window_days: number;
  kpis: FlowKpis;
  deltas: { runs: number; success_rate: number | null; p50_duration_ms: number | null; avg_cost_usd: number | null };
  daily: FlowDailyPoint[];
  triggers: { trigger: string; runs: number }[];
  step_health: FlowStepHealth[];
  recent_runs: FlowRunRow[];
  last_run: FlowRunRow | null;
  pending_approvals: {
    id: string;
    title: string;
    risk_level: string;
    required_role: string;
    created_at: string;
    run_id: string;
  }[];
  assumptions: { minutes_saved_per_step: number };
}

export interface FlowObservability {
  flow: FlowHeader;
  window_days: number;
  slo: {
    target_success_rate: number;
    success_rate: number | null;
    error_budget_remaining: number;
    status: 'healthy' | 'at_risk' | 'no_data';
  };
  latency: { p50_ms: number; p90_ms: number; p95_ms: number; max_ms: number };
  time_split: {
    agent_ms: number;
    human_wait_ms: number;
    orchestration_ms: number;
    avg_agent_ms_per_run: number;
    avg_human_wait_ms_per_run: number;
  };
  daily: FlowDailyPoint[];
  step_latency: Pick<
    FlowStepHealth,
    | 'node_key'
    | 'label'
    | 'node_type'
    | 'executions'
    | 'p50_duration_ms'
    | 'p95_duration_ms'
    | 'retries'
    | 'failures'
    | 'avg_confidence'
    | 'total_tokens'
    | 'total_cost_usd'
  >[];
  models: {
    provider: string;
    model: string;
    calls: number;
    tokens: number;
    cost_usd: number;
    errors: number;
    fallbacks: number;
    p50_latency_ms: number;
    p95_latency_ms: number;
    error_rate: number | null;
  }[];
  llm_totals: { calls: number; tokens: number; cost_usd: number; fallbacks: number; errors: number };
  failures: { step: string; signature: string; count: number }[];
  retries: number;
  events: {
    id: string;
    run_id: string;
    run_number?: number | null;
    event_type: string;
    content: string;
    created_at: string;
  }[];
}

export interface PostureCheck {
  key: string;
  title: string;
  status: 'pass' | 'warn' | 'fail';
  detail: string;
}

export interface FlowGovernance {
  flow: FlowHeader;
  window_days: number;
  posture: { score: number; passed: number; total: number; checks: PostureCheck[] };
  settings: FlowGovernanceSettings & { owner?: string | null; cost_budget_usd: number; token_budget: number };
  controls: {
    node_key: string;
    label: string;
    node_type: string;
    agent_name?: string | null;
    risk_level?: string | null;
    human_gate: boolean;
    approval_role?: string | null;
    agent_version?: string | null;
    version_pinned: boolean;
    cost_limit_usd?: number | null;
    retry?: number | null;
    timeout_seconds?: number | null;
  }[];
  approvals: {
    total: number;
    by_status: Record<string, number>;
    median_decision_hours: number | null;
    recent: {
      id: string;
      title: string;
      status: string;
      risk_level: string;
      required_role: string;
      decided_by?: string | null;
      decision_notes?: string | null;
      created_at: string;
      decided_at?: string | null;
    }[];
  };
  budget: {
    per_run_budget_usd: number;
    alert_threshold_usd: number;
    runs_over_alert: number;
    max_run_cost_usd: number;
    avg_run_cost_usd: number;
  };
  policies: {
    key: string;
    name: string;
    policy_type: string;
    effect: string;
    severity: string;
    enforcement_count: number;
  }[];
  versions: {
    version: string;
    change_summary?: string | null;
    published_at?: string | null;
    created_at: string;
    created_by?: string | null;
  }[];
  audit: {
    id: string;
    actor: string;
    action: string;
    entity_type: string;
    entity_label?: string | null;
    outcome: string;
    severity: string;
    reason?: string | null;
    created_at: string;
  }[];
}

export interface FlowReport {
  title: string;
  project: string | null;
  generated_at: string;
  period: { days: number; from: string; to: string };
  flow: FlowHeader;
  highlights: string[];
  kpis: FlowKpis;
  deltas: FlowDashboard['deltas'];
  daily: FlowDailyPoint[];
  step_health: FlowStepHealth[];
  slo: FlowObservability['slo'];
  latency: FlowObservability['latency'];
  models: FlowObservability['models'];
  failures: FlowObservability['failures'];
  posture: FlowGovernance['posture'];
  approvals: FlowGovernance['approvals'];
  budget: FlowGovernance['budget'];
  recent_runs: FlowRunRow[];
  recommendations: { priority: 'high' | 'medium' | 'low'; title: string; detail: string }[];
  assumptions: { minutes_saved_per_step: number };
}

export interface FlowApiToken {
  token: string;
  hint: string;
  endpoint: string;
  example: string;
}

/* -------------------------------------------------------------------------- */

export interface RunStep {
  id: string;
  node_key: string;
  node_type: string;
  label: string;
  sequence: number;
  status: string;
  agent_id?: string | null;
  agent_key?: string | null;
  attempt: number;
  started_at?: string | null;
  finished_at?: string | null;
  duration_ms: number;
  inputs: Record<string, unknown>;
  output: AgentOutput;
  reasoning_summary?: string | null;
  evidence: EvidenceItem[];
  tool_calls: ToolCall[];
  artifacts: ArtifactRef[];
  confidence?: number | null;
  policy_decision: Record<string, unknown>;
  provider?: string | null;
  model?: string | null;
  deployment?: string | null;
  total_tokens: number;
  cost_usd: number;
  error?: string | null;
}

/** The structured agent output contract (spec §28). */
export interface AgentOutput {
  status?: string;
  confidence?: number;
  summary?: string;
  findings?: Record<string, unknown>[];
  recommendations?: Record<string, unknown>[];
  artifacts?: Record<string, unknown>[];
  next_action?: string | null;
  outputs?: Record<string, unknown>;
}

export interface EvidenceItem {
  ref?: string;
  title?: string;
  source_type?: string;
  external_id?: string;
  document_id?: string;
  module?: string;
  score?: number;
  type?: string;
  detail?: string;
}

export interface ToolCall {
  server: string;
  tool: string;
  success: boolean;
  duration_ms?: number;
  error?: string | null;
  arguments?: Record<string, unknown>;
}

export interface ArtifactRef {
  type?: string;
  label?: string;
  entity_type?: string;
  entity_id?: string;
  [key: string]: unknown;
}

export interface RunSummary {
  id: string;
  project_id: string;
  flow_id?: string | null;
  agent_id?: string | null;
  run_number: number;
  title: string;
  kind: string;
  status: string;
  trigger: string;
  started_at?: string | null;
  finished_at?: string | null;
  duration_ms: number;
  total_tokens: number;
  total_cost_usd: number;
  step_count: number;
  completed_step_count: number;
  summary?: string | null;
  triggered_by?: string | null;
  created_at?: string | null;
}

export interface RunDetail extends RunSummary {
  correlation_id: string;
  flow_version?: string | null;
  environment_id?: string | null;
  inputs: Record<string, unknown>;
  outputs: Record<string, AgentOutput>;
  variables: Record<string, unknown>;
  error?: string | null;
  prompt_tokens: number;
  completion_tokens: number;
  steps: RunStep[];
}

/* -------------------------------------------------------------------------- */

export interface RequirementRecord {
  id: string;
  external_key: string;
  title: string;
  description?: string | null;
  module: string;
  status: string;
  priority: string;
  epic?: string | null;
  sprint?: string | null;
  story_points?: number | null;
  acceptance_criteria: string[];
  labels: string[];
  risk_score: number;
  change_frequency: number;
  completeness_score?: number | null;
  completeness_findings: Record<string, unknown>[];
  last_analyzed_at?: string | null;
}

export interface ScenarioRecord {
  id: string;
  key: string;
  title: string;
  description?: string | null;
  scenario_type: string;
  module: string;
  priority: string;
  risk_level: string;
  requirement_id?: string | null;
  generated_by_agent?: string | null;
  confidence?: number | null;
}

export interface TestStep {
  step: number;
  action: string;
  data?: string | null;
}

export interface TestCaseRecord {
  id: string;
  key: string;
  title: string;
  objective?: string | null;
  module: string;
  test_type: string;
  priority: string;
  preconditions: string[];
  steps: TestStep[];
  expected_result?: string | null;
  is_automated: boolean;
  automation_status: string;
  scenario_id?: string | null;
  requirement_id?: string | null;
  duplicate_of_id?: string | null;
  duplicate_similarity?: number | null;
  last_result?: string | null;
  last_executed_at?: string | null;
  execution_count: number;
  failure_count: number;
  flakiness_score: number;
  avg_duration_ms: number;
}

export interface TestScript {
  id: string;
  name: string;
  framework: string;
  language: string;
  file_path: string;
  code: string;
  page_objects: { name: string; file_path: string; code: string }[];
  locators: { name: string; description: string; strategy: string; locator: string; confidence: number }[];
  version: number;
  status: string;
  test_case_id?: string | null;
  generated_by_agent?: string | null;
  healing_count: number;
  quality_notes: string[];
}

export interface TestDataSet {
  id: string;
  name: string;
  description?: string | null;
  module: string;
  data_type: string;
  record_count: number;
  contains_pii: boolean;
  masking_applied: boolean;
  schema_definition: { fields?: string[] };
  records: Record<string, unknown>[];
  sql_scripts: { name: string; purpose: string; sql: string }[];
  generated_by_agent?: string | null;
  updated_at?: string | null;
}

/* -------------------------------------------------------------------------- */

export interface ExecutionTestRecord {
  id: string;
  name: string;
  module: string;
  result: string;
  duration_ms: number;
  retry_count: number;
  failure_message?: string | null;
  failure_category?: string | null;
  failure_signature?: string | null;
  stack_trace?: string | null;
  console_logs: { level: string; message: string }[];
  network_logs: { url: string; status: number; duration_ms: number }[];
  healed: boolean;
  test_case_id?: string | null;
  test_script_id?: string | null;
}

export interface ExecutionSummary {
  id: string;
  name: string;
  execution_number: number;
  suite_type: string;
  status: string;
  browser: string;
  mode: string;
  project_id: string;
  environment_id?: string | null;
  started_at?: string | null;
  finished_at?: string | null;
  duration_ms: number;
  total_tests: number;
  passed: number;
  failed: number;
  skipped: number;
  flaky: number;
  healed: number;
  pass_rate: number;
  failure_categories: Record<string, number>;
  defects_created: number;
  triggered_by?: string | null;
  created_at?: string | null;
}

export interface ExecutionDetail extends ExecutionSummary {
  parallelism: number;
  headless: boolean;
  trigger: string;
  config: Record<string, unknown>;
  ai_findings: Record<string, unknown>[];
  tests: ExecutionTestRecord[];
}

/* -------------------------------------------------------------------------- */

export interface DefectRecord {
  id: string;
  external_key?: string | null;
  title: string;
  description?: string | null;
  module: string;
  status: string;
  severity: string;
  priority: string;
  source: string;
  is_ai_suggested: boolean;
  ai_confidence?: number | null;
  cluster_key?: string | null;
  duplicate_of_id?: string | null;
  failure_signature?: string | null;
  steps_to_reproduce: string[];
  evidence: EvidenceItem[];
  labels: string[];
  assigned_to?: string | null;
  reported_by?: string | null;
  execution_id?: string | null;
  test_case_id?: string | null;
  requirement_id?: string | null;
  resolved_at?: string | null;
  resolution_notes?: string | null;
  jira_sync_state: string;
  created_at?: string | null;
}

export interface RcaRecord {
  id: string;
  title: string;
  probable_root_cause: string;
  category: string;
  confidence: number;
  status: string;
  evidence: EvidenceItem[];
  contributing_factors: { signal?: string; weight?: number }[];
  affected_tests: Record<string, unknown>[];
  historical_similarity: { score: number; excerpt: string }[];
  related_code_changes: { sha?: string; message?: string }[];
  recommended_action?: string | null;
  defect_id?: string | null;
  execution_id?: string | null;
  agent_key?: string | null;
  reviewed_by?: string | null;
  created_at?: string | null;
}

export interface DefectPrediction {
  id: string;
  target_ref: string;
  module: string;
  probability: number;
  predicted_severity: string;
  risk_band: string;
  drivers: { driver: string; weight: number; detail: string }[];
  recommended_actions: string[];
  horizon_days: number;
  created_at?: string | null;
}

/** One distinct problem, and every test it broke. */
export interface FailureCluster {
  signature: string;
  size: number;
  representative_message: string;
  test_ids: string[];
  test_names: string[];
  modules: string[];
  classification: {
    category: string;
    label: string;
    owner: string;
    healable: boolean;
    change_type: string | null;
    guidance: string;
    confidence: number;
    matched: string[];
    runner_up: string | null;
    /** The message did not decide it; a person or a model should look. */
    needs_review: boolean;
  };
}

export interface ExecutionTriage {
  execution_id: string;
  execution_name: string;
  failures: number;
  distinct_causes: number;
  /** How many investigations grouping removed. */
  investigations_saved: number;
  by_category: Record<string, number>;
  healable_causes: number;
  healable_failures: number;
  needs_review_causes: number;
  largest_cluster: FailureCluster | null;
  clusters: FailureCluster[];
}

export interface ConfidenceSignal {
  signal: string;
  score: number;
  weight: number;
  contribution: number;
}

export interface HealingRecord {
  id: string;
  status: string;
  failure_class: string;
  /** What the change touches; the healing policy matrix is applied to this. */
  change_type: string;
  original_locator: string;
  proposed_locator: string;
  locator_strategy: string;
  candidates: { strategy: string; locator: string; confidence: number }[];
  reason: string;
  confidence: number;
  confidence_breakdown: ConfidenceSignal[];
  evidence: EvidenceItem[];
  policy_decision: Record<string, unknown>;
  patch: Record<string, unknown>;
  result_before?: string | null;
  /** Written only by a re-run. Empty means nothing has been proven yet. */
  result_after?: string | null;
  validation_status: 'not_started' | 'running' | 'passed' | 'failed' | 'inconclusive';
  validation_mode?: string | null;
  validation_evidence: EvidenceItem[];
  validation_execution_id?: string | null;
  validated_at?: string | null;
  attempt_count: number;
  rolled_back_at?: string | null;
  approval_request_id?: string | null;
  approver?: string | null;
  approved_at?: string | null;
  script_version_before?: number | null;
  script_version_after?: number | null;
  test_script_id?: string | null;
  created_at?: string | null;
}

export interface RegressionAnalysis {
  id: string;
  name: string;
  changed_modules: string[];
  changed_requirements: string[];
  selected_tests: Record<string, unknown>[];
  skipped_tests: Record<string, unknown>[];
  risk_score: number;
  baseline_duration_ms: number;
  optimized_duration_ms: number;
  reduction_percent: number;
  rationale?: string | null;
  created_at?: string | null;
}

export interface DefectInsights {
  total: number;
  open: number;
  resolved: number;
  ai_suggested: number;
  by_status: Record<string, number>;
  by_severity: Record<string, number>;
  by_module: Record<string, number>;
  clusters: { cluster: string; count: number }[];
  mean_resolution_days?: number | null;
  healing: {
    total: number;
    applied: number;
    pending_review: number;
    mean_confidence?: number | null;
  };
}

/* -------------------------------------------------------------------------- */

export interface TraceabilityRow {
  requirement: {
    id: string;
    key: string;
    title: string;
    module: string;
    priority: string;
    status: string;
    risk_score: number;
    acceptance_criteria_count: number;
  };
  scenarios: {
    id: string;
    key: string;
    title: string;
    type: string;
    test_cases: {
      id: string;
      key: string;
      title: string;
      priority: string;
      is_automated: boolean;
      last_result?: string | null;
      execution_count: number;
      scripts: { id: string; file_path: string; framework: string }[];
      defects: { id: string; key: string; title: string; severity: string; status: string }[];
    }[];
  }[];
  counts: {
    scenarios: number;
    test_cases: number;
    automated: number;
    executed: number;
    defects: number;
  };
  status: string;
}

export interface TraceabilityMatrix {
  rows: TraceabilityRow[];
  summary: {
    requirements: number;
    covered: number;
    uncovered: number;
    uncovered_keys: string[];
    modules: string[];
  };
}

/* -------------------------------------------------------------------------- */

export interface KnowledgeSource {
  id: string;
  key: string;
  name: string;
  description?: string | null;
  source_type: string;
  connector_mode: string;
  sync_status: string;
  sync_schedule: string;
  is_enabled: boolean;
  last_synced_at?: string | null;
  document_count: number;
  chunk_count: number;
  collection_name: string;
}

export interface KnowledgeDocument {
  id: string;
  external_id: string;
  title: string;
  source_type: string;
  artifact_type: string;
  module: string;
  version: number;
  url?: string | null;
  author?: string | null;
  index_status: string;
  indexed_at?: string | null;
  chunk_count: number;
  tags: string[];
}

export interface KnowledgeSearchHit {
  id: string;
  content: string;
  score: number;
  metadata: Record<string, string | number | boolean>;
}

export interface KnowledgeOverview {
  source_count: number;
  document_count: number;
  chunk_count: number;
  indexed_documents: number;
  index_coverage: number;
  documents_by_source_type: Record<string, number>;
  vector_store: VectorHealth;
  last_sync_at?: string | null;
}

export interface VectorCollection {
  name: string;
  description: string;
  vector_count: number;
  status: string;
  error?: string;
}

export interface VectorHealth {
  provider: string;
  status: string;
  mode: string;
  detail?: string;
  persist_directory?: string | null;
  host?: string | null;
  port?: number | null;
  collections: VectorCollection[];
  total_vectors: number;
}

/* -------------------------------------------------------------------------- */

export interface GovernancePolicy {
  id: string;
  key: string;
  name: string;
  description?: string | null;
  policy_type: string;
  effect: string;
  scope: string;
  conditions: Record<string, unknown>;
  parameters: Record<string, unknown>;
  severity: string;
  is_enabled: boolean;
  priority: number;
  enforcement_count: number;
  last_enforced_at?: string | null;
  project_id?: string | null;
}

export interface ApprovalRequest {
  id: string;
  title: string;
  reason: string;
  risk_level: string;
  status: string;
  required_role: string;
  subject_type: string;
  subject_ref?: string | null;
  requested_by?: string | null;
  decided_by?: string | null;
  decided_at?: string | null;
  decision_notes?: string | null;
  expires_at?: string | null;
  context: Record<string, unknown>;
  proposed_action: Record<string, unknown>;
  run_id?: string | null;
  project_id: string;
  created_at?: string | null;
}

export interface AuditLogEntry {
  id: string;
  actor: string;
  actor_type: string;
  action: string;
  entity_type: string;
  entity_id?: string | null;
  entity_label?: string | null;
  reason?: string | null;
  outcome: string;
  severity: string;
  tool_used?: string | null;
  model_used?: string | null;
  confidence?: number | null;
  policy_result: Record<string, unknown>;
  correlation_id?: string | null;
  run_id?: string | null;
  created_at?: string | null;
}

/* -------------------------------------------------------------------------- */

export interface ProviderStatus {
  provider: string;
  display_name?: string;
  status: string;
  configured: boolean;
  detail?: string;
  is_default?: boolean;
  endpoint?: string | null;
  api_version?: string;
  deployments?: Record<string, string | null>;
  models?: Record<string, string> | string[];
}

export interface CostBreakdown {
  window_days: number;
  total_cost_usd: number;
  total_tokens: number;
  total_calls: number;
  avg_latency_ms: number;
  by_agent: { key: string; cost_usd: number; tokens: number; calls: number }[];
  by_model: { key: string; cost_usd: number; tokens: number; calls: number }[];
  by_provider: { key: string; cost_usd: number; tokens: number; calls: number }[];
  by_capability: { key: string; cost_usd: number; tokens: number; calls: number }[];
}

export interface McpTool {
  name: string;
  description: string;
  parameters: { name: string; type: string; description: string; required: boolean; enum?: string[] }[];
  mutating: boolean;
  risk_level: string;
  requires_approval: boolean;
}

export interface McpServer {
  key: string;
  name: string;
  description: string;
  icon: string;
  is_enabled: boolean;
  connector_mode: string;
  status: string;
  health: Record<string, unknown>;
  tools: McpTool[];
  allowed_tools: string[];
  requires_approval_tools: string[];
}

/* -------------------------------------------------------------------------- */

export interface DashboardData {
  window_days: number;
  kpis: {
    automation_coverage: number;
    requirement_coverage: number;
    regression_optimization: number;
    defect_prediction_accuracy: number | null;
    test_pass_rate: number;
    flaky_test_rate: number;
    mean_time_to_diagnose_hours: number | null;
    ai_automation_rate: number;
    ai_cost_usd: number;
    human_approval_rate: number;
  };
  deltas: { test_pass_rate_pp: number };
  totals: Record<string, number>;
  charts: {
    execution_trend: {
      date: string;
      name: string;
      passed: number;
      failed: number;
      skipped: number;
      flaky: number;
      pass_rate: number;
      duration_minutes: number;
    }[];
    defect_trend: { date: string; opened: number; resolved: number; open: number }[];
    failure_categories: { category: string; label: string; count: number; share: number }[];
    agent_utilization: {
      agent_key: string;
      agent_name: string;
      invocations: number;
      tokens: number;
      cost_usd: number;
      avg_latency_ms: number;
    }[];
    coverage_by_module: {
      module: string;
      requirements: number;
      covered: number;
      automated: number;
      test_cases: number;
      defects: number;
      coverage: number;
      automation: number;
    }[];
    quality_risk: { module: string; probability: number; risk_band: string }[];
    cost_by_agent: { key: string; cost_usd: number; tokens: number; calls: number }[];
  };
  summary: string;
}

/** Live event pushed over the run/execution WebSocket. */
export interface StreamEvent {
  topic: string;
  type: string;
  timestamp: string;
  payload: Record<string, unknown>;
}


/* -------------------------------------------------------------------------- */
/* Copilot                                                                    */
/* -------------------------------------------------------------------------- */

export interface CopilotAgentCandidate {
  agent_id: string;
  agent_key: string;
  name: string;
  category: string;
  risk_level: string;
  requires_approval: boolean;
  score: number;
  semantic_score: number;
  intent_score: number;
  rationale: string;
}

export interface CopilotMessage {
  id: string;
  sequence: number;
  role: 'user' | 'assistant' | 'system';
  content: string;
  plan_kind?: string | null;
  intent?: string | null;
  intent_confidence?: number | null;
  considered_agents?: CopilotAgentCandidate[];
  selected_agents?: CopilotAgentCandidate[];
  extracted_entities?: Record<string, unknown>;
  reasoning_summary?: string | null;
  run_id?: string | null;
  evidence?: unknown[];
  artifacts?: unknown[];
  suggestions?: unknown[];
  navigation?: Record<string, unknown>;
  provider?: string | null;
  model?: string | null;
  total_tokens?: number;
  cost_usd?: number;
  duration_ms?: number;
  policy_decision?: Record<string, unknown>;
  is_voice?: boolean;
  feedback?: 'up' | 'down' | null;
  feedback_note?: string | null;
  created_at?: string | null;
}

/** A figure an answer was built from, shown as a chip under the reply. */
export interface CopilotFact {
  type: string;
  label?: string;
  value?: string;
  detail?: string | null;
  title?: string;
}

export interface CopilotTurn {
  conversation_id: string;
  title: string;
  message: CopilotMessage;
}

export interface CopilotCapabilities {
  intents: { key: string; label: string; example: string }[];
  starters: { label: string; prompt: string }[];
  modules: string[];
}

export interface CopilotConversation {
  id: string;
  title: string;
  project_id: string;
  message_count: number;
  total_tokens: number;
  total_cost_usd: number;
  last_message_at?: string | null;
  created_at?: string | null;
}

/* ---- Agent collaboration ------------------------------------------------- */

export type CollaborationNodeState =
  | 'pending'
  | 'running'
  | 'succeeded'
  | 'failed'
  | 'awaiting_approval'
  | 'not_reached'
  | 'skipped'
  | 'cancelled';

export interface CollaborationNode {
  node_key: string;
  node_type: string;
  label: string;
  position_x: number;
  position_y: number;
  agent_key?: string | null;
  agent_name?: string | null;
  agent_icon?: string | null;
  risk_level?: string | null;
  state: CollaborationNodeState;
  step_id?: string | null;
  sequence?: number | null;
  attempt?: number | null;
  started_at?: string | null;
  finished_at?: string | null;
  duration_ms: number;
  confidence?: number | null;
  cost_usd: number;
  tokens: number;
  summary?: string | null;
  decision?: boolean | null;
  error?: string | null;
  approval_role?: string | null;
  requires_approval?: boolean;
  condition_expression?: string | null;
}

export interface CollaborationEdge {
  id: string;
  source: string;
  target: string;
  branch_label?: string | null;
  state: 'pending' | 'active' | 'traversed' | 'not_taken';
  handoff?: { summary: string; highlights: { label: string; value: number | string }[] } | null;
}

export interface CollaborationParticipant {
  key: string;
  name: string;
  kind: 'orchestrator' | 'agent' | 'decision' | 'gate' | 'human';
  icon: string;
  subtitle: string;
  color_index: number | null;
}

export type CollaborationMessageKind =
  | 'kickoff'
  | 'acknowledge'
  | 'handoff'
  | 'decision'
  | 'approval_request'
  | 'approval_decision'
  | 'retry'
  | 'failure'
  | 'complete';

export interface CollaborationMessage {
  id: string;
  index: number;
  at: string;
  kind: CollaborationMessageKind;
  from: string;
  to: string[];
  text: string;
  node_key?: string | null;
  node_state?: CollaborationNodeState | null;
  edges: string[];
  data: {
    confidence?: number | null;
    highlights?: { label: string; value: number | string }[];
    duration_ms?: number;
    cost_usd?: number;
    tools?: string[];
    context_key?: string;
    inputs?: Record<string, string>;
    reads?: { from: string; path: string; value?: string }[];
    expression?: string;
    result?: boolean;
    risk_level?: string;
    required_role?: string;
    decision?: string;
    status?: string;
  };
}

export interface SharedContextEntry {
  key: string;
  kind: 'input' | 'agent_result' | 'decision' | 'approval';
  written_by: string;
  written_at?: string | null;
  preview: string;
  used_by: string[];
  available_to?: string[];
  fields?: string[];
}

export interface RunCollaboration {
  run: {
    id: string;
    run_number: number;
    title: string;
    status: string;
    trigger: string;
    triggered_by?: string | null;
    started_at?: string | null;
    finished_at?: string | null;
    duration_ms: number;
    flow_id?: string | null;
    flow_name?: string | null;
    flow_version?: string | null;
    is_live: boolean;
  };
  graph: { nodes: CollaborationNode[]; edges: CollaborationEdge[] };
  participants: CollaborationParticipant[];
  conversation: CollaborationMessage[];
  context: SharedContextEntry[];
  stats: {
    agents: number;
    messages: number;
    handoffs: number;
    decisions: number;
    human_decisions: number;
    shared_facts: number;
  };
}

/** Healing analytics, counted from records the platform wrote. */
export interface HealingAnalytics {
  project_id: string;
  window: { days: number; label: string; start: string };
  as_of: string;
  totals: {
    proposed: number;
    decided: number;
    applied: number;
    /** Applied *and* proved by a re-run. The only thing counted as success. */
    proven: number;
    /** Applied before validation was required; excluded from the success rate. */
    unproven_applied: number;
    rolled_back: number;
    rejected: number;
    blocked: number;
    awaiting_decision: number;
    success_rate: number;
    success_rate_basis: string;
  };
  by_change_type: { change_type: string; proposed: number; decided: number; proven: number; success_rate: number }[];
  by_strategy: { strategy: string; proposed: number; proven: number; success_rate: number; mean_confidence: number }[];
  by_failure_class: Record<string, number>;
  confidence: {
    mean_when_proven: number | null;
    mean_when_failed: number | null;
    sample_proven: number;
    sample_failed: number;
    /** Positive means confidence predicted which repairs held. */
    separation: number | null;
    note: string;
  };
  validation: {
    by_status: Record<string, number>;
    by_mode: Record<string, number>;
    mean_attempts: number;
    simulated_share: number | null;
  };
  trend: { date: string; proposed: number; proven: number; rolled_back: number }[];
  queue: {
    awaiting_decision: number;
    oldest_hours: number;
    by_change_type: Record<string, number>;
    needing_approval_by_policy: number;
  };
  effort: {
    repairs_that_held: number;
    minutes_per_repair: number;
    minutes_saved: number;
    hours_saved: number;
    basis: string;
  };
  evidence: {
    executions_by_mode: Record<string, number>;
    failed_tests: number;
    real_browser_share: number | null;
  };
  recent: {
    id: string;
    change_type: string;
    failure_class: string;
    strategy: string;
    status: string;
    validation_status: string;
    confidence: number;
    from: string;
    to: string;
    approver: string | null;
    created_at: string | null;
  }[];
}


/** How a third party calls one agent or flow. Served by `/api-access`. */
export interface ApiAccess {
  kind: 'agent' | 'flow';
  id: string;
  name: string;
  available: boolean;
  unavailable_reason: string | null;
  endpoint: { method: string; path: string; url: string };
  authentication: {
    scheme: string;
    header: string;
    scope_required: string;
    issued_by: string;
  };
  input_schema: Record<string, unknown>;
  example: { body: Record<string, unknown>; curl: string };
  polling: { note: string; path: string };
  mcp: { tool: string; endpoint: string; note: string };
  documentation: { quickstart: string; openapi: string; swagger: string };
  keys: {
    name: string;
    platform: string | null;
    token_hint: string;
    grant: 'project-wide' | 'named explicitly';
    expires_at: string | null;
  }[];
}


/** An API key as an operator sees it. The token itself is never in here. */
export interface IntegrationClientOut {
  id: string;
  project_id: string;
  name: string;
  description: string | null;
  platform: string | null;
  token_hint: string;
  scopes: string[];
  allowed_flow_ids: string[];
  allowed_agent_keys: string[];
  grants_all_flows: boolean;
  grants_all_agents: boolean;
  is_active: boolean;
  rate_limit_per_minute: number;
  callback_url: string | null;
  expires_at: string | null;
  last_used_at: string | null;
  call_count: number;
  created_at: string;
}

/** The same, plus the token — returned once, at creation or rotation. */
export interface IntegrationClientCreated extends IntegrationClientOut {
  token: string;
}

export interface IntegrationClientCreate {
  project_id: string;
  name: string;
  description?: string | null;
  platform?: string | null;
  scopes?: string[];
  allowed_flow_ids?: string[];
  allowed_agent_keys?: string[];
  grants_all_flows?: boolean;
  grants_all_agents?: boolean;
  rate_limit_per_minute?: number;
  expires_in_days?: number | null;
}

/** What `/integration/me` tells the holder of a key about itself. */
export interface ApiIdentity {
  authenticated: true;
  client: {
    name: string;
    platform: string | null;
    description: string | null;
    project_id: string;
    token_hint: string;
    created_at: string | null;
  };
  scopes: { granted: string[]; meaning: Record<string, string> };
  provisioned: {
    flows: number;
    agents: number;
    all_flows_in_project: boolean;
    all_agents_in_project: boolean;
  };
  validity: { active: boolean; expires_at: string | null; expired: boolean };
  limits: { rate_limit_per_minute: number };
  usage: { calls: number; last_used_at: string | null };
  activity: {
    runs_total: number;
    runs_by_disposition: Record<string, number>;
    in_flight: number;
    total_cost_usd: number;
    last_run_at: string | null;
  };
}

export interface ApiCatalogEntry {
  id?: string;
  key?: string;
  name: string;
  description: string | null;
  category: string | null;
  status?: string;
  invoke: { method: string; path: string; scope: string };
  input_schema: Record<string, unknown>;
  guardrails?: { requires_approval?: boolean; risk_level?: string | null };
}

export interface ApiCatalog {
  project_id: string;
  flows: ApiCatalogEntry[];
  agents: ApiCatalogEntry[];
  counts: { flows: number; agents: number };
}

export interface ApiRunSummary {
  run_id: string;
  run_number: number;
  title: string | null;
  kind: string;
  status: string;
  disposition: string;
  is_terminal: boolean;
  flow_id: string | null;
  started_at: string | null;
  finished_at: string | null;
  duration_ms: number | null;
  summary: string | null;
  error: string | null;
  progress: { completed_steps: number; total_steps: number };
  guardrails: { awaiting_approval: { title: string; required_role: string }[] };
  links: { self: string; cancel: string };
}

export interface ApiRunPage {
  items: ApiRunSummary[];
  total: number;
  limit: number;
  offset: number;
}

/**
 * A system the customer owns, connected to their project.
 *
 * There is no field here for a credential, and that is deliberate rather than
 * an omission: the server has no route that returns one. A screen can show
 * which fields a kind takes (`credential_fields`), that one is stored
 * (`has_credentials`) and that it changed (`credential_fingerprint`).
 */
export interface DataSource {
  id: string;
  project_id: string;
  key: string;
  name: string;
  description: string | null;
  kind: string;
  status: 'unverified' | 'connected' | 'error' | 'disabled';
  is_enabled: boolean;
  allow_writes: boolean;
  config: Record<string, unknown>;
  credential_fields: string[];
  has_credentials: boolean;
  credential_fingerprint: string | null;
  credential_updated_at: string | null;
  credential_updated_by: string | null;
  last_tested_at: string | null;
  last_test_ok: boolean | null;
  last_error: string | null;
  created_by: string | null;
  created_at: string;
}

export interface DataSourceKind {
  kind: string;
  required_fields: string[];
  optional_fields: string[];
  credential_fields: string[];
}

/** What a connection test actually proved, which is not always what was hoped. */
export interface DataSourceTestResult {
  ok: boolean;
  check: string;
  detail: string;
  proves?: string;
  tested_at: string;
}

/**
 * The governance log of one run, as the integration API serves it
 * (`GET /integration/runs/{id}/log`). A versioned contract of its own: prompts,
 * tool arguments and the identity of platform users are never in it.
 */
export interface ApiRunLogActivity {
  sequence: number;
  node_key: string;
  kind: string;
  label: string | null;
  agent: { key: string; version: string | null } | null;
  status: string;
  attempt: number | null;
  started_at: string | null;
  finished_at: string | null;
  duration_ms: number | null;
  confidence: number | null;
  model: { provider: string; model: string; deployment: string | null } | null;
  usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number; cost_usd: number };
  tools: { server: string; tool: string; success: boolean; duration_ms: number | null; error: string | null }[];
  policy: { effect: string | null; requires_approval: boolean | null; policies: string[] } | null;
  error: string | null;
}

export interface ApiRunLog {
  schema_version: string;
  run: { run_id: string; disposition: string; duration_ms: number | null; correlation_id: string | null };
  activities: ApiRunLogActivity[];
  timeline: { sequence: number; at: string; type: string; message: string | null }[];
  approvals: { approval_id: string; title: string | null; required_role: string | null; status: string; decided_at: string | null }[];
  audit: { event_id: string; at: string; action: string; outcome: string }[];
  usage: { total_tokens: number; total_cost_usd: number; by_model: { provider: string; model: string; calls: number; fallback_calls: number }[] };
  redaction: { masked: Record<string, string>; omitted: string[] };
}

export interface ApiMetrics {
  schema_version: string;
  window: { days: number };
  runs: {
    total: number;
    by_disposition: Record<string, number>;
    success_rate: number | null;
    duration_ms: { p50: number | null; p95: number | null };
    total_cost_usd: number;
  };
  by_model: { provider: string; model: string; calls: number; failed_calls: number; fallback_calls: number }[];
  approvals: { requested: number; pending: number; median_wait_seconds: number | null };
}
