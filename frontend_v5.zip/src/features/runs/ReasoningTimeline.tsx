/**
 * Renders a `reasoning_summary` as a step-by-step log when the agent wrote it
 * with `[marker] LABEL: detail` sections (several built-in agents do, e.g.
 * `[1] INPUT: ... [2] SCORE: ...`) -- a small vertical timeline instead of one
 * dense paragraph. Detected from the text itself, not the agent, so every
 * agent that already follows the convention gets it for free. Text with fewer
 * than two markers falls back to the plain paragraph -- most agents' prose.
 */
import type { ComponentType } from 'react';
import {
  CheckCircle2, CircleDot, ClipboardList, ListChecks, RefreshCw, Search, ShieldCheck, Sparkles,
} from 'lucide-react';
import { cn } from '@/design-system/primitives';

interface LogStep {
  marker: string;
  label: string;
  detail: string;
}

const STEP_PATTERN = /\[([\w.]+)\]\s+([A-Z][A-Za-z/&\- ]*):\s*/g;

function parseSteps(text: string): LogStep[] {
  const matches = [...text.matchAll(STEP_PATTERN)];
  if (matches.length < 2) return [];
  return matches.map((match, index) => {
    const start = match.index! + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index! : text.length;
    return { marker: match[1], label: match[2].trim(), detail: text.slice(start, end).trim() };
  });
}

const ICON_BY_LABEL: Record<string, ComponentType<{ className?: string }>> = {
  INPUT: Search,
  'AI-ASSIST': Sparkles,
  SCORE: ClipboardList,
  BAND: ShieldCheck,
  SELECT: ListChecks,
  OUTPUT: CheckCircle2,
  LEARN: RefreshCw,
};

export function ReasoningTimeline({ text }: { text: string }) {
  const steps = parseSteps(text);

  if (!steps.length) {
    return <p className="text-sm leading-relaxed text-ink-secondary">{text}</p>;
  }

  return (
    <ol className="space-y-0">
      {steps.map((step, index) => {
        const Icon = ICON_BY_LABEL[step.label] ?? CircleDot;
        const isLast = index === steps.length - 1;
        return (
          <li key={index} className="flex gap-3">
            <div className="flex flex-col items-center">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-brand-200 bg-brand-50 text-brand-600">
                <Icon className="h-3.5 w-3.5" aria-hidden />
              </span>
              {!isLast ? <span className="w-px flex-1 bg-line" aria-hidden /> : null}
            </div>
            <div className={cn('min-w-0 flex-1', !isLast && 'pb-4')}>
              <p className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 pt-0.5">
                <span className="font-mono text-2xs font-semibold text-brand-600">[{step.marker}]</span>
                <span className="text-xs font-semibold uppercase tracking-wide text-ink">{step.label}</span>
              </p>
              <p className="mt-1 text-sm leading-relaxed text-ink-secondary">{step.detail}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
