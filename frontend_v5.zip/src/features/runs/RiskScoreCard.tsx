/**
 * A premium, RAG-coloured view of a weighted risk assessment (band, escalation
 * rule, 15 scored factors, test pack) -- the shape the Impact Analyzer Agent's
 * `outputs` returns. Detected structurally, from `outputs` carrying `band` +
 * `base_score` + `dimensions`, not from the agent's key, so any future agent
 * returning the same shape gets the same treatment for free instead of
 * needing its own bespoke view.
 *
 * Written for a non-technical reader (a release manager, a product owner) --
 * every label and sentence here is plain English on purpose. No "veto", no
 * raw weight arithmetic as the primary explanation, no jargon left
 * unexplained. See AGENT_ARCHITECTURE_REVIEW-style feedback that drove this.
 */
import { useState } from 'react';
import {
  AlertTriangle, ClipboardList, Gauge, ListChecks, Minus, MousePointerClick,
  ShieldAlert, ShieldCheck, TrendingDown, TrendingUp,
} from 'lucide-react';
import { Badge, Card, CardBody, CardHeader, ProgressBar, cn } from '@/design-system/primitives';

interface DimensionScore {
  key: string;
  label: string;
  weight: number;
  score: number;
  weighted: number;
  low_anchor?: string;
  high_anchor?: string;
}

interface SelectedTestRow {
  path: string;
  priority: string;
  journey?: string;
  reason: string;
}

interface InputConsidered {
  label: string;
  detail: string;
}

interface TestPack {
  automated: { count: number; description: string };
  manual: { required: boolean; description: string; suggested?: string[] };
}

interface RiskOutputs {
  change_id?: string;
  change_title?: string;
  band: string;
  band_before_veto: string;
  base_score: number;
  max_score: number;
  veto_triggered: string[];
  modifier: number;
  modifier_reading: string;
  coverage_commitment?: string;
  dimensions: DimensionScore[];
  selected_tests: SelectedTestRow[];
  test_counts_by_priority?: Record<string, number>;
  inputs_considered?: InputConsidered[];
  test_pack?: TestPack;
}

export function isRiskOutputs(value: unknown): value is RiskOutputs {
  if (!value || typeof value !== 'object') return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.band === 'string' &&
    typeof v.base_score === 'number' &&
    typeof v.max_score === 'number' &&
    Array.isArray(v.dimensions)
  );
}

type Severity = 'critical' | 'high' | 'medium' | 'low';

function severityOf(band: string): Severity {
  const key = band.split(' /')[0].trim().toLowerCase();
  return key === 'critical' || key === 'high' || key === 'medium' || key === 'low' ? key : 'medium';
}

const BAND_STYLE: Record<Severity, { badge: string; bar: 'danger' | 'warning' | 'success'; icon: typeof ShieldAlert }> = {
  critical: { badge: 'border-transparent bg-danger text-white', bar: 'danger', icon: ShieldAlert },
  high: { badge: 'bg-danger-bg text-danger-text border-danger-border', bar: 'danger', icon: ShieldAlert },
  medium: { badge: 'bg-warning-bg text-warning-text border-warning-border', bar: 'warning', icon: ShieldAlert },
  low: { badge: 'bg-success-bg text-success-text border-success-border', bar: 'success', icon: ShieldCheck },
};

const PRIORITY_TONE: Record<string, 'danger' | 'warning' | 'neutral'> = { P1: 'danger', P2: 'warning', P3: 'neutral' };

function scoreTone(score: number): 'success' | 'warning' | 'danger' {
  if (score >= 4) return 'danger';
  if (score === 3) return 'warning';
  return 'success';
}

export function RiskScoreCard({ outputs }: { outputs: RiskOutputs }) {
  const severity = severityOf(outputs.band);
  const style = BAND_STYLE[severity];
  const BandIcon = style.icon;
  const escalated = outputs.veto_triggered.length > 0;
  const testEntries = Object.entries(outputs.test_counts_by_priority ?? {}).sort(([a], [b]) => a.localeCompare(b));
  const labelByKey = new Map(outputs.dimensions.map((d) => [d.key, d.label]));
  const escalatedByLabels = outputs.veto_triggered.map((key) => labelByKey.get(key) ?? key).join(', ');

  return (
    <Card className="border-line-strong shadow-raised">
      <CardHeader
        title={outputs.change_title ? `${outputs.change_id ?? ''} — ${outputs.change_title}` : 'Risk assessment'}
        description="How risky this change is, and what testing it needs, scored against Wickes's own risk model"
        icon={<Gauge className="h-4 w-4" />}
      />
      <CardBody className="space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">Risk level</p>
            <span
              className={cn(
                'mt-1.5 inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-semibold',
                style.badge,
              )}
            >
              <BandIcon className="h-4 w-4" /> {outputs.band}
            </span>
          </div>
          <div className="text-right">
            <p className="text-2xs font-semibold uppercase tracking-wide text-ink-tertiary">Overall risk score</p>
            <p className="tabular mt-1 text-3xl font-semibold text-ink">
              {outputs.base_score}
              <span className="text-lg font-normal text-ink-tertiary">/{outputs.max_score}</span>
            </p>
          </div>
        </div>

        <ProgressBar value={outputs.base_score / outputs.max_score} tone={style.bar} className="h-2" label="Overall risk score" />

        {escalated ? (
          <div className="flex items-start gap-2.5 rounded border border-danger-border bg-danger-bg px-3.5 py-3">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-danger-text" aria-hidden />
            <p className="text-sm text-danger-text">
              <span className="font-semibold">Automatically raised to a higher risk level.</span>{' '}
              {escalatedByLabels} scored the maximum (5) —{' '}
              {outputs.band === outputs.band_before_veto
                ? `a score that high on any of these always puts a change at its risk level, and this change was already there (${outputs.band}) from its own score.`
                : `a score that high on any of these always moves a change up one risk level, so this went from ${outputs.band_before_veto} to ${outputs.band}.`}
            </p>
          </div>
        ) : null}

        <div>
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span className="font-medium text-ink">Risk direction check</span>
            <span
              className={cn(
                'tabular inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-xs font-semibold',
                outputs.modifier > 0
                  ? 'bg-danger-bg text-danger-text'
                  : outputs.modifier < 0
                    ? 'bg-success-bg text-success-text'
                    : 'bg-surface-sunken text-ink-secondary',
              )}
            >
              {outputs.modifier > 0 ? (
                <TrendingUp className="h-3 w-3" aria-hidden />
              ) : outputs.modifier < 0 ? (
                <TrendingDown className="h-3 w-3" aria-hidden />
              ) : (
                <Minus className="h-3 w-3" aria-hidden />
              )}
              {outputs.modifier > 0 ? `+${outputs.modifier}` : outputs.modifier}
            </span>
            <span className="text-ink-tertiary">({outputs.modifier_reading})</span>
          </div>
          <p className="mt-1 text-xs text-ink-tertiary">
            A separate check of how likely this is to cause a problem and how well it's being managed. It doesn't
            change the risk level above — it's an extra signal for whoever reviews this.
          </p>
        </div>

        {outputs.coverage_commitment ? (
          <p className="text-sm text-ink-secondary">
            <span className="font-medium text-ink">Testing coverage required at this level: </span>
            {outputs.coverage_commitment}
          </p>
        ) : null}

        {outputs.inputs_considered?.length ? <InputsConsideredSection inputs={outputs.inputs_considered} /> : null}

        <div>
          <p className="text-sm font-semibold text-ink">What we assessed</p>
          <p className="mb-2 text-xs text-ink-secondary">
            {outputs.dimensions.length} factors, each scored 1 (low risk) to 5 (high risk). Factors that matter more to
            risk count for more toward the total.
          </p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {outputs.dimensions.map((dimension) => (
              <DimensionChip
                key={dimension.key}
                dimension={dimension}
                canEscalate={outputs.veto_triggered.includes(dimension.key)}
              />
            ))}
          </div>
        </div>

        {outputs.test_pack || outputs.selected_tests.length ? (
          <TestPackSection testPack={outputs.test_pack} tests={outputs.selected_tests} testEntries={testEntries} />
        ) : null}
      </CardBody>
    </Card>
  );
}

function InputsConsideredSection({ inputs }: { inputs: InputConsidered[] }) {
  return (
    <div className="rounded border border-line bg-surface-muted px-4 py-3.5">
      <p className="text-sm font-semibold text-ink">What we used to work this out</p>
      <dl className="mt-2 space-y-2.5">
        {inputs.map((input) => (
          <div key={input.label}>
            <dt className="text-xs font-semibold uppercase tracking-wide text-ink-tertiary">{input.label}</dt>
            <dd className="mt-0.5 text-sm leading-relaxed text-ink-secondary">{input.detail}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

function DimensionChip({ dimension, canEscalate }: { dimension: DimensionScore; canEscalate: boolean }) {
  const tone = scoreTone(dimension.score);
  const toneText = { success: 'text-success-text', warning: 'text-warning-text', danger: 'text-danger-text' }[tone];
  const toneDot = { success: 'bg-success', warning: 'bg-warning', danger: 'bg-danger' }[tone];
  const toneBorder = { success: 'border-line', warning: 'border-warning-border', danger: 'border-danger-border' }[tone];
  const meaning = dimension.score >= 3 ? dimension.high_anchor : dimension.low_anchor;

  return (
    <div className={cn('rounded border bg-surface px-3 py-2', toneBorder)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-medium leading-snug text-ink">{dimension.label}</p>
        <span className={cn('tabular shrink-0 text-xs font-semibold', toneText)}>{dimension.score}/5</span>
      </div>
      <div className="mt-1.5 flex gap-0.5" aria-hidden>
        {[1, 2, 3, 4, 5].map((n) => (
          <span key={n} className={cn('h-1.5 flex-1 rounded-full', n <= dimension.score ? toneDot : 'bg-surface-sunken')} />
        ))}
      </div>
      {meaning ? <p className="mt-1.5 text-2xs leading-snug text-ink-secondary">{meaning}</p> : null}
      {canEscalate ? (
        <p className={cn('mt-1 flex items-center gap-1 text-2xs font-medium', toneText)}>
          <AlertTriangle className="h-3 w-3" aria-hidden /> This top score is why the risk level was raised (see above)
        </p>
      ) : null}
    </div>
  );
}

function TestPackSection({
  testPack,
  tests,
  testEntries,
}: {
  testPack?: TestPack;
  tests: SelectedTestRow[];
  testEntries: [string, number][];
}) {
  const [showAll, setShowAll] = useState(false);

  return (
    <div>
      <p className="text-sm font-semibold text-ink">Test pack: what needs to run</p>
      <p className="mb-2.5 text-xs text-ink-secondary">
        Split into tests that run by themselves, and testing that needs a person.
      </p>

      <div className="space-y-3">
        <div className="rounded border border-line px-3.5 py-3">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
              <ListChecks className="h-3.5 w-3.5 text-brand-600" aria-hidden />
              Automated -- {tests.length} test{tests.length === 1 ? '' : 's'}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {testEntries.map(([priority, count]) => (
                <Badge key={priority} tone={PRIORITY_TONE[priority] ?? 'neutral'}>
                  {priority}: {count}
                </Badge>
              ))}
            </div>
          </div>
          {testPack?.automated.description ? (
            <p className="mb-2 text-xs text-ink-secondary">{testPack.automated.description}</p>
          ) : null}
          {tests.length ? (
            <ul
              className={cn(
                'divide-y divide-line-subtle overflow-y-auto rounded border border-line-subtle print:max-h-none print:overflow-visible',
                showAll ? 'max-h-none' : 'max-h-72',
              )}
            >
              {tests.map((test, index) => (
                <li key={index} className="flex items-start gap-2.5 px-3 py-2">
                  <Badge tone={PRIORITY_TONE[test.priority] ?? 'neutral'} className="mt-0.5 shrink-0">
                    {test.priority}
                  </Badge>
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs text-ink">{test.path}</p>
                    <p className="mt-0.5 text-xs text-ink-secondary">{test.reason}</p>
                  </div>
                </li>
              ))}
            </ul>
          ) : null}
          {tests.length > 8 ? (
            <button
              type="button"
              onClick={() => setShowAll((v) => !v)}
              className="mt-2 text-2xs font-semibold text-brand-600 hover:underline print:hidden"
            >
              {showAll ? 'Show fewer' : `Show all ${tests.length}`}
            </button>
          ) : null}
        </div>

        <div
          className={cn(
            'rounded border px-3.5 py-3',
            testPack?.manual.required ? 'border-warning-border bg-warning-bg' : 'border-line',
          )}
        >
          <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
              <MousePointerClick
                className={cn('h-3.5 w-3.5', testPack?.manual.required ? 'text-warning-text' : 'text-ink-tertiary')}
                aria-hidden
              />
              Manual / exploratory
            </p>
            <Badge tone={testPack?.manual.required ? 'warning' : 'neutral'}>
              {testPack?.manual.required ? 'Required at this risk level' : 'Recommended'}
            </Badge>
          </div>
          {testPack?.manual.required ? (
            <p className="mb-2 flex items-start gap-1.5 text-sm text-warning-text">
              <ClipboardList className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              {testPack.manual.description}
            </p>
          ) : null}
          {testPack?.manual.suggested?.length ? (
            <ul className="space-y-1.5">
              {testPack.manual.suggested.map((item, index) => (
                <li key={index} className="flex items-start gap-1.5 text-sm text-ink-secondary">
                  <MousePointerClick className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-tertiary" aria-hidden />
                  {item}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-ink-secondary">No manual testing information available for this run.</p>
          )}
        </div>
      </div>
    </div>
  );
}
