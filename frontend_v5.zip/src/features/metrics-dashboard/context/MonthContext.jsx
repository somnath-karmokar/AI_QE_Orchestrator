import React, { createContext, useContext, useEffect, useState } from "react";
import { fetchAvailableMonths, monthLabelToId } from "../services/monthlyMetricsApi";

const MonthContext = createContext();

function sortMonthsDesc(labels) {
  return [...labels].sort((a, b) => monthLabelToId(b).localeCompare(monthLabelToId(a)));
}

// eslint-disable-next-line react-refresh/only-export-components
export const useMonth = () => {
  const context = useContext(MonthContext);
  if (!context) {
    throw new Error("useMonth must be used within MonthProvider");
  }
  return context;
};

export const MonthProvider = ({ children }) => {
  const [months, setMonths] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState("");

  useEffect(() => {
    let active = true;

    fetchAvailableMonths()
      .then((apiMonths) => {
        if (!active) return;
        if (!Array.isArray(apiMonths) || apiMonths.length === 0) {
          setMonths([]);
          setSelectedMonth("");
          return;
        }
        const sorted = [...apiMonths].sort((a, b) =>
          String(b?.month_id || "").localeCompare(String(a?.month_id || ""))
        );
        const labels = sorted.map((item) => item?.month).filter(Boolean);
        if (labels.length === 0) {
          setMonths([]);
          setSelectedMonth("");
          return;
        }
        setMonths(labels);
        setSelectedMonth(labels[0]);
      })
      .catch(() => {
        if (!active) return;
        setMonths([]);
        setSelectedMonth("");
      });

    return () => {
      active = false;
    };
  }, []);

  const value = {
    selectedMonth,
    setSelectedMonth,
    months,
  };

  return (
    <MonthContext.Provider value={value}>
      {children}
    </MonthContext.Provider>
  );
};
