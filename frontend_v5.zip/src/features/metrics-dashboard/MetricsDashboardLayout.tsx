/**
 * Integration glue for the ported metrics dashboard (src/features/metrics-dashboard/{pages,components,...}
 * is a near-verbatim port of a separate standalone app, kept as plain JSX --
 * see MEMORY / session notes for the source and what was changed).
 *
 * The dashboard's pages render their own Header/Footer rather than this
 * platform's AppShell, so it's mounted as a self-contained section reachable
 * from one sidebar entry rather than dissolved into the main navigation.
 * This layout only supplies the one context (`MonthProvider`) its pages
 * expect, exactly as the original app's own root component did.
 */
import { Outlet } from 'react-router-dom';
import { MonthProvider } from '@/features/metrics-dashboard/context/MonthContext';

export function MetricsDashboardLayout() {
  return (
    <MonthProvider>
      <Outlet />
    </MonthProvider>
  );
}
