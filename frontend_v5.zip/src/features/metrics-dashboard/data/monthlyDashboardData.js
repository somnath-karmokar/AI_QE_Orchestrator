/**
 * Static replacement for the live `/api/monthly-metrics/*` backend.
 *
 * The real backend serves per-month category/metric rows plus an AI-written
 * analysis object, cross-referenced by `category::metric::domain::portfolio::
 * project`. This module generates the same shape from a small hand-authored
 * table (real category/metric names, kept deterministic so values don't
 * jitter between renders) instead of hand-typing hundreds of data points.
 */

const MONTHS = [
  { month_id: "2026-04", month: "Apr 2026" },
  { month_id: "2026-05", month: "May 2026" },
  { month_id: "2026-06", month: "Jun 2026" },
  { month_id: "2026-07", month: "Jul 2026" },
  { month_id: "2026-08", month: "Aug 2026" },
  { month_id: "2026-09", month: "Sep 2026" },
];

const CONTEXTS = [
  { domain: "Commercial", portfolio: "Product & Planning", project: "Flex PLM" },
  { domain: "Shared Services", portfolio: "Tech", project: "Supply Chain MS" },
];

// target: "higher" metrics improve as the value rises; "lower" metrics
// improve as the value falls (defect counts, TAT, density, ...).
const CATEGORY_METRICS = {
  Engineering: [
    { name: "Unique GenAI Use cases", unit: "", base: 3, target: "higher", volatility: 1 },
    { name: "GenAI Adoption (%)", unit: "%", base: 42, target: "higher", volatility: 4 },
    { name: "Automation Adoption (%)", unit: "%", base: 68, target: "higher", volatility: 3 },
    { name: "CICD Adoption (%)", unit: "%", base: 74, target: "higher", volatility: 2 },
    { name: "Regression Automation(%)", unit: "%", base: 61, target: "higher", volatility: 3 },
    { name: "E2E Automation (%)", unit: "%", base: 55, target: "higher", volatility: 3 },
  ],
  Velocity: [
    { name: "Average Defect TAT for 1-Urgent and 2-High (in hours)", unit: "hrs", base: 18, target: "lower", volatility: 2 },
    { name: "Defect Density", unit: "", base: 2.1, target: "lower", volatility: 0.3 },
    { name: "Defect Re-Open %", unit: "%", base: 9, target: "lower", volatility: 2 },
    { name: "Environment availability %", unit: "%", base: 96, target: "higher", volatility: 1.5 },
    { name: "First Time Right for Build %", unit: "%", base: 82, target: "higher", volatility: 3 },
    { name: "Ontime delivery %", unit: "%", base: 88, target: "higher", volatility: 2.5 },
  ],
  Quality: [
    { name: "Automated Data Provisioning %", unit: "%", base: 64, target: "higher", volatility: 3 },
    { name: "Defect due to (Code, Config) from Defect RCA %", unit: "%", base: 34, target: "lower", volatility: 3 },
    { name: "Escape Defect to Prod", unit: "", base: 4, target: "lower", volatility: 1 },
    { name: "Escape Defect to UAT", unit: "", base: 7, target: "lower", volatility: 2 },
    { name: "Invalid Defects", unit: "", base: 5, target: "lower", volatility: 1 },
    { name: "Test case Traceability %", unit: "%", base: 91, target: "higher", volatility: 1.5 },
  ],
  Collaboration: [
    { name: "Audit compliance %", unit: "%", base: 97, target: "higher", volatility: 1 },
    { name: "Improvement Ideas submitted", unit: "", base: 6, target: "higher", volatility: 1.5 },
    { name: "Knowledge Sharing session", unit: "", base: 2, target: "higher", volatility: 0.8 },
    { name: "Learning Hours", unit: "hrs", base: 14, target: "higher", volatility: 2 },
    { name: "Optimization Initiatives undertaken", unit: "", base: 3, target: "higher", volatility: 1 },
    { name: "Reusable Knowledge Assets", unit: "", base: 8, target: "higher", volatility: 1.5 },
  ],
};

const INSIGHT_TITLES = ["Anomaly Detection", "Trend Forecasting", "Root Cause Analysis", "Prescriptive Recommendations"];

// Deterministic pseudo-random in [0, 1), seeded from a string so the same
// metric/context/month always generates the same value across renders.
function seededRandom(seed) {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  hash = (hash ^ (hash >>> 15)) >>> 0;
  return (hash % 10000) / 10000;
}

function round(value, unit) {
  if (unit === "%" || unit === "hrs") return Math.round(value * 10) / 10;
  if (Number.isInteger(value)) return value;
  return Math.round(value * 10) / 10;
}

function roundPct(value) {
  return Math.round(value * 10) / 10;
}

// One 6-point history series per metric+context, drifting toward "better"
// or "worse" depending on a per-series coin flip, weighted 60/40 toward
// improvement so the demo mostly reads as a healthy, improving programme.
function buildSeries(metric, context) {
  const seedBase = `${metric.name}::${context.domain}::${context.portfolio}::${context.project}`;
  const improving = seededRandom(`${seedBase}::direction`) < 0.6;
  const direction = metric.target === "higher" ? (improving ? 1 : -1) : improving ? -1 : 1;
  const values = [];
  let current = metric.base + (seededRandom(`${seedBase}::start`) - 0.5) * metric.volatility * 2;
  MONTHS.forEach((m, index) => {
    const noise = (seededRandom(`${seedBase}::${m.month_id}`) - 0.5) * metric.volatility;
    const drift = direction * metric.volatility * 0.35 * index;
    const value = current + drift + noise;
    values.push(round(Math.max(0, value), metric.unit));
  });
  return { values, improving };
}

function trendAndRisk(values, target, improving) {
  const latest = values[values.length - 1];
  const previous = values[values.length - 2];
  const delta = latest - previous;
  const meaningfulMove = Math.abs(delta) > Math.max(0.5, Math.abs(previous) * 0.02);
  let trend = "stable";
  if (meaningfulMove) {
    const better = target === "higher" ? delta > 0 : delta < 0;
    trend = better ? "improving" : "declining";
  }
  const risk = trend === "declining" ? (Math.abs(delta) > Math.abs(previous) * 0.08 ? "high" : "medium") : "low";
  return { trend, risk };
}

function buildInsights(metric, trend, risk, context) {
  const subject = `${metric.name} for ${context.project}`;
  return [
    {
      title: "Anomaly Detection",
      description:
        risk === "high"
          ? `${subject} moved outside its normal range this month.`
          : `No anomalies detected in ${subject.toLowerCase()} this month.`,
      example: risk === "high" ? `Month-over-month change exceeded the usual band.` : "Values stayed within the expected band.",
    },
    {
      title: "Trend Forecasting",
      description: `Based on the last 6 months, ${subject.toLowerCase()} is ${trend === "stable" ? "holding steady" : trend}.`,
      example: `Projected to ${trend === "declining" ? "continue softening" : trend === "improving" ? "continue improving" : "stay flat"} next month absent intervention.`,
    },
    {
      title: "Root Cause Analysis",
      description:
        trend === "declining"
          ? `Recent changes in ${context.project}'s delivery cadence correlate with this movement.`
          : `Consistent process adherence is sustaining this metric.`,
      example: trend === "declining" ? "Cross-check against recent release/deployment history." : "No corrective action required.",
    },
    {
      title: "Prescriptive Recommendations",
      description:
        trend === "declining"
          ? `Review ${metric.name.toLowerCase()} with the ${context.project} team and agree a two-sprint improvement target.`
          : `Maintain current approach and monitor trend monthly.`,
      example: trend === "declining" ? "Add to the next governance review agenda." : "",
    },
  ];
}

function buildMonthPayload(monthId, historyMonths) {
  const monthIndex = MONTHS.findIndex((m) => m.month_id === monthId);
  if (monthIndex === -1) return null;
  const monthMeta = MONTHS[monthIndex];
  const windowStart = Math.max(0, monthIndex - historyMonths);

  const categories = Object.entries(CATEGORY_METRICS).map(([categoryName, metrics]) => ({
    name: categoryName,
    metrics: metrics.flatMap((metric) =>
      CONTEXTS.map((context) => {
        const { values } = buildSeries(metric, context);
        const windowed = values.slice(windowStart, monthIndex + 1);
        const history = MONTHS.slice(windowStart, monthIndex + 1).map((m, i) => ({
          month: m.month,
          month_id: m.month_id,
          value: windowed[i],
        }));
        const { trend, risk } = trendAndRisk(windowed, metric.target, true);
        return {
          name: metric.name,
          value: values[monthIndex],
          unit: metric.unit,
          // "higher"|"lower" -- which direction counts as improvement for
          // this metric (e.g. a defect count improves by falling). Consumed
          // by the trend chart so it can colour red/green correctly instead
          // of assuming "up" always means "good".
          target: metric.target,
          domain: context.domain,
          portfolio: context.portfolio,
          project: context.project,
          history,
          past_6_months: history.slice(1),
          _category: categoryName,
          _context: context,
          _trend: trend,
          _risk: risk,
          _metric: metric,
        };
      }),
    ),
  }));

  const analysisMetrics = [];
  categories.forEach((category) => {
    category.metrics.forEach((metric) => {
      const avg = metric.history.reduce((sum, h) => sum + h.value, 0) / metric.history.length;
      const changeVsAvgPct = avg ? roundPct(((metric.value - avg) / avg) * 100) : 0;
      const summary = `${metric.name} is currently at ${metric.value}${metric.unit} for ${metric._context.project}, ${
        metric._trend === "stable" ? "holding steady versus" : metric._trend === "improving" ? "improving versus" : "trailing"
      } its 6-month average of ${roundPct(avg)}${metric.unit}.`;
      const recommendation =
        metric._trend === "declining"
          ? `Review ${metric.name.toLowerCase()} with the ${metric._context.project} team and agree a two-sprint improvement target.`
          : "Maintain current approach and monitor trend monthly.";
      analysisMetrics.push({
        category: metric._category,
        metric_name: metric.name,
        domain: metric.domain,
        portfolio: metric.portfolio,
        project: metric.project,
        unit: metric.unit,
        current_value: metric.value,
        past_6_months: metric.past_6_months.map((h) => h.value),
        trend: metric._trend,
        risk: metric._risk,
        summary,
        recommendation,
        generated_metric: metric.value,
        change_vs_avg_pct: changeVsAvgPct,
        insights: buildInsights(metric._metric, metric._trend, metric._risk, metric._context),
        generated_at: `${monthId}-28T09:00:00Z`,
      });
    });
  });

  // Strip the generation-only `_` fields before handing back a payload
  // shaped exactly like the real API response.
  const cleanCategories = categories.map((category) => ({
    name: category.name,
    metrics: category.metrics.map(({ _category, _context, _trend, _risk, _metric, ...metric }) => metric),
  }));

  const overallGeneratedMetric =
    Math.round(
      (analysisMetrics.reduce((sum, m) => sum + (m.risk === "low" ? 100 : m.risk === "medium" ? 65 : 25), 0) /
        analysisMetrics.length) *
        10,
    ) / 10;

  return {
    dashboard: { title: "Quality Engineering Dashboard", month: monthMeta.month },
    month_id: monthMeta.month_id,
    categories: cleanCategories,
    domain_portfolios: [
      { name: "Commercial", portfolios: ["Product & Planning", "B&M"] },
      { name: "Shared Services", portfolios: ["Tech"] },
      { name: "Enterprise", portfolios: ["Finance"] },
    ],
    history_window_months: historyMonths,
    months_available: MONTHS,
    analysis: {
      month_id: monthMeta.month_id,
      month: monthMeta.month,
      lookback_months: historyMonths,
      generated_at: `${monthMeta.month_id}-28T09:00:00Z`,
      overall_generated_metric: overallGeneratedMetric,
      metrics: analysisMetrics,
    },
  };
}

export const AVAILABLE_MONTHS = MONTHS;

export function getFrontendDashboard(monthId, historyMonths = 6) {
  return buildMonthPayload(monthId, historyMonths);
}

// KPIDetailsPage / TrendAnalysisPage read a flattened, KPIDashboard-shaped
// row directly when there is no router state to work from (e.g. a page
// refresh or a bookmarked link) -- this is that fallback, computed once for
// the latest month instead of leaving it an empty array.
function buildKpiDetailsFallback() {
  const latest = MONTHS[MONTHS.length - 1];
  const payload = buildMonthPayload(latest.month_id, 6);
  const analysisByMetric = new Map();
  payload.analysis.metrics.forEach((metric) => {
    const key = `${metric.category}::${metric.metric_name}::${metric.domain}::${metric.portfolio}::${metric.project}`;
    analysisByMetric.set(key, metric);
  });
  return payload.categories.flatMap((category) =>
    category.metrics.map((metric) => {
      const key = `${category.name}::${metric.name}::${metric.domain}::${metric.portfolio}::${metric.project}`;
      const analysis = analysisByMetric.get(key);
      return {
        dimension: category.name,
        domain: metric.domain,
        portfolio: metric.portfolio,
        project: metric.project,
        kpiname: metric.name,
        definition: analysis?.summary || `${metric.name} metric`,
        analysisSummary: analysis?.summary || "",
        analysisRecommendation: analysis?.recommendation || "",
        analysisTrend: analysis?.trend || "",
        analysisRisk: analysis?.risk || "",
        generatedMetric: analysis?.generated_metric,
        changeVsAvgPct: analysis?.change_vs_avg_pct,
        guidelines: { ideal: metric.unit === "%" ? "> 80%" : "", target: metric.target },
        value: metric.value,
        status: analysis?.risk === "high" ? "Red" : analysis?.risk === "medium" ? "Amber" : "Green",
        updated_at: `${payload.month_id}-01`,
        // updated_at matches the shape KPIDashboard's own history rows use
        // (`${month_id}-01`) -- TrendAnalysisPage / KPIDetailsPage read it
        // directly off history rows regardless of which source produced them.
        history: [...metric.history].reverse().map((h) => ({ ...h, updated_at: h.month_id ? `${h.month_id}-01` : "" })),
        insights: analysis?.insights || [],
        insightPoints: (analysis?.insights || []).map((item) => `${item?.title || ""}: ${item?.description || ""}`.trim()),
      };
    }),
  );
}

export const kpiDetailsFallback = buildKpiDetailsFallback();
