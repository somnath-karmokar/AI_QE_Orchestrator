/**
 * Static replacement for the live `/api/token-usage/summary` backend --
 * generated once per module load so the numbers stay internally consistent
 * (daily/feature/model totals all reconcile to the same grand total).
 */

const FEATURES = [
  { feature: "copilot", label: "AI Copilot", model: "gpt-4o-mini", weight: 0.45 },
  { feature: "monthly_analysis", label: "Monthly Metrics Analysis", model: "gpt-4o", weight: 0.35 },
  { feature: "insights", label: "Root Cause Insights", model: "gpt-4o-mini", weight: 0.2 },
];

const COST_PER_1K_PROMPT = { "gpt-4o-mini": 0.00015, "gpt-4o": 0.0025 };
const COST_PER_1K_COMPLETION = { "gpt-4o-mini": 0.0006, "gpt-4o": 0.01 };

function seededRandom(seed) {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  hash = (hash ^ (hash >>> 15)) >>> 0;
  return (hash % 10000) / 10000;
}

function isoDate(date) {
  return date.toISOString().slice(0, 10);
}

function buildSummary() {
  const today = new Date();
  const days = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (29 - i));
    return d;
  });

  const dailyTotals = [];
  const recentCalls = [];
  const featureTotals = new Map(FEATURES.map((f) => [f.feature, { calls: 0, prompt: 0, completion: 0 }]));
  const modelTotals = new Map();

  days.forEach((day) => {
    const dateStr = isoDate(day);
    const callsToday = 6 + Math.round(seededRandom(`${dateStr}::calls`) * 14);
    let dayTokens = 0;

    for (let i = 0; i < callsToday; i += 1) {
      const roll = seededRandom(`${dateStr}::${i}::feature`);
      const feature = FEATURES.find((f, idx) => roll < FEATURES.slice(0, idx + 1).reduce((s, x) => s + x.weight, 0)) || FEATURES[0];
      const promptTokens = 300 + Math.round(seededRandom(`${dateStr}::${i}::prompt`) * 1200);
      const completionTokens = 80 + Math.round(seededRandom(`${dateStr}::${i}::completion`) * 400);
      const totalTokens = promptTokens + completionTokens;
      dayTokens += totalTokens;

      const ft = featureTotals.get(feature.feature);
      ft.calls += 1;
      ft.prompt += promptTokens;
      ft.completion += completionTokens;

      const mt = modelTotals.get(feature.model) || { calls: 0, prompt: 0, completion: 0 };
      mt.calls += 1;
      mt.prompt += promptTokens;
      mt.completion += completionTokens;
      modelTotals.set(feature.model, mt);

      // Keep only a rolling window of calls for the "recent calls" table.
      recentCalls.push({
        timestamp: new Date(day.getTime() + i * 45 * 60 * 1000).toISOString().replace("T", " ").slice(0, 19),
        feature: feature.feature,
        model: feature.model,
        prompt_tokens: promptTokens,
        completion_tokens: completionTokens,
        total_tokens: totalTokens,
        status: seededRandom(`${dateStr}::${i}::status`) < 0.04 ? "fallback" : "success",
        estimated_cost_usd:
          Math.round(
            ((promptTokens / 1000) * COST_PER_1K_PROMPT[feature.model] +
              (completionTokens / 1000) * COST_PER_1K_COMPLETION[feature.model]) *
              10000,
          ) / 10000,
      });
    }

    dailyTotals.push({ date: dateStr, calls: callsToday, total_tokens: dayTokens });
  });

  const byFeature = FEATURES.map(({ feature, label, model }) => {
    const t = featureTotals.get(feature);
    const cost =
      (t.prompt / 1000) * COST_PER_1K_PROMPT[model] + (t.completion / 1000) * COST_PER_1K_COMPLETION[model];
    return {
      feature,
      label,
      calls: t.calls,
      prompt_tokens: t.prompt,
      completion_tokens: t.completion,
      total_tokens: t.prompt + t.completion,
      estimated_cost_usd: Math.round(cost * 10000) / 10000,
    };
  });

  const byModel = Array.from(modelTotals.entries()).map(([model, t]) => {
    const cost = (t.prompt / 1000) * COST_PER_1K_PROMPT[model] + (t.completion / 1000) * COST_PER_1K_COMPLETION[model];
    return {
      model,
      calls: t.calls,
      prompt_tokens: t.prompt,
      completion_tokens: t.completion,
      total_tokens: t.prompt + t.completion,
      estimated_cost_usd: Math.round(cost * 10000) / 10000,
    };
  });

  const totalCalls = byFeature.reduce((s, f) => s + f.calls, 0);
  const totalPrompt = byFeature.reduce((s, f) => s + f.prompt_tokens, 0);
  const totalCompletion = byFeature.reduce((s, f) => s + f.completion_tokens, 0);
  const totalCost = byFeature.reduce((s, f) => s + f.estimated_cost_usd, 0);

  return {
    generated_at: new Date().toISOString(),
    has_data: true,
    total_calls: totalCalls,
    total_prompt_tokens: totalPrompt,
    total_completion_tokens: totalCompletion,
    total_tokens: totalPrompt + totalCompletion,
    total_estimated_cost_usd: Math.round(totalCost * 10000) / 10000,
    daily: dailyTotals,
    by_feature: byFeature,
    by_model: byModel,
    // Most recent first, capped at 20 to match the page's own "last 20" label.
    recent_calls: recentCalls.slice(-20).reverse(),
  };
}

export const TOKEN_USAGE_SUMMARY = buildSummary();
