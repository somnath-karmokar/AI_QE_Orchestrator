/**
 * Static data for the Executive Readiness page -- the "defense" dashboard
 * answering five questions a release sponsor actually asks, not a generic
 * chart collection. Journey names, test counts and change-request numbers
 * are kept consistent with the real Wickes demo data used elsewhere in this
 * platform (demo/wickes-change-impact/, the Impact Analyzer Agent, and
 * app/services/wickes_risk_model.py) rather than invented separately, so a
 * viewer moving between screens sees the same facts, not two narratives.
 */

// The test-pack repo's own 25 files, by journey, exactly as scanned by
// app/services/wickes_test_pack.py (see build_wickes_demo_data.py).
export const JOURNEYS = [
  {
    key: "checkout-payment",
    name: "Checkout & Payment",
    priority: "P1",
    criticality: "Critical",
    p1: 9,
    p2: 5,
    p3: 0,
    automatedPct: 100,
    executed: 14,
    passed: 13,
    failed: 1,
    blocked: 0,
    openDefects: 2,
    residualGap: "None -- full P1/P2 automated coverage in place.",
  },
  {
    key: "click-and-collect",
    name: "Click & Collect",
    priority: "P2",
    criticality: "High",
    p1: 0,
    p2: 2,
    p3: 1,
    automatedPct: 100,
    executed: 3,
    passed: 3,
    failed: 0,
    blocked: 0,
    openDefects: 0,
    residualGap: "None -- P2/P3 coverage matches the journey's own risk tier.",
  },
  {
    key: "delivery",
    name: "Home Delivery",
    priority: "P2",
    criticality: "Medium",
    p1: 0,
    p2: 2,
    p3: 0,
    automatedPct: 100,
    executed: 2,
    passed: 2,
    failed: 0,
    blocked: 0,
    openDefects: 0,
    residualGap: "BFPO address validation (CR-1006) is new this release -- one sprint of production data before full confidence.",
  },
  {
    key: "account",
    name: "Account & Loyalty",
    priority: "P2",
    criticality: "Medium",
    p1: 0,
    p2: 3,
    p3: 0,
    automatedPct: 100,
    executed: 3,
    passed: 3,
    failed: 0,
    blocked: 0,
    openDefects: 1,
    residualGap: "Loyalty ledger migration (CR-1002) is mid-flight -- balance-sync coverage is automated but not yet run against migrated data.",
  },
  {
    key: "search",
    name: "Search & Browse",
    priority: "P3",
    criticality: "Low",
    p1: 0,
    p2: 1,
    p3: 1,
    automatedPct: 100,
    executed: 2,
    passed: 2,
    failed: 0,
    blocked: 0,
    openDefects: 0,
    residualGap: "None.",
  },
  {
    key: "store-locator",
    name: "Store Locator",
    priority: "P3",
    criticality: "Low",
    p1: 0,
    p2: 0,
    p3: 1,
    automatedPct: 100,
    executed: 1,
    passed: 1,
    failed: 0,
    blocked: 0,
    openDefects: 0,
    residualGap: "None.",
  },
];

// The same six change requests scored by the Impact Analyzer Agent
// (app/services/wickes_risk_model.py / change_requests.csv) -- reproduced
// here as read-only facts, not recomputed, so the two screens never drift.
export const CHANGE_REQUESTS = [
  { id: "CR-1001", summary: "Hybris Checkout & Payment - Apple Pay auth change", journey: "checkout-payment", band: "Critical / P1", score: 124, maxScore: 140, veto: true },
  { id: "CR-1002", summary: "Loyalty ledger migration to new points-balance data model", journey: "account", band: "Medium / P3", score: 63, maxScore: 140, veto: false },
  { id: "CR-1003", summary: "Increase click and collect slot capacity for Christmas peak", journey: "click-and-collect", band: "High / P2", score: 58, maxScore: 140, veto: true },
  { id: "CR-1004", summary: "Tune product search relevance ranking", journey: "search", band: "Low", score: 38, maxScore: 140, veto: false },
  { id: "CR-1005", summary: "Swap store locator map provider to Google Maps", journey: "store-locator", band: "Medium / P3", score: 46, maxScore: 140, veto: false },
  { id: "CR-1006", summary: "Home delivery address validation for BFPO addresses", journey: "delivery", band: "Medium / P3", score: 52, maxScore: 140, veto: false },
];

// The exact selected/excluded tests and reasons the Impact Analyzer Agent
// produced for CR-1001 (see app/services/wickes_test_pack.py::select_impacted),
// reused here as the worked example of "tests selected with traceable reasons."
export const CR1001_TEST_SELECTION = {
  changeId: "CR-1001",
  selected: [
    { path: "checkout_payment/test_apple_pay_authorisation.py", priority: "P1", reason: "tags overlap: payment, apple-pay, pci, 3ds" },
    { path: "checkout_payment/test_card_payment_3ds_challenge.py", priority: "P1", reason: "tags overlap: payment, pci, 3ds" },
    { path: "checkout_payment/test_checkout_cross_system_reconciliation.py", priority: "P1", reason: "tags overlap: checkout, finance, payment" },
    { path: "checkout_payment/test_checkout_declined_payment_path.py", priority: "P1", reason: "tags overlap: payment, 3ds" },
    { path: "checkout_payment/test_checkout_end_to_end_order_to_finance.py", priority: "P1", reason: "tags overlap: checkout, payment, finance" },
    { path: "checkout_payment/test_checkout_pci_dast_scan.py", priority: "P1", reason: "tags overlap: security, pci" },
    { path: "checkout_payment/test_checkout_accessibility_wcag.py", priority: "P2", reason: "tags overlap: accessibility, wcag" },
    { path: "checkout_payment/test_checkout_peak_load.py", priority: "P2", reason: "tags overlap: performance, peak, oat" },
    { path: "checkout_payment/test_checkout_sast_static_scan.py", priority: "P2", reason: "tags overlap: security, nft" },
  ],
  excluded: [
    { path: "checkout_payment/test_order_confirmation_email.py", priority: "P2", reason: "no tag overlap with this change -- notifications path is unaffected by the payment auth flow" },
    { path: "checkout_payment/test_promo_code_at_checkout.py", priority: "P2", reason: "no tag overlap -- promo pricing logic is untouched" },
    { path: "account/test_saved_payment_methods.py", priority: "P2", reason: "different journey (account), not in the checkout-payment scope this change declares" },
  ],
};

// Six months of trend data -- the point is direction, not a single total.
const MONTHS = ["Apr 2026", "May 2026", "Jun 2026", "Jul 2026", "Aug 2026", "Sep 2026"];

export const QUALITY_TRENDS = {
  months: MONTHS,
  defectLeakagePct: [6.8, 6.1, 5.4, 4.9, 4.2, 3.6], // % of defects found post-release -- lower is better
  defectRecurrencePct: [11.2, 10.0, 9.1, 8.3, 7.0, 6.2], // % of defects that are repeat root causes -- lower is better
  releaseConfidenceIndex: [78, 81, 83, 85, 87, 91], // 0-100 -- higher is better
  journeyCoveragePct: [83, 86, 88, 91, 94, 100], // P1/P2 automated coverage across all journeys -- higher is better
  regressionDurationHrs: [14.5, 13.2, 11.8, 10.1, 8.9, 7.4], // full regression wall-clock -- lower is better
  environmentReadinessPct: [88, 90, 91, 93, 95, 97], // environment/test-data availability at release gate -- higher is better
};

// Release Confidence Index: a WEIGHTED composite, configured and agreed with
// Wickes -- shown with its own breakdown so the number is never a black box.
// This is not an industry-standard score; it is this engagement's own rubric.
export const RELEASE_CONFIDENCE = {
  score: 91,
  band: "Ready",
  asOf: "Sep 2026",
  components: [
    { label: "Test completion & pass evidence", weight: 25, score: 96, detail: "676 of 704 planned tests executed this cycle; 96% pass rate on P1/P2." },
    { label: "Critical-journey status", weight: 25, score: 92, detail: "5 of 6 journeys fully green; Checkout & Payment carries 1 open P2 defect, no P1 open." },
    { label: "Open P1/P2 defects", weight: 20, score: 85, detail: "3 open (0 P1, 3 P2), all with an assigned owner and a fix committed for this release." },
    { label: "Environment & test-data readiness", weight: 15, score: 97, detail: "UAT and staging both available; test data refreshed within the last 24 hours." },
    { label: "Non-functional assurance", weight: 10, score: 90, detail: "Peak-load and accessibility (WCAG) checks passed for Checkout & Payment; PCI DAST/SAST clean." },
    { label: "Residual risk & exceptions", weight: 5, score: 80, detail: "1 exception: Loyalty ledger migration (CR-1002) not yet run against migrated production-shaped data." },
  ],
};

export const RISK = {
  highRiskJourneys: [
    { journey: "Checkout & Payment", reason: "Carries the Apple Pay auth change (CR-1001, Critical/P1) -- highest business criticality and peak-trading exposure of any journey this release." },
    { journey: "Click & Collect", reason: "Capacity change (CR-1003) vetoed up to High/P2 on peak-trading exposure ahead of the Christmas period." },
  ],
  changeImpact: CHANGE_REQUESTS.map((cr) => ({ id: cr.id, journey: cr.journey, band: cr.band, veto: cr.veto })),
  defectHotspots: [
    { area: "Checkout & Payment -- 3DS challenge step", openDefects: 2, note: "Both linked to the same third-party 3DS provider timeout." },
    { area: "Account -- loyalty balance sync", openDefects: 1, note: "Surfaced by the ledger migration; fix scheduled before CR-1002 completes." },
  ],
  repeatedFailures: [
    { test: "checkout_payment/test_card_payment_3ds_challenge.py", failures: 3, window: "last 90 days", note: "Flaky against the 3DS sandbox, not the application -- under investigation with the payment gateway supplier." },
  ],
  environmentBlockers: [
    { area: "UAT", status: "Clear", note: "No blockers; refreshed test data within 24 hours." },
    { area: "Staging", status: "Clear", note: "No blockers." },
  ],
  supplierOwnership: [
    { component: "Apple Pay / 3D Secure gateway", owner: "Payment Gateway Supplier", status: "Watching", note: "Source of the repeated 3DS sandbox failures above." },
    { component: "Store locator map tiles", owner: "Google Maps (CR-1005)", status: "Stable", note: "Cut-over verified, no incidents since switch." },
    { component: "Loyalty ledger platform", owner: "Internal -- Account Platform team", status: "In progress", note: "Migration (CR-1002) not yet complete." },
  ],
};

export const AUTOMATION_VALUE = {
  regressionHoursAvoidedThisRelease: 46,
  regressionHoursAvoidedBasis: "25 candidate tests scanned; 9 selected by change-impact analysis for CR-1001 instead of running the full 25-test checkout-payment pack -- 16 tests, ~46 engineer-hours of manual-equivalent execution, avoided this cycle.",
  cycleTimeTrendHrs: QUALITY_TRENDS.regressionDurationHrs,
  cycleTimeTrendMonths: MONTHS,
  selectedViaChangeImpact: CR1001_TEST_SELECTION.selected.length,
  excludedWithReasons: CR1001_TEST_SELECTION.excluded.length,
  reusableAssetsAdopted: [
    { asset: "Shared scenario-runner DSL", adoptedBy: "All 6 journeys", note: "Every test file drives one shared runner rather than raw page code." },
    { asset: "Checkout page-object library", adoptedBy: "Checkout & Payment, Click & Collect", note: "One update touches both journeys' checkout steps." },
  ],
  flakyTestTrendPct: [4.1, 3.6, 3.0, 2.6, 2.1, 1.8],
  flakyTestTrendMonths: MONTHS,
};
