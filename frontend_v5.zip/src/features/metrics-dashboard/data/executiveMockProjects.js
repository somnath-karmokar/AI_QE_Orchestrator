const names = [
  ["Commercial", "Product & Planning", "Flex PLM", 88, "Anika Rao"],
  ["Commercial", "B&M", "Retail Ordering Platform", 91, "James Miller"],
  ["Shared Services", "Tech", "Supply Chain MS", 82, "Sofia Klein"],
  ["Shared Services", "Tech", "Manhattan MS", 79, "Claire Dubois"],
  ["Shared Services", "Tech", "Inventory MS – Design", 85, "Mateo Ruiz"],
  ["Shared Services", "Tech", "Desktop Modernisation", 76, "Ines Costa"],
  ["Shared Services", "Tech", "Modern Management", 93, "Oliver Smith"],
  ["Enterprise", "Finance", "ISO 20022 Upgrade", 42, "Nora Weiss"],
];

const dimensions = ["Engineering", "Velocity", "Automation", "Quality", "Environment"];

function statusFromScore(score) {
  if (score >= 75) return "green";
  if (score >= 60) return "amber";
  return "red";
}

export const executiveMockProjects = names.map(([domain, portfolio, project, score, owner], index) => {
  const rag = statusFromScore(score);
  const kpis = dimensions.reduce((acc, dimension, dimensionIndex) => {
    const adjusted = Math.max(35, Math.min(98, score + ((index + dimensionIndex) % 5) * 3 - 6));
    acc[dimension] = statusFromScore(adjusted);
    return acc;
  }, {});
  return {
    id: project.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    domain,
    portfolio,
    project,
    businessUnit: domain,
    owner,
    score,
    rag,
    kpis,
    criticalKpis: Object.values(kpis).filter((value) => value === "red").length,
    openRisks: rag === "red" ? 5 + (index % 4) : rag === "amber" ? 2 + (index % 3) : index % 2,
    trend: rag === "red" ? -4 - (index % 4) : rag === "amber" ? 1 - (index % 3) : 3 + (index % 5),
    lastUpdated: index % 3 === 0 ? "Today" : index % 3 === 1 ? "Yesterday" : "2 days ago",
    risks:
      rag === "red"
        ? ["Defect density rising", "Environment instability", "Release delay"]
        : rag === "amber"
          ? ["Velocity variance", "Automation coverage"]
          : ["Minor regression backlog"],
  };
});
