import React, { useState, useRef, useEffect } from "react";
import { Send, User, Bot, Sparkles, Loader2, ArrowLeft, BarChart3, TrendingUp, AlertTriangle, Lightbulb } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";

// Simple inline markdown renderer (bold, italic, line breaks, bullet lines)
function MarkdownText({ text }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-1.5">
      {lines.map((line, i) => {
        if (!line.trim()) return <div key={i} className="h-1" />;
        // Render inline bold (**text**) and italic (_text_)
        const parts = line.split(/(\*\*[^*]+\*\*|_[^_]+_)/g).map((part, j) => {
          if (part.startsWith("**") && part.endsWith("**"))
            return <strong key={j} className="font-black text-slate-900">{part.slice(2, -2)}</strong>;
          if (part.startsWith("_") && part.endsWith("_"))
            return <em key={j} className="text-slate-600 not-italic font-medium">{part.slice(1, -1)}</em>;
          return part;
        });
        return <p key={i} className="leading-relaxed">{parts}</p>;
      })}
    </div>
  );
}

const SUGGESTED_QUESTIONS = [
  { icon: TrendingUp,    label: "Which metrics are declining this month?" },
  { icon: AlertTriangle, label: "What are the high-risk KPIs right now?" },
  { icon: BarChart3,     label: "Give me an automation adoption summary." },
  { icon: Lightbulb,     label: "What actions should I take to improve quality?" },
];

// This demo runs on static data, not a live model -- a few keyword-matched
// canned replies stand in for the real /api/copilot/query call so the page
// still responds sensibly instead of erroring against a backend that isn't
// wired up here.
const CANNED_REPLIES = [
  {
    match: /declin|drop|down|worse|regress/i,
    answer:
      "**Defect Re-Open %** and **Escape Defect to UAT** are the two metrics trending down this month, both driven by the Supply Chain MS project. _Environment availability %_ also softened slightly after a round of infrastructure changes.",
    supporting_metrics: ["Defect Re-Open %", "Escape Defect to UAT", "Environment availability %"],
  },
  {
    match: /risk|red|critical|urgent/i,
    answer:
      "Three KPIs are currently flagged **RED**: _Escape Defect to Prod_, _Average Defect TAT (1-Urgent/2-High)_, and _Regression Automation %_ on the Retail Ordering Platform programme. These are the ones I'd prioritise for this sprint's risk review.",
    supporting_metrics: ["Escape Defect to Prod", "Average Defect TAT", "Regression Automation %"],
  },
  {
    match: /automat/i,
    answer:
      "Automation Adoption sits at **78%** platform-wide, up from 71% last month. CI/CD Adoption and E2E Automation are both ahead of target; Regression Automation is the laggard at 62% and is the best lever for further gains.",
    supporting_metrics: ["Automation Adoption (%)", "CICD Adoption (%)", "Regression Automation(%)"],
  },
  {
    match: /recommend|improve|action|should/i,
    answer:
      "Based on the latest monthly analysis, the highest-leverage actions are: 1) close out the backlog of re-opened defects before they age past 30 days, 2) extend regression automation coverage on the Supply Chain MS project, and 3) schedule a knowledge-sharing session on the new CI/CD pipeline pattern to lift adoption in lagging teams.",
    supporting_metrics: ["Defect Re-Open %", "Regression Automation(%)", "Knowledge Sharing session"],
  },
];

const DEFAULT_REPLY =
  "I can talk through trends, risk areas, automation adoption, or recommendations from the latest monthly KPI analysis -- try one of the suggested questions, or ask about a specific metric by name.";

function answerLocally(question) {
  const hit = CANNED_REPLIES.find((entry) => entry.match.test(question));
  if (hit) return { answer: hit.answer, supporting_metrics: hit.supporting_metrics };
  return { answer: DEFAULT_REPLY, supporting_metrics: [] };
}

export default function ChatAssistantPage() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hello! I am your QE metrics assistant.\n\nAsk me anything about KPI trends, risk areas, automation adoption, defect leakage, or any metric from the latest monthly analysis.",
      supporting_metrics: [],
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const sendQuestion = async (question) => {
    const userMsg = question.trim();
    if (!userMsg || isLoading) return;
    setInputValue("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setIsLoading(true);

    // Static demo: a brief simulated delay, then a locally-matched canned
    // reply, rather than a call to a live copilot backend.
    await new Promise((resolve) => setTimeout(resolve, 500 + Math.random() * 400));
    const { answer, supporting_metrics } = answerLocally(userMsg);
    setMessages((prev) => [...prev, { role: "assistant", content: answer, supporting_metrics }]);
    setIsLoading(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendQuestion(inputValue);
  };

  const showSuggestions = messages.length === 1;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-montserrat flex flex-col relative overflow-hidden">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 -left-32 h-[500px] w-[500px] rounded-full bg-fuchsia-600/10 blur-[120px]" />
        <div className="absolute bottom-0 -right-32 h-[500px] w-[500px] rounded-full bg-cyan-600/10 blur-[120px]" />
      </div>

      <Header />

      <main className="relative z-10 flex-1 flex flex-col items-center p-4 sm:p-6 w-full max-w-4xl mx-auto">
        {/* Page title row */}
        <div className="w-full flex items-center gap-4 mb-5">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="p-2.5 bg-white/80 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors border border-slate-200"
            title="Go Back"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-[0_0_16px_rgba(6,182,212,0.4)]">
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-slate-900 leading-tight">AI Data Assistant</h1>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-widest">Powered by monthly KPI analysis</p>
            </div>
          </div>
        </div>

        {/* Chat window */}
        <div className="w-full flex-1 flex flex-col bg-white/40 backdrop-blur-md border border-slate-200/60 rounded-2xl shadow-2xl overflow-hidden" style={{ minHeight: "calc(100vh - 260px)" }}>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`flex max-w-[88%] gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  {/* Avatar */}
                  <div className="flex-shrink-0 mt-0.5">
                    {msg.role === "user" ? (
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center border border-slate-300">
                        <User size={15} className="text-slate-600" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-md">
                        <Bot size={15} className="text-white" />
                      </div>
                    )}
                  </div>

                  {/* Bubble */}
                  <div className="flex flex-col gap-2">
                    <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-cyan-600/25 border border-cyan-500/40 text-white rounded-tr-sm"
                        : "bg-slate-100/70 border border-slate-200/60 text-slate-900 rounded-tl-sm"
                    }`}>
                      <MarkdownText text={msg.content} />
                    </div>

                    {/* Supporting metrics chips */}
                    {msg.supporting_metrics?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 px-1">
                        {msg.supporting_metrics.map((m) => (
                          <span key={m} className="inline-flex items-center gap-1 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-2 py-0.5 text-[10px] font-bold text-indigo-300">
                            <BarChart3 size={9} />
                            {m}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Suggested questions — shown only before first user message */}
            {showSuggestions && (
              <div className="pt-2">
                <p className="text-[11px] font-black uppercase tracking-widest text-slate-500 mb-3">Suggested questions</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {SUGGESTED_QUESTIONS.map(({ icon: Icon, label }) => (
                    <button
                      key={label}
                      type="button"
                      onClick={() => sendQuestion(label)}
                      className="flex items-center gap-2.5 rounded-xl border border-slate-200/60 bg-white/50 px-4 py-3 text-left text-xs font-semibold text-slate-600 hover:border-cyan-500/40 hover:bg-slate-100/50 hover:text-slate-900 transition-all"
                    >
                      <Icon size={14} className="text-cyan-400 shrink-0" />
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Loading indicator */}
            {isLoading && (
              <div className="flex justify-start">
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center animate-pulse">
                    <Bot size={15} className="text-white" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl rounded-tl-sm bg-slate-100/70 border border-slate-200/60 flex items-center gap-1.5">
                    {[0, 0.18, 0.36].map((delay) => (
                      <div key={delay} className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: `${delay}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input bar */}
          <div className="p-4 bg-slate-100/60 border-t border-slate-200/60 backdrop-blur-md">
            <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about KPI trends, risks, recommendations…"
                className="flex-1 bg-white/80 text-slate-900 border border-slate-300/60 rounded-xl py-3 pl-4 pr-4 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 transition-all text-sm placeholder:text-slate-500"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className="flex items-center justify-center h-11 w-11 bg-gradient-to-br from-cyan-500 to-indigo-500 text-slate-900 rounded-xl hover:shadow-[0_0_16px_rgba(6,182,212,0.5)] disabled:opacity-40 disabled:cursor-not-allowed transition-all shrink-0"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Send size={16} />}
              </button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
