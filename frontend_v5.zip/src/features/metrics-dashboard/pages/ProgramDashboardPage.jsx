import { useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Activity, AlertTriangle, Gauge, ShieldCheck } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { useMonth } from "../context/MonthContext";
import { monthLabelToId } from "../services/monthlyMetricsApi";
import { getProgramsForMonth } from "../data/programPortfolioData";
import { governanceFramework } from "../data/governanceFramework";
import { getProgramMetricsForMonth } from "../data/programMetricsData";

const toneMap = {
  green: {
    badge: "bg-green-600 text-white border-green-400",
    border: "border-emerald-300/35",
    dot: "bg-emerald-400",
    label: "Green",
  },
  amber: {
    badge: "bg-amber-500 text-slate-950 border-amber-300",
    border: "border-amber-300/40",
    dot: "bg-amber-300",
    label: "Amber",
  },
  red: {
    badge: "bg-red-600 text-white border-red-400",
    border: "border-red-300/35",
    dot: "bg-red-400",
    label: "Red",
  },
};

function readinessTone(value) {
  if (value >= 90) return "green";
  if (value >= 75) return "amber";
  return "red";
}

function defectTrendTone(trend) {
  const normalized = String(trend || "").toLowerCase();
  if (normalized.includes("high") || normalized.includes("severity")) return "red";
  if (normalized.includes("increasing")) return "amber";
  return "green";
}

function attentionTone(attention) {
  if (attention === "Yes") return "red";
  if (attention === "Monitor") return "amber";
  return "green";
}

const statToneClasses = {
  green: { border: "border-green-400/50", icon: "border-green-400/40 bg-green-500/15 text-green-400", value: "text-green-400" },
  amber: { border: "border-amber-400/50", icon: "border-amber-400/40 bg-amber-500/15 text-amber-400", value: "text-amber-400" },
  red: { border: "border-red-400/50", icon: "border-red-400/40 bg-red-500/15 text-red-400", value: "text-red-400" },
};

function StatTile({ icon: Icon, label, value, tone }) {
  const cls = statToneClasses[tone] || statToneClasses.amber;
  return (
    <div className={`flex items-center gap-3 rounded-xl border ${cls.border} bg-slate-100/70 px-4 py-3.5 transition-all hover:-translate-y-0.5 hover:shadow-lg`}>
      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border ${cls.icon}`}>
        <Icon size={18} />
      </span>
      <div className="min-w-0">
        <p className={`truncate text-xl font-black leading-tight ${cls.value}`}>{value}</p>
        <p className="mt-0.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">{label}</p>
      </div>
    </div>
  );
}

const PARTNER_LABELS = [
  { key: "si", label: "SI Partner" },
  { key: "testing", label: "Testing Partner" },
  { key: "integration", label: "Integration Partner" },
  { key: "others", label: "Others" },
];

function PartnerTag({ label, active }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[10px] font-bold uppercase tracking-wide ${
        active
          ? "border-cyan-300/40 bg-cyan-400/10 text-cyan-700"
          : "border-slate-200/70 bg-slate-100/50 text-slate-400"
      }`}
    >
      {label}
    </span>
  );
}

function MeasurementCard({ row, metric }) {
  const status = metric?.status || "amber";
  const tone = toneMap[status] || toneMap.amber;

  return (
    <div className={`rounded-xl border ${tone.border} bg-slate-100/70 p-4`}>
      <div className="flex items-start justify-between gap-3">
        <h3 className="text-sm font-bold text-slate-900">{row.measurement}</h3>
        <span className={`shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-black uppercase ${tone.badge}`}>
          {tone.label}
        </span>
      </div>

      {metric && (
        <p className="mt-2 text-2xl font-black text-slate-900">{metric.value}%</p>
      )}

      <div className="mt-2 flex flex-wrap gap-3 text-[10px] font-semibold text-slate-500">
        <span className="text-green-400">Green {row.green}</span>
        <span className="text-amber-400">Amber {row.amber}</span>
        <span className="text-red-400">Red {row.red}</span>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {PARTNER_LABELS.map(({ key, label }) => (
          <PartnerTag key={key} label={label} active={row.partners[key]} />
        ))}
      </div>
    </div>
  );
}

export default function ProgramDashboardPage() {
  const navigate = useNavigate();
  const { programId } = useParams();
  const { selectedMonth } = useMonth();
  const monthId = monthLabelToId(selectedMonth);

  const program = useMemo(
    () => getProgramsForMonth(monthId).find((item) => item.id === programId),
    [monthId, programId],
  );

  const tone = toneMap[program?.rag] || toneMap.amber;

  const metricsByMeasurement = useMemo(() => {
    const rows = program ? getProgramMetricsForMonth(monthId, program.id) : [];
    return new Map(rows.map((row) => [row.measurement, row]));
  }, [monthId, program]);

  const groupedFramework = useMemo(() => {
    const groups = new Map();
    governanceFramework.forEach((row) => {
      if (!groups.has(row.phase)) groups.set(row.phase, []);
      groups.get(row.phase).push(row);
    });
    return Array.from(groups.entries());
  }, []);

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-slate-100">
      <Header />
      <main className="mx-auto flex w-full max-w-[1800px] flex-1 flex-col gap-6 px-3 pb-10 sm:px-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => navigate("/metrics/dashboard")}
            className="inline-flex w-fit items-center gap-2 rounded-lg border border-slate-300/70 bg-white/70 px-3 py-2 text-sm font-bold text-slate-600 transition-all hover:border-slate-500 hover:text-slate-900"
          >
            <ArrowLeft size={15} /> Back to Program Overview
          </button>
          {selectedMonth && (
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200/60 bg-white/60 px-3 py-1.5 text-xs font-bold text-slate-500">
              Reporting Period: <span className="text-slate-900">{selectedMonth}</span>
            </span>
          )}
        </div>

        {!program ? (
          <div className="rounded-2xl border border-slate-300/70 bg-white/80 px-6 py-5 text-slate-800">
            Program not found. Go back and select a program from the list.
          </div>
        ) : (
          <>
            <section className="rounded-2xl border border-slate-300/70 bg-white/80 px-6 py-5 shadow-xl backdrop-blur-md">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <span className={`h-3 w-3 shrink-0 rounded-full ${tone.dot}`} />
                  <div>
                    <h1 className="text-2xl font-black text-slate-900">{program.program}</h1>
                    <p className="text-sm font-semibold text-slate-500">{program.portfolio} Portfolio</p>
                  </div>
                </div>
                <span className={`rounded-full border px-4 py-1.5 text-xs font-black uppercase ${tone.badge}`}>
                  {tone.label}
                </span>
              </div>
              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <StatTile icon={Gauge} label="Release Readiness" value={`${program.releaseReadiness}%`} tone={readinessTone(program.releaseReadiness)} />
                <StatTile icon={Activity} label="Defect Trend" value={program.defectTrend} tone={defectTrendTone(program.defectTrend)} />
                <StatTile icon={AlertTriangle} label="Executive Attention" value={program.executiveAttention} tone={attentionTone(program.executiveAttention)} />
                <StatTile icon={ShieldCheck} label="Testing Status" value={tone.label} tone={program.rag} />
              </div>
            </section>

            <section className="rounded-2xl border border-slate-300/70 bg-white/88 p-5 shadow-xl backdrop-blur-md">
              <div className="mb-5 flex items-center gap-3">
                <div className="rounded-xl border border-cyan-300/30 bg-cyan-400/10 p-2 text-cyan-700">
                  <Gauge size={20} />
                </div>
                <div>
                  <h2 className="text-lg font-black text-slate-900">Program / Portfolio Governance &amp; Decision Intelligence Framework – Quality</h2>
                  <p className="text-xs font-semibold text-slate-500">Testing health by phase and measurement</p>
                </div>
              </div>

              <div className="space-y-8">
                {groupedFramework.map(([phase, rows], phaseIndex) => {
                  const phaseCounts = rows.reduce(
                    (acc, row) => {
                      const status = metricsByMeasurement.get(row.measurement)?.status || "amber";
                      acc[status] = (acc[status] || 0) + 1;
                      return acc;
                    },
                    { green: 0, amber: 0, red: 0 },
                  );

                  return (
                  <div key={phase}>
                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border-l-4 border-cyan-400 bg-gradient-to-r from-white to-slate-900/40 px-4 py-3 shadow-inner">
                      <div className="flex items-center gap-3">
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-cyan-300/30 bg-cyan-400/10 text-sm font-black text-cyan-700">
                          {String(phaseIndex + 1).padStart(2, "0")}
                        </span>
                        <div>
                          <h3 className="text-base font-black tracking-tight text-slate-900">{phase}</h3>
                          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{rows.length} measurement{rows.length === 1 ? "" : "s"} tracked</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] font-black">
                        {phaseCounts.green > 0 && <span className="rounded-full border border-green-400/40 bg-green-400/10 px-2.5 py-1 text-green-700">{phaseCounts.green} Green</span>}
                        {phaseCounts.amber > 0 && <span className="rounded-full border border-amber-400/40 bg-amber-400/10 px-2.5 py-1 text-amber-700">{phaseCounts.amber} Amber</span>}
                        {phaseCounts.red > 0 && <span className="rounded-full border border-red-400/40 bg-red-400/10 px-2.5 py-1 text-red-700">{phaseCounts.red} Red</span>}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
                      {rows.map((row) => (
                        <MeasurementCard key={row.measurement} row={row} metric={metricsByMeasurement.get(row.measurement)} />
                      ))}
                    </div>
                  </div>
                  );
                })}
              </div>

              <p className="mt-6 border-t border-slate-200/70 pt-4 text-xs font-semibold text-slate-500">
                Time &amp; Cost dimension to be applied in addition to Quality dimension to represent the RAG.
              </p>
            </section>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
