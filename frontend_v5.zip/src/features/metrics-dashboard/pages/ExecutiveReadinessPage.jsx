import React from "react";
import {
  ShieldCheck, Gauge, AlertTriangle, TrendingUp, TrendingDown, CheckCircle2,
  Building2, GitBranch, Users, Clock, Info,
} from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import {
  JOURNEYS, CHANGE_REQUESTS, CR1001_TEST_SELECTION, QUALITY_TRENDS,
  RELEASE_CONFIDENCE, RISK, AUTOMATION_VALUE,
} from "../data/wickesExecutiveData";

const RAG = {
  Critical: { bg: "bg-red-500", text: "text-red-700", chip: "bg-red-100 text-red-800 border-red-300" },
  High: { bg: "bg-orange-500", text: "text-orange-700", chip: "bg-orange-100 text-orange-800 border-orange-300" },
  Medium: { bg: "bg-amber-400", text: "text-amber-700", chip: "bg-amber-100 text-amber-800 border-amber-300" },
  Low: { bg: "bg-emerald-500", text: "text-emerald-700", chip: "bg-emerald-100 text-emerald-800 border-emerald-300" },
};

function bandTone(band) {
  const key = band.split(" /")[0].trim();
  return RAG[key] || RAG.Medium;
}

function SectionHeader({ number, question, subtitle, icon: Icon }) {
  return (
    <div className="mb-4 flex items-start gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-700">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-cyan-700">Question {number}</p>
        <h2 className="text-xl font-black text-slate-900">{question}</h2>
        {subtitle ? <p className="text-sm text-slate-500">{subtitle}</p> : null}
      </div>
    </div>
  );
}

function Panel({ title, icon: Icon, children, className = "" }) {
  return (
    <div className={`rounded-2xl border border-slate-200/70 bg-white/80 backdrop-blur-md shadow-lg p-5 ${className}`}>
      {title ? (
        <div className="mb-3 flex items-center gap-2">
          {Icon ? <Icon className="h-4 w-4 text-slate-500" /> : null}
          <h3 className="text-sm font-black text-slate-800">{title}</h3>
        </div>
      ) : null}
      {children}
    </div>
  );
}

// A small, dependency-free trend line -- direction matters far more here
// than precision, so an inline SVG sparkline is enough.
function Sparkline({ values, months, higherIsBetter, unit = "" }) {
  const width = 260;
  const height = 60;
  const pad = 4;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const points = values.map((v, i) => {
    const x = pad + (i / (values.length - 1)) * (width - pad * 2);
    const y = height - pad - ((v - min) / range) * (height - pad * 2);
    return [x, y];
  });
  const path = points.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const first = values[0];
  const last = values[values.length - 1];
  const improved = higherIsBetter ? last > first : last < first;
  const deltaPct = first ? Math.round(((last - first) / Math.abs(first)) * 1000) / 10 : 0;

  return (
    <div>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
        <path d={path} fill="none" stroke={improved ? "#059669" : "#dc2626"} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {points.map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={i === points.length - 1 ? 3.5 : 2} fill={improved ? "#059669" : "#dc2626"} />
        ))}
      </svg>
      <div className="mt-1 flex items-center justify-between text-xs">
        <span className="text-slate-400">
          {months[0]} → {months[months.length - 1]}
        </span>
        <span className={`flex items-center gap-1 font-bold ${improved ? "text-emerald-700" : "text-red-700"}`}>
          {improved ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {last}
          {unit} ({deltaPct > 0 ? "+" : ""}
          {deltaPct}%)
        </span>
      </div>
    </div>
  );
}

export default function ExecutiveReadinessPage() {
  const totalP1 = JOURNEYS.reduce((s, j) => s + j.p1, 0);
  const totalP2 = JOURNEYS.reduce((s, j) => s + j.p2, 0);
  const totalExecuted = JOURNEYS.reduce((s, j) => s + j.executed, 0);
  const totalPassed = JOURNEYS.reduce((s, j) => s + j.passed, 0);
  const totalDefects = JOURNEYS.reduce((s, j) => s + j.openDefects, 0);
  const journeysFullyGreen = JOURNEYS.filter((j) => j.failed === 0 && j.blocked === 0).length;

  return (
    <div className="min-h-screen w-full bg-slate-50 font-inter">
      <Header />
      <main className="mx-auto max-w-[1400px] px-4 pb-16 pt-2 sm:px-6">
        <div className="mb-6">
          <p className="text-[11px] font-black uppercase tracking-[0.2em] text-cyan-700">Release defense view</p>
          <h1 className="text-3xl font-black tracking-tight text-slate-900">Executive Readiness</h1>
          <p className="mt-1 max-w-3xl text-sm text-slate-600">
            Risk, confidence, business-journey protection and improvement trends -- not pass/fail counts.
            Every figure on this page traces to the same journeys, change requests and test-pack data shown
            elsewhere in this platform.
          </p>
        </div>

        {/* ============================================================ */}
        {/* Q1 -- Are critical Wickes journeys protected? */}
        {/* ============================================================ */}
        <section className="mb-10">
          <SectionHeader
            number={1}
            icon={ShieldCheck}
            question="Are critical Wickes journeys protected?"
            subtitle="P1/P2 coverage, automation, execution status and defects, by journey."
          />
          <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Panel className="!p-4">
              <p className="text-2xs font-bold uppercase text-slate-400">Journeys fully green</p>
              <p className="text-2xl font-black text-slate-900">{journeysFullyGreen} / {JOURNEYS.length}</p>
            </Panel>
            <Panel className="!p-4">
              <p className="text-2xs font-bold uppercase text-slate-400">P1 tests covered</p>
              <p className="text-2xl font-black text-slate-900">{totalP1}</p>
            </Panel>
            <Panel className="!p-4">
              <p className="text-2xs font-bold uppercase text-slate-400">Pass rate this cycle</p>
              <p className="text-2xl font-black text-slate-900">{Math.round((totalPassed / totalExecuted) * 100)}%</p>
            </Panel>
            <Panel className="!p-4">
              <p className="text-2xs font-bold uppercase text-slate-400">Open journey defects</p>
              <p className="text-2xl font-black text-slate-900">{totalDefects}</p>
            </Panel>
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
            {JOURNEYS.map((j) => {
              const tone = bandTone(j.criticality);
              return (
                <Panel key={j.key} className="!p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <h4 className="font-black text-slate-900">{j.name}</h4>
                    <span className={`rounded-full border px-2 py-0.5 text-2xs font-black ${tone.chip}`}>{j.priority} · {j.criticality}</span>
                  </div>
                  <div className="mb-2 grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-lg bg-slate-50 py-1.5">
                      <p className="text-lg font-black text-slate-900">{j.p1}</p>
                      <p className="text-2xs text-slate-400">P1 tests</p>
                    </div>
                    <div className="rounded-lg bg-slate-50 py-1.5">
                      <p className="text-lg font-black text-slate-900">{j.p2}</p>
                      <p className="text-2xs text-slate-400">P2 tests</p>
                    </div>
                    <div className="rounded-lg bg-slate-50 py-1.5">
                      <p className="text-lg font-black text-emerald-600">{j.automatedPct}%</p>
                      <p className="text-2xs text-slate-400">Automated</p>
                    </div>
                  </div>
                  <div className="mb-2 flex items-center gap-2 text-xs text-slate-600">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                    {j.passed}/{j.executed} passed
                    {j.failed > 0 ? <span className="font-bold text-red-600">· {j.failed} failed</span> : null}
                    {j.openDefects > 0 ? <span className="font-bold text-amber-600">· {j.openDefects} open defect(s)</span> : null}
                  </div>
                  <p className="text-xs text-slate-500">
                    <span className="font-bold text-slate-700">Residual gap: </span>
                    {j.residualGap}
                  </p>
                </Panel>
              );
            })}
          </div>
        </section>

        {/* ============================================================ */}
        {/* Q2 -- Is the release ready? */}
        {/* ============================================================ */}
        <section className="mb-10">
          <SectionHeader
            number={2}
            icon={Gauge}
            question="Is the release ready?"
            subtitle="A single Release Confidence Index, with its full breakdown -- never a black box."
          />
          <Panel>
            <div className="mb-1 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
              <div className="flex items-center gap-4">
                <div className="flex h-24 w-24 shrink-0 items-center justify-center rounded-full border-8 border-emerald-500 bg-emerald-50">
                  <span className="text-3xl font-black text-emerald-700">{RELEASE_CONFIDENCE.score}</span>
                </div>
                <div>
                  <p className="text-2xl font-black text-emerald-700">{RELEASE_CONFIDENCE.band}</p>
                  <p className="text-xs text-slate-500">Release Confidence Index -- as of {RELEASE_CONFIDENCE.asOf}</p>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-xl border border-cyan-200 bg-cyan-50 px-3 py-2 text-xs text-cyan-800 sm:max-w-sm">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  This index is <strong>configured and agreed with Wickes</strong> for this engagement -- the six
                  weighted components below, not a pre-existing industry standard.
                </span>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {RELEASE_CONFIDENCE.components.map((c) => (
                <div key={c.label} className="rounded-xl border border-slate-200 bg-slate-50/70 p-3">
                  <div className="mb-1 flex items-center justify-between">
                    <p className="text-sm font-bold text-slate-800">{c.label}</p>
                    <span className="text-2xs font-black text-slate-400">weight {c.weight}%</span>
                  </div>
                  <div className="mb-1.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
                    <div
                      className={`h-full rounded-full ${c.score >= 90 ? "bg-emerald-500" : c.score >= 75 ? "bg-amber-400" : "bg-red-500"}`}
                      style={{ width: `${c.score}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-500">{c.detail}</p>
                </div>
              ))}
            </div>
          </Panel>
        </section>

        {/* ============================================================ */}
        {/* Q3 -- Where is the risk? */}
        {/* ============================================================ */}
        <section className="mb-10">
          <SectionHeader number={3} icon={AlertTriangle} question="Where is the risk?" subtitle="Business-journey risk, change-impact, defect hotspots and blockers." />
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Panel title="High-risk business journeys" icon={AlertTriangle}>
              <ul className="space-y-2">
                {RISK.highRiskJourneys.map((r) => (
                  <li key={r.journey} className="rounded-lg border border-red-200 bg-red-50/60 p-2.5">
                    <p className="text-sm font-bold text-red-800">{r.journey}</p>
                    <p className="text-xs text-red-700/80">{r.reason}</p>
                  </li>
                ))}
              </ul>
            </Panel>

            <Panel title="Change-impact risk (this release's change requests)" icon={GitBranch}>
              <table className="w-full text-left text-xs">
                <thead className="text-slate-400">
                  <tr>
                    <th className="pb-1.5 font-bold">CR</th>
                    <th className="pb-1.5 font-bold">Journey</th>
                    <th className="pb-1.5 font-bold">Band</th>
                    <th className="pb-1.5 font-bold">Veto</th>
                  </tr>
                </thead>
                <tbody>
                  {RISK.changeImpact.map((c) => {
                    const tone = bandTone(c.band.split(" /")[0]);
                    return (
                      <tr key={c.id} className="border-t border-slate-100">
                        <td className="py-1.5 font-mono font-bold text-slate-700">{c.id}</td>
                        <td className="py-1.5 text-slate-600">{c.journey}</td>
                        <td className="py-1.5">
                          <span className={`rounded-full border px-1.5 py-0.5 text-2xs font-black ${tone.chip}`}>{c.band}</span>
                        </td>
                        <td className="py-1.5">{c.veto ? <span className="font-bold text-red-600">Yes</span> : <span className="text-slate-400">—</span>}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </Panel>

            <Panel title="Defect hotspots" icon={AlertTriangle}>
              <ul className="space-y-2">
                {RISK.defectHotspots.map((h) => (
                  <li key={h.area} className="rounded-lg border border-amber-200 bg-amber-50/60 p-2.5">
                    <p className="text-sm font-bold text-amber-900">{h.area} <span className="font-black">· {h.openDefects} open</span></p>
                    <p className="text-xs text-amber-800/80">{h.note}</p>
                  </li>
                ))}
              </ul>
            </Panel>

            <Panel title="Repeated failure areas" icon={TrendingDown}>
              <ul className="space-y-2">
                {RISK.repeatedFailures.map((f) => (
                  <li key={f.test} className="rounded-lg border border-slate-200 bg-slate-50 p-2.5">
                    <p className="font-mono text-xs font-bold text-slate-800">{f.test}</p>
                    <p className="text-xs text-slate-500">{f.failures} failures in the {f.window} -- {f.note}</p>
                  </li>
                ))}
              </ul>
            </Panel>

            <Panel title="Environment & dependency blockers" icon={CheckCircle2}>
              <ul className="space-y-1.5">
                {RISK.environmentBlockers.map((e) => (
                  <li key={e.area} className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700">{e.area}</span>
                    <span className="rounded-full border border-emerald-300 bg-emerald-100 px-2 py-0.5 font-black text-emerald-800">{e.status}</span>
                  </li>
                ))}
              </ul>
            </Panel>

            <Panel title="Supplier / component ownership" icon={Users}>
              <ul className="space-y-2">
                {RISK.supplierOwnership.map((s) => (
                  <li key={s.component} className="flex items-start justify-between gap-2 text-xs">
                    <div>
                      <p className="font-bold text-slate-800">{s.component}</p>
                      <p className="text-slate-500">{s.owner} -- {s.note}</p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full border px-2 py-0.5 font-black ${
                        s.status === "Stable" ? "border-emerald-300 bg-emerald-100 text-emerald-800" : "border-amber-300 bg-amber-100 text-amber-800"
                      }`}
                    >
                      {s.status}
                    </span>
                  </li>
                ))}
              </ul>
            </Panel>
          </div>
        </section>

        {/* ============================================================ */}
        {/* Q4 -- What value is automation generating? */}
        {/* ============================================================ */}
        <section className="mb-10">
          <SectionHeader number={4} icon={Clock} question="What value is automation generating?" subtitle="Hours avoided, what was selected or excluded and why, and reliability." />
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Panel title="Regression hours avoided this release" icon={Clock}>
              <p className="text-4xl font-black text-emerald-700">{AUTOMATION_VALUE.regressionHoursAvoidedThisRelease}h</p>
              <p className="mt-1 text-xs text-slate-500">{AUTOMATION_VALUE.regressionHoursAvoidedBasis}</p>
            </Panel>
            <Panel title="Regression cycle-time trend" icon={TrendingDown}>
              <Sparkline values={AUTOMATION_VALUE.cycleTimeTrendHrs} months={AUTOMATION_VALUE.cycleTimeTrendMonths} higherIsBetter={false} unit="h" />
            </Panel>
            <Panel title={`Tests selected by change-impact analysis -- worked example: ${CR1001_TEST_SELECTION.changeId}`} icon={GitBranch}>
              <div className="mb-2 flex gap-4 text-xs">
                <span><strong className="text-emerald-700">{AUTOMATION_VALUE.selectedViaChangeImpact}</strong> selected</span>
                <span><strong className="text-slate-500">{AUTOMATION_VALUE.excludedWithReasons}</strong> excluded, all with a traceable reason</span>
              </div>
              <ul className="max-h-40 space-y-1 overflow-y-auto pr-1">
                {CR1001_TEST_SELECTION.excluded.map((t) => (
                  <li key={t.path} className="rounded-lg border border-slate-200 bg-slate-50 p-2 text-xs">
                    <p className="font-mono font-bold text-slate-600">{t.path}</p>
                    <p className="text-slate-500">Excluded -- {t.reason}</p>
                  </li>
                ))}
              </ul>
            </Panel>
            <Panel title="Reusable assets adopted" icon={Building2}>
              <ul className="space-y-2">
                {AUTOMATION_VALUE.reusableAssetsAdopted.map((a) => (
                  <li key={a.asset} className="rounded-lg border border-cyan-200 bg-cyan-50/60 p-2.5 text-xs">
                    <p className="font-bold text-cyan-900">{a.asset}</p>
                    <p className="text-cyan-800/80">Adopted by: {a.adoptedBy} -- {a.note}</p>
                  </li>
                ))}
              </ul>
            </Panel>
            <Panel title="Automation reliability -- flaky-test trend" icon={TrendingDown} className="lg:col-span-2">
              <Sparkline values={AUTOMATION_VALUE.flakyTestTrendPct} months={AUTOMATION_VALUE.flakyTestTrendMonths} higherIsBetter={false} unit="%" />
            </Panel>
          </div>
        </section>

        {/* ============================================================ */}
        {/* Q5 -- Is quality improving? */}
        {/* ============================================================ */}
        <section>
          <SectionHeader number={5} icon={TrendingUp} question="Is quality improving?" subtitle="Trends, not monthly totals -- six months, one direction per metric." />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
            <Panel title="Defect leakage trend">
              <Sparkline values={QUALITY_TRENDS.defectLeakagePct} months={QUALITY_TRENDS.months} higherIsBetter={false} unit="%" />
            </Panel>
            <Panel title="Defect recurrence trend">
              <Sparkline values={QUALITY_TRENDS.defectRecurrencePct} months={QUALITY_TRENDS.months} higherIsBetter={false} unit="%" />
            </Panel>
            <Panel title="Release-confidence trend">
              <Sparkline values={QUALITY_TRENDS.releaseConfidenceIndex} months={QUALITY_TRENDS.months} higherIsBetter />
            </Panel>
            <Panel title="Journey coverage trend">
              <Sparkline values={QUALITY_TRENDS.journeyCoveragePct} months={QUALITY_TRENDS.months} higherIsBetter unit="%" />
            </Panel>
            <Panel title="Regression duration trend">
              <Sparkline values={QUALITY_TRENDS.regressionDurationHrs} months={QUALITY_TRENDS.months} higherIsBetter={false} unit="h" />
            </Panel>
            <Panel title="Environment-readiness trend">
              <Sparkline values={QUALITY_TRENDS.environmentReadinessPct} months={QUALITY_TRENDS.months} higherIsBetter unit="%" />
            </Panel>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
