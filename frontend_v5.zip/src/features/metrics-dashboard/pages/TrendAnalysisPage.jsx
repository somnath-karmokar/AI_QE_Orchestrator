import React, { useEffect, useMemo, useState } from "react";
import { useParams, useLocation } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import PlotLineChart from "../components/PlotLineChart";
import { kpiDetailsFallback as kpiData } from "../data/monthlyDashboardData";
import slugify from "slugify";
import { parseThreshold } from "../utils/ThresholdParser";
import { IoMdArrowRoundBack } from "react-icons/io";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { useMonth } from "../context/MonthContext";

export default function TrendAnalysisPage() {
  const { kpiName } = useParams();
  const location = useLocation();
  const { selectedMonth } = useMonth();
  const searchParams = new URLSearchParams(location.search);
  const queryMonth = searchParams.get("month");
  
  const { kpi: passedKpi, selectedPeriod = "" } = location.state || {};
  const selectedMonthId = location.state?.selectedMonthId || queryMonth || "";
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let active = true;
    if (!selectedMonth) {
      setApiPayload(null);
      setLoading(false);
      return () => {
        active = false;
      };
    }

    setLoading(true);

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async () => {
        if (!active) return;
        setApiPayload(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  const kpiFromApi = useMemo(() => {
    if (!apiPayload?.categories?.length) return null;

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}::${metric.domain || "Unassigned"}::${metric.portfolio || "General"}::${metric.project || "General"}`;
      analysisByMetric.set(key, metric);
    });

    const allKpis = apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const domain = metric.domain || "Unassigned";
        const portfolio = metric.portfolio || "General";
        const project = metric.project || "General";
        const key = `${category.name}::${metric.name}::${domain}::${portfolio}::${project}`;
        const analysis = analysisByMetric.get(key);
        // metric.history from the API is oldest-first (current month last);
        // the month filter just below expects newest-first (current month
        // first), the same convention KPIDashboard's own history uses.
        // Without this reverse, filtering to the latest month slices the
        // array down to that one point instead of the trailing six.
        const history = (metric.history || [])
          .map((item, index) => ({
            id: index + 1,
            period: item.month,
            value: item.value,
            status: "Amber",
            updated_at: item.month_id ? `${item.month_id}-01` : "",
          }))
          .reverse();
        return {
          dimension: category.name,
          domain,
          portfolio,
          project,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "", target: metric.target },
          value: metric.value,
          status: "Amber",
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
          analysisHistory: metric.analysis_history || [],
        };
      }),
    );

    const slugMatches = allKpis.filter((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName);
    if (passedKpi?.domain || passedKpi?.portfolio || passedKpi?.project) {
      const exactMatch = slugMatches.find(
        (k) =>
          (!passedKpi.domain || k.domain === passedKpi.domain) &&
          (!passedKpi.portfolio || k.portfolio === passedKpi.portfolio) &&
          (!passedKpi.project || k.project === passedKpi.project),
      );
      if (exactMatch) return exactMatch;
    }
    return slugMatches[0] || null;
  }, [apiPayload, kpiName, passedKpi?.domain, passedKpi?.portfolio, passedKpi?.project]);

  const kpi =
    kpiFromApi ||
    passedKpi ||
    kpiData.find((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName);

  if (!kpi) {
    if (loading) {
      return <div className="p-6 text-gray-500">Loading trend analysis...</div>;
    }
    return <div className="p-6 text-red-500">KPI not found</div>;
  }

  const threshold = parseThreshold(kpi.guidelines.ideal);
  const normalizedSelectedPeriod = selectedPeriod.trim().toLowerCase();

  // 1. Filter history up to selected month
  let currentHistory = [...kpi.history];
  if (selectedMonthId) {
    const targetIdx = currentHistory.findIndex(h => h.updated_at?.startsWith(selectedMonthId));
    if (targetIdx !== -1) {
      currentHistory = currentHistory.slice(targetIdx);
    }
  }
  const lastSix = currentHistory.slice(-6).reverse();
  const categories = lastSix.map((h) => h.period); 
  const values = lastSix.map((h) => h.value); 

  // 2. Filter analysis to match the selected month
  const analysisHistoryArray = Array.isArray(kpi.analysisHistory) ? kpi.analysisHistory : [];
  let currentAnalysis = {
    summary: kpi.analysisSummary,
    recommendation: kpi.analysisRecommendation,
    trend: kpi.analysisTrend,
    risk: kpi.analysisRisk,
    generatedMetric: kpi.generatedMetric,
    changeVsAvgPct: kpi.changeVsAvgPct,
  };
  let currentInsights = kpi.insights || [];
  let currentInsightPoints = kpi.insightPoints || [];

  const filteredAnalysisHistory = analysisHistoryArray.filter((entry) => {
    if (!entry) return false;
    const entryMonthId = String(entry.month_id || "").trim();
    const entryMonthLabel = String(entry.month || "").trim().toLowerCase();

    if (selectedMonthId && entryMonthId === selectedMonthId) return true;
    if (normalizedSelectedPeriod && entryMonthLabel === normalizedSelectedPeriod) return true;

    return false;
  });

  const displayAnalysisHistory =
    selectedMonthId || normalizedSelectedPeriod
      ? filteredAnalysisHistory.length > 0
        ? filteredAnalysisHistory
        : analysisHistoryArray
      : analysisHistoryArray;

  // Use the specific month's analysis for the top metrics if available
  if ((selectedMonthId || normalizedSelectedPeriod) && filteredAnalysisHistory.length > 0) {
    const specificAnalysis = filteredAnalysisHistory[0];
    currentAnalysis = {
      summary: specificAnalysis.summary || "",
      recommendation: specificAnalysis.recommendation || "",
      trend: specificAnalysis.trend || "",
      risk: specificAnalysis.risk || "",
      generatedMetric: specificAnalysis.generated_metric,
      changeVsAvgPct: specificAnalysis.change_vs_avg_pct,
    };
    currentInsights = specificAnalysis.insights || [];
    currentInsightPoints = (specificAnalysis.insights || []).map(
      (item) => `${item?.title || ""}: ${item?.description || ""}`.trim()
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 relative overflow-x-hidden p-4">
      {/* Decorative dark background orbs */}
      <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-indigo-900/40 to-transparent pointer-events-none" />
      <div className="absolute top-[10%] left-[-5%] w-[300px] h-[300px] rounded-full bg-cyan-600/20 blur-[100px] pointer-events-none" />

      <div className="flex items-center gap-4 mb-6 z-10">
        <button
          onClick={() => window.history.back()}
          className="p-2 rounded-xl bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-100 shadow-xl transition-all border border-slate-200"
        >
          <IoMdArrowRoundBack size={24} />
        </button>

        <h1 className="text-2xl font-bold text-slate-900 tracking-tight drop-shadow-md">
          {kpi.kpiname} <span className="text-cyan-400 font-medium ml-2">Trend Analysis</span>
        </h1>
      </div>
      <div className="z-10 mb-4 flex flex-wrap gap-3 text-sm text-slate-800">
        <span className="rounded-lg border border-slate-300 bg-white px-3 py-1.5">
          Domain: <span className="font-semibold text-slate-900">{kpi.domain || "Unassigned"}</span>
        </span>
        <span className="rounded-lg border border-slate-300 bg-white px-3 py-1.5">
          Portfolio: <span className="font-semibold text-slate-900">{kpi.portfolio || "General"}</span>
        </span>
        <span className="rounded-lg border border-slate-300 bg-white px-3 py-1.5">
          Project: <span className="font-semibold text-slate-900">{kpi.project || "General"}</span>
        </span>
      </div>
      
      <main className="flex-1 flex flex-col w-full max-w-[1600px] mx-auto z-10 bg-white/60 backdrop-blur-md rounded-2xl p-6 mb-8 border border-slate-200/50 shadow-xl">
        <div className="bg-white rounded-xl p-4 shadow-inner">
          {/* PlotLineChart might expect a light background for Highcharts/Chart.js readability unless we inject a dark theme to it. Wrapping it in a white container keeps the chart legible while the rest of the page is dark. */}
          <PlotLineChart
            title={kpi.kpiname}
            categories={categories}
            values={values}
            threshold={threshold}
            guidelines={kpi.guidelines}
            insights={currentInsights}
            insightPoints={currentInsightPoints}
            analysisHistory={displayAnalysisHistory}
            metricAnalysis={currentAnalysis}
          />
        </div>
      </main>
    </div>
  );
}
