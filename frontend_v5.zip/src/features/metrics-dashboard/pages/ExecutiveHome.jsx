import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Filter, Search } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import PortfolioSummaryCard from "../components/PortfolioSummaryCard";
import ProjectHealthCard from "../components/ProjectHealthCard";
import ProjectRAGTable from "../components/ProjectRAGTable";
import RiskPanel from "../components/RiskPanel";
import ExecutiveInsights from "../components/ExecutiveInsights";
import PortfolioCharts from "../components/PortfolioCharts";
import { useMonth } from "../context/MonthContext";
import { executiveMockProjects } from "../data/executiveMockProjects";

const FILTER_STORAGE_KEY = "qe-metrics.dashboard.filters";

function summarize(projects) {
  const total = projects.length || 1;
  const green = projects.filter((project) => project.rag === "green").length;
  const amber = projects.filter((project) => project.rag === "amber").length;
  const red = projects.filter((project) => project.rag === "red").length;
  const score = projects.length ? projects.reduce((sum, project) => sum + project.score, 0) / projects.length : 0;
  const trend = projects.length ? Math.round(projects.reduce((sum, project) => sum + project.trend, 0) / projects.length) : 0;
  return {
    total: projects.length,
    green,
    amber,
    red,
    score,
    trend,
    highRisk: projects.filter((project) => project.openRisks >= 4 || project.rag === "red").length,
    greenPct: (green / total) * 100,
    amberPct: (amber / total) * 100,
    redPct: (red / total) * 100,
  };
}

export default function ExecutiveHome() {
  const navigate = useNavigate();
  const { selectedMonth, months, setSelectedMonth } = useMonth();
  const [projects] = useState(executiveMockProjects);
  const [filters, setFilters] = useState({ domain: "", portfolio: "", project: "", search: "" });

  const options = useMemo(() => ({
    domains: Array.from(new Set(projects.map((project) => project.domain))).sort(),
    portfolios: Array.from(new Set(projects.filter((project) => !filters.domain || project.domain === filters.domain).map((project) => project.portfolio))).sort(),
    projects: Array.from(new Set(projects
      .filter((project) => !filters.domain || project.domain === filters.domain)
      .filter((project) => !filters.portfolio || project.portfolio === filters.portfolio)
      .map((project) => project.project))).sort(),
  }), [projects, filters.domain, filters.portfolio]);

  const filteredProjects = useMemo(() => projects.filter((project) => {
    const term = filters.search.trim().toLowerCase();
    return (!filters.domain || project.domain === filters.domain)
      && (!filters.portfolio || project.portfolio === filters.portfolio)
      && (!filters.project || project.project === filters.project)
      && (!term || project.project.toLowerCase().includes(term) || project.owner.toLowerCase().includes(term));
  }), [projects, filters]);

  const summary = useMemo(() => summarize(filteredProjects), [filteredProjects]);

  const openProject = (project) => {
    const nextFilters = {
      month: selectedMonth,
      domain: project.domain,
      portfolio: project.portfolio,
      project: project.project,
    };
    sessionStorage.setItem(FILTER_STORAGE_KEY, JSON.stringify(nextFilters));
    navigate("/metrics/dashboard", { state: { filters: nextFilters } });
  };

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-slate-100">
      <Header />
      <main className="mx-auto flex w-full max-w-[1800px] flex-1 flex-col gap-6 px-3 pb-10 sm:px-5">
        <section className="rounded-2xl border border-slate-300/70 bg-white/80 px-5 py-4 shadow-xl backdrop-blur-md">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end">
            <div className="flex min-w-[150px] items-center gap-2 font-black text-slate-900">
              <Filter size={18} className="text-cyan-700" />
              Filters
            </div>
            <Select label="Domain" value={filters.domain} options={options.domains} onChange={(value) => setFilters((current) => ({ ...current, domain: value, portfolio: "", project: "" }))} />
            <Select label="Portfolio" value={filters.portfolio} options={options.portfolios} onChange={(value) => setFilters((current) => ({ ...current, portfolio: value, project: "" }))} />
            <Select label="Project" value={filters.project} options={options.projects} onChange={(value) => setFilters((current) => ({ ...current, project: value }))} />
            
            <Select label="Month" value={selectedMonth} options={months} onChange={setSelectedMonth} className="xl:max-w-[180px]" />
          </div>
        </section>

        <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <PortfolioSummaryCard label="Total Projects" value={summary.total} sub="In current view" />
          <PortfolioSummaryCard label="Green" value={summary.green}  tone="green" />
          <PortfolioSummaryCard label="Amber" value={summary.amber}  tone="amber" />
          <PortfolioSummaryCard label="Red" value={summary.red} tone="red" />
        </section>

        <div className="grid grid-cols-1 items-start gap-6 xl:grid-cols-[1fr_360px]">
          <section className="grid grid-cols-1 gap-5 md:grid-cols-2 2xl:grid-cols-3 content-start">
            {filteredProjects.map((project) => <ProjectHealthCard key={project.id} project={project} onOpen={openProject} />)}
          </section>
          <RiskPanel projects={filteredProjects} onOpen={openProject} />
        </div>

        <ExecutiveInsights summary={summary} />

        <PortfolioCharts projects={filteredProjects} summary={summary} />
        <ProjectRAGTable projects={filteredProjects} onOpen={openProject} />
      </main>
      <Footer />
    </div>
  );
}

function Select({ label, value, options, onChange, className = "" }) {
  return (
    <label className={`flex-1 text-sm font-semibold text-slate-600 ${className}`}>
      <span className="mb-1 block">{label}</span>
      <select value={value || ""} onChange={(event) => onChange(event.target.value)} className="w-full rounded-lg border border-slate-400 bg-slate-100 px-3 py-2 text-slate-900 outline-none focus:border-cyan-400">
        <option value="">All</option>
        {(options || []).map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    </label>
  );
}
