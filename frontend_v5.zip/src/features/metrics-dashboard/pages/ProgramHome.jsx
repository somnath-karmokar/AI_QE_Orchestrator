import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Filter, ArrowUpRight, Building2, FolderKanban, CalendarDays, XCircle } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import PortfolioSummaryCard from "../components/PortfolioSummaryCard";
import ProjectHealthCard from "../components/ProjectHealthCard";
import ProjectRAGTable from "../components/ProjectRAGTable";
import RiskPanel from "../components/RiskPanel";
import ExecutiveInsights from "../components/ExecutiveInsights";
import { useMonth } from "../context/MonthContext";
import { executiveMockProjects } from "../data/executiveMockProjects";

const FILTER_STORAGE_KEY = "qe-metrics.dashboard.filters";

function summarize(projects) {
  const total = projects.length || 1;
  const green = projects.filter((project) => project.rag === "green").length;
  const amber = projects.filter((project) => project.rag === "amber").length;
  const red = projects.filter((project) => project.rag === "red").length;
  const score = projects.length ? projects.reduce((sum, project) => sum + project.score, 0) / projects.length : 0;
  const trend = projects.length ? Math.round(projects.reduce((sum, project) => sum + project.trend, 0) / projects.length) : 0;
  return {
    total: projects.length,
    green,
    amber,
    red,
    score,
    trend,
    highRisk: projects.filter((project) => project.openRisks >= 4 || project.rag === "red").length,
    greenPct: (green / total) * 100,
    amberPct: (amber / total) * 100,
    redPct: (red / total) * 100,
  };
}

export default function ProgramHome() {
  const navigate = useNavigate();
  const { selectedMonth, months, setSelectedMonth } = useMonth();
  const [projects] = useState(executiveMockProjects);
  const [selectedPortfolio, setSelectedPortfolio] = useState("");
  const [selectedProject, setSelectedProject] = useState("");

  const portfolioOptions = useMemo(
    () => Array.from(new Set(projects.map((project) => project.portfolio))).sort(),
    [projects],
  );

  const projectOptions = useMemo(
    () =>
      projects
        .filter((project) => !selectedPortfolio || project.portfolio === selectedPortfolio)
        .map((project) => project.project)
        .sort(),
    [projects, selectedPortfolio],
  );

  const filteredProjects = useMemo(
    () =>
      projects.filter((project) => {
        const portfolioMatch = !selectedPortfolio || project.portfolio === selectedPortfolio;
        const projectMatch = !selectedProject || project.project === selectedProject;
        return portfolioMatch && projectMatch;
      }),
    [projects, selectedPortfolio, selectedProject],
  );

  const summary = useMemo(() => summarize(filteredProjects), [filteredProjects]);

  const openProject = (project) => {
    const nextFilters = {
      month: selectedMonth,
      domain: project.domain,
      portfolio: project.portfolio,
      project: project.project,
    };
    sessionStorage.setItem(FILTER_STORAGE_KEY, JSON.stringify(nextFilters));
    navigate("/metrics/dashboard", { state: { filters: nextFilters } });
  };

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-slate-100">
      <Header />
      <main className="mx-auto flex w-full max-w-[1800px] flex-1 flex-col gap-6 px-3 pb-10 sm:px-5">
        <section className="flex flex-wrap items-end gap-x-6 gap-y-4 rounded-2xl border border-slate-300/70 bg-white/80 px-5 py-4 shadow-xl backdrop-blur-md">
          <div className="flex items-center gap-2 pb-0.5 text-sm font-black uppercase tracking-wide text-slate-600">
            <Filter size={15} className="text-cyan-700" />
            Filters
          </div>

          <div className="h-9 w-px self-stretch bg-slate-100/70" />

          <label className="w-full min-w-[160px] flex-1 text-sm font-semibold text-slate-600 sm:max-w-xs">
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">
              <Building2 size={12} className="text-cyan-700" /> Portfolio
            </span>
            <select
              value={selectedPortfolio}
              onChange={(event) => {
                setSelectedPortfolio(event.target.value);
                setSelectedProject("");
              }}
              className="w-full rounded-lg border border-slate-300/80 bg-slate-100/70 px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50"
            >
              <option value="">All Portfolios</option>
              {portfolioOptions.map((portfolio) => (
                <option key={portfolio} value={portfolio}>
                  {portfolio}
                </option>
              ))}
            </select>
          </label>
          <label className="w-full min-w-[160px] flex-1 text-sm font-semibold text-slate-600 sm:max-w-xs">
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">
              <FolderKanban size={12} className="text-cyan-700" /> Project
            </span>
            <select
              value={selectedProject}
              onChange={(event) => setSelectedProject(event.target.value)}
              className="w-full rounded-lg border border-slate-300/80 bg-slate-100/70 px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50"
            >
              <option value="">All Projects</option>
              {projectOptions.map((project) => (
                <option key={project} value={project}>
                  {project}
                </option>
              ))}
            </select>
          </label>
          <label className="w-full min-w-[140px] flex-1 text-sm font-semibold text-slate-600 sm:max-w-[200px]">
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">
              <CalendarDays size={12} className="text-cyan-700" /> Month
            </span>
            <select
              value={selectedMonth || ""}
              onChange={(event) => setSelectedMonth(event.target.value)}
              className="w-full rounded-lg border border-slate-300/80 bg-slate-100/70 px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50"
            >
              {months.map((month) => (
                <option key={month} value={month}>
                  {month}
                </option>
              ))}
            </select>
          </label>

          {(selectedPortfolio || selectedProject) && (
            <button
              type="button"
              onClick={() => {
                setSelectedPortfolio("");
                setSelectedProject("");
              }}
              className="mb-0.5 inline-flex items-center gap-1.5 rounded-lg border border-slate-300/70 bg-slate-100/60 px-3 py-2 text-xs font-bold text-slate-600 transition-all hover:border-slate-500 hover:text-slate-900 sm:ml-auto"
            >
              <XCircle size={14} /> Clear filters
            </button>
          )}
        </section>

        <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <PortfolioSummaryCard label="Total Projects" value={summary.total} sub="In current view" />
          <PortfolioSummaryCard label="Green" value={summary.green} tone="green" />
          <PortfolioSummaryCard label="Amber" value={summary.amber} tone="amber" />
          <PortfolioSummaryCard label="Red" value={summary.red} tone="red" />
        </section>

        <div className="grid grid-cols-1 items-start gap-6 xl:grid-cols-[1fr_360px]">
          <section className="grid grid-cols-1 gap-5 md:grid-cols-2 2xl:grid-cols-3 content-start">
            {filteredProjects.map((project) => (
              <ProjectHealthCard key={project.id} project={project} onOpen={openProject} />
            ))}
            {filteredProjects.length === 0 && (
              <div className="col-span-full rounded-2xl border border-slate-300/70 bg-white/80 px-6 py-5 text-slate-800">
                No projects match the selected filters.
              </div>
            )}
          </section>
          <RiskPanel projects={filteredProjects} onOpen={openProject} />
        </div>

        <ExecutiveInsights summary={summary} />

        <ProjectRAGTable projects={filteredProjects} onOpen={openProject} />

        <div className="flex justify-center pt-4">
          <button
            type="button"
            onClick={() => navigate("/metrics/executive-home")}
            className="inline-flex items-center gap-2 rounded-xl border border-cyan-300/30 bg-cyan-400/10 px-5 py-3 text-sm font-black text-cyan-800 shadow-xl backdrop-blur-md transition-all hover:-translate-y-0.5 hover:bg-cyan-400/20"
          >
            Go to Executive Project View <ArrowUpRight size={16} />
          </button>
        </div>
      </main>
      <Footer />
    </div>
  );
}
