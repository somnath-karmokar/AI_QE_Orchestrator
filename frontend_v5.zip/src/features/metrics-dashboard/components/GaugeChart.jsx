import React, { useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import Highcharts from "highcharts";
import HighchartsMore from "highcharts/highcharts-more";
import SolidGauge from "highcharts/modules/solid-gauge";
import { ComputegaugeAxis } from "../utils/ComputegaugeAxis";

if (typeof HighchartsMore === "function") HighchartsMore(Highcharts);
if (typeof SolidGauge === "function") SolidGauge(Highcharts);

export default function GaugeChart({
  title,
  value,
  status,
  threshold,
  historyValues = [],
  trendLink,
  kpiData,
  monthDate,
}) {
  const chartRef = useRef(null);

  const getColor = () => {
    if (status === "Green") return "#55BF3B";
    if (status === "Amber") return "#DDDF0D";
    if (status === "Red") return "#DF5353";
    return "#7cb5ec";
  };

  useEffect(() => {
    if (!chartRef.current) return;

    const axis = ComputegaugeAxis({ value, threshold, historyValues });
    const showPlotLine =
      Number.isFinite(Number(threshold)) &&
      Number(threshold) >= axis.min &&
      Number(threshold) <= axis.max;

    Highcharts.chart(chartRef.current, {
      chart: {
        type: "solidgauge",
        height: "100%",
        backgroundColor: "transparent",
        spacingTop: 10,
        spacingBottom: 40,
        spacingLeft: 25,
        spacingRight: 30,
      },
      title: null,
      tooltip: { enabled: false },
      credits: { enabled: false },

      pane: {
        center: ["50%", "80%"],
        size: "100%",
        startAngle: -90,
        endAngle: 90,
        background: {
          backgroundColor: "rgba(15,23,42,0.08)", // slate-900 tint on light track
          innerRadius: "60%",
          outerRadius: "100%",
          shape: "arc",
        },
      },

      yAxis: {
        min: axis.min,
        max: axis.max,
        tickAmount: axis.tickAmount,          
        lineWidth: 0,
        tickWidth: 2,
        tickColor: "#475569", // slate-600
        tickPosition: "outside",
        labels: {
          enabled: true,
          distance: 17,
          style: { fontSize: "12px", color: "#334155", fontWeight: "bold", fontFamily: "Inter, sans-serif" },
          formatter: function () {
            return axis.isPercent ? `${this.value}` : this.value;
          },
        },
        plotLines: showPlotLine
          ? [
              {
                value: Number(threshold),
                color: "#334155", // slate-700
                width: 3,
                zIndex: 10,
              },
            ]
          : [],
      },

      plotOptions: {
        solidgauge: {
          dataLabels: {
            y: -25,
            borderWidth: 0,
            useHTML: true,
            format: `<div style="text-align:center">
                      <span style="font-size:20px; font-weight:bold; color: #0f172a; font-family: Inter, sans-serif;">
                        {y}${axis.isPercent ? "" : ""}
                      </span>
                    </div>`,
          },
        },
      },

      series: [
        {
          name: title,
          data: [{ y: Number(value), color: getColor() }],
        },
      ],
    });
  }, [value, title, status, threshold, historyValues]);

  return (
    <div className="flex flex-col items-center justify-between h-full bg-transparent p-2">
      <div ref={chartRef} className="w-full h-full max-w-[280px]" />
      <div className="w-full mt-3 mb-2 flex items-center justify-between px-2 gap-2">
        <h3 className="text-base font-bold text-slate-800 tracking-wide whitespace-nowrap">{title}</h3>
        <Link
          to={trendLink}
          state={{
            kpi: kpiData,
            selectedPeriod: title,
            selectedMonthId: typeof monthDate === "string" ? monthDate.slice(0, 7) : "",
          }}
          className="text-sm font-bold text-cyan-800 hover:text-cyan-900 hover:underline transition-colors bg-cyan-100 border border-cyan-200 hover:bg-cyan-200 px-3 py-1.5 rounded-lg whitespace-nowrap"
        >
          Trend for {title} &rarr;
        </Link>
      </div>
    </div>
  );
}
