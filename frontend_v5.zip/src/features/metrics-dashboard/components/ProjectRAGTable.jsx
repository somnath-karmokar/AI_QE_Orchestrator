import { useMemo, useState } from "react";
import { ArrowUpDown, ArrowUpRight } from "lucide-react";

const columns = ["Engineering", "Velocity", "Automation", "Quality", "Environment"];
const toneMap = {
  green: "bg-green-600 text-white border-green-400 shadow-[0_0_14px_rgba(22,163,74,0.30)]",
  amber: "bg-amber-500 text-slate-950 border-amber-300 shadow-[0_0_14px_rgba(245,158,11,0.30)]",
  red: "bg-red-600 text-white border-red-400 shadow-[0_0_14px_rgba(220,38,38,0.30)]",
};

function Chip({ value }) {
  const text = value === "green" ? "Green" : value === "red" ? "Red" : "Amber";
  return <span className={`rounded-full border px-2.5 py-1 text-[11px] font-black ${toneMap[value] || toneMap.amber}`}>{text}</span>;
}

export default function ProjectRAGTable({ projects, onOpen }) {
  const [sortKey, setSortKey] = useState("score");
  const [direction, setDirection] = useState("desc");
  const [page, setPage] = useState(0);
  const pageSize = 8;

  const sorted = useMemo(() => {
    const copy = [...projects];
    copy.sort((a, b) => {
      const left = a[sortKey] ?? "";
      const right = b[sortKey] ?? "";
      const result = typeof left === "number" ? left - right : String(left).localeCompare(String(right));
      return direction === "asc" ? result : -result;
    });
    return copy;
  }, [projects, sortKey, direction]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const rows = sorted.slice(page * pageSize, page * pageSize + pageSize);

  const handleSort = (key) => {
    setPage(0);
    if (sortKey === key) setDirection((value) => (value === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setDirection("desc");
    }
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-300/70 bg-white/88 shadow-xl backdrop-blur-md">
      <div className="flex items-center justify-between gap-3 border-b border-slate-200/70 px-5 py-4">
        <div>
          <h2 className="text-lg font-black text-slate-900">Project RAG Table</h2>
          <p className="text-xs font-semibold text-slate-500">Sortable health matrix</p>
        </div>
        <p className="text-xs font-bold text-slate-500">{projects.length} projects</p>
      </div>
      <div className="max-h-[520px] overflow-auto">
        <table className="w-full min-w-[1120px] border-collapse text-left text-sm">
          <thead className="sticky top-0 z-10 bg-slate-100">
            <tr className="border-b border-slate-200/70 text-xs uppercase tracking-widest text-slate-500">
              {["project", "portfolio", "score"].map((key) => (
                <th key={key} className="whitespace-nowrap px-4 py-3">
                  <button type="button" onClick={() => handleSort(key)} className="inline-flex items-center gap-1 font-black">
                    {key === "score" ? "Overall Health" : key} <ArrowUpDown size={13} />
                  </button>
                </th>
              ))}
              {columns.map((column) => <th key={column} className="whitespace-nowrap px-4 py-3 font-black">{column}</th>)}
              <th className="px-4 py-3 font-black">Open Risks</th>
              <th className="px-4 py-3 font-black">Owner</th>
              <th className="px-4 py-3 font-black">Trend</th>
              <th className="px-4 py-3 font-black">Last Updated</th>
              <th className="px-4 py-3 font-black">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((project) => (
              <tr key={project.id} className="border-b border-slate-100/90 text-slate-800 hover:bg-white/45">
                <td className="px-4 py-3 font-black text-slate-900">{project.project}</td>
                <td className="px-4 py-3 font-semibold text-slate-500">{project.portfolio}</td>
                <td className="whitespace-nowrap px-4 py-3">
                  <Chip value={project.rag} />
                </td>
                {columns.map((column) => <td key={column} className="px-4 py-3"><Chip value={project.kpis?.[column] || "amber"} /></td>)}
                <td className="px-4 py-3 font-black">{project.openRisks}</td>
                <td className="px-4 py-3 font-semibold text-slate-600">{project.owner}</td>
                <td className={`px-4 py-3 font-black ${project.trend >= 0 ? "text-emerald-700" : "text-red-700"}`}>{project.trend > 0 ? "+" : ""}{project.trend}%</td>
                <td className="px-4 py-3 text-slate-500">{project.lastUpdated}</td>
                <td className="px-4 py-3">
                  <button type="button" onClick={() => onOpen(project)} className="inline-flex items-center gap-1 rounded-lg border border-cyan-300/30 bg-cyan-400/10 px-3 py-1.5 text-xs font-black text-cyan-800">
                    Open <ArrowUpRight size={13} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between px-5 py-4 text-sm font-bold text-slate-600">
        <button type="button" disabled={page === 0} onClick={() => setPage((value) => Math.max(0, value - 1))} className="rounded-lg border border-slate-300 px-3 py-1.5 disabled:opacity-35">Previous</button>
        <span>Page {page + 1} of {pageCount}</span>
        <button type="button" disabled={page >= pageCount - 1} onClick={() => setPage((value) => Math.min(pageCount - 1, value + 1))} className="rounded-lg border border-slate-300 px-3 py-1.5 disabled:opacity-35">Next</button>
      </div>
    </div>
  );
}
