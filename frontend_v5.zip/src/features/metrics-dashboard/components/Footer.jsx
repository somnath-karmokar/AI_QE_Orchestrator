import React from "react";

export default function Footer() {
  return (
    <footer className="bg-white/50 backdrop-blur-md border border-slate-200/50 mx-2 mt-4 mb-2 text-center py-5 rounded-xl flex flex-col items-center justify-center">
      <span className="text-slate-500 font-medium text-base tracking-wide">
        &copy; 2026 QE Metrics Dashboard. All rights reserved.
      </span>
    </footer>
  );
}
