import { AlertTriangle, ArrowUpRight } from "lucide-react";

const toneMap = {
  red: "border-red-300/35 bg-red-400/10 text-red-800",
  amber: "border-amber-300/40 bg-amber-400/10 text-amber-800",
  green: "border-emerald-300/35 bg-emerald-400/10 text-emerald-800",
};

export default function RiskPanel({ projects, onOpen }) {
  const riskyProjects = [...projects]
    .sort((a, b) => (b.openRisks + b.criticalKpis * 2) - (a.openRisks + a.criticalKpis * 2))
    .slice(0, 10);

  return (
    <aside className="rounded-2xl border border-red-300/25 bg-white/88 p-5 shadow-xl backdrop-blur-md">
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-xl border border-red-300/30 bg-red-400/10 p-2 text-red-700">
          <AlertTriangle size={20} />
        </div>
        <div>
          <h2 className="text-lg font-black text-slate-900">Top Risks</h2>
          <p className="text-xs font-semibold text-slate-500">Projects needing attention</p>
        </div>
      </div>
      <div className="space-y-3">
        {riskyProjects.map((project) => (
          <button
            type="button"
            key={project.id}
            onClick={() => onOpen(project)}
            className={`w-full rounded-xl border ${toneMap[project.rag] || toneMap.amber} p-3 text-left transition-all hover:-translate-y-0.5 hover:bg-white/70`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-black text-slate-900">{project.project}</p>
                <p className="mt-1 text-xs font-semibold text-slate-500">{project.risks?.slice(0, 2).join(" | ")}</p>
              </div>
              <ArrowUpRight size={15} className="shrink-0" />
            </div>
          </button>
        ))}
      </div>
    </aside>
  );
}
