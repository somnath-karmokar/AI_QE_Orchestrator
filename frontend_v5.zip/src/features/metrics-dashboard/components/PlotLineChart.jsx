import React, { useEffect, useRef, useState } from "react";
import Highcharts from "highcharts";
import { parseThreshold } from "../utils/ThresholdParser";
import { FiCopy } from "react-icons/fi";
import { FaArrowUp, FaArrowDown, FaChartLine } from "react-icons/fa";

export default function PlotLineChart({
  title,
  categories,
  values,
  threshold,
  guidelines,
  insights = [],
  insightPoints = [],
  analysisHistory = [],
  metricAnalysis = {},
}) {
  const chartRef = useRef(null);
  const [summary, setSummary] = useState({});
  const [copied, setCopied] = useState(false);

  const buildBands = () => {
    const bands = [];
    if (!guidelines) return bands;

    if (guidelines.red) {
      const max = parseThreshold(guidelines.red);
      bands.push({ from: 0, to: max, color: "rgba(255,0,0,0.1)" });
    }

    if (guidelines.amber) {
      const [min, max] = guidelines.amber
        .split("-")
        .map((s) => parseInt(s, 10));
      bands.push({ from: min, to: max + 1, color: "rgba(255,165,0,0.1)" });
    }

    if (guidelines.green) {
      const min = parseThreshold(guidelines.green);
      bands.push({ from: min, to: 100, color: "rgba(0,128,0,0.1)" });
    }

    return bands;
  };

  // RAG per point/segment: green where a month improved on the one before
  // it, red where it declined, amber where it held flat -- there is no fixed
  // guideline band for every metric here, so direction of travel is what
  // "red/amber/green" means for a trend line. Which direction counts as
  // "improved" depends on the metric: a rising pass rate is good, a rising
  // defect count is not, so this reads guidelines.target ("higher"|"lower")
  // rather than assuming up always means better.
  const RAG_COLORS = { green: "#059669", amber: "#d97706", red: "#dc2626" };
  const higherIsBetter = guidelines?.target !== "lower";

  const ragForStep = (current, previous) => {
    if (previous === null || previous === undefined || current === previous) return RAG_COLORS.amber;
    const rose = current > previous;
    const improved = higherIsBetter ? rose : !rose;
    return improved ? RAG_COLORS.green : RAG_COLORS.red;
  };

  useEffect(() => {
    if (!chartRef.current) return;

    const seriesValues = values || [];
    const pointColors = seriesValues.map((v, i) => ragForStep(v, i > 0 ? seriesValues[i - 1] : null));
    const ragData = seriesValues.map((v, i) => ({ y: v, color: pointColors[i], marker: { fillColor: pointColors[i] } }));
    // zoneAxis 'x' colours each line SEGMENT by the point it leads into, so a
    // segment reads red exactly where that step declined.
    const zones = seriesValues.slice(1).map((v, i) => ({ value: i + 1, color: ragForStep(v, seriesValues[i]) }));

    Highcharts.chart(chartRef.current, {
      chart: { type: "line", backgroundColor: "transparent" },
      title: { text: "" },
      credits: { enabled: false },
      xAxis: { 
        categories: categories || [],
        labels: { style: { color: "#334155", fontFamily: "Inter, sans-serif", fontWeight: "bold" } },
        lineColor: "#334155",
        tickColor: "#334155"
      },
      yAxis: {
        title: { text: null },
        labels: { style: { color: "#334155", fontFamily: "Inter, sans-serif", fontWeight: "bold" } },
        gridLineColor: "#e2e8f0",
        plotLines: threshold
          ? [
              {
                value: threshold,
                color: "#10b981", // emerald-500
                dashStyle: "Dash",
                width: 2,
                label: {
                  text: `Ideal >= ${threshold}`,
                  align: "right",
                  x: -10,
                  style: { color: "#047857", fontWeight: "bold", fontFamily: "Inter, sans-serif" },
                },
                zIndex: 5,
              },
            ]
          : [],
        plotBands: buildBands(),
      },
      tooltip: {
        backgroundColor: "rgba(15, 23, 42, 0.9)", // slate-900
        borderColor: "#334155",
        style: { color: "#f8fafc" }
      },
      series: [{
        showInLegend: false,
        name: title || "Value",
        data: ragData,
        zoneAxis: "x",
        zones,
        lineWidth: 3,
        marker: {
          lineWidth: 2,
          lineColor: "#ffffff",
        },
      }],
    });
  }, [title, categories, values, threshold, guidelines]);

  useEffect(() => {
    if (!categories || !values || values.length === 0) return;

    const maxVal = Math.max(...values);
    const minVal = Math.min(...values);
    const lastVal = values[values.length - 1];

    const maxIndex = values.indexOf(maxVal);
    const minIndex = values.indexOf(minVal);

    let majorImpact = null;
    if (values.length >= 2) {
      const prev = values[values.length - 2];
      const change = ((lastVal - prev) / prev) * 100;
      majorImpact = `Between ${categories[values.length - 2]} -> ${
        categories[values.length - 1]
      }, ${change > 0 ? "increased" : "declined"} by ${Math.abs(
        change.toFixed(1)
      )}%`;
    }

    let improvementStreak = 0;
    let declineStreak = 0;
    let maxImprovement = 0;
    let maxDecline = 0;

    for (let i = 1; i < values.length; i++) {
      if (values[i] > values[i - 1]) {
        improvementStreak++;
        declineStreak = 0;
      } else if (values[i] < values[i - 1]) {
        declineStreak++;
        improvementStreak = 0;
      } else {
        improvementStreak = 0;
        declineStreak = 0;
      }
      maxImprovement = Math.max(maxImprovement, improvementStreak);
      maxDecline = Math.max(maxDecline, declineStreak);
    }

    const overallTrend = (((lastVal - values[0]) / values[0]) * 100).toFixed(1);

    const compliance = { green: 0, amber: 0, red: 0 };
    values.forEach((val) => {
      if (guidelines.green && val >= parseThreshold(guidelines.green)) {
        compliance.green++;
      } else if (guidelines.amber) {
        const [min, max] = guidelines.amber
          .split("-")
          .map((s) => parseInt(s, 10));
        if (val >= min && val <= max) compliance.amber++;
        else compliance.red++;
      } else {
        compliance.red++;
      }
    });

    setSummary({
      highest: `Highest: ${maxVal} (${categories[maxIndex]})`,
      lowest: `Lowest: ${minVal} (${categories[minIndex]})`,
      latest: `Latest: ${lastVal} (${categories[values.length - 1]})`,
      impact: majorImpact,
      improvement: `Improvement streak: ${maxImprovement} sprints`,
      decline: `Decline streak: ${maxDecline} sprints`,
      trend: `Overall trend: ${overallTrend}% over last ${values.length} sprints`,
      compliance: `Guideline compliance: Green - ${compliance.green}, Amber - ${compliance.amber}, Red - ${compliance.red}`,
    });
  }, [categories, values, guidelines]);

  const handleCopy = () => {
    const textToCopy = [
      `${title} - Highlights`,
      ...Object.values(summary).filter(Boolean),
      ...(Array.isArray(insightPoints) ? insightPoints : []),
    ].join("\n");

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-6 text-slate-800">
      <div className="bg-slate-100/50 backdrop-blur-md rounded-2xl p-4 border border-slate-200/50 shadow-inner">
        <div ref={chartRef} style={{ height: "400px", width: "100%" }} />
      </div>

      <div className="bg-white/80 backdrop-blur-md shadow-xl rounded-2xl p-6 relative border border-slate-200/50">
        <h2 className="text-xl font-bold mb-6 text-slate-900 flex items-center gap-3 drop-shadow-md">
          <div className="p-2 bg-cyan-500/20 rounded-lg text-cyan-400 border border-cyan-500/30">
            <FaChartLine size={18} />
          </div>
          Highlights
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="flex flex-col gap-1 p-5 bg-emerald-900/40 border border-emerald-500/40 rounded-xl shadow-inner group hover:bg-emerald-900/60 transition-colors">
            <div className="flex items-center gap-2 text-emerald-700 mb-1">
              <FaArrowUp />
              <span className="text-xs font-bold uppercase tracking-wider">Highest</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.highest?.replace("Highest: ", "")}</span>
          </div>

          <div className="flex flex-col gap-1 p-5 bg-rose-900/40 border border-rose-500/40 rounded-xl shadow-inner group hover:bg-rose-900/60 transition-colors">
            <div className="flex items-center gap-2 text-rose-700 mb-1">
              <FaArrowDown />
              <span className="text-xs font-bold uppercase tracking-wider">Lowest</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.lowest?.replace("Lowest: ", "")}</span>
          </div>

          <div className="flex flex-col gap-1 p-5 bg-sky-900/40 border border-sky-500/40 rounded-xl shadow-inner group hover:bg-sky-900/60 transition-colors">
            <div className="flex items-center gap-2 text-sky-300 mb-1">
              <FaChartLine />
              <span className="text-xs font-bold uppercase tracking-wider">Latest</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.latest?.replace("Latest: ", "")}</span>
          </div>

          {summary.impact && (
            <div className="flex flex-col gap-1 p-5 bg-amber-900/40 border border-amber-500/40 rounded-xl shadow-inner group hover:bg-amber-900/60 transition-colors">
              <div className="flex items-center gap-2 text-amber-700 mb-1">
                <FaChartLine />
                <span className="text-xs font-bold uppercase tracking-wider">Impact</span>
              </div>
              <span className="text-slate-900 text-base font-bold">{summary.impact}</span>
            </div>
          )}

          <div className="flex flex-col gap-1 p-5 bg-emerald-900/40 border border-emerald-500/40 rounded-xl shadow-inner group hover:bg-emerald-900/60 transition-colors">
            <div className="flex items-center gap-2 text-emerald-700 mb-1">
              <FaArrowUp />
              <span className="text-xs font-bold uppercase tracking-wider">Improvement</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.improvement?.replace("Improvement streak: ", "")}</span>
          </div>

          <div className="flex flex-col gap-1 p-5 bg-rose-900/40 border border-rose-500/40 rounded-xl shadow-inner group hover:bg-rose-900/60 transition-colors">
            <div className="flex items-center gap-2 text-rose-700 mb-1">
              <FaArrowDown />
              <span className="text-xs font-bold uppercase tracking-wider">Decline</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.decline?.replace("Decline streak: ", "")}</span>
          </div>

          <div className="flex flex-col gap-1 p-5 bg-indigo-900/40 border border-indigo-500/40 rounded-xl shadow-inner group hover:bg-indigo-900/60 transition-colors">
            <div className="flex items-center gap-2 text-indigo-300 mb-1">
              <FaChartLine />
              <span className="text-xs font-bold uppercase tracking-wider">Trend</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.trend?.replace("Overall trend: ", "")}</span>
          </div>

          <div className="flex flex-col gap-1 p-5 bg-fuchsia-900/40 border border-fuchsia-500/40 rounded-xl shadow-inner group hover:bg-fuchsia-900/60 transition-colors">
            <div className="flex items-center gap-2 text-fuchsia-700 mb-1">
              <FaChartLine />
              <span className="text-xs font-bold uppercase tracking-wider">Compliance</span>
            </div>
            <span className="text-slate-900 text-base font-bold">{summary.compliance?.replace("Guideline compliance: ", "")}</span>
          </div>
        </div>

        <button
          onClick={handleCopy}
          className="absolute top-6 right-6 p-2 rounded-lg bg-slate-100/50 text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors border border-slate-300/50"
          title="Copy Highlights"
        >
          <FiCopy size={18} />
        </button>

        {copied && (
          <span className="absolute top-8 right-16 text-emerald-400 text-sm font-medium animate-fade-in">
            Copied!
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {Array.isArray(insightPoints) && insightPoints.length > 0 && (
          <div className="bg-white/80 backdrop-blur-md shadow-xl rounded-2xl p-6 border border-slate-200/50 flex flex-col h-full">
            <h2 className="text-lg font-bold mb-4 text-slate-900 flex items-center gap-2">
              <div className="w-2 h-6 bg-cyan-500 rounded-full" />
              AI Insights
            </h2>
            {Array.isArray(insights) && insights.length > 0 ? (
              <div className="space-y-4 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                {insights.map((item, idx) => (
                  <div key={`${idx}-${item?.title || "insight"}`} className="bg-slate-100/70 border border-slate-300 rounded-xl p-5 shadow-inner">
                    <p className="text-base font-bold text-cyan-700 mb-2">{item?.title}</p>
                    {item?.description && (
                      <p className="text-base text-slate-900 font-medium leading-relaxed">{item.description}</p>
                    )}
                    {item?.example && (
                      <p className="text-sm text-indigo-200 font-bold mt-3 p-3 bg-indigo-900/40 rounded-lg">Example: {item.example}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <ul className="space-y-3">
                {insightPoints.map((point, idx) => (
                  <li key={`${idx}-${point}`} className="text-base text-slate-900 font-medium flex items-start gap-2 bg-slate-100/70 p-4 rounded-xl border border-slate-300 shadow-inner">
                    <span className="text-cyan-400 mt-1 shrink-0 font-bold">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {(metricAnalysis?.summary ||
          metricAnalysis?.recommendation ||
          metricAnalysis?.trend ||
          metricAnalysis?.risk) && (
          <div className="bg-white/80 backdrop-blur-md shadow-xl rounded-2xl p-6 border border-slate-200/50 flex flex-col h-full">
            <h2 className="text-lg font-bold mb-4 text-slate-900 flex items-center gap-2">
              <div className="w-2 h-6 bg-emerald-500 rounded-full" />
              Analysis Summary
            </h2>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-slate-100/70 rounded-xl p-4 border border-slate-300 shadow-inner">
                <p className="text-sm text-slate-600 mb-1 uppercase tracking-wider font-bold">Trend</p>
                <p className="text-base font-bold text-slate-900">{metricAnalysis.trend || "NA"}</p>
              </div>
              <div className="bg-slate-100/70 rounded-xl p-4 border border-slate-300 shadow-inner">
                <p className="text-sm text-slate-600 mb-1 uppercase tracking-wider font-bold">Risk</p>
                <p className={`text-base font-bold ${metricAnalysis.risk?.toLowerCase() === 'high' ? 'text-rose-400' : metricAnalysis.risk?.toLowerCase() === 'low' ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {metricAnalysis.risk || "NA"}
                </p>
              </div>
              <div className="bg-slate-100/70 rounded-xl p-4 border border-slate-300 shadow-inner">
                <p className="text-sm text-slate-600 mb-1 uppercase tracking-wider font-bold">Generated</p>
                <p className="text-base font-bold text-slate-900">{metricAnalysis.generatedMetric ?? "NA"}</p>
              </div>
              <div className="bg-slate-100/70 rounded-xl p-4 border border-slate-300 shadow-inner">
                <p className="text-sm text-slate-600 mb-1 uppercase tracking-wider font-bold">Vs Avg</p>
                <p className={`text-base font-bold ${metricAnalysis.changeVsAvgPct > 0 ? 'text-emerald-400' : metricAnalysis.changeVsAvgPct < 0 ? 'text-rose-400' : 'text-slate-900'}`}>
                  {metricAnalysis.changeVsAvgPct ?? "NA"}%
                </p>
              </div>
            </div>

            <div className="flex-1 space-y-5">
              {metricAnalysis.summary && (
                <div>
                  <h3 className="text-sm text-slate-900 uppercase tracking-wider font-bold mb-2">Summary</h3>
                  <p className="text-base text-slate-900 font-medium bg-slate-100/70 p-4 rounded-xl border border-slate-300 leading-relaxed shadow-inner">
                    {metricAnalysis.summary}
                  </p>
                </div>
              )}
              {metricAnalysis.recommendation && (
                <div>
                  <h3 className="text-sm text-slate-900 uppercase tracking-wider font-bold mb-2">Recommendation</h3>
                  <p className="text-base text-slate-900 font-medium bg-dashCyan-900/40 p-4 rounded-xl border border-dashCyan-500/40 leading-relaxed shadow-inner">
                    {metricAnalysis.recommendation}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {Array.isArray(analysisHistory) && analysisHistory.filter(Boolean).length > 0 && (
        <div className="bg-white/80 backdrop-blur-md shadow-xl rounded-2xl p-6 border border-slate-200/50 mt-2">
          <h2 className="text-lg font-bold mb-4 text-slate-900 flex items-center gap-2">
            <div className="w-2 h-6 bg-purple-500 rounded-full" />
            Monthly Insights History
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {analysisHistory
              .filter(Boolean)
              .map((entry) => (
                <div
                  key={entry.metric_month_id || `${entry.month_id}-${entry.metric_name}`}
                  className="bg-slate-100/50 border border-slate-200 rounded-xl p-4 hover:border-slate-400 transition-colors"
                >
                  <p className="text-sm font-bold text-slate-800 mb-3 pb-2 border-b border-slate-200">
                    {entry.month || entry.month_id}
                  </p>
                  {Array.isArray(entry.insights) && entry.insights.length > 0 ? (
                    <ul className="space-y-2">
                      {entry.insights.map((insight, idx) => (
                        <li key={`${entry.month_id}-${idx}`} className="text-xs text-slate-500 flex flex-col gap-1">
                          <span className="font-bold text-purple-700">{insight?.title}</span>
                          <span className="leading-relaxed">{insight?.description}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-slate-500 italic">No monthly insights available.</p>
                  )}
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
