import { Sparkles } from "lucide-react";

export default function ExecutiveInsights({ summary }) {
  const points = [
    `${summary.green} projects are healthy.`,
    `${summary.amber} projects require monitoring.`,
    `${summary.red} projects require executive attention.`,
    `Portfolio health score is ${Math.round(summary.score)}%.`,
    `Average trend is ${summary.trend > 0 ? "+" : ""}${summary.trend}% versus last month.`,
    `${summary.highRisk} projects currently carry high-risk indicators.`,
  ];

  return (
    <section className="rounded-2xl border border-purple-300/25 bg-white/88 p-5 shadow-xl backdrop-blur-md">
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-xl border border-purple-300/30 bg-purple-400/10 p-2 text-purple-700">
          <Sparkles size={20} />
        </div>
        <div>
          <h2 className="text-lg font-black text-slate-900">Portfolio Health Summary</h2>
          <p className="text-xs font-semibold text-slate-500">insights</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {points.map((point) => (
          <div key={point} className="rounded-xl border border-slate-200/80 bg-slate-100/70 px-4 py-3 text-sm font-semibold text-slate-800">
            {point}
          </div>
        ))}
      </div>
    </section>
  );
}
