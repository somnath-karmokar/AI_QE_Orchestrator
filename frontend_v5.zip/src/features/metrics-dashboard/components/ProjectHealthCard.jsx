import { ArrowUpRight, TrendingDown, TrendingUp } from "lucide-react";

const toneMap = {
  green: {
    badge: "bg-green-600 text-white border-green-400 shadow-[0_0_18px_rgba(22,163,74,0.35)]",
    border: "border-emerald-300/35 hover:border-emerald-200/70",
    glow: "bg-emerald-400/20",
    dot: "bg-emerald-400",
    text: "text-white",
    label: "Green",
  },
  amber: {
    badge: "bg-amber-500 text-slate-950 border-amber-300 shadow-[0_0_18px_rgba(245,158,11,0.35)]",
    border: "border-amber-300/40 hover:border-amber-200/75",
    glow: "bg-amber-400/20",
    dot: "bg-amber-300",
    text: "text-slate-950",
    label: "Amber",
  },
  red: {
    badge: "bg-red-600 text-white border-red-400 shadow-[0_0_18px_rgba(220,38,38,0.35)]",
    border: "border-red-300/35 hover:border-red-200/70",
    glow: "bg-red-400/20",
    dot: "bg-red-400",
    text: "text-white",
    label: "Red",
  },
};

function DimensionChip({ label, value }) {
  const tone = toneMap[value] || toneMap.amber;
  return (
    <span className={`inline-flex items-center justify-between gap-2 rounded-lg border px-2.5 py-1 text-[11px] font-bold ${tone.badge}`}>
      <span className="text-slate-800">{label}</span>
      <span className={`font-black uppercase ${tone.text}`}>{tone.label}</span>
    </span>
  );
}

export default function ProjectHealthCard({ project, onOpen }) {
  const tone = toneMap[project.rag] || toneMap.amber;
  const TrendIcon = project.trend >= 0 ? TrendingUp : TrendingDown;
  const topKpis = Object.entries(project.kpis || {}).slice(0, 4);

  return (
    <button
      type="button"
      onClick={() => onOpen(project)}
      className={`group relative overflow-hidden rounded-2xl border ${tone.border} bg-white/88 p-5 text-left shadow-xl backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_22px_60px_rgba(2,6,23,0.45)]`}
    >
      <div className={`absolute -right-10 -top-12 h-36 w-36 rounded-full ${tone.glow} blur-3xl transition-transform duration-300 group-hover:scale-125`} />
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-cyan-300 via-emerald-300 to-amber-300" />
      <div className="relative z-10 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className={`h-3 w-3 shrink-0 rounded-full ${tone.dot}`} />
            <h3 className="truncate text-lg font-black text-slate-900">{project.project}</h3>
          </div>
          <p className="mt-1 text-xs font-semibold text-slate-500">{project.portfolio}</p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-2">
          <span className={`rounded-full border px-3 py-1 text-xs font-black uppercase ${tone.badge}`}>
            {tone.label}
          </span>
          <div className="flex items-center gap-1 rounded-lg border border-slate-300/70 bg-slate-100/70 px-2 py-1 text-xs font-bold text-slate-800">
            <TrendIcon size={13} className={project.trend >= 0 ? "text-emerald-700" : "text-red-700"} />
            {project.trend > 0 ? "+" : ""}{project.trend}%
          </div>
        </div>
      </div>

      <div className="relative z-10 mt-5 grid grid-cols-2 gap-2">
        {topKpis.map(([label, value]) => (
          <DimensionChip key={label} label={label} value={value} />
        ))}
      </div>

      <div className="relative z-10 mt-5 grid grid-cols-3 gap-2 text-xs">
        <div>
          <p className="font-black text-slate-900">{project.criticalKpis}</p>
          <p className="font-semibold text-slate-500">Critical KPIs</p>
        </div>
        <div>
          <p className="font-black text-slate-900">{project.openRisks}</p>
          <p className="font-semibold text-slate-500">Open Risks</p>
        </div>
        <div>
          <p className="font-black text-slate-900">{project.lastUpdated}</p>
          <p className="font-semibold text-slate-500">Updated</p>
        </div>
      </div>

      <div className="relative z-10 mt-5 flex items-center justify-between border-t border-slate-200/70 pt-4">
        <p className="truncate text-xs font-bold text-slate-500">Owner: <span className="text-slate-800">{project.owner}</span></p>
        <span className="inline-flex items-center gap-1 text-sm font-black text-cyan-700">
          View Dashboard <ArrowUpRight size={15} />
        </span>
      </div>
    </button>
  );
}
