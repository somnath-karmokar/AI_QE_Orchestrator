export default function PortfolioSummaryCard({ label, value, sub, tone = "cyan" }) {
  const tones = {
    cyan: {
      card: "border-cyan-200/55 bg-cyan-400/15 shadow-[0_0_18px_rgba(34,211,238,0.16)]",
      label: "text-cyan-800",
      value: "text-slate-900",
      sub: "text-cyan-700",
    },
    green: {
      card: "border-green-400 bg-green-600 shadow-[0_0_24px_rgba(22,163,74,0.35)]",
      label: "text-white",
      value: "text-white",
      sub: "text-green-50",
    },
    amber: {
      card: "border-amber-400 bg-amber-500 shadow-[0_0_24px_rgba(245,158,11,0.35)]",
      label: "text-slate-950",
      value: "text-slate-950",
      sub: "text-slate-900",
    },
    red: {
      card: "border-red-400 bg-red-600 shadow-[0_0_24px_rgba(220,38,38,0.35)]",
      label: "text-white",
      value: "text-white",
      sub: "text-red-50",
    },
    slate: {
      card: "border-slate-500/55 bg-white/80",
      label: "text-slate-900",
      value: "text-slate-900",
      sub: "text-slate-600",
    },
  };
  const selectedTone = tones[tone] || tones.cyan;

  return (
    <div className={`rounded-xl border ${selectedTone.card} px-5 py-4 shadow-xl backdrop-blur-md`}>
      <p className={`text-xs font-black uppercase tracking-widest ${selectedTone.label}`}>{label}</p>
      <p className={`mt-2 text-3xl font-black tracking-normal ${selectedTone.value}`}>{value}</p>
      {sub && <p className={`mt-1 text-xs font-black uppercase tracking-wide ${selectedTone.sub}`}>{sub}</p>}
    </div>
  );
}
