const colors = { green: "#34d399", amber: "#fbbf24", red: "#f87171" };

export default function PortfolioCharts({ projects, summary }) {
  const maxProjects = Math.max(summary.green, summary.amber, summary.red, 1);
  const trendPoints = [-5, -2, 1, 3, summary.trend - 1, summary.trend].map((value, index) => ({
    x: 20 + index * 48,
    y: 92 - (value + 10) * 4,
  }));
  const path = trendPoints.map((point, index) => `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`).join(" ");
  const heatmapRows = ["Engineering", "Velocity", "Automation", "Quality", "Environment"];

  return (
    <section className="grid grid-cols-1 gap-5 xl:grid-cols-2">
      <ChartCard title="Portfolio Health Distribution">
        <div className="flex items-center gap-6">
          <div
            className="h-36 w-36 shrink-0 rounded-full border border-slate-200"
            style={{
              background: `conic-gradient(${colors.green} 0 ${summary.greenPct}%, ${colors.amber} ${summary.greenPct}% ${summary.greenPct + summary.amberPct}%, ${colors.red} ${summary.greenPct + summary.amberPct}% 100%)`,
            }}
          />
          <div className="space-y-3 text-sm font-bold text-slate-600">
            <Legend color="bg-emerald-400" label="Green" value={summary.green} />
            <Legend color="bg-amber-300" label="Amber" value={summary.amber} />
            <Legend color="bg-red-400" label="Red" value={summary.red} />
          </div>
        </div>
      </ChartCard>

      <ChartCard title="Portfolio Trend">
        <svg viewBox="0 0 280 120" className="h-36 w-full overflow-visible">
          <path d="M 16 100 H 268" stroke="rgb(51 65 85)" strokeWidth="1" />
          <path d={path} fill="none" stroke="rgb(34 211 238)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
          {trendPoints.map((point) => <circle key={`${point.x}-${point.y}`} cx={point.x} cy={point.y} r="4" fill="rgb(52 211 153)" />)}
        </svg>
      </ChartCard>

      <ChartCard title="Projects by RAG">
        <Bar label="Green" value={summary.green} max={maxProjects} color="bg-emerald-400" />
        <Bar label="Amber" value={summary.amber} max={maxProjects} color="bg-amber-300" />
        <Bar label="Red" value={summary.red} max={maxProjects} color="bg-red-400" />
      </ChartCard>

      <ChartCard title="Portfolio KPI Heatmap">
        <div className="space-y-2">
          {heatmapRows.map((row) => (
            <div key={row} className="grid grid-cols-[110px_1fr] items-center gap-3">
              <span className="text-xs font-black text-slate-500">{row}</span>
              <div className="grid grid-cols-8 gap-1">
                {projects.slice(0, 8).map((project) => (
                  <span key={`${row}-${project.id}`} className={`h-7 rounded ${heatColor(project.kpis?.[row])}`} title={`${project.project}: ${row}`} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </ChartCard>
    </section>
  );
}

function ChartCard({ title, children }) {
  return (
    <div className="rounded-2xl border border-slate-300/70 bg-white/88 p-5 shadow-xl backdrop-blur-md">
      <h2 className="mb-4 text-lg font-black text-slate-900">{title}</h2>
      {children}
    </div>
  );
}

function Legend({ color, label, value }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`h-3 w-3 rounded-full ${color}`} />
      <span>{label}</span>
      <span className="text-slate-900">{value}</span>
    </div>
  );
}

function Bar({ label, value, max, color }) {
  return (
    <div className="mb-4">
      <div className="mb-1 flex justify-between text-xs font-black uppercase tracking-widest text-slate-500">
        <span>{label}</span><span>{value}</span>
      </div>
      <div className="h-3 overflow-hidden rounded-full bg-white">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${Math.max(4, (value / max) * 100)}%` }} />
      </div>
    </div>
  );
}

function heatColor(value = "amber") {
  if (value === "green") return "bg-emerald-400/80";
  if (value === "red") return "bg-red-400/80";
  return "bg-amber-300/80";
}
