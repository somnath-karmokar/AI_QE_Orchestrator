import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import slugify from "slugify";
import { useMonth } from "../context/MonthContext";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { Code2, Zap, Users, ShieldCheck, ArrowUpRight, ArrowDownRight, Minus, Filter } from "lucide-react";

const FILTER_STORAGE_KEY = "qe-metrics.dashboard.filters";

function readSavedFilters() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(FILTER_STORAGE_KEY) || "{}");
    return {
      domain: parsed.domain || "",
      portfolio: parsed.portfolio || "",
      project: parsed.project || "",
      month: parsed.month || "",
    };
  } catch {
    return { domain: "", portfolio: "", project: "", month: "" };
  }
}

export default function KPIDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { selectedMonth } = useMonth();
  const routeFilters = location.state?.filters || {};
  const savedFilters = { ...readSavedFilters(), ...routeFilters };
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedDomain, setSelectedDomain] = useState(savedFilters.domain);
  const [selectedPortfolio, setSelectedPortfolio] = useState(savedFilters.portfolio);
  const [selectedProject, setSelectedProject] = useState(savedFilters.project);

  useEffect(() => {
    const nextFilters = location.state?.filters;
    if (!nextFilters) return;
    if (typeof nextFilters.domain === "string") setSelectedDomain(nextFilters.domain);
    if (typeof nextFilters.portfolio === "string") setSelectedPortfolio(nextFilters.portfolio);
    if (typeof nextFilters.project === "string") setSelectedProject(nextFilters.project);
  }, [location.state]);

  useEffect(() => {
    let active = true;
    if (!selectedMonth) {
      setApiPayload(null);
      setError("");
      setLoading(false);
      return () => {
        active = false;
      };
    }

    setLoading(true);
    setError("");

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async (err) => {
        if (!active) return;
        setApiPayload(null);
        setError(err?.message || "No metrics available for the selected month.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  useEffect(() => {
    sessionStorage.setItem(
      FILTER_STORAGE_KEY,
      JSON.stringify({
        month: selectedMonth,
        domain: selectedDomain,
        portfolio: selectedPortfolio,
        project: selectedProject,
      }),
    );
  }, [selectedMonth, selectedDomain, selectedPortfolio, selectedProject]);

  const buildStatusFromSeries = (history, risk = "") => {
    if (Array.isArray(history) && history.length >= 2) {
      const [current, previous] = history;
      if (typeof current?.value === "number" && typeof previous?.value === "number") {
        const delta = current.value - previous.value;
        if (delta > 0) return "Green";
      }
    }

    const riskLower = String(risk).toLowerCase();
    if (riskLower === "low") return "Green";
    if (riskLower === "normal") return "Green";
    if (riskLower === "high") return "Red";
    if (riskLower === "medium") return "Amber";

    if (!Array.isArray(history) || history.length < 2) return "Amber";
    const [current, previous] = history;
    if (typeof current?.value !== "number" || typeof previous?.value !== "number") return "Amber";
    const delta = current.value - previous.value;
    if (delta >= 0) return "Green";
    if (delta > -5) return "Amber";
    return "Red";
  };

  const getMonthStatus = (analysis, metrics) => {
    const riskRows = Array.isArray(analysis?.metrics) ? analysis.metrics : [];
    const riskScores = riskRows
      .map((metric) => {
        const risk = String(metric?.risk || "").toLowerCase();
        if (risk === "high") return 25;
        if (risk === "medium") return 65;
        if (risk === "low" || risk === "normal") return 100;
        return null;
      })
      .filter((score) => Number.isFinite(score));

    if (riskScores.length > 0) {
      const averageRiskScore = riskScores.reduce((sum, score) => sum + score, 0) / riskScores.length;
      if (averageRiskScore >= 75) return { label: "Green", display: "Green", score: averageRiskScore };
      if (averageRiskScore >= 50) return { label: "Amber", display: "Amber", score: averageRiskScore };
      return { label: "Red", display: "Red", score: averageRiskScore };
    }

    const counts = (metrics || []).reduce(
      (acc, metric) => {
        const key = String(metric.status || "Amber").toLowerCase();
        if (key === "red") acc.red += 1;
        else if (key === "amber") acc.amber += 1;
        else acc.green += 1;
        return acc;
      },
      { green: 0, amber: 0, red: 0 },
    );
    const total = counts.green + counts.amber + counts.red;
    const fallbackScore = total > 0 ? ((counts.green * 100) + (counts.amber * 65) + (counts.red * 25)) / total : 65;
    if (fallbackScore >= 75) return { label: "Green", display: "Green", score: fallbackScore };
    if (fallbackScore >= 50) return { label: "Amber", display: "Amber", score: fallbackScore };
    return { label: "Red", display: "Red", score: fallbackScore };
  };

  const getMonthStatusTone = (status) => {
    const normalized = String(status || "").toLowerCase();
    if (normalized === "red") {
      return {
        dot: "bg-red-400 shadow-[0_0_12px_rgba(248,113,113,1)]",
        pill: "bg-red-400/15 text-red-800 border-red-300/40",
        text: "text-red-700",
      };
    }
    if (normalized === "amber") {
      return {
        dot: "bg-amber-300 shadow-[0_0_12px_rgba(252,211,77,1)]",
        pill: "bg-amber-400/15 text-amber-800 border-amber-300/40",
        text: "text-amber-700",
      };
    }
    return {
      dot: "bg-green-400 shadow-[0_0_12px_rgba(74,222,128,1)]",
      pill: "bg-green-400/15 text-green-800 border-green-300/40",
      text: "text-green-700",
    };
  };

  const kpiData = useMemo(() => {
    if (!apiPayload?.categories?.length) {
      return [];
    }

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}::${metric.domain || "Unassigned"}::${metric.portfolio || "General"}::${metric.project || "General"}`;
      analysisByMetric.set(key, metric);
    });

    return apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const domain = metric.domain || "Unassigned";
        const portfolio = metric.portfolio || "General";
        const project = metric.project || "General";
        const key = `${category.name}::${metric.name}::${domain}::${portfolio}::${project}`;
        const analysis = analysisByMetric.get(key);
        const history = (metric.history || []).map((item, index) => ({
          id: index + 1,
          period: item.month,
          value: item.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: item.month_id ? `${item.month_id}-01` : "",
        }));
        return {
          dimension: category.name,
          domain,
          portfolio,
          project,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "" },
          value: metric.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
        };
      }),
    );
  }, [apiPayload, selectedMonth]);
  const dataMonthLabel = apiPayload?.dashboard?.month || selectedMonth;
  const analysisMeta = apiPayload?.analysis || null;
  const monthStatus = getMonthStatus(analysisMeta, kpiData);
  const monthStatusTone = getMonthStatusTone(monthStatus.label);
  const domainOptions = useMemo(
    () => Array.from(new Set(kpiData.map((kpi) => kpi.domain || "Unassigned"))).sort(),
    [kpiData],
  );
  const portfolioOptions = useMemo(() => {
    const available = kpiData
      .filter((kpi) => !selectedDomain || (kpi.domain || "Unassigned") === selectedDomain)
      .map((kpi) => kpi.portfolio || "General");
    return Array.from(new Set(available)).sort();
  }, [kpiData, selectedDomain]);
  const projectOptions = useMemo(() => {
    const available = kpiData
      .filter((kpi) => !selectedDomain || (kpi.domain || "Unassigned") === selectedDomain)
      .filter((kpi) => !selectedPortfolio || (kpi.portfolio || "General") === selectedPortfolio)
      .map((kpi) => kpi.project || "General");
    return Array.from(new Set(available)).sort();
  }, [kpiData, selectedDomain, selectedPortfolio]);

  useEffect(() => {
    if (domainOptions.length > 0 && !domainOptions.includes(selectedDomain)) {
      setSelectedDomain(domainOptions[0]);
    }
  }, [domainOptions, selectedDomain]);
  useEffect(() => {
    if (portfolioOptions.length > 0 && !portfolioOptions.includes(selectedPortfolio)) {
      setSelectedPortfolio(portfolioOptions[0]);
    }
  }, [portfolioOptions, selectedPortfolio]);
  useEffect(() => {
    if (projectOptions.length > 0 && !projectOptions.includes(selectedProject)) {
      setSelectedProject(projectOptions[0]);
    }
  }, [projectOptions, selectedProject]);

  const filteredKpiData = useMemo(
    () =>
      kpiData.filter((kpi) => {
        const domainMatch = !selectedDomain || (kpi.domain || "Unassigned") === selectedDomain;
        const portfolioMatch =
          !selectedPortfolio || (kpi.portfolio || "General") === selectedPortfolio;
        const projectMatch = !selectedProject || (kpi.project || "General") === selectedProject;
        return domainMatch && portfolioMatch && projectMatch;
      }),
    [kpiData, selectedDomain, selectedPortfolio, selectedProject],
  );

  const groupedData = filteredKpiData.reduce((acc, kpi) => {
    if (!acc[kpi.dimension]) acc[kpi.dimension] = [];
    acc[kpi.dimension].push(kpi);
    return acc;
  }, {});
  const preferredDimensions = ["Engineering", "Velocity", "Collaboration", "Quality"];
  const visibleDimensions = [
    ...preferredDimensions.filter((dimension) => groupedData[dimension]?.length),
    ...Object.keys(groupedData)
      .filter((dimension) => !preferredDimensions.includes(dimension))
      .sort(),
  ];

  const renderKpiCard = (kpi) => {
    const historyValues = Array.isArray(kpi.history)
      ? kpi.history
          .map((item) => Number(item?.value))
          .filter((value) => Number.isFinite(value))
      : [];
    const isUpward = historyValues.length >= 2 && historyValues[0] > historyValues[1];
    const normalizedStatus = String(kpi.status || "").toLowerCase();
    const isPositive = isUpward || normalizedStatus === "green" || normalizedStatus === "normal";
    const isWarning = normalizedStatus === "amber";
    const isCritical = !isPositive && normalizedStatus === "red";
    const portfolioLabel = String(kpi.portfolio || "").trim();
    const projectLabel = String(kpi.project || "").trim();
    const showPortfolioLabel = portfolioLabel && portfolioLabel.toLowerCase() !== "general";
    const showProjectLabel = projectLabel && projectLabel.toLowerCase() !== "general";
    const cardTone = isPositive
      ? {
          card: "bg-white/88 border-green-400/35 shadow-green-950/20 hover:border-green-300/70",
          surface: "bg-green-400/10",
          glow: "bg-green-400/20",
          text: "text-slate-900",
          value: "text-green-700",
          badge: "bg-green-400/15 text-green-800 border-green-300/35",
          icon: "bg-green-400/15 text-green-700 border-green-300/35",
          accent: "from-green-300 via-green-400 to-green-600",
          statusPill: "bg-green-400/18 text-green-800 border-green-300/40",
          statusLabel: "Green",
        }
      : isCritical
        ? {
            card: "bg-white/88 border-red-400/35 shadow-red-950/20 hover:border-red-300/70",
            surface: "bg-red-400/10",
            glow: "bg-red-400/20",
            text: "text-slate-900",
            value: "text-red-700",
            badge: "bg-red-400/15 text-red-800 border-red-300/35",
            icon: "bg-red-400/15 text-red-700 border-red-300/35",
            accent: "from-red-300 via-red-500 to-red-700",
            statusPill: "bg-red-400/18 text-red-800 border-red-300/40",
            statusLabel: "Red",
          }
        : {
            card: "bg-white/88 border-amber-400/40 shadow-amber-950/20 hover:border-amber-300/75",
            surface: "bg-amber-400/10",
            glow: "bg-amber-400/20",
            text: "text-slate-900",
            value: "text-amber-700",
            badge: "bg-amber-400/15 text-amber-800 border-amber-300/35",
            icon: "bg-amber-400/15 text-amber-800 border-amber-300/35",
            accent: "from-amber-200 via-amber-400 to-orange-500",
            statusPill: "bg-amber-400/18 text-amber-800 border-amber-300/40",
            statusLabel: "Amber",
          };
    
    return (
      <div
        key={kpi.kpiname}
        onClick={() =>
          navigate(
            `/metrics/kpi/${slugify(kpi.kpiname, { lower: true, strict: true })}`,
            { state: { kpi } },
          )
        }
        className={`group cursor-pointer ${cardTone.card} border rounded-xl shadow-lg hover:shadow-[0_20px_50px_rgba(2,6,23,0.42)] hover:-translate-y-1 transition-all duration-300 p-3.5 flex flex-col gap-2 h-[124px] overflow-hidden relative backdrop-blur-md font-inter`}
      >
        <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${cardTone.accent} pointer-events-none`} />
        <div className="flex min-h-0 flex-1 justify-between items-start w-full z-10 gap-2 pt-0.5">
          <div className="min-w-0 pr-1">
            <p className={`text-sm ${cardTone.text} font-bold leading-tight line-clamp-3 tracking-normal`}>
              {kpi.kpiname}
            </p>
          </div>
          <div className="flex shrink-0 items-start">
            <div className={`flex items-center justify-center w-7 h-7 rounded-lg shrink-0 shadow-md border ${cardTone.icon}`}>
              {isPositive ? <ArrowUpRight size={12} strokeWidth={3} /> :
               isCritical ? <ArrowDownRight size={12} strokeWidth={3} /> :
               <Minus size={12} strokeWidth={3} />}
            </div>
          </div>
        </div>
        
        <div className="flex items-end justify-between gap-2 w-full z-10">
          <div className="min-w-0 flex-1">
            <span className={`block truncate text-3xl font-black tracking-normal leading-none ${cardTone.value}`}>
              {kpi.value}
            </span>
          </div>
          <span className={`inline-flex max-w-[112px] shrink-0 rounded-full border px-2 py-1 text-[11px] font-extrabold uppercase leading-none tracking-normal ${cardTone.statusPill} backdrop-blur-md shadow-sm`}>
            {cardTone.statusLabel}
          </span>
          {/* {(showProjectLabel || showPortfolioLabel) && (
            <p className={`rounded-full border px-2.5 py-1 text-[11px] ${cardTone.badge} font-bold uppercase text-right leading-tight tracking-normal backdrop-blur-md shadow-sm truncate max-w-[120px]`}>
              {showProjectLabel ? projectLabel : portfolioLabel}
            </p>
          )} */}
        </div>
      </div>
    );
  };

  const getDimensionConfig = (dimension) => {
    switch(dimension) {
      case "Engineering":
        return {
          icon: Code2,
          panel: "bg-gradient-to-br from-white via-cyan-50 to-slate-100 border-cyan-300/40 hover:border-cyan-200/70",
          glow: "bg-cyan-400/20",
          iconBox: "bg-cyan-400/15 text-cyan-800 border-cyan-300/35",
          accent: "bg-cyan-300",
          title: "text-slate-900",
        };
      case "Velocity":
        return {
          icon: Zap,
          panel: "bg-gradient-to-br from-white via-amber-50 to-slate-100 border-amber-300/45 hover:border-amber-200/75",
          glow: "bg-amber-400/20",
          iconBox: "bg-amber-400/15 text-amber-800 border-amber-300/35",
          accent: "bg-amber-300",
          title: "text-slate-900",
        };
      case "Collaboration":
        return {
          icon: Users,
          panel: "bg-gradient-to-br from-white via-sky-50 to-slate-100 border-sky-300/40 hover:border-sky-200/70",
          glow: "bg-sky-400/20",
          iconBox: "bg-sky-400/15 text-sky-800 border-sky-300/35",
          accent: "bg-sky-300",
          title: "text-slate-900",
        };
      case "Quality":
        return {
          icon: ShieldCheck,
          panel: "bg-gradient-to-br from-white via-emerald-50 to-slate-100 border-emerald-300/40 hover:border-emerald-200/70",
          glow: "bg-emerald-400/20",
          iconBox: "bg-emerald-400/15 text-emerald-800 border-emerald-300/35",
          accent: "bg-emerald-300",
          title: "text-slate-900",
        };
      default:
        return {
          icon: Code2,
          panel: "bg-gradient-to-br from-white via-slate-50 to-slate-200 border-slate-500/35 hover:border-slate-600/60",
          glow: "bg-slate-400/15",
          iconBox: "bg-slate-400/15 text-slate-900 border-slate-600/30",
          accent: "bg-slate-300",
          title: "text-slate-900",
        };
    }
  };

  const renderDimensionCards = (dimension) => {
    const config = getDimensionConfig(dimension);
    const Icon = config.icon;
    
    return (
      <div className={`${config.panel} rounded-2xl p-5 flex flex-col h-full animate-fade-in relative overflow-hidden shadow-xl border transition-colors duration-300`}>
        <div className="flex items-center space-x-3 mb-5 relative z-10">
          <div className={`p-3 rounded-xl border shadow-sm backdrop-blur-sm ${config.iconBox}`}>
            <Icon size={24} />
          </div>
          <div>
            <div className={`h-1 w-10 rounded-full ${config.accent} mb-2`} />
            <h3 className={`text-xl font-bold ${config.title} tracking-normal font-inter`}>
              {dimension}
            </h3>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 flex-1 relative z-10">
          {groupedData[dimension]?.map((kpi) => renderKpiCard(kpi))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full flex flex-col relative pb-12">
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="animate-pulse-slow px-6 py-3 bg-white/80 backdrop-blur-md text-dashCyan-400 rounded-full text-base font-medium border border-slate-200 shadow-xl flex items-center space-x-3">
            <div className="w-5 h-5 rounded-full border-2 border-dashCyan-400 border-t-transparent animate-spin" />
            <span>Loading dashboard metrics...</span>
          </div>
        </div>
      )}
      
      {!loading && error && (
        <div className="mx-auto mt-2 mb-6 bg-rose-50 backdrop-blur-md border border-rose-300/60 rounded-xl px-6 py-4 text-base text-rose-700 max-w-2xl text-center shadow-xl">
          {error}
        </div>
      )}

      {!loading && kpiData.length > 0 && (
        <div className="mx-auto mb-6 w-full max-w-4xl bg-white/80 backdrop-blur-md rounded-xl px-5 py-4 border border-slate-300 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-end gap-4">
            <div className="flex items-center gap-2 text-slate-900 font-semibold min-w-[140px]">
              <Filter size={18} className="text-cyan-700" />
              <span>Filters</span>
            </div>
            <label className="flex-1 text-sm text-slate-600">
              <span className="block mb-1 font-medium">Domain</span>
              <select
                value={selectedDomain}
                onChange={(event) => {
                  setSelectedDomain(event.target.value);
                  setSelectedPortfolio("");
                  setSelectedProject("");
                }}
                className="w-full rounded-lg border border-slate-400 bg-slate-100 px-3 py-2 text-slate-900 outline-none focus:border-cyan-400"
              >
                {domainOptions.map((domain) => (
                  <option key={domain} value={domain}>
                    {domain}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex-1 text-sm text-slate-600">
              <span className="block mb-1 font-medium">Portfolio</span>
              <select
                value={selectedPortfolio}
                onChange={(event) => {
                  setSelectedPortfolio(event.target.value);
                  setSelectedProject("");
                }}
                className="w-full rounded-lg border border-slate-400 bg-slate-100 px-3 py-2 text-slate-900 outline-none focus:border-cyan-400"
              >
                {portfolioOptions.map((portfolio) => (
                  <option key={portfolio} value={portfolio}>
                    {portfolio}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex-1 text-sm text-slate-600">
              <span className="block mb-1 font-medium">Project</span>
              <select
                value={selectedProject}
                onChange={(event) => setSelectedProject(event.target.value)}
                className="w-full rounded-lg border border-slate-400 bg-slate-100 px-3 py-2 text-slate-900 outline-none focus:border-cyan-400"
              >
                {projectOptions.map((project) => (
                  <option key={project} value={project}>
                    {project}
                  </option>
                ))}
              </select>
            </label>
            <div className="text-sm text-slate-600 md:text-right">
              <span className="block font-semibold text-slate-900">{filteredKpiData.length}</span>
              <span>metrics shown</span>
            </div>
          </div>
        </div>
      )}

      {!loading && !error && kpiData.length > 0 && analysisMeta && (
        <div className="mx-auto mb-8 w-full max-w-4xl bg-white/80 backdrop-blur-md rounded-2xl px-8 py-5 text-base text-slate-900 flex flex-wrap items-center justify-between gap-4 shadow-xl border border-slate-300">
          <div className="flex flex-wrap items-center gap-3">
            <div className={`w-3 h-3 rounded-full animate-pulse ${monthStatusTone.dot}`} />
            <span className="font-medium text-slate-800">Analysis month: <span className="font-bold text-slate-900 ml-1">{analysisMeta.month || dataMonthLabel}</span></span>
            <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-extrabold uppercase tracking-normal ${monthStatusTone.pill}`}>
              Overall status: {monthStatus.display}
              <span className={`ml-1.5 font-black ${monthStatusTone.text}`}>
                Score {Math.round(monthStatus.score)}
              </span>
            </span>
          </div>
          <div className="hidden sm:block w-px h-6 bg-slate-300" />
          <div className="text-sm text-slate-600 font-medium">
            Generated: <span className="text-slate-900">{analysisMeta.generated_at || "NA"}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 xl:gap-8 w-full max-w-[1400px] mx-auto z-10">
        {visibleDimensions.map((dimension) => renderDimensionCards(dimension))}
      </div>
      {!loading && !error && !selectedMonth && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-300 bg-white/80 px-6 py-5 text-slate-800">
          No monthly data uploaded yet.
        </div>
      )}
      {!loading && !error && selectedMonth && kpiData.length === 0 && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-300 bg-white/80 px-6 py-5 text-slate-800">
          No metrics available for {selectedMonth}.
        </div>
      )}
      {!loading && !error && kpiData.length > 0 && visibleDimensions.length === 0 && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-300 bg-white/80 px-6 py-5 text-slate-800">
          No metrics match the selected domain, portfolio, and project.
        </div>
      )}
    </div>
  );
}
