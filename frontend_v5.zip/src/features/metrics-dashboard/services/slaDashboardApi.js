import { SAMPLE_SLA_CSV } from "../data/qeKpiSlaConfig";
import { parseSlaCsv } from "../utils/qeKpiAnalytics";

// This dashboard runs on static data: rather than triggering SlaDashboard's
// own "no CSV uploaded, showing sample data" banner (its real behaviour when
// the live endpoint returns no rows), serve the same sample rows here so the
// page reads as populated data.
export async function fetchSlaDashboardRows() {
  const rows = parseSlaCsv(SAMPLE_SLA_CSV);
  return new Promise((resolve) => setTimeout(() => resolve(rows), 150 + Math.random() * 150));
}
