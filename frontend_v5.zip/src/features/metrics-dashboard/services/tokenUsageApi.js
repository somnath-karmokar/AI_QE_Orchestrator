import { TOKEN_USAGE_SUMMARY } from "../data/tokenUsageData";

function settle(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), 150 + Math.random() * 150));
}

// "Cleared" is per browser session, not persisted: a static demo has no log
// to actually delete, but the page's own clear-then-reload flow should still
// show an empty state afterwards rather than silently reappearing.
let cleared = false;

export async function fetchTokenUsageSummary() {
  if (cleared) {
    return settle({
      generated_at: new Date().toISOString(),
      has_data: false,
      total_calls: 0,
      total_prompt_tokens: 0,
      total_completion_tokens: 0,
      total_tokens: 0,
      total_estimated_cost_usd: 0,
      daily: [],
      by_feature: [],
      by_model: [],
      recent_calls: [],
    });
  }
  return settle(TOKEN_USAGE_SUMMARY);
}

export async function clearTokenUsageLog() {
  const deleted = TOKEN_USAGE_SUMMARY.total_calls;
  cleared = true;
  return settle({ status: "cleared", deleted_records: deleted });
}
