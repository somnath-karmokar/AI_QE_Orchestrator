import { AVAILABLE_MONTHS, getFrontendDashboard } from "../data/monthlyDashboardData";

// This dashboard runs on static, locally-generated data (see
// ../data/monthlyDashboardData.js) rather than a live backend -- these
// functions keep their original names and return shapes so every page that
// calls them is unaffected by the swap.
const monthMap = {
  Jan: "01",
  Feb: "02",
  Mar: "03",
  Apr: "04",
  May: "05",
  Jun: "06",
  Jul: "07",
  Aug: "08",
  Sep: "09",
  Oct: "10",
  Nov: "11",
  Dec: "12",
};

export function monthLabelToId(label) {
  const text = String(label || "").trim();
  if (/^\d{4}-\d{2}$/.test(text)) return text;
  const [mon, year] = text.split(/\s+/);
  if (!mon || !year || !monthMap[mon]) return "";
  return `${year}-${monthMap[mon]}`;
}

// A short, simulated delay so loading states still render briefly, the way
// they would against a real network call.
function settle(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), 150 + Math.random() * 150));
}

export async function fetchAvailableMonths() {
  return settle(AVAILABLE_MONTHS);
}

export async function fetchFrontendDashboard(month, historyMonths = 6) {
  const monthId = monthLabelToId(month);
  const payload = getFrontendDashboard(monthId, historyMonths);
  if (!payload) {
    throw new Error(`No metrics available for ${month}.`);
  }
  return settle(payload);
}
