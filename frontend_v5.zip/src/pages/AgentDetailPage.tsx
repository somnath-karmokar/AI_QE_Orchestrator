/** Agent detail: capability, contract, tools, governance and a live test harness. */
import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Check, Copy, FlaskConical, Pencil, ShieldAlert, ShoppingCart, Star } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useProjectId, formatCurrency, formatDuration, formatPercent } from '@/hooks';
import { useSession } from '@/store';
import { AgentIcon } from '@/components/AgentIcon';
import { ApiAccessCard } from '@/components/ApiAccessCard';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, Field, Input,
  KeyValue, LoadingBlock, PageHeader, Select, statusTone, TONE_BY_RISK,
} from '@/design-system/primitives';

export default function AgentDetailPage() {
  const { agentId } = useParams<{ agentId: string }>();
  const projectId = useProjectId();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const can = useSession((state) => state.can);

  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<{ tone: 'success' | 'danger'; text: string } | null>(null);

  const { data: agent, isLoading } = useQuery({
    queryKey: ['agent', agentId],
    queryFn: () => api.getAgent(agentId!),
    enabled: Boolean(agentId),
  });

  const { data: versions } = useQuery({
    queryKey: ['agent-versions', agentId],
    queryFn: () => api.agentVersions(agentId!),
    enabled: Boolean(agentId),
  });

  const { data: cart } = useQuery({
    queryKey: ['cart', projectId],
    queryFn: () => api.getCart(projectId!),
    enabled: Boolean(projectId),
  });

  const inCart = useMemo(() => (cart ?? []).some((item) => item.agent_id === agentId), [cart, agentId]);

  const addToCart = useMutation({
    mutationFn: () => api.addToCart({ agent_id: agentId!, project_id: projectId! }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['cart', projectId] });
      setMessage({ tone: 'success', text: 'Added to your agent cart.' });
    },
    onError: (error) =>
      setMessage({ tone: 'danger', text: error instanceof ApiError ? error.message : 'Could not add the agent.' }),
  });

  const clone = useMutation({
    mutationFn: () => api.cloneAgent(agentId!, projectId ?? undefined),
    onSuccess: (created) => navigate(`/agents/${created.id}/edit`),
  });

  const testAgent = useMutation({
    mutationFn: () => api.testAgent(agentId!, { project_id: projectId!, inputs }),
    onSuccess: (run) => navigate(`/runs/${run.id}`),
    onError: (error) =>
      setMessage({ tone: 'danger', text: error instanceof ApiError ? error.message : 'The test run failed.' }),
  });

  if (isLoading) return <LoadingBlock rows={8} />;
  if (!agent) return <EmptyState title="Agent not found" />;

  const schema = agent.input_schema ?? {};
  const properties = Object.entries(schema.properties ?? {});
  const required = new Set(schema.required ?? []);

  return (
    <div>
      <PageHeader
        title={agent.name}
        description={agent.description ?? undefined}
        breadcrumb={
          <Link to="/marketplace" className="text-sm text-ink-secondary hover:text-brand-600">
            ← Agent Marketplace
          </Link>
        }
        actions={
          <>
            {can('agent:write') ? (
              agent.is_builtin ? (
                <Button variant="secondary" icon={<Copy className="h-3.5 w-3.5" />} loading={clone.isPending} onClick={() => clone.mutate()}>
                  Clone &amp; customise
                </Button>
              ) : (
                <Link
                  to={`/agents/${agent.id}/edit`}
                  className="inline-flex h-9 items-center gap-2 rounded border border-line-strong bg-surface px-3.5 text-sm font-medium text-ink hover:bg-surface-muted"
                >
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </Link>
              )
            ) : null}
            <Button
              variant={inCart ? 'subtle' : 'primary'}
              disabled={inCart}
              loading={addToCart.isPending}
              onClick={() => addToCart.mutate()}
              icon={inCart ? <Check className="h-3.5 w-3.5" /> : <ShoppingCart className="h-3.5 w-3.5" />}
            >
              {inCart ? 'In cart' : 'Add to flow'}
            </Button>
          </>
        }
      />

      {message ? (
        <div
          role="status"
          className={cn(
            'mb-4 rounded-lg border px-4 py-2.5 text-sm',
            message.tone === 'success'
              ? 'border-success-border bg-success-bg text-success-text'
              : 'border-danger-border bg-danger-bg text-danger-text',
          )}
        >
          {message.text}
        </div>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-5">
          <Card>
            <CardBody className="flex gap-4">
              <AgentIcon name={agent.icon} className="h-14 w-14 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone="brand">{agent.category}</Badge>
                  <Badge tone={TONE_BY_RISK[agent.risk_level] ?? 'neutral'}>{agent.risk_level} risk</Badge>
                  <Badge tone="neutral">{agent.cost_tier} cost</Badge>
                  <Badge tone={statusTone(agent.lifecycle_state)}>{agent.lifecycle_state}</Badge>
                  {agent.requires_approval ? (
                    <Badge tone="warning">
                      <ShieldAlert className="h-3 w-3" /> Requires approval
                    </Badge>
                  ) : null}
                </div>
                {agent.goal ? (
                  <p className="mt-3 text-sm leading-relaxed text-ink-secondary">
                    <span className="font-medium text-ink">Goal: </span>
                    {agent.goal}
                  </p>
                ) : null}
              </div>
            </CardBody>
          </Card>

          <ApiAccessCard resource="agent" id={agent.id} projectId={projectId ?? undefined} />

          {agent.system_instructions ? (
            <Card>
              <CardHeader title="Instructions" description="How this agent is directed to behave" />
              <CardBody>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-ink-secondary">
                  {agent.system_instructions}
                </p>
              </CardBody>
            </Card>
          ) : null}

          <div className="grid gap-5 md:grid-cols-2">
            <Card>
              <CardHeader title="Required inputs" />
              <CardBody className="p-0">
                {properties.length ? (
                  <ul className="divide-y divide-line-subtle">
                    {properties.map(([name, definition]) => (
                      <li key={name} className="px-5 py-2.5">
                        <p className="flex items-center gap-2">
                          <code className="font-mono text-xs font-medium text-ink">{name}</code>
                          <span className="text-2xs text-ink-tertiary">{definition.type ?? 'string'}</span>
                          {required.has(name) ? <Badge tone="danger">required</Badge> : null}
                        </p>
                        {definition.description ? (
                          <p className="mt-0.5 text-xs text-ink-secondary">{definition.description}</p>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="px-5 py-4 text-sm text-ink-secondary">This agent takes no explicit inputs.</p>
                )}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Expected output" description="Structured contract every agent returns" />
              <CardBody className="p-0">
                <ul className="divide-y divide-line-subtle">
                  {Object.entries(agent.output_schema?.properties ?? {}).map(([name, definition]) => (
                    <li key={name} className="px-5 py-2.5">
                      <p className="flex items-center gap-2">
                        <code className="font-mono text-xs font-medium text-ink">{name}</code>
                        <span className="text-2xs text-ink-tertiary">{definition.type ?? 'string'}</span>
                      </p>
                      {definition.description ? (
                        <p className="mt-0.5 text-xs text-ink-secondary">{definition.description}</p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          </div>

          {agent.guardrails?.length ? (
            <Card>
              <CardHeader title="Guardrails" description="Constraints applied on every invocation" />
              <CardBody>
                <ul className="space-y-1.5">
                  {agent.guardrails.map((rule, index) => (
                    <li key={index} className="flex gap-2 text-sm text-ink-secondary">
                      <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-tertiary" />
                      {rule}
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          ) : null}
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Test this agent" icon={<FlaskConical className="h-4 w-4" />} />
            <CardBody className="space-y-3">
              <p className="text-xs text-ink-secondary">
                Runs the agent once against this project's real data and opens the resulting run.
              </p>
              {properties.slice(0, 4).map(([name, definition]) => (
                <Field
                  key={name}
                  label={name.replace(/_/g, ' ')}
                  htmlFor={`input-${name}`}
                  required={required.has(name)}
                  hint={definition.description}
                >
                  {definition.enum ? (
                    <Select
                      id={`input-${name}`}
                      value={inputs[name] ?? ''}
                      onChange={(event) => setInputs((current) => ({ ...current, [name]: event.target.value }))}
                    >
                      <option value="" disabled>
                        {definition.enum.length ? `Choose ${name.replace(/_/g, ' ')}…` : 'No options available'}
                      </option>
                      {definition.enum.map((value, index) => (
                        <option key={value} value={value}>
                          {definition.enumNames?.[index] ?? value}
                        </option>
                      ))}
                    </Select>
                  ) : (
                    <Input
                      id={`input-${name}`}
                      value={inputs[name] ?? ''}
                      onChange={(event) => setInputs((current) => ({ ...current, [name]: event.target.value }))}
                      placeholder={String(definition.default ?? '')}
                    />
                  )}
                </Field>
              ))}
              <Button
                variant="primary"
                className="w-full"
                loading={testAgent.isPending}
                onClick={() => {
                  setMessage(null);
                  testAgent.mutate();
                }}
              >
                Run test
              </Button>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Performance" />
            <CardBody>
              <dl className="divide-y divide-line">
                <KeyValue label="Total runs">{agent.usage_count}</KeyValue>
                <KeyValue label="Success rate">{formatPercent(agent.success_rate, 0)}</KeyValue>
                <KeyValue label="Average duration">{formatDuration(agent.avg_duration_ms)}</KeyValue>
                <KeyValue label="Average cost">{formatCurrency(agent.avg_cost_usd, 4)}</KeyValue>
                {agent.rating > 0 ? (
                  <KeyValue label="Rating">
                    <span className="flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 fill-warning text-warning" aria-hidden />
                      {agent.rating.toFixed(1)}
                    </span>
                  </KeyValue>
                ) : null}
              </dl>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Configuration" />
            <CardBody>
              <dl className="divide-y divide-line">
                <KeyValue label="Capability">{agent.capability.replace(/_/g, ' ')}</KeyValue>
                <KeyValue label="Temperature">{agent.temperature}</KeyValue>
                <KeyValue label="Max tokens">{agent.max_tokens.toLocaleString()}</KeyValue>
                <KeyValue label="Token budget">{agent.token_budget.toLocaleString()}</KeyValue>
                <KeyValue label="Cost budget">{formatCurrency(agent.cost_budget_usd)}</KeyValue>
                <KeyValue label="Timeout">{agent.timeout_seconds}s</KeyValue>
                <KeyValue label="Retry policy">
                  {String(agent.retry_policy?.max_attempts ?? 1)} attempt(s)
                </KeyValue>
              </dl>
            </CardBody>
          </Card>

          {agent.supported_tools?.length ? (
            <Card>
              <CardHeader title="Tools" description="MCP servers this agent may use" />
              <CardBody className="flex flex-wrap gap-1.5">
                {agent.supported_tools.map((tool) => (
                  <span key={tool} className="rounded border border-line bg-surface-muted px-2 py-1 font-mono text-xs text-ink-secondary">
                    {tool}
                  </span>
                ))}
              </CardBody>
            </Card>
          ) : null}

          {versions?.length ? (
            <Card>
              <CardHeader title="Version history" />
              <CardBody className="p-0">
                <ul className="divide-y divide-line-subtle">
                  {versions.map((version) => (
                    <li key={version.id} className="px-5 py-2.5">
                      <p className="flex items-center gap-2">
                        <span className="font-mono text-xs font-medium text-ink">v{version.version}</span>
                        <Badge tone={statusTone(version.lifecycle_state)}>{version.lifecycle_state}</Badge>
                      </p>
                      {version.change_summary ? (
                        <p className="mt-0.5 text-xs text-ink-secondary">{version.change_summary}</p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          ) : null}
        </div>
      </div>
    </div>
  );
}
