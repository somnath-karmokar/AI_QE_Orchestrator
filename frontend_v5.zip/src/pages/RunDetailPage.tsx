/**
 * Live agent run experience (spec §27).
 *
 * Shows a step timeline that updates over WebSocket, and for each step the
 * input, a concise reasoning summary, evidence, tool calls, output, confidence,
 * cost and policy decision. Private chain-of-thought is never displayed --
 * the backend does not produce it and this screen has nowhere to show it.
 */
import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Activity, AlertTriangle, ArrowRight, Ban, Check, ChevronRight, CircleDashed,
  CircleDot, Clock, FileText, Handshake, ListOrdered, Loader2, PlayCircle, Printer, ShieldCheck, Wrench, XCircle,
} from 'lucide-react';
import { AgentCollaboration } from '@/features/collaboration/AgentCollaboration';
import { isRiskOutputs, RiskScoreCard } from '@/features/runs/RiskScoreCard';
import { ReasoningTimeline } from '@/features/runs/ReasoningTimeline';
import { api } from '@/services/api';
import { formatCurrency, formatDateTime, formatDuration, formatNumber, useEventStream } from '@/hooks';
import {
  Badge, Button, Card, CardBody, CardHeader, cn, EmptyState, KeyValue,
  LoadingBlock, PageHeader, ProgressBar, statusTone,
} from '@/design-system/primitives';
import type { RunStep } from '@/types';

const ACTIVE_STATUSES = new Set(['queued', 'running', 'awaiting_approval']);

export default function RunDetailPage() {
  const { runId } = useParams<{ runId: string }>();
  const queryClient = useQueryClient();
  const [selectedStepId, setSelectedStepId] = useState<string | null>(null);
  const [view, setView] = useState<'collaboration' | 'steps' | null>(null);

  const { data: run, isLoading } = useQuery({
    queryKey: ['run', runId],
    queryFn: () => api.getRun(runId!),
    enabled: Boolean(runId),
    // Poll as a safety net; the WebSocket is the primary update path.
    refetchInterval: (query) =>
      query.state.data && ACTIVE_STATUSES.has(query.state.data.status) ? 4000 : false,
  });

  const isActive = run ? ACTIVE_STATUSES.has(run.status) : false;

  const { connected } = useEventStream(isActive && runId ? `/runs/${runId}/ws` : null, {
    terminalTypes: ['run_completed', 'run_failed', 'run_paused'],
    onEvent: () => {
      void queryClient.invalidateQueries({ queryKey: ['run', runId] });
      void queryClient.invalidateQueries({ queryKey: ['run-collaboration', runId] });
    },
  });

  const cancel = useMutation({
    mutationFn: () => api.cancelRun(runId!),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['run', runId] }),
  });

  const resume = useMutation({
    mutationFn: () => api.resumeRun(runId!),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['run', runId] }),
  });

  const steps = useMemo(() => [...(run?.steps ?? [])].sort((a, b) => a.sequence - b.sequence), [run]);
  const selectedStep = steps.find((step) => step.id === selectedStepId) ?? steps.find((s) => s.status === 'running') ?? steps[steps.length - 1] ?? null;

  useEffect(() => {
    if (!selectedStepId && steps.length) setSelectedStepId(steps[steps.length - 1].id);
  }, [steps, selectedStepId]);

  if (isLoading) return <LoadingBlock rows={8} />;
  if (!run) return <EmptyState title="Run not found" />;

  const progress = run.step_count ? run.completed_step_count / run.step_count : 0;
  // Flow runs open on the collaboration view; single-agent runs have nobody to collaborate with.
  const activeView = view ?? (run.flow_id ? 'collaboration' : 'steps');
  // A one-step run has nothing to navigate between -- the timeline sidebar
  // would only take width away from the report itself, on screen and on paper.
  const singleStep = steps.length <= 1;

  return (
    <div>
      <PageHeader
        title={run.title}
        description={run.summary ?? undefined}
        breadcrumb={
          run.flow_id ? (
            <Link to={`/flows/${run.flow_id}/runs`} className="text-sm text-ink-secondary hover:text-brand-600">
              ← Flow runs
            </Link>
          ) : (
            <Link to="/runs" className="text-sm text-ink-secondary hover:text-brand-600">
              ← All runs
            </Link>
          )
        }
        actions={
          <>
            <Badge tone={statusTone(run.status)} dot>
              {run.status.replace(/_/g, ' ')}
            </Badge>
            {isActive && connected ? (
              <Badge tone="info" className="print:hidden">
                <Activity className="h-3 w-3 animate-pulse" /> Live
              </Badge>
            ) : null}
            {run.status === 'awaiting_approval' ? (
              <>
                <Link
                  to="/governance?tab=approvals"
                  className="inline-flex h-9 items-center gap-2 rounded border border-line-strong bg-surface px-3.5 text-sm font-medium text-ink hover:bg-surface-muted print:hidden"
                >
                  <ShieldCheck className="h-3.5 w-3.5" /> Review approvals
                </Link>
                <Button variant="primary" loading={resume.isPending} onClick={() => resume.mutate()} className="print:hidden">
                  Resume run
                </Button>
              </>
            ) : null}
            {run.status === 'running' || run.status === 'queued' ? (
              <Button
                variant="danger"
                icon={<Ban className="h-3.5 w-3.5" />}
                loading={cancel.isPending}
                onClick={() => cancel.mutate()}
                className="print:hidden"
              >
                Cancel
              </Button>
            ) : null}
            <Button
              icon={<Printer className="h-3.5 w-3.5" />}
              onClick={() => window.print()}
              className="print:hidden"
            >
              Download report
            </Button>
          </>
        }
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <Metric label="Progress" value={`${run.completed_step_count}/${run.step_count || steps.length}`} progress={progress} />
        <Metric label="Duration" value={formatDuration(run.duration_ms)} />
        <Metric label="Tokens" value={formatNumber(run.total_tokens)} />
        <Metric label="Cost" value={formatCurrency(run.total_cost_usd, 4)} />
        <Metric label="Triggered by" value={run.triggered_by ?? 'system'} small />
      </div>

      {run.flow_id ? (
        <div role="tablist" aria-label="Run views" className="mb-4 flex gap-1 border-b border-line print:hidden">
          {(
            [
              ['collaboration', 'Agent collaboration', Handshake],
              ['steps', 'Step details', ListOrdered],
            ] as const
          ).map(([key, label, Icon]) => (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={activeView === key}
              onClick={() => setView(key)}
              className={cn(
                '-mb-px flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-sm font-medium transition-colors',
                activeView === key
                  ? 'border-brand-500 text-brand-700'
                  : 'border-transparent text-ink-secondary hover:border-line-strong hover:text-ink',
              )}
            >
              <Icon className="h-3.5 w-3.5" aria-hidden />
              {label}
            </button>
          ))}
        </div>
      ) : null}

      {activeView === 'collaboration' && runId ? <AgentCollaboration runId={runId} active={isActive} /> : null}

      <div
        className={cn(
          'grid gap-5',
          singleStep ? 'grid-cols-1' : 'lg:grid-cols-[340px_1fr]',
          activeView !== 'steps' && 'hidden',
        )}
      >
        {/* Timeline -- a single step has nothing to navigate between, so the
            report goes full width instead of sharing it with a one-row list. */}
        {!singleStep ? (
          <Card className="self-start">
            <CardHeader title="Flow timeline" description={`${steps.length} step${steps.length === 1 ? '' : 's'}`} />
            <CardBody className="p-2">
              {steps.length ? (
                <ol className="space-y-0.5">
                  {steps.map((step, index) => (
                    <li key={step.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedStepId(step.id)}
                        aria-current={selectedStep?.id === step.id ? 'step' : undefined}
                        className={cn(
                          'flex w-full items-start gap-3 rounded px-3 py-2.5 text-left transition-colors',
                          selectedStep?.id === step.id ? 'bg-brand-50' : 'hover:bg-surface-muted',
                        )}
                      >
                        <StepIcon status={step.status} />
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center justify-between gap-2">
                            <span className="truncate text-sm font-medium text-ink">{step.label}</span>
                            {step.duration_ms > 0 ? (
                              <span className="tabular shrink-0 text-2xs text-ink-tertiary">
                                {formatDuration(step.duration_ms)}
                              </span>
                            ) : null}
                          </span>
                          <span className="mt-0.5 flex items-center gap-2 text-2xs text-ink-tertiary">
                            <span>Step {index + 1}</span>
                            {step.confidence !== null && step.confidence !== undefined ? (
                              <span>· {(step.confidence * 100).toFixed(0)}% confidence</span>
                            ) : null}
                            {step.attempt > 1 ? <span>· attempt {step.attempt}</span> : null}
                          </span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ol>
              ) : (
                <EmptyState title="Waiting to start" description="Steps appear as the flow executes." />
              )}
            </CardBody>
          </Card>
        ) : null}

        {/* Step detail */}
        {selectedStep ? <StepDetail step={selectedStep} /> : (
          <Card>
            <EmptyState icon={<PlayCircle className="h-5 w-5" />} title="Select a step" description="Choose a step to inspect what it did." />
          </Card>
        )}
      </div>

      {run.error ? (
        <Card className="mt-5 border-danger-border">
          <CardHeader title="Run error" icon={<XCircle className="h-4 w-4 text-danger" />} />
          <CardBody>
            <pre className="overflow-x-auto whitespace-pre-wrap rounded bg-danger-bg px-3 py-2 font-mono text-xs text-danger-text">
              {run.error}
            </pre>
          </CardBody>
        </Card>
      ) : null}
    </div>
  );
}

function Metric({ label, value, progress, small }: { label: string; value: string; progress?: number; small?: boolean }) {
  return (
    <Card>
      <CardBody className="p-4">
        <p className="text-xs font-medium text-ink-secondary">{label}</p>
        <p className={cn('tabular mt-1.5 font-semibold text-ink', small ? 'truncate text-sm' : 'text-xl')}>{value}</p>
        {progress !== undefined ? <ProgressBar value={progress} className="mt-2" label={label} /> : null}
      </CardBody>
    </Card>
  );
}

function StepIcon({ status }: { status: string }) {
  const shared = 'mt-0.5 h-4 w-4 shrink-0';
  if (status === 'succeeded') return <Check className={cn(shared, 'text-success')} aria-label="succeeded" />;
  if (status === 'failed') return <XCircle className={cn(shared, 'text-danger')} aria-label="failed" />;
  if (status === 'running') return <Loader2 className={cn(shared, 'animate-spin text-info')} aria-label="running" />;
  if (status === 'awaiting_approval') return <ShieldCheck className={cn(shared, 'text-warning')} aria-label="awaiting approval" />;
  if (status === 'skipped' || status === 'cancelled') return <CircleDashed className={cn(shared, 'text-ink-tertiary')} aria-label={status} />;
  return <CircleDot className={cn(shared, 'text-ink-tertiary')} aria-label="pending" />;
}

function StepDetail({ step }: { step: RunStep }) {
  const output = step.output ?? {};
  const recommendations = (output.recommendations ?? []) as Record<string, unknown>[];
  const artifacts = (output.artifacts ?? []) as Record<string, unknown>[];
  const riskOutputs = isRiskOutputs(output.outputs) ? output.outputs : null;
  // A risk-scoring card already presents every dimension/band/modifier/test
  // finding on its own terms; the generic list beneath would just repeat it.
  const findings = riskOutputs ? [] : ((output.findings ?? []) as Record<string, unknown>[]);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader
          title={step.label}
          description={step.agent_key ? `Agent: ${step.agent_key}` : step.node_type}
          actions={<Badge tone={statusTone(step.status)}>{step.status.replace(/_/g, ' ')}</Badge>}
        />
        <CardBody className="space-y-4">
          {output.summary ? (
            <div className="rounded border border-line bg-surface-muted px-4 py-3">
              <p className="text-sm leading-relaxed text-ink">{String(output.summary)}</p>
            </div>
          ) : null}

          {/* Concise, user-safe rationale -- never raw model deliberation. */}
          {step.reasoning_summary ? (
            <section>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
                How this was determined
              </h4>
              <ReasoningTimeline text={step.reasoning_summary} />
            </section>
          ) : null}

          <dl className="grid grid-cols-2 gap-x-6 border-t border-line pt-1 sm:grid-cols-4">
            <KeyValue label="Confidence">
              {step.confidence !== null && step.confidence !== undefined ? (
                <span className="flex items-center gap-2">
                  <span className="tabular">{(step.confidence * 100).toFixed(0)}%</span>
                  <ProgressBar
                    value={step.confidence}
                    tone={step.confidence > 0.8 ? 'success' : step.confidence > 0.6 ? 'warning' : 'danger'}
                    className="w-12"
                    label="Confidence"
                  />
                </span>
              ) : (
                '—'
              )}
            </KeyValue>
            <KeyValue label="Duration">{formatDuration(step.duration_ms)}</KeyValue>
            <KeyValue label="Tokens">{formatNumber(step.total_tokens)}</KeyValue>
            <KeyValue label="Cost">{formatCurrency(step.cost_usd, 4)}</KeyValue>
          </dl>

          {step.model ? (
            <p className="flex flex-wrap items-center gap-1.5 text-xs text-ink-tertiary">
              <span className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono">
                {step.provider}
              </span>
              <span className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono">
                {step.model}
              </span>
              {step.deployment ? (
                <span className="rounded border border-line bg-surface-muted px-1.5 py-0.5 font-mono">
                  deployment: {step.deployment}
                </span>
              ) : null}
              {step.started_at ? <span>· started {formatDateTime(step.started_at)}</span> : null}
            </p>
          ) : null}

          {step.error ? (
            <div role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2">
              <p className="text-xs font-semibold text-danger-text">Step failed</p>
              <p className="mt-1 font-mono text-xs text-danger-text">{step.error}</p>
            </div>
          ) : null}
        </CardBody>
      </Card>

      {riskOutputs ? <RiskScoreCard outputs={riskOutputs} /> : null}

      {findings.length ? (
        <Card>
          <CardHeader title="Findings" description={`${findings.length} item${findings.length === 1 ? '' : 's'}`} />
          <CardBody className="max-h-96 overflow-y-auto p-0 print:max-h-none print:overflow-visible">
            <ul className="divide-y divide-line-subtle">
              {findings.slice(0, 40).map((finding, index) => (
                <li key={index} className="px-5 py-2.5">
                  <RecordRow record={finding} />
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : null}

      {recommendations.length ? (
        <Card>
          <CardHeader title="Recommendations" icon={<ArrowRight className="h-4 w-4" />} />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {recommendations.map((item, index) => (
                <li key={index} className="flex items-start gap-2.5 px-5 py-2.5">
                  {item.priority ? (
                    <Badge
                      tone={
                        item.priority === 'critical' || item.priority === 'high'
                          ? 'danger'
                          : item.priority === 'medium'
                            ? 'warning'
                            : 'neutral'
                      }
                      className="mt-0.5 shrink-0"
                    >
                      {String(item.priority)}
                    </Badge>
                  ) : null}
                  <span className="text-sm text-ink">{String(item.action ?? JSON.stringify(item))}</span>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : null}

      <div className="grid gap-4 md:grid-cols-2">
        {step.evidence?.length ? (
          <Card>
            <CardHeader title="Evidence" description="What grounded this result" icon={<FileText className="h-4 w-4" />} />
            <CardBody className="max-h-72 overflow-y-auto p-0 print:max-h-none print:overflow-visible">
              <ul className="divide-y divide-line-subtle">
                {step.evidence.map((item, index) => (
                  <li key={index} className="px-5 py-2.5">
                    <p className="flex items-center gap-2 text-sm text-ink">
                      {item.ref ? <span className="font-mono text-2xs text-ink-tertiary">{item.ref}</span> : null}
                      <span className="truncate">{item.title ?? item.type ?? 'Evidence'}</span>
                      {item.score !== undefined ? (
                        <span className="tabular ml-auto shrink-0 text-2xs text-ink-tertiary">
                          {(item.score * 100).toFixed(0)}%
                        </span>
                      ) : null}
                    </p>
                    {item.detail ? <p className="mt-0.5 text-xs text-ink-secondary">{item.detail}</p> : null}
                    {item.external_id ? (
                      <p className="mt-0.5 font-mono text-2xs text-ink-tertiary">{item.external_id}</p>
                    ) : null}
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        ) : null}

        {step.tool_calls?.length ? (
          <Card>
            <CardHeader title="Tool calls" description="MCP operations performed" icon={<Wrench className="h-4 w-4" />} />
            <CardBody className="max-h-72 overflow-y-auto p-0 print:max-h-none print:overflow-visible">
              <ul className="divide-y divide-line-subtle">
                {step.tool_calls.map((call, index) => (
                  <li key={index} className="flex items-center gap-2 px-5 py-2.5">
                    {call.success ? (
                      <Check className="h-3.5 w-3.5 shrink-0 text-success" aria-label="succeeded" />
                    ) : (
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-warning" aria-label="failed" />
                    )}
                    <code className="flex-1 truncate font-mono text-xs text-ink">
                      {call.server}.{call.tool}
                    </code>
                    {call.duration_ms !== undefined ? (
                      <span className="tabular shrink-0 text-2xs text-ink-tertiary">{call.duration_ms}ms</span>
                    ) : null}
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        ) : null}
      </div>

      {artifacts.length ? (
        <Card>
          <CardHeader title="Artifacts produced" description={`${artifacts.length} created`} />
          <CardBody className="p-0">
            <ul className="divide-y divide-line-subtle">
              {artifacts.slice(0, 25).map((artifact, index) => (
                <li key={index} className="flex items-center gap-2.5 px-5 py-2.5">
                  <Badge tone="brand" className="shrink-0">
                    {String(artifact.type ?? 'artifact').replace(/_/g, ' ')}
                  </Badge>
                  <span className="truncate text-sm text-ink">{String(artifact.label ?? artifact.entity_id)}</span>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : null}

      {Object.keys(step.policy_decision ?? {}).length ? (
        <Card>
          <CardHeader title="Policy decision" icon={<ShieldCheck className="h-4 w-4" />} />
          <CardBody>
            <PolicyDecision decision={step.policy_decision} />
          </CardBody>
        </Card>
      ) : null}
    </div>
  );
}

function RecordRow({ record }: { record: Record<string, unknown> }) {
  const entries = Object.entries(record).filter(
    ([, value]) => value !== null && value !== undefined && typeof value !== 'object',
  );
  const primaryKey = ['title', 'test', 'check', 'module', 'signal', 'metric', 'name', 'action'].find(
    (key) => key in record,
  );
  const primary = primaryKey ? String(record[primaryKey]) : null;

  return (
    <div>
      {primary ? <p className="text-sm font-medium text-ink">{primary}</p> : null}
      <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1">
        {entries
          .filter(([key]) => key !== primaryKey)
          .slice(0, 6)
          .map(([key, value]) => (
            <span key={key} className="text-xs text-ink-secondary">
              <span className="text-ink-tertiary">{key.replace(/_/g, ' ')}:</span>{' '}
              <span className="font-medium text-ink">{String(value)}</span>
            </span>
          ))}
      </div>
    </div>
  );
}

function PolicyDecision({ decision }: { decision: Record<string, unknown> }) {
  const effect = String(decision.effect ?? (decision.decision as string) ?? 'allow');
  const reasons = (decision.reasons ?? []) as string[];
  const matched = (decision.matched_policies ?? []) as { name: string; type: string; effect: string }[];

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Badge tone={effect === 'deny' ? 'danger' : effect === 'require_approval' ? 'warning' : effect === 'warn' ? 'warning' : 'success'}>
          {effect.replace(/_/g, ' ')}
        </Badge>
        {decision.threshold !== undefined ? (
          <span className="text-xs text-ink-secondary">
            Confidence threshold: {Number(decision.threshold) * 100}%
          </span>
        ) : null}
      </div>

      {reasons.length ? (
        <ul className="space-y-1">
          {reasons.map((reason, index) => (
            <li key={index} className="flex gap-1.5 text-sm text-ink-secondary">
              <ChevronRight className="mt-1 h-3 w-3 shrink-0 text-ink-tertiary" />
              {reason}
            </li>
          ))}
        </ul>
      ) : null}

      {matched.length ? (
        <div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-tertiary">
            Policies evaluated
          </p>
          <ul className="space-y-1">
            {matched.map((policy, index) => (
              <li key={index} className="flex items-center gap-2 text-xs text-ink-secondary">
                <Badge tone="neutral">{policy.type?.replace(/_/g, ' ')}</Badge>
                {policy.name}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {decision.approval_request_id ? (
        <Link
          to="/governance?tab=approvals"
          className="inline-flex items-center gap-1 text-sm font-medium text-brand-600 hover:text-brand-700"
        >
          <Clock className="h-3.5 w-3.5" /> Review the pending approval
        </Link>
      ) : null}
    </div>
  );
}
