/** The flow's own dashboard: outcomes, speed, cost, value and step health. */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Activity, BadgeEuro, Gauge, Handshake, Hourglass, Network, PencilRuler, Timer, UserCheck } from 'lucide-react';
import { api } from '@/services/api';
import { formatCurrency, formatDuration, formatNumber, formatPercent, formatRelativeTime } from '@/hooks';
import {
  Badge,
  Card,
  CardBody,
  CardHeader,
  cn,
  EmptyState,
  ErrorState,
  humanize,
  LoadingBlock,
  ProgressBar,
  statusTone,
  TONE_BY_RISK,
} from '@/design-system/primitives';
import {
  ChartCard,
  MetricTile,
  MiniTable,
  OUTCOME_LEGEND,
  OutcomeColumns,
  OutcomeTable,
  RankedBars,
} from '@/features/flow-studio/charts';
import { StepIcon } from '@/features/flow-studio/components';
import { TRIGGER_LABELS, deltaDirection, formatPoints } from '@/features/flow-studio/format';
import { FlowGraphView } from '@/features/flow-graph/FlowGraphView';
import { WindowSelect } from './shared';
import type { FlowDetail, FlowStepHealth } from '@/types';

export default function OverviewTab({ flow }: { flow: FlowDetail }) {
  const flowId = flow.id;
  const [windowDays, setWindowDays] = useState(30);
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['flow-dashboard', flowId, windowDays],
    queryFn: () => api.flowDashboard(flowId, windowDays),
    refetchInterval: 15000,
  });
  const agents = useQuery({
    queryKey: ['agents-catalogue', flow.project_id],
    queryFn: () => api.listAgents({ project_id: flow.project_id, limit: 200 }),
    staleTime: 5 * 60 * 1000,
  });

  if (isLoading) return <LoadingBlock rows={8} className="rounded-lg border border-line bg-surface" />;
  if (error || !data) return <ErrorState message={(error as Error)?.message} onRetry={() => void refetch()} />;

  const { kpis, deltas, daily } = data;
  const agentIcons = Object.fromEntries((agents.data?.items ?? []).map((agent) => [agent.id, agent.icon]));
  const agentNames = Object.fromEntries((agents.data?.items ?? []).map((agent) => [agent.id, agent.name]));
  const budgetUse = kpis.budget_utilisation ?? 0;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-secondary">
          Compared with the previous {windowDays} days. Updates live while runs are in flight.
        </p>
        <WindowSelect value={windowDays} onChange={setWindowDays} />
      </div>

      <section aria-label="Key figures" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <MetricTile
          label="Runs"
          icon={<Activity className="h-3.5 w-3.5" />}
          value={formatNumber(kpis.runs)}
          delta={{
            text: `${deltas.runs >= 0 ? '+' : '−'}${Math.abs(deltas.runs)}`,
            direction: deltas.runs === 0 ? 'flat' : 'better',
            srLabel: 'runs versus the previous period',
          }}
          spark={daily.map((day) => day.runs)}
          sparkLabel="Runs per day"
          hint={`${kpis.succeeded_runs} succeeded · ${kpis.failed_runs} failed${kpis.attention_runs ? ` · ${kpis.attention_runs} waiting` : ''}`}
        />
        <MetricTile
          label="Success rate"
          icon={<Gauge className="h-3.5 w-3.5" />}
          value={formatPercent(kpis.success_rate, 0)}
          delta={
            deltas.success_rate !== null
              ? { text: formatPoints(deltas.success_rate), direction: deltaDirection(deltas.success_rate, true, 0.001), srLabel: 'versus the previous period' }
              : undefined
          }
          hint={`${kpis.finished_runs} finished runs`}
        />
        <MetricTile
          label="Typical duration"
          icon={<Timer className="h-3.5 w-3.5" />}
          value={formatDuration(kpis.p50_duration_ms)}
          delta={
            deltas.p50_duration_ms !== null
              ? {
                  text: `${deltas.p50_duration_ms > 0 ? '+' : '−'}${formatDuration(Math.abs(deltas.p50_duration_ms))}`,
                  direction: deltaDirection(deltas.p50_duration_ms, false, 500),
                  srLabel: 'change in median duration',
                }
              : undefined
          }
          hint={`Slowest 5% take ${formatDuration(kpis.p95_duration_ms)}`}
        />
        <MetricTile
          label="Cost per run"
          icon={<BadgeEuro className="h-3.5 w-3.5" />}
          value={formatCurrency(kpis.avg_cost_usd)}
          delta={
            deltas.avg_cost_usd !== null
              ? {
                  text: `${deltas.avg_cost_usd > 0 ? '+' : '−'}${formatCurrency(Math.abs(deltas.avg_cost_usd))}`,
                  direction: deltaDirection(deltas.avg_cost_usd, false, 0.005),
                  srLabel: 'change in average cost',
                }
              : undefined
          }
          spark={daily.map((day) => day.cost_usd)}
          sparkLabel="AI cost per day"
          hint={`${formatCurrency(kpis.total_cost_usd)} total · ${formatNumber(kpis.total_tokens)} tokens`}
        />
        <MetricTile
          label="Effort saved"
          icon={<Hourglass className="h-3.5 w-3.5" />}
          value={`${kpis.hours_saved} h`}
          hint={`${kpis.automated_steps} agent steps × ${data.assumptions.minutes_saved_per_step} min (estimate)`}
        />
      </section>

      <Card>
        <CardHeader
          icon={<Network className="h-4 w-4" />}
          title="Flow map"
          description={`How the agents connect, with each step's success rate and typical time over the last ${windowDays} days.`}
          actions={
            <>
              {data.last_run ? (
                <Link
                  to={`/runs/${data.last_run.id}`}
                  className="inline-flex h-8 items-center gap-1.5 rounded border border-line-strong bg-surface px-3 text-xs font-medium text-ink hover:bg-surface-muted"
                >
                  <Handshake className="h-3.5 w-3.5" aria-hidden /> Watch the last run
                </Link>
              ) : null}
              <Link
                to={`/flows/${flowId}/designer`}
                className="inline-flex h-8 items-center gap-1.5 rounded border border-line-strong bg-surface px-3 text-xs font-medium text-ink hover:bg-surface-muted"
              >
                <PencilRuler className="h-3.5 w-3.5" aria-hidden /> Edit in designer
              </Link>
            </>
          }
        />
        <div className="p-4">
          <FlowGraphView
            height={Math.min(620, Math.max(380, flow.nodes.length * 78))}
            label={`Graph of ${flow.name}`}
            nodes={flow.nodes.map((node) => {
              const health = data.step_health.find((row) => row.node_key === node.node_key);
              return {
                node_key: node.node_key,
                node_type: node.node_type,
                label: node.label,
                position_x: node.position_x,
                position_y: node.position_y,
                icon: agentIcons[node.agent_id ?? ''] ?? null,
                subtitle:
                  node.node_type === 'agent'
                    ? agentNames[node.agent_id ?? ''] ?? 'Agent'
                    : node.node_type === 'approval'
                      ? 'Human approval'
                      : undefined,
                metrics: health
                  ? [
                      `${formatPercent(health.success_rate, 0)} ok`,
                      health.node_type === 'approval' ? `wait ${formatDuration(health.p50_duration_ms)}` : formatDuration(health.p50_duration_ms),
                    ]
                  : undefined,
              };
            })}
            edges={flow.edges.map((edge) => ({
              id: `${edge.source_node_key}->${edge.target_node_key}`,
              source: edge.source_node_key,
              target: edge.target_node_key,
              branch_label: edge.branch_label,
              state: 'static' as const,
            }))}
          />
        </div>
      </Card>

      <div className="grid gap-5 xl:grid-cols-3">
        <ChartCard
          className="xl:col-span-2"
          title="Run outcomes per day"
          description="Every run of this flow, by how it ended."
          legend={OUTCOME_LEGEND}
          table={<OutcomeTable daily={daily} />}
        >
          <OutcomeColumns daily={daily} height={240} />
        </ChartCard>

        <Card className="flex flex-col">
          <CardHeader title="Right now" />
          <CardBody className="flex-1 space-y-5">
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-ink-tertiary">Last run</p>
              {data.last_run ? (
                <Link to={`/runs/${data.last_run.id}`} className="mt-1.5 flex items-center justify-between gap-2 rounded-lg border border-line p-3 hover:bg-surface-muted">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink">Run #{data.last_run.run_number}</p>
                    <p className="text-xs text-ink-secondary">
                      {TRIGGER_LABELS[data.last_run.trigger] ?? humanize(data.last_run.trigger)} · {formatRelativeTime(data.last_run.created_at)} ·{' '}
                      {formatDuration(data.last_run.duration_ms)}
                    </p>
                  </div>
                  <Badge tone={statusTone(data.last_run.status)} dot>
                    {humanize(data.last_run.status)}
                  </Badge>
                </Link>
              ) : (
                <p className="mt-1.5 text-sm text-ink-secondary">This flow has not run yet.</p>
              )}
            </div>

            <div>
              <p className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-ink-tertiary">
                <UserCheck className="h-3.5 w-3.5" aria-hidden /> Waiting for a decision
              </p>
              {data.pending_approvals.length ? (
                <ul className="mt-1.5 space-y-1.5">
                  {data.pending_approvals.slice(0, 3).map((approval) => (
                    <li key={approval.id}>
                      <Link to="/governance" className="flex items-center justify-between gap-2 rounded border border-warning-border bg-warning-bg px-3 py-2 text-xs text-warning-text">
                        <span className="truncate">{approval.title}</span>
                        <Badge tone={TONE_BY_RISK[approval.risk_level] ?? 'neutral'}>{approval.risk_level}</Badge>
                      </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1.5 text-sm text-ink-secondary">Nothing waiting.</p>
              )}
            </div>

            <div>
              <div className="flex items-baseline justify-between">
                <p className="text-xs font-medium uppercase tracking-wide text-ink-tertiary">Budget use per run</p>
                <p className="text-xs text-ink-secondary tabular">
                  {formatCurrency(kpis.avg_cost_usd)} of {formatCurrency(data.flow.cost_budget_usd)}
                </p>
              </div>
              <ProgressBar className="mt-2" value={budgetUse} tone={budgetUse > 0.8 ? 'warning' : 'brand'} label="Average budget use" />
            </div>

            {data.triggers.length ? (
              <div>
                <p className="mb-2 text-xs font-medium uppercase tracking-wide text-ink-tertiary">How runs start</p>
                <RankedBars
                  label="Runs by trigger"
                  rows={data.triggers.map((item) => ({ label: TRIGGER_LABELS[item.trigger] ?? humanize(item.trigger), value: item.runs }))}
                  format={(value) => `${value}`}
                />
              </div>
            ) : null}
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader title="Step health" description="How each step behaves across every run in the window." />
        {data.step_health.length ? <StepHealthTable rows={data.step_health} /> : (
          <EmptyState title="No step data yet" description="Run the flow to see how each step performs." />
        )}
      </Card>

      <Card>
        <CardHeader
          title="Recent runs"
          actions={
            <Link to={`/flows/${flowId}/runs`} className="text-sm font-medium text-brand-600 hover:text-brand-700">
              All runs
            </Link>
          }
        />
        <div className="p-4">
          <MiniTable
            caption="Recent runs"
            maxHeight={420}
            rows={data.recent_runs}
            columns={[
              {
                header: 'Run',
                render: (run) => (
                  <Link to={`/runs/${run.id}`} className="font-medium text-ink hover:text-brand-600">
                    #{run.run_number}
                  </Link>
                ),
              },
              { header: 'Status', render: (run) => <Badge tone={statusTone(run.status)} dot>{humanize(run.status)}</Badge> },
              { header: 'Trigger', render: (run) => TRIGGER_LABELS[run.trigger] ?? humanize(run.trigger) },
              { header: 'Started', render: (run) => formatRelativeTime(run.created_at) },
              { header: 'Steps', render: (run) => `${run.completed_step_count}/${run.step_count}`, numeric: true },
              { header: 'Duration', render: (run) => formatDuration(run.duration_ms), numeric: true },
              { header: 'Cost', render: (run) => formatCurrency(run.total_cost_usd, 3), numeric: true },
            ]}
          />
        </div>
      </Card>
    </div>
  );
}

export function StepHealthTable({ rows }: { rows: FlowStepHealth[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[820px] text-sm">
        <caption className="sr-only">Step health</caption>
        <thead>
          <tr className="border-b border-line bg-surface-muted text-left text-xs text-ink-secondary">
            <th scope="col" className="px-5 py-2 font-medium">Step</th>
            <th scope="col" className="px-3 py-2 text-right font-medium">Executions</th>
            <th scope="col" className="w-44 px-3 py-2 font-medium">Success</th>
            <th scope="col" className="px-3 py-2 text-right font-medium">p50</th>
            <th scope="col" className="px-3 py-2 text-right font-medium">p95</th>
            <th scope="col" className="px-3 py-2 text-right font-medium">Avg cost</th>
            <th scope="col" className="px-3 py-2 text-right font-medium">Confidence</th>
            <th scope="col" className="px-5 py-2 font-medium">Most common error</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const rate = row.success_rate ?? 0;
            return (
              <tr key={row.node_key} className="border-b border-line-subtle last:border-0">
                <td className="px-5 py-2.5">
                  <span className="flex items-center gap-2 font-medium text-ink">
                    <StepIcon type={row.node_type} className="text-ink-tertiary" />
                    {row.label}
                  </span>
                </td>
                <td className="px-3 py-2.5 text-right text-ink-secondary tabular">{row.executions}</td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <ProgressBar
                      value={rate}
                      tone={rate >= 0.95 ? 'brand' : rate >= 0.85 ? 'warning' : 'danger'}
                      label={`${row.label} success rate`}
                    />
                    <span className="w-10 shrink-0 text-right text-xs text-ink tabular">{formatPercent(row.success_rate, 0)}</span>
                  </div>
                </td>
                <td className="px-3 py-2.5 text-right text-ink-secondary tabular">{formatDuration(row.p50_duration_ms)}</td>
                <td className="px-3 py-2.5 text-right text-ink-secondary tabular">{formatDuration(row.p95_duration_ms)}</td>
                <td className="px-3 py-2.5 text-right text-ink-secondary tabular">
                  {row.node_type === 'agent' ? formatCurrency(row.avg_cost_usd, 3) : '—'}
                </td>
                <td className="px-3 py-2.5 text-right text-ink-secondary tabular">{formatPercent(row.avg_confidence, 0)}</td>
                <td className={cn('max-w-[260px] px-5 py-2.5 text-xs', row.top_error ? 'text-danger-text' : 'text-ink-tertiary')}>
                  <span className="line-clamp-2">{row.top_error ?? 'None'}</span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
