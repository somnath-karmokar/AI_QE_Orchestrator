/** Sign-in screen. In demo mode it also lists the seeded accounts. */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowRight, Shield, Sparkles } from 'lucide-react';
import { api, ApiError } from '@/services/api';
import { useSession } from '@/store';
import { useSystemInfo } from '@/hooks';
import { Badge, Button, Field, Input } from '@/design-system/primitives';

export function LoginPage() {
  const signIn = useSession((state) => state.signIn);
  const { data: systemInfo } = useSystemInfo();
  const { data: demoUsers } = useQuery({
    queryKey: ['demo-users'],
    queryFn: api.demoUsers,
    retry: false,
  });

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function submit(nextEmail: string, nextPassword: string) {
    setSubmitting(true);
    setError(null);
    try {
      const response = await api.login(nextEmail, nextPassword);
      signIn(response.user, response.access_token);
    } catch (caught) {
      setError(
        caught instanceof ApiError
          ? caught.message
          : 'Unable to reach the platform. Check that the API is running.',
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Brand panel: deep navy, no gradients, per the design language. */}
      <div className="relative hidden w-1/2 flex-col justify-between bg-navy-700 p-12 lg:flex">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded bg-brand-500">
            <Sparkles className="h-4.5 w-4.5 text-white" />
          </div>
          <span className="text-lg font-semibold text-white">AI QE Orchestrator</span>
        </div>

        <div className="max-w-lg">
          <h1 className="text-4xl font-semibold leading-tight text-white text-balance">
            Intelligent agents. Governed orchestration. Continuous quality.
          </h1>
          <p className="mt-5 text-md leading-relaxed text-navy-100">
            Discover quality engineering agents, compose them into governed workflows, execute them
            against your applications, and learn from every run.
          </p>

          <dl className="mt-10 grid grid-cols-2 gap-x-8 gap-y-6">
            {[
              ['23', 'Specialised QE agents'],
              ['6', 'MCP tool integrations'],
              ['Full', 'Audit and cost governance'],
              ['Chroma', 'Knowledge Fabric retrieval'],
            ].map(([value, label]) => (
              <div key={label}>
                <dt className="text-2xl font-semibold text-white">{value}</dt>
                <dd className="mt-0.5 text-sm text-navy-200">{label}</dd>
              </div>
            ))}
          </dl>
        </div>

        <p className="text-2xs text-navy-300">
          {systemInfo?.app_name} v{systemInfo?.version} · {systemInfo?.environment}
        </p>
      </div>

      {/* Sign-in panel */}
      <div className="flex w-full items-center justify-center bg-surface-muted px-6 py-12 lg:w-1/2">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden">
            <div className="mb-3 flex h-9 w-9 items-center justify-center rounded bg-brand-500">
              <Sparkles className="h-4.5 w-4.5 text-white" />
            </div>
            <h1 className="text-2xl font-semibold text-ink">AI QE Orchestrator</h1>
          </div>

          <div className="rounded-lg border border-line bg-surface p-8 shadow-card">
            <h2 className="text-2xl font-semibold text-ink">Sign in</h2>
            <p className="mt-1 text-sm text-ink-secondary">
              Access your quality engineering workspace.
            </p>

            <form
              className="mt-6 space-y-4"
              onSubmit={(event) => {
                event.preventDefault();
                void submit(email, password);
              }}
            >
              <Field label="Email address" htmlFor="email" required>
                <Input
                  id="email"
                  type="email"
                  autoComplete="username"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@example.com"
                  required
                />
              </Field>

              <Field label="Password" htmlFor="password" required>
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="••••••••"
                  required
                />
              </Field>

              {error ? (
                <div role="alert" className="rounded border border-danger-border bg-danger-bg px-3 py-2">
                  <p className="text-sm font-medium text-danger-text">{error}</p>
                </div>
              ) : null}

              <Button type="submit" variant="primary" size="lg" className="w-full" loading={submitting}>
                Sign in
                {!submitting ? <ArrowRight className="h-4 w-4" /> : null}
              </Button>
            </form>
          </div>

          {demoUsers?.length ? (
            <div className="mt-6 rounded-lg border border-line bg-surface p-5 shadow-card">
              <div className="mb-3 flex items-center gap-2">
                <Shield className="h-3.5 w-3.5 text-ink-tertiary" />
                <h3 className="text-sm font-semibold text-ink">Demo accounts</h3>
                <Badge tone="info">Demo Mode</Badge>
              </div>
              <p className="mb-3 text-xs text-ink-secondary">
                Select an account to sign in. Each role sees a different slice of the platform.
              </p>
              <ul className="space-y-1.5">
                {demoUsers.map((user) => (
                  <li key={user.email}>
                    <button
                      type="button"
                      onClick={() => {
                        setEmail(user.email);
                        setPassword('Demo!2024');
                        void submit(user.email, 'Demo!2024');
                      }}
                      className="flex w-full items-center justify-between gap-3 rounded border border-line px-3 py-2
                                 text-left transition-colors hover:border-brand-200 hover:bg-brand-50"
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium text-ink">{user.full_name}</span>
                        <span className="block truncate text-xs text-ink-secondary">{user.job_title}</span>
                      </span>
                      <Badge tone="neutral" className="shrink-0">
                        {user.role_label}
                      </Badge>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
