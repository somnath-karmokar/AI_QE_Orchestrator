/** Resolves an agent's stored icon name to a Lucide icon, with a safe fallback. */
import {
  Accessibility, Activity, Bot, CalendarRange, ClipboardCheck, Code2, Copy, Database,
  DatabaseZap, FileCode2, FileSearch, FileText, Filter, Gauge, GitBranch, Library,
  ListTree, Microscope, MonitorPlay, Network, PlayCircle, Plug, SearchX, Sparkles,
  Table, Ticket, TrendingUp, UserCheck, Workflow, Wrench, type LucideIcon,
} from 'lucide-react';
import { cn } from '@/design-system/primitives';

const ICONS: Record<string, LucideIcon> = {
  Accessibility, Activity, Bot, CalendarRange, ClipboardCheck, Code2, Copy, Database,
  DatabaseZap, FileCode2, FileSearch, FileText, Filter, Gauge, GitBranch, Library,
  ListTree, Microscope, MonitorPlay, Network, PlayCircle, Plug, SearchX, Sparkles,
  Table, Ticket, TrendingUp, UserCheck, Workflow, Wrench,
};

export function AgentIcon({
  name,
  className,
  tone = 'brand',
}: {
  name?: string | null;
  className?: string;
  tone?: 'brand' | 'neutral';
}) {
  const Icon = (name && ICONS[name]) || Bot;
  return (
    <span
      className={cn(
        'flex items-center justify-center rounded-lg border',
        tone === 'brand' ? 'border-brand-100 bg-brand-50 text-brand-600' : 'border-line bg-surface-muted text-ink-secondary',
        className,
      )}
      aria-hidden
    >
      <Icon className="h-[55%] w-[55%]" />
    </span>
  );
}
