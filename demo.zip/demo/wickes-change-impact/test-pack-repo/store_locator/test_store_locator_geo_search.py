"""
Store locator returns nearby stores for a postcode
"""
# journey: store-locator
# priority: P3
# tags: store-locator, maps

import pytest


def test_store_locator_geo_search():
    """Store locator returns nearby stores for a postcode."""
    result = run_scenario("store-locator", "store_locator_geo_search")
    assert result.passed, result.failure_reason
