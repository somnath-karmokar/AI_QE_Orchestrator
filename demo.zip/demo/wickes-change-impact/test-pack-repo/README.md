# Wickes test pack

One directory per customer journey. Each test file's header names the journey, priority (P1/P2/P3) and topic tags the Impact Analyzer reads to select impacted tests for a change request:

    # journey: checkout-payment
    # priority: P1
    # tags: payment, apple-pay, pci, 3ds

Test bodies drive the shared scenario runner rather than raw page code, so a change to a page object updates every test that uses it in one place.
