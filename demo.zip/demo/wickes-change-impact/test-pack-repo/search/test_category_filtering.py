"""
Category page filters narrow results correctly
"""
# journey: search
# priority: P3
# tags: search, plp, filters

import pytest


def test_category_filtering():
    """Category page filters narrow results correctly."""
    result = run_scenario("search", "category_filtering")
    assert result.passed, result.failure_reason
