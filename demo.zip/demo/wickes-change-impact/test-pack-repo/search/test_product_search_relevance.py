"""
Search results rank in-stock, relevant products first
"""
# journey: search
# priority: P2
# tags: search, plp

import pytest


def test_product_search_relevance():
    """Search results rank in-stock, relevant products first."""
    result = run_scenario("search", "product_search_relevance")
    assert result.passed, result.failure_reason
