"""
Account login with multi-factor authentication
"""
# journey: account
# priority: P2
# tags: account, login, security

import pytest


def test_login_mfa():
    """Account login with multi-factor authentication."""
    result = run_scenario("account", "login_mfa")
    assert result.passed, result.failure_reason
