"""
Saved payment methods are listed and usable at checkout
"""
# journey: account
# priority: P2
# tags: account, payment, pci

import pytest


def test_saved_payment_methods():
    """Saved payment methods are listed and usable at checkout."""
    result = run_scenario("account", "saved_payment_methods")
    assert result.passed, result.failure_reason
