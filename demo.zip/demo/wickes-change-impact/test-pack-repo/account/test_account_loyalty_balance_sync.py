"""
Loyalty points balance matches the ledger after a purchase
"""
# journey: account
# priority: P2
# tags: account, loyalty, data
# defect_history: 1 in last 90d

import pytest


def test_account_loyalty_balance_sync():
    """Loyalty points balance matches the ledger after a purchase."""
    result = run_scenario("account", "account_loyalty_balance_sync")
    assert result.passed, result.failure_reason
