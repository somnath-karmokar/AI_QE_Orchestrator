"""
Customer can select an available delivery slot
"""
# journey: delivery
# priority: P2
# tags: delivery, scheduling
# defect_history: 1 in last 90d

import pytest


def test_delivery_slot_selection():
    """Customer can select an available delivery slot."""
    result = run_scenario("delivery", "delivery_slot_selection")
    assert result.passed, result.failure_reason
