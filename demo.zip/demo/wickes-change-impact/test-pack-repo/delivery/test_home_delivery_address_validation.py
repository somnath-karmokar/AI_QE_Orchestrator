"""
Home delivery address is validated before dispatch
"""
# journey: delivery
# priority: P2
# tags: delivery, address

import pytest


def test_home_delivery_address_validation():
    """Home delivery address is validated before dispatch."""
    result = run_scenario("delivery", "home_delivery_address_validation")
    assert result.passed, result.failure_reason
