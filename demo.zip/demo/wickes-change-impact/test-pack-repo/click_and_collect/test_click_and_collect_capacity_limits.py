"""
Store collect slots respect capacity limits at peak
"""
# journey: click-and-collect
# priority: P2
# tags: click-and-collect, store, peak

import pytest


def test_click_and_collect_capacity_limits():
    """Store collect slots respect capacity limits at peak."""
    result = run_scenario("click-and-collect", "click_and_collect_capacity_limits")
    assert result.passed, result.failure_reason
