"""
Customer can book a click and collect slot
"""
# journey: click-and-collect
# priority: P2
# tags: click-and-collect, store, scheduling

import pytest


def test_click_and_collect_slot_booking():
    """Customer can book a click and collect slot."""
    result = run_scenario("click-and-collect", "click_and_collect_slot_booking")
    assert result.passed, result.failure_reason
