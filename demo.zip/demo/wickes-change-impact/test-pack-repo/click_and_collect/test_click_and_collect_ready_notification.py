"""
Ready-for-collection notification is sent
"""
# journey: click-and-collect
# priority: P3
# tags: click-and-collect, notifications

import pytest


def test_click_and_collect_ready_notification():
    """Ready-for-collection notification is sent."""
    result = run_scenario("click-and-collect", "click_and_collect_ready_notification")
    assert result.passed, result.failure_reason
