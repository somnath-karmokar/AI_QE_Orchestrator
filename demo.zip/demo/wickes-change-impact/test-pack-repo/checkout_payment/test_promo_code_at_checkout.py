"""
A valid promo code is applied to the basket total at checkout
"""
# journey: checkout-payment
# priority: P2
# tags: checkout, promotion

import pytest


def test_promo_code_at_checkout():
    """A valid promo code is applied to the basket total at checkout."""
    result = run_scenario("checkout-payment", "promo_code_at_checkout")
    assert result.passed, result.failure_reason
