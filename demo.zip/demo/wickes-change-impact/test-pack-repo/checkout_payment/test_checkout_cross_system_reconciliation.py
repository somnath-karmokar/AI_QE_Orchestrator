"""
Order total reconciles across commerce, payment gateway and finance
"""
# journey: checkout-payment
# priority: P1
# tags: checkout, finance, reconciliation, payment
# defect_history: 2 in last 90d

import pytest


def test_checkout_cross_system_reconciliation():
    """Order total reconciles across commerce, payment gateway and finance."""
    result = run_scenario("checkout-payment", "checkout_cross_system_reconciliation")
    assert result.passed, result.failure_reason
