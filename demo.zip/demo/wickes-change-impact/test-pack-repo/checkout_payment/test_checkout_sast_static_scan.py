"""
Static security scan of the checkout and payment code paths
"""
# journey: checkout-payment
# priority: P2
# tags: nft, security, pci, sast

import pytest


def test_checkout_sast_static_scan():
    """Static security scan of the checkout and payment code paths."""
    result = run_scenario("checkout-payment", "checkout_sast_static_scan")
    assert result.passed, result.failure_reason
