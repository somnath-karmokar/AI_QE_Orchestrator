"""
End-to-end: checkout -> payment -> order -> finance ledger
"""
# journey: checkout-payment
# priority: P1
# tags: checkout, payment, order, finance, e2e
# defect_history: 1 in last 90d

import pytest


def test_checkout_end_to_end_order_to_finance():
    """End-to-end: checkout -> payment -> order -> finance ledger."""
    result = run_scenario("checkout-payment", "checkout_end_to_end_order_to_finance")
    assert result.passed, result.failure_reason
