"""
Double-submitting checkout does not charge the customer twice
"""
# journey: checkout-payment
# priority: P1
# tags: payment, negative, duplicate

import pytest


def test_checkout_duplicate_payment_guard():
    """Double-submitting checkout does not charge the customer twice."""
    result = run_scenario("checkout-payment", "checkout_duplicate_payment_guard")
    assert result.passed, result.failure_reason
