"""
Apple Pay authorisation completes and order is confirmed
"""
# journey: checkout-payment
# priority: P1
# tags: payment, apple-pay, pci, 3ds
# defect_history: 3 in last 90d

import pytest


def test_apple_pay_authorisation():
    """Apple Pay authorisation completes and order is confirmed."""
    result = run_scenario("checkout-payment", "apple_pay_authorisation")
    assert result.passed, result.failure_reason
