"""
A declined card shows a clear error and does not create an order
"""
# journey: checkout-payment
# priority: P1
# tags: payment, negative, decline, 3ds
# defect_history: 1 in last 90d

import pytest


def test_checkout_declined_payment_path():
    """A declined card shows a clear error and does not create an order."""
    result = run_scenario("checkout-payment", "checkout_declined_payment_path")
    assert result.passed, result.failure_reason
