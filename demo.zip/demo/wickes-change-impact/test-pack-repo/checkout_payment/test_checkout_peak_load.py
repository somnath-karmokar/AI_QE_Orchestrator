"""
Checkout holds target throughput under simulated peak-trading load
"""
# journey: checkout-payment
# priority: P2
# tags: nft, performance, peak, oat

import pytest


def test_checkout_peak_load():
    """Checkout holds target throughput under simulated peak-trading load."""
    result = run_scenario("checkout-payment", "checkout_peak_load")
    assert result.passed, result.failure_reason

# tuned for Black Friday capacity planning
