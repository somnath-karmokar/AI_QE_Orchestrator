"""
Basket totals, tax and delivery charge are calculated correctly
"""
# journey: checkout-payment
# priority: P1
# tags: checkout, totals, pricing

import pytest


def test_checkout_basket_totals():
    """Basket totals, tax and delivery charge are calculated correctly."""
    result = run_scenario("checkout-payment", "checkout_basket_totals")
    assert result.passed, result.failure_reason
