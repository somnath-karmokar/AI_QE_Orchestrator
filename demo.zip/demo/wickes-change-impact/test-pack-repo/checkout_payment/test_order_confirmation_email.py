"""
Order confirmation email is sent with correct order detail
"""
# journey: checkout-payment
# priority: P2
# tags: checkout, notifications

import pytest


def test_order_confirmation_email():
    """Order confirmation email is sent with correct order detail."""
    result = run_scenario("checkout-payment", "order_confirmation_email")
    assert result.passed, result.failure_reason
