"""
Post-release smoke: checkout is live and taking real-shaped orders
"""
# journey: checkout-payment
# priority: P1
# tags: checkout, smoke, post-release, peak-readiness

import pytest


def test_checkout_post_release_smoke():
    """Post-release smoke: checkout is live and taking real-shaped orders."""
    result = run_scenario("checkout-payment", "checkout_post_release_smoke")
    assert result.passed, result.failure_reason
