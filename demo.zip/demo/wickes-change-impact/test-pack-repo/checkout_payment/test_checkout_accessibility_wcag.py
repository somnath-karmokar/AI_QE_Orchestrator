"""
Checkout meets WCAG 2.1 AA accessibility criteria
"""
# journey: checkout-payment
# priority: P2
# tags: nft, accessibility, wcag

import pytest


def test_checkout_accessibility_wcag():
    """Checkout meets WCAG 2.1 AA accessibility criteria."""
    result = run_scenario("checkout-payment", "checkout_accessibility_wcag")
    assert result.passed, result.failure_reason
