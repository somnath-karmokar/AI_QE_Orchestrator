"""
Dynamic security scan of the checkout and payment endpoints
"""
# journey: checkout-payment
# priority: P1
# tags: nft, security, pci, dast

import pytest


def test_checkout_pci_dast_scan():
    """Dynamic security scan of the checkout and payment endpoints."""
    result = run_scenario("checkout-payment", "checkout_pci_dast_scan")
    assert result.passed, result.failure_reason
