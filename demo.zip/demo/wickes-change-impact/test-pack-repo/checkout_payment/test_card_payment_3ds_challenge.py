"""
Card payment with a 3D Secure challenge step
"""
# journey: checkout-payment
# priority: P1
# tags: payment, card, pci, 3ds
# defect_history: 1 in last 90d

import pytest


def test_card_payment_3ds_challenge():
    """Card payment with a 3D Secure challenge step."""
    result = run_scenario("checkout-payment", "card_payment_3ds_challenge")
    assert result.passed, result.failure_reason
