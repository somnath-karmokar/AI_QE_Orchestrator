# Wickes Change Impact & Risk Analyzer — client demo

A live, narrated demonstration of the **Impact Analyzer Agent**, running the
exact 15-dimension weighted risk model specified in
`requirement_docs_2/AI QE Use Case_Change Impact Risk Analyzer_for Somnath.pptx`
and `image (13).png`, against:

- **`test-pack-repo/`** — a real local git repository of synthetic test packs,
  standing in for the customer's own test-pack repo (25 tests across 6
  journeys: checkout & payment, delivery, click & collect, search, account,
  store locator).
- **`change_requests.csv`** — a Jira-export-shaped change board, standing in
  for the customer's Jira, with 6 change requests spanning all four risk
  bands.

The agent reads the board, scores each change, bands it, selects impacted
tests from the repo, and prints every step of the pipeline as it runs — the
same INPUT → SCORE → BAND → SELECT → OUTPUT → LEARN flow from slide 2 of the
deck.

## Running it

```bash
cd backend
./.venv/Scripts/python.exe scripts/build_wickes_demo_data.py        # (re)build the demo data
./.venv/Scripts/python.exe scripts/run_wickes_impact_analyzer_demo.py
```

Useful flags:

| Flag | What it does |
|---|---|
| `--change CR-1001` | Run one change request only — the Apple Pay flagship example |
| `--pace 2` | Pause 2 seconds between pipeline steps, so a live narration has room |
| `--quiet` | Print step headers and results only, skip the detail tables |

`build_wickes_demo_data.py` is safe to re-run any time — it rebuilds the git
repo and CSV from scratch, so the demo always starts from a known state.

## The flagship example: CR-1001

`change_requests.csv`'s first row is the client's own worked example from
slide 3 — *Hybris Checkout & Payment: Apple Pay auth change* — entered with
the **exact same 15 dimension scores** the deck lists by hand. Running it
reproduces their own numbers precisely:

| | Deck (slide 3) | This demo |
|---|---|---|
| Base weighted score | 124 / 140 | 124 / 140 |
| Band | Critical / P1 | Critical / P1 |
| Veto triggered | Business Criticality=5 & Security=5 | `business_criticality`, `security_data_privacy` |
| Modifier | +2 (risk elevated) | +2 (risk elevated) |

The tests it selects from `test-pack-repo/checkout_payment/` cover every item
on slide 3's own "Coverage Applied" checklist: end-to-end order-to-finance,
cross-system reconciliation, the negative/failure paths (3DS, decline,
duplicate), PCI security (SAST/DAST), WCAG accessibility, and peak-load/OAT.
`tests/test_wickes_demo_data.py::test_cr_1001_selection_covers_every_item_on_the_worked_examples_checklist`
holds this exactly, on every build.

## The other five change requests

Deliberately spread across the other three bands, so the demo shows the full
range rather than only the headline example:

| Issue | Change | Band | Why |
|---|---|---|---|
| CR-1002 | Loyalty ledger migration to a new data model | High / P2 | Data migration + legacy/low-coverage code, no veto |
| CR-1003 | Click & collect slot capacity for Christmas peak | High / P2 (**veto**) | Would score Medium (58) — the peak-trading veto pushes it up, on a change that looks routine at first glance |
| CR-1004 | Product search relevance tuning | Low | Small, localised, well-understood |
| CR-1005 | Store locator map provider swap | Medium / P3 | Third-party dependency change, no customer/payment data |
| CR-1006 | Home delivery BFPO address validation | Medium / P3 | New feature, moderate integration touch |

CR-1003 is worth calling out live: it is the second, independent proof that
the veto rule generalises rather than being special-cased for the flagship
example — a change nobody would flag as "Critical" on its risk total alone
still gets escalated because it touches peak trading.

## What is "AI" here, honestly

- **SCORE (step 2)** runs on the dimension scores given in the CSV — the
  numbers a QE analyst (or an earlier AI pass) has already confirmed. This is
  what makes the demo exactly reproducible on stage, run after run.
- **Step 1b** additionally runs a first, independent AI-style read of each
  change's free-text description (`app.services.wickes_risk_model.suggest_scores`,
  a deterministic keyword/heuristic classifier — no network call, no
  variance) and shows how many of the 15 dimensions it agrees with the
  confirmed scores on. This is the honest way to say "the AI proposes, a
  human or a prior review confirms" without overstating what a live demo can
  prove about a model's judgement in the room.
- **SELECT (step 4)** is not a keyword trick dressed up — it is the same
  ranked, deduplicated, P1-floor-enforced selection
  `app/services/wickes_test_pack.py` implements and
  `tests/test_wickes_test_pack.py` holds to specific, adversarial cases (a
  test that only shares a journey folder and nothing else must **not** be
  swept in for free).

## Where the code lives

| | |
|---|---|
| The 15-dimension formula, bands, veto rule, modifier | `backend/app/services/wickes_risk_model.py` |
| Test-pack scanning and impacted-test selection | `backend/app/services/wickes_test_pack.py` |
| Demo data builder (this git repo + this CSV) | `backend/scripts/build_wickes_demo_data.py` |
| The narrated runner | `backend/scripts/run_wickes_impact_analyzer_demo.py` |
| Tests, including the exact worked-example reproduction | `backend/tests/test_wickes_risk_model.py`, `test_wickes_test_pack.py`, `test_wickes_demo_data.py` |

This is a client-specific risk model, kept apart from the platform's general-
purpose Impact Analyzer (`app/agents/implementations/planning.py`), which
uses a different, project-agnostic scoring approach for every other project.
Wickes's own 15 weighted dimensions and band thresholds are exactly that —
theirs — and are not asserted to be the right model for any other client.
